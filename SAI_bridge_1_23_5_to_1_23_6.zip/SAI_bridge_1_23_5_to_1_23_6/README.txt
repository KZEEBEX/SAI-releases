SAI UPDATE

Close SAI and run INSTALL_SAI_BRIDGE.cmd.
The updater preserves user_data and app/.venv and creates a rollback backup.
