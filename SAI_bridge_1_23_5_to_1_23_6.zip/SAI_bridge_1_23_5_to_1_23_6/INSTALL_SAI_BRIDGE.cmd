@echo off
setlocal
cd /d "%~dp0"
title SAI Update
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
set "PY=python"
for %%D in ("%~dp0..\..\..\..\..") do set "TARGET=%%~fD"
if exist "%TARGET%\app\.venv\Scripts\python.exe" set "PY=%TARGET%\app\.venv\Scripts\python.exe"
if exist "%TARGET%\_runtime\python\python.exe" set "PY=%TARGET%\_runtime\python\python.exe"
if exist "%TARGET%\_offline\python\python.exe" set "PY=%TARGET%\_offline\python\python.exe"
timeout /t 3 /nobreak >nul
"%PY%" "%~dp0install_bridge.py" --restart
set "EXIT_CODE=%ERRORLEVEL%"
if "%EXIT_CODE%"=="0" exit /b 0
echo UPDATE FAILED. The previous SAI version was restored.
if exist "%~dp0SAI_BRIDGE_LAST_LOG.txt" start "" notepad.exe "%~dp0SAI_BRIDGE_LAST_LOG.txt"
pause
exit /b %EXIT_CODE%
