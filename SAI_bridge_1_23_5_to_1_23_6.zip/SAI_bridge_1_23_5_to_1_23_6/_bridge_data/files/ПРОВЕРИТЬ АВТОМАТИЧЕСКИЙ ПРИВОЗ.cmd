@echo off
setlocal
title SAI - Automatic receipt readiness
set "SAI_ROOT=%~dp0"
if not exist "%SAI_ROOT%app\.venv\Scripts\python.exe" goto no_python
"%SAI_ROOT%app\.venv\Scripts\python.exe" "%SAI_ROOT%app\run_receipt_readiness.py" automatic
set "SAI_EXIT=%ERRORLEVEL%"
goto finish
:no_python
echo ERROR: SAI Python was not found.
set "SAI_EXIT=9009"
:finish
echo.
echo Exit code: %SAI_EXIT%
pause
exit /b %SAI_EXIT%
