@echo off
setlocal
cd /d "%~dp0"
"app\.venv\Scripts\python.exe" "make_online_release.py"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
pause
exit /b %EXIT_CODE%
