@echo off
setlocal
cd /d "%~dp0"
set "SAI_PYTHON=app\.venv\Scripts\python.exe"
if not exist "%SAI_PYTHON%" set "SAI_PYTHON=python"
"%SAI_PYTHON%" "app\sai_admin.py"
if errorlevel 1 pause
endlocal
