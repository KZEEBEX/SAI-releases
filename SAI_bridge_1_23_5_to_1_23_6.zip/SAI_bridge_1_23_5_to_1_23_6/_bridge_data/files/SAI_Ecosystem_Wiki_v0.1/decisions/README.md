# Журнал архитектурных решений

ADR фиксируют решения, которые нельзя терять между чатами и разработчиками.

| ADR | Решение | Статус |
|---|---|---|
| [001](ADR-001-SAI-AS-MODULE.md) | SAI — модуль экосистемы | принято |
| [002](ADR-002-ONE-SOURCE-OF-TRUTH.md) | Один итоговый источник факта и цен | принято |
| [003](ADR-003-AI-WORKER.md) | AI изолирован от SIGMA | принято |
| [004](ADR-004-UPDATER.md) | Все изменения через установщик | принято |
| [005](ADR-005-HISTORY.md) | История содержит только успешные приходы | принято |
| [006](ADR-006-DIRECT-SIGMA-NETWORK.md) | SIGMA игнорирует системный proxy | принято |

Для нового решения скопировать шаблон из `templates/ADR_TEMPLATE.md`.

- [ADR-007: SAI является экосистемой и центральной оболочкой](ADR-007-SAI-AS-ECOSYSTEM-CORE.md)

- [ADR-008 — OpenAI как слой распознавания накладных](ADR-008-OPENAI-INVOICE-INGEST.md)

- [ADR-009 — SAI Package становится основным форматом](ADR-009-SAI-PACKAGE-FORMAT.md)

- [ADR-010 — финальная сумма строки как источник закупочной цены](ADR-010-FINAL-LINE-TOTAL-AS-PURCHASE-PRICE.md)

- [ADR-011 — Внешний версионируемый AI-контракт](ADR-011-EXTERNAL-VERSIONED-AI-CONTRACT.md)

- [ADR-012: единый защищённый маршрутизатор прихода](ADR-012-GUARDED-RECEIPT-ROUTING.md)
- [ADR-013: экономичная и проверяемая обработка накладных](ADR-013-ECONOMICAL-AI-INVOICE-PROCESSING.md)
- [ADR-015 — компактный аудит накладной](ADR-015-COMPACT-INVOICE-AUDIT.md)
- [ADR-016 — материальная AI-проверка](ADR-016-MATERIAL-ONLY-AI-AUDIT.md)
- [ADR-017 — построчная проверка по увеличенным фрагментам](ADR-017-ROW-TILE-AI-AUDIT.md)
- [ADR-018 — фиксированный поворот боковых PDF](ADR-018-FIXED-CCW-PDF-ORIENTATION.md) — заменён ADR-019
- [ADR-019 — подтверждаемая ориентация страниц до AI-запроса](ADR-019-OPERATOR-CONFIRMED-PAGE-ORIENTATION.md)

- ADR-020 — нечитаемый штрихкод оставляется пустым и маршрутизируется в полуавтоматический режим.
- [ADR-021 — адаптивный SAI Invoice Agent](ADR-021-ADAPTIVE-INVOICE-AGENT.md)

- [ADR-022 — постраничное чтение Luna с локальным повышением модели](ADR-022-PAGE-BY-PAGE-LUNA-EXTRACTION.md)

- [ADR-023](ADR-023-DUAL-LUNA-CONSENSUS-AND-CROPPED-ESCALATION.md) — двойное независимое чтение Luna, локальный консенсус и усиление только по увеличенным фрагментам спорных строк.
- [ADR-024](ADR-024-SHADOW-ADAPTIVE-SECOND-LUNA.md) — теневой риск-анализ второго Luna-чтения и локальная телеметрия стоимости до включения реальной экономии.

- [ADR-025](ADR-025-INVOICE-AI-PIPELINE-BOUNDARIES.md) — AI-конвейер разделён на оркестрацию, состояние и телеметрию без изменения платного маршрута.

- [ADR-026](ADR-026-INVOICE-AI-CONTRACT-AND-SOURCE-BOUNDARIES.md) — AI-контракт и подготовка источников вынесены из основного модуля без изменения платного маршрута.

- [ADR-027](ADR-027-INVOICE-AI-CLIENT-RECONCILIATION-BOUNDARIES.md) — модели, HTTP-транспорт и детерминированное согласование вынесены из фасада; AI-рефакторинг завершён.

- [ADR-028 — неразрушительное применение построчного AI-аудита](ADR-028-NON-DESTRUCTIVE-ROW-AUDIT-MERGE.md)

- [ADR-029 — локальная нормализация названий товаров](ADR-029-LOCAL-PRODUCT-NAME-NORMALIZATION.md)

- [ADR-030 — SAI Ready и локальное зеркало каталога](ADR-030-SAI-READY-LOCAL-CATALOG-MIRROR.md)
- [ADR-031 — единая система уведомлений и модальных сообщений](ADR-031-UNIFIED-NOTIFICATION-SYSTEM.md)

- [ADR-032 — стабильная геометрия навигационной панели и визуальная глубина уведомлений](ADR-032-STABLE-RAIL-AND-TOAST-ELEVATION.md)
- [ADR-033 — инвариантная геометрия левой панели](ADR-033-INVARIANT-RAIL-GEOMETRY.md)
- [ADR-034 — AI-first новый привоз и внутренние черновики](ADR-034-AI-FIRST-RECEIPT-AND-INTERNAL-DRAFTS.md)

- [ADR-035 — единый контроллер и четыре режима темы](ADR-035-UNIFIED-THEME-MODES.md) — заменён ADR-036
- [ADR-036 — фиксированная тема и счётчик активных черновиков](ADR-036-FIXED-THEME-AND-DRAFT-BADGE.md)

- [ADR-037 — безрамочное окно и необратимое удаление черновика](ADR-037-FRAMELESS-SHELL-AND-DURABLE-DRAFT-DELETION.md)
- [ADR-038 — необязательное интро запуска по времени суток](ADR-038-TIME-AWARE-OPTIONAL-STARTUP-INTRO.md)
- [ADR-039 — Премиальная hero-кнопка, развёрнутый запуск и интегрированная панель](ADR-039-PREMIUM-HERO-MAXIMIZED-SHELL-AND-INTEGRATED-RAIL.md)
- [ADR-040 — Нормализованный UI-слой и сворачиваемые настройки](ADR-040-NORMALIZED-UI-LAYER-AND-COLLAPSIBLE-SETTINGS.md)
- [ADR-041 — Кинематографичное интро и векторная сборка логотипа](ADR-041-CINEMATIC-INTRO-AND-VECTOR-LOGO-ASSEMBLY.md)
- [ADR-042 — Статичное интро с оригинальным логотипом](ADR-042-STATIC-INTRO-WITH-ORIGINAL-LOGO.md)
- [ADR-042 — Основание SAI Core v2](ADR-042-SAI-CORE-V2-FOUNDATION.md)
- [ADR-043 — Граница модуля «Новый привоз»](ADR-043-RECEIPT-HUB-BOUNDARY.md)
- [ADR-044 — Бесшовная передача управления от интро](ADR-044-SEAMLESS-STARTUP-HANDOFF.md)
- [ADR-045 — Ядро ручной накладной вне Qt](ADR-045-MANUAL-RECEIPT-CORE.md)
- [ADR-046 — Ядро полуавтоматического привоза вне Qt](ADR-046-SEMI-AUTO-RECEIPT-CORE.md)
- [ADR-047: обязательный теневой приёмочный контур патчей](ADR-047-PATCH-ACCEPTANCE-GATE.md)
- [ADR-048: граница каталога и штрихкодов свободного привоза](ADR-048-FREE-RECEIPT-CATALOG-BOUNDARY.md)
- [ADR-049: общие штрихкоды и данные ценников](ADR-049-BARCODE-AND-PRICE-TAG-DATA-BOUNDARY.md)
- [ADR-050: граница генерации PDF-ценников](ADR-050-PRICE-TAG-PDF-BOUNDARY.md)
- [ADR-051: граница термопечати](ADR-051-THERMAL-PRINTING-BOUNDARY.md)
- [ADR-052: постоянная личность товара и складской журнал](ADR-052-STABLE-PRODUCT-IDENTITY-AND-STOCK-LEDGER.md)
- [ADR-053: локальный владелец и отдельные права на модули](ADR-053-LOCAL-OWNER-AND-MODULE-ENTITLEMENTS.md)
- [ADR-054: отдельная административная консоль](ADR-054-STANDALONE-ADMIN-CONSOLE.md)
- [ADR-055: приёмка и склад являются базовыми модулями](ADR-055-RECEIPT-AND-STOCK-AS-CORE-MODULES.md)
- [ADR-056: рабочее место склада строится поверх неизменяемого журнала](ADR-056-WAREHOUSE-WORKBENCH.md)
- [ADR-057: API-ключом владельца управляет только SAI Admin](ADR-057-ADMIN-OWNED-OPENAI-CREDENTIAL.md)
- [ADR-058: безопасное редактирование карточки товара SIGMA](ADR-058-SAFE-SIGMA-PRODUCT-EDITOR.md)
- [ADR-059: ручной вход в SIGMA без передачи учётных данных SAI](ADR-059-MANUAL-SIGMA-LOGIN.md)
- [ADR-060: решение оператора при сомнительном итоге накладной](ADR-060-OPERATOR-INVOICE-TOTAL-OVERRIDE.md)
- [ADR-061: единое округление продажной цены](ADR-061-UNIFIED-RETAIL-PRICE-ROUNDING.md)
- [ADR-062: нодовая архитектура процессов SAI](ADR-062-NODE-PROCESS-ARCHITECTURE.md)
