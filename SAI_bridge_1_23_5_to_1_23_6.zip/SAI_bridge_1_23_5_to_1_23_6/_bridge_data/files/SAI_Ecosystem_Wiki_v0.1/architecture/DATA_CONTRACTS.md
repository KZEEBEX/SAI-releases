# Контракты данных

## Каноническая позиция

```json
{
  "line_id": "stable-local-id",
  "source_line": 1,
  "name_original": "",
  "name_normalized": "",
  "supplier_code": "",
  "barcodes": [],
  "quantity_document": 0,
  "quantity_fact": 0,
  "unit": "шт",
  "purchase_price": 0,
  "selling_price_incoming": 0,
  "selling_price_sigma": null,
  "selling_price_approved": 0,
  "sigma_product_id": null,
  "sigma_item_id": null,
  "status": "accepted",
  "notes": []
}
```

## Статусы позиции

- `accepted` — принята полностью;
- `partial` — принят недовоз;
- `rejected` — не принимать;
- `return` — возврат;
- `missing_barcode` — нужен ШК;
- `catalog_missing` — нет карточки;
- `barcode_conflict` — неоднозначный ШК.

## Канонический приход

```json
{
  "receipt_id": "local-id",
  "supplier_sigma_id": "",
  "supplier_name": "",
  "invoice_number": "",
  "invoice_date": "YYYY-MM-DD",
  "sigma_waybill_id": "",
  "state": "prices_approved",
  "items": [],
  "totals": {
    "positions": 0,
    "quantity": 0,
    "purchase": 0,
    "selling": 0
  },
  "attachments": []
}
```

## Состояния прихода

```text
created
→ parsed
→ catalog_checked
→ fact_approved
→ prices_approved (optional explicit screen)
→ dry_run_passed
→ applied_to_sigma
→ documents_generated
→ archived
```

Ошибку нужно хранить отдельно от основного состояния: `last_error`, `failed_step`, `retryable`.

## Денежные значения

Во внутренних контрактах предпочтителен `Decimal` или целое число копеек. Float не должен быть источником итоговых сумм.

### Расчёт продажной цены

Все модули используют `sai_core_v2.pricing.sale_price_from_purchase`.
Порог выбирается по рассчитанной итоговой цене: ниже `25 ₽` копейки
округляются вверх до рубля; от `25 ₽` цена округляется до ближайшего шага
`5 ₽`, поэтому заканчивается на `0` или `5`. Точная середина шага
округляется вверх.

## Совместимость форматов

- `.sai` / SAI Package — основной пользовательский и переносимый формат;
- `data/receipt.json` внутри пакета — текущий канонический контракт прихода;
- SAI XML/XLSX — legacy-адаптеры канонической модели;
- бизнес-логика не должна зависеть от номера колонки, XML-тега или внутреннего пути ZIP напрямую;
- доступ к контейнеру выполняется через официальный слой `sai_package.py`.

Подробная спецификация: [SAI Package Format](SAI_PACKAGE_FORMAT.md).


## Аудит AI-цены

Для AI-приходов позиция дополнительно хранит:

```json
{
  "line_total": 1160.00,
  "purchase_price_source": "сумма строки / количество",
  "confidence": 0.96
}
```

Приход хранит `validation` с итогом документа, суммой распознанных товарных строк, допустимой погрешностью и количеством позиций по каждому источнику цены. Критические расхождения хранятся в `critical_issues`.

Инвариант: при наличии `line_total > 0` и `quantity > 0` поле `purchase_price` вычисляется как `line_total / quantity`; напечатанная цена не может его переопределить.

## Происхождение названия товара

В SAI Package позиция сохраняет исходное и рабочее название отдельно:

```json
{
  "raw_name": "дословная строка поставщика",
  "name": "КАТАЛОЖНОЕ НАЗВАНИЕ",
  "name_source": "normalized",
  "name_normalization_changes": [],
  "name_search_aliases": [],
  "name_normalizer_version": 1
}
```

`name_source=manual` означает явную правку оператора. Такая правка не должна быть перезаписана автоматической нормализацией. Дополнительные ключи остаются обратно совместимыми со схемой `sai.receipt/1.0`.
