# Архитектура экосистемы

## Слои

### Представление

PySide6-интерфейс, мобильная web-панель, окна диагностики. UI не должен самостоятельно обращаться к SQLite или конструировать REST-запросы.

### Прикладные сценарии

`CreateReceipt`, `CheckCatalog`, `ApprovePrices`, `ApplyWaybill`, `PrintDocuments`, `ArchiveReceipt`.

### Доменные сервисы

Товар, позиция накладной, факт приёмки, политика цены, сопоставление ШК, успешный приход.

### Адаптеры

SIGMA API, Playwright, SQLite, XLSX/XML/PDF, Windows printing, AI provider.

## Целевой поток событий

```text
InvoiceParsed
  → ItemsMatched
  → ReceiptFactApproved
  → PricesApproved
  → SigmaDryRunPassed
  → SigmaWaybillApplied
  → DocumentsGenerated
  → ReceiptArchived
```

События не обязаны внедряться как сложная event-система сразу. Они задают правильные границы и журналирование.

## Отказоустойчивость

- Неуспех AI: перейти к ручному вводу/локальному парсеру.
- Неуспех SIGMA: сохранить локальное состояние, не помечать приход успешным.
- Неуспех печати: приход остаётся успешным, файлы доступны для повторной печати.
- Неуспех архива: сообщить отдельно, не скрывать успешность SIGMA.
- Повторный запуск: операция должна уметь продолжиться без повторного создания товаров или двойного прихода.

## Граница секретов

```text
SAI Core ── имеет доступ к SIGMA secrets
AI Worker ─ не имеет доступа к SIGMA secrets
Archive   ─ не хранит открытые токены
Updater   ─ не включает user_data в payload
```
