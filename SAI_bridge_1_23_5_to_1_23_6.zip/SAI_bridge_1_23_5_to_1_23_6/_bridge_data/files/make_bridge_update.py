#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Build a rollback-capable full-code update package for SAI."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
sys.path.insert(0, str(APP))
from sai_version import APP_VERSION, BUILD_ID, VERSION  # noqa: E402

EXCLUDED_DIRS = {
    ".git", ".venv", "__pycache__", ".pytest_cache", "user_data", "tmp",
    "_deployment_staging", "_demo_build", "_demo_release", "Sai logo history",
    "Profile", "cache", "logs", "backups", "_backups", "_patch_backups",
    "_offline", "_runtime",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".7z"}
EXCLUDED_NAMES = {
    "sai.db", "sai_config.json", "sai_private_config.json", "Cookies",
    "Login Data", "Local State", "SAI_BRIDGE_LAST_LOG.txt",
}


def excluded(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return True
    if path.name in EXCLUDED_NAMES or path.suffix.casefold() in EXCLUDED_SUFFIXES:
        return True
    return path.name.startswith(("acceptance_report", "sai_crash_", "sai_doctor_"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tracked_sources() -> list[Path]:
    raw = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT)
    return [ROOT / value.decode("utf-8") for value in raw.split(b"\0") if value]


def write_cmd(path: Path) -> None:
    # The old 1.23.1 bootstrap launches this file directly.  The Python
    # installer discovers the actual root, installs, and starts SAI again.
    lines = [
        "@echo off", "setlocal", 'cd /d "%~dp0"', "title SAI Update",
        'set "PYTHONUTF8=1"', 'set "PYTHONDONTWRITEBYTECODE=1"', 'set "PY=python"',
        'for %%D in ("%~dp0..\\..\\..\\..\\..") do set "TARGET=%%~fD"',
        'if exist "%TARGET%\\app\\.venv\\Scripts\\python.exe" set "PY=%TARGET%\\app\\.venv\\Scripts\\python.exe"',
        'if exist "%TARGET%\\_runtime\\python\\python.exe" set "PY=%TARGET%\\_runtime\\python\\python.exe"',
        'if exist "%TARGET%\\_offline\\python\\python.exe" set "PY=%TARGET%\\_offline\\python\\python.exe"',
        "timeout /t 3 /nobreak >nul",
        '"%PY%" "%~dp0install_bridge.py" --restart',
        'set "EXIT_CODE=%ERRORLEVEL%"',
        'if "%EXIT_CODE%"=="0" exit /b 0',
        "echo UPDATE FAILED. The previous SAI version was restored.",
        'if exist "%~dp0SAI_BRIDGE_LAST_LOG.txt" start "" notepad.exe "%~dp0SAI_BRIDGE_LAST_LOG.txt"',
        "pause", "exit /b %EXIT_CODE%",
    ]
    path.write_bytes(("\r\n".join(lines) + "\r\n").encode("ascii"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "_deployment_staging" / "bridge")
    parser.add_argument("--supported-version", action="append", default=[])
    args = parser.parse_args()
    output = args.output_dir.resolve()
    supported_versions = sorted(set(args.supported_version or ["1.23.1"]))
    source_slug = "_and_".join(value.replace(".", "_") for value in supported_versions)
    version_slug = APP_VERSION.removeprefix("v").replace(".", "_")
    package_name = f"SAI_bridge_{source_slug}_to_{version_slug}"
    package = output / package_name
    payload = package / "_bridge_data" / "files"
    if output.exists():
        shutil.rmtree(output)
    payload.mkdir(parents=True)

    files = []
    for source in sorted(tracked_sources()):
        if excluded(source) or not source.is_file():
            continue
        relative = source.relative_to(ROOT)
        destination = payload / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        files.append({"path": relative.as_posix(), "size": destination.stat().st_size, "sha256": sha256(destination)})

    shutil.copy2(APP / "sai_bridge_installer.py", package / "install_bridge.py")
    write_cmd(package / "INSTALL_SAI_BRIDGE.cmd")
    manifest = {
        "schema_version": 1,
        "supported_versions": supported_versions,
        "target_version": VERSION,
        "target_app_version": APP_VERSION,
        "build_id": BUILD_ID,
        "update_repository": "KZEEBEX/SAI-releases",
        "files": files,
    }
    (package / "_bridge_data" / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8",
    )
    (package / "README.txt").write_text(
        "SAI UPDATE\n\nClose SAI and run INSTALL_SAI_BRIDGE.cmd.\n"
        "The updater preserves user_data and app/.venv and creates a rollback backup.\n",
        encoding="utf-8",
    )
    archive_path = output / f"{package_name}.zip"
    with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(package.rglob("*")):
            if path.is_file():
                archive.write(path, (Path(package.name) / path.relative_to(package)).as_posix())
    print(package)
    print(archive_path)
    print(f"Files: {len(files)}")
    print(f"Size: {archive_path.stat().st_size / 1024 / 1024:.1f} MB")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
