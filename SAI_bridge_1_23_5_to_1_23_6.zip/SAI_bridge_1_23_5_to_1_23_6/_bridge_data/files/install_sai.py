#!/usr/bin/env python
"""Install SAI on Windows using bundled Python and automatic downloads."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
RUNTIME = ROOT / "_runtime"
RUNTIME_PYTHON = RUNTIME / "python" / "python.exe"
BROWSERS = RUNTIME / "ms-playwright"
VENV = APP / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"
LOG_PATH = ROOT / "SAI_SETUP_LAST_LOG.txt"
MANIFEST_PATH = RUNTIME / "RELEASE_MANIFEST.json"
REQUIREMENTS = ROOT / "requirements-online.txt"


class InstallError(RuntimeError):
    pass


def log(message: object = "") -> None:
    text = str(message)
    print(text, flush=True)
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def run(
    command: list[str],
    *,
    cwd: Path = ROOT,
    env: dict[str, str] | None = None,
) -> None:
    safe = [str(part) for part in command]
    log("  > " + " ".join(f'"{part}"' if " " in part else part for part in safe))
    process = subprocess.Popen(
        safe,
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert process.stdout is not None
    for line in process.stdout:
        log("    " + line.rstrip())
    code = process.wait()
    if code:
        raise InstallError(f"Command failed with exit code {code}: {safe[0]}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_bundle() -> dict:
    if platform.system() != "Windows" or platform.machine().lower() not in {"amd64", "x86_64"}:
        raise InstallError("This setup requires 64-bit Windows.")
    for path in (RUNTIME_PYTHON, REQUIREMENTS, MANIFEST_PATH):
        if not path.is_file():
            raise InstallError(f"Required file is missing: {path.relative_to(ROOT)}")
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    checked = 0
    for item in manifest.get("files", []):
        relative = str(item.get("path") or "")
        path = ROOT / Path(relative)
        if not path.is_file():
            raise InstallError(f"Archive is incomplete: {relative}")
        if (
            int(item.get("size", -1)) != path.stat().st_size
            or str(item.get("sha256")) != sha256(path)
        ):
            raise InstallError(f"Archive integrity check failed: {relative}")
        checked += 1
    if checked < 1:
        raise InstallError("Release manifest is empty.")
    log(f"  Archive integrity: OK ({checked} files)")
    return manifest


def prepare_user_data() -> None:
    user_data = ROOT / "user_data"
    (user_data / "backups").mkdir(parents=True, exist_ok=True)
    (user_data / "logs").mkdir(parents=True, exist_ok=True)
    for source, target in (
        (APP / "sai_private_config.example.json", user_data / "sai_private_config.json"),
        (APP / "sai_config.example.json", user_data / "sai_config.json"),
    ):
        if not target.exists() and source.is_file():
            shutil.copy2(source, target)


def install_environment(env: dict[str, str]) -> Path | None:
    backup: Path | None = None
    if VENV.exists():
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = APP / f".venv_before_setup_{stamp}"
        VENV.replace(backup)
        log(f"  Existing environment saved as {backup.name}")
    try:
        run([str(RUNTIME_PYTHON), "-m", "venv", str(VENV)], env=env)
        if not VENV_PYTHON.is_file():
            raise InstallError("Python did not create app\\.venv.")
        run([
            str(VENV_PYTHON), "-m", "pip", "install",
            "--disable-pip-version-check", "--retries", "5", "--timeout", "60",
            "-r", str(REQUIREMENTS),
        ], env=env)
        BROWSERS.mkdir(parents=True, exist_ok=True)
        last_error: Exception | None = None
        for attempt in range(1, 4):
            try:
                log(f"  Chromium download attempt {attempt}/3")
                run([str(VENV_PYTHON), "-m", "playwright", "install", "chromium"], env=env)
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                log(f"  Download attempt {attempt} failed.")
        if last_error is not None:
            raise last_error
        return backup
    except Exception:
        shutil.rmtree(VENV, ignore_errors=True)
        if backup and backup.exists():
            backup.replace(VENV)
        raise


def install_ready_autostart(env: dict[str, str]) -> None:
    code = (
        "from pathlib import Path; "
        "from sai_ready_autostart import install_autostart; "
        f"p=install_autostart(Path({str(ROOT)!r})); "
        "print('SAI Ready:', p or 'not available')"
    )
    run([str(VENV_PYTHON), "-c", code], cwd=APP, env=env)


def write_installed_build(manifest: dict) -> None:
    payload = {
        "version": str(manifest.get("version") or ""),
        "build_id": str(manifest.get("build_id") or ""),
        "installation": "easy-online-windows-x64",
        "installed_at": dt.datetime.now().astimezone().isoformat(),
        "python": "3.12.10 x64 bundled",
        "acceptance": "PATCH ACCEPTED",
    }
    target = ROOT / "user_data" / "installed_build.json"
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    LOG_PATH.write_text(
        "SAI setup log\n"
        + dt.datetime.now().astimezone().isoformat()
        + "\n"
        + "=" * 78
        + "\n",
        encoding="utf-8",
    )
    backup: Path | None = None
    try:
        log("[1/7] Checking release files...")
        manifest = validate_bundle()
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["QT_QPA_PLATFORM"] = "offscreen"
        env["PLAYWRIGHT_BROWSERS_PATH"] = str(BROWSERS)
        log("[2/7] Creating the SAI Python environment...")
        backup = install_environment(env)
        prepare_user_data()
        log("[3/7] Checking Python and application libraries...")
        run([
            str(VENV_PYTHON), "-c",
            "import PySide6,openpyxl,requests; print('Python libraries: OK')",
        ], cwd=APP, env=env)
        log("[4/7] Checking the downloaded Chromium...")
        run([
            str(VENV_PYTHON), "-c",
            "from playwright.sync_api import sync_playwright; "
            "p=sync_playwright().start(); b=p.chromium.launch(headless=True); "
            "print('Chromium: OK'); b.close(); p.stop()",
        ], cwd=APP, env=env)
        log("[5/7] Running the mandatory SAI acceptance suite...")
        with tempfile.TemporaryDirectory(prefix="sai_setup_acceptance_") as temp:
            test_env = env.copy()
            test_env["SAI_USER_DATA_DIR"] = str(Path(temp) / "user_data")
            run([
                str(VENV_PYTHON), str(APP / "run_patch_acceptance.py"),
                "--root", str(ROOT), "--python", str(VENV_PYTHON),
            ], cwd=APP, env=test_env)
        log("[6/7] Enabling catalog preparation at Windows sign-in...")
        if os.environ.get("SAI_SETUP_VERIFY_ONLY") == "1":
            log("  Verification mode: Windows Startup was not changed.")
        else:
            install_ready_autostart(env)
        log("[7/7] Recording the installed build...")
        write_installed_build(manifest)
        if backup and backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        log("")
        log("SUCCESS: SAI is installed and passed the acceptance suite.")
        log("Launch it with START_SAI.cmd.")
        return 0
    except Exception as exc:
        if backup and backup.exists():
            shutil.rmtree(VENV, ignore_errors=True)
            backup.replace(VENV)
            log("The previous Python environment was restored.")
        elif VENV.exists():
            shutil.rmtree(VENV, ignore_errors=True)
        log("")
        log("ERROR: " + str(exc))
        log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
