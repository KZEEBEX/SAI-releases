@echo off
setlocal
cd /d "%~dp0"
title SAI Setup
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONUTF8=1"

echo ==============================================================================
echo SAI SETUP
echo ==============================================================================
echo.
echo Python is included. Required libraries will be downloaded automatically.
echo Keep this window open until the setup is complete.
echo.

if not exist "_runtime\python\python.exe" goto missing
if not exist "install_sai.py" goto missing

"_runtime\python\python.exe" "install_sai.py"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" goto success

echo ==============================================================================
echo ERROR: SAI WAS NOT INSTALLED.
echo Send the file SAI_SETUP_LAST_LOG.txt to the developer.
echo ==============================================================================
if exist "SAI_SETUP_LAST_LOG.txt" start "" notepad.exe "SAI_SETUP_LAST_LOG.txt"
echo.
pause
exit /b %EXIT_CODE%

:success
echo ==============================================================================
echo SUCCESS: SAI IS INSTALLED AND VERIFIED.
echo Use START_SAI.cmd to launch the application.
echo ==============================================================================
echo.
pause
exit /b 0

:missing
echo ERROR: The ZIP archive was not extracted completely.
echo Extract the entire SAI folder and run INSTALL_SAI.cmd again.
echo.
pause
exit /b 2
