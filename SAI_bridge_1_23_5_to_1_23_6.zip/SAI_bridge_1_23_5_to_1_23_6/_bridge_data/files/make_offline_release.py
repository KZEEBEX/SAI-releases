#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Build a clean, self-contained SAI installer for a new Windows x64 PC."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
sys.path.insert(0, str(APP))
from sai_version import APP_VERSION, BUILD_ID, VERSION  # noqa: E402

STAGING_PARENT = ROOT / "_deployment_staging" / "full_offline_release"
STAGING_ROOT = STAGING_PARENT / "SAI"
ZIP_PATH = ROOT.parent / f"SAI_{VERSION}_FULL_OFFLINE_WINDOWS_X64.zip"
WHEEL_SOURCE = ROOT / "_deployment_staging" / "wheelhouse-test"
BASE_PYTHON = Path(sys.base_prefix)
LOCAL_APP_DATA = Path(os.environ.get("LOCALAPPDATA") or "")
BROWSER_SOURCE = LOCAL_APP_DATA / "ms-playwright"

EXCLUDED_DIRS = {
    ".git", ".venv", "__pycache__", ".pytest_cache", "user_data",
    "_deployment_staging", "Sai logo history", "Profile", "cache", "logs",
    "backups", "_backups", "_patch_backups", "_offline", "_runtime",
    "_demo_build", "_demo_release", "demo",
}
EXCLUDED_FILES = {
    ".gitignore", "make_release.py", "make_release.cmd",
    "make_offline_release.py", "make_offline_release.cmd",
    "make_online_release.py", "make_online_release.cmd",
    "INSTALL_SAI.cmd", "install_sai.py", "requirements-online.txt",
    "README_INSTALL.txt",
    "_demo_preview.png",
    "SAI_RECEIPT_READINESS_LAST_LOG.txt", "SAI_INSTALL_LAST_LOG.txt",
    "SAI_SETUP_LAST_LOG.txt",
    "SAI_PATCH_LAST_LOG.txt", "app/install.cmd",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".7z"}
LOCKED_REQUIREMENTS = """\
certifi==2026.7.22
charset-normalizer==3.4.9
et-xmlfile==2.0.0
greenlet==3.0.3
idna==3.18
openpyxl==3.1.5
playwright==1.46.0
pyee==11.1.0
PySide6==6.11.1
PySide6_Addons==6.11.1
PySide6_Essentials==6.11.1
requests==2.32.3
shiboken6==6.11.1
typing_extensions==4.16.0
urllib3==2.7.0
"""


def excluded(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return True
    if relative.as_posix() in EXCLUDED_FILES or path.name in EXCLUDED_FILES:
        return True
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if path.name.startswith(("acceptance_report", "sai_crash_", "sai_doctor_")):
        return True
    return False


def copy_clean_source() -> None:
    if STAGING_PARENT.exists():
        shutil.rmtree(STAGING_PARENT)
    STAGING_ROOT.mkdir(parents=True)
    for source in ROOT.rglob("*"):
        if excluded(source):
            continue
        relative = source.relative_to(ROOT)
        target = STAGING_ROOT / relative
        if source.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif source.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    # The release exposes one unambiguous installer. Keep the implementation
    # file separate, but give the user-facing launcher the standard ASCII name.
    offline_launcher = STAGING_ROOT / "INSTALL_SAI_OFFLINE.cmd"
    standard_launcher = STAGING_ROOT / "INSTALL_SAI.cmd"
    if not offline_launcher.is_file():
        raise RuntimeError("Не найден INSTALL_SAI_OFFLINE.cmd")
    offline_launcher.replace(standard_launcher)


def validate_sources() -> None:
    if not (BASE_PYTHON / "python.exe").is_file():
        raise RuntimeError(f"Не найден переносимый Python: {BASE_PYTHON}")
    expected_wheels = {
        "playwright", "openpyxl", "requests", "pyside6", "pyside6_addons",
        "pyside6_essentials", "shiboken6", "greenlet",
    }
    actual = {path.name.lower().split("-")[0] for path in WHEEL_SOURCE.glob("*.whl")}
    missing = sorted(expected_wheels - actual)
    if missing:
        raise RuntimeError("Не хватает офлайн wheels: " + ", ".join(missing))
    for folder in ("chromium-1129", "ffmpeg-1009"):
        if not (BROWSER_SOURCE / folder / "INSTALLATION_COMPLETE").is_file():
            raise RuntimeError(f"Не найден браузер Playwright: {folder}")


def add_offline_payload() -> None:
    offline = STAGING_ROOT / "_offline"
    shutil.copytree(
        BASE_PYTHON,
        offline / "python",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
    )
    shutil.copytree(WHEEL_SOURCE, offline / "wheelhouse")
    browsers = offline / "ms-playwright"
    for folder in ("chromium-1129", "ffmpeg-1009"):
        shutil.copytree(BROWSER_SOURCE / folder, browsers / folder)
    (offline / "requirements-offline.txt").write_text(LOCKED_REQUIREMENTS, encoding="utf-8")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_manifest() -> None:
    offline = STAGING_ROOT / "_offline"
    manifest_path = offline / "RELEASE_MANIFEST.json"
    files = []
    for path in sorted(STAGING_ROOT.rglob("*")):
        if not path.is_file() or path == manifest_path:
            continue
        files.append({
            "path": path.relative_to(STAGING_ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256(path),
        })
    payload = {
        "format": 1,
        "version": APP_VERSION,
        "build_id": BUILD_ID,
        "platform": "Windows x64",
        "python": "3.12.10 x64",
        "playwright": "1.46.0",
        "chromium_revision": "1129",
        "files": files,
    }
    manifest_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def validate_clean_tree() -> None:
    forbidden = []
    for path in STAGING_ROOT.rglob("*"):
        relative = path.relative_to(STAGING_ROOT)
        if any(part in {".git", ".venv", "user_data", "Profile"} for part in relative.parts):
            forbidden.append(relative.as_posix())
        if path.name in {"sai_private_config.json", "sai.db", "Cookies", "Login Data", "Local State"}:
            forbidden.append(relative.as_posix())
    if forbidden:
        raise RuntimeError("В релиз попали приватные/локальные файлы:\n" + "\n".join(forbidden[:30]))
    required = (
        STAGING_ROOT / "INSTALL_SAI.cmd",
        STAGING_ROOT / "START_SAI.cmd",
        STAGING_ROOT / "install_offline.py",
        STAGING_ROOT / "_offline" / "python" / "python.exe",
        STAGING_ROOT / "_offline" / "requirements-offline.txt",
        STAGING_ROOT / "_offline" / "ms-playwright" / "chromium-1129" / "INSTALLATION_COMPLETE",
    )
    for path in required:
        if not path.exists():
            raise RuntimeError(f"В релизе отсутствует: {path.relative_to(STAGING_ROOT)}")
    for name in ("INSTALL_SAI.cmd", "START_SAI.cmd"):
        data = (STAGING_ROOT / name).read_bytes()
        data.decode("ascii")
        if b"\n" in data.replace(b"\r\n", b""):
            raise RuntimeError(f"{name} должен использовать Windows CRLF.")


def run_acceptance() -> None:
    with tempfile.TemporaryDirectory(prefix="sai_offline_release_acceptance_") as temp:
        env = os.environ.copy()
        env["QT_QPA_PLATFORM"] = "offscreen"
        env["SAI_USER_DATA_DIR"] = str(Path(temp) / "user_data")
        subprocess.run([
            sys.executable, str(APP / "run_patch_acceptance.py"),
            "--root", str(ROOT), "--python", sys.executable,
        ], cwd=APP, env=env, check=True)


def zip_release() -> None:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=1) as archive:
        for path in sorted(STAGING_ROOT.rglob("*")):
            if path.is_file():
                archive.write(path, (Path("SAI") / path.relative_to(STAGING_ROOT)).as_posix())
    with zipfile.ZipFile(ZIP_PATH) as archive:
        roots = {name.split("/", 1)[0] for name in archive.namelist() if name}
        if roots != {"SAI"}:
            raise RuntimeError(f"ZIP должен содержать одну папку SAI, найдено: {sorted(roots)}")
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"Повреждённый файл ZIP: {bad}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    print(f"Собираю полный офлайн-релиз SAI {APP_VERSION}...")
    if not args.skip_tests:
        print("Запускаю приёмочный контур...")
        run_acceptance()
    validate_sources()
    print("Копирую чистый код SAI...")
    copy_clean_source()
    print("Добавляю Python, wheels и Chromium...")
    add_offline_payload()
    write_manifest()
    validate_clean_tree()
    print("Создаю ZIP...")
    zip_release()
    print(f"Готово: {ZIP_PATH}")
    print(f"Размер: {ZIP_PATH.stat().st_size / 1024 / 1024:.1f} МБ")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
