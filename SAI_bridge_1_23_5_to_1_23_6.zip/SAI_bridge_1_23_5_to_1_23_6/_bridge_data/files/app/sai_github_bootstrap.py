#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tiny GitHub update bootstrap intended for SAI 1.23.1.

It runs before the normal Hub starts, checks at most once every six hours and
only interrupts startup after the operator accepts an available release.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

import sai_github_updates
from sai_runtime_paths import USER_DATA_DIR


STATE_PATH = USER_DATA_DIR / "github_update_bootstrap.json"
EXTRACT_ROOT = USER_DATA_DIR / "updates" / "ready"
# This module exists on legacy 1.23.1 only until the first full update.
# Checking every launch prevents an early negative result from hiding a newly
# published bridge release for hours.
CHECK_INTERVAL_SECONDS = 0


def _read_state() -> dict[str, Any]:
    try:
        value = json.loads(STATE_PATH.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_state(**values: Any) -> None:
    state = _read_state()
    state.update(values)
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, STATE_PATH)


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _check_due(force: bool) -> bool:
    if force:
        return True
    raw = str(_read_state().get("checked_at") or "")
    try:
        checked = dt.datetime.fromisoformat(raw)
        if checked.tzinfo is None:
            checked = checked.replace(tzinfo=dt.timezone.utc)
        return (_now() - checked).total_seconds() >= CHECK_INTERVAL_SECONDS
    except Exception:
        return True


def _message(title: str, text: str, *, question: bool = False, console: bool = False) -> bool:
    if console:
        print(f"{title}: {text}")
        if not question:
            return True
        try:
            return input("Download and install? [y/N] ").strip().casefold() in {"y", "yes", "д", "да"}
        except EOFError:
            return False
    try:
        import ctypes
        flags = 0x24 if question else 0x40  # MB_YESNO|MB_ICONQUESTION / MB_ICONINFORMATION
        result = ctypes.windll.user32.MessageBoxW(None, text, title, flags)
        return result == 6 if question else True
    except Exception:
        return False


def _safe_extract(archive: Path, destination: Path) -> Path:
    temporary = destination.with_name(destination.name + ".extracting")
    shutil.rmtree(temporary, ignore_errors=True)
    temporary.mkdir(parents=True)
    with zipfile.ZipFile(archive) as source:
        members = source.infolist()
        if not members or len(members) > 5000:
            raise RuntimeError("Архив обновления пуст или содержит слишком много файлов.")
        total = 0
        for member in members:
            relative = Path(member.filename.replace("\\", "/"))
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError("Архив обновления содержит небезопасный путь.")
            total += max(0, int(member.file_size))
            if total > sai_github_updates.MAX_PACKAGE_BYTES:
                raise RuntimeError("Распакованный пакет обновления слишком велик.")
        source.extractall(temporary)
    shutil.rmtree(destination, ignore_errors=True)
    os.replace(temporary, destination)
    return destination


def launch_downloaded_update(
    package: Path,
    version: str,
    target_root: Path | None = None,
    *,
    restart: bool = False,
) -> bool:
    """Launch a verified downloaded package without blocking the SAI UI."""
    suffix = package.suffix.casefold()
    if suffix == ".zip":
        extracted = _safe_extract(package, EXTRACT_ROOT / version.replace(".", "_"))
        python_installers = list(extracted.rglob("install_bridge.py"))
        if len(python_installers) == 1:
            command = [sys.executable, str(python_installers[0])]
            if target_root is not None:
                command.extend(["--target", str(Path(target_root).resolve())])
            command.extend(["--wait-seconds", "2"])
            if restart:
                command.append("--restart")
            kwargs: dict[str, Any] = {"cwd": str(python_installers[0].parent), "close_fds": True}
            if os.name == "nt":
                kwargs["creationflags"] = (
                    getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                    | getattr(subprocess, "CREATE_NO_WINDOW", 0)
                )
            subprocess.Popen(command, **kwargs)
            return True
        installers = list(extracted.rglob("INSTALL_SAI_BRIDGE.cmd"))
        if not installers:
            installers = list(extracted.rglob("INSTALL_SAI.cmd"))
        if len(installers) != 1:
            raise RuntimeError("В пакете не найден единственный установщик SAI.")
        os.startfile(str(installers[0]))  # type: ignore[attr-defined]
        return True
    if suffix in {".cmd", ".bat", ".exe", ".msi"}:
        os.startfile(str(package))  # type: ignore[attr-defined]
        return True
    raise RuntimeError("Формат обновления не поддерживается.")


def _launch_package(package: Path, version: str) -> bool:
    return launch_downloaded_update(package, version, restart=True)


def maybe_install_available_update(current_version: str, *, console: bool = False, force: bool = False) -> bool:
    """Return True only when an installer was launched and Hub must stay closed."""
    if not _check_due(force):
        return False
    checked_at = _now().isoformat()
    try:
        update = sai_github_updates.check_for_update(current_version, channel="production")
        _write_state(checked_at=checked_at, error="")
    except Exception as exc:
        _write_state(checked_at=checked_at, error=str(exc)[:500])
        return False
    if update is None:
        return False
    accepted = _message(
        "Обновление SAI",
        f"Доступна новая production-версия SAI v{update.version}.\n\n"
        "Скачать проверенный пакет с GitHub и начать обновление?",
        question=True,
        console=console,
    )
    if not accepted:
        _write_state(declined_version=update.version)
        return False
    try:
        package = sai_github_updates.download_update(update)
        launched = _launch_package(package, update.version)
        if launched:
            _write_state(launched_version=update.version, launched_at=_now().isoformat())
        return launched
    except Exception as exc:
        _write_state(error=str(exc)[:500])
        _message("Обновление SAI", f"Не удалось подготовить обновление:\n{exc}", console=console)
        return False
