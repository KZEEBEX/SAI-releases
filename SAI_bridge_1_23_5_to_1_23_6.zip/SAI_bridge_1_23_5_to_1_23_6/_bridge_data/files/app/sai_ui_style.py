#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Final normalized UI layer for SAI.

The historic stylesheet is intentionally kept for compatibility.  This module is
loaded last and owns the shared visual tokens that must remain consistent across
pages, themes and future modules.  New generic surfaces and controls should be
added here instead of appending unrelated one-off colour rules to the main UI.
"""
from __future__ import annotations
from sai_design_tokens import palette, component_stylesheet


def ui_polish_stylesheet(dark: bool) -> str:
    colors = palette(dark)
    return _legacy_normalized_stylesheet(dark, colors) + component_stylesheet(dark)


def _legacy_normalized_stylesheet(dark: bool, colors: dict[str, str]) -> str:
    canvas, surface, surface_hover, field, border, border_soft, text, muted, subdued, hover, selected, selected_border, scrollbar, scrollbar_hover, scrollbar_pressed, focus = (
        colors[key] for key in (
            "canvas", "surface", "surface_hover", "field", "border", "border_soft", "text", "muted", "subdued",
            "hover", "selected", "selected_border", "scrollbar", "scrollbar_hover", "scrollbar_pressed", "focus",
        )
    )
    return f"""
/* SAI normalized UI layer ---------------------------------------------------- */
QWidget#FramelessWindowShell,
QFrame#FramelessTitleBar,
QFrame#MainArea,
QStackedWidget#ContentStack,
QWidget#StatsPage,
QWidget#UxPage,
QScrollArea,
QScrollArea QWidget#qt_scrollarea_viewport,
QScrollArea#WorkbenchScroll,
QWidget#WorkbenchBody {{
    background: {canvas};
}}
QFrame#FramelessTitleBar {{
    border: none;
    border-bottom: 1px solid {border_soft};
}}
QLabel#FramelessTitleBrand {{
    color: {subdued};
    background: transparent;
}}

/* The rail is a navigation lane, not a differently coloured slab. */
QFrame#Rail {{
    background: {canvas};
    border: none;
    border-right: 1px solid {border_soft};
}}
QFrame#RailTopBlock,
QFrame#RailBottomBlock {{
    background: transparent;
    border: none;
}}
QLabel#RailVersion {{
    background: transparent;
    color: {subdued};
}}
QPushButton#StableRailButton,
QPushButton#StableRailButtonPrimary {{
    background: transparent;
    border: 1px solid transparent;
    border-radius: 13px;
    padding: 0;
}}
QPushButton#StableRailButton:hover {{
    background: {hover};
    border-color: {border};
}}
QPushButton#StableRailButton:checked {{
    background: {selected};
    border-color: {selected_border};
}}
QPushButton#StableRailButtonPrimary {{
    background: #2563eb;
    border-color: #3b82f6;
}}
QPushButton#StableRailButtonPrimary:hover {{
    background: #1d4ed8;
    border-color: #60a5fa;
}}
QPushButton#StableRailButtonPrimary:checked {{
    background: #1e40af;
    border-color: #60a5fa;
}}
QFrame#CatalogStatusBadge {{
    background: {surface};
    border: 1px solid {border};
    border-radius: 13px;
}}
QFrame#CatalogStatusBadge[compactBadge="true"] {{
    background: transparent;
    border-color: transparent;
}}
QLabel#CatalogStatusTitle {{ color: {text}; }}
QLabel#CatalogStatusDetail {{ color: {muted}; }}

/* One surface language for settings and workbench forms. */
QFrame#WorkbenchCard,
QFrame#StatsHeader,
QFrame#UxCard,
QFrame#UxHeaderCard {{
    background: {surface};
    border: 1px solid {border};
}}
QWidget#TransparentPanel,
QWidget#SettingsDisclosureBody {{
    background: transparent;
    border: none;
}}
QLineEdit,
QComboBox,
QTextEdit,
QTimeEdit,
QSpinBox,
QDoubleSpinBox,
QLineEdit#WorkbenchInput,
QComboBox#WorkbenchCombo {{
    background: {field};
    color: {text};
    border: 1px solid {border};
    border-radius: 11px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}}
QLineEdit:focus,
QComboBox:focus,
QTextEdit:focus,
QTimeEdit:focus,
QSpinBox:focus,
QDoubleSpinBox:focus,
QLineEdit#WorkbenchInput:focus,
QComboBox#WorkbenchCombo:focus {{
    border-color: {focus};
}}
QComboBox QAbstractItemView {{
    background: {surface};
    color: {text};
    border: 1px solid {border};
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}}
QLabel#WorkbenchSection,
QLabel#WorkbenchLabel {{ color: {text}; }}
QLabel#WorkbenchNote {{ color: {muted}; }}
QLabel#WarehousePageTitle {{ color: {text}; font-size: 27px; font-weight: 900; }}
QLabel#WarehousePageSubtitle {{ color: {muted}; font-size: 12px; }}
QFrame#MetricCard {{
    background: {surface};
    border: 1px solid {border};
    border-radius: 15px;
}}
QFrame#AnalyticHero {{
    background: {surface};
    border: 1px solid {border};
    border-left: 5px solid #2563eb;
    border-radius: 16px;
}}
QFrame#AnalyticHero[level="warning"] {{ border-left-color: #f59e0b; }}
QFrame#AnalyticHero[level="urgent"],
QFrame#AnalyticHero[level="error"] {{ border-left-color: #ef4444; }}
QFrame#AnalyticHero[level="ready"] {{ border-left-color: #10b981; }}
QLabel#AnalyticBadge {{ color: #2563eb; font-size: 11px; font-weight: 900; }}
QLabel#AnalyticTitle {{ color: {text}; font-size: 18px; font-weight: 900; }}
QLabel#AnalyticWhy {{ color: {muted}; font-size: 13px; }}
QLabel#AnalyticActions {{ color: {text}; font-size: 12px; font-weight: 700; }}
QFrame#CoverageFrame {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 12px; }}
QLabel#CoverageTitle {{ color: {text}; font-size: 12px; font-weight: 900; padding-right: 7px; }}
QLabel#MetricTitle,
QLabel#MetricHint {{ color: {muted}; }}
QLabel#MetricValue {{
    color: {text};
    font-size: 21px;
    font-weight: 800;
}}
QPushButton#WorkbenchPrimaryButton,
QPushButton#SoftButton {{
    min-height: 36px;
    padding: 0 16px;
    border-radius: 10px;
    font-weight: 700;
}}
QPushButton#WorkbenchPrimaryButton {{
    color: #ffffff;
    background: #2563eb;
    border: 1px solid #2563eb;
}}
QPushButton#WorkbenchPrimaryButton:hover {{ background: #1d4ed8; }}
QPushButton#WorkbenchPrimaryButton:pressed {{ background: #1e40af; }}
QPushButton#SoftButton {{
    color: {text};
    background: {surface};
    border: 1px solid {border};
}}
QPushButton#SoftButton:hover {{ background: {surface_hover}; border-color: {focus}; }}
QPushButton#TableEditButton {{
    padding: 5px;
    background: transparent;
    border: none;
    border-radius: 8px;
}}
QPushButton#TableEditButton:hover {{ background: #eff6ff; }}
QPushButton#TableEditButton:pressed {{ background: #dbeafe; }}
QPushButton#PrintModeOption {{
    min-height: 34px;
    padding: 0 12px;
    color: {muted};
    background: {surface_hover};
    border: 1px solid {border};
    border-radius: 9px;
    font-weight: 800;
}}
QPushButton#PrintModeOption:hover {{ border-color: {focus}; color: {text}; }}
QPushButton#PrintModeOption:checked {{ color: #ffffff; background: #2563eb; border-color: #2563eb; }}
QPushButton#SemiCodeModeButton,
QPushButton#SemiLabelPresetButton {{
    min-height: 40px;
    padding: 0 13px;
    color: {muted};
    background: {surface};
    border: 1px solid {border};
    border-radius: 9px;
    font-weight: 800;
}}
QPushButton#SemiCodeModeButton:hover,
QPushButton#SemiLabelPresetButton:hover {{
    color: {text};
    border-color: {focus};
}}
QPushButton#SemiCodeModeButton:checked,
QPushButton#SemiLabelPresetButton:checked {{
    color: #ffffff;
    background: #2563eb;
    border-color: #2563eb;
}}
QPushButton#SemiCodeModeButton:disabled,
QPushButton#SemiLabelPresetButton:disabled {{
    color: {subdued};
    background: {surface_hover};
    border-color: {border_soft};
}}
QPushButton#SemiCodeModeButton {{ text-align: center; }}
QPushButton#SemiStepLeft,
QPushButton#SemiStepRight {{
    min-width: 38px; max-width: 38px;
    min-height: 38px; max-height: 38px;
    padding: 0;
    color: {text};
    background: {surface};
    border: 1px solid {border};
    font-size: 16px;
    font-weight: 800;
}}
QPushButton#SemiStepLeft {{
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
}}
QPushButton#SemiStepRight {{
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
}}
QPushButton#SemiStepLeft:hover,
QPushButton#SemiStepRight:hover {{ color: #2563eb; background: {surface_hover}; }}
QPushButton#SemiStepLeft:disabled,
QPushButton#SemiStepRight:disabled {{ color: {subdued}; background: {surface_hover}; }}
QLineEdit#SemiStepInput {{
    min-height: 38px;
    max-height: 38px;
    padding: 0 8px;
    color: {text};
    background: {field};
    border-top: 1px solid {border};
    border-bottom: 1px solid {border};
    border-left: none;
    border-right: none;
    border-radius: 0;
}}
QLineEdit#SemiStepInput:focus {{
    border-top-color: {focus};
    border-bottom-color: {focus};
}}
QLineEdit#SemiStepInput[autoQuantity="true"] {{
    color: #1d4ed8;
    background: #eef5ff;
    font-weight: 800;
}}
QFrame#SemiStepper {{ background: transparent; border: none; }}
QFrame#SemiProgressStrip {{
    background: {surface_hover};
    border: none;
    border-bottom: 1px solid {border};
    border-top-left-radius: 15px;
    border-top-right-radius: 15px;
}}
QLabel#SemiProgressTitle {{ color: {text}; font-weight: 800; }}
QLabel#SemiProgressRemaining {{ color: {muted}; font-weight: 700; }}
QFrame#SemiFocusArea {{
    background: {surface};
    border: none;
}}
QFrame#SemiControlArea {{
    background: {surface_hover};
    border: none;
    border-top: 1px solid {border};
    border-bottom-left-radius: 15px;
    border-bottom-right-radius: 15px;
}}
QFrame#SemiValueSection,
QFrame#SemiLabelsSection {{
    background: transparent;
    border: none;
}}
QFrame#SemiValueDivider {{
    color: {border};
    background: {border};
    border: none;
    min-height: 1px;
    max-height: 1px;
}}
QFrame#SemiVerticalDivider {{
    color: {border};
    background: {border};
    border: none;
    min-width: 1px;
    max-width: 1px;
}}
QFrame#SemiValuesColumn {{ background: transparent; border: none; }}
QLabel#SemiScanPrompt {{ color: {text}; font-size: 16px; font-weight: 800; }}
QFrame#SemiScanField {{
    background: {field};
    border: 2px solid #2563eb;
    border-radius: 13px;
}}
QLineEdit#SemiScanInput {{
    color: {text};
    background: transparent;
    border: none;
    border-radius: 0;
    font-size: 18px;
}}
QLineEdit#SemiScanInput:focus {{ border: none; }}
QPushButton#SemiPhoneButton {{
    min-height: 42px;
    padding: 0 14px;
    color: {text};
    background: {surface};
    border: 1px solid {border};
    border-radius: 9px;
    font-weight: 700;
}}
QPushButton#SemiPhoneButton:hover {{ border-color: {focus}; background: {surface_hover}; }}
QLabel#SemiScannerHint {{ color: #059669; font-size: 12px; }}
QPushButton#SemiAlternativeButton {{
    min-height: 46px;
    padding: 0 12px;
    color: {text};
    background: {surface};
    border: 1px solid {border};
    border-radius: 10px;
    font-weight: 700;
}}
QPushButton#SemiAlternativeButton:hover {{ border-color: {focus}; background: {surface_hover}; }}
QLabel#SemiCurrentName {{ font-size: 30px; font-weight: 900; }}
QPushButton#QuantityStepButton {{
    min-width: 32px; max-width: 32px; min-height: 32px; max-height: 32px;
    color: #2563eb; background: {surface_hover}; border: 1px solid {border};
    border-radius: 9px; font-size: 18px; font-weight: 900;
}}
QLabel#QuantityValue {{ color: {text}; font-size: 15px; font-weight: 900; }}
QPushButton#WorkbenchPrimaryButton:disabled,
QPushButton#SoftButton:disabled {{
    color: {subdued};
    background: {surface_hover};
    border-color: {border_soft};
}}
QTabWidget#WorkbenchTabs::pane {{
    background: {surface};
    border: 1px solid {border};
    border-radius: 14px;
    top: -1px;
}}
QTabWidget#WorkbenchTabs QTabBar::tab {{
    color: {muted};
    background: transparent;
    border: none;
    padding: 10px 18px;
    font-weight: 700;
}}
QTabWidget#WorkbenchTabs QTabBar::tab:selected {{
    color: #2563eb;
    border-bottom: 2px solid #2563eb;
}}
QTableWidget {{
    color: {text};
    background: {surface};
    alternate-background-color: {surface_hover};
    border: 1px solid {border_soft};
    border-radius: 10px;
    gridline-color: {border_soft};
    selection-background-color: #dbeafe;
    selection-color: #172033;
}}
QHeaderView::section {{
    color: {muted};
    background: {surface_hover};
    border: none;
    border-bottom: 1px solid {border};
    padding: 9px 8px;
    font-weight: 700;
}}
QLabel#BarcodePreview {{
    background: {surface};
    color: {muted};
    border-color: {border};
}}

/* Optional settings groups remain compact until the user opens them. */
QPushButton#SettingsDisclosureButton {{
    background: transparent;
    border: 1px solid transparent;
    border-radius: 13px;
    padding: 0;
    text-align: left;
}}
QPushButton#SettingsDisclosureButton:hover {{
    background: {surface_hover};
    border-color: {border};
}}
QPushButton#SettingsDisclosureButton[expanded="true"] {{
    background: {surface_hover};
    border-color: {border};
}}
QLabel#SettingsDisclosureTitle {{
    background: transparent;
    color: {text};
    font-size: 14px;
    font-weight: 850;
}}
QLabel#SettingsDisclosureSummary {{
    background: transparent;
    color: {muted};
    font-size: 11px;
    font-weight: 600;
}}
QLabel#SettingsDisclosureArrow {{
    background: transparent;
    color: {subdued};
    font-size: 22px;
    font-weight: 650;
}}

/* Identical modern scrollbars in both themes; only the token colours change. */
QScrollBar:vertical {{
    background: transparent;
    border: none;
    width: 9px;
    margin: 4px 2px;
}}
QScrollBar:horizontal {{
    background: transparent;
    border: none;
    height: 9px;
    margin: 2px 4px;
}}
QScrollBar::groove:vertical,
QScrollBar::groove:horizontal {{
    background: transparent;
    border: none;
}}
QScrollBar::handle:vertical,
QScrollBar::handle:horizontal {{
    background: {scrollbar};
    border: none;
    border-radius: 4px;
    min-height: 42px;
    min-width: 42px;
}}
QScrollBar::handle:vertical:hover,
QScrollBar::handle:horizontal:hover {{ background: {scrollbar_hover}; }}
QScrollBar::handle:vertical:pressed,
QScrollBar::handle:horizontal:pressed {{ background: {scrollbar_pressed}; }}
QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical,
QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal,
QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical,
QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal,
QScrollBar::up-arrow:vertical,
QScrollBar::down-arrow:vertical,
QScrollBar::left-arrow:horizontal,
QScrollBar::right-arrow:horizontal {{
    background: transparent;
    border: none;
    width: 0;
    height: 0;
}}

/* Toast children stay visually inside the rounded host. */
QWidget#NotificationBody,
QWidget#NotificationContent {{ background: transparent; }}
QFrame#NotificationAccent {{ border: none; }}

/* Store dashboard: bright information cards inside the established SAI shell. */
QWidget#StoreDashboardPage {{ background: {canvas}; }}
QLabel#StorePageTitle {{
    color: {text};
    font-size: 28px;
    font-weight: 850;
}}
QLabel#StorePageSubtitle,
QLabel#StoreMetricTitle,
QLabel#StoreMetricHint {{ color: {muted}; }}
QLabel#StoreConnectionState {{
    color: {muted};
    background: {surface};
    border: 1px solid {border_soft};
    border-radius: 10px;
    padding: 7px 11px;
    font-weight: 650;
}}
QLabel#StoreConnectionState[connected="true"] {{
    color: #047857;
    background: #ecfdf5;
    border-color: #a7f3d0;
}}
QFrame#StoreMetricCard {{
    background: #315ff0;
    border: none;
    border-radius: 20px;
}}
QFrame#StoreMetricCard[accent="blue"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #315ff0, stop:1 #2652dc);
}}
QFrame#StoreMetricCard[accent="green"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #45c49a, stop:1 #32ad83);
}}
QFrame#StoreMetricCard[accent="amber"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #ffbb31, stop:1 #f2a91f);
}}
QFrame#StoreMetricCard[accent="violet"] {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #a15bd0, stop:1 #8749bd);
}}
QFrame#StoreMetricCard QLabel {{ color: #ffffff; background: transparent; }}
QLabel#StoreMetricTitle {{ font-size: 12px; font-weight: 750; }}
QLabel#StoreMetricValue {{
    color: #ffffff;
    font-size: 27px;
    font-weight: 850;
}}
QLabel#StoreMetricHint {{ font-size: 10px; font-weight: 600; }}
QFrame#StoreRecommendedAction {{
    background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #a15bd0, stop:1 #8749bd);
    border: none;
    border-radius: 20px;
}}
QFrame#StoreRecommendedAction QLabel {{ color: #ffffff; background: transparent; }}
QLabel#StoreRecommendedTitle {{ font-size: 12px; font-weight: 750; }}
QLabel#StoreRecommendedText {{ font-size: 14px; font-weight: 750; }}
QLabel#StoreRecommendedHint {{ font-size: 10px; font-weight: 600; }}
QFrame#StoreChartCard {{
    background: {surface};
    border: 1px solid {border_soft};
    border-radius: 18px;
}}
QLabel#StoreChartTitle {{
    color: {text};
    font-size: 20px;
    font-weight: 850;
}}
QLabel#StoreChartTotal {{
    color: {text};
    font-size: 18px;
    font-weight: 800;
}}
QLabel#StoreChartChange {{
    color: #b45309;
    background: #fff7ed;
    border-radius: 8px;
    padding: 3px 8px;
    font-size: 10px;
    font-weight: 750;
}}
QLabel#StoreChartChange[positive="true"] {{
    color: #047857;
    background: #ecfdf5;
}}
QPushButton#StorePeriodButton {{
    min-width: 64px;
    min-height: 31px;
    padding: 0 10px;
    color: {muted};
    background: {surface_hover};
    border: 1px solid {border_soft};
    border-radius: 9px;
    font-weight: 700;
}}
QPushButton#StorePeriodButton:hover {{ border-color: {focus}; color: {text}; }}
QPushButton#StorePeriodButton:checked {{
    color: #ffffff;
    background: #2563eb;
    border-color: #2563eb;
}}
QFrame#StoreDashboardPanel {{
    background: {surface};
    border: 1px solid {border_soft};
    border-radius: 18px;
}}
QFrame#StoreDashboardPanel[tone="coral"] {{
    background: #fff6f4;
    border-color: #ffd8d2;
}}
QFrame#StoreDashboardPanel[tone="mint"] {{
    background: #effcf7;
    border-color: #c7f0df;
}}
QLabel#StorePanelTitle {{
    color: {text};
    font-size: 18px;
    font-weight: 850;
}}
QFrame#StoreDashboardPanel[tone="coral"] QLabel#StorePanelTitle {{ color: #ef5c53; }}
QFrame#StoreDashboardPanel[tone="mint"] QLabel#StorePanelTitle {{ color: #1c9b73; }}
QLabel#StorePanelMeta {{
    color: {muted};
    background: transparent;
    font-size: 10px;
    font-weight: 650;
}}
QLabel#StoreEmptyState {{
    color: {muted};
    background: transparent;
    padding: 12px 0;
}}
QPushButton#StorePanelAction {{
    min-height: 30px;
    padding: 0 13px;
    color: #ffffff;
    background: #f2675e;
    border: none;
    border-radius: 15px;
    font-weight: 750;
}}
QPushButton#StorePanelAction:hover {{ background: #e8524a; }}
QFrame#StoreReceiptRow {{
    background: rgba(255, 255, 255, 170);
    border: 1px solid #f5ded9;
    border-radius: 10px;
}}
QLabel#StoreReceiptMark {{
    min-width: 25px;
    min-height: 25px;
    color: #15966e;
    background: #d5f4e7;
    border-radius: 8px;
    font-size: 16px;
    font-weight: 850;
    qproperty-alignment: AlignCenter;
}}
QLabel#StoreReceiptSupplier {{
    color: {text};
    background: transparent;
    font-size: 11px;
    font-weight: 750;
}}
QLabel#StoreDayMarker {{
    color: #1ba67a;
    background: transparent;
    font-size: 16px;
    font-weight: 850;
}}
QLabel#StoreDayText {{
    color: {text};
    background: transparent;
    font-size: 11px;
    font-weight: 650;
}}

/* Plain thermal text printing --------------------------------------------- */
QWidget#ThermalTextPage {{ background: {canvas}; }}
QLabel#ThermalTextPageTitle {{ color: {text}; background: transparent; font-size: 27px; font-weight: 850; }}
QLabel#ThermalTextPageSubtitle {{ color: {muted}; background: transparent; font-size: 12px; }}
QFrame#ThermalTextCard {{ background: {surface}; border: 1px solid {border_soft}; border-radius: 18px; }}
QLabel#ThermalTextSectionTitle {{ color: {text}; background: transparent; font-size: 16px; font-weight: 850; }}
QLabel#ThermalTextFieldLabel, QLabel#ThermalTextPreviewSize {{ color: {muted}; background: transparent; font-size: 11px; font-weight: 700; }}
QTextEdit#ThermalTextEditor {{
    color: {text}; background: {field}; border: 1px solid {border}; border-radius: 13px;
    padding: 14px; font-size: 20px; font-weight: 750;
    selection-background-color: {focus}; selection-color: #ffffff;
}}
QTextEdit#ThermalTextEditor:focus {{ border: 2px solid {focus}; padding: 13px; }}
QComboBox#ThermalTextCombo, QSpinBox#ThermalTextCopies {{
    min-height: 40px; color: {text}; background: {field}; border: 1px solid {border};
    border-radius: 11px; padding: 0 12px; font-size: 12px; font-weight: 750;
}}
QSpinBox#ThermalTextCopies {{ min-width: 76px; }}
QLabel#ThermalTextCanvas {{ background: {surface_hover}; border: 1px solid {border_soft}; border-radius: 14px; }}
QLabel#ThermalTextPrinterState {{
    color: #b45309; background: #fff7ed; border: 1px solid #fed7aa;
    border-radius: 10px; padding: 9px 11px; font-size: 11px; font-weight: 700;
}}
QLabel#ThermalTextPrinterState[configured="true"] {{ color: #047857; background: #ecfdf5; border-color: #a7f3d0; }}
QPushButton#ThermalTextSoftButton, QPushButton#ThermalTextPrimaryButton {{
    min-height: 42px; padding: 0 18px; border-radius: 11px; font-weight: 800;
}}
QPushButton#ThermalTextSoftButton {{ color: {text}; background: {surface}; border: 1px solid {border}; }}
QPushButton#ThermalTextSoftButton:hover {{ background: {surface_hover}; border-color: {focus}; }}
QPushButton#ThermalTextPrimaryButton {{ color: #ffffff; background: {focus}; border: 1px solid {focus}; }}
QPushButton#ThermalTextPrimaryButton:hover {{ background: #1d4ed8; border-color: #1d4ed8; }}
QPushButton#ThermalTextPrimaryButton:disabled {{ color: {muted}; background: {surface_hover}; border-color: {border_soft}; }}
QLabel#ThermalTextStatus {{ color: {muted}; background: {surface_hover}; border-radius: 9px; padding: 8px 10px; font-size: 11px; font-weight: 700; }}
QLabel#ThermalTextStatus[tone="success"] {{ color: #047857; background: #ecfdf5; }}
QLabel#ThermalTextStatus[tone="error"] {{ color: #b42318; background: #fef2f2; }}

/* Marking verification ----------------------------------------------------- */
QWidget#MarkingCheckPage {{ background: {canvas}; }}
QLabel#MarkingPageTitle {{ color: {text}; font-size: 26px; font-weight: 850; }}
QLabel#MarkingPageSubtitle, QLabel#MarkingStateNote {{ color: {muted}; font-size: 12px; }}
QLabel#MarkingTokenState {{
    color: #b45309; background: #fff7ed; border: 1px solid #fed7aa;
    border-radius: 10px; padding: 7px 11px; font-weight: 700;
}}
QLabel#MarkingTokenState[configured="true"] {{ color: #047857; background: #ecfdf5; border-color: #a7f3d0; }}
QFrame#MarkingScanCard, QFrame#MarkingResultCard, QFrame#MarkingPdfDropFrame {{
    background: {surface}; border: 1px solid {border}; border-radius: 17px;
}}
QFrame#MarkingPdfDropFrame[dragActive="true"] {{ background: #eff6ff; border: 2px solid #2f6df6; }}
QLabel#MarkingPdfTitle {{ color: {text}; font-size: 15px; font-weight: 850; }}
QLabel#MarkingPdfNote {{ color: {muted}; font-size: 12px; }}
QLabel#MarkingStateTitle {{ color: {text}; font-size: 18px; font-weight: 850; }}
QLineEdit#MarkingScanInput {{ min-height: 44px; padding: 0 14px; font-size: 16px; font-weight: 650; }}
QLabel#MarkingVerdict {{ color: {muted}; background: {surface_hover}; border-radius: 12px; padding: 11px 14px; font-size: 18px; font-weight: 850; }}
QLabel#MarkingVerdict[verdict="ok"] {{ color: #047857; background: #ecfdf5; }}
QLabel#MarkingVerdict[verdict="blocked"], QLabel#MarkingVerdict[verdict="error"] {{ color: #b42318; background: #fef2f2; }}
QLabel#MarkingVerdict[verdict="warning"] {{ color: #b45309; background: #fff7ed; }}
QTableWidget#MarkingDetailsTable {{ border-radius: 12px; }}
QLabel#MarkingRawResponse {{ color: {muted}; background: {surface_hover}; border: 1px solid {border_soft}; border-radius: 10px; padding: 12px; font-family: Consolas; }}
"""
