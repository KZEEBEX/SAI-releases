from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Optional

from PySide6.QtCore import QEvent, QPoint, QRect, Qt, QTimer
from PySide6.QtGui import QColor, QKeyEvent, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


@dataclass(frozen=True)
class GuidedTourStep:
    target: QWidget | Callable[[], Optional[QWidget]]
    title: str
    text: str


class GuidedTourOverlay(QWidget):
    """Modal in-app tutorial with a dimmed screen and one highlighted control."""

    def __init__(
        self,
        host: QWidget,
        steps: Iterable[GuidedTourStep],
        *,
        on_finished: Optional[Callable[[], None]] = None,
    ) -> None:
        super().__init__(host)
        self.host = host
        self.steps = list(steps)
        self.on_finished = on_finished
        self.index = 0
        self._spotlight = QRect()
        self._closed = False
        self.setObjectName("GuidedTourOverlay")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMouseTracking(True)

        self.card = QFrame(self)
        self.card.setObjectName("GuidedTourCard")
        self.card.setFixedWidth(390)
        self.card.setStyleSheet(
            "QFrame#GuidedTourCard { background:#ffffff; border:1px solid #d7e2f2; border-radius:16px; }"
            "QLabel#GuidedTourEyebrow { color:#2667eb; font-size:10px; font-weight:700; }"
            "QLabel#GuidedTourTitle { color:#162033; font-size:18px; font-weight:700; }"
            "QLabel#GuidedTourText { color:#51617d; font-size:12px; }"
            "QPushButton { min-height:36px; padding:0 14px; border-radius:9px; font-weight:700; }"
            "QPushButton#GuidedTourSoft { color:#51617d; background:#ffffff; border:1px solid #d7e2f2; }"
            "QPushButton#GuidedTourPrimary { color:#ffffff; background:#2667eb; border:1px solid #2667eb; }"
            "QPushButton#GuidedTourPrimary:hover { background:#1f5bd5; }"
        )
        layout = QVBoxLayout(self.card)
        layout.setContentsMargins(22, 20, 22, 18)
        layout.setSpacing(9)
        self.progress = QLabel()
        self.progress.setObjectName("GuidedTourEyebrow")
        self.title = QLabel()
        self.title.setObjectName("GuidedTourTitle")
        self.title.setWordWrap(True)
        self.text = QLabel()
        self.text.setObjectName("GuidedTourText")
        self.text.setWordWrap(True)
        layout.addWidget(self.progress)
        layout.addWidget(self.title)
        layout.addWidget(self.text)
        layout.addSpacing(5)

        controls = QHBoxLayout()
        controls.setSpacing(8)
        self.skip_btn = QPushButton("Пропустить")
        self.skip_btn.setObjectName("GuidedTourSoft")
        self.back_btn = QPushButton("Назад")
        self.back_btn.setObjectName("GuidedTourSoft")
        self.next_btn = QPushButton("Далее")
        self.next_btn.setObjectName("GuidedTourPrimary")
        self.skip_btn.clicked.connect(self.finish)
        self.back_btn.clicked.connect(self.previous)
        self.next_btn.clicked.connect(self.next)
        controls.addWidget(self.skip_btn)
        controls.addStretch(1)
        controls.addWidget(self.back_btn)
        controls.addWidget(self.next_btn)
        layout.addLayout(controls)

        self.host.installEventFilter(self)
        self._follow_timer = QTimer(self)
        self._follow_timer.setInterval(80)
        self._follow_timer.timeout.connect(self._layout_for_step)

    def start(self) -> None:
        if not self.steps:
            self.finish()
            return
        self.setGeometry(self.host.rect())
        self.show()
        self.raise_()
        self.setFocus(Qt.FocusReason.OtherFocusReason)
        self._follow_timer.start()
        self.show_step(0)

    def _target(self) -> Optional[QWidget]:
        if not self.steps:
            return None
        target = self.steps[self.index].target
        return target() if callable(target) else target

    def show_step(self, index: int) -> None:
        self.index = max(0, min(index, len(self.steps) - 1))
        step = self.steps[self.index]
        self.progress.setText(f"ШАГ {self.index + 1} ИЗ {len(self.steps)}")
        self.title.setText(step.title)
        self.text.setText(step.text)
        self.back_btn.setVisible(self.index > 0)
        self.next_btn.setText("Готово" if self.index == len(self.steps) - 1 else "Далее")
        target = self._target()
        if target is not None:
            parent = target.parentWidget()
            while parent is not None:
                ensure = getattr(parent, "ensureWidgetVisible", None)
                if callable(ensure):
                    ensure(target, 32, 32)
                    break
                parent = parent.parentWidget()
        QTimer.singleShot(0, self._layout_for_step)

    def next(self) -> None:
        if self.index >= len(self.steps) - 1:
            self.finish()
        else:
            self.show_step(self.index + 1)

    def previous(self) -> None:
        if self.index > 0:
            self.show_step(self.index - 1)

    def finish(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._follow_timer.stop()
        try:
            self.host.removeEventFilter(self)
        except Exception:
            pass
        self.hide()
        self.deleteLater()
        if self.on_finished is not None:
            self.on_finished()

    def _layout_for_step(self) -> None:
        if self._closed or not self.isVisible():
            return
        if self.geometry() != self.host.rect():
            self.setGeometry(self.host.rect())
        target = self._target()
        if target is None or not target.isVisible():
            self._spotlight = QRect()
        else:
            top_left = target.mapTo(self.host, QPoint(0, 0))
            self._spotlight = QRect(top_left, target.size()).adjusted(-9, -9, 9, 9)
            self._spotlight = self._spotlight.intersected(self.rect().adjusted(8, 8, -8, -8))

        margin = 18
        gap = 18
        card_size = self.card.sizeHint()
        card_w = self.card.width()
        card_h = max(190, card_size.height())
        self.card.resize(card_w, card_h)
        spot = self._spotlight
        if spot.isValid() and spot.bottom() + gap + card_h <= self.height() - margin:
            x = min(max(margin, spot.center().x() - card_w // 2), self.width() - card_w - margin)
            y = spot.bottom() + gap
        elif spot.isValid() and spot.top() - gap - card_h >= margin:
            x = min(max(margin, spot.center().x() - card_w // 2), self.width() - card_w - margin)
            y = spot.top() - gap - card_h
        elif spot.isValid() and spot.right() + gap + card_w <= self.width() - margin:
            x = spot.right() + gap
            y = min(max(margin, spot.center().y() - card_h // 2), self.height() - card_h - margin)
        else:
            x = max(margin, self.width() - card_w - margin)
            y = max(margin, min(self.height() - card_h - margin, (spot.top() if spot.isValid() else margin)))
        self.card.move(x, y)
        self.card.raise_()
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        shade = QPainterPath()
        shade.addRect(self.rect())
        if self._spotlight.isValid():
            shade.addRoundedRect(self._spotlight, 13, 13)
        shade.setFillRule(Qt.FillRule.OddEvenFill)
        painter.fillPath(shade, QColor(10, 19, 35, 178))
        if self._spotlight.isValid():
            painter.setPen(QPen(QColor("#6ea0ff"), 3))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(self._spotlight, 13, 13)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802 - Qt override
        if event.key() == Qt.Key.Key_Escape:
            self.finish()
            return
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Right):
            self.next()
            return
        if event.key() == Qt.Key.Key_Left:
            self.previous()
            return
        super().keyPressEvent(event)

    def eventFilter(self, watched, event):  # noqa: N802 - Qt override
        if watched is self.host and event.type() in (
            QEvent.Type.Resize,
            QEvent.Type.Move,
            QEvent.Type.Show,
            QEvent.Type.LayoutRequest,
        ):
            QTimer.singleShot(0, self._layout_for_step)
        return False

