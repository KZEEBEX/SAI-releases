#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import ast, json, os, sys, tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve()
os.environ["SAI_USER_DATA_DIR"]=tempfile.mkdtemp(prefix="sai_patch_af_")
sys.path.insert(0,str(root/"app"))
import sai_openai_invoice as ai
assert ai.CONTRACT_VERSION=="invoice_ai_contract_v10"
assert ai.AUDIT_PROMPT_VERSION=="invoice_audit_prompt_v5"
assert ai.AUDIT_SCHEMA_VERSION=="invoice_audit_schema_v5"
ai.invoice_contract_metadata()
doc={"supplier":"ТЕСТ","invoice_date":"2026-07-18","invoice_number":"1","document_total":100.0,"items":[{"source_row":1,"source_page":1,"raw_name":"ТОВАР","name":"ТОВАР","quantity":1,"unit":"шт","purchase_price":100,"line_total":100,"article":"A1","barcodes":["4601234567893"],"confidence":0.9,"note":""}]}
audit_barcode={"supplier":"ТЕСТ","invoice_date":"2026-07-18","invoice_number":"1","document_total":100.0,"checked_rows":[1],"rows":[{"source_row":1,"source_page":1,"status":"uncertain","uncertain_fields":["barcodes"],"raw_name":"ТОВАР","article":"A1","barcodes":[],"quantity":1,"unit":"шт","line_total":100,"note":"ШК закрыт загнутым уголком"}]}
merged,changed,unresolved,omitted=ai.apply_audit(doc,audit_barcode)
assert merged["items"][0]["barcodes"]==[]
assert unresolved==[]
assert omitted==[1]
assert merged["items"][0]["note"]==""
audit_name=json.loads(json.dumps(audit_barcode,ensure_ascii=False))
audit_name["rows"][0]["uncertain_fields"]=["raw_name"]
audit_name["rows"][0]["note"]="Название закрыто"
_,_,unresolved2,omitted2=ai.apply_audit(doc,audit_name)
assert unresolved2==[1] and omitted2==[]
ui_path=root/"app"/"sai_pyside_preview.py"
ui=ui_path.read_text(encoding="utf-8")
ast.parse(ui,filename=str(ui_path))
assert "нечитаемый ШК оставлен пустым" in ui
assert "missing = self._missing_barcode_indices(rows)" in ui
assert "self.parent_page.show_semi_receipt()" in ui
wiki=json.loads((root/"SAI_Ecosystem_Wiki_v0.1"/"wiki_manifest.json").read_text(encoding="utf-8-sig"))
assert wiki["wiki_version"]=="1.7"
assert wiki["snapshot_sai_version"]=="1.22.7af"
print("PATCH_AF_SELF_TEST_OK")
