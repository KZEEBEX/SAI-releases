#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""UI decision tests for manually accepting a suspicious AI invoice total."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_invoice_manual_review_")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(ROOT / "app"))

import sai_pyside_preview as ui


class FakeStatus:
    def __init__(self) -> None:
        self.value = "Результат требует решения"

    def text(self) -> str:
        return self.value

    def setText(self, value: str) -> None:
        self.value = value


class FakeMessageBox:
    class Icon:
        Warning = 1

    class ButtonRole:
        AcceptRole = 1
        RejectRole = 2

    accept_next = False

    def __init__(self, parent=None) -> None:
        self.accept_button = None
        self.reject_button = None
        self.clicked = None
        self.default = None

    def setIcon(self, value):
        pass

    def setWindowTitle(self, value):
        pass

    def setText(self, value):
        pass

    def setInformativeText(self, value):
        self.info = value

    def addButton(self, text, role):
        button = object()
        if role == self.ButtonRole.AcceptRole:
            self.accept_button = button
        else:
            self.reject_button = button
        return button

    def setDefaultButton(self, button):
        self.default = button

    def exec(self):
        self.clicked = self.accept_button if self.accept_next else self.reject_button

    def clickedButton(self):
        return self.clicked


def result():
    return SimpleNamespace(
        critical_issues=["Сумма строк 100.00 не сходится с итогом документа 125.00"],
        validation={
            "manual_review_required": True,
            "manual_review_accepted": False,
            "manual_review_reasons": [
                "сумма строк 100.00 не сходится с итогом документа 125.00",
            ],
            "items_total": 100.0,
            "document_total": 125.0,
            "total_difference": 25.0,
        },
    )


class FakePage:
    def __init__(self) -> None:
        self.result = result()
        self.status_label = FakeStatus()
        self.saved_stages = []

    def persist_internal_draft(self, stage):
        self.saved_stages.append(stage)


original_box = ui.QMessageBox
ui.QMessageBox = FakeMessageBox
try:
    rejected = FakePage()
    FakeMessageBox.accept_next = False
    assert ui.ConverterPage.confirm_critical_result(rejected) is False
    assert rejected.saved_stages == []
    assert rejected.result.validation["manual_review_accepted"] is False
    assert "приход не создан" in rejected.status_label.text()

    accepted = FakePage()
    FakeMessageBox.accept_next = True
    assert ui.ConverterPage.confirm_critical_result(accepted) is True
    assert accepted.saved_stages == ["ai_review_accepted"]
    assert accepted.result.validation["manual_review_accepted"] is True
    decision = accepted.result.validation["manual_review_decision"]
    assert decision["decision"] == "accepted_by_operator"
    assert decision["items_total"] == 100.0
    assert decision["document_total"] == 125.0
    assert decision["total_difference"] == 25.0
    assert decision["accepted_at"]

    # An accepted decision is stable and never asks again.
    FakeMessageBox.accept_next = False
    assert ui.ConverterPage.confirm_critical_result(accepted) is True
    assert accepted.saved_stages == ["ai_review_accepted"]
finally:
    ui.QMessageBox = original_box

source = (ROOT / "app" / "sai_pyside_preview.py").read_text(encoding="utf-8")
assert '"Принять результат ИИ"' in source
assert '"Не принимать"' in source
assert '"НУЖНО ТВОЁ РЕШЕНИЕ: принять результат ИИ или не использовать его"' in source

print("INVOICE_AI_MANUAL_REVIEW_TESTS_OK")
