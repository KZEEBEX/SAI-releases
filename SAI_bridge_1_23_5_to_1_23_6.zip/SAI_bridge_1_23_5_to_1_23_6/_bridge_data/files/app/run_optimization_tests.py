"""Isolated regressions for session reuse, archive refresh and catalog merging."""
from __future__ import annotations
import base64
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import datetime as dt
import json
import os
from pathlib import Path
import tempfile
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch


def jwt(expiry):
    claim = base64.urlsafe_b64encode(json.dumps({"exp": expiry}).encode()).decode().rstrip("=")
    return "header." + claim + ".signature"


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "token.json"

    def test_expiry_and_corruption(self):
        from sai_sigma_session import save_session, load_session, atomic_json
        save_session(jwt(time.time() + 7200), "https://example.invalid/", self.path)
        self.assertEqual(load_session(self.path)["api_base"], "https://example.invalid")
        self.assertFalse(load_session(self.path, now=time.time() + 8000))
        save_session(jwt(time.time() + 20), "x", self.path)
        self.assertFalse(load_session(self.path))
        atomic_json(self.path, {"token": "opaque", "created_at": "2000-01-01 00:00:00"})
        self.assertFalse(load_session(self.path))
        self.path.write_text("broken", encoding="utf-8")
        self.assertFalse(load_session(self.path))
        for value in ([], 7, None):
            self.path.write_text(json.dumps(value), encoding="utf-8")
            self.assertFalse(load_session(self.path))

    def test_concurrent_login_once_and_rejected_token(self):
        from sai_sigma_session import SigmaSessionManager
        count = []
        def login():
            count.append(1)
            time.sleep(.05)
            return {"token": jwt(time.time() + 7200), "api_base": "https://example.invalid"}
        def ensure(_):
            return SigmaSessionManager(self.path).ensure(login)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(ensure, range(8)))
        self.assertEqual(len(count), 1)
        self.assertEqual(len({item["token"] for item in results}), 1)
        old = results[0]["token"]
        renewed = SigmaSessionManager(self.path).ensure(login, rejected_token=old)
        self.assertEqual(len(count), 2)
        SigmaSessionManager(self.path).ensure(login, rejected_token=old)
        self.assertEqual(len(count), 2)
        self.assertNotEqual(renewed["token"], old)

    def test_failed_login_cooldown_releases_lock(self):
        from sai_sigma_session import SigmaSessionManager, SessionUnavailable, ProcessLock
        def fail():
            raise RuntimeError("secret-must-not-be-persisted")
        with self.assertRaises(RuntimeError):
            SigmaSessionManager(self.path).ensure(fail)
        self.assertNotIn("secret", self.path.with_name("sigma_session_status.json").read_text())
        with self.assertRaises(SessionUnavailable):
            SigmaSessionManager(self.path).ensure(fail)
        with ProcessLock(self.path.with_suffix(".login.lock"), timeout=0):
            pass

    def test_get_401_replays_only_get(self):
        from sai_sigma_warehouse_sync import SigmaWarehouseSync
        sync = SigmaWarehouseSync.__new__(SigmaWarehouseSync)
        sync.progress = None
        sync.token, sync.api_base = "old", "https://old.invalid"
        calls = []
        class Response:
            def __init__(self, status): self.status_code = status
            def raise_for_status(self): assert self.status_code == 200
            def json(self): return {"ok": True}
        class Transport:
            headers = {}
            def get(self, url, **kwargs):
                calls.append((url, kwargs))
                return Response(401 if len(calls) == 1 else 200)
        sync.session = Transport()
        with patch("sai_sigma_warehouse_sync.ensure_sigma_session", return_value={"token": "new", "api_base": "https://new.invalid"}) as refresh:
            self.assertEqual(sync._get_any("https://old.invalid/products"), {"ok": True})
            refresh.assert_called_once_with(rejected_token="old")
        self.assertEqual(calls[1][0], "https://new.invalid/products")
        self.assertEqual(calls[1][1]["headers"]["Authorization"], "Bearer new")


class CoordinationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)

    def test_scope_freshness_force_and_preserved_result(self):
        from sai_sync_coordinator import SyncCoordinator
        coordinator = SyncCoordinator(self.root)
        calls = []
        def load():
            calls.append(1)
            return {"ok": True, "count": 12}
        self.assertEqual(coordinator.run("sales", "shop-a", load)["_sync_state"], "ready")
        self.assertEqual(coordinator.run("sales", "shop-a", load)["_sync_state"], "fresh")
        coordinator.run("sales", "shop-b", load)
        coordinator.run("sales", "shop-a", load, force=True)
        self.assertEqual(len(calls), 3)
        result = coordinator.run("sales", "shop-a", lambda: {"source_errors": {"sales": "failed"}}, force=True)
        self.assertEqual(result["_sync_state"], "error")
        self.assertEqual(coordinator.snapshot("sales", "shop-a")["result"]["count"], 12)
        coordinator.run("sales", "shop-a", load)
        self.assertEqual(len(calls), 4)

    def test_parallel_refresh_does_not_execute_twice(self):
        from sai_sync_coordinator import SyncCoordinator
        coordinator = SyncCoordinator(self.root)
        started, release = threading.Event(), threading.Event()
        def load():
            started.set()
            self.assertTrue(release.wait(5))
            return {"ok": True}
        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(coordinator.run, "catalog", "shop", load)
            self.assertTrue(started.wait(5))
            try:
                result = coordinator.run("catalog", "shop", lambda: self.fail("duplicate loader"))
                self.assertEqual(result["_sync_state"], "busy")
            finally:
                release.set()
            self.assertEqual(first.result()["_sync_state"], "ready")

    def test_print_per_document_restart_and_uncertain_result(self):
        from sai_print_jobs import dispatch_once
        calls = []
        def send():
            calls.append(1)
            return True
        def run(key, callback=send, **kwargs):
            return dispatch_once(key, callback, directory=self.root, **kwargs)
        self.assertEqual(run("receipt:1:ndp")["state"], "submitted")
        self.assertEqual(run("receipt:1:tags", lambda: False)["state"], "uncertain")
        self.assertEqual(run("receipt:1:ndp")["state"], "already_submitted")
        self.assertEqual(run("receipt:1:tags")["state"], "uncertain")
        self.assertEqual(calls, [1])
        self.assertEqual(run("receipt:1:tags", reprint=True)["state"], "submitted")
        self.assertEqual(len(calls), 2)
        def crash():
            raise RuntimeError("private-detail")
        with self.assertRaises(RuntimeError):
            run("receipt:2:ndp", crash)
        self.assertEqual(run("receipt:2:ndp")["state"], "uncertain")
        for path in self.root.glob("*.json"):
            self.assertNotIn("private-detail", path.read_text())

    def test_operator_price_rejects_nonfinite(self):
        from sai_core_v2.semi_auto_receipt_refactor import approve_operator_sale_price
        from sai_core_v2.pricing import sale_price_from_purchase
        for value in ("NaN", "Infinity", "-Infinity", "0", "-1"):
            with self.assertRaises(ValueError):
                approve_operator_sale_price({}, value)
        self.assertEqual(approve_operator_sale_price({}, "32,10")["sale"], 32.1)
        self.assertEqual(sale_price_from_purchase("NaN", 50), 0)
        self.assertEqual(sale_price_from_purchase(32.1, 0), 30)

    def test_receipt_partial_print_does_not_repeat_ndp(self):
        import sai_pyside_preview as ui
        import sai_print_jobs
        original_dispatch = sai_print_jobs.dispatch_once
        sent = {"ndp": 0, "tags": 0}
        def ndp(*_):
            sent["ndp"] += 1
            return True
        def tags(*_):
            sent["tags"] += 1
            if sent["tags"] == 1:
                raise RuntimeError("printer unavailable")
            return "test printer"
        page = SimpleNamespace(
            active_apply_run_id=lambda: 42,
            _last_final_print_apply_run_id=0, _last_final_print_at=0,
            _final_print_in_progress=False, log=lambda *_: None,
            create_ndp_artifact=lambda: (self.root / "ndp.pdf", 1),
            create_price_tags_artifact=lambda: (self.root / "tags.pdf", 1),
            final_document_source=lambda: self.root / "receipt.sai",
            parent_page=SimpleNamespace(notify=lambda *_: None, refresh_history_table=lambda: None),
        )
        with patch.object(ui, "load_private_config", return_value={"auto_print_ndp": True, "auto_print_price_tags": True}), \
             patch.object(ui.sai_receipt_archive, "archive_generated_document"), \
             patch.object(ui, "print_file_silent", side_effect=ndp), \
             patch.object(ui, "configured_a4_printer_name", return_value="test printer"), \
             patch.object(ui, "read_sai_price_items", return_value=[{"name": "Товар", "price": 30}]), \
             patch.object(ui, "print_price_tags_a4", side_effect=tags), \
             patch.object(sai_print_jobs, "dispatch_once", side_effect=lambda key, submit, **kw: original_dispatch(key, submit, directory=self.root, **kw)):
            ui.WorkbenchPage.create_ndp_and_price_tags(page, auto_print=True, quiet=True)
            self.assertEqual(sent, {"ndp": 1, "tags": 1})
            ui.WorkbenchPage.create_ndp_and_price_tags(page, auto_print=True, quiet=True)
            self.assertEqual(sent, {"ndp": 1, "tags": 1})
            self.assertFalse(page._final_print_in_progress)
            ui.WorkbenchPage.create_ndp_and_price_tags(page, auto_print=True, quiet=True, force_print=True)
            self.assertEqual(sent, {"ndp": 2, "tags": 2})
            self.assertEqual(page._last_final_print_apply_run_id, 42)

    def test_missing_legacy_print_flags_restore_automatic_ndp(self):
        import sai_pyside_preview as ui
        self.assertEqual(
            ui._with_private_config_defaults({}),
            {
                "auto_print_ndp": True,
                "auto_print_price_tags": True,
                "github_update_channel": "production",
            },
        )
        self.assertFalse(
            ui._with_private_config_defaults({"auto_print_ndp": False})["auto_print_ndp"]
        )

    def test_read_queue_priority_timeout_and_exception_release(self):
        from sai_read_queue import ReadQueue, INTERACTIVE, ARCHIVE
        from sai_sigma_session import SessionUnavailable
        queue = ReadQueue(self.root, capacity=1)
        order = []
        def read(name, priority):
            with queue.slot(priority, timeout=5):
                order.append(name)
        # Hold the sole slot until both priorities are demonstrably queued.
        with ThreadPoolExecutor(max_workers=2) as pool:
            with queue.slot():
                background = pool.submit(read, "archive", ARCHIVE)
                interactive = pool.submit(read, "operator", INTERACTIVE)
                deadline = time.monotonic() + 3
                while len(list(self.root.glob("*.json"))) < 2 and time.monotonic() < deadline:
                    time.sleep(.01)
                self.assertEqual(len(list(self.root.glob("*.json"))), 2)
                with self.assertRaises(SessionUnavailable):
                    with queue.slot(timeout=.05):
                        self.fail("capacity exceeded")
            background.result()
            interactive.result()
        self.assertEqual(order, ["operator", "archive"])
        with self.assertRaises(ValueError):
            with queue.slot():
                raise ValueError("request failed")
        with queue.slot(timeout=.2):
            pass
        self.assertEqual(list(self.root.glob("*.json")), [])


class CatalogTests(unittest.TestCase):
    def setUp(self):
        import sai_db
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.patch = patch.object(sai_db, "DB_PATH", Path(self.tmp.name) / "test.db")
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def test_unchanged_partial_removed_and_rollback(self):
        import sai_db
        first = {"id": "one", "name": "Товар", "barcodes": ["00001", "00002"], "raw": {"price": 25}}
        second = {"id": "two", "name": "Другой", "barcodes": ["00003"], "raw": {}}
        snapshot = {"products_by_id": {"one": first, "two": second}}
        self.assertEqual(sai_db.save_catalog(snapshot, "c", "s")["changed"], 2)
        self.assertEqual(sai_db.save_catalog(snapshot, "c", "s")["changed"], 0)
        with closing(sai_db.connect()) as con:
            before = [tuple(row) for row in con.execute("SELECT * FROM products ORDER BY sigma_id")]
        with self.assertRaises(ValueError):
            sai_db.save_catalog({}, "c", "s")
        with self.assertRaises(ValueError):
            sai_db.save_catalog(snapshot, "other-company", "s")
        with closing(sai_db.connect()) as con:
            self.assertEqual(before, [tuple(row) for row in con.execute("SELECT * FROM products ORDER BY sigma_id")])
        partial = {"products_by_id": {"one": {**first, "barcodes": ["00004"]}}}
        result = sai_db.save_catalog(partial, "c", "s", complete=False)
        self.assertEqual(result["product_count"], 2)
        loaded = sai_db.load_catalog("c", "s")
        self.assertNotIn("00001", loaded["code_to_products"])
        self.assertIn("00004", loaded["code_to_products"])
        self.assertEqual(sai_db.save_catalog(partial, "c", "s")["removed"], 1)

    def test_large_snapshot_no_rewrite(self):
        import sai_db
        products = {str(i): {"id": str(i), "name": f"Товар {i}", "barcodes": [f"{i:013d}"]} for i in range(6000)}
        snapshot = {"products_by_id": products}
        sai_db.save_catalog(snapshot, "c", "s")
        started = time.perf_counter()
        result = sai_db.save_catalog(snapshot, "c", "s")
        self.assertEqual(result["changed"], 0)
        self.assertEqual(result["barcode_count"], 6000)
        print(f"Catalog 6000 unchanged: {time.perf_counter() - started:.3f}s")

    def test_source_failure_does_not_stop_other_sources(self):
        import sai_db
        import sai_sigma_warehouse_sync as module
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            sync = module.SigmaWarehouseSync.__new__(module.SigmaWarehouseSync)
            sync.connection, sync.location_id, sync.progress = con, "test", None
            sync._devices = lambda: []
            today = dt.date.today()
            sync._periods = lambda *_args, **_kwargs: [(today, today)]
            def fail(*_):
                raise RuntimeError("network unavailable")
            sync.sync_sales_period = fail
            sync.sync_shifts_period = lambda *_: {"shifts": 2}
            sync.sync_cash_period = lambda *_: {"cash_operations": 3}
            with patch.object(module, "write_ai_dataset", return_value="isolated.json"), patch.object(module, "rebuild_daily_metrics", return_value=0), patch.object(module, "analytics_archive_stats", return_value={}):
                result = sync.sync_history()
            self.assertIn("sales", result["source_errors"])
            self.assertEqual(result["shifts"], 2)
            self.assertEqual(result["cash_operations"], 3)

    def test_recent_archive_revisited_old_archive_skipped(self):
        import sai_db
        import sai_sigma_warehouse_sync as module
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            sync = module.SigmaWarehouseSync.__new__(module.SigmaWarehouseSync)
            sync.connection, sync.location_id, sync.progress = con, "test", None
            sync._devices = lambda: []
            today = dt.date.today()
            periods = [(today - dt.timedelta(days=20), today - dt.timedelta(days=14)), (today, today)]
            sync._periods = lambda *_args, **_kwargs: periods
            seen = []
            sync.sync_sales_period = lambda start, end: (seen.append((start, end)) or {"sale_operations": 1})
            sync.sync_shifts_period = lambda *_: {}
            sync.sync_cash_period = lambda *_: {}
            with patch.object(module, "write_ai_dataset", return_value="isolated.json"), patch.object(module, "rebuild_daily_metrics", return_value=0), patch.object(module, "analytics_archive_stats", return_value={}):
                sync.sync_history()
                sync.sync_history()
            self.assertEqual(seen.count(periods[0]), 1)
            self.assertEqual(seen.count(periods[1]), 2)
            self.assertEqual(con.execute("SELECT status FROM sigma_history_periods WHERE source='sales' AND period_start=?", (today.isoformat(),)).fetchone()[0], "complete")

    def test_loaded_recent_period_does_not_make_august_incomplete(self):
        import sai_db
        import sai_analytics_ai as ai
        from sai_core_v2.sigma_warehouse import save_history_period, history_period_status
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            for start, end, status in (("2026-01-01", "2026-08-26", "complete"), ("2026-08-27", "2026-09-02", "partial"), ("2026-09-03", "2026-09-04", "partial")):
                save_history_period(con, source="sales", period_start=start, period_end=end, status=status)
            con.commit()
            rows = ai.archive_month_coverage(con, today=dt.date(2026, 9, 4))
            self.assertEqual(rows[7]["status"], "complete")
            self.assertEqual(rows[8]["status"], "complete")
            self.assertIn("04.09", rows[8]["hint"])
            self.assertEqual(rows[9]["status"], "future")
            self.assertEqual(history_period_status(con, "sales", "2026-08-27", "2026-09-02"), "complete")
            # Compatibility interpretation must not rewrite the original archive.
            self.assertEqual(con.execute("SELECT status FROM sigma_history_periods WHERE period_start='2026-08-27'").fetchone()[0], "partial")
            save_history_period(con, source="sales", period_start="2026-08-27", period_end="2026-09-02", status="partial", detail_errors=1)
            self.assertEqual(ai.archive_month_coverage(con, today=dt.date(2026, 9, 4))[7]["status"], "partial")
            save_history_period(con, source="sales", period_start="2026-08-27", period_end="2026-09-02", status="error", error="timeout")
            self.assertEqual(ai.archive_month_coverage(con, today=dt.date(2026, 9, 4))[7]["status"], "error")
            con.execute("DELETE FROM sigma_history_periods WHERE period_start='2026-08-27'")
            self.assertEqual(ai.archive_month_coverage(con, today=dt.date(2026, 9, 4))[7]["status"], "partial")

    def test_recommendation_cache_tracks_data_and_location(self):
        import sai_db
        import sai_analytics_ai as ai
        from sai_core_v2.sigma_warehouse import save_history_period
        sai_db.init_db()
        with closing(sai_db.connect()) as con, patch.object(ai, "CACHE_PATH", Path(self.tmp.name) / "recommendation.json"):
            ai.CACHE_PATH.write_text(json.dumps({"source": "ai", "title": "old"}))
            self.assertIsNone(ai.load_cached_recommendation(con, "shop"))
            ai.CACHE_PATH.write_text(json.dumps({"source": "ai", "title": "current", "data_revision": ai.recommendation_revision(con, "shop")}))
            self.assertEqual(ai.load_cached_recommendation(con, "shop")["title"], "current")
            self.assertIsNone(ai.load_cached_recommendation(con, "another-shop"))
            save_history_period(con, source="sales", period_start="2026-01-01", period_end="2026-01-07", status="complete")
            self.assertIsNone(ai.load_cached_recommendation(con, "shop"))

    def test_partial_sync_refreshes_dashboard(self):
        from sai_stock_ui import WarehousePage
        calls = []
        control = SimpleNamespace(setText=lambda *_: None, setEnabled=lambda *_: None, currentData=lambda: "shop")
        page = SimpleNamespace(sync_btn=control, hero_sync_btn=control, location_combo=control,
            refresh=lambda: calls.append("refresh"), refresh_analytics=lambda: calls.append("analytics"),
            _set_sync_status=lambda *_: None)
        for job in ({"error": "timeout"}, {"result": {"source_errors": {"sales": "timeout"}}}, {"result": {"stock": 5}}):
            page._warehouse_sync_job = job
            WarehousePage._finish_warehouse_sync(page, job)
            self.assertIsNone(page._warehouse_sync_job)
        self.assertEqual(calls, ["refresh", "refresh", "refresh"])
        WarehousePage._show_warehouse_sync_progress(page, {"phase": "analytics_ready"})
        self.assertEqual(calls[-1], "analytics")


if __name__ == "__main__":
    with tempfile.TemporaryDirectory(prefix="sai_optimization_") as isolated:
        os.environ["SAI_USER_DATA_DIR"] = isolated
        # A regression must never fall through to an actual network request.
        with patch("requests.sessions.Session.request", side_effect=AssertionError("Network forbidden in tests")):
            unittest.main()
