#!/usr/bin/env python
# -*- coding: utf-8 -*-
from decimal import Decimal

from sai_sigma_product_editor import (
    ProductCardChanges, SigmaProductEditError, SigmaProductEditor,
)


class FakeHttp:
    def __init__(self):
        self.calls = []
        self.fail_menu_put = False
        self.menu = {
            "id": "menu-product-1", "name": "Старое имя", "vendorCode": "OLD",
            "image": None, "showOnDevice": False, "workshopIds": [],
            "modifierGroups": [], "categoryId": None, "parentIds": ["group-1"],
            "menuId": "menu-1", "variations": [{
                "id": "variation-1", "catalogProductId": "product-1",
                "catalogProductName": "Старое имя", "catalogVendorCode": "OLD",
                "barcodes": ["460000000001"], "price": {"value": 10, "type": "Rb"},
                "productUnitId": "unit-piece", "productType": "OTHER",
                "isMarked": False, "isExcise": False, "isPrescription": False,
            }],
        }

    def request(self, method, path, body=None, params=None, timeout=45):
        self.calls.append((method, path, body, params))
        if path.endswith("/menu-matrix"):
            return {"rows": [{
                "id": "product-1", "name": "Старое имя", "vendorCode": "OLD",
                "productType": "OTHER", "variations": [{
                    "menu": {"id": "menu-1"},
                    "menuProduct": {"id": "menu-product-1"},
                }],
            }]}
        if path.endswith("/product-units"):
            return [{"id": "unit-piece", "shortName": "шт"}, {"id": "unit-meter", "shortName": "м"}]
        if method == "GET" and path.endswith("/menu-products/menu-product-1"):
            import copy
            return copy.deepcopy(self.menu)
        if method == "PUT" and path.endswith("/menu-products/menu-product-1"):
            if self.fail_menu_put:
                raise SigmaProductEditError("planned")
            import copy
            self.menu = copy.deepcopy(body)
            return {"id": "menu-product-1"}
        if method == "PUT" and path.endswith("/products/product-1"):
            return {"id": "product-1"}
        raise AssertionError((method, path))


class DelayedReadHttp(FakeHttp):
    def __init__(self):
        super().__init__()
        self.stale_menu = None
        self.stale_reads = 0

    def request(self, method, path, body=None, params=None, timeout=45):
        if method == "GET" and path.endswith("/menu-products/menu-product-1") and self.stale_reads:
            import copy
            self.stale_reads -= 1
            self.calls.append((method, path, body, params))
            return copy.deepcopy(self.stale_menu)
        if method == "PUT" and path.endswith("/menu-products/menu-product-1"):
            import copy
            self.stale_menu = copy.deepcopy(self.menu)
            result = super().request(method, path, body, params, timeout)
            self.stale_reads = 2
            return result
        return super().request(method, path, body, params, timeout)


class VerificationFailureHttp(FakeHttp):
    def request(self, method, path, body=None, params=None, timeout=45):
        result = super().request(method, path, body, params, timeout)
        if method == "GET" and path.endswith("/menu-products/menu-product-1"):
            if result.get("name") == "Новое имя":
                result["variations"][0]["price"]["value"] = 999
        return result


def main():
    http = FakeHttp()
    editor = SigmaProductEditor(http, "company-1", "menu-1")
    changes = ProductCardChanges(
        "Новое имя", "NEW", Decimal("241"),
        ("460000000001", "460000000002"), "м",
    )
    preview = editor.apply("product-1", changes, dry_run=True)
    assert not preview.applied and set(preview.changed_fields) == {
        "name", "vendorCode", "price", "barcodes", "productUnitId",
    }
    assert not any(call[0] == "PUT" for call in http.calls)
    result = editor.apply("product-1", changes)
    assert result.applied and result.verified
    matrix_reads = [
        call for call in http.calls
        if call[0] == "GET" and call[1].endswith("/menu-matrix")
    ]
    assert len(matrix_reads) == 1, "one editor session must reuse the menu-matrix index"
    assert matrix_reads[0][3]["size"] == 10_000, "large catalogs must load in one request"
    puts = [call for call in http.calls if call[0] == "PUT"]
    assert puts[-2][1].endswith("/products/product-1")
    assert puts[-1][1].endswith("/menu-products/menu-product-1")
    assert puts[-1][2]["parentIds"] == ["group-1"], "unknown/current card fields must survive merge"
    assert puts[-1][2]["variations"][0]["barcodes"] == ["460000000001", "460000000002"]
    assert puts[-1][2]["variations"][0]["productUnitId"] == "unit-meter"

    fast_http = FakeHttp()
    fast_editor = SigmaProductEditor(fast_http, "company-1", "menu-1")
    current = fast_editor.prepare_edit("product-1", changes)
    prepared = fast_editor.prepare_edit("product-1", changes, current=current)
    reads_before_write = [
        call for call in fast_http.calls
        if call[0] == "GET" and "/menu-products/" in call[1]
    ]
    assert len(reads_before_write) == 1, "batch preflight snapshot must be reused"
    fast_result = fast_editor.apply_prepared(prepared)
    assert fast_result.applied and fast_result.verified
    all_card_reads = [
        call for call in fast_http.calls
        if call[0] == "GET" and "/menu-products/" in call[1]
    ]
    assert len(all_card_reads) == 2, "one preflight read plus one verification read is enough"

    rollback = FakeHttp(); rollback.fail_menu_put = True
    try:
        SigmaProductEditor(rollback, "company-1", "menu-1").apply("product-1", changes)
    except SigmaProductEditError:
        pass
    else:
        raise AssertionError("menu write failure must be propagated")
    catalog_puts = [call for call in rollback.calls if call[0] == "PUT" and "/products/" in call[1]]
    assert len(catalog_puts) == 2, "catalog write must be rolled back after menu failure"

    delayed_http = DelayedReadHttp()
    delayed = SigmaProductEditor(
        delayed_http, "company-1", "menu-1",
        sleep_func=lambda _seconds: None,
        verification_delays=(0, 0, 0),
    )
    delayed_result = delayed.apply("product-1", changes)
    assert delayed_result.applied and delayed_result.verified

    rejected_http = VerificationFailureHttp()
    rejected = SigmaProductEditor(
        rejected_http, "company-1", "menu-1",
        sleep_func=lambda _seconds: None,
        verification_delays=(0, 0),
    )
    try:
        rejected.apply("product-1", changes)
    except SigmaProductEditError as exc:
        assert "откат подтверждён" in str(exc)
    else:
        raise AssertionError("unverified write must fail after a confirmed current-card rollback")
    assert rejected_http.menu["name"] == "Старое имя"
    assert rejected_http.menu["variations"][0]["price"]["value"] == 10

    try:
        editor.apply("product-1", ProductCardChanges("x", "y", Decimal("1"), ("bad-code",), "шт"), dry_run=True)
    except SigmaProductEditError:
        pass
    else:
        raise AssertionError("non-numeric barcode must be rejected")
    print("SAI SIGMA product editor tests: OK")


if __name__ == "__main__":
    main()
