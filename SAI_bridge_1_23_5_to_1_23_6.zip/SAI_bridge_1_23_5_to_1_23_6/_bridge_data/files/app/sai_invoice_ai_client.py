#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""OpenAI transport and structured-response parsing for invoice AI."""
from __future__ import annotations

import json
import ssl
import time
import urllib.error
import urllib.request
from typing import Any, Dict

import sai_converter
from sai_invoice_ai_errors import OpenAIInvoiceError
from sai_invoice_ai_models import DEFAULT_API_BASE


def make_opener(proxy_url: str = "") -> urllib.request.OpenerDirector:
    handlers: list[Any] = [urllib.request.HTTPSHandler(context=ssl.create_default_context())]
    proxy = (proxy_url or "").strip()
    handlers.insert(
        0,
        urllib.request.ProxyHandler({"http": proxy, "https": proxy} if proxy else {}),
    )
    return urllib.request.build_opener(*handlers)


def extract_output_text(response: Dict[str, Any]) -> str:
    for output in response.get("output") or []:
        if output.get("type") != "message":
            continue
        for part in output.get("content") or []:
            if part.get("type") == "output_text" and isinstance(part.get("text"), str):
                return part["text"]
            if part.get("type") == "refusal":
                raise OpenAIInvoiceError(
                    "Модель отказалась обрабатывать документ: "
                    + str(part.get("refusal") or "")
                )
    raise OpenAIInvoiceError("OpenAI вернул ответ без распознанных данных.")


def parse_response_document(
    response: Dict[str, Any],
    stage_label: str = "OpenAI",
) -> Dict[str, Any]:
    document = parse_response_document_allow_empty(response, stage_label)
    if not document.get("items"):
        raise OpenAIInvoiceError(
            f"Этап «{stage_label}» не нашёл ни одной товарной строки. "
            "Пустой результат не принят и не сохранён."
        )
    return document


def parse_response_document_allow_empty(
    response: Dict[str, Any],
    stage_label: str = "OpenAI",
) -> Dict[str, Any]:
    try:
        document = json.loads(extract_output_text(response))
    except OpenAIInvoiceError:
        raise
    except Exception as exc:
        raise OpenAIInvoiceError(
            f"Не удалось разобрать структурированный ответ этапа «{stage_label}»."
        ) from exc
    if not isinstance(document, dict) or not isinstance(document.get("items"), list):
        raise OpenAIInvoiceError(f"Этап «{stage_label}» вернул неправильную структуру.")
    return document


def parse_audit_response(
    response: Dict[str, Any],
    stage_label: str = "проверка",
) -> Dict[str, Any]:
    try:
        data = json.loads(extract_output_text(response))
    except OpenAIInvoiceError:
        raise
    except Exception as exc:
        raise OpenAIInvoiceError(
            f"Не удалось разобрать ответ этапа «{stage_label}»."
        ) from exc
    if (
        not isinstance(data, dict)
        or not isinstance(data.get("checked_rows"), list)
        or not isinstance(data.get("rows"), list)
    ):
        raise OpenAIInvoiceError(f"Этап «{stage_label}» вернул неправильную структуру.")
    try:
        data["checked_rows"] = sorted(
            set(int(value) for value in data.get("checked_rows") or [] if int(value) > 0)
        )
    except Exception as exc:
        raise OpenAIInvoiceError(
            f"Этап «{stage_label}» вернул неправильные номера строк."
        ) from exc
    seen: set[int] = set()
    for row in data.get("rows") or []:
        try:
            number = int(row.get("source_row") or 0)
        except Exception as exc:
            raise OpenAIInvoiceError(
                f"Этап «{stage_label}» вернул строку без source_row."
            ) from exc
        if number <= 0 or number in seen:
            raise OpenAIInvoiceError(
                f"Этап «{stage_label}» вернул дубликат или неверный source_row: {number}."
            )
        seen.add(number)
        row["source_row"] = number
        row["source_page"] = max(1, int(row.get("source_page") or 1))
        row["barcodes"] = [
            sai_converter.safe_str(value)
            for value in (row.get("barcodes") or [])
            if sai_converter.safe_str(value)
        ]
        row["status"] = "uncertain" if row.get("status") == "uncertain" else "verified"
    return data


def parse_header_response(
    response: Dict[str, Any],
    stage_label: str = "реквизиты",
) -> Dict[str, Any]:
    try:
        data = json.loads(extract_output_text(response))
    except OpenAIInvoiceError:
        raise
    except Exception as exc:
        raise OpenAIInvoiceError(
            f"Не удалось разобрать ответ этапа «{stage_label}»."
        ) from exc
    if not isinstance(data, dict):
        raise OpenAIInvoiceError(f"Этап «{stage_label}» вернул неправильную структуру.")
    return {
        "supplier": sai_converter.safe_str(data.get("supplier")),
        "invoice_date": sai_converter.safe_str(data.get("invoice_date")),
        "invoice_number": sai_converter.safe_str(data.get("invoice_number")),
        "document_total": sai_converter.parse_float(data.get("document_total")),
        "note": sai_converter.safe_str(data.get("note")),
    }


def response_from_document(document: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "output": [
            {
                "type": "message",
                "content": [
                    {
                        "type": "output_text",
                        "text": json.dumps(document, ensure_ascii=False),
                    }
                ],
            }
        ]
    }


def call_openai(
    payload: Dict[str, Any],
    api_key: str,
    api_base: str = DEFAULT_API_BASE,
    proxy_url: str = "",
    timeout: int = 420,
) -> Dict[str, Any]:
    key = (api_key or "").strip()
    if not key:
        raise OpenAIInvoiceError("Не указан OpenAI API key. Добавь его в настройках SAI.")
    wire_payload = {
        key_name: value
        for key_name, value in payload.items()
        if not str(key_name).startswith("_sai_")
    }
    request = urllib.request.Request(
        api_base.rstrip("/") + "/responses",
        data=json.dumps(wire_payload, ensure_ascii=False).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "User-Agent": "SAI-Invoice-Agent/13.0",
        },
    )
    raw = ""
    for attempt in range(3):
        try:
            with make_opener(proxy_url).open(request, timeout=timeout) as response:
                raw = response.read().decode("utf-8", errors="replace")
            break
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            try:
                message = (json.loads(raw).get("error") or {}).get("message") or raw[:800]
            except Exception:
                message = raw[:800]
            raise OpenAIInvoiceError(f"OpenAI HTTP {exc.code}: {message}") from exc
        except (urllib.error.URLError, ConnectionError, TimeoutError) as exc:
            if attempt < 2:
                time.sleep(0.6 * (attempt + 1))
                continue
            reason = getattr(exc, "reason", exc)
            raise OpenAIInvoiceError(
                "Сервис обработки трижды оборвал соединение. "
                "Выбранные файлы не потеряны — нажми «Распознать данные с ИИ» ещё раз. "
                f"Причина: {reason}"
            ) from exc
    try:
        data = json.loads(raw)
    except Exception as exc:
        raise OpenAIInvoiceError("OpenAI вернул повреждённый JSON-ответ.") from exc
    if data.get("error"):
        raise OpenAIInvoiceError(str((data.get("error") or {}).get("message") or data["error"]))
    return data
