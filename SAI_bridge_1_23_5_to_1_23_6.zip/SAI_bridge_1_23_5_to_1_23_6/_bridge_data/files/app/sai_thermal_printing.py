"""Thermal label rendering and Windows/Xprinter transport boundary."""
from __future__ import annotations

import ctypes
import os
import sys
from ctypes import wintypes
from pathlib import Path
from typing import Any, Mapping

from PySide6.QtCore import QMarginsF, QRect, QSizeF, Qt
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPageLayout, QPageSize, QPainter, QImage

try:
    from PySide6.QtPrintSupport import QPrinter
except Exception:  # pragma: no cover
    QPrinter = None

from sai_core_v2.barcodes import barcode_modules_for_print
from sai_datamatrix import encode_ecc200
from sai_print_routing import (
    THERMAL_PRINTER_NAME_HINTS,
    is_thermal_printer_name,
)
from sai_price_tag_pdf import fit_font, price_tag_date_text
from sai_price_tags import price_number, price_tag_name, price_text, safe_text, unit_text


THERMAL_LABEL_PROFILES = {
    "58x40": {"w_mm": 58.0, "h_mm": 40.0, "title_max": 15, "price_max": 42, "barcode_h_mm": 11.2},
    "43x25": {"w_mm": 43.0, "h_mm": 25.0, "title_max": 9, "price_max": 26, "barcode_h_mm": 7.4},
    # On 30x20 there is no useful room for a readable product title.  This
    # profile deliberately reserves the whole label for price and barcode.
    "30x20": {"w_mm": 30.0, "h_mm": 20.0, "title_max": 0, "price_max": 34, "barcode_h_mm": 10.8},
}
THERMAL_DPI = 203
DRIVER_PAGE_TOLERANCE_MM = 1.0
_THERMAL_FONTS_LOADED = False


def _ensure_thermal_fonts_loaded() -> None:
    """Load known Windows fonts explicitly for bitmap/RAW rendering.

    The bundled Qt runtime does not ship fonts.  Normal widgets can still use
    Windows text services, while an off-screen QImage may otherwise render
    every glyph as a square.
    """
    global _THERMAL_FONTS_LOADED
    if _THERMAL_FONTS_LOADED:
        return
    _THERMAL_FONTS_LOADED = True
    fonts_dir = Path(os.environ.get("WINDIR") or r"C:\Windows") / "Fonts"
    for filename in (
        "arial.ttf",
        "arialbd.ttf",
        "ariblk.ttf",
        "consola.ttf",
        "consolab.ttf",
        "segoeui.ttf",
        "segoeuib.ttf",
    ):
        path = fonts_dir / filename
        if path.exists():
            QFontDatabase.addApplicationFont(str(path))


def normalize_thermal_config(raw: Mapping[str, Any] | None = None) -> dict[str, Any]:
    cfg = dict(raw or {})
    # Accept both persisted config keys and the already-normalized mapping
    # returned by this function.  UI helpers pass the normalized mapping into
    # print_thermal_label(); treating it as raw used to reset 43x25/raw back to
    # 58x40/auto immediately before every print.
    size = str(cfg.get("thermal_label_size") or cfg.get("size") or "58x40").lower().replace("×", "x").replace(" ", "")
    if size not in THERMAL_LABEL_PROFILES:
        size = "58x40"
    method = str(cfg.get("thermal_label_print_method") or cfg.get("method") or "auto").lower().strip()
    if method not in {"auto", "raw", "driver"}:
        method = "auto"
    invert_tspl = (
        bool(cfg.get("thermal_label_tspl_invert"))
        if "thermal_label_tspl_invert" in cfg
        else bool(cfg.get("invert_tspl", True))
    )
    offset_x = cfg.get("thermal_label_offset_x_tenth_mm") if "thermal_label_offset_x_tenth_mm" in cfg else cfg.get("offset_x_tenth_mm")
    offset_y = cfg.get("thermal_label_offset_y_tenth_mm") if "thermal_label_offset_y_tenth_mm" in cfg else cfg.get("offset_y_tenth_mm")
    return {
        "printer": str(cfg.get("thermal_label_printer") or cfg.get("thermal_free_receipt_printer") or cfg.get("printer") or "").strip(),
        "free_receipt_printer": str(cfg.get("thermal_label_printer") or cfg.get("thermal_free_receipt_printer") or cfg.get("printer") or "").strip(),
        "size": size,
        "method": method,
        "invert_tspl": invert_tspl,
        "max_without_confirm": int(cfg.get("thermal_label_max_without_confirm") or cfg.get("max_without_confirm") or 20),
        "scale_percent": max(80, min(160, int(cfg.get("thermal_label_scale_percent") or cfg.get("scale_percent") or (130 if size == "58x40" else 115)))),
        "price_scale_percent": max(70, min(180, int(cfg.get("thermal_label_price_scale_percent") or cfg.get("price_scale_percent") or (120 if size == "58x40" else 110)))),
        "barcode_scale_percent": max(70, min(180, int(cfg.get("thermal_label_barcode_scale_percent") or cfg.get("barcode_scale_percent") or (125 if size == "58x40" else 110)))),
        "code_mode": "datamatrix" if str(cfg.get("thermal_label_code_mode") or cfg.get("code_mode") or "barcode").lower() == "datamatrix" else "barcode",
        "datamatrix_split": bool(cfg.get("thermal_label_datamatrix_split") if "thermal_label_datamatrix_split" in cfg else cfg.get("datamatrix_split", False)),
        "offset_x_tenth_mm": max(-50, min(50, int(offset_x or 0))),
        "offset_y_tenth_mm": max(-50, min(50, int(offset_y or 0))),
    }


def mm_to_dots(value: float, dpi: int = THERMAL_DPI) -> int:
    return int(round(float(value) * dpi / 25.4))


def resolve_windows_printer_name(
    configured: Any,
    installed: list[str] | tuple[str, ...],
    default_printer: Any = "",
) -> str:
    """Resolve stale legacy names to an installed thermal printer.

    Early SAI builds stored ``Xprinter V1 BT`` as a placeholder even when the
    real Windows queue had a vendor-specific name. QPrinter could then fall
    through to the Windows default while RAW OpenPrinter correctly failed.
    """
    requested = safe_text(configured).strip()
    names = [safe_text(name).strip() for name in installed if safe_text(name).strip()]
    by_casefold = {name.casefold(): name for name in names}
    if requested.casefold() in by_casefold:
        return by_casefold[requested.casefold()]
    if not names:
        return requested

    default_name = by_casefold.get(safe_text(default_printer).strip().casefold(), "")
    if default_name and is_thermal_printer_name(default_name):
        return default_name

    thermal = [name for name in names if is_thermal_printer_name(name)]
    if len(thermal) == 1:
        return thermal[0]
    if thermal:
        # A reinstalled USB queue commonly has "(Copy 1)" while an obsolete
        # Bluetooth/COM queue keeps the old base name. Prefer the newer copy.
        return sorted(thermal, key=lambda name: ("(copy" not in name.casefold(), name.casefold()))[0]
    return ""


def page_size_matches_label(
    actual_width_mm: float,
    actual_height_mm: float,
    size_key: str,
    tolerance_mm: float = DRIVER_PAGE_TOLERANCE_MM,
) -> bool:
    """Return whether a driver page is the requested physical label size.

    Some Windows thermal-printer drivers silently reject a custom QPageSize and
    keep A4 or another stock size. Stretching a label into that viewport makes
    one price tag span several physical stickers.
    """
    profile = THERMAL_LABEL_PROFILES.get(size_key) or THERMAL_LABEL_PROFILES["58x40"]
    actual = (float(actual_width_mm), float(actual_height_mm))
    expected = (float(profile["w_mm"]), float(profile["h_mm"]))
    tolerance = max(0.0, float(tolerance_mm))

    def close(left: tuple[float, float], right: tuple[float, float]) -> bool:
        return all(abs(a - b) <= tolerance for a, b in zip(left, right))

    return close(actual, expected)


def _driver_page_size_mm(printer: Any) -> tuple[float, float]:
    size = printer.pageLayout().pageSize().size(QPageSize.Unit.Millimeter)
    return float(size.width()), float(size.height())


def _configure_driver_label_page(printer: Any, size_key: str) -> None:
    profile = THERMAL_LABEL_PROFILES.get(size_key) or THERMAL_LABEL_PROFILES["58x40"]
    page = QPageSize(
        QSizeF(profile["w_mm"], profile["h_mm"]),
        QPageSize.Unit.Millimeter,
        f"SAI {size_key}",
        QPageSize.SizeMatchPolicy.ExactMatch,
    )
    layout = QPageLayout(
        page,
        QPageLayout.Orientation.Portrait,
        QMarginsF(0, 0, 0, 0),
        QPageLayout.Unit.Millimeter,
    )
    page_ok = bool(printer.setPageSize(page))
    layout_ok = bool(printer.setPageLayout(layout))
    actual_width, actual_height = _driver_page_size_mm(printer)
    if not page_ok or not layout_ok or not page_size_matches_label(actual_width, actual_height, size_key):
        raise RuntimeError(
            "Драйвер Windows не принял размер этикетки "
            f"{profile['w_mm']:g}×{profile['h_mm']:g} мм "
            f"(сейчас у драйвера {actual_width:g}×{actual_height:g} мм). "
            "SAI остановил печать, чтобы один ценник не разрезало на несколько наклеек. "
            "Выбери этот размер бумаги в свойствах принтера Windows или используй режим «Только TSPL RAW»."
        )


def _scaled_rect(rect: QRect, sx: float, sy: float, bounds: QRect) -> QRect:
    sx, sy = max(.2, float(sx)), max(.2, float(sy))
    width = min(bounds.width(), max(1, round(rect.width() * sx)))
    height = min(bounds.height(), max(1, round(rect.height() * sy)))
    x = round(rect.x() + rect.width() / 2 - width / 2)
    y = round(rect.y() + rect.height() / 2 - height / 2)
    x = min(max(x, bounds.x()), bounds.right() + 1 - width)
    y = min(max(y, bounds.y()), bounds.bottom() + 1 - height)
    return QRect(x, y, width, height)


def _moved_rect(rect: QRect, dx: int, dy: int, bounds: QRect) -> QRect:
    x = min(max(rect.x() + dx, bounds.x()), bounds.right() + 1 - rect.width())
    y = min(max(rect.y() + dy, bounds.y()), bounds.bottom() + 1 - rect.height())
    return QRect(x, y, rect.width(), rect.height())


def _draw_barcode(painter: QPainter, code: str, rect: QRect) -> None:
    if not safe_text(code):
        return
    modules, symbology = barcode_modules_for_print(code)
    margin = max(8, int(rect.width() * (.05 if symbology.startswith("EAN") or symbology == "UPC-A" else .12)))
    text_height = 18
    bar_height = max(18, rect.height() - text_height)
    module_width = max(1, int((rect.width() - margin * 2) / max(1, len(modules))))
    if symbology.startswith("Code128") and len(modules) * 2 + margin * 2 <= rect.width():
        module_width = max(module_width, 2)
    x_start = rect.x() + max(margin, (rect.width() - module_width * len(modules)) // 2)
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor("#000000"))
    for index, bit in enumerate(modules):
        if bit == "1":
            painter.drawRect(x_start + index * module_width, rect.y(), module_width, bar_height)
    painter.setPen(QColor("#000000"))
    font = QFont("Consolas", 7)
    font.setBold(True)
    painter.setFont(font)
    painter.drawText(QRect(rect.x(), rect.y() + bar_height, rect.width(), text_height), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, code)


def _draw_datamatrix(painter: QPainter, code: str, rect: QRect) -> None:
    """Draw a crisp square ECC200 code with a one-module quiet zone."""
    matrix = encode_ecc200(code)
    count = len(matrix)
    module = max(1, min(rect.width(), rect.height()) // (count + 2))
    side = module * (count + 2)
    left = rect.x() + (rect.width() - side) // 2 + module
    top = rect.y() + (rect.height() - side) // 2 + module
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor("#000000"))
    for row, values in enumerate(matrix):
        for col, enabled in enumerate(values):
            if enabled:
                painter.drawRect(left + col * module, top + row * module, module, module)


def render_thermal_label(item: Mapping[str, Any], size_key: str = "58x40", config: Mapping[str, Any] | None = None) -> QImage:
    _ensure_thermal_fonts_loaded()
    cfg = normalize_thermal_config(config)
    profile = THERMAL_LABEL_PROFILES.get(size_key) or THERMAL_LABEL_PROFILES["58x40"]
    width, height = mm_to_dots(profile["w_mm"]), mm_to_dots(profile["h_mm"])
    image = QImage(width, height, QImage.Format.Format_RGB32)
    image.fill(QColor("#ffffff"))
    painter = QPainter(image)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    px = mm_to_dots
    try:
        name, barcode = price_tag_name(item.get("name")), safe_text(item.get("barcode"))
        display_unit, display_price = unit_text(item.get("unit")), price_text(item.get("price"))
        scale = cfg["scale_percent"] / 100
        price_scale = cfg["price_scale_percent"] / 100
        barcode_scale = cfg["barcode_scale_percent"] / 100
        offset_x = px(cfg["offset_x_tenth_mm"] / 10)
        offset_y = px(cfg["offset_y_tenth_mm"] / 10)
        if size_key == "30x20":
            bounds = QRect(px(.6), px(.5), width-px(1.2), height-px(1.0))
            if cfg["code_mode"] == "datamatrix":
                painter.setPen(QColor("#000000"))
                if cfg["datamatrix_split"]:
                    half_width = width // 2
                    for half in range(2):
                        x = half * half_width
                        matrix_rect = QRect(x + px(.7), px(.6), half_width - px(1.4), px(13.5))
                        price_rect = QRect(x + px(.5), px(14.1), half_width - px(1.0), px(5.0))
                        _draw_datamatrix(painter, barcode, matrix_rect)
                        painter.setPen(QColor("#000000"))
                        compact_price = f"{display_price} ₽"
                        flags = int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)
                        painter.setFont(fit_font(painter, "Arial Black", compact_price, price_rect, 18, 10, False, flags))
                        painter.drawText(price_rect, flags, compact_price)
                    painter.setPen(QColor("#777777"))
                    painter.drawLine(width // 2, px(.5), width // 2, height - px(.5))
                    return image
                matrix_rect = QRect(px(.6), px(.5), px(18.8), height-px(1.0))
                price_rect = QRect(px(19.7), px(2.0), width-px(20.3), px(11.8))
                rub_rect = QRect(px(19.7), px(14.0), width-px(20.3), px(3.6))
                _draw_datamatrix(painter, barcode, matrix_rect)
                painter.setPen(QColor("#000000"))
                flags = int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)
                painter.setFont(fit_font(painter, "Arial Black", display_price, price_rect, 30, 13, False, flags))
                painter.drawText(price_rect, flags, display_price)
                rub_font = QFont("Arial", 9); rub_font.setBold(True); painter.setFont(rub_font)
                painter.drawText(rub_rect, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop, "₽")
                return image
            price = QRect(px(1.0), px(.6), width-px(2.0), px(6.3))
            barcode_rect = QRect(px(1.0), px(7.5), width-px(2.0), px(11.3))
            price = _scaled_rect(
                price,
                min(1.18, max(.82, scale * price_scale)),
                min(1.12, max(.82, scale * price_scale)),
                bounds,
            )
            barcode_rect = _scaled_rect(
                barcode_rect,
                min(1.08, max(.88, scale * barcode_scale)),
                min(1.08, max(.88, .96 + (scale * barcode_scale - 1) * .25)),
                bounds,
            )
            price = _moved_rect(price, offset_x, offset_y, bounds)
            barcode_rect = _moved_rect(barcode_rect, offset_x, offset_y, bounds)
            compact_price = f"{display_price} ₽"
            price_flags = int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter)
            painter.setPen(QColor("#000000"))
            price_max = max(20, round(34 * min(scale * price_scale, 1.25)))
            painter.setFont(fit_font(painter, "Arial Black", compact_price, price, price_max, 18, False, price_flags))
            painter.drawText(price, price_flags, compact_price)
            _draw_barcode(painter, barcode, barcode_rect)
            return image
        if size_key == "43x25":
            bounds = QRect(px(.8), px(.5), width-px(1.6), height-px(1))
            title, price, rub = QRect(px(1.4),px(.8),width-px(2.8),px(5.6)), QRect(px(1.2),px(6.2),px(29.2),px(8.8)), QRect(px(31.2),px(6.9),width-px(32.8),px(7.8))
            barcode_rect, date = QRect(px(2.2),px(15.1),width-px(4.4),px(7.2)), QRect(px(1.3),px(22.4),px(17),px(2.1))
            title_max,title_min,price_max,price_min,rub_size,date_size=9,5,26,15,6,5
        else:
            bounds = QRect(px(1.3),px(.9),width-px(2.6),height-px(1.8))
            title, price, rub = QRect(px(2),px(1.4),width-px(4),px(8.8)), QRect(px(2),px(10.7),px(41.2),px(12.8)), QRect(px(43.6),px(12.2),width-px(46),px(9.2))
            barcode_rect, date = QRect(px(4),px(23.2),width-px(8),px(11.4)), QRect(px(2),px(36),px(21),px(2.8))
            title_max,title_min,price_max,price_min,rub_size,date_size=15,7,42,22,9,7
        title_max=max(title_min,round(title_max*min(scale,1.35))); price_max=max(price_min,round(price_max*min(scale*price_scale,1.55)))
        rub_size=max(5,round(rub_size*min(scale*price_scale,1.45))); date_size=max(5,round(date_size*min(scale,1.25)))
        barcode_rect=_scaled_rect(barcode_rect,min(1.35,max(.75,scale*barcode_scale)),min(1.22,max(.75,.92+(scale*barcode_scale-1)*.45)),bounds)
        title,price,rub,barcode_rect,date=[_moved_rect(r,offset_x,offset_y,bounds) for r in (title,price,rub,barcode_rect,date)]
        title_flags=int(Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop|Qt.TextFlag.TextWordWrap)
        painter.setPen(QColor("#000000")); painter.setFont(fit_font(painter,"Arial",name,title,title_max,title_min,True,title_flags)); painter.drawText(title,title_flags,name)
        price_flags=int(Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter)
        painter.setFont(fit_font(painter,"Arial Black",display_price,price,price_max,price_min,False,price_flags)); painter.drawText(price,price_flags,display_price)
        font=QFont("Arial",rub_size); font.setBold(True); painter.setFont(font)
        half=max(1,rub.height()//2); painter.drawText(QRect(rub.x(),rub.y(),rub.width(),half),Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignBottom,"руб."); painter.drawText(QRect(rub.x(),rub.y()+half,rub.width(),half),Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop,f"1 {display_unit}")
        _draw_barcode(painter,barcode,barcode_rect)
        font=QFont("Arial",date_size); font.setBold(True); painter.setFont(font); painter.drawText(date,Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter,price_tag_date_text())
    finally:
        painter.end()
    return image


def qimage_to_tspl_bitmap_bytes(image: QImage, invert: bool = False) -> tuple[int, int, bytes]:
    bytes_per_row=(image.width()+7)//8; data=bytearray(bytes_per_row*image.height())
    for y in range(image.height()):
        for x in range(image.width()):
            color=image.pixelColor(x,y); luminance=(color.red()*299+color.green()*587+color.blue()*114)//1000
            bit_on=(luminance>=190) if invert else (luminance<190)
            if bit_on: data[y*bytes_per_row+x//8] |= 0x80 >> (x%8)
    return bytes_per_row,image.height(),bytes(data)


def build_tspl_payload(image: QImage, size_key: str, copies: int, invert: bool = False) -> bytes:
    profile=THERMAL_LABEL_PROFILES.get(size_key) or THERMAL_LABEL_PROFILES["58x40"]
    row_bytes,height,bitmap=qimage_to_tspl_bitmap_bytes(image,invert)
    header=(f"SIZE {profile['w_mm']:.1f} mm,{profile['h_mm']:.1f} mm\r\nGAP 2 mm,0 mm\r\nDENSITY 8\r\nSPEED 4\r\nDIRECTION 1\r\nREFERENCE 0,0\r\nCLS\r\nBITMAP 0,0,{row_bytes},{height},0,").encode("ascii")
    return header+bitmap+f"\r\nPRINT 1,{max(1,int(copies or 1))}\r\n".encode("ascii")


def list_windows_printers() -> list[str]:
    if os.name != "nt": return []
    try:
        class Info(ctypes.Structure): _fields_=[("pPrinterName",ctypes.c_wchar_p),("pServerName",ctypes.c_wchar_p),("Attributes",ctypes.c_ulong)]
        spool=ctypes.WinDLL("winspool.drv",use_last_error=True); needed=ctypes.c_ulong(); returned=ctypes.c_ulong(); flags=6
        spool.EnumPrintersW(flags,None,4,None,0,ctypes.byref(needed),ctypes.byref(returned))
        if not needed.value: return []
        buf=ctypes.create_string_buffer(needed.value)
        if not spool.EnumPrintersW(flags,None,4,buf,needed,ctypes.byref(needed),ctypes.byref(returned)): return []
        arr=ctypes.cast(buf,ctypes.POINTER(Info)); names=[]
        for index in range(returned.value):
            name=safe_text(arr[index].pPrinterName)
            if name and name not in names: names.append(name)
        return sorted(names,key=lambda value:("xprinter" not in value.lower(),value.lower()))
    except Exception: return []


def get_default_windows_printer() -> str:
    if os.name != "nt": return ""
    try:
        spool=ctypes.WinDLL("winspool.drv",use_last_error=True); needed=ctypes.c_ulong(); spool.GetDefaultPrinterW(None,ctypes.byref(needed))
        if needed.value<=1: return ""
        buf=ctypes.create_unicode_buffer(needed.value)
        return safe_text(buf.value) if spool.GetDefaultPrinterW(buf,ctypes.byref(needed)) else ""
    except Exception: return ""


def send_raw_to_windows_printer(printer_name: str, payload: bytes) -> None:
    if not sys.platform.startswith("win"):
        raise RuntimeError("RAW-печать термоэтикеток пока поддерживается только на Windows.")
    if not printer_name.strip():
        raise RuntimeError("Не задано имя термопринтера в настройках.")

    spool = ctypes.WinDLL("winspool.drv", use_last_error=True)
    handle = wintypes.HANDLE()

    class Doc(ctypes.Structure):
        _fields_ = [
            ("pDocName", wintypes.LPWSTR),
            ("pOutputFile", wintypes.LPWSTR),
            ("pDatatype", wintypes.LPWSTR),
        ]

    # ctypes otherwise assumes 32-bit integer arguments/returns.  On 64-bit
    # Windows that truncated the printer HANDLE and terminated SAI before it
    # could report an error.
    spool.OpenPrinterW.argtypes = [
        wintypes.LPWSTR,
        ctypes.POINTER(wintypes.HANDLE),
        ctypes.c_void_p,
    ]
    spool.OpenPrinterW.restype = wintypes.BOOL
    spool.StartDocPrinterW.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        ctypes.POINTER(Doc),
    ]
    spool.StartDocPrinterW.restype = wintypes.DWORD
    spool.StartPagePrinter.argtypes = [wintypes.HANDLE]
    spool.StartPagePrinter.restype = wintypes.BOOL
    spool.WritePrinter.argtypes = [
        wintypes.HANDLE,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    spool.WritePrinter.restype = wintypes.BOOL
    spool.EndPagePrinter.argtypes = [wintypes.HANDLE]
    spool.EndPagePrinter.restype = wintypes.BOOL
    spool.EndDocPrinter.argtypes = [wintypes.HANDLE]
    spool.EndDocPrinter.restype = wintypes.BOOL
    spool.ClosePrinter.argtypes = [wintypes.HANDLE]
    spool.ClosePrinter.restype = wintypes.BOOL

    if not spool.OpenPrinterW(printer_name, ctypes.byref(handle), None):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        doc = Doc("SAI thermal label", None, "RAW")
        if not spool.StartDocPrinterW(handle, 1, ctypes.byref(doc)):
            raise ctypes.WinError(ctypes.get_last_error())
        try:
            if not spool.StartPagePrinter(handle):
                raise ctypes.WinError(ctypes.get_last_error())
            try:
                written = wintypes.DWORD()
                buf = ctypes.create_string_buffer(payload)
                if (
                    not spool.WritePrinter(
                        handle,
                        ctypes.cast(buf, ctypes.c_void_p),
                        len(payload),
                        ctypes.byref(written),
                    )
                    or written.value != len(payload)
                ):
                    raise ctypes.WinError(ctypes.get_last_error())
            finally:
                spool.EndPagePrinter(handle)
        finally:
            spool.EndDocPrinter(handle)
    finally:
        spool.ClosePrinter(handle)


def send_image_to_windows_printer(printer_name: str, image: QImage, size_key: str, copies: int = 1) -> None:
    if QPrinter is None: raise RuntimeError("Модуль QtPrintSupport недоступен.")
    profile=THERMAL_LABEL_PROFILES.get(size_key) or THERMAL_LABEL_PROFILES["58x40"]
    printer=QPrinter(QPrinter.PrinterMode.HighResolution); printer.setPrinterName(printer_name); printer.setResolution(THERMAL_DPI); printer.setFullPage(True)
    if not printer.isValid(): raise RuntimeError(f"Windows-драйвер не готов: {printer_name}")
    _configure_driver_label_page(printer, size_key)
    painter=QPainter()
    if not painter.begin(printer): raise RuntimeError("Не удалось начать печать через драйвер Windows.")
    try:
        actual_width, actual_height = _driver_page_size_mm(printer)
        if not page_size_matches_label(actual_width, actual_height, size_key):
            raise RuntimeError(
                "После начала задания драйвер Windows снова изменил размер страницы. "
                "Печать остановлена, чтобы не разрезать ценник на несколько этикеток."
            )
        target = QRect(
            0,
            0,
            mm_to_dots(profile["w_mm"], printer.resolution()),
            mm_to_dots(profile["h_mm"], printer.resolution()),
        )
        for index in range(max(1,int(copies or 1))):
            if index: printer.newPage()
            painter.drawImage(target,image)
    finally: painter.end()


def print_thermal_image(image: QImage, config: Mapping[str, Any], copies: int = 1, printer_override: str | None = None) -> bool:
    """Print an already-rendered image through the shared thermal route."""
    if image is None or image.isNull():
        raise RuntimeError("Не удалось подготовить изображение термоэтикетки.")
    cfg = normalize_thermal_config(config)
    requested_printer = safe_text(printer_override) or cfg["printer"]
    installed_printers = list_windows_printers()
    printer = resolve_windows_printer_name(requested_printer, installed_printers, get_default_windows_printer())
    size = cfg["size"]
    if not printer:
        if requested_printer:
            raise RuntimeError(
                f"Принтер «{requested_printer}» не найден в Windows. "
                "Открой настройки SAI и выбери установленный термопринтер."
            )
        raise RuntimeError("В Windows не найден установленный термопринтер.")
    raw_error = None
    if cfg["method"] in {"auto", "raw"}:
        try:
            send_raw_to_windows_printer(
                printer,
                build_tspl_payload(image, size, copies, cfg["invert_tspl"]),
            )
            return True
        except Exception as exc:
            raw_error = exc
            if cfg["method"] == "raw":
                raise
    try:
        send_image_to_windows_printer(printer, image, size, copies)
        return True
    except Exception as exc:
        if raw_error:
            raise RuntimeError(
                f"RAW-печать не сработала: {raw_error}\n\n"
                f"Печать через драйвер Windows тоже не сработала: {exc}"
            )
        raise


def print_thermal_label(item: Mapping[str, Any], config: Mapping[str, Any], copies: int = 1, printer_override: str | None = None) -> bool:
    cfg=normalize_thermal_config(config)
    requested_printer=safe_text(printer_override) or cfg["printer"]
    installed_printers=list_windows_printers()
    printer=resolve_windows_printer_name(requested_printer,installed_printers,get_default_windows_printer())
    size=cfg["size"]
    if not printer:
        if requested_printer:
            raise RuntimeError(
                f"Принтер «{requested_printer}» не найден в Windows. "
                "Открой настройки SAI и выбери установленный термопринтер."
            )
        raise RuntimeError("В Windows не найден установленный термопринтер.")
    if not safe_text(item.get("barcode")): raise RuntimeError("Нельзя печатать термоценник без штрихкода.")
    if price_number(item.get("price"))<=0: raise RuntimeError("Нельзя печатать термоценник без цены.")
    image=render_thermal_label(item,size,cfg); raw_error=None
    physical_copies = max(1, int(copies or 1))
    if size == "30x20" and cfg["code_mode"] == "datamatrix" and cfg["datamatrix_split"]:
        physical_copies = (physical_copies + 1) // 2
    if cfg["method"] in {"auto","raw"}:
        try: send_raw_to_windows_printer(printer,build_tspl_payload(image,size,physical_copies,cfg["invert_tspl"])); return True
        except Exception as exc:
            raw_error=exc
            if cfg["method"]=="raw": raise
    try: send_image_to_windows_printer(printer,image,size,physical_copies); return True
    except Exception as exc:
        if raw_error: raise RuntimeError(f"RAW-печать не сработала: {raw_error}\n\nПечать через драйвер Windows тоже не сработала: {exc}")
        raise


__all__=["DRIVER_PAGE_TOLERANCE_MM","THERMAL_DPI","THERMAL_LABEL_PROFILES","THERMAL_PRINTER_NAME_HINTS","build_tspl_payload","get_default_windows_printer","is_thermal_printer_name","list_windows_printers","mm_to_dots","normalize_thermal_config","page_size_matches_label","print_thermal_image","print_thermal_label","qimage_to_tspl_bitmap_bytes","render_thermal_label","resolve_windows_printer_name"]
