#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""SAI Package Format (.sai).

A .sai file is an open ZIP container owned by the SAI ecosystem. Structured
receipt data is stored as JSON; original supplier documents may be embedded in
``sources/``. The package is intentionally transparent and versioned so it can
be migrated without locking data into a proprietary binary format.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import mimetypes
import os
import re
import tempfile
import uuid
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

FORMAT_NAME = "SAI Package"
FORMAT_ID = "com.sai.ecosystem.package"
SCHEMA_VERSION = "1.0"
DOCUMENT_TYPE_RECEIPT = "receipt"
MANIFEST_PATH = "manifest.json"
RECEIPT_PATH = "data/receipt.json"
CHECKSUMS_PATH = "checksums.json"
MAX_JSON_BYTES = 32 * 1024 * 1024


class SaiPackageError(ValueError):
    """Raised when a .sai package is unreadable, unsafe or invalid."""


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_archive_name(name: str) -> str:
    """Return a safe, compact filename for a source embedded in ZIP."""
    raw = Path(name).name.strip() or "document"
    stem = re.sub(r"[^0-9A-Za-zА-Яа-яЁё._ -]+", "_", raw)
    stem = re.sub(r"\s+", " ", stem).strip(" .") or "document"
    return stem[:160]


def _unique_archive_path(filename: str, used: set[str]) -> str:
    clean = _safe_archive_name(filename)
    path = f"sources/{clean}"
    if path not in used:
        used.add(path)
        return path
    p = Path(clean)
    for index in range(2, 10000):
        candidate = f"sources/{p.stem}_{index}{p.suffix}"
        if candidate not in used:
            used.add(candidate)
            return candidate
    raise SaiPackageError(f"Не удалось подобрать уникальное имя вложения: {filename}")


def _safe_zip_member(name: str) -> bool:
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name


def is_sai_package(path: str | Path) -> bool:
    p = Path(path)
    if p.suffix.lower() != ".sai" or not p.is_file():
        return False
    try:
        with zipfile.ZipFile(p, "r") as zf:
            return MANIFEST_PATH in zf.namelist() and RECEIPT_PATH in zf.namelist()
    except Exception:
        return False


def _item_to_dict(item: Any, index: int) -> Dict[str, Any]:
    issues = list(getattr(item, "issues", None) or [])
    comment = str(getattr(item, "comment", "") or "").strip()
    return {
        "row": int(getattr(item, "row", 0) or index),
        "raw_name": str(getattr(item, "raw_name", "") or getattr(item, "name", "") or "").strip(),
        "name": str(getattr(item, "name", "") or "").strip(),
        "quantity": float(getattr(item, "quantity", 0.0) or 0.0),
        "unit": str(getattr(item, "unit", "штука") or "штука").strip(),
        "purchase_price": float(getattr(item, "purchase_price", 0.0) or 0.0),
        "sale_price": float(getattr(item, "sale_price", 0.0) or 0.0),
        "article": str(getattr(item, "article", "") or "").strip(),
        "category": str(getattr(item, "category", "") or "").strip(),
        "barcodes": [str(value).strip() for value in (getattr(item, "barcodes", None) or []) if str(value).strip()],
        "comment": comment,
        "issues": [str(value).strip() for value in issues if str(value).strip()],
        "line_total": float(getattr(item, "line_total", 0.0) or 0.0),
        "purchase_price_source": str(getattr(item, "purchase_price_source", "") or "").strip(),
        "confidence": float(getattr(item, "confidence", 0.0) or 0.0),
        "name_source": "manual" if bool(getattr(item, "name_manually_edited", False)) else "normalized",
        "name_normalization_changes": [str(value).strip() for value in (getattr(item, "name_normalization_changes", None) or []) if str(value).strip()],
        "name_search_aliases": [str(value).strip() for value in (getattr(item, "name_search_aliases", None) or []) if str(value).strip()],
        "name_normalizer_version": int(getattr(item, "name_normalizer_version", 0) or 0),
        "price_operator_approved": bool(getattr(item, "price_operator_approved", False)),
        "price_approval_source": str(getattr(item, "price_approval_source", "") or "").strip(),
        "price_tag_accent": str(getattr(item, "price_tag_accent", "") or "").strip(),
        "catalog_price_snapshot": float(getattr(item, "catalog_price_snapshot", 0.0) or 0.0),
        "price_approval_barcode": str(getattr(item, "price_approval_barcode", "") or "").strip(),
    }


def receipt_dict_from_result(result: Any, *, created_by_version: str = "") -> Dict[str, Any]:
    items = [_item_to_dict(item, index) for index, item in enumerate(getattr(result, "items", None) or [], start=1)]
    return {
        "schema": "sai.receipt/1.0",
        "supplier": str(getattr(result, "supplier", "") or "").strip(),
        "invoice_date": str(getattr(result, "date", "") or "").strip(),
        "invoice_number": str(getattr(result, "invoice_number", "") or "").strip(),
        "markup_percent": float(getattr(result, "markup_percent", 0.0) or 0.0),
        "currency": "RUB",
        "created_by": "SAI",
        "created_by_version": str(created_by_version or "").strip(),
        "source_type": str(getattr(result, "source_type", "") or "").strip(),
        "warnings": [str(value).strip() for value in (getattr(result, "warnings", None) or []) if str(value).strip()],
        "critical_issues": [str(value).strip() for value in (getattr(result, "critical_issues", None) or []) if str(value).strip()],
        "validation": dict(getattr(result, "validation", None) or {}),
        "items": items,
    }


def _normalize_sources(source_paths: Sequence[str | Path] | None, fallback_source: str | Path | None = None) -> List[Path]:
    values: List[str | Path] = list(source_paths or [])
    if not values and fallback_source:
        values.append(fallback_source)
    out: List[Path] = []
    seen: set[str] = set()
    for value in values:
        try:
            path = Path(value).expanduser().resolve()
        except Exception:
            continue
        if not path.is_file():
            continue
        try:
            key = os.path.normcase(str(path))
        except Exception:
            key = str(path)
        if key in seen:
            continue
        seen.add(key)
        out.append(path)
    return out


def write_package(
    result: Any,
    out_path: str | Path,
    *,
    source_paths: Sequence[str | Path] | None = None,
    created_by_version: str = "",
    document_id: str = "",
) -> str:
    """Write a complete SAI receipt package atomically and return its path."""
    out = Path(out_path)
    if out.suffix.lower() != ".sai":
        out = out.with_suffix(".sai")
    out.parent.mkdir(parents=True, exist_ok=True)

    receipt = receipt_dict_from_result(result, created_by_version=created_by_version)
    if not receipt["items"]:
        raise SaiPackageError("Нельзя создать SAI Package без товарных строк.")

    now = dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")
    doc_id = document_id.strip() if document_id else str(uuid.uuid4())
    sources = _normalize_sources(source_paths, getattr(result, "source_path", ""))
    used_names: set[str] = {MANIFEST_PATH, RECEIPT_PATH, CHECKSUMS_PATH}
    source_entries: List[Dict[str, Any]] = []
    source_payloads: List[Tuple[str, Path]] = []
    for source in sources:
        archive_path = _unique_archive_path(source.name, used_names)
        source_payloads.append((archive_path, source))
        mime = mimetypes.guess_type(source.name)[0] or "application/octet-stream"
        source_entries.append({
            "path": archive_path,
            "name": source.name,
            "mime_type": mime,
            "size": source.stat().st_size,
            "sha256": sha256_file(source),
        })

    receipt_bytes = _json_bytes(receipt)
    payload_checksums: Dict[str, Dict[str, Any]] = {
        RECEIPT_PATH: {"sha256": _sha256_bytes(receipt_bytes), "size": len(receipt_bytes)}
    }
    for archive_path, source in source_payloads:
        payload_checksums[archive_path] = {"sha256": sha256_file(source), "size": source.stat().st_size}

    manifest = {
        "format": FORMAT_NAME,
        "format_id": FORMAT_ID,
        "schema_version": SCHEMA_VERSION,
        "document_type": DOCUMENT_TYPE_RECEIPT,
        "document_id": doc_id,
        "created_at": now,
        "created_by": "SAI",
        "created_by_version": str(created_by_version or "").strip(),
        "data_file": RECEIPT_PATH,
        "sources": source_entries,
        "integrity_file": CHECKSUMS_PATH,
    }
    manifest_bytes = _json_bytes(manifest)
    checksums_bytes = _json_bytes({
        "algorithm": "SHA-256",
        "files": payload_checksums,
    })

    temp_fd, temp_name = tempfile.mkstemp(prefix=out.stem + "_", suffix=".tmp", dir=str(out.parent))
    os.close(temp_fd)
    temp = Path(temp_name)
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            zf.writestr(MANIFEST_PATH, manifest_bytes)
            zf.writestr(RECEIPT_PATH, receipt_bytes)
            zf.writestr(CHECKSUMS_PATH, checksums_bytes)
            for archive_path, source in source_payloads:
                zf.write(source, archive_path)
        # Read through the public validator before replacing an existing file.
        read_package(temp, require_sai_suffix=False, verify_integrity=True)
        temp.replace(out)
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass
        raise
    return str(out)


def _read_json_member(zf: zipfile.ZipFile, name: str) -> Any:
    try:
        info = zf.getinfo(name)
    except KeyError:
        raise SaiPackageError(f"В SAI Package отсутствует {name}.")
    if info.file_size > MAX_JSON_BYTES:
        raise SaiPackageError(f"Служебный файл {name} слишком большой.")
    try:
        return json.loads(zf.read(name).decode("utf-8-sig"))
    except Exception as exc:
        raise SaiPackageError(f"Не удалось прочитать {name}: {exc}")


def read_package(
    path: str | Path,
    *,
    require_sai_suffix: bool = True,
    verify_integrity: bool = True,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """Validate and return ``(manifest, receipt)`` from a SAI Package."""
    p = Path(path)
    if require_sai_suffix and p.suffix.lower() != ".sai":
        raise SaiPackageError("Ожидался файл с расширением .sai.")
    if not p.is_file():
        raise SaiPackageError("SAI Package не найден.")
    try:
        with zipfile.ZipFile(p, "r") as zf:
            names = zf.namelist()
            if len(names) != len(set(names)):
                raise SaiPackageError("В SAI Package есть повторяющиеся внутренние пути.")
            bad = [name for name in names if not _safe_zip_member(name)]
            if bad:
                raise SaiPackageError("SAI Package содержит небезопасный внутренний путь.")
            manifest = _read_json_member(zf, MANIFEST_PATH)
            if not isinstance(manifest, dict):
                raise SaiPackageError("manifest.json имеет неверную структуру.")
            if manifest.get("format_id") != FORMAT_ID or manifest.get("format") != FORMAT_NAME:
                raise SaiPackageError("Это не SAI Package.")
            if str(manifest.get("schema_version") or "") != SCHEMA_VERSION:
                raise SaiPackageError(
                    f"Версия формата {manifest.get('schema_version')} пока не поддерживается."
                )
            if manifest.get("document_type") != DOCUMENT_TYPE_RECEIPT:
                raise SaiPackageError("Этот тип SAI Package пока не поддерживается.")
            data_file = str(manifest.get("data_file") or RECEIPT_PATH)
            if data_file != RECEIPT_PATH:
                raise SaiPackageError("В manifest.json указан неизвестный файл данных.")
            receipt = _read_json_member(zf, data_file)
            if not isinstance(receipt, dict):
                raise SaiPackageError("receipt.json имеет неверную структуру.")
            if receipt.get("schema") != "sai.receipt/1.0":
                raise SaiPackageError("Неизвестная схема данных прихода.")
            items = receipt.get("items")
            if not isinstance(items, list) or not items:
                raise SaiPackageError("В SAI Package нет товарных строк.")

            if verify_integrity:
                checksums = _read_json_member(zf, str(manifest.get("integrity_file") or CHECKSUMS_PATH))
                files = checksums.get("files") if isinstance(checksums, dict) else None
                if not isinstance(files, dict):
                    raise SaiPackageError("checksums.json имеет неверную структуру.")
                for member, expected in files.items():
                    if not _safe_zip_member(str(member)) or str(member) not in names:
                        raise SaiPackageError(f"Файл целостности ссылается на отсутствующий путь: {member}")
                    data = zf.read(str(member))
                    expected_hash = str((expected or {}).get("sha256") or "").lower()
                    expected_size = int((expected or {}).get("size") or -1)
                    if len(data) != expected_size or _sha256_bytes(data).lower() != expected_hash:
                        raise SaiPackageError(f"Нарушена целостность внутреннего файла: {member}")
            return manifest, receipt
    except SaiPackageError:
        raise
    except zipfile.BadZipFile as exc:
        raise SaiPackageError(f"SAI Package повреждён: {exc}")
    except Exception as exc:
        raise SaiPackageError(f"Не удалось открыть SAI Package: {exc}")


def receipt_to_rows(receipt: Mapping[str, Any]) -> Tuple[str, List[Dict[str, Any]], Dict[str, str]]:
    """Convert package receipt JSON into the row shape used by existing SAI flows."""
    raw_items = receipt.get("items")
    if not isinstance(raw_items, list):
        raise SaiPackageError("В receipt.json отсутствует список items.")
    rows: List[Dict[str, Any]] = []
    for idx, raw in enumerate(raw_items, start=1):
        if not isinstance(raw, dict):
            raise SaiPackageError(f"Товарная строка {idx} имеет неверную структуру.")
        name = str(raw.get("name") or "").strip()
        unit = str(raw.get("unit") or "штука").strip()
        if unit not in {"штука", "м"}:
            # Keep the data layer conservative; UI/core may normalize legacy aliases.
            unit = "м" if unit.lower() in {"м", "метр", "метров", "пог. м", "погм"} else "штука"
        barcodes: List[str] = []
        for value in raw.get("barcodes") or []:
            cleaned = re.sub(r"\D+", "", str(value or ""))
            if cleaned and cleaned not in barcodes:
                barcodes.append(cleaned)
        try:
            qty = float(raw.get("quantity") or 0)
            buy = float(raw.get("purchase_price") or 0)
            sale = float(raw.get("sale_price") or 0)
        except Exception:
            raise SaiPackageError(f"В товарной строке {idx} неверное числовое значение.")
        if not name and not barcodes and qty == 0 and buy == 0 and sale == 0:
            continue
        source_row = raw.get("row") or idx
        try:
            source_row = int(float(source_row))
        except Exception:
            source_row = idx
        comment = str(raw.get("comment") or "").strip()
        issues = [str(value).strip() for value in (raw.get("issues") or []) if str(value).strip()]
        if issues:
            comment = (comment + "; " if comment else "") + "Проверить: " + ", ".join(issues)
        rows.append({
            "excel_row": idx + 1,
            "source_row": source_row,
            "barcode_cell": ", ".join(barcodes),
            "barcodes": barcodes,
            "name": name,
            "qty": qty,
            "buy": buy,
            "sale": sale,
            "unit": unit,
            "article": str(raw.get("article") or "").strip(),
            "category": str(raw.get("category") or "").strip(),
            "vat": "Без НДС",
            "type": "Обычный товар",
            "comment": comment,
            "source_format": "sai-package",
            "price_operator_approved": bool(raw.get("price_operator_approved")),
            "price_approval_source": str(raw.get("price_approval_source") or "").strip(),
            "catalog_price_snapshot": float(raw.get("catalog_price_snapshot") or 0),
            "price_approval_barcode": str(raw.get("price_approval_barcode") or "").strip(),
            "price_tag_accent": str(raw.get("price_tag_accent") or raw.get("accent_text") or "").strip(),
        })
    if not rows:
        raise SaiPackageError("В SAI Package нет читаемых товарных строк.")
    meta = {
        "supplier": str(receipt.get("supplier") or "").strip(),
        "date": str(receipt.get("invoice_date") or "").strip(),
        "invoice_number": str(receipt.get("invoice_number") or "").strip(),
        "markup_percent": str(receipt.get("markup_percent") or ""),
        "currency": str(receipt.get("currency") or "RUB").strip(),
        "source": "SAI Package",
    }
    return "SAI Package", rows, meta


def load_rows(path: str | Path) -> Tuple[str, List[Dict[str, Any]], Dict[str, str]]:
    _manifest, receipt = read_package(path)
    return receipt_to_rows(receipt)


def read_summary(path: str | Path) -> Dict[str, Any]:
    manifest, receipt = read_package(path)
    return {
        "document_id": str(manifest.get("document_id") or ""),
        "supplier": str(receipt.get("supplier") or ""),
        "date": str(receipt.get("invoice_date") or ""),
        "invoice_number": str(receipt.get("invoice_number") or ""),
        "item_count": len(receipt.get("items") or []),
        "source_count": len(manifest.get("sources") or []),
    }


def extract_sources(path: str | Path, destination: str | Path) -> List[Path]:
    """Safely extract embedded original documents and return created paths."""
    p = Path(path)
    destination = Path(destination)
    manifest, _receipt = read_package(p)
    entries = manifest.get("sources") or []
    destination.mkdir(parents=True, exist_ok=True)
    created: List[Path] = []
    with zipfile.ZipFile(p, "r") as zf:
        used: set[str] = set()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            member = str(entry.get("path") or "")
            if not _safe_zip_member(member) or member not in zf.namelist():
                continue
            name = _safe_archive_name(str(entry.get("name") or Path(member).name))
            candidate = destination / name
            stem, suffix = candidate.stem, candidate.suffix
            index = 2
            while os.path.normcase(str(candidate)) in used or candidate.exists():
                candidate = destination / f"{stem}_{index}{suffix}"
                index += 1
            used.add(os.path.normcase(str(candidate)))
            candidate.write_bytes(zf.read(member))
            created.append(candidate)
    return created


def rewrite_receipt(
    path: str | Path,
    receipt: Mapping[str, Any],
    *,
    out_path: str | Path | None = None,
) -> str:
    """Atomically replace receipt JSON while preserving manifest and attachments."""
    source = Path(path)
    manifest, _old_receipt = read_package(source)
    if not isinstance(receipt, Mapping) or receipt.get("schema") != "sai.receipt/1.0":
        raise SaiPackageError("Нельзя записать неизвестную схему receipt.json.")
    items = receipt.get("items")
    if not isinstance(items, list) or not items:
        raise SaiPackageError("Нельзя сохранить SAI Package без товарных строк.")
    destination = Path(out_path) if out_path else source
    if destination.suffix.lower() != ".sai":
        destination = destination.with_suffix(".sai")
    destination.parent.mkdir(parents=True, exist_ok=True)

    receipt_bytes = _json_bytes(dict(receipt))
    with zipfile.ZipFile(source, "r") as zin:
        preserved: Dict[str, bytes] = {}
        for name in zin.namelist():
            if name in {MANIFEST_PATH, RECEIPT_PATH, CHECKSUMS_PATH}:
                continue
            if not _safe_zip_member(name):
                raise SaiPackageError("SAI Package содержит небезопасный путь.")
            preserved[name] = zin.read(name)

    checks: Dict[str, Dict[str, Any]] = {
        RECEIPT_PATH: {"sha256": _sha256_bytes(receipt_bytes), "size": len(receipt_bytes)}
    }
    for name, data in preserved.items():
        checks[name] = {"sha256": _sha256_bytes(data), "size": len(data)}
    manifest = dict(manifest)
    manifest["modified_at"] = dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")
    manifest_bytes = _json_bytes(manifest)
    checksums_bytes = _json_bytes({"algorithm": "SHA-256", "files": checks})

    temp_fd, temp_name = tempfile.mkstemp(prefix=destination.stem + "_", suffix=".tmp", dir=str(destination.parent))
    os.close(temp_fd)
    temp = Path(temp_name)
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
            zout.writestr(MANIFEST_PATH, manifest_bytes)
            zout.writestr(RECEIPT_PATH, receipt_bytes)
            zout.writestr(CHECKSUMS_PATH, checksums_bytes)
            for name, data in preserved.items():
                zout.writestr(name, data)
        read_package(temp, require_sai_suffix=False, verify_integrity=True)
        temp.replace(destination)
    except Exception:
        try:
            temp.unlink(missing_ok=True)
        except Exception:
            pass
        raise
    return str(destination)


def read_receipt(path: str | Path) -> Dict[str, Any]:
    """Return a mutable copy of receipt.json from a validated package."""
    _manifest, receipt = read_package(path)
    return json.loads(json.dumps(receipt, ensure_ascii=False))
