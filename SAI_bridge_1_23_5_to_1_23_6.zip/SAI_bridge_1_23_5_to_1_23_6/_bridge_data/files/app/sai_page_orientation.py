#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Operator-confirmed page orientation for AI invoice ingestion.

The pure helpers intentionally avoid importing PySide6 at module import time so
installer self-tests can run even from a minimal Python runtime.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

from sai_runtime_paths import USER_DATA_DIR

ALLOWED_ANGLES = (0, -90, 90, 180)
PREFERENCES_PATH = USER_DATA_DIR / "ai_page_orientation_preferences.json"
VISUAL_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".gif"}


def normalize_angle(value: Any) -> int:
    """Return one of 0, -90, 90, 180 for any integer-like angle."""
    try:
        angle = int(float(value or 0)) % 360
    except Exception:
        return 0
    if angle == 270:
        return -90
    if angle in (0, 90, 180):
        return angle
    # Snap unusual values to the nearest right angle.
    candidates = (0, 90, 180, 270)
    snapped = min(candidates, key=lambda item: min((angle - item) % 360, (item - angle) % 360))
    return -90 if snapped == 270 else snapped


def angle_label(angle: Any) -> str:
    value = normalize_angle(angle)
    return {
        0: "без поворота",
        -90: "90° против часовой стрелки",
        90: "90° по часовой стрелке",
        180: "180°",
    }[value]


def normalize_plan(
    paths: Sequence[str | Path],
    plan: Mapping[str, Sequence[Any]] | None,
) -> Dict[str, list[Any]]:
    """Normalize page rotation and optional operator-selected crop rectangles."""
    raw = dict(plan or {})
    normalized: Dict[str, list[int]] = {}
    for raw_path in paths:
        path = Path(raw_path).expanduser().resolve()
        values = raw.get(str(path))
        if values is None:
            values = raw.get(path.name)
        if values is None:
            values = []
        page_settings: list[Any] = []
        for value in values:
            if not isinstance(value, Mapping):
                page_settings.append(normalize_angle(value))
                continue
            angle = normalize_angle(value.get("angle"))
            crop = normalize_crop(value.get("crop"))
            page_settings.append({"angle": angle, "crop": list(crop)} if crop else angle)
        normalized[str(path)] = page_settings
    return normalized


def normalize_crop(value: Any) -> tuple[float, float, float, float] | None:
    """Return a safe normalized x/y/width/height crop or ``None`` for full page."""
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        return None
    try:
        x, y, width, height = (float(part) for part in value)
    except Exception:
        return None
    x = max(0.0, min(1.0, x))
    y = max(0.0, min(1.0, y))
    width = max(0.0, min(1.0 - x, width))
    height = max(0.0, min(1.0 - y, height))
    # Tiny accidental selections are less safe than keeping the full page.
    if width < 0.05 or height < 0.05 or width * height < 0.01:
        return None
    if x < 0.002 and y < 0.002 and width > 0.996 and height > 0.996:
        return None
    return tuple(round(part, 6) for part in (x, y, width, height))


def angle_for_page(
    path: str | Path,
    page_index: int,
    plan: Mapping[str, Sequence[Any]] | None,
) -> int:
    resolved = str(Path(path).expanduser().resolve())
    values = dict(plan or {}).get(resolved)
    if values is None:
        values = dict(plan or {}).get(Path(path).name)
    if not values or page_index < 0 or page_index >= len(values):
        return 0
    value = values[page_index]
    return normalize_angle(value.get("angle")) if isinstance(value, Mapping) else normalize_angle(value)


def crop_for_page(
    path: str | Path,
    page_index: int,
    plan: Mapping[str, Sequence[Any]] | None,
) -> tuple[float, float, float, float] | None:
    resolved = str(Path(path).expanduser().resolve())
    values = dict(plan or {}).get(resolved)
    if values is None:
        values = dict(plan or {}).get(Path(path).name)
    if not values or page_index < 0 or page_index >= len(values):
        return None
    value = values[page_index]
    return normalize_crop(value.get("crop")) if isinstance(value, Mapping) else None


def plan_fingerprint(
    paths: Sequence[str | Path],
    plan: Mapping[str, Sequence[Any]] | None,
) -> str:
    normalized = normalize_plan(paths, plan)
    payload = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def has_visual_sources(paths: Sequence[str | Path]) -> bool:
    return any(Path(path).suffix.lower() in VISUAL_EXTENSIONS for path in paths)


def _supplier_key(value: str) -> str:
    text = re.sub(r"[^0-9a-zа-яё]+", " ", str(value or "").casefold()).strip()
    return re.sub(r"\s+", " ", text)


def load_supplier_preference(supplier: str) -> int | None:
    key = _supplier_key(supplier)
    if not key or not PREFERENCES_PATH.is_file():
        return None
    try:
        data = json.loads(PREFERENCES_PATH.read_text(encoding="utf-8-sig"))
        entry = (data.get("suppliers") or {}).get(key)
        if not isinstance(entry, dict):
            return None
        return normalize_angle(entry.get("default_angle"))
    except Exception:
        return None


def save_supplier_preference(supplier: str, angle: Any) -> None:
    key = _supplier_key(supplier)
    if not key:
        return
    try:
        data = json.loads(PREFERENCES_PATH.read_text(encoding="utf-8-sig")) if PREFERENCES_PATH.is_file() else {}
    except Exception:
        data = {}
    suppliers = data.setdefault("suppliers", {})
    suppliers[key] = {"default_angle": normalize_angle(angle)}
    PREFERENCES_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = PREFERENCES_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(PREFERENCES_PATH)


def apply_rotation(image: Any, angle: Any) -> Any:
    """Rotate a QImage. PySide6 is imported lazily."""
    value = normalize_angle(angle)
    if value == 0:
        return image
    from PySide6.QtGui import QTransform

    return image.transformed(QTransform().rotate(value))


def apply_crop(image: Any, crop: Any) -> Any:
    """Crop a QImage using normalized coordinates after rotation."""
    normalized = normalize_crop(crop)
    if normalized is None or image.isNull():
        return image
    from PySide6.QtCore import QRect

    x, y, width, height = normalized
    left = max(0, min(image.width() - 1, round(x * image.width())))
    top = max(0, min(image.height() - 1, round(y * image.height())))
    right = max(left + 1, min(image.width(), round((x + width) * image.width())))
    bottom = max(top + 1, min(image.height(), round((y + height) * image.height())))
    return image.copy(QRect(left, top, right - left, bottom - top))


def _ink_metrics(image: Any) -> tuple[float, float, float, float]:
    """Estimate horizontal text-line strength and ink centroid from a QImage."""
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage

    sample = image.convertToFormat(QImage.Format_Grayscale8).scaled(
        260,
        360,
        Qt.KeepAspectRatio,
        Qt.SmoothTransformation,
    )
    width = max(1, sample.width())
    height = max(1, sample.height())
    row_counts = [0.0] * height
    col_counts = [0.0] * width
    total = 0.0
    weighted_x = 0.0
    weighted_y = 0.0
    # Ignore a thin border because scanner edges can dominate the signal.
    x0, x1 = max(1, width // 50), min(width - 1, width - width // 50)
    y0, y1 = max(1, height // 50), min(height - 1, height - height // 50)
    for y in range(y0, y1):
        for x in range(x0, x1):
            gray = sample.pixelColor(x, y).red()
            ink = max(0.0, (218.0 - float(gray)) / 218.0)
            if ink <= 0.03:
                continue
            row_counts[y] += ink
            col_counts[x] += ink
            total += ink
            weighted_x += ink * x
            weighted_y += ink * y

    def variance(values: list[float]) -> float:
        if not values:
            return 0.0
        avg = sum(values) / len(values)
        return sum((value - avg) ** 2 for value in values) / len(values)

    row_variance = variance(row_counts)
    col_variance = variance(col_counts)
    cx = weighted_x / total / width if total else 0.5
    cy = weighted_y / total / height if total else 0.5
    return row_variance, col_variance, cx, cy


def propose_rotation(image: Any, preferred_angle: int | None = None) -> tuple[int, str]:
    """Suggest a rotation, always requiring visual confirmation by the operator.

    The heuristic compares all four right-angle orientations. It is deliberately
    advisory: the UI never starts a paid request until the operator confirms it.
    """
    if preferred_angle is not None:
        value = normalize_angle(preferred_angle)
        return value, "запомнено для этого поставщика"

    candidates: list[tuple[float, int]] = []
    for angle in (0, -90, 90, 180):
        rotated = apply_rotation(image, angle)
        row_variance, col_variance, cx, cy = _ink_metrics(rotated)
        line_score = row_variance / max(1e-6, col_variance)
        # Correctly oriented business documents usually begin at the left/top.
        reading_bias = (0.5 - cx) * 0.55 + (0.5 - cy) * 0.20
        candidates.append((line_score + reading_bias, angle))
    candidates.sort(reverse=True)
    best_score, best_angle = candidates[0]
    runner_up = candidates[1][0]
    margin = best_score - runner_up
    third_score = candidates[2][0]
    opposite_pair = normalize_angle(best_angle + 180) == normalize_angle(candidates[1][1])
    axis_is_clear = best_score > max(0.20, third_score * 1.35)
    if margin < max(0.03, abs(best_score) * 0.018) and not (opposite_pair and axis_is_clear):
        return 0, "ориентация неоднозначна — проверь вручную"
    return normalize_angle(best_angle), "предложено по направлению строк текста"
