#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for pixel-stable SAI navigation rail geometry."""
from __future__ import annotations

import ast
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
UI = APP / "sai_pyside_preview.py"
NOTIFICATIONS = APP / "sai_notifications.py"
ICONS = APP / "assets" / "icons"
MDI = ICONS / "mdi"


def static_tests() -> None:
    ui = UI.read_text(encoding="utf-8-sig")
    notifications = NOTIFICATIONS.read_text(encoding="utf-8-sig")
    ast.parse(ui, filename=str(UI))
    ast.parse(notifications, filename=str(NOTIFICATIONS))

    assert 'top_block.setObjectName("RailTopBlock")' in ui
    assert 'bottom_block.setObjectName("RailBottomBlock")' in ui
    assert 'rail_layout.setSpacing(0)' in ui
    assert 'top_layout.addSpacing(14)' in ui
    assert 'bottom_layout.addSpacing(12)' in ui
    assert 'version.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)' in ui
    assert 'rail.setUpdatesEnabled(False)' in ui
    assert 'layout.setContentsMargins(10, 14, 10, 12)' not in ui
    assert 'layout.setSpacing(10 if self._rail_compact else 8)' not in ui
    assert 'self._content_layout.setContentsMargins(15, 0, 15, 0)' not in ui
    assert 'self._content_layout.setSpacing(0 if self.compact else 10)' not in ui
    assert 'self._layout.setContentsMargins(15, 9, 15, 9)' not in notifications
    assert 'self._layout.setSpacing(0 if self._compact else 10)' not in notifications
    assert 'shadow.setBlurRadius(44)' in notifications

    required = [
        "truck-delivery-outline.svg", "history.svg", "tag-outline.svg",
        "store-outline.svg", "package-variant-closed.svg",
        "account-group-outline.svg", "data-matrix-scan.svg",
        "tune-variant.svg", "barcode-scan.svg",
        "plus-box-outline.svg",
    ]
    for name in required:
        path = MDI / name
        assert path.is_file(), name
        root = ET.parse(path).getroot()
        assert root.attrib.get("viewBox") == "0 0 24 24"
    assert '"ux": "mdi/truck-delivery-outline.svg"' in ui
    assert '"semi": "mdi/barcode-scan.svg"' in ui
    assert '"marking": "mdi/data-matrix-scan.svg"' in ui
    assert '"settings": "mdi/tune-variant.svg"' in ui
    assert 'return "panel-expand.svg" if self.compact else "panel-collapse.svg"' in ui


def runtime_tests() -> None:
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    try:
        from PySide6.QtCore import QPoint
        from PySide6.QtWidgets import QApplication, QWidget
    except Exception as exc:
        print(f"SKIP: PySide6 rail runtime tests ({exc})")
        return

    sys.path.insert(0, str(APP))
    from sai_notifications import CatalogStatusBadge, NotificationToast
    from sai_pyside_preview import RailIconButton

    app = QApplication.instance() or QApplication([])
    app.setProperty("saiNightTheme", True)
    host = QWidget()
    host.resize(800, 600)
    host.show()

    button = RailIconButton("history", "История", parent=host)
    button.resize(196, 42)
    button.show()
    app.processEvents()
    expanded_icon = button.icon_label.mapTo(button, QPoint(0, 0))
    expanded_height = button.height()

    button.resize(50, 42)
    button.set_compact(True)
    app.processEvents()
    compact_icon = button.icon_label.mapTo(button, QPoint(0, 0))
    assert compact_icon == expanded_icon, (expanded_icon, compact_icon)
    assert button.height() == expanded_height == 42
    assert button.icon_label.size().width() == 24
    assert button.icon_label.size().height() == 24
    assert button.text_label.isHidden()

    badge = CatalogStatusBadge(host)
    badge.resize(196, 58)
    badge.show()
    app.processEvents()
    expanded_glyph = badge.glyph.mapTo(badge, QPoint(0, 0))
    badge.resize(50, 58)
    badge.set_compact(True)
    app.processEvents()
    compact_glyph = badge.glyph.mapTo(badge, QPoint(0, 0))
    assert compact_glyph == expanded_glyph, (expanded_glyph, compact_glyph)
    assert badge.height() == 58

    toast = NotificationToast(host, "ПРОВЕРКА", "Тень отделяет карточку от ночного фона", "info", 30000)
    effect = toast.graphicsEffect()
    assert effect is not None
    assert int(effect.blurRadius()) == 44

    toast.deleteLater()
    badge.deleteLater()
    button.deleteLater()
    host.deleteLater()
    app.processEvents()


def main() -> None:
    static_tests()
    runtime_tests()
    print("OK: pixel-stable rail geometry tests passed")


if __name__ == "__main__":
    main()
