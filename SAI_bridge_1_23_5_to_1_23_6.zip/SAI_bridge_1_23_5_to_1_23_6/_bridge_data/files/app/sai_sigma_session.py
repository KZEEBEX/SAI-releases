"""Shared SIGMA session policy. No UI imports or network work on import.

JWT claims are only expiry hints, NOT signature validation. SIGMA validates
the credential. Automatic replay is restricted to read-only requests by callers.
"""
from __future__ import annotations

import base64
import datetime as dt
import json
import math
import os
from pathlib import Path
import tempfile
import time
from typing import Callable

from sai_runtime_paths import CACHE_DIR

OPAQUE_TOKEN_MAX_AGE = 3600
EXPIRY_MARGIN = 60


class SessionUnavailable(RuntimeError):
    pass


class ProcessLock:
    """OS-owned lock, automatically released on process death; never unlink it."""

    def __init__(self, path: Path, timeout: float = 360):
        self.path = Path(path)
        self.timeout = timeout
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        handle = self.path.open("a+b")
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self.handle = handle
                return self
            except OSError:
                if time.monotonic() >= deadline:
                    handle.close()
                    raise SessionUnavailable("Операция уже выполняется в другом процессе SAI") from None
                time.sleep(0.05)

    def __exit__(self, *_):
        handle, self.handle = self.handle, None
        if handle is None:
            return
        try:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle, fcntl.LOCK_UN)
        finally:
            handle.close()


def atomic_json(path: Path, payload: dict) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_json(path: Path) -> dict:
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8-sig"))
        return payload if isinstance(payload, dict) else {}
    except (OSError, ValueError):
        return {}


def jwt_expiry(token: str) -> float | None:
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        value = json.loads(base64.urlsafe_b64decode(parts[1] + "=" * (-len(parts[1]) % 4)))
        result = float(value["exp"])
        return result if math.isfinite(result) else None
    except (ValueError, KeyError, TypeError, UnicodeError, OverflowError):
        return None


def load_session(path: Path | None = None, *, now: float | None = None) -> dict:
    payload = read_json(path or CACHE_DIR / "sigma_runtime_token.json")
    token = str(payload.get("token") or "").strip()
    if not token:
        return {}
    timestamp = time.time() if now is None else now
    expiry = jwt_expiry(token)
    if expiry is not None:
        if timestamp + EXPIRY_MARGIN >= expiry:
            return {}
    else:
        try:
            created = dt.datetime.fromisoformat(str(payload["created_at"]))
            age = timestamp - created.timestamp()
            if age < -EXPIRY_MARGIN or age > OPAQUE_TOKEN_MAX_AGE:
                return {}
        except (ValueError, KeyError, TypeError, OverflowError):
            return {}
    return {**payload, "token": token, "api_base": str(payload.get("api_base") or "").rstrip("/")}


def save_session(token: str, api_base: str, path: Path | None = None) -> dict:
    payload = {
        "token": str(token).strip(), "api_base": str(api_base).rstrip("/"),
        "created_at": dt.datetime.now().isoformat(sep=" ", timespec="seconds"),
    }
    if not payload["token"]:
        raise SessionUnavailable("SIGMA не вернула токен")
    atomic_json(path or CACHE_DIR / "sigma_runtime_token.json", payload)
    return payload


class SigmaSessionManager:
    def __init__(self, path: Path | None = None):
        self.path = Path(path or CACHE_DIR / "sigma_runtime_token.json")
        self.status_path = self.path.with_name("sigma_session_status.json")

    def ensure(self, login: Callable[[], dict], *, rejected_token: str = "") -> dict:
        current = load_session(self.path)
        if current and current["token"] != rejected_token:
            return current
        with ProcessLock(self.path.with_suffix(".login.lock")):
            current = load_session(self.path)
            if current and current["token"] != rejected_token:
                return current
            # Failed simultaneous callers must not open a succession of browsers.
            status = read_json(self.status_path)
            if status.get("state") == "needs_login" and time.time() - float(status.get("at") or 0) < 15:
                raise SessionUnavailable("Вход SIGMA не завершён. Повторите через несколько секунд")
            atomic_json(self.status_path, {"state": "refreshing", "at": time.time()})
            try:
                payload = login()
                if rejected_token and payload.get("token") == rejected_token:
                    raise SessionUnavailable("SIGMA повторно вернула отклонённую сессию")
                saved = save_session(payload.get("token", ""), payload.get("api_base", ""), self.path)
                if not load_session(self.path):
                    raise SessionUnavailable("Полученная сессия SIGMA уже истекла")
                atomic_json(self.status_path, {"state": "ready", "at": time.time()})
                return saved
            except Exception:
                # Never persist an exception containing an access token/password.
                atomic_json(self.status_path, {"state": "needs_login", "at": time.time()})
                raise


def ensure_sigma_session(cfg: dict | None = None, *, rejected_token: str = "") -> dict:
    """Refresh auth without downloading suppliers or creating any documents."""
    from sai_runtime_paths import PRIVATE_CONFIG_PATH, PROFILE_DIR
    config = dict(cfg) if cfg is not None else read_json(PRIVATE_CONFIG_PATH)

    def login() -> dict:
        from sai_secret_store import reveal_config_secret
        from sai_waybill_creator import open_sigma_context
        from sigma_autoprihod import DEFAULT_API_BASE, DEFAULT_CLOUD_URL
        base = str(read_json(CACHE_DIR / "sigma_runtime_token.json").get("api_base") or config.get("sigma_import_api_base") or DEFAULT_API_BASE)
        runtime = open_sigma_context(
            str(PROFILE_DIR), base, DEFAULT_CLOUD_URL, 300,
            str(config.get("sigma_login") or ""), reveal_config_secret(str(config.get("sigma_password") or "")),
            str(config.get("sigma_legacy_login") or ""), reveal_config_secret(str(config.get("sigma_legacy_password") or "")),
            int(config.get("sigma_atol_max_attempts") or 3), visible=False,
            prefer_bundled_chromium=bool(config.get("prefer_bundled_chromium", True)),
            hidden_auto_visible_after=max(5, int(config.get("sai_ready_login_visible_after_seconds") or 20)),
        )
        playwright, context, _page, client = runtime
        try:
            return {"token": client.get_api_access_token(), "api_base": base}
        finally:
            try:
                context.close()
            finally:
                playwright.stop()

    return SigmaSessionManager().ensure(login, rejected_token=rejected_token)
