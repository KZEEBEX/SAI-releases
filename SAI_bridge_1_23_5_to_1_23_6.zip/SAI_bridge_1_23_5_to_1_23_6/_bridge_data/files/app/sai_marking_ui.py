#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Desktop page for operator-facing marking-code verification."""
from __future__ import annotations

import json
import threading
from pathlib import Path
from PySide6.QtCore import QObject, Qt, Signal, QTimer
from PySide6.QtWidgets import (QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget, QHeaderView, QAbstractItemView)
from sai_accounts import AccountService
from sai_marking import MarkingCheckError, MarkingCheckResult, MarkingVerificationService, result_rows
from sai_marking_pdf_print import print_marking_pdfs


class _CheckSignals(QObject):
    completed = Signal(object); failed = Signal(str)


class _PdfPrintSignals(QObject):
    completed = Signal(object); failed = Signal(str); progress = Signal(int, int, str, int)


class MarkingPdfDropFrame(QFrame):
    files_dropped = Signal(object)

    def __init__(self, parent=None) -> None:
        super().__init__(parent); self.setObjectName("MarkingPdfDropFrame"); self.setAcceptDrops(True); self.setProperty("dragActive", False)

    @staticmethod
    def _pdf_files(event) -> list[Path]:
        mime = event.mimeData()
        if not mime or not mime.hasUrls(): return []
        return [Path(url.toLocalFile()) for url in mime.urls() if url.isLocalFile() and Path(url.toLocalFile()).suffix.lower() == ".pdf"]

    def _drag_state(self, active: bool) -> None:
        self.setProperty("dragActive", bool(active)); self.style().unpolish(self); self.style().polish(self)

    def dragEnterEvent(self, event) -> None:
        if self._pdf_files(event): self._drag_state(True); event.acceptProposedAction()
        else: event.ignore()

    def dragMoveEvent(self, event) -> None:
        if self._pdf_files(event): event.acceptProposedAction()
        else: event.ignore()

    def dragLeaveEvent(self, event) -> None:
        self._drag_state(False); event.accept()

    def dropEvent(self, event) -> None:
        paths = self._pdf_files(event); self._drag_state(False)
        if paths: self.files_dropped.emit(paths); event.acceptProposedAction()
        else: event.ignore()


class MarkingCheckPage(QWidget):
    def __init__(self, parent_page=None) -> None:
        super().__init__(); self.setObjectName("MarkingCheckPage"); self.parent_page = parent_page; self._busy = False
        self._signals = _CheckSignals(self); self._signals.completed.connect(self._show_result); self._signals.failed.connect(self._show_error)
        self._pdf_busy = False; self._pdf_signals = _PdfPrintSignals(self); self._pdf_signals.completed.connect(self._pdf_printed); self._pdf_signals.failed.connect(self._pdf_failed); self._pdf_signals.progress.connect(self._pdf_progress)
        self._scan_finish_timer = QTimer(self); self._scan_finish_timer.setSingleShot(True); self._scan_finish_timer.setInterval(220)
        self._scan_finish_timer.timeout.connect(self._auto_accept_scan)
        self._build_ui(); QTimer.singleShot(0, self.arm_scanner)

    @staticmethod
    def _label(text: str, name: str) -> QLabel:
        label = QLabel(text); label.setObjectName(name); return label

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self); outer.setContentsMargins(28, 26, 28, 26); outer.setSpacing(16)
        header = QHBoxLayout(); titles = QVBoxLayout(); titles.setSpacing(2)
        titles.addWidget(self._label("Проверка маркировки", "MarkingPageTitle"))
        titles.addWidget(self._label("Отсканируйте полный Data Matrix — SAI сразу покажет результат проверки.", "MarkingPageSubtitle"))
        header.addLayout(titles, 1); self.token_state = self._label("", "MarkingTokenState"); header.addWidget(self.token_state, 0, Qt.AlignTop); outer.addLayout(header)
        scan_card = QFrame(); scan_card.setObjectName("MarkingScanCard"); scan = QVBoxLayout(scan_card); scan.setContentsMargins(22, 20, 22, 20); scan.setSpacing(10)
        self.state_title = self._label("Ожидание сканирования", "MarkingStateTitle")
        self.state_note = self._label("Просто отсканируйте Data Matrix — Enter нажимать не нужно.", "MarkingStateNote"); self.state_note.setWordWrap(True)
        scan.addWidget(self.state_title); scan.addWidget(self.state_note)
        row = QHBoxLayout(); row.setSpacing(10); self.code_input = QLineEdit(); self.code_input.setObjectName("MarkingScanInput")
        self.code_input.setPlaceholderText("Готов к сканированию Data Matrix")
        # A USB scanner is a keyboard wedge and sends the payload character by
        # character. Hide that mechanical stream and accept the complete code
        # automatically after the short end-of-transmission pause.
        self.code_input.setEchoMode(QLineEdit.EchoMode.NoEcho)
        self.code_input.textChanged.connect(self._scan_input_changed)
        self.code_input.returnPressed.connect(self.check_current)
        self.check_button = QPushButton("Проверить"); self.check_button.setObjectName("WorkbenchPrimaryButton"); self.check_button.clicked.connect(self.check_current)
        row.addWidget(self.code_input, 1); row.addWidget(self.check_button); scan.addLayout(row); outer.addWidget(scan_card)
        self.pdf_card = MarkingPdfDropFrame(); self.pdf_card.files_dropped.connect(self.print_pdf_files)
        pdf_layout = QHBoxLayout(self.pdf_card); pdf_layout.setContentsMargins(20, 16, 20, 16); pdf_layout.setSpacing(14)
        pdf_text = QVBoxLayout(); pdf_text.setSpacing(3)
        pdf_text.addWidget(self._label("Печать термоэтикеток из PDF", "MarkingPdfTitle"))
        self.pdf_note = self._label("Перетащите PDF сюда. Каждая страница будет напечатана как отдельная термоэтикетка.", "MarkingPdfNote"); self.pdf_note.setWordWrap(True); pdf_text.addWidget(self.pdf_note)
        pdf_layout.addLayout(pdf_text, 1)
        self.pdf_button = QPushButton("Выбрать PDF"); self.pdf_button.setObjectName("SoftButton"); self.pdf_button.clicked.connect(self._choose_pdf_files); pdf_layout.addWidget(self.pdf_button)
        outer.addWidget(self.pdf_card)
        self.result_card = QFrame(); self.result_card.setObjectName("MarkingResultCard"); result_layout = QVBoxLayout(self.result_card); result_layout.setContentsMargins(20, 18, 20, 18); result_layout.setSpacing(12)
        top = QHBoxLayout(); self.verdict = self._label("Результат появится после сканирования", "MarkingVerdict"); self.verdict.setProperty("verdict", "idle"); top.addWidget(self.verdict, 1); result_layout.addLayout(top)
        self.details = QTableWidget(0, 2); self.details.setObjectName("MarkingDetailsTable"); self.details.setHorizontalHeaderLabels(["Параметр", "Значение"])
        self.details.verticalHeader().setVisible(False); self.details.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers); self.details.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection); self.details.setAlternatingRowColors(True); self.details.setShowGrid(False)
        self.details.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents); self.details.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch); self.details.setVisible(False); result_layout.addWidget(self.details, 1)
        self.raw_button = QPushButton("Показать технический ответ"); self.raw_button.setObjectName("SoftButton"); self.raw_button.setCheckable(True); self.raw_button.toggled.connect(self._toggle_raw); self.raw_button.setVisible(False); result_layout.addWidget(self.raw_button, 0, Qt.AlignLeft)
        self.raw_text = self._label("", "MarkingRawResponse"); self.raw_text.setTextInteractionFlags(Qt.TextSelectableByMouse); self.raw_text.setWordWrap(True); self.raw_text.setVisible(False); result_layout.addWidget(self.raw_text)
        outer.addWidget(self.result_card, 1); self.refresh_token_state()

    def refresh_token_state(self) -> None:
        configured = AccountService().marking_token_mask() != "Не задан"; self.token_state.setText("Токен подключён" if configured else "Нужен токен из SAI Admin")
        self.token_state.setProperty("configured", configured); self.token_state.style().unpolish(self.token_state); self.token_state.style().polish(self.token_state)

    def arm_scanner(self) -> None:
        self._busy = False; self._scan_finish_timer.stop(); self.refresh_token_state(); self.code_input.setEnabled(True); self.check_button.setEnabled(True); self.code_input.setEchoMode(QLineEdit.EchoMode.NoEcho); self.code_input.clear(); self.code_input.setFocus()
        self.state_title.setText("Ожидание сканирования"); self.state_note.setText("Просто отсканируйте Data Matrix — Enter нажимать не нужно.")

    def _prepare_next_scan(self) -> None:
        """Keep the scanner armed after every response without an extra click."""
        self._scan_finish_timer.stop(); self.code_input.setEnabled(True); self.check_button.setEnabled(True)
        self.code_input.setEchoMode(QLineEdit.EchoMode.NoEcho); self.code_input.clear(); self.code_input.setFocus()

    def _auto_accept_scan(self) -> None:
        if not self._busy and len(self.code_input.text().strip()) >= 18:
            self.check_current()

    def check_current(self) -> None:
        if self._busy: return
        self._scan_finish_timer.stop()
        token = AccountService().effective_owner_marking_token()
        if not token: self._show_error("Токен ККТ не задан. Откройте SAI Admin и добавьте его в карточке владельца."); return
        code = self.code_input.text(); self.code_input.setEchoMode(QLineEdit.EchoMode.Normal)
        self._busy = True; self.code_input.setEnabled(False); self.check_button.setEnabled(False)
        self.state_title.setText("Проверяю маркировку…"); self.state_note.setText("SAI связался с CDN-площадкой «Честного знака». Интерфейс не зависнет.")
        def work() -> None:
            try: result = MarkingVerificationService(token).check(code)
            except Exception as exc: self._signals.failed.emit(str(exc) if isinstance(exc, MarkingCheckError) else f"Не удалось проверить маркировку: {exc}")
            else: self._signals.completed.emit(result)
        threading.Thread(target=work, name="sai-marking-check", daemon=True).start()

    def _show_result(self, result: MarkingCheckResult) -> None:
        self._busy = False; data = result.code
        verdict, tone = (("Продажа разрешена", "ok") if bool(data.get("realizable")) else (("Продажа запрещена", "blocked") if bool(data.get("found")) else ("Код не найден", "warning")))
        self.verdict.setText(verdict); self.verdict.setProperty("verdict", tone); self.verdict.style().unpolish(self.verdict); self.verdict.style().polish(self.verdict)
        rows = result_rows(result); self.details.setRowCount(len(rows))
        for row, pair in enumerate(rows): self.details.setItem(row, 0, QTableWidgetItem(pair[0])); self.details.setItem(row, 1, QTableWidgetItem(pair[1]))
        self.details.resizeRowsToContents(); self.details.setVisible(True); self.raw_text.setText(json.dumps(result.raw, ensure_ascii=False, indent=2)); self.raw_text.setVisible(False)
        self.raw_button.setChecked(False); self.raw_button.setVisible(True); self.state_title.setText("Готов к следующему сканированию"); self.state_note.setText("Результат показан ниже. Можно сразу сканировать следующий товар."); self._prepare_next_scan()

    def _show_error(self, message: str) -> None:
        self._busy = False; self.verdict.setText("Проверка не выполнена"); self.verdict.setProperty("verdict", "error"); self.verdict.style().unpolish(self.verdict); self.verdict.style().polish(self.verdict)
        self.state_title.setText("Нужна помощь"); self.state_note.setText(message); self._prepare_next_scan()

    def _scan_input_changed(self, text: str) -> None:
        if text and not self._busy and self.code_input.echoMode() == QLineEdit.EchoMode.NoEcho:
            self.state_title.setText("Считываю Data Matrix…")
            self.state_note.setText("SAI сам примет код, когда сканер закончит передачу.")
            if len(text.strip()) >= 18:
                self._scan_finish_timer.start()
        else:
            self._scan_finish_timer.stop()

    def _toggle_raw(self, shown: bool) -> None:
        self.raw_text.setVisible(bool(shown)); self.raw_button.setText("Скрыть технический ответ" if shown else "Показать технический ответ")

    def _choose_pdf_files(self) -> None:
        if self._pdf_busy: return
        paths, _filter = QFileDialog.getOpenFileNames(self, "Выберите PDF с этикетками", "", "PDF (*.pdf)")
        if paths: self.print_pdf_files([Path(path) for path in paths])

    def print_pdf_files(self, paths) -> None:
        if self._pdf_busy: return
        files = [Path(path) for path in paths]
        self._pdf_busy = True; self.pdf_button.setEnabled(False); self.pdf_card.setAcceptDrops(False)
        self.pdf_note.setText(f"Подготавливаю PDF: {len(files)} файл(а)…")
        def work() -> None:
            try:
                result = print_marking_pdfs(files, lambda done, total, name, page: self._pdf_signals.progress.emit(done, total, name, page))
            except Exception as exc: self._pdf_signals.failed.emit(str(exc))
            else: self._pdf_signals.completed.emit(result)
        threading.Thread(target=work, name="sai-marking-pdf-print", daemon=True).start()

    def _pdf_progress(self, done: int, total: int, name: str, page: int) -> None:
        self.pdf_note.setText(f"Печатаю {done + 1} из {total}: {name}, страница {page}")

    def _pdf_printed(self, result) -> None:
        self._pdf_busy = False; self.pdf_button.setEnabled(True); self.pdf_card.setAcceptDrops(True)
        self.pdf_note.setText(f"Готово: напечатано {int(result.get('printed') or 0)} термоэтикеток из {int(result.get('files') or 0)} PDF.")

    def _pdf_failed(self, message: str) -> None:
        self._pdf_busy = False; self.pdf_button.setEnabled(True); self.pdf_card.setAcceptDrops(True)
        self.pdf_note.setText(f"Печать остановлена: {message}")
