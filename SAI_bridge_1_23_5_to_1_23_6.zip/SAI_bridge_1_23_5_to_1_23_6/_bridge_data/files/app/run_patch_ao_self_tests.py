#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7ao."""
from __future__ import annotations
import ast
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
app_dir = root / "app"
ui_path = app_dir / "sai_pyside_preview.py"
version_path = app_dir / "sai_version.py"
self_tests_path = app_dir / "run_self_tests.py"
wiki_dir = root / "SAI_Ecosystem_Wiki_v0.1"

for source in (ui_path, version_path, self_tests_path, Path(__file__)):
    ast.parse(source.read_text(encoding="utf-8-sig"), filename=str(source))

ui = ui_path.read_text(encoding="utf-8-sig")
version = version_path.read_text(encoding="utf-8-sig")
self_tests = self_tests_path.read_text(encoding="utf-8-sig")
assert 'VERSION = "1.22.7ao"' in version
assert 'APP_VERSION == "v1.22.7ao"' in self_tests
assert 'title = QLabel("Добавить файлы")' in ui
assert 'Отпустите файлы — они добавятся в накладную' not in ui
assert 'title.setWordWrap(False)' in ui
assert 'title.setMinimumWidth(280)' in ui
assert 'background: rgba(219, 234, 254, 0.94);' in ui
assert 'background: rgba(15, 23, 42, 0.94);' in ui

manifest = json.loads((wiki_dir / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.6"
assert manifest["snapshot_sai_version"] == "1.22.7ao"
assert (wiki_dir / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.6 / SAI 1.22.7ao")
print("PATCH_AO_SELF_TEST_OK")
