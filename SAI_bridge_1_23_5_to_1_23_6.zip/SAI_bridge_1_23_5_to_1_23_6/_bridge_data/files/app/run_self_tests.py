#!/usr/bin/env python
# -*- coding: utf-8 -*-

import csv
import copy
import gc
import json
import os
import shutil
import tempfile
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

# Tests must never write test products or price history into the live shop database.
_TEST_RUNTIME = Path(tempfile.mkdtemp(prefix="sai_self_tests_"))
os.environ["SAI_USER_DATA_DIR"] = str(_TEST_RUNTIME / "user_data")

from openpyxl import Workbook, load_workbook

from sai_core import (
    extract_barcode_candidates,
    gtin_check_digit_ok,
    classify_barcode,
    choose_selling_price,
    price_source_label,
)
from sai_runtime_paths import ensure_runtime_dirs, LOGS_DIR, DB_PATH
import sai_db
import sai_receipt_archive
import sai_package
import sai_converter
from sai_app import (
    create_ndp_file,
    load_sai_rows,
    normalize_unit,
    prepare_sigma_import_workbook,
    fill_sigma_import_rows,
    make_xlsx_sigma_compatible,
    duplicate_article_warnings,
    analyze_multi_barcode_rows,
    barcode_conflict_resolution_key,
)


def assert_equal(actual, expected, message):
    if actual != expected:
        raise AssertionError(f"{message}: expected {expected!r}, got {actual!r}")


def read_text_auto(path: Path) -> str:
    """Read launcher text regardless of a valid Windows script encoding."""
    data = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-16", "cp1251"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise UnicodeError(f"Unsupported text encoding: {path}")


def test_core_helpers():
    import sai_converter
    assert_equal(sai_converter.parse_date("2026-07-18"), "2026-07-18", "ISO date parsing")
    assert_equal(sai_converter.parse_date("120826"), "2026-08-12", "Compact DDMMYY date parsing")
    assert_equal(sai_converter.parse_date("18.07.2026"), "2026-07-18", "Russian date parsing")
    assert_equal(extract_barcode_candidates("4006381333931, 123456"), ["4006381333931", "123456"], "barcode split")
    assert gtin_check_digit_ok("4006381333931"), "valid EAN-13 checksum should pass"
    assert_equal(classify_barcode("4006381333931"), "GTIN_OK", "barcode classification")
    assert_equal(classify_barcode("123456"), "INTERNAL_SHORT", "short/internal barcode classification")
    assert_equal(choose_selling_price(100, 120, "max"), 120.0, "max price policy")
    assert_equal(choose_selling_price(100, 120, "incoming"), 100.0, "incoming price policy")
    assert_equal(choose_selling_price(100, 120, "sigma"), 120.0, "sigma price policy")
    assert_equal(price_source_label(100, 120, 120, "max"), "MAX_SIGMA", "price source label")


def test_unit_normalization():
    assert_equal(normalize_unit("шт."), "штука", "шт. -> штука")
    assert_equal(normalize_unit("штук"), "штука", "штук -> штука")
    assert_equal(normalize_unit("метров"), "м", "метров -> м")
    assert_equal(normalize_unit("пог. м"), "м", "пог. м -> м")
    assert_equal(normalize_unit("упак"), "штука", "unknown units default to штука")


def make_dummy_sai(path: Path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Для робота SIGMA"
    ws.append(["ШК", "Кол-во", "Закуп цена", "Продажная цена", "Наименование", "Ед.", "Артикул", "Категория"])
    ws.append(["4006381333931", 2, 10, 30, "ТЕСТОВЫЙ ТОВАР 1", "шт", "ТЕСТ", "ТЕСТ"])
    ws.append(["123456", 3, 20, 40, "ТЕСТОВЫЙ ТОВАР 2", "метров", "ТЕСТ", "ТЕСТ"])
    wb.save(path)



def make_dummy_sai_xml(path: Path):
    path.write_text("""<?xml version="1.0" encoding="UTF-8"?>
<sai_receipt version="1.0">
  <meta>
    <supplier>ТЕСТ</supplier>
    <date>2026-07-03</date>
    <invoice_number>123</invoice_number>
    <markup_percent>60</markup_percent>
    <currency>RUB</currency>
    <source>ChatGPT</source>
  </meta>
  <items>
    <item row="1">
      <name>ТЕСТОВЫЙ ТОВАР XML</name>
      <quantity>2</quantity>
      <unit>шт.</unit>
      <purchase_price>10.0</purchase_price>
      <sale_price>20.0</sale_price>
      <article>XML-1</article>
      <category>ТЕСТ</category>
      <barcodes>
        <barcode>4006381333931</barcode>
        <barcode>123456</barcode>
      </barcodes>
      <comment>Проверка XML</comment>
    </item>
  </items>
</sai_receipt>
""", encoding="utf-8")


def test_xml_sai_parsing():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        sai = td / "SAI_TEST.xml"
        make_dummy_sai_xml(sai)
        sheet, rows = load_sai_rows(sai)
        assert_equal(sheet, "SAI XML", "XML sheet name")
        assert_equal(len(rows), 1, "XML rows count")
        assert_equal(rows[0]["name"], "ТЕСТОВЫЙ ТОВАР XML", "XML name")
        assert_equal(rows[0]["unit"], "штука", "XML unit normalization")
        assert_equal(rows[0]["barcodes"], ["4006381333931", "123456"], "XML multiple barcodes")
        assert_equal(rows[0]["article"], "XML-1", "XML article")
        assert_equal(rows[0]["category"], "ТЕСТ", "XML category")


def test_sai_package_roundtrip():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        source = td / "invoice.txt"
        source.write_text("Исходная накладная", encoding="utf-8")
        result = sai_converter.ConvertResult(
            source_path=str(source),
            source_type="TEST",
            supplier="ООО ТЕСТ",
            date="2026-07-18",
            invoice_number="PKG-1",
            markup_percent=60,
            items=[sai_converter.ConvertItem(
                row=1, name="ТОВАР PACKAGE", quantity=3, unit="штука",
                purchase_price=100, sale_price=160, article="PKG", category="ТЕСТ",
                barcodes=["4006381333931", "123456"], comment="Проверка пакета",
            )],
        )
        out = td / "SAI_TEST.sai"
        saved = Path(sai_converter.write_sai_package(result, out, source_paths=[source]))
        assert saved.suffix.lower() == ".sai", "Canonical SAI output must use .sai"
        assert sai_package.is_sai_package(saved), "Written file must be recognized as SAI Package"
        with zipfile.ZipFile(saved, "r") as zf:
            names = set(zf.namelist())
            assert "manifest.json" in names, "SAI Package manifest missing"
            assert "data/receipt.json" in names, "SAI Package receipt JSON missing"
            assert "checksums.json" in names, "SAI Package checksums missing"
            assert any(name.startswith("sources/") for name in names), "Original invoice must be embedded"
        sheet, rows = load_sai_rows(saved)
        assert_equal(sheet, "SAI Package", "Package virtual sheet name")
        assert_equal(len(rows), 1, "Package rows count")
        assert_equal(rows[0]["name"], "ТОВАР PACKAGE", "Package item name")
        assert_equal(rows[0]["barcodes"], ["4006381333931", "123456"], "Package barcodes")
        summary = sai_package.read_summary(saved)
        assert_equal(summary["supplier"], "ООО ТЕСТ", "Package supplier")
        assert_equal(summary["source_count"], 1, "Package source count")
        receipt = sai_package.read_receipt(saved)
        receipt["items"][0]["quantity"] = 7
        sai_package.rewrite_receipt(saved, receipt)
        _sheet, updated_rows = load_sai_rows(saved)
        assert_equal(updated_rows[0]["qty"], 7.0, "Package atomic receipt rewrite")
        extracted_dir = td / "sources"
        extracted = sai_package.extract_sources(saved, extracted_dir)
        assert_equal(len(extracted), 1, "Package source extraction")
        assert_equal(extracted[0].read_text(encoding="utf-8"), "Исходная накладная", "Extracted source content")


def make_dummy_log(path: Path):
    headers = [
        "excel_row", "barcode", "used_barcode", "barcode_status", "name", "quantity", "buying_price",
        "incoming_selling_price", "sigma_existing_selling_price", "final_selling_price", "price_source",
        "status", "product_id", "element_id", "message",
    ]
    rows = [
        [2, "4006381333931", "4006381333931", "GTIN_OK", "ТЕСТОВЫЙ ТОВАР 1", 2, 10, 30, 35, 35, "MAX_SIGMA", "OK", "p1", "e1", "processed"],
        [3, "123456", "123456", "INTERNAL_SHORT", "ТЕСТОВЫЙ ТОВАР 2", 3, 20, 40, "", 40, "MAX_INCOMING_NO_SIGMA_PRICE", "OK", "p2", "e2", "processed"],
    ]
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(headers)
        w.writerows(rows)


def test_ndp_generation():
    ensure_runtime_dirs()
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        sai = td / "SAI_TEST.xlsx"
        log = td / "sigma_api_first_test.csv"
        make_dummy_sai(sai)
        make_dummy_log(log)
        out_path, count = create_ndp_file(str(sai), "ТЕСТ", "03.07.2026", log_path=str(log), out_dir=td)
        assert_equal(count, 2, "NDP row count")
        wb = load_workbook(out_path, data_only=False)
        ws = wb.active
        assert_equal(ws.print_area, "'НДП'!$A$1:$F$4" if ws.title == "НДП" else f"'{ws.title}'!$A$1:$F$4", "NDP print area")
        assert str(ws["F1"].value).startswith("=SUMPRODUCT("), "NDP F1 should contain total formula"
        # Critical visual rule: no border between E1 and F1 / label and total.
        assert ws["F1"].border.left.style is None, "F1 left border must be empty"
        assert ws["A1"].border.left.style == "thin", "A1 left border must be visible"
        assert ws["A1"].border.top.style == "thin", "A1 top border must be visible"



def test_ndp_uses_approved_source_price_without_log():
    ensure_runtime_dirs()
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        sai = td / "SAI_APPROVED.xml"
        make_dummy_sai_xml(sai)
        tree = ET.parse(sai)
        tree.getroot().find("./items/item/sale_price").text = "777.77"
        approved_name = 'КРАН ШАР. Д/ВОДЫ 1/2" Г/Ш/Б 1158 AQUALINK'
        tree.getroot().find("./items/item/name").text = approved_name
        tree.write(sai, encoding="utf-8", xml_declaration=True)
        out_path, count = create_ndp_file(str(sai), "ТЕСТ", "17.07.2026", log_path=None, out_dir=td)
        assert_equal(count, 1, "Approved-source NDP row count")
        wb = load_workbook(out_path, data_only=False)
        ws = wb.active
        assert abs(float(ws.cell(3, 5).value) - 777.77) < 0.001, "NDP must use approved source price without CSV override"
        assert_equal(ws.cell(3, 3).value, approved_name, "NDP must preserve operator-approved name literally")
        assert "17.07.2026" in str(ws["B1"].value), "NDP must use current receipt date"


def test_draft_ndp_shows_purchase_and_sale_prices():
    ensure_runtime_dirs()
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        out_path, count = create_ndp_file(
            "",
            "ТЕСТ",
            "31.07.2026",
            out_dir=td,
            rows_override=[{
                "name": "Тестовый товар 125 мл (200) !!!",
                "qty": 2,
                "buy": 100,
                "sale": 165,
            }],
            price_source="buy_and_sale",
        )
        assert_equal(count, 1, "Draft NDP row count")
        wb = load_workbook(out_path, data_only=False)
        ws = wb.active
        assert_equal(ws["E2"].value, "Закупочная", "Draft NDP purchase header")
        assert_equal(ws["F2"].value, "Продажная", "Draft NDP sale header")
        assert_equal(ws["C3"].value, "ТЕСТОВЫЙ ТОВАР 125 МЛ", "Draft NDP seller-facing name")
        assert_equal(float(ws["E3"].value), 100.0, "Draft NDP purchase price")
        assert_equal(float(ws["F3"].value), 165.0, "Draft NDP sale price")
        assert ",F3:F3)" in str(ws["F1"].value), "Draft NDP total must use sale price"


def test_draft_ndp_prefers_catalog_sale_price():
    ensure_runtime_dirs()
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        calls = []

        def catalog_price(row):
            calls.append(row.get("name"))
            return 219

        out_path, count = create_ndp_file(
            "",
            "ТЕСТ",
            "31.07.2026",
            out_dir=td,
            rows_override=[{
                "name": "Товар из черновика",
                "barcodes": ["4601234567893"],
                "qty": 2,
                "buy": 100,
                "sale": 165,
            }],
            price_source="buy_and_sale",
            sale_price_resolver=catalog_price,
        )
        assert_equal(count, 1, "Catalog-price NDP row count")
        wb = load_workbook(out_path, data_only=False)
        ws = wb.active
        assert_equal(float(ws["E3"].value), 100.0, "Catalog lookup must not alter purchase price")
        assert_equal(float(ws["F3"].value), 219.0, "Draft NDP must prefer catalog sale price")
        assert_equal(calls, ["Товар из черновика"], "Catalog resolver must receive the draft row")


def test_import_keeps_category_from_sai():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        sai = td / "SAI_TEST.xlsx"
        make_dummy_sai(sai)
        _, rows = load_sai_rows(sai)
        assert_equal(rows[0]["article"], "ТЕСТ", "SAI article should be read")
        assert_equal(rows[0]["category"], "ТЕСТ", "SAI category should be read")
        assert_equal(rows[0]["unit"], "штука", "SAI unit шт should normalize to штука")
        assert_equal(rows[1]["unit"], "м", "SAI unit метров should normalize to м")
        wb, ws, _ = prepare_sigma_import_workbook(len(rows))
        fill_sigma_import_rows(ws, rows)
        assert_equal(ws.cell(2, 2).value, "ТЕСТ", "SIGMA import should keep article")
        assert_equal(ws.cell(2, 5).value, "ТЕСТ", "SIGMA import should keep category")
        assert_equal(ws.cell(3, 5).value, "ТЕСТ", "SIGMA import should keep category for all rows")
        assert_equal(ws.cell(2, 3).value, "штука", "SIGMA import unit should be canonical штука")
        assert_equal(ws.cell(3, 3).value, "м", "SIGMA import unit should be canonical м")
        assert_equal(ws.cell(2, 7).number_format, "0.0", "SIGMA import price should use one decimal format")
        assert_equal(ws.cell(3, 7).number_format, "0.0", "SIGMA import price should use one decimal format for all rows")
        assert isinstance(ws.cell(2, 7).value, (int, float)), "SIGMA import price should stay numeric, not text"



def test_sigma_import_shared_strings_compatibility():
    import zipfile
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        sai = td / "SAI_TEST.xlsx"
        make_dummy_sai(sai)
        _, rows = load_sai_rows(sai)
        wb, ws, _ = prepare_sigma_import_workbook(len(rows))
        fill_sigma_import_rows(ws, rows)
        out = td / "Импорт_TEST.xlsx"
        wb.save(out)
        make_xlsx_sigma_compatible(out)
        with zipfile.ZipFile(out, "r") as z:
            names = set(z.namelist())
            assert "xl/sharedStrings.xml" in names, "SIGMA import XLSX should contain sharedStrings.xml"
            sheet_xml = z.read("xl/worksheets/sheet1.xml").decode("utf-8")
            assert 't="inlineStr"' not in sheet_xml, "SIGMA import XLSX must not contain inlineStr cells"
            assert 't="s"' in sheet_xml, "SIGMA import XLSX should use shared string cells"
            assert "/xl/sharedStrings.xml" in z.read("[Content_Types].xml").decode("utf-8"), "sharedStrings content type required"
            assert "sharedStrings" in z.read("xl/_rels/workbook.xml.rels").decode("utf-8"), "sharedStrings relationship required"


def test_duplicate_article_warning():
    rows = [
        {"article": "ТЕСТ", "name": "А"},
        {"article": "ТЕСТ", "name": "Б"},
        {"article": "", "name": "В"},
    ]
    warnings = duplicate_article_warnings(rows)
    assert_equal(warnings[0]["article"], "ТЕСТ", "duplicate article warning article")
    assert_equal(warnings[0]["count"], 2, "duplicate article warning count")


def test_exact_name_duplicate_guard():
    rows = [
        {"excel_row": 2, "name": "МОНОФОСФАТ КАЛИЯ 20 Г", "barcodes": ["4603388535490"], "qty": 1, "buy": 10, "sale": 20, "article": "ТЕСТ", "category": "ТЕСТ"},
    ]
    catalog = {
        "codes": set(),
        "product_count": 1,
        "strategy": "test",
        "code_to_products": {},
        "products_by_id": {
            "p-mono": {"id": "p-mono", "name": "МОНОФОСФАТ КАЛИЯ 20 Г", "vendor_code": "", "barcodes": [], "raw": {"id": "p-mono", "items": [{"barcodes": []}]}}
        },
    }
    result = analyze_multi_barcode_rows(rows, catalog, exact_name_guard=True)
    assert_equal(len(result["missing"]), 0, "exact name duplicate should not go to import")
    assert_equal(len(result["add_needed"]), 1, "exact name duplicate should request barcode add")
    assert_equal(result["add_needed"][0]["match_reason"], "exact_name", "exact name match reason")
    assert_equal(result["add_needed"][0]["missing_codes"], ["4603388535490"], "exact name missing barcode")

    duplicate_rows = [{
        "excel_row": 20,
        "name": 'КЛАПАН ВПУСКНОЙ НИЖНИЙ ПОДВОД (1/60) "ИНКОЭР" НпрНРФ Р',
        "barcodes": ["4607129333673"],
        "qty": 1,
        "buy": 100,
        "sale": 160,
        "article": "",
        "category": "",
    }]
    duplicate_catalog = {
        "codes": {"4607129333673"},
        "product_count": 2,
        "strategy": "test",
        "products_by_id": {},
        "code_to_products": {
            "4607129333673": {
                "wrong": {
                    "id": "wrong",
                    "name": 'Клапан наполнительный нижний 1/2" и-нпрнрф',
                    "barcodes": ["4607129333673"],
                },
                "right": {
                    "id": "right",
                    "name": 'КЛАПАН ВПУСКНОЙ НИЖНИЙ ПОДВОД (1/60) "ИНКОЭР" НпрНРФ Р',
                    "barcodes": ["4607129333673"],
                },
            },
        },
    }
    resolved = analyze_multi_barcode_rows(duplicate_rows, duplicate_catalog)
    assert_equal(len(resolved["conflicts"]), 0, "unique exact name must resolve duplicate barcode")
    assert_equal(len(resolved["ok_full"]), 1, "resolved duplicate barcode row must be ready")
    assert_equal(
        resolved["resolved_name_conflicts"][0]["product"]["id"],
        "right",
        "exact-name product must win duplicate barcode tie",
    )
    ambiguous_catalog = copy.deepcopy(duplicate_catalog)
    ambiguous_catalog["code_to_products"]["4607129333673"]["right"]["name"] = "ЕЩЁ ОДИН ТОВАР"
    manually_resolved = analyze_multi_barcode_rows(
        duplicate_rows,
        ambiguous_catalog,
        conflict_resolutions={
            barcode_conflict_resolution_key(duplicate_rows[0]): {"product_id": "right"},
        },
    )
    assert_equal(len(manually_resolved["conflicts"]), 0, "saved operator choice must resolve duplicate")
    assert_equal(
        manually_resolved["resolved_manual_conflicts"][0]["product"]["id"],
        "right",
        "saved operator product must win duplicate barcode tie",
    )


def test_sqlite_catalog_and_history():
    ensure_runtime_dirs()
    catalog = {
        "codes": {"4006381333931", "123456"},
        "product_count": 2,
        "strategy": "test",
        "products_by_id": {
            "p1": {"id": "p1", "name": "ТЕСТОВЫЙ ТОВАР 1", "vendor_code": "A1", "barcodes": ["4006381333931"], "raw": {"id": "p1"}},
            "p2": {"id": "p2", "name": "ТЕСТОВЫЙ ТОВАР 2", "vendor_code": "A2", "barcodes": ["123456"], "raw": {"id": "p2"}},
        },
        "code_to_products": {},
    }
    counters = sai_db.save_catalog(catalog, "company-test", "sellpoint-test", app_version="test")
    assert_equal(counters["product_count"], 2, "SQLite catalog product count")
    loaded = sai_db.load_catalog("company-test", "sellpoint-test")
    assert loaded, "SQLite catalog should load"
    assert "4006381333931" in loaded["codes"], "SQLite catalog should keep barcode"
    assert_equal(loaded["code_to_products"]["123456"]["p2"]["name"], "ТЕСТОВЫЙ ТОВАР 2", "SQLite barcode lookup")

    rows = [
        {"excel_row": 2, "name": "ТЕСТОВЫЙ ТОВАР 1", "barcodes": ["4006381333931"], "qty": 2, "buy": 10, "sale": 30, "article": "A1", "category": "ТЕСТ"},
        {"excel_row": 3, "name": "ТЕСТОВЫЙ ТОВАР 3", "barcodes": ["777777"], "qty": 1, "buy": 20, "sale": 40, "article": "A3", "category": "ТЕСТ"},
    ]
    result = {
        "total": 2, "ok_full": 1, "missing": 1, "no_barcode": 0, "barcode_add_needed": 0, "conflicts": 0,
        "import_path": "Импорт_TEST.xlsx", "barcode_update_path": "",
        "missing_rows": [rows[1]], "no_barcode_rows": [], "barcode_add_rows": [], "conflict_rows": [],
    }
    rid = sai_db.save_receipt_check("SAI_TEST.xlsx", "ТЕСТ", "03.07.2026", rows, result)
    assert rid > 0, "SQLite receipt history id"
    latest = sai_db.latest_receipt_summary(limit=1)
    assert latest and latest[0]["id"] == rid, "SQLite latest receipt"
    assert_equal(latest[0]["status"], "import_required", "SQLite receipt status")

    # v1.18: APPLY logs are stored as price history and can warn on later changes.
    import csv
    from sai_runtime_paths import LOGS_DIR
    log_path = LOGS_DIR / "sigma_api_first_test_history.csv"
    with open(log_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "excel_row", "barcode", "used_barcode", "barcode_status", "name", "quantity",
            "buying_price", "incoming_selling_price", "sigma_existing_selling_price",
            "final_selling_price", "price_source", "status", "product_id", "element_id", "message",
        ], delimiter=";")
        writer.writeheader()
        writer.writerow({
            "excel_row": 2, "barcode": "4006381333931", "used_barcode": "4006381333931",
            "barcode_status": "EAN-13", "name": "ТЕСТОВЫЙ ТОВАР 1", "quantity": 2,
            "buying_price": 10, "incoming_selling_price": 30, "sigma_existing_selling_price": "",
            "final_selling_price": 30, "price_source": "incoming", "status": "OK",
            "product_id": "p1", "element_id": "e1", "message": "processed",
        })
    saved = sai_db.record_apply_log(log_path, "SAI_TEST.xlsx", "ТЕСТ", "03.07.2026", "waybill-test", app_version="test")
    assert saved["apply_run_id"] > 0, "SQLite apply history id"
    assert_equal(saved["ok_count"], 1, "SQLite apply OK count")
    assert_equal(saved["total_quantity"], 2.0, "SQLite total receipt quantity")
    successful = sai_db.successful_apply_runs(limit=10)
    assert successful and successful[0]["id"] == saved["apply_run_id"], "Successful receipt history should list only completed APPLY"
    failed_log = LOGS_DIR / "sigma_api_first_failed_history.csv"
    with open(failed_log, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "excel_row", "barcode", "used_barcode", "barcode_status", "name", "quantity",
            "buying_price", "incoming_selling_price", "sigma_existing_selling_price",
            "final_selling_price", "price_source", "status", "product_id", "element_id", "message",
        ], delimiter=";")
        writer.writeheader()
        writer.writerow({
            "excel_row": 2, "barcode": "999", "used_barcode": "999", "name": "ОШИБОЧНЫЙ ТОВАР",
            "quantity": 1, "buying_price": 1, "incoming_selling_price": 2, "final_selling_price": 2,
            "status": "ERROR", "message": "not found",
        })
    failed_saved = sai_db.record_apply_log(failed_log, "SAI_FAILED.xlsx", "ТЕСТ", "03.07.2026", "waybill-failed", app_version="test")
    visible_ids = {row["id"] for row in sai_db.successful_apply_runs(limit=20)}
    assert failed_saved["apply_run_id"] not in visible_ids, "Failed APPLY must not appear in receipt history"
    source_invoice = LOGS_DIR / "Входная накладная тест.pdf"
    source_invoice.write_bytes(b"%PDF-1.4\nSAI TEST")
    sai_file_for_archive = LOGS_DIR / "SAI_TEST_ARCHIVE.xml"
    make_dummy_sai_xml(sai_file_for_archive)
    sai_receipt_archive.write_source_sidecar(sai_file_for_archive, [source_invoice])
    archive_dir = sai_receipt_archive.archive_successful_receipt(
        saved["apply_run_id"], sai_file_for_archive, log_path=log_path
    )
    assert archive_dir.is_dir(), "Receipt archive folder should be created"
    archived_files = sai_db.receipt_files(saved["apply_run_id"])
    kinds = {row["kind"] for row in archived_files}
    assert "sai" in kinds and "source" in kinds and "service_log" in kinds, "Receipt archive should keep SAI, source invoice and log"
    ndp_dummy = LOGS_DIR / "НДП_TEST.xlsx"
    ndp_dummy.write_bytes(b"test")
    sai_receipt_archive.archive_generated_document(saved["apply_run_id"], "ndp", ndp_dummy)
    assert any(row["kind"] == "ndp" for row in sai_db.receipt_files(saved["apply_run_id"])), "NDP should attach to receipt history"

    stats = sai_db.price_history_stats()
    assert stats["price_rows"] >= 1, "SQLite price history rows"
    warnings = sai_db.price_warnings_for_rows([
        {"name": "ТЕСТОВЫЙ ТОВАР 1", "barcodes": ["4006381333931"], "buy": 13, "sale": 40}
    ], buy_threshold_pct=10, sale_threshold_pct=10)
    assert warnings, "SQLite price warning should detect noticeable changes"


def test_hub_artifacts():
    from pathlib import Path
    from sai_version import APP_VERSION, VERSION, RELEASE_CHANNEL, DEVELOPMENT_REVISION
    app_dir = Path(__file__).resolve().parent
    root_dir = app_dir.parent
    assert RELEASE_CHANNEL in ("development", "production")
    expected = f"v{VERSION}-dev.{DEVELOPMENT_REVISION}" if RELEASE_CHANNEL == "development" else f"v{VERSION}"
    assert APP_VERSION == expected, "Unexpected SAI version"
    pyside_text = (Path(__file__).parent / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    assert "def route_sai_file" in pyside_text, "Every SAI file must use guarded workflow routing"
    assert "self.parent_page.route_sai_file(Path(path))" in pyside_text, "AI continue must use guarded routing"
    assert "def save_sai_to_desktop" in pyside_text, "AI continue must auto-save the SAI package"
    assert "sai_receipt_drafts.save_result" in pyside_text, "AI package must be saved in the internal draft store"
    assert "self.continue_btn.setVisible(False)" in pyside_text, "Continue button must stay hidden before AI result"
    assert "sai_package.read_package(path, verify_integrity=True)" in pyside_text, "Supplier must come from SAI Package metadata"
    assert "def supplier_match_index" in pyside_text, "Supplier auto-selection must use safe matching"
    assert (app_dir / "sai_pyside_preview.py").exists(), "PySide6 Hub entry file should exist"
    assert (app_dir / "sai_launcher.py").exists(), "Reliable Hub launcher should exist"
    assert (app_dir / "sai_invoice_ai_pipeline.py").exists(), "Invoice AI pipeline state module should exist"
    assert (app_dir / "sai_invoice_ai_telemetry.py").exists(), "Invoice AI telemetry module should exist"
    assert (app_dir / "sai_notifications.py").exists(), "Unified notification module should exist"
    assert (app_dir / "sai_receipt_drafts.py").exists(), "Internal receipt draft module should exist"
    assert (app_dir / "sai_manual_receipt.py").exists(), "Manual receipt application service should exist"
    assert (app_dir / "sai_semi_auto.py").exists(), "Semi-auto application service should exist"
    assert (app_dir / "sai_core_v2" / "semi_auto_receipt.py").exists(), "Semi-auto core rules should exist"
    assert (app_dir / "sai_core_v2" / "manual_receipt.py").exists(), "Manual receipt domain core should exist"
    assert "from sai_manual_receipt import ManualReceiptService" in pyside_text, "Manual receipt UI must use the service boundary"
    assert "from sai_notifications import CatalogStatusBadge, NotificationCenter, QMessageBox" in pyside_text, "Hub must use unified notification facade"
    assert (app_dir / "run_invoice_ai_pipeline_tests.py").exists(), "Stable Invoice AI pipeline regression should exist"
    assert (app_dir / "run_sai_hub.cmd").exists(), "Hub console runner should exist"
    assert (root_dir / "Запустить SAI Hub.vbs").exists(), "Hub VBS launcher should exist"
    assert not (app_dir / "app").exists(), "Obsolete duplicate app/app must be removed"
    pyside_text = (app_dir / "sai_pyside_preview.py").read_text(encoding="utf-8")
    receipt_hub_text = (app_dir / "sai_receipt_hub.py").read_text(encoding="utf-8")
    classic_text = (app_dir / "sai_app.py").read_text(encoding="utf-8")
    vbs_text = read_text_auto(root_dir / "Запустить SAI Hub.vbs")
    assert "from sai_version import APP_VERSION" in pyside_text, "Hub should use shared version"
    assert "from sai_version import APP_VERSION" in classic_text, "Classic core should use shared version"
    assert "sai_launcher.py" in vbs_text, "VBS should use reliable launcher"
    assert "StableRailButton" in pyside_text, "PySide6 Hub should use stable SVG rail buttons"
    assert "Исправлено — проверить и продолжить" in pyside_text, "Barcode conflict must have a continuation action"
    assert "Подготовить накладную на согласование" in pyside_text, "Price approval flow must exist"
    assert 'QPushButton("Ввести приход")' in pyside_text, "Direct APPLY action must be available"
    assert pyside_text.count('price_policy = "max"') >= 2, "Every APPLY path must keep the highest SAI/SIGMA price"
    assert 'policy = "max"' in pyside_text, "Price approval must always compare SAI and SIGMA prices"
    assert "def synchronize_final_prices_from_apply" in pyside_text, "Final APPLY prices must be synchronized"
    assert 'QPushButton("Печатать НДП и Ценники")' in pyside_text, "Only final print action must exist"
    assert "source_for_docs = self.final_document_source()" in pyside_text, "NDP must use one approved canonical source"
    assert "validate_ndp_against_source" in pyside_text, "NDP prices must be verified against approved source"
    assert "print_price_tags_a4(tag_items, tags_printer)" in pyside_text, "Price tags must print directly through the configured A4 printer"
    assert "Цена SAI" in pyside_text and "Цена SIGMA" in pyside_text and "Утвержд." in pyside_text, "Price comparison columns must exist"
    doctor_text = (app_dir / "sai_doctor.py").read_text(encoding="utf-8")
    assert "from sai_version import APP_VERSION" in doctor_text, "Doctor must use shared SAI version"
    assert "Версия SAI" in doctor_text, "Doctor must display installed SAI version"
    assert "История приходов" in pyside_text, "Successful receipt archive UI must exist"
    assert "Товаров всего" in pyside_text, "History must show total quantity matching SIGMA"
    assert 'setPlaceholderText("Найти товар по названию, ШК или поставщику")' in pyside_text, "History must search products and suppliers"
    assert 'row.get("history_matches")' in pyside_text, "History search must expose matching product lines"
    history_ui = pyside_text[pyside_text.find('history_title = QLabel("История приходов")'):pyside_text.find('self.price_tags_page = PriceTagsPage')]
    assert 'QPushButton("Обновить")' not in history_ui, "History refresh button must be removed"
    assert 'QPushButton("Открыть приход")' not in pyside_text, "Large history open button must be removed"
    assert 'QPushButton("Удалить запись")' not in pyside_text, "Large history delete button must be removed"
    assert 'QPushButton("Открыть папку истории")' not in pyside_text, "History root-folder button must be removed"
    assert 'HistoryDeleteButton' in pyside_text and 'delete_receipt_by_id' in pyside_text, "Each history row must have a delete cross"
    assert 'class HistoryDeleteButton(QPushButton)' in pyside_text, "History delete cross must use stable custom painting"
    assert 'delete_cell.setObjectName("HistoryDeleteCell")' in pyside_text, "History delete cell must remain transparent"
    assert 'painter.drawEllipse(QRectF(1.0, 1.0, 24.0, 24.0))' in pyside_text, "Delete hover circle must be centered"
    scrollbar_styles = (app_dir / "sai_legacy_styles.py").read_text(encoding="utf-8-sig")
    assert 'width: 7px;' in scrollbar_styles and 'QScrollBar::groove:vertical' in scrollbar_styles, "Night scrollbar must be slim and groove-free"
    assert 'QScrollBar::up-arrow:vertical' in scrollbar_styles, "Scrollbar arrow artifacts must be disabled"
    assert 'self.history_table.setTextElideMode(Qt.TextElideMode.ElideNone)' in pyside_text, "Supplier names must not be shortened with ellipsis"
    assert 'self.history_table.setWordWrap(True)' in pyside_text, "Long supplier names must wrap in History"
    assert 'Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter' in pyside_text, "Supplier names must be vertically centered"
    assert 'delete_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)' in pyside_text, "Delete cross must be centered in its row"
    assert 'table.setRowHeight(row_index, max(46, table.rowHeight(row_index)))' in pyside_text, "History rows must keep a stable minimum height"
    assert 'auto_refresh_history' in pyside_text, "History must refresh automatically"
    assert 'def make_standard_page_header' in pyside_text, "Top-level pages must share one header component"
    assert pyside_text.count('make_standard_page_header(') >= 4, "History, price tags and settings must use the shared header"
    assert '"История",\n            "Успешно введённые приходы' in pyside_text, "History must have a concise standard description"
    assert '"Ценники",\n            "Быстро найди товар' in pyside_text, "Price tags must have a concise standard description"
    assert '"Настройки",\n            "Подключение SIGMA' in pyside_text, "Settings must have a concise standard description"
    assert 'class ThemeModeSelector' in pyside_text, "Theme selector must exist"
    assert '("day", "Светлая тема")' in pyside_text and '("night", "Тёмная тема")' in pyside_text, "Only light and dark theme choices must remain"
    assert 'self.theme_time_edit' not in pyside_text, "Timed theme controls must be removed"
    assert 'class AutoThemeController' in pyside_text, "Application theme controller must exist"
    assert 'self.mode == THEME_MODE_NIGHT' in pyside_text, "Theme controller must use a fixed user choice"
    assert 'class DraftsTileButton' in receipt_hub_text and 'DraftCountBadge' in receipt_hub_text, "Draft counter badge must exist"
    assert 'Составить накладную вручную' in pyside_text, "Manual receipt action must use the approved title"
    assert 'DARK_STYLESHEET' in pyside_text, "Dark stylesheet must exist"
    assert 'app._sai_theme_controller = AutoThemeController(app)' in pyside_text, "Automatic theme must be active for the whole app"
    assert "Последние проверки" not in pyside_text, "Diagnostic receipt checks must be removed from History UI"
    assert "История цен" not in pyside_text, "Global price-history tab must be removed"
    assert "def delete_selected_receipt" in pyside_text, "History records must be deletable"
    assert "sai_receipt_archive.archive_successful_receipt" in pyside_text, "Successful receipts must archive related files"
    assert (app_dir / "sai_openai_invoice.py").exists(), "OpenAI invoice module must exist"
    assert (app_dir / "sai_package.py").exists(), "SAI Package module must exist"
    ai_prompt = root_dir / "config" / "ai" / "invoice_prompt_v1.txt"
    ai_schema = root_dir / "config" / "ai" / "invoice_schema_v1.json"
    assert ai_prompt.is_file(), "External AI prompt must exist"
    assert ai_schema.is_file(), "External AI schema must exist"
    assert "SAI_INVOICE_PROMPT_VERSION: invoice_prompt_v1" in ai_prompt.read_text(encoding="utf-8"), "AI prompt version marker"
    assert json.loads(ai_schema.read_text(encoding="utf-8"))["type"] == "object", "AI schema must be valid JSON"
    package_text = (app_dir / "sai_package.py").read_text(encoding="utf-8")
    converter_text = (app_dir / "sai_converter.py").read_text(encoding="utf-8")
    app_text = (app_dir / "sai_app.py").read_text(encoding="utf-8")
    sigma_text = (app_dir / "sigma_autoprihod.py").read_text(encoding="utf-8")
    assert 'FORMAT_ID = "com.sai.ecosystem.package"' in package_text, "SAI Package format ID must be stable"
    assert 'SCHEMA_VERSION = "1.0"' in package_text, "SAI Package schema must be versioned"
    assert 'def rewrite_receipt' in package_text, "SAI Package must support atomic updates"
    assert 'write_sai_package' in converter_text and '.sai"' in converter_text, "New converter outputs must use .sai"
    assert 'suffix == ".sai"' in app_text, "Core SAI reader must support .sai"
    assert 'lower.endswith(".sai")' in sigma_text, "SIGMA APPLY reader must support .sai"
    assert 'sai_receipt_drafts.save_result' in pyside_text, "AI invoices must create internal SAI draft packages"
    assert '"НОВЫЙ ПРИВОЗ"' in pyside_text, "Receipt hub must expose the new AI-first receipt action"
    assert 'app.installEventFilter(self)' in pyside_text, "AI invoice page must accept drops across the SAI window"
    assert 'self.drop_overlay.setGeometry(host.rect())' in pyside_text, "Invoice drop must show a full-window overlay"
    assert 'class DropPlusIndicator(QWidget):' in pyside_text, "Drag-and-drop plus must use exact custom painting"
    assert 'plus = DropPlusIndicator()' in pyside_text, "Drag-and-drop overlay must use centred plus indicator"
    assert 'QTableWidget QHeaderView::section:first' not in pyside_text, "Table headers must not punch transparent corner holes"
    assert 'self.set_source_paths(paths)' in pyside_text, "Dropped invoices must use the normal source workflow"
    assert 'Предпросмотр для сканера' not in pyside_text, "Price tags must not show the scanner barcode preview"
    styles_text = (app_dir / "sai_legacy_styles.py").read_text(encoding="utf-8-sig")
    assert 'QLabel#StartupTitle' in styles_text and 'QPushButton#StartupSecondary' in styles_text, "First-run night theme selectors must exist"
    assert 'self.content_stack.setCurrentIndex(7)' in pyside_text, "AI invoice page must be reachable"
    assert 'self.openai_key_edit' not in pyside_text, "User settings must not edit the OpenAI API key"
    assert 'self.openai_model_edit' not in pyside_text and 'self.openai_proxy_edit' not in pyside_text, "USER must not contain ChatGPT settings"
    assert 'AccountService().effective_owner_ai_configuration()' in pyside_text, "Invoice AI must use all settings from SAI Admin"
    openai_text = (app_dir / "sai_openai_invoice.py").read_text(encoding="utf-8")
    assert 'FINAL_LINE_TOTAL_POLICY = "final_line_total_including_vat_and_discounts"' in openai_text, "Final row amount must be the price source of truth"
    assert 'document_total' in openai_text, "AI contract must include document total"
    assert 'сумма строки / количество' in openai_text, "AI price basis must be visible"
    assert 'confirm_critical_result' in pyside_text, "Critical AI discrepancies must require explicit confirmation"



def test_openai_invoice_module():
    import json
    import sai_openai_invoice

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        source = td / "invoice.txt"
        source.write_text("Накладная ТЕСТ: товар 2 шт по 10 руб", encoding="utf-8")
        payload = sai_openai_invoice.build_request_payload([source], model="gpt-test")
        assert_equal(payload["model"], "gpt-test", "OpenAI invoice model")
        content = payload["input"][0]["content"]
        assert any(part.get("type") == "input_file" for part in content), "Invoice text file must be sent as input_file"
        assert payload["text"]["format"]["type"] == "json_schema", "Invoice extraction must use Structured Outputs"
        assert_equal(payload["reasoning"]["effort"], "low", "Economical reasoning effort")
        assert_equal(payload["text"]["verbosity"], "low", "Economical response verbosity")
        assert payload["max_output_tokens"] <= 20000, "AI output must have a cost guard"
        assert_equal(sai_openai_invoice.economical_model("gpt-5.6"), "gpt-5.6-luna", "Legacy Sol/default model migration")
        assert_equal(sai_openai_invoice.economical_model("gpt-custom"), "gpt-custom", "Unknown custom model must be preserved")
        contract = sai_openai_invoice.invoice_contract_metadata()
        assert_equal(contract["prompt_version"], sai_openai_invoice.PROMPT_VERSION, "External AI prompt version")
        assert_equal(contract["schema_version"], sai_openai_invoice.SCHEMA_VERSION, "External AI schema version")
        assert len(contract["prompt_sha256"]) == 64 and len(contract["schema_sha256"]) == 64, "AI contract hashes"
        instruction = next(part["text"] for part in content if part.get("type") == "input_text")
        assert "Оператор не указал подсказки" in instruction, "Operator hints must be rendered into external prompt"
        result_doc = {
            "supplier": "ООО ТЕСТ",
            "invoice_date": "2026-07-18",
            "invoice_number": "77",
            "currency": "RUB",
            "document_total": 20,
            "document_total_note": "",
            "items": [{
                "raw_name": "Товар тестовый (16/100)",
                "name": "Товар тестовый (16/100)",
                "quantity": 2,
                "unit": "шт.",
                "purchase_price": 10,
                "line_total": 20,
                "article": "A-1",
                "barcodes": ["4601234567893"],
                "confidence": 0.95,
                "note": "",
            }],
            "warnings": [],
        }
        response = {
            "usage": {
                "input_tokens": 10000,
                "input_tokens_details": {"cached_tokens": 1000},
                "output_tokens": 2000,
                "output_tokens_details": {"reasoning_tokens": 300},
                "total_tokens": 12000,
            },
            "output": [{
                "type": "message",
                "content": [{"type": "output_text", "text": json.dumps(result_doc, ensure_ascii=False)}],
            }]
        }
        converted = sai_openai_invoice.response_to_convert_result(response, [source], markup_percent=60, model="gpt-5.6-luna")
        assert_equal(converted.supplier, "ООО ТЕСТ", "AI supplier")
        assert_equal(len(converted.items), 1, "AI item count")
        assert_equal(converted.items[0].raw_name, "Товар тестовый (16/100)", "Literal source name")
        assert_equal(converted.items[0].name, "ТОВАР ТЕСТОВЫЙ", "AI product name cleaning")
        assert_equal(converted.items[0].unit, "штука", "AI unit normalization")
        assert_equal(converted.items[0].sale_price, 16.0, "AI sale price calculation")
        assert_equal(converted.items[0].barcodes, ["4601234567893"], "AI barcode extraction")
        assert_equal(converted.items[0].purchase_price, 10.0, "Final line total must define purchase price")
        assert_equal(converted.items[0].purchase_price_source, "сумма строки / количество", "AI purchase price source")
        assert_equal(converted.validation.get("price_from_line_total"), 1, "AI line-total price count")
        assert_equal(converted.validation["ai_contract"]["prompt_version"], sai_openai_invoice.PROMPT_VERSION, "AI contract must be persisted")
        assert_equal(converted.validation["openai_usage"]["total_tokens"], 12000, "AI usage must be persisted")
        assert abs(float(converted.validation["estimated_cost_usd"]) - 0.0211) < 0.000001, "AI cost calculation"
        assert_equal(converted.critical_issues, [], "Matching document total must not be critical")

        mismatch_doc = dict(result_doc)
        mismatch_doc["document_total"] = 25
        mismatch_response = {
            "output": [{
                "type": "message",
                "content": [{"type": "output_text", "text": json.dumps(mismatch_doc, ensure_ascii=False)}],
            }]
        }
        mismatch = sai_openai_invoice.response_to_convert_result(mismatch_response, [source], markup_percent=60)
        assert mismatch.critical_issues, "Document total mismatch must require explicit review"

        price_conflict_doc = dict(result_doc)
        price_conflict_doc["items"] = [dict(result_doc["items"][0], purchase_price=7, line_total=20)]
        conflict_response = {
            "output": [{
                "type": "message",
                "content": [{"type": "output_text", "text": json.dumps(price_conflict_doc, ensure_ascii=False)}],
            }]
        }
        conflict = sai_openai_invoice.response_to_convert_result(conflict_response, [source], markup_percent=60)
        assert_equal(conflict.items[0].purchase_price, 10.0, "Printed price must not override final row amount")
        assert not any("напечатанная цена" in issue for issue in conflict.items[0].issues), "Pre-VAT printed price must not create a false alarm"
        assert_equal(conflict.validation["printed_price_mismatch_info"], 1, "Printed mismatch remains auditable")

        invalid_doc = dict(result_doc)
        invalid_doc["items"] = [dict(result_doc["items"][0], barcodes=["4601234567890"])]
        invalid_response = {
            "output": [{
                "type": "message",
                "content": [{"type": "output_text", "text": json.dumps(invalid_doc, ensure_ascii=False)}],
            }]
        }
        invalid = sai_openai_invoice.response_to_convert_result(invalid_response, [source], markup_percent=60)
        assert_equal(invalid.items[0].barcodes, [], "Invalid GTIN must not be trusted")
        assert any("контрольную цифру" in issue for issue in invalid.items[0].issues), "Invalid GTIN must require scanning"
        assert_equal(invalid.validation["invalid_barcode_count"], 1, "Invalid barcode count")




def test_direct_network_mode():
    import os
    import requests
    from sai_direct_network import configure_direct_network, direct_chromium_args

    configure_direct_network()
    assert os.environ.get("NO_PROXY") == "*"
    assert os.environ.get("no_proxy") == "*"
    session = requests.Session()
    assert session.trust_env is False
    assert "--no-proxy-server" in direct_chromium_args()
    assert "--proxy-bypass-list=*" in direct_chromium_args()
    print("OK: direct SIGMA network mode")

def main():
    test_direct_network_mode()
    try:
        test_core_helpers()
        test_unit_normalization()
        test_ndp_generation()
        test_ndp_uses_approved_source_price_without_log()
        test_draft_ndp_shows_purchase_and_sale_prices()
        test_draft_ndp_prefers_catalog_sale_price()
        test_import_keeps_category_from_sai()
        test_sigma_import_shared_strings_compatibility()
        test_xml_sai_parsing()
        test_sai_package_roundtrip()
        test_duplicate_article_warning()
        test_exact_name_duplicate_guard()
        test_sqlite_catalog_and_history()
        test_openai_invoice_module()
        test_hub_artifacts()
        print("OK: SAI self tests passed")
        print(f"Runtime logs dir: {LOGS_DIR}")
        print(f"Runtime SQLite DB: {DB_PATH}")
    finally:
        # On Windows SQLite/antivirus may briefly retain a handle. Cleanup is best-effort
        # and must never turn a successful or useful failed test into a second traceback.
        gc.collect()
        shutil.rmtree(_TEST_RUNTIME, ignore_errors=True)


if __name__ == "__main__":
    main()
