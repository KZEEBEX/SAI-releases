"""Offline component gallery: python app/sai_design_showcase.py."""
from PySide6.QtWidgets import QApplication, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QTableWidget, QTableWidgetItem, QFrame
from sai_ui_components import button, field, set_state, TableEditButton
from sai_ui_style import ui_polish_stylesheet


def create_showcase():
    page = QDialog()
    page.setProperty("saiRole", "dialog")
    page.setWindowTitle("SAI · Дизайн-система")
    page.resize(920, 640)
    layout = QVBoxLayout(page)
    layout.setContentsMargins(24, 24, 24, 24)
    layout.setSpacing(16)
    title = QLabel("SAI · Библиотека интерфейса")
    title.setObjectName("WarehousePageTitle")
    layout.addWidget(title)
    layout.addWidget(QLabel("Общие компоненты · светлая и тёмная темы · состояния и размеры"))
    actions = QHBoxLayout()
    for text, role in (("Главное действие", "hero"), ("Обычная кнопка", "secondary"), ("Удалить", "danger")):
        actions.addWidget(button(text, role))
    disabled = button("Недоступно", "hero")
    disabled.setEnabled(False)
    actions.addWidget(disabled)
    actions.addWidget(TableEditButton())
    layout.addLayout(actions)
    inputs = QHBoxLayout()
    edit = field()
    edit.setPlaceholderText("Название / ШК / артикул")
    inputs.addWidget(edit)
    invalid = field("Некорректное значение")
    set_state(invalid, "error")
    inputs.addWidget(invalid)
    combo = QComboBox()
    combo.setObjectName("WorkbenchCombo")
    combo.addItems(["Выберите поставщика", "Поставщик 1"])
    inputs.addWidget(combo)
    layout.addLayout(inputs)
    card = QFrame()
    card.setObjectName("MetricCard")
    card_layout = QVBoxLayout(card)
    card_layout.addWidget(QLabel("Карточка · единая рамка и скругление"))
    card_layout.addWidget(QLabel("Важное действие выделено цветом. Остальные элементы спокойные."))
    layout.addWidget(card)
    table = QTableWidget(3, 4)
    table.setHorizontalHeaderLabels(["Товар", "Штрихкод", "Цена SIGMA", ""])
    table.verticalHeader().hide()
    table.setColumnWidth(0, 400)
    table.setColumnWidth(1, 230)
    table.setColumnWidth(2, 125)
    for row in range(3):
        table.setItem(row, 0, QTableWidgetItem(f"Товар для проверки интерфейса {row + 1}"))
        table.setItem(row, 1, QTableWidgetItem("04600000000001"))
        table.setItem(row, 2, QTableWidgetItem("125,00"))
        table.setCellWidget(row, 3, TableEditButton())
        table.setRowHeight(row, 42)
    layout.addWidget(table, 1)
    return page


if __name__ == "__main__":
    app = QApplication([])
    app.setStyleSheet(ui_polish_stylesheet(False))
    page = create_showcase()
    page.show()
    app.exec()
