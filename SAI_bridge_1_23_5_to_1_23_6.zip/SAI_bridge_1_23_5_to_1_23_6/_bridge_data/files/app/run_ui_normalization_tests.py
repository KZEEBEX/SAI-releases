#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for v1.22.7bf normalized shell and controls."""
from __future__ import annotations

import ast
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
UI = APP / "sai_pyside_preview.py"
STYLE = APP / "sai_ui_style.py"
NOTIFICATIONS = APP / "sai_notifications.py"


def static_tests() -> None:
    ui = UI.read_text(encoding="utf-8-sig")
    style = STYLE.read_text(encoding="utf-8-sig")
    notifications = NOTIFICATIONS.read_text(encoding="utf-8-sig")
    ast.parse(ui, filename=str(UI))
    ast.parse(style, filename=str(STYLE))
    ast.parse(notifications, filename=str(NOTIFICATIONS))

    assert "from sai_ui_style import ui_polish_stylesheet" in ui
    assert "+ ui_polish_stylesheet(dark)" in ui
    assert 'brand = QLabel(f"SAI  ·  {APP_VERSION}", self)' in ui
    assert "version.setVisible(False)" in ui
    assert "CompositionMode_SourceIn" in ui
    assert "QTimer.singleShot(0, self.refresh_theme)" in ui
    assert "class SettingsDisclosureButton" in ui
    assert 'thermal_settings_expanded' in ui
    assert 'self.thermal_body.setObjectName("SettingsDisclosureBody")' in ui
    assert "QScrollBar::handle:vertical" in style
    assert "background: {canvas}" in style
    assert "QFrame#Rail" in style
    assert "QPushButton#SettingsDisclosureButton" in style
    assert "TextInteractionFlag.NoTextInteraction" in notifications
    assert 'body.setObjectName("NotificationBody")' in notifications
    assert "body_layout.setContentsMargins(6, 2, 2, 2)" in notifications


def runtime_tests() -> None:
    from PySide6.QtCore import QEvent, QPointF, Qt
    from PySide6.QtGui import QEnterEvent
    from PySide6.QtWidgets import QApplication, QLabel, QScrollArea

    sys.path.insert(0, str(APP))
    from sai_notifications import NotificationToast
    from sai_pyside_preview import (
        DARK_STYLESHEET,
        STYLESHEET,
        FramelessTitleBar,
        MainPage,
        RailIconButton,
    )
    from sai_ui_style import ui_polish_stylesheet
    from sai_version import APP_VERSION

    app = QApplication.instance() or QApplication([])
    app.setProperty("saiNightTheme", False)
    app.setStyleSheet(STYLESHEET + ui_polish_stylesheet(False))

    rail = RailIconButton("ux", "Привоз", primary=True)
    rail.resize(196, 46)
    rail.show()
    app.processEvents()
    rail.refresh_theme()
    pixmap = rail.icon_label.pixmap()
    assert pixmap is not None and not pixmap.isNull()
    image = pixmap.toImage()
    opaque = [image.pixelColor(x, y) for y in range(image.height()) for x in range(image.width()) if image.pixelColor(x, y).alpha() > 80]
    assert opaque
    assert max(c.red() for c in opaque) > 225 and max(c.green() for c in opaque) > 225

    normal_style = rail.text_label.styleSheet()
    rail.enterEvent(QEnterEvent(QPointF(2, 2), QPointF(2, 2), QPointF(2, 2)))
    rail.leaveEvent(QEvent(QEvent.Type.Leave))
    assert rail.text_label.styleSheet() == normal_style

    page = MainPage()
    page.resize(1200, 760)
    page.show()
    page.show_settings()
    app.processEvents()
    assert page.settings_page.thermal_body.isHidden()
    page.settings_page.thermal_toggle_btn.click()
    app.processEvents()
    assert not page.settings_page.thermal_body.isHidden()
    page.settings_page.thermal_toggle_btn.click()
    assert page.settings_page.thermal_body.isHidden()

    title_host = page.window()
    # MainPage itself has no title bar; create the title widget with a harmless host.
    from PySide6.QtWidgets import QMainWindow
    host_window = QMainWindow()
    title = FramelessTitleBar(host_window)
    brand = title.findChild(QLabel, "FramelessTitleBrand")
    assert brand is not None and APP_VERSION in brand.text()

    toast = NotificationToast(page, "ТЕСТ", "Текст не выделяется и не дублируется", "info", 30000)
    title_label = toast.findChild(QLabel, "NotificationTitle")
    message_label = toast.findChild(QLabel, "NotificationMessage")
    assert title_label.textInteractionFlags() == Qt.TextInteractionFlag.NoTextInteraction
    assert message_label.textInteractionFlags() == Qt.TextInteractionFlag.NoTextInteraction
    assert title_label.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
    assert message_label.testAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

    app.setProperty("saiNightTheme", True)
    app.setStyleSheet(STYLESHEET + DARK_STYLESHEET + ui_polish_stylesheet(True))
    rail.refresh_theme()
    assert "#ffffff" in rail.text_label.styleSheet()

    toast.deleteLater(); title.deleteLater(); host_window.deleteLater(); page.deleteLater(); rail.deleteLater()
    app.processEvents()


def main() -> int:
    static_tests()
    runtime_tests()
    print("SAI UI normalization tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
