#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for the v1.22.7bp receipt-hub boundary."""
from __future__ import annotations

import ast
import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))


def static_tests() -> None:
    main_path = APP_DIR / "sai_pyside_preview.py"
    hub_path = APP_DIR / "sai_receipt_hub.py"
    routing_path = APP_DIR / "sai_core_v2" / "receipt_routing.py"
    for path in (main_path, hub_path, routing_path):
        assert path.is_file(), path
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

    main = main_path.read_text(encoding="utf-8-sig")
    hub = hub_path.read_text(encoding="utf-8-sig")
    routing = routing_path.read_text(encoding="utf-8-sig")
    assert "from sai_receipt_hub import" in main
    assert "from sai_core_v2.receipt_routing import" in main
    for name in ("UxTwoLineButton", "DraftsTileButton", "NewReceiptHeroButton", "ReceiptDraftsDialog"):
        assert f"class {name}" not in main
        assert f"class {name}" in hub
    assert "build_receipt_route_plan(path, rows)" in main
    assert 'self.workbench_stack.setCurrentWidget(self.setup_stage)' in main
    assert 'self.workbench_stack.setCurrentWidget(self.workflow_stage)' in main
    assert 'self.confirm_setup_btn = QPushButton("Подтвердить и продолжить")' in main
    assert 'self.file_label.setText(path.name)' in main
    assert 'self.file_label.setText(str(path))' not in main
    workbench = main[main.index("class WorkbenchPage"):main.index("class FreeReceiptPage")]
    assert 'title = QLabel("Обработка SAI-файла")' not in workbench
    assert 'subtitle = QLabel("Проверка товаров, фактическое количество и заполнение прихода в SIGMA.")' not in workbench
    assert 'QPushButton("← Вернуться к сбору ШК")' not in workbench
    assert 'QPushButton("← К экрану привоза")' not in workbench
    assert 'QPushButton("Обновить поставщиков")' not in workbench
    assert "self.workbench_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)" in workbench
    assert "Qt.ScrollBarAsNeeded if visible else Qt.ScrollBarAlwaysOff" in workbench
    assert 'card.setObjectName("UxStartActions")' in main
    assert 'card = self._card("UxStartCard")' not in main[main.index("def _build_empty_state"):main.index("def _build_final_state")]
    styles = (APP_DIR / "sai_legacy_styles.py").read_text(encoding="utf-8-sig")
    assert "border-radius: 18px;" in styles
    assert "background: #ffffff;" in styles[styles.index("QPushButton#UxSourceAction {"):styles.index("QPushButton#UxSourceAction:hover")]
    assert "radius = 18.0" in hub
    assert "class ReceiptRoutePlan" in routing
    assert "full shortage" in routing
    # Production 1.23.3 adds marking, staff, warehouse intelligence and the
    # expanded receipt workbench. Freeze that accumulated shell below 19k;
    # the next development cycle must reduce it through node-based extraction,
    # never raise this checkpoint again.
    assert len(main.splitlines()) < 19_000


def routing_tests() -> None:
    from sai_core_v2.receipt_routing import (
        DraftResumeKind,
        ReceiptRouteKind,
        build_draft_resume_plan,
        build_receipt_route_plan,
        missing_barcode_indices,
        numeric_barcodes,
        receipt_quantity,
        resolve_prepared_receipt_path,
    )

    rows = [
        {"qty": 4, "barcodes": ["4601234567890"]},
        {"quantity": "2,5", "barcode_cell": ""},
        {"qty": 0, "barcode": ""},
        {"qty": 1, "ШК": "12345; 67890 12345"},
    ]
    assert numeric_barcodes(rows[3]) == ("12345", "67890")
    assert receipt_quantity(rows[1]) == 2.5
    assert missing_barcode_indices(rows) == (1,)
    plan = build_receipt_route_plan("test.sai", rows)
    assert plan.kind is ReceiptRouteKind.SEMI_AUTO
    assert plan.stage == "semi_auto"
    assert plan.item_count == 4 and plan.missing_count == 1
    ready = build_receipt_route_plan("ready.sai", [rows[0], rows[2], rows[3]])
    assert ready.kind is ReceiptRouteKind.AUTOMATIC
    assert build_draft_resume_plan({"kind": "manual"}).kind is DraftResumeKind.MANUAL
    package_resume = build_draft_resume_plan({"kind": "ai", "package_path": "draft.sai"})
    assert package_resume.kind is DraftResumeKind.PACKAGE

    with tempfile.TemporaryDirectory(prefix="sai_receipt_hub_") as td:
        xlsx = Path(td) / "invoice.xlsx"
        xlsx.touch()
        assert resolve_prepared_receipt_path(xlsx) == xlsx
        xml = xlsx.with_suffix(".xml")
        xml.touch()
        assert resolve_prepared_receipt_path(xlsx) == xml
        sai = xlsx.with_suffix(".sai")
        sai.touch()
        assert resolve_prepared_receipt_path(xlsx) == sai


def qt_tests() -> None:
    from PySide6.QtWidgets import QApplication, QWidget

    import sai_receipt_drafts
    from sai_receipt_hub import DraftsTileButton, NewReceiptHeroButton, ReceiptDraftsDialog, UxTwoLineButton

    app = QApplication.instance() or QApplication([])
    action = UxTwoLineButton("Действие", "Пояснение", primary=True)
    assert action.objectName() == "UxSourceActionPrimary"
    assert action.title_label.text() == "Действие"
    assert action.subtitle_label.text() == "Пояснение"

    badge = DraftsTileButton("Черновики", "Продолжить")
    badge.resize(300, 68)
    badge.set_draft_count(12)
    assert badge.badge_label.isVisible() or not badge.isVisible()
    assert badge.badge_label.text() == "12"
    assert badge.badge_label.width() >= 24

    hero = NewReceiptHeroButton("НОВЫЙ ПРИВОЗ", "Загрузить накладную")
    assert hero.objectName() == "NewReceiptHeroButton"
    assert hero.minimumHeight() == 172

    class Parent(QWidget):
        def on_draft_deleted(self, draft) -> None:
            pass

    old_list_active = sai_receipt_drafts.list_active
    sai_receipt_drafts.list_active = lambda: []
    try:
        parent = Parent()
        dialog = ReceiptDraftsDialog(parent)
        assert dialog.table.rowCount() == 0
        assert not dialog.open_btn.isEnabled()
        dialog.close()
    finally:
        sai_receipt_drafts.list_active = old_list_active

    action.close(); badge.close(); hero.close(); app.processEvents()


def main() -> int:
    static_tests()
    routing_tests()
    qt_tests()
    print("SAI receipt hub refactor tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
