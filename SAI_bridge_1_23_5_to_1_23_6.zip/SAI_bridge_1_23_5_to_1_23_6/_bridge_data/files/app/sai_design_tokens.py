"""SAI design source of truth. Change tokens here, not in individual screens."""
from __future__ import annotations

BRAND = {
    "primary": "#2563eb", "hover": "#1d4ed8", "pressed": "#1e40af",
    "on_primary": "#ffffff", "danger": "#dc2626", "success": "#10b981",
    "warning": "#f59e0b", "icon": "#2f6fed", "icon_dark": "#60a5fa",
}

METRICS = {
    "hero_radius": 10, "button_radius": 10, "button_height": 36,
    "button_padding_x": 16, "field_radius": 10, "field_height": 36,
    "card_radius": 16, "table_radius": 16, "header_radius": 13,
    "dialog_radius": 20, "icon_size": 30, "icon_radius": 8,
    "font_size": 13, "heading_size": 20, "space_small": 6, "space": 12,
}

LIGHT = {
    "canvas": "#f5f7fb", "surface": "#ffffff", "surface_hover": "#f8fafc",
    "field": "#ffffff", "border": "#dbe3ef", "border_soft": "#e7edf5",
    "text": "#172033", "muted": "#64748b", "subdued": "#8a99ae",
    "hover": "#ffffff", "selected": "#ffffff", "selected_border": "#cbd7e5",
    "scrollbar": "#aab7c8", "scrollbar_hover": "#8797ac",
    "scrollbar_pressed": "#718198", "focus": "#3b82f6", "selection": "#dbeafe",
}
DARK = {
    "canvas": "#0f172a", "surface": "#111827", "surface_hover": "#172033",
    "field": "#111827", "border": "#2f3d53", "border_soft": "#253247",
    "text": "#e8eef8", "muted": "#94a3b8", "subdued": "#7183a1",
    "hover": "#1b2738", "selected": "#202d40", "selected_border": "#456184",
    "scrollbar": "#475569", "scrollbar_hover": "#64748b",
    "scrollbar_pressed": "#748399", "focus": "#60a5fa", "selection": "#1e3a8a",
}

# Existing object names remain supported while pages migrate to semantic roles.
ROLES = {
    "hero": ("WorkbenchPrimaryButton", "HeroButton", "SoftPrimaryButton", "PageOrientationConfirmButton", "StartupPrimary", "UxButtonPrimary"),
    "secondary": ("SoftButton", "SecondaryButton", "StartupSecondary", "UxButton"),
    "danger": ("DangerButton",),
    "field": ("WorkbenchInput", "WorkbenchCombo"),
}


def palette(dark: bool = False) -> dict[str, str]:
    return dict(DARK if dark else LIGHT)


def stock_dashboard_stylesheet(dark: bool = False) -> str:
    """Dashboard-specific layout using the same palette and geometry tokens."""
    p, m, b = palette(dark), METRICS, BRAND
    return f"""
QDialog {{ background: {p['canvas']}; color: {p['text']}; }}
QLabel {{ color: {p['text']}; }}
QFrame#ProductHeroCard, QFrame#MetricCard, QFrame#TimelineCard {{
    background: {p['surface']}; border: 1px solid {p['border']}; border-radius: {m['card_radius']}px;
}}
QFrame#MetricCard {{ min-height: 92px; }}
QFrame#MetricCard[accent="blue"] {{ border-bottom: 3px solid {b['primary']}; }}
QFrame#MetricCard[accent="green"] {{ border-bottom: 3px solid {b['success']}; }}
QFrame#MetricCard[accent="amber"] {{ border-bottom: 3px solid {b['warning']}; }}
QFrame#MetricCard[accent="violet"] {{ border-bottom: 3px solid {b['icon']}; }}
QLabel#MetricTitle, QLabel#ProductIdentity {{ color: {p['muted']}; font-size: 12px; }}
QLabel#MetricValue {{ font-size: 24px; font-weight: 850; }}
QLabel#MetricHint {{ color: {p['muted']}; font-size: 11px; }}
QLabel#ProductName {{ font-size: {m['heading_size']}px; font-weight: 850; }}
QLabel#ProductSyncBadge {{ color: {b['success']}; background: {p['surface_hover']};
    border: 1px solid {p['border']}; border-radius: {m['button_radius']}px; padding: 6px 10px; font-weight: 700; }}
QLabel#TimelineTitle {{ font-size: 16px; font-weight: 800; }}
QPushButton#TimelineModeButton, QToolButton#TimelineFilterButton {{
    color: {p['text']}; background: {p['surface_hover']}; border: 1px solid {p['border']};
    border-radius: {m['button_radius']}px; padding: 7px 12px; font-weight: 700;
}}
QPushButton#TimelineModeButton:checked {{ color: {b['on_primary']}; background: {b['primary']}; border-color: {b['primary']}; }}
QToolButton#TimelineFilterButton:hover {{ background: {p['selection']}; }}
QTableWidget {{ background: {p['surface']}; alternate-background-color: {p['surface_hover']};
    border: 1px solid {p['border']}; border-radius: {m['table_radius']}px;
    selection-background-color: {p['selection']}; selection-color: {p['text']}; }}
QHeaderView::section {{ background: {p['surface_hover']}; color: {p['muted']}; border: none;
    border-bottom: 1px solid {p['border']}; padding: 9px 8px; font-weight: 750; }}
"""


def role_selectors(role: str, state: str = "") -> str:
    names = ROLES[role]
    kind = "primary" if role == "hero" else role
    return ",\n".join([f'QPushButton[saiRole="{role}"]{state}', f'QPushButton#SAIMessageButton[kind="{kind}"]{state}'] + [f"QPushButton#{name}{state}" for name in names])


def component_stylesheet(dark: bool = False) -> str:
    p, m, b = palette(dark), METRICS, BRAND
    result = []
    for role in ("hero", "secondary", "danger"):
        primary = role in ("hero", "danger")
        fill = b["danger"] if role == "danger" else b["primary"] if primary else p["surface"]
        hover = "#b91c1c" if role == "danger" else b["hover"] if primary else p["surface_hover"]
        result.append(f"""
{role_selectors(role)} {{
    background: {fill}; color: {b['on_primary'] if primary else p['text']};
    border: 1px solid {fill if primary else p['border']};
    border-radius: {m['hero_radius'] if role == 'hero' else m['button_radius']}px;
    min-height: {m['button_height']}px; padding: 0 {m['button_padding_x']}px; font-weight: 700;
}}
{role_selectors(role, ':hover')} {{ background: {hover}; border-color: {p['focus']}; }}
{role_selectors(role, ':pressed')} {{ background: {b['pressed'] if role == 'hero' else hover}; }}
{role_selectors(role, ':focus')} {{ border: 2px solid {p['focus']}; }}
{role_selectors(role, ':disabled')} {{ color: {p['subdued']}; background: {p['surface_hover']}; border-color: {p['border_soft']}; }}
""")
    result.append(f"""
QLineEdit#WorkbenchInput, QComboBox#WorkbenchCombo, QLineEdit[saiRole="field"], QComboBox[saiRole="field"] {{
    background: {p['field']}; color: {p['text']}; border: 1px solid {p['border']};
    border-radius: {m['field_radius']}px; min-height: {m['field_height']}px; padding: 0 10px;
}}
QLineEdit#WorkbenchInput:focus, QComboBox#WorkbenchCombo:focus {{ border-color: {p['focus']}; }}
QLabel#ImportantAccentLabel {{ color: {p['text']}; font-size: 12px; font-weight: 800; }}
QLineEdit[saiState="error"], QComboBox[saiState="error"],
QLineEdit#WorkbenchInput[saiState="error"], QComboBox#WorkbenchCombo[saiState="error"] {{ border: 2px solid {b['danger']}; }}
QComboBox#WorkbenchCombo::drop-down {{ border: none; width: 24px; }}
QFrame#WorkbenchCard, QFrame#MetricCard, QFrame#RoundedTableShell {{
    background: {p['surface']}; border: 1px solid {p['border']}; border-radius: {m['card_radius']}px;
}}
QFrame#MassUnknownPanel {{
    background: {p['surface_hover']}; border: 1px solid {p['border_soft']};
    border-radius: {m['field_radius']}px;
}}
QLabel#MassUnknownTitle {{ color: {p['text']}; font-weight: 700; }}
QLabel#StaffPageTitle {{
    color: {p['text']}; background: transparent; font-size: 24px; font-weight: 900;
}}
QLabel#StaffPageSubtitle {{
    color: {p['muted']}; background: transparent; font-size: 12px;
}}
QLabel#StaffPeriodTitle {{
    color: {p['text']}; background: transparent; font-size: 15px; font-weight: 850;
    padding-left: 6px;
}}
QPushButton#StaffMonthButton {{
    color: {p['text']}; background: transparent; border: none;
    min-height: {m['button_height']}px; padding: 0 14px; font-size: 14px; font-weight: 850;
}}
QPushButton#StaffMonthButton:hover {{ background: {p['surface_hover']}; border-radius: {m['button_radius']}px; }}
QFrame#StaffEmptyState {{
    background: {p['surface']}; border: 1px solid {p['border']};
    border-radius: {m['card_radius']}px;
}}
QFrame#StaffWeekCard {{
    background: {p['surface']}; border: 1px solid {p['border']};
    border-radius: {m['table_radius']}px;
}}
QLabel#StaffWeekCaption {{
    color: {p['text']}; background: {p['surface_hover']};
    font-size: 12px; font-weight: 800; border: none;
}}
QTableWidget#StaffScheduleGrid {{
    background: {p['surface']}; border: none; border-radius: 0px; gridline-color: transparent;
}}
QFrame#StaffScheduleShell {{
    background: {p['surface']}; border: 1px solid {p['border']};
    border-radius: {m['table_radius']}px;
}}
QPushButton#StaffAddEmployeeButton {{
    color: {b['primary']}; background: transparent; border: none;
    min-height: 32px; padding: 0 10px; font-weight: 750; text-align: left;
}}
QPushButton#StaffAddEmployeeButton:hover {{
    color: {b['hover']}; background: {p['selection']}; border-radius: {m['button_radius']}px;
}}
QTableWidget#ReceiptTable {{ border-radius: {m['table_radius']}px; }}
QFrame#RoundedTableShell {{ border-radius: {m['table_radius']}px; }}
QHeaderView#SemiProductsHeader::section:first, QHeaderView#RoundedTableHeader::section:first {{ border-top-left-radius: {m['table_radius'] - 3}px; }}
QHeaderView#SemiProductsHeader::section:last, QHeaderView#RoundedTableHeader::section:last {{ border-top-right-radius: {m['table_radius'] - 3}px; }}
QTableWidget {{ selection-background-color: {p['selection']}; selection-color: {p['text']}; }}
QDialog[saiRole="dialog"] {{ background: {p['canvas']}; color: {p['text']}; }}
QDialog[saiRole="dialog"] QLabel {{ color: {p['text']}; }}
QDialog[saiRole="dialog"] QHeaderView {{ background: {p['surface_hover']}; }}
QWidget#ReceiptWorkflowTracker {{ background: transparent; border: none; }}
QFrame#ReceiptWorkflowStep {{
    background: {p['surface_hover']}; border: 1px solid {p['border_soft']};
    border-radius: {m['button_radius']}px;
}}
QFrame#ReceiptWorkflowStep[workflowState="current"] {{
    background: {p['selection']}; border: 2px solid {b['primary']};
}}
QFrame#ReceiptWorkflowStep[workflowState="done"] {{
    background: {p['surface']}; border: 1px solid {b['success']};
}}
QFrame#ReceiptWorkflowStep[workflowState="error"] {{
    background: {p['surface']}; border: 2px solid {b['danger']};
}}
QFrame#ReceiptWorkflowStep[workflowState="skipped"] {{
    background: transparent; border: 1px dashed {p['border']};
}}
QLabel#ReceiptWorkflowBadge {{
    background: {p['border_soft']}; color: {p['muted']}; border: none;
    border-radius: 13px; font-size: 11px; font-weight: 850;
}}
QLabel#ReceiptWorkflowBadge[workflowState="current"] {{ background: {b['primary']}; color: {b['on_primary']}; }}
QLabel#ReceiptWorkflowBadge[workflowState="done"] {{ background: {b['success']}; color: #ffffff; }}
QLabel#ReceiptWorkflowBadge[workflowState="error"] {{ background: {b['danger']}; color: #ffffff; }}
QLabel#ReceiptWorkflowBadge[workflowState="skipped"] {{ background: {p['border_soft']}; color: {p['subdued']}; }}
QLabel#ReceiptWorkflowTitle {{ background: transparent; color: {p['text']}; font-size: 11px; font-weight: 760; }}
QLabel#ReceiptWorkflowActor {{ background: transparent; color: {p['muted']}; font-size: 9px; font-weight: 650; }}
QLabel#ReceiptWorkflowTitle[workflowState="pending"],
QLabel#ReceiptWorkflowActor[workflowState="pending"],
QLabel#ReceiptWorkflowTitle[workflowState="skipped"],
QLabel#ReceiptWorkflowActor[workflowState="skipped"] {{ color: {p['subdued']}; }}
""")
    return "\n".join(result)
