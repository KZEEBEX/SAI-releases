#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused installation checks for SAI v1.22.7aq AI pipeline refactor."""
from __future__ import annotations

import ast
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
app = root / "app"

version_text = (app / "sai_version.py").read_text(encoding="utf-8")
assert 'VERSION = "1.22.7aq"' in version_text
self_tests = (app / "run_self_tests.py").read_text(encoding="utf-8")
assert 'APP_VERSION == "v1.22.7aq"' in self_tests

main_path = app / "sai_openai_invoice.py"
pipeline_path = app / "sai_invoice_ai_pipeline.py"
telemetry_path = app / "sai_invoice_ai_telemetry.py"
regression_path = app / "run_invoice_ai_pipeline_tests.py"
for path in (main_path, pipeline_path, telemetry_path, regression_path):
    assert path.is_file(), path
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

main_tree = ast.parse(main_path.read_text(encoding="utf-8"))
analyze = next(node for node in main_tree.body if isinstance(node, ast.FunctionDef) and node.name == "analyze_invoice")
assert analyze.end_lineno - analyze.lineno + 1 <= 140
assert any(isinstance(node, ast.FunctionDef) and node.name == "_read_visual_document" for node in main_tree.body)
assert any(isinstance(node, ast.FunctionDef) and node.name == "_review_problem_rows" for node in main_tree.body)
assert not any(isinstance(node, ast.FunctionDef) and node.name == "_shadow_page_risk" for node in main_tree.body)

pipeline_text = pipeline_path.read_text(encoding="utf-8")
assert "class InvoicePipelineState" in pipeline_text
assert "def build_quality_metadata" in pipeline_text
telemetry_text = telemetry_path.read_text(encoding="utf-8")
for token in ("def response_usage", "def shadow_page_risk", "def append_economy_telemetry"):
    assert token in telemetry_text

subprocess.run([sys.executable, str(regression_path), str(root)], cwd=app, check=True)

wiki = root / "SAI_Ecosystem_Wiki_v0.1"
manifest = json.loads((wiki / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.8"
assert manifest["snapshot_sai_version"] == "1.22.7aq"
assert (wiki / "decisions" / "ADR-025-INVOICE-AI-PIPELINE-BOUNDARIES.md").is_file()
assert (wiki / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.8 / SAI 1.22.7aq")

print("PATCH_AQ_SELF_TEST_OK")
