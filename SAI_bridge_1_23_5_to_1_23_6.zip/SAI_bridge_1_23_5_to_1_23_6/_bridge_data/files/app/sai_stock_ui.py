#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Qt pages for the Warehouse entry point and owner cabinet."""
from __future__ import annotations

from contextlib import closing
import datetime as dt
from decimal import Decimal
from pathlib import Path
import threading
import uuid

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QColor, QIcon, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication, QAbstractItemView, QButtonGroup, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
    QFrame, QGridLayout, QHBoxLayout, QHeaderView, QInputDialog, QLabel,
    QLineEdit, QMenu, QMessageBox, QPushButton, QTabWidget, QTableWidget,
    QTableWidgetItem, QToolButton, QToolTip, QVBoxLayout, QWidget,
)

import sai_db
from sai_stock import StockService
from sai_store_dashboard import SalesChart


def _title(text: str, subtitle: str) -> QWidget:
    box = QWidget()
    layout = QVBoxLayout(box); layout.setContentsMargins(0, 0, 0, 0); layout.setSpacing(5)
    heading = QLabel(text); heading.setObjectName("WarehousePageTitle")
    note = QLabel(subtitle); note.setObjectName("WarehousePageSubtitle"); note.setWordWrap(True)
    layout.addWidget(heading); layout.addWidget(note)
    return box


def _card(title: str, value: str, hint: str = "", accent: str = "") -> QFrame:
    frame = QFrame(); frame.setObjectName("MetricCard")
    if accent:
        frame.setProperty("accent", accent)
    layout = QVBoxLayout(frame); layout.setContentsMargins(16, 14, 16, 14); layout.setSpacing(5)
    label = QLabel(title); label.setObjectName("MetricTitle")
    number = QLabel(value); number.setObjectName("MetricValue")
    layout.addWidget(label); layout.addWidget(number)
    if hint:
        detail = QLabel(hint); detail.setObjectName("MetricHint"); detail.setWordWrap(True); layout.addWidget(detail)
    return frame


class ProductTimelineWidget(QWidget):
    """Compact product timeline with uniform and real-time scales."""

    COLORS = {
        "product_created": QColor("#2F6FED"),
        "receipt": QColor("#35B98F"),
        "sale": QColor("#FF9F1C"),
        "return": QColor("#9550CC"),
        "adjustment": QColor("#E54B4B"),
        "writeoff": QColor("#E54B4B"),
        "stock_snapshot": QColor("#5B7CFA"),
        "price_change": QColor("#64748B"),
    }
    LABELS = {
        "product_created": "Создана карточка",
        "receipt": "Поступление",
        "sale": "Продажа",
        "return": "Возврат",
        "adjustment": "Инвентаризация",
        "writeoff": "Списание",
        "stock_snapshot": "Остаток SIGMA",
        "price_change": "Изменение цены",
    }

    def __init__(self, rows: list[dict], parent=None) -> None:
        super().__init__(parent)
        self.rows = list(rows)
        self.mode = "relative"
        self.visible_types = set(self.COLORS)
        self._points: list[tuple[QPointF, dict]] = []
        self.setMinimumHeight(155)
        self.setMouseTracking(True)

    @staticmethod
    def _moment(row: dict) -> dt.datetime | None:
        try:
            value = dt.datetime.fromisoformat(str(row.get("date") or "").replace("Z", "+00:00"))
            return value.astimezone() if value.tzinfo else value.astimezone()
        except Exception:
            return None

    def set_mode(self, mode: str) -> None:
        self.mode = "real" if mode == "real" else "relative"
        self.update()

    def set_visible_types(self, values: set[str]) -> None:
        self.visible_types = set(values)
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        chart = QRectF(32, 20, max(20, self.width() - 64), max(60, self.height() - 54))
        center_y = chart.top() + 58
        events = [
            (moment, row) for row in self.rows
            if str(row.get("type") or "") in self.visible_types
            for moment in [self._moment(row)] if moment is not None
        ]
        events.sort(key=lambda item: item[0])
        self._points = []
        if not events:
            painter.setPen(QColor("#718096"))
            painter.drawText(chart, Qt.AlignCenter, "Нет событий с выбранными фильтрами")
            return

        now = dt.datetime.now().astimezone()
        start = events[0][0]
        if start > now:
            start = now
        duration = max(1.0, (now - start).total_seconds())
        painter.setPen(QPen(QColor("#CDD8E6"), 3, Qt.SolidLine, Qt.RoundCap))
        painter.drawLine(QPointF(chart.left(), center_y), QPointF(chart.right(), center_y))

        if self.mode == "real":
            painter.setPen(QPen(QColor("#E2E8F0"), 1))
            for index in range(5):
                ratio = index / 4
                x = chart.left() + chart.width() * ratio
                painter.drawLine(QPointF(x, center_y - 7), QPointF(x, center_y + 7))
                label_date = start + (now - start) * ratio
                painter.setPen(QColor("#718096"))
                rect = QRectF(x - 42, center_y + 15, 84, 22)
                painter.drawText(rect, Qt.AlignHCenter | Qt.AlignTop, label_date.strftime("%d.%m.%y"))
                painter.setPen(QPen(QColor("#E2E8F0"), 1))

        count = len(events)
        milestone_indices = {0, count - 1}
        for event_type in ("product_created", "receipt", "sale"):
            for index, (_moment, row) in enumerate(events):
                if row.get("type") == event_type:
                    milestone_indices.add(index)
                    break
        for index, (moment, row) in enumerate(events):
            if self.mode == "real":
                ratio = min(1.0, max(0.0, (moment - start).total_seconds() / duration))
            else:
                # Current time is the final, empty endpoint; every event and
                # the remaining interval to "now" receive equal spacing.
                ratio = index / count
            x = chart.left() + chart.width() * ratio
            point = QPointF(x, center_y)
            event_type = str(row.get("type") or "")
            color = self.COLORS.get(event_type, QColor("#64748B"))
            painter.setPen(QPen(QColor("#FFFFFF"), 2))
            painter.setBrush(color)
            painter.drawEllipse(point, 7, 7)
            self._points.append((point, row))
            if index in milestone_indices and len(milestone_indices) <= 6:
                above = index % 2 == 0
                label_y = center_y - 42 if above else center_y + 12
                painter.setPen(color)
                label_rect = QRectF(x - 66, label_y, 132, 28)
                painter.drawText(
                    label_rect, Qt.AlignHCenter | (Qt.AlignBottom if above else Qt.AlignTop),
                    self.LABELS.get(event_type, event_type),
                )

        if self.mode != "real":
            painter.setPen(QColor("#718096"))
            painter.drawText(QRectF(chart.left(), center_y + 28, 100, 20), Qt.AlignLeft, start.strftime("%d.%m.%y"))
            painter.drawText(QRectF(chart.right() - 100, center_y + 28, 100, 20), Qt.AlignRight, "Сейчас")

    def mouseMoveEvent(self, event) -> None:
        position = event.position()
        nearest = None
        distance = 999.0
        for point, row in self._points:
            current = abs(point.x() - position.x()) + abs(point.y() - position.y())
            if current < distance:
                nearest, distance = row, current
        if nearest is not None and distance <= 18:
            event_type = str(nearest.get("type") or "")
            quantity = nearest.get("quantity")
            parts = [
                self.LABELS.get(event_type, event_type),
                str(nearest.get("date") or "")[:19].replace("T", " "),
            ]
            if quantity is not None:
                parts.append(f"Количество: {quantity}")
            note = str(nearest.get("note") or "").strip()
            if note:
                parts.append(note)
            QToolTip.showText(event.globalPosition().toPoint(), "\n".join(parts), self)
        else:
            QToolTip.hideText()
        super().mouseMoveEvent(event)


class WarehousePage(QWidget):
    sigma_sync_finished = Signal(dict)
    sigma_sync_progress = Signal(dict)
    analytic_finished = Signal(dict)

    def __init__(self, parent_page=None) -> None:
        super().__init__()
        self.parent_page = parent_page
        self._catalog_rows: list[dict] = []
        self._catalog_revision: tuple[int, str, int] | None = None
        self._event_journal_synced = False
        self.search_timer = QTimer(self)
        self.search_timer.setSingleShot(True)
        self.search_timer.setInterval(180)
        self.search_timer.timeout.connect(self.refresh_balances)
        self._warehouse_sync_job: dict | None = None
        self._analytic_job: dict | None = None
        self.sigma_sync_finished.connect(self._finish_warehouse_sync)
        self.sigma_sync_progress.connect(self._show_warehouse_sync_progress)
        self.analytic_finished.connect(self._finish_analytic)
        self.build_ui()
        self.refresh()

    def build_ui(self) -> None:
        root = QVBoxLayout(self); root.setContentsMargins(28, 18, 28, 18); root.setSpacing(10)
        header_row = QHBoxLayout(); header_row.setSpacing(16)
        header_row.addWidget(_title(
            "Склад",
            "Аналитика продаж и остатков: что происходит с товарами и что требует внимания.",
        ), 1)
        location_row = QHBoxLayout(); location_row.setSpacing(8)
        location_label = QLabel("Место"); location_label.setObjectName("WorkbenchNote"); location_row.addWidget(location_label)
        self.location_combo = QComboBox(); self.location_combo.setObjectName("WorkbenchCombo"); self.location_combo.setMinimumWidth(260)
        self.location_combo.currentIndexChanged.connect(self.refresh_tables); location_row.addWidget(self.location_combo)
        self.add_location_btn = QPushButton("+ Место"); self.add_location_btn.setObjectName("SoftButton"); self.add_location_btn.clicked.connect(self.create_location)
        location_row.addWidget(self.add_location_btn)
        header_row.addLayout(location_row); root.addLayout(header_row)
        self.sync_btn = QPushButton("Докачать архив"); self.sync_btn.setObjectName("SoftButton"); self.sync_btn.clicked.connect(self.sync_warehouse_data)
        self.sync_btn.setVisible(False)
        self.sync_status = QLabel(); self.sync_status.setObjectName("InlineStatus"); self.sync_status.setWordWrap(True); self.sync_status.setVisible(False)
        root.addWidget(self.sync_status)

        self.tabs = QTabWidget(); self.tabs.setObjectName("WorkbenchTabs")
        self.tabs.addTab(self._build_analytics_tab(), "Обзор")
        self.tabs.addTab(self._build_balances_tab(), "Товары")
        self.tabs.addTab(self._build_movements_tab(), "Журнал")
        root.addWidget(self.tabs, 1)

    def _build_analytics_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(0, 8, 0, 0); layout.setSpacing(9)
        self.analytic_hero = QFrame(); self.analytic_hero.setObjectName("AnalyticHero"); self.analytic_hero.setProperty("level", "warning")
        self.analytic_hero.setMinimumHeight(124)
        hero = QHBoxLayout(self.analytic_hero); hero.setContentsMargins(20, 14, 16, 14); hero.setSpacing(18)
        hero_text = QVBoxLayout(); hero_text.setSpacing(4)
        self.analytic_badge = QLabel("SAI ANALYTIC"); self.analytic_badge.setObjectName("AnalyticBadge")
        self.analytic_title = QLabel("Проверяю доступные данные…"); self.analytic_title.setObjectName("AnalyticTitle"); self.analytic_title.setWordWrap(True)
        self.analytic_why = QLabel(); self.analytic_why.setObjectName("AnalyticWhy"); self.analytic_why.setWordWrap(True)
        self.analytic_actions = QLabel(); self.analytic_actions.setObjectName("AnalyticActions"); self.analytic_actions.setWordWrap(True)
        hero_text.addWidget(self.analytic_badge); hero_text.addWidget(self.analytic_title); hero_text.addWidget(self.analytic_why); hero_text.addWidget(self.analytic_actions)
        hero.addLayout(hero_text, 1)
        hero_buttons = QVBoxLayout(); hero_buttons.setSpacing(7)
        self.analyze_btn = QPushButton("Провести анализ"); self.analyze_btn.setObjectName("WorkbenchPrimaryButton"); self.analyze_btn.clicked.connect(self.run_analytic)
        self.hero_sync_btn = QPushButton("Докачать архив"); self.hero_sync_btn.setObjectName("SoftButton"); self.hero_sync_btn.clicked.connect(self.sync_warehouse_data)
        hero_buttons.addWidget(self.analyze_btn); hero_buttons.addWidget(self.hero_sync_btn); hero_buttons.addStretch(1)
        hero.addLayout(hero_buttons)
        layout.addWidget(self.analytic_hero)

        coverage_frame = QFrame(); coverage_frame.setObjectName("CoverageFrame")
        coverage_layout = QHBoxLayout(coverage_frame); coverage_layout.setContentsMargins(14, 9, 14, 9); coverage_layout.setSpacing(6)
        coverage_title = QLabel("Архив 2026"); coverage_title.setObjectName("CoverageTitle"); coverage_layout.addWidget(coverage_title)
        self.coverage_labels: list[QLabel] = []
        for _month in range(12):
            label = QLabel("—"); label.setObjectName("CoverageMonth"); label.setAlignment(Qt.AlignCenter); label.setMinimumWidth(43)
            self.coverage_labels.append(label); coverage_layout.addWidget(label, 1)
        layout.addWidget(coverage_frame)

        metrics = QGridLayout(); metrics.setHorizontalSpacing(9); metrics.setVerticalSpacing(9)
        self.analytics_revenue = _card("Выручка за 30 дней", "—", "по загруженным чекам", "blue")
        self.analytics_units = _card(
            "Поштучно продано за 30 дней", "—",
            "поштучно · без общих отделов и продаж по весу", "green",
        )
        self.analytics_stock = _card("Товаров в наличии", "—", "с положительным остатком", "violet")
        self.analytics_attention = _card("Требует внимания", "—", "нет продаж более 90 дней", "amber")
        for column, card in enumerate((
            self.analytics_revenue, self.analytics_units,
            self.analytics_stock, self.analytics_attention,
        )):
            card.setMinimumHeight(88)
            metrics.addWidget(card, 0, column)
        layout.addLayout(metrics)

        chart_card = QFrame(); chart_card.setObjectName("MetricCard")
        chart_layout = QVBoxLayout(chart_card); chart_layout.setContentsMargins(16, 14, 16, 12); chart_layout.setSpacing(6)
        chart_title = QLabel("Продажи · последние 30 дней"); chart_title.setObjectName("WorkbenchSection")
        chart_layout.addWidget(chart_title)
        self.analytics_chart = SalesChart(chart_card); self.analytics_chart.setMinimumHeight(150)
        chart_layout.addWidget(self.analytics_chart)
        lower = QHBoxLayout(); lower.setSpacing(9); lower.addWidget(chart_card, 3)

        attention_card = QFrame(); attention_card.setObjectName("MetricCard")
        attention_layout = QVBoxLayout(attention_card); attention_layout.setContentsMargins(14, 13, 14, 12); attention_layout.setSpacing(6)
        attention_header = QVBoxLayout(); attention_header.setSpacing(2)
        attention_title = QLabel("Требует внимания"); attention_title.setObjectName("WorkbenchSection")
        attention_hint = QLabel("Двойное нажатие откроет историю товара")
        attention_hint.setObjectName("WorkbenchNote")
        attention_header.addWidget(attention_title); attention_header.addWidget(attention_hint)
        attention_layout.addLayout(attention_header)
        self.attention_table = self._table(("Товар", "Почему", "Остаток"))
        attention_columns = self.attention_table.horizontalHeader()
        attention_columns.setSectionResizeMode(0, QHeaderView.Stretch)
        attention_columns.setSectionResizeMode(1, QHeaderView.Stretch)
        attention_columns.setSectionResizeMode(2, QHeaderView.Fixed); attention_columns.resizeSection(2, 74)
        self.attention_table.cellDoubleClicked.connect(self.open_attention_product)
        attention_layout.addWidget(self.attention_table, 1)
        lower.addWidget(attention_card, 2)
        layout.addLayout(lower, 1)
        return page

    def _build_balances_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(0, 12, 0, 0); layout.setSpacing(10)
        tools = QHBoxLayout(); tools.setSpacing(10)
        self.search = QLineEdit(); self.search.setObjectName("WorkbenchInput"); self.search.setPlaceholderText("Название, артикул, цена или штрихкод"); self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.schedule_search)
        self.search.returnPressed.connect(self.apply_search_now)
        tools.addWidget(self.search, 1)
        self.timeline_btn = QPushButton("Открыть аналитику товара"); self.timeline_btn.setObjectName("WorkbenchPrimaryButton"); self.timeline_btn.clicked.connect(self.open_product_timeline); tools.addWidget(self.timeline_btn)
        self.operations_btn = QToolButton(); self.operations_btn.setText("Операции"); self.operations_btn.setObjectName("TimelineFilterButton")
        operations_menu = QMenu(self.operations_btn)
        self.receipt_action = operations_menu.addAction("Оприходовать вручную")
        self.writeoff_action = operations_menu.addAction("Списать")
        self.adjust_action = operations_menu.addAction("Уточнить остаток")
        self.receipt_action.triggered.connect(lambda: self.open_operation("receipt"))
        self.writeoff_action.triggered.connect(lambda: self.open_operation("writeoff"))
        self.adjust_action.triggered.connect(lambda: self.open_operation("adjustment"))
        self.operations_btn.setMenu(operations_menu); self.operations_btn.setPopupMode(QToolButton.InstantPopup)
        tools.addWidget(self.operations_btn)
        layout.addLayout(tools)
        self.balance_hint = QLabel(); self.balance_hint.setObjectName("WorkbenchNote"); layout.addWidget(self.balance_hint)
        self.balance_table = self._table(("Товар", "Артикул", "Штрихкоды", "Цена", "Остаток"))
        header = self.balance_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        for column, width in ((1, 130), (2, 210), (3, 90), (4, 90)):
            header.setSectionResizeMode(column, QHeaderView.Interactive)
            header.resizeSection(column, width)
        self.balance_table.itemSelectionChanged.connect(self.update_action_state)
        self.balance_table.cellDoubleClicked.connect(self.balance_cell_double_clicked)
        layout.addWidget(self.balance_table, 1)
        return page

    def _build_movements_tab(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.setContentsMargins(0, 12, 0, 0); layout.setSpacing(10)
        note = QLabel("История неизменяема: ошибка исправляется новой корректировкой, а не удалением записи.")
        note.setObjectName("WorkbenchNote"); note.setWordWrap(True); layout.addWidget(note)
        self.movement_table = self._table(("Дата", "Операция", "Товар", "Количество", "Место", "Комментарий"))
        header = self.movement_table.horizontalHeader()
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(5, QHeaderView.Stretch)
        for column, width in ((0, 145), (1, 120), (3, 95), (4, 170)):
            header.setSectionResizeMode(column, QHeaderView.Interactive)
            header.resizeSection(column, width)
        layout.addWidget(self.movement_table, 1); return page

    @staticmethod
    def _table(headers: tuple[str, ...]) -> QTableWidget:
        table = QTableWidget(0, len(headers)); table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows); table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers); table.setAlternatingRowColors(True); table.setShowGrid(False)
        table.verticalHeader().setVisible(False); table.horizontalHeader().setStretchLastSection(True)
        return table

    def product_barcodes_at(self, row: int) -> tuple[str, ...]:
        item = self.balance_table.item(row, 0) if row >= 0 else None
        return tuple(str(code) for code in (item.data(Qt.UserRole + 2) or ()) if code) if item else ()

    def balance_cell_double_clicked(self, row: int, column: int) -> None:
        if column == 2:
            codes = self.product_barcodes_at(row)
            if codes:
                QApplication.clipboard().setText("\n".join(codes))
                item = self.balance_table.item(row, column)
                rect = self.balance_table.visualItemRect(item)
                QToolTip.showText(
                    self.balance_table.viewport().mapToGlobal(rect.center()),
                    "ШК скопирован" if len(codes) == 1 else f"Скопировано ШК: {len(codes)}",
                    self.balance_table,
                )
            return
        self.open_product_timeline()

    @staticmethod
    def _set_card_value(card: QFrame, value: str) -> None:
        labels = card.findChildren(QLabel)
        if len(labels) > 1: labels[1].setText(value)

    def refresh(self) -> None:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            service = StockService(con); service.sync_all_catalog_identities()
            revision = service.catalog_revision()
            if not self._event_journal_synced or revision != self._catalog_revision:
                service.sync_event_journal()
                self._event_journal_synced = True
        self.refresh_locations()
        if revision != self._catalog_revision:
            self.reload_catalog(revision)
        else:
            self.refresh_current_balances()
        self.refresh_analytics(); self.refresh_movements(); self.update_action_state()

    def refresh_locations(self) -> None:
        current = self.location_combo.currentData()
        with closing(sai_db.connect()) as con:
            locations = StockService(con).locations()
        self.location_combo.blockSignals(True); self.location_combo.clear()
        for item in locations:
            self.location_combo.addItem(item["name"], item["id"])
        if current:
            index = self.location_combo.findData(current)
            if index >= 0: self.location_combo.setCurrentIndex(index)
        self.location_combo.blockSignals(False)

    def refresh_tables(self, *_args) -> None:
        self.refresh_current_balances(); self.refresh_analytics(); self.refresh_movements(); self.update_action_state()

    def refresh_analytics(self) -> None:
        location_id = str(self.location_combo.currentData() or "")
        if not location_id:
            return
        with closing(sai_db.connect()) as con:
            overview = StockService(con).analytics_overview(location_id)
            from sai_analytics_ai import archive_month_coverage, load_cached_recommendation, local_recommendation
            coverage = archive_month_coverage(con)
            local = local_recommendation(con, location_id=location_id, coverage=coverage)
            recommendation = local if local.get("level") == "warning" else (load_cached_recommendation(con, location_id) or local)
        self._show_coverage(coverage)
        self._show_recommendation(recommendation)
        self._set_card_value(self.analytics_revenue, self._price_text(overview.get("revenue") or 0))
        self._set_card_value(self.analytics_units, self._quantity_text(overview.get("units_sold") or 0))
        self._set_card_value(self.analytics_stock, str(int(overview.get("stock_products") or 0)))
        self._set_card_value(self.analytics_attention, str(int(overview.get("attention_count") or 0)))
        self.analytics_chart.set_series(
            tuple(overview.get("chart_labels") or ()),
            tuple(overview.get("chart_values") or ()),
        )
        rows = list(overview.get("attention") or ())
        self.attention_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            last_sale = str(row.get("last_sale") or "")[:10] or "—"
            reason = str(row.get("reason") or "—")
            if last_sale != "—":
                reason += f" · {last_sale}"
            values = (row.get("name") or "—", reason, self._quantity_text(row.get("balance") or 0))
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column == 0:
                    item.setData(Qt.UserRole, str(row.get("sai_product_id") or ""))
                if column == 2:
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.attention_table.setItem(row_index, column, item)

    def _show_coverage(self, coverage: list[dict]) -> None:
        colors = {
            "complete": ("#DCFCE7", "#166534"), "partial": ("#FEF3C7", "#92400E"),
            "error": ("#FEE2E2", "#B91C1C"), "missing": ("#F1F5F9", "#64748B"),
            "future": ("transparent", "#A0AEC0"),
        }
        for label, item in zip(self.coverage_labels, coverage):
            background, foreground = colors.get(str(item.get("status")), colors["missing"])
            label.setText(str(item.get("label") or "—")); label.setToolTip(str(item.get("hint") or ""))
            label.setStyleSheet(
                f"QLabel {{ background: {background}; color: {foreground}; border-radius: 8px; "
                "padding: 6px 3px; font-weight: 800; }}"
            )

    def _show_recommendation(self, value: dict) -> None:
        self.analytic_hero.setProperty("level", str(value.get("level") or "info"))
        self.analytic_hero.style().unpolish(self.analytic_hero); self.analytic_hero.style().polish(self.analytic_hero)
        self.analytic_badge.setText("SAI ANALYTIC  ·  " + str(value.get("badge") or "РЕКОМЕНДАЦИЯ"))
        self.analytic_title.setText(str(value.get("title") or "Нет рекомендации"))
        self.analytic_why.setText(str(value.get("why") or ""))
        actions = [str(item) for item in (value.get("actions") or []) if str(item).strip()]
        self.analytic_actions.setText("   •   ".join(actions))

    def run_analytic(self) -> None:
        location_id = str(self.location_combo.currentData() or "")
        if not location_id or self._analytic_job is not None:
            return
        from sai_accounts import AccountService
        ai_cfg = AccountService().effective_owner_ai_configuration()
        if not str(ai_cfg.get("api_key") or "").strip():
            QMessageBox.information(self, "SAI Analytic", "Подключите ключ ИИ владельца в SAI Admin.")
            return
        job = {"location_id": location_id, "config": ai_cfg}
        self._analytic_job = job; self.analyze_btn.setEnabled(False); self.analyze_btn.setText("Анализирую…")
        self.analytic_badge.setText("SAI ANALYTIC  ·  ИДЁТ АНАЛИЗ")
        self.analytic_title.setText("Ищу одно главное действие на ближайшие 7 дней…")
        self.analytic_why.setText("SAI отправляет только компактные агрегаты, без сырых чеков.")
        self.analytic_actions.clear()

        def worker() -> None:
            try:
                from sai_analytics_ai import run_ai_analysis
                with closing(sai_db.connect()) as con:
                    job["result"] = run_ai_analysis(
                        con, location_id=location_id, api_key=str(ai_cfg.get("api_key") or ""),
                        model=str(ai_cfg.get("model") or "gpt-5.6-luna"),
                        api_base=str(ai_cfg.get("api_base") or "https://api.openai.com/v1"),
                        proxy_url=str(ai_cfg.get("proxy_url") or ""),
                    )
            except Exception as exc:
                job["error"] = str(exc)
            self.analytic_finished.emit(job)

        threading.Thread(target=worker, daemon=True, name="sai-analytic").start()

    def _finish_analytic(self, job: dict) -> None:
        if job is not self._analytic_job:
            return
        self._analytic_job = None; self.analyze_btn.setEnabled(True); self.analyze_btn.setText("Провести анализ")
        if job.get("error"):
            self.analytic_hero.setProperty("level", "error")
            self.analytic_hero.style().unpolish(self.analytic_hero); self.analytic_hero.style().polish(self.analytic_hero)
            self.analytic_badge.setText("SAI ANALYTIC  ·  ОШИБКА")
            self.analytic_title.setText("Не удалось получить новый разбор")
            self.analytic_why.setText(str(job["error"])); self.analytic_actions.setText("Сохранённые данные не изменены")
            return
        self._show_recommendation(job.get("result") or {})

    def open_attention_product(self, row: int, _column: int = 0) -> None:
        item = self.attention_table.item(row, 0)
        product_id = str(item.data(Qt.UserRole) or "") if item else ""
        if not product_id:
            return
        self.tabs.setCurrentIndex(1)
        self.search.setText(item.text())
        self.apply_search_now()
        for candidate in range(self.balance_table.rowCount()):
            product_item = self.balance_table.item(candidate, 0)
            if product_item and str(product_item.data(Qt.UserRole) or "") == product_id:
                self.balance_table.selectRow(candidate)
                self.open_product_timeline()
                return

    def schedule_search(self, *_args) -> None:
        self.search_timer.start()

    def apply_search_now(self) -> None:
        self.search_timer.stop()
        self.refresh_balances()

    def reload_catalog(self, revision: tuple[int, str, int] | None = None) -> None:
        location_id = str(self.location_combo.currentData() or "")
        if not location_id:
            self._catalog_rows = []
            self.balance_table.setRowCount(0)
            self.balance_hint.setText("Создайте первое место хранения, чтобы начать учитывать остатки.")
            return
        with closing(sai_db.connect()) as con:
            service = StockService(con)
            self._catalog_rows = service.catalog_rows(location_id)
            self._catalog_revision = revision or service.catalog_revision()
        self.refresh_balances()

    def refresh_current_balances(self) -> None:
        location_id = str(self.location_combo.currentData() or "")
        if not location_id:
            self.refresh_balances()
            return
        with closing(sai_db.connect()) as con:
            service = StockService(con)
            current = service.location_balances(location_id)
            actual_ids = service.actual_balance_ids(location_id)
        for row in self._catalog_rows:
            row["balance"] = current.get(row["sai_product_id"], Decimal("0"))
            row["balance_actual"] = row["sai_product_id"] in actual_ids
        self.refresh_balances()

    def refresh_balances(self, *_args) -> None:
        rows, match_count = StockService.search_catalog_rows(
            self._catalog_rows, self.search.text(), limit=250,
        )
        self.balance_table.setUpdatesEnabled(False)
        self.balance_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            codes = ", ".join(row["barcodes"][:3])
            price = self._price_text(row["price"])
            # A fresh catalog row has no trustworthy stock information yet,
            # while a non-zero local ledger balance is still meaningful even
            # before the first SIGMA snapshot arrives.
            has_local_balance = Decimal(str(row.get("balance") or 0)) != 0
            balance = self._quantity_text(row["balance"]) if row.get("balance_actual") or has_local_balance else "—"
            values = (row["name"], row["article"], codes, price, balance)
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column == 0:
                    item.setData(Qt.UserRole, row["sai_product_id"])
                    item.setData(Qt.UserRole + 1, row["sigma_product_id"])
                    item.setData(Qt.UserRole + 2, tuple(row["barcodes"]))
                if column == 2:
                    item.setToolTip(
                        "Двойной клик — скопировать все ШК товара:\n" + "\n".join(row["barcodes"])
                        if row["barcodes"] else "У товара нет ШК"
                    )
                if column in (3, 4): item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.balance_table.setItem(row_index, column, item)
        self.balance_table.setUpdatesEnabled(True)
        total = len(self._catalog_rows)
        if self.search.text().strip():
            self.balance_hint.setText(
                f"Найдено: {match_count}. Показано первых {len(rows)}." if match_count > len(rows)
                else f"Найдено: {match_count}."
            )
        else:
            self.balance_hint.setText(f"Всего товаров: {total}. Для быстрого выбора начните поиск.")
        self.update_action_state()

    def refresh_movements(self) -> None:
        location_id = str(self.location_combo.currentData() or "")
        with closing(sai_db.connect()) as con:
            rows = StockService(con).movement_rows(location_id)
        names = {"receipt": "Приход", "writeoff": "Списание", "adjustment": "Инвентаризация", "sale": "Продажа", "return": "Возврат", "stock_snapshot": "Остаток SIGMA"}
        self.movement_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            quantity = "—" if row["quantity"] is None else self._signed_quantity(row["quantity"])
            values = (row["date"][:19].replace("T", " "), names.get(row["type"], row["type"]), row["product"], quantity, row["location"], row["note"])
            for column, value in enumerate(values): self.movement_table.setItem(row_index, column, QTableWidgetItem(str(value)))

    def update_action_state(self) -> None:
        enabled = bool(self.location_combo.currentData()) and self.selected_product_id() is not None
        for action in (self.receipt_action, self.writeoff_action, self.adjust_action):
            action.setEnabled(enabled)
        self.timeline_btn.setEnabled(enabled)
        self.operations_btn.setEnabled(enabled)
        self.sync_btn.setEnabled(bool(self.location_combo.currentData()) and self._warehouse_sync_job is None)
        self.hero_sync_btn.setEnabled(bool(self.location_combo.currentData()) and self._warehouse_sync_job is None)
        self.analyze_btn.setEnabled(bool(self.location_combo.currentData()) and self._analytic_job is None)

    def _set_sync_status(self, text: str) -> None:
        value = str(text or "").strip()
        self.sync_status.setText(value)
        self.sync_status.setVisible(bool(value))

    def sync_warehouse_data(self) -> None:
        location_id = str(self.location_combo.currentData() or "")
        if not location_id or self._warehouse_sync_job is not None:
            return
        job: dict = {"location_id": location_id}
        self._warehouse_sync_job = job
        self.sync_btn.setEnabled(False)
        self.hero_sync_btn.setEnabled(False)
        self.sync_btn.setText("Обновляю…")
        self._set_sync_status(
            "Получаю остатки и архив статистики с 1 января 2026 года. "
            "Первый запуск может быть очень долгим; его можно продолжить позднее."
        )

        def worker() -> None:
            try:
                with closing(sai_db.connect()) as con:
                    from sai_sigma_warehouse_sync import run_warehouse_sync_with_session_refresh
                    job["result"] = run_warehouse_sync_with_session_refresh(
                        con, location_id, progress=self.sigma_sync_progress.emit,
                    )
            except Exception as exc:
                job["error"] = str(exc)
            self.sigma_sync_finished.emit(job)

        threading.Thread(target=worker, daemon=True, name="sai-warehouse-sync").start()

    def _show_warehouse_sync_progress(self, payload: dict) -> None:
        phase = str(payload.get("phase") or "")
        if phase == "stock":
            self._set_sync_status(
                f"Остатки готовы: {int(payload.get('stock', 0))} товаров. Получаю продажи…"
            )
            self.refresh_current_balances()
        elif phase == "sales_staged":
            self._set_sync_status(
                f"Продажи уже доступны: {int(payload.get('sale_lines', 0))} новых строк. "
                "Уточняю цены чеков в фоне…"
            )
            self.refresh_movements()
        elif phase == "sale_prices":
            self._set_sync_status(
                f"Продажи доступны. Уточнены цены в {int(payload.get('sale_prices', 0))} строках…"
            )
        elif phase == "history_period":
            self._set_sync_status(
                f"Архив 2026: период {int(payload.get('period', 0))} из "
                f"{int(payload.get('periods', 0))} · "
                f"{payload.get('period_start', '')} — {payload.get('period_end', '')}. "
                "Уже готовые периоды повторно не скачиваются."
            )
        elif phase == "auth_refresh":
            self._set_sync_status(
                "Сессия SIGMA истекла. SAI выполняет один общий вход и продолжит архив автоматически…"
            )
        elif phase == "analytics_ready":
            self.refresh_analytics()
            if payload.get("source_errors"):
                self._set_sync_status("Часть данных не обновлена. " + "; ".join(payload["source_errors"].values()))
                return
            self._set_sync_status(
                f"Обработано: {int(payload.get('archive_sale_operations', 0))} чеков, "
                f"{int(payload.get('archive_sale_lines', 0))} товарных строк. "
                "Витрина для SAI Analytic обновлена."
            )

    def _finish_warehouse_sync(self, job: dict) -> None:
        if job is not self._warehouse_sync_job:
            return
        self._warehouse_sync_job = None
        self.sync_btn.setText("Докачать архив")
        self.hero_sync_btn.setEnabled(bool(self.location_combo.currentData()))
        self.sync_btn.setEnabled(bool(self.location_combo.currentData()))
        if job.get("error"):
            self.refresh()
            self._set_sync_status(f"Не удалось обновить склад: {job['error']}")
            return
        result = job.get("result") or {}
        if result.get("_sync_state") == "busy":
            self._set_sync_status("Склад уже обновляется другим процессом SAI. Повторный запуск не требуется.")
            return
        if result.get("source_errors"):
            self.refresh()
            self._set_sync_status("Обновление завершено частично. " + "; ".join(result["source_errors"].values()))
            return
        self._set_sync_status(
            f"Остатки обновлены: {int(result.get('stock', 0))} товаров. "
            f"В архиве: {int(result.get('archive_sale_operations', 0))} чеков и "
            f"{int(result.get('archive_sale_lines', 0))} товарных строк с 01.01.2026."
        )
        # refresh() also reloads changed catalog identities and movement rows.
        self.refresh()

    def selected_product_id(self) -> str | None:
        row = self.balance_table.currentRow()
        item = self.balance_table.item(row, 0) if row >= 0 else None
        return str(item.data(Qt.UserRole)) if item and item.data(Qt.UserRole) else None

    def selected_product_name(self) -> str:
        item = self.balance_table.item(self.balance_table.currentRow(), 0)
        return item.text() if item else ""

    def open_product_timeline(self) -> None:
        product_id = self.selected_product_id()
        if not product_id:
            return
        location_id = str(self.location_combo.currentData() or "")
        current_row = self.balance_table.currentRow()
        article_item = self.balance_table.item(current_row, 1)
        barcodes = self.product_barcodes_at(current_row)
        with closing(sai_db.connect()) as con:
            service = StockService(con)
            rows = service.product_timeline_rows(product_id)
            summary = service.product_dashboard(product_id, location_id)

        dialog = QDialog(self)
        dialog.setWindowTitle("Товар · история и показатели")
        dialog.resize(1180, 820)
        from sai_design_tokens import stock_dashboard_stylesheet
        app = QApplication.instance()
        dialog.setStyleSheet(stock_dashboard_stylesheet(bool(app and app.property("saiNightTheme"))))
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(20, 18, 20, 16)
        layout.setSpacing(12)

        hero = QFrame(); hero.setObjectName("ProductHeroCard")
        hero_layout = QHBoxLayout(hero); hero_layout.setContentsMargins(16, 14, 16, 14)
        identity = QVBoxLayout(); identity.setSpacing(5)
        title = QLabel(self.selected_product_name()); title.setObjectName("ProductName")
        title.setWordWrap(True)
        note = QLabel(
            f"Артикул: {(article_item.text() if article_item else '—') or '—'}   ·   "
            f"ШК: {', '.join(barcodes) or '—'}"
        )
        note.setObjectName("ProductIdentity")
        note.setWordWrap(True)
        note.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        title.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        identity.addWidget(title); identity.addWidget(note)
        copy_barcode_btn = QPushButton("Копировать ШК")
        copy_barcode_btn.setObjectName("TimelineModeButton")
        copy_barcode_btn.setEnabled(bool(barcodes))
        copy_barcode_btn.setToolTip("Скопировать все ШК товара, каждый с новой строки")

        def copy_barcodes() -> None:
            QApplication.clipboard().setText("\n".join(barcodes))
            copy_barcode_btn.setText("ШК скопирован" if len(barcodes) == 1 else "ШК скопированы")

        copy_barcode_btn.clicked.connect(copy_barcodes)
        identity.addWidget(copy_barcode_btn, 0, Qt.AlignLeft)
        hero_layout.addLayout(identity, 1)
        actual = summary.get("actual_balance")
        captured = str(summary.get("captured_at") or "")[:16].replace("T", " ")
        badge = QLabel("Остаток синхронизирован" if actual is not None else "Ожидаю синхронизацию")
        badge.setObjectName("ProductSyncBadge"); hero_layout.addWidget(badge, 0, Qt.AlignTop)
        layout.addWidget(hero)

        metrics = QGridLayout()
        metrics.setHorizontalSpacing(10)
        metrics.addWidget(_card(
            "Фактический остаток",
            "—" if actual is None else self._quantity_text(actual),
            "ещё не получен из SIGMA" if actual is None else f"обновлено {captured}",
            "blue",
        ), 0, 0)
        metrics.addWidget(_card(
            "Продано за 7 дней", self._quantity_text(summary.get("sold_7") or 0), "поштучно по чекам", "green",
        ), 0, 1)
        metrics.addWidget(_card(
            "Продано за 30 дней", self._quantity_text(summary.get("sold_30") or 0), "поштучно по чекам", "amber",
        ), 0, 2)
        metrics.addWidget(_card(
            "Выручка за 30 дней", self._price_text(summary.get("revenue_30") or 0), "по этому товару", "violet",
        ), 0, 3)
        layout.addLayout(metrics)

        timeline_card = QFrame(); timeline_card.setObjectName("TimelineCard")
        timeline_layout = QVBoxLayout(timeline_card)
        timeline_layout.setContentsMargins(14, 12, 14, 10); timeline_layout.setSpacing(6)
        timeline_header = QHBoxLayout(); timeline_header.setSpacing(7)
        visual_title = QLabel("Таймлайн товара"); visual_title.setObjectName("TimelineTitle")
        timeline_header.addWidget(visual_title); timeline_header.addStretch(1)

        relative_button = QPushButton("Равномерно"); relative_button.setObjectName("TimelineModeButton")
        real_button = QPushButton("По времени"); real_button.setObjectName("TimelineModeButton")
        for button in (relative_button, real_button):
            button.setCheckable(True)
        relative_button.setChecked(True)
        modes = QButtonGroup(dialog); modes.setExclusive(True)
        modes.addButton(relative_button); modes.addButton(real_button)
        timeline_header.addWidget(relative_button); timeline_header.addWidget(real_button)

        filter_button = QToolButton(); filter_button.setObjectName("TimelineFilterButton")
        filter_button.setIcon(QIcon(str(Path(__file__).resolve().parent / "assets" / "icons" / "mdi" / "filter-variant.svg")))
        filter_button.setIconSize(filter_button.iconSize())
        filter_button.setToolTip("Какие события показывать")
        filter_menu = QMenu(filter_button)
        filter_groups = {
            "Создание карточки": {"product_created"},
            "Поступления": {"receipt"},
            "Продажи": {"sale"},
            "Возвраты": {"return"},
            "Инвентаризации и списания": {"adjustment", "writeoff"},
            "Снимки остатков SIGMA": {"stock_snapshot"},
            "Изменения цен": {"price_change"},
        }
        filter_actions: list[tuple[QAction, set[str]]] = []
        for text, event_types in filter_groups.items():
            action = QAction(text, filter_menu); action.setCheckable(True); action.setChecked(True)
            filter_menu.addAction(action); filter_actions.append((action, event_types))
        filter_button.setMenu(filter_menu); filter_button.setPopupMode(QToolButton.InstantPopup)
        timeline_header.addWidget(filter_button)
        timeline_layout.addLayout(timeline_header)

        visual_timeline = ProductTimelineWidget(rows, timeline_card)
        relative_button.clicked.connect(lambda: visual_timeline.set_mode("relative"))
        real_button.clicked.connect(lambda: visual_timeline.set_mode("real"))

        def apply_timeline_filters(*_args) -> None:
            selected: set[str] = set()
            for action, event_types in filter_actions:
                if action.isChecked():
                    selected.update(event_types)
            visual_timeline.set_visible_types(selected)

        for action, _event_types in filter_actions:
            action.toggled.connect(apply_timeline_filters)
        timeline_layout.addWidget(visual_timeline)
        layout.addWidget(timeline_card)

        timeline_title = QLabel("Подробные события")
        timeline_title.setObjectName("TimelineTitle")
        layout.addWidget(timeline_title)

        table = self._table(("Дата", "Событие", "Количество", "Закупка", "Продажа", "Документ", "Комментарий"))
        header = table.horizontalHeader()
        header.setSectionResizeMode(6, QHeaderView.Stretch)
        for column, width in ((0, 155), (1, 150), (2, 95), (3, 95), (4, 95), (5, 145)):
            header.setSectionResizeMode(column, QHeaderView.Interactive)
            header.resizeSection(column, width)
        labels = {
            "product_created": "Создана карточка",
            "receipt": "Поступление",
            "writeoff": "Списание",
            "adjustment": "Инвентаризация",
            "sale": "Продажа",
            "return": "Возврат",
            "price_change": "Изменение цены",
            "stock_snapshot": "Остаток SIGMA",
        }
        table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            quantity = row.get("quantity")
            buying = row.get("unit_cost")
            selling = row.get("selling_price")
            document = row.get("document") or "—"
            location = row.get("location") or ""
            note_text = row.get("note") or ""
            if location:
                note_text = f"{note_text} · {location}" if note_text else location
            values = (
                str(row.get("date") or "")[:19].replace("T", " "),
                labels.get(str(row.get("type") or ""), str(row.get("type") or "")),
                self._signed_quantity(quantity) if quantity is not None else "—",
                self._price_text(buying) if buying is not None else "—",
                self._price_text(selling) if selling is not None else "—",
                document,
                note_text or "—",
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if column in (2, 3, 4):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(row_index, column, item)
        layout.addWidget(table, 1)
        empty = QLabel("Для этого товара события пока не записаны.")
        empty.setObjectName("InlineStatus")
        empty.setVisible(not rows)
        layout.addWidget(empty)
        actions = QHBoxLayout(); actions.addStretch(1)
        close_button = QPushButton("Закрыть"); close_button.setObjectName("SoftButton")
        close_button.clicked.connect(dialog.accept); actions.addWidget(close_button)
        layout.addLayout(actions)
        dialog.exec()

    def create_location(self) -> None:
        name, accepted = QInputDialog.getText(self, "Новое место хранения", "Название, например «Основной магазин»")
        if not accepted or not name.strip(): return
        location_id = str(uuid.uuid4())
        with closing(sai_db.connect()) as con:
            StockService(con).ensure_location(location_id, name.strip())
        self.refresh(); index = self.location_combo.findData(location_id)
        if index >= 0: self.location_combo.setCurrentIndex(index)

    def open_operation(self, operation: str) -> None:
        if not self.selected_product_id(): return
        labels = {"receipt": "Оприходовать товар", "writeoff": "Списать товар", "adjustment": "Уточнить фактический остаток"}
        dialog = QDialog(self); dialog.setWindowTitle(labels[operation]); dialog.setMinimumWidth(420)
        layout = QVBoxLayout(dialog); title = QLabel(self.selected_product_name()); title.setObjectName("WorkbenchSection"); layout.addWidget(title)
        form = QFormLayout(); quantity = QLineEdit(); quantity.setObjectName("WorkbenchInput"); quantity.setPlaceholderText("0")
        note = QLineEdit(); note.setObjectName("WorkbenchInput"); note.setPlaceholderText("Причина или документ")
        form.addRow("Фактический остаток" if operation == "adjustment" else "Количество", quantity); form.addRow("Комментарий", note); layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel); buttons.button(QDialogButtonBox.Save).setText("Сохранить")
        buttons.accepted.connect(dialog.accept); buttons.rejected.connect(dialog.reject); layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted: return
        try: self.post_selected_movement(operation, Decimal(quantity.text().replace(",", ".")), note.text())
        except Exception as exc: QMessageBox.warning(self, "Склад", str(exc))

    def post_selected_movement(self, operation: str, quantity: Decimal, note: str = "") -> None:
        product_id = self.selected_product_id(); location_id = str(self.location_combo.currentData() or "")
        if not product_id or not location_id: raise ValueError("Выберите товар и место хранения")
        with closing(sai_db.connect()) as con:
            StockService(con).post_manual(sai_product_id=product_id, location_id=location_id, operation=operation, quantity=quantity, note=note)
        self.refresh_current_balances(); self.refresh_analytics(); self.refresh_movements()

    @staticmethod
    def _quantity_text(value: Decimal) -> str:
        if not value:
            return "0"
        number = Decimal(str(value))
        if number == number.to_integral_value():
            return f"{int(number):,}".replace(",", " ")
        return format(number.normalize(), "f").replace(".", ",")

    @staticmethod
    def _price_text(value: Decimal) -> str:
        if not value:
            return "—"
        whole = f"{Decimal(str(value)):,.2f}".replace(",", " ").replace(".", ",")
        return whole + " ₽"

    @staticmethod
    def _signed_quantity(value: Decimal) -> str:
        text = WarehousePage._quantity_text(abs(value))
        return f"+{text}" if value > 0 else f"-{text}" if value < 0 else "0"
