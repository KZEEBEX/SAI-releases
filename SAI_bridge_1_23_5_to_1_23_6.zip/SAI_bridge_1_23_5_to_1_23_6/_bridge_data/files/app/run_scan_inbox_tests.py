#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pathlib import Path

import sai_scan_inbox as scans


def item(name: str, minute: int) -> scans.ScanCandidate:
    return scans.ScanCandidate(Path(name), minute * 60 * 1_000_000_000, 100)


def main() -> int:
    batch = scans.newest_contiguous_batch([
        item("old.pdf", 0),
        item("scan-1.pdf", 30),
        item("scan-2.pdf", 38),
        item("scan-3.jpg", 48),
    ])
    assert [entry.path.name for entry in batch] == ["scan-1.pdf", "scan-2.pdf", "scan-3.jpg"]
    assert scans.batch_marker(batch) == 48 * 60 * 1_000_000_000
    assert scans.newest_contiguous_batch([]) == []
    print("scan inbox tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
