#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import os,sys,tempfile,inspect
from pathlib import Path
root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_ac_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as m
assert m.CONTRACT_VERSION=='invoice_ai_contract_v8'
assert m.PROMPT_VERSION=='invoice_prompt_v7'
assert m.AUDIT_PROMPT_VERSION=='invoice_audit_prompt_v4'
assert m.AI_CACHE_DIR.name=='openai_invoice_v8'
source=(root/'app'/'sai_openai_invoice.py').read_text(encoding='utf-8')
assert 'QTransform().rotate(-90)' in source
assert 'QTransform().rotate(90)' not in source
assert 'поворот против часовой стрелки на 90°' in source
assert 'исходная ориентация, полный лист' not in source
assert (root/'config'/'ai'/'invoice_prompt_v7.txt').is_file()
assert (root/'config'/'ai'/'invoice_audit_prompt_v4.txt').is_file()
print('PATCH_AC_SELF_TEST_OK')
