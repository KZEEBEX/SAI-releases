#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

from sai_core_v2.semi_auto_receipt import (
    ean_checksum,
    existing_barcodes,
    find_barcode_owner,
    is_valid_ean,
    label_copies,
    merge_barcodes,
    missing_indices,
    next_internal_barcode,
    next_missing_index,
    parse_scan_barcodes,
    progress,
    row_barcodes,
    with_label_quantity,
    with_quantity,
)
from sai_semi_auto import SemiAutoReceiptService


def test_barcode_parser() -> None:
    valid = "4006381333931"
    assert is_valid_ean(valid, 13)
    assert ean_checksum(valid[:-1]) == int(valid[-1])
    parsed = parse_scan_barcodes(valid)
    assert parsed.codes == (valid,) and not parsed.error and not parsed.wait_more
    invalid_checksum = parse_scan_barcodes("4006381333932")
    assert invalid_checksum.codes == ("4006381333932",)
    assert "контрольная цифра" in invalid_checksum.warnings[0]
    assert parse_scan_barcodes("1234").wait_more
    forced = parse_scan_barcodes("12345", force=True)
    assert forced.codes == ("12345",) and "принят вручную" in forced.warnings[0]
    assert "только цифры" in parse_scan_barcodes("ABC").error
    multiple = parse_scan_barcodes(f"{valid}, {valid}")
    assert multiple.codes == (valid,)


def test_rows_duplicates_and_progress() -> None:
    rows = [
        {"name": "A", "qty": 2, "barcodes": ["4006381333931"]},
        {"name": "B", "qty": 1, "barcode_cell": ""},
        {"name": "C", "qty": 0, "barcodes": []},
        {"name": "D", "qty": "", "barcodes": []},
    ]
    assert row_barcodes(rows[0]) == ("4006381333931",)
    assert missing_indices(rows) == (1, 3)
    assert find_barcode_owner(rows, "4006381333931", current_index=1) == 0
    assert next_missing_index(rows, start=1, wrap=False) == 3
    assert next_missing_index(rows, start=3, wrap=True) == 1
    snapshot = progress(rows)
    assert (snapshot.total, snapshot.done, snapshot.missing, snapshot.zero_quantity) == (4, 2, 2, 1)
    assert snapshot.percent == 50 and not snapshot.complete


def test_immutable_row_updates() -> None:
    original = {"name": "A", "qty": 2, "future_field": "keep"}
    merged = merge_barcodes(original, ["12345", "12345"], warnings=["warning"])
    assert original.get("barcodes") is None
    assert merged["barcodes"] == ["12345"] and merged["future_field"] == "keep"
    assert merged["barcode_warning"] == "warning"
    shortage = with_quantity(original, 0)
    assert shortage["qty"] == 0 and "Недовоз" in shortage["comment"]
    restored = with_quantity(shortage, 3)
    assert restored["qty"] == 3
    labels = with_label_quantity(restored, 7)
    assert label_copies(labels) == 7
    assert label_copies(with_quantity(labels, 0)) == 0
    try:
        with_label_quantity(restored, "abc")
    except ValueError:
        pass
    else:
        raise AssertionError("invalid label quantity must be rejected")


def test_internal_barcode_policy() -> None:
    first = next_internal_barcode(set(), prefix="77", start_counter=1)
    assert first is not None
    code, counter = first
    assert counter == 1 and len(code) == 13 and code.startswith("77") and is_valid_ean(code, 13)
    second = next_internal_barcode({code}, prefix="77", start_counter=1)
    assert second is not None and second[0] != code and second[1] == 2
    assert code in existing_barcodes([{"barcodes": [code]}])


def test_facade_and_boundaries() -> None:
    service = SemiAutoReceiptService()
    rows = [{"qty": 1, "barcodes": []}, {"qty": 0, "barcodes": []}]
    assert service.missing_indices(rows) == [0]
    assert service.next_missing(rows, start=-1, wrap=True) == 0
    assert service.progress(rows).zero_quantity == 1

    main_text = (APP_DIR / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    service_text = (APP_DIR / "sai_semi_auto.py").read_text(encoding="utf-8-sig")
    core_text = (APP_DIR / "sai_core_v2" / "semi_auto_receipt.py").read_text(encoding="utf-8-sig")
    assert "from sai_semi_auto import SemiAutoReceiptService" in main_text
    assert "self.semi_service = SemiAutoWorkflowService()" in main_text
    semi_segment = main_text[main_text.index("class SemiAutoReceiptPage"):main_text.index("class AIInvoiceSignals")]
    assert "self.semi_service.parse_scan" in semi_segment
    assert "self.semi_service.merge_barcodes" in semi_segment
    assert "self.semi_service.next_internal_barcode" in semi_segment
    assert "for chunk in chunks" not in semi_segment
    assert "PySide6" not in service_text and "PySide6" not in core_text
    for forbidden in ("sqlite3", "QMessageBox", "sai_receipt_drafts", "sai_package"):
        assert forbidden not in core_text


def main() -> int:
    test_barcode_parser()
    test_rows_duplicates_and_progress()
    test_immutable_row_updates()
    test_internal_barcode_policy()
    test_facade_and_boundaries()
    print("Semi-auto receipt refactor tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
