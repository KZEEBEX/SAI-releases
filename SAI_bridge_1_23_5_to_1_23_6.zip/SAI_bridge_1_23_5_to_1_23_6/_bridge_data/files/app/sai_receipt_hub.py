#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Receipt hub presentation components.

This module owns the start-screen action widgets and the unfinished-receipts
dialog.  It intentionally depends only on Qt and the stable
``sai_receipt_drafts`` facade, keeping the main application shell free from
receipt-specific presentation details.
"""
from __future__ import annotations

import datetime as dt
import math
from pathlib import Path
from typing import Any, Dict, Optional

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import (
    QColor, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap,
    QRadialGradient, QRegion,
)
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QDialog, QFrame, QHeaderView,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy, QTableWidget,
    QTableWidgetItem, QVBoxLayout,
)

from sai_notifications import QMessageBox
import sai_receipt_drafts
from sai_design_tokens import METRICS


def safe_str(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    return text.replace("import_required", "нужен импорт").replace("ready", "готово")


def money(value: Any) -> str:
    try:
        return f"{float(value):,.2f}".replace(",", " ")
    except Exception:
        return ""


def make_standard_page_header(title_text: str, subtitle_text: str) -> QFrame:
    header = QFrame()
    header.setObjectName("PageHeader")
    layout = QVBoxLayout(header)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(5)
    title = QLabel(title_text)
    title.setObjectName("PageHeaderTitle")
    subtitle = QLabel(subtitle_text)
    subtitle.setObjectName("PageHeaderSubtitle")
    subtitle.setWordWrap(True)
    layout.addWidget(title)
    layout.addWidget(subtitle)
    return header


class RoundedTableWidget(QTableWidget):
    """Table clipped by one rounded outer contour."""

    CORNER_RADIUS = float(METRICS["table_radius"])

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().resizeEvent(event)
        if self.width() <= 1 or self.height() <= 1:
            return
        path = QPainterPath()
        contour = QRectF(self.rect()).adjusted(0.0, 0.0, -0.5, -0.5)
        path.addRoundedRect(contour, self.CORNER_RADIUS, self.CORNER_RADIUS)
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))


class UxTwoLineButton(QPushButton):
    """Action button with real two-level text hierarchy.

    A newline inside QPushButton has one font for both lines. This widget keeps
    the action name bold and the explanation lighter without relying on rich
    text support in native buttons.
    """

    def __init__(self, title: str, subtitle: str, primary: bool = False, large: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.setText("")
        self.setObjectName(
            "UxNewReceiptButton" if large else ("UxSourceActionPrimary" if primary else "UxSourceAction")
        )
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(108 if large else 68)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22 if large else 15, 14 if large else 10, 18, 14 if large else 10)
        layout.setSpacing(4 if large else 2)
        layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        self.title_label = QLabel(title)
        self.title_label.setObjectName(
            "UxActionTitlePrimaryLarge" if large else ("UxActionTitlePrimary" if primary else "UxActionTitle")
        )
        self.title_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.title_label.setWordWrap(False)
        layout.addWidget(self.title_label)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName(
            "UxActionSubtitlePrimaryLarge" if large else ("UxActionSubtitlePrimary" if primary else "UxActionSubtitle")
        )
        self.subtitle_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.subtitle_label.setWordWrap(True)
        layout.addWidget(self.subtitle_label)

class DraftsTileButton(UxTwoLineButton):
    """Two-line action tile with a live, non-layout-shifting draft counter."""

    def __init__(self, title: str, subtitle: str, parent=None) -> None:
        super().__init__(title, subtitle, primary=False, large=False, parent=parent)
        self.badge_label = QLabel(self)
        self.badge_label.setObjectName("DraftCountBadge")
        self.badge_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.badge_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.badge_label.setStyleSheet(
            "QLabel#DraftCountBadge {"
            "background: #ef4444; color: #ffffff; border: none;"
            "border-radius: 10px; font-size: 10px; font-weight: 900; padding: 0;"
            "}"
        )
        self.badge_label.hide()
        self._draft_count = 0

    def set_draft_count(self, count: int) -> None:
        value = max(0, int(count))
        self._draft_count = value
        if value <= 0:
            self.badge_label.hide()
            return
        text = str(value)
        width = 20 if len(text) == 1 else max(24, 12 + len(text) * 7)
        self.badge_label.setText(text)
        self.badge_label.setFixedSize(width, 20)
        self._position_badge()
        self.badge_label.show()
        self.badge_label.raise_()

    def _position_badge(self) -> None:
        self.badge_label.move(max(8, self.width() - self.badge_label.width() - 10), 8)

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().resizeEvent(event)
        self._position_badge()


class ManualReceiptTileButton(UxTwoLineButton):
    """Manual-receipt tile with a secondary new-document action inside it."""

    def __init__(self, title: str, subtitle: str, parent=None) -> None:
        super().__init__(title, subtitle, primary=False, large=False, parent=parent)
        self.layout().setContentsMargins(15, 10, 142, 10)
        self.new_button = QPushButton("Создать новую", self)
        self.new_button.setObjectName("ManualReceiptNewButton")
        self.new_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.new_button.setFixedSize(122, 34)
        self._position_new_button()

    def _position_new_button(self) -> None:
        self.new_button.move(
            max(8, self.width() - self.new_button.width() - 14),
            max(8, (self.height() - self.new_button.height()) // 2),
        )
        self.new_button.raise_()

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().resizeEvent(event)
        self._position_new_button()

class NewReceiptHeroButton(QPushButton):
    """Premium SAI hero action with a transparent, cropped ribbon mark.

    The logo deliberately extends beyond the button composition instead of
    sitting inside a white image card.  Hovering gently moves the mark, light
    sweep and constellation points without changing layout geometry.
    """

    def __init__(self, title: str, subtitle: str, parent=None) -> None:
        super().__init__(parent)
        self.setText("")
        self.setObjectName("NewReceiptHeroButton")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(172)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_Hover, True)
        self._hover_target = 0.0
        self._hover_progress = 0.0
        self._motion_phase = 0.0
        self._motion_timer = QTimer(self)
        self._motion_timer.setInterval(16)
        self._motion_timer.timeout.connect(self._animate_hover)
        logo_path = Path(__file__).resolve().parent / "assets" / "sai_logo_transparent.png"
        self._logo = QPixmap(str(logo_path)) if logo_path.exists() else QPixmap()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 275, 25)
        layout.setSpacing(6)
        layout.setAlignment(Qt.AlignmentFlag.AlignVCenter)

        self.title_label = QLabel(title)
        self.title_label.setObjectName("NewReceiptHeroTitle")
        self.title_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        layout.addWidget(self.title_label)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName("NewReceiptHeroSubtitle")
        self.subtitle_label.setWordWrap(True)
        self.subtitle_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        layout.addWidget(self.subtitle_label)

    def enterEvent(self, event) -> None:  # noqa: N802
        self._hover_target = 1.0
        if not self._motion_timer.isActive():
            self._motion_timer.start()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._hover_target = 0.0
        if not self._motion_timer.isActive():
            self._motion_timer.start()
        super().leaveEvent(event)

    def _animate_hover(self) -> None:
        delta = self._hover_target - self._hover_progress
        if abs(delta) < 0.006:
            self._hover_progress = self._hover_target
            if self._hover_target == 0.0:
                self._motion_timer.stop()
        else:
            self._hover_progress += delta * 0.14
        self._motion_phase += 0.045
        self.update()

    @staticmethod
    def _ease(value: float) -> float:
        value = max(0.0, min(1.0, value))
        return value * value * (3.0 - 2.0 * value)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        radius = 18.0
        path = QPainterPath()
        path.addRoundedRect(rect, radius, radius)
        hover = self._ease(self._hover_progress)
        pressed = 1.0 if self.isDown() else 0.0

        gradient = QLinearGradient(
            QPointF(rect.left() - rect.width() * 0.06, rect.bottom()),
            QPointF(rect.right() + rect.width() * (0.08 + 0.05 * hover), rect.top()),
        )
        if self.isEnabled():
            gradient.setColorAt(0.00, QColor("#112b9f" if hover < 0.5 else "#142fb0"))
            gradient.setColorAt(0.38, QColor("#075fd3" if hover < 0.5 else "#0872e5"))
            gradient.setColorAt(0.72, QColor("#099edc" if hover < 0.5 else "#0bb4e8"))
            gradient.setColorAt(1.00, QColor("#18d3df" if hover < 0.5 else "#2de3e8"))
        else:
            gradient.setColorAt(0.0, QColor("#334155"))
            gradient.setColorAt(1.0, QColor("#475569"))
        painter.fillPath(path, gradient)

        # A restrained inner edge gives depth without looking like a separate card.
        painter.setPen(QPen(QColor(255, 255, 255, int(58 + 38 * hover)), 1.15))
        painter.drawPath(path)
        inner = QPainterPath()
        inner.addRoundedRect(rect.adjusted(1.8, 1.8, -1.8, -1.8), radius - 2, radius - 2)
        painter.setPen(QPen(QColor(3, 32, 102, int(52 - 18 * hover)), 1.0))
        painter.drawPath(inner)

        painter.save()
        painter.setClipPath(path)

        # Atmospheric glow behind the oversized logo.
        glow_center = QPointF(rect.right() - 105 - 9 * hover, rect.center().y() - 10)
        glow = QRadialGradient(glow_center, 270 + 20 * hover)
        glow.setColorAt(0.0, QColor(225, 250, 255, int(78 + 42 * hover)))
        glow.setColorAt(0.42, QColor(83, 205, 255, int(42 + 24 * hover)))
        glow.setColorAt(1.0, QColor(20, 100, 220, 0))
        painter.fillPath(path, glow)

        # Fine constellation: points drift a few pixels on hover, never affecting layout.
        for row in range(4):
            for col in range(9):
                base_x = rect.left() + 34 + col * max(34.0, rect.width() / 10.8)
                base_y = rect.top() + 26 + row * 34
                wave = math.sin(self._motion_phase + col * 0.72 + row * 0.91)
                x = base_x + hover * (2.2 + (col % 3)) * wave
                y = base_y + hover * 2.0 * math.cos(self._motion_phase * 0.8 + row + col * 0.3)
                alpha = int(24 + (22 if (row + col) % 3 == 0 else 8) + 34 * hover)
                size = 1.2 + (0.7 if (row * 2 + col) % 5 == 0 else 0.0) + 0.35 * hover
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(235, 252, 255, alpha))
                painter.drawEllipse(QPointF(x, y), size, size)

        # A quiet flowing ribbon line links the button to the SAI mark.
        ribbon = QPainterPath(QPointF(rect.left() + rect.width() * 0.47, rect.bottom() - 27))
        ribbon.cubicTo(
            QPointF(rect.left() + rect.width() * 0.60, rect.bottom() - 51 - 5 * hover),
            QPointF(rect.right() - 245, rect.top() + 42 + 6 * hover),
            QPointF(rect.right() - 70, rect.top() + 30),
        )
        ribbon_pen = QPen(QColor(210, 248, 255, int(38 + 34 * hover)), 1.25 + 0.25 * hover)
        ribbon_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(ribbon_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(ribbon)

        # Oversized transparent logo: angled and intentionally cropped by the hero edge.
        if not self._logo.isNull():
            painter.save()
            center = QPointF(rect.right() - 104 - 10 * hover, rect.center().y() + 6 - 4 * hover)
            painter.translate(center)
            painter.rotate(-13.0 + 4.0 * hover)
            scale = (0.48 + 0.025 * hover) * (0.985 if pressed else 1.0)
            width = self._logo.width() * scale
            height = self._logo.height() * scale
            target = QRectF(-width / 2, -height / 2, width, height)
            painter.setOpacity(0.82 + 0.15 * hover)
            painter.drawPixmap(target, self._logo, QRectF(self._logo.rect()))
            painter.restore()

        # A small moving sheen gives immediate hover feedback.
        sheen_x = rect.left() - rect.width() * 0.35 + (rect.width() * 1.55) * hover
        sheen = QLinearGradient(QPointF(sheen_x - 85, rect.top()), QPointF(sheen_x + 85, rect.bottom()))
        sheen.setColorAt(0.0, QColor(255, 255, 255, 0))
        sheen.setColorAt(0.5, QColor(255, 255, 255, int(20 + 30 * hover)))
        sheen.setColorAt(1.0, QColor(255, 255, 255, 0))
        painter.fillPath(path, sheen)
        painter.restore()

class ReceiptDraftsDialog(QDialog):
    """List unfinished receipts without exposing internal files."""

    def __init__(self, parent_page: "MainPage", parent=None) -> None:
        super().__init__(parent or parent_page)
        self.parent_page = parent_page
        self.selected: Optional[Dict[str, Any]] = None
        self.setObjectName("ReceiptDraftsDialog")
        self.setWindowTitle("Черновики")
        self.resize(900, 500)

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(14)
        root.addWidget(make_standard_page_header(
            "Черновики",
            "Незавершённые привозы сохраняются внутри SAI автоматически.",
        ))

        self.table = RoundedTableWidget(0, 6)
        self.table.setObjectName("ReceiptDraftsTable")
        self.table.setHorizontalHeaderLabels(["Поставщик", "Дата", "Закупка", "Позиций", "Этап", "Изменён"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for col in range(1, 6):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.ResizeToContents)
        self.table.cellDoubleClicked.connect(lambda *_: self.open_selected())
        root.addWidget(self.table, 1)

        self.empty_label = QLabel("Активных черновиков нет")
        self.empty_label.setObjectName("InlineStatus")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(self.empty_label)

        actions = QHBoxLayout()
        self.delete_btn = QPushButton("Удалить черновик")
        self.delete_btn.setObjectName("SoftButton")
        self.delete_btn.clicked.connect(self.delete_selected)
        self.print_ndp_btn = QPushButton("Печатать НДП")
        self.print_ndp_btn.setObjectName("SoftButton")
        self.print_ndp_btn.setToolTip("Распечатать НДП сейчас — приход и штрихкоды для этого не требуются")
        self.print_ndp_btn.clicked.connect(self.print_selected_ndp)
        self.cancel_btn = QPushButton("Закрыть")
        self.cancel_btn.setObjectName("SoftButton")
        self.cancel_btn.clicked.connect(self.reject)
        self.open_btn = QPushButton("Продолжить")
        self.open_btn.setObjectName("WorkbenchPrimaryButton")
        self.open_btn.clicked.connect(self.open_selected)
        actions.addWidget(self.delete_btn)
        actions.addWidget(self.print_ndp_btn)
        actions.addStretch(1)
        actions.addWidget(self.cancel_btn)
        actions.addWidget(self.open_btn)
        root.addLayout(actions)
        self.reload()

    @staticmethod
    def _display_date(raw: Any) -> str:
        text = safe_str(raw)
        if not text:
            return "—"
        for fmt in ("%Y-%m-%d", "%d.%m.%Y"):
            try:
                return dt.datetime.strptime(text[:10], fmt).strftime("%d.%m.%Y")
            except Exception:
                pass
        return text

    @staticmethod
    def _display_updated(raw: Any) -> str:
        text = safe_str(raw)
        if not text:
            return "—"
        try:
            value = dt.datetime.fromisoformat(text)
            return value.strftime("%d.%m %H:%M")
        except Exception:
            return text

    def reload(self) -> None:
        rows = sai_receipt_drafts.list_active()
        self.table.setRowCount(len(rows))
        for r, draft in enumerate(rows):
            values = [
                safe_str(draft.get("supplier")) or "—",
                self._display_date(draft.get("invoice_date")),
                money(draft.get("purchase_total") or 0),
                str(int(draft.get("item_count") or 0)),
                safe_str(draft.get("stage_label")) or safe_str(draft.get("stage")),
                self._display_updated(draft.get("updated_at")),
            ]
            for c, value in enumerate(values):
                item = QTableWidgetItem(value)
                if c == 0:
                    item.setData(Qt.ItemDataRole.UserRole, draft)
                if c in (1, 2, 3, 5):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(r, c, item)
            self.table.setRowHeight(r, 46)
        has_rows = bool(rows)
        self.table.setVisible(has_rows)
        self.empty_label.setVisible(not has_rows)
        self.open_btn.setEnabled(has_rows)
        self.delete_btn.setEnabled(has_rows)
        self.print_ndp_btn.setEnabled(has_rows)
        if has_rows:
            self.table.selectRow(0)

    def current_draft(self) -> Optional[Dict[str, Any]]:
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        data = item.data(Qt.ItemDataRole.UserRole) if item else None
        return dict(data) if isinstance(data, dict) else None

    def open_selected(self) -> None:
        draft = self.current_draft()
        if not draft:
            return
        self.selected = draft
        self.accept()

    def print_selected_ndp(self) -> None:
        draft = self.current_draft()
        if not draft:
            return
        callback = getattr(self.parent_page, "print_draft_ndp", None)
        if not callable(callback):
            QMessageBox.warning(self, "Черновики", "Печать НДП сейчас недоступна.")
            return
        callback(draft)

    def delete_selected(self) -> None:
        draft = self.current_draft()
        if not draft:
            return
        answer = QMessageBox.question(
            self,
            "Удалить черновик",
            f"Удалить незавершённый привоз «{safe_str(draft.get('supplier')) or 'без поставщика'}»?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        sai_receipt_drafts.remove(safe_str(draft.get("id")))
        try:
            self.parent_page.on_draft_deleted(draft)
        except Exception:
            pass
        self.reload()
        hub = getattr(self.parent_page, "ux_preview_page", None)
        if hub is not None:
            hub.refresh_draft_badges()
