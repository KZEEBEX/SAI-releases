#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Resumable command-line backfill of the 2026 SIGMA analytical archive."""
from __future__ import annotations

import datetime as dt
import json
import os
from contextlib import closing
from pathlib import Path
from typing import Any

import sai_db
from sai_runtime_paths import CACHE_DIR, LOGS_DIR
from sai_sigma_warehouse_sync import run_warehouse_sync_with_session_refresh

LOCK_PATH = CACHE_DIR / "analytics_backfill.lock"
LOG_PATH = LOGS_DIR / "analytics_backfill.log"


def _log(payload: dict[str, Any] | str) -> None:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    text = payload if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False, default=str)
    line = f"{dt.datetime.now().astimezone().isoformat()} {text}"
    print(line, flush=True)
    with LOG_PATH.open("a", encoding="utf-8") as stream:
        stream.write(line + "\n")


def _acquire_lock() -> int:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    try:
        return os.open(str(LOCK_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        try:
            age = dt.datetime.now().timestamp() - LOCK_PATH.stat().st_mtime
            if age > 12 * 60 * 60:
                LOCK_PATH.unlink(missing_ok=True)
                return os.open(str(LOCK_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except Exception:
            pass
        raise RuntimeError("Историческая синхронизация уже выполняется")


def main() -> int:
    handle = _acquire_lock()
    try:
        os.write(handle, str(os.getpid()).encode("ascii"))
        os.close(handle)
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            row = con.execute(
                "SELECT location_id, name FROM stock_locations WHERE active=1 ORDER BY created_at LIMIT 1"
            ).fetchone()
            if row is None:
                raise RuntimeError("В SAI не создано активное место хранения")
            _log(f"Начинаю архив 2026 для места хранения: {row[1]}")
            result = run_warehouse_sync_with_session_refresh(
                con, str(row[0]), progress=_log,
            )
            _log({"phase": "complete", **result})
        return 0
    except Exception as exc:
        _log({"phase": "error", "error": str(exc)})
        return 1
    finally:
        try:
            os.close(handle)
        except Exception:
            pass
        LOCK_PATH.unlink(missing_ok=True)


if __name__ == "__main__":
    raise SystemExit(main())
