#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Read-only synchronization of SIGMA remainders and item-level sales."""
from __future__ import annotations

import datetime as dt
import json
import re
import sqlite3
from concurrent.futures import ThreadPoolExecutor, as_completed
from decimal import Decimal
from pathlib import Path
from typing import Any, Callable

import requests

from sai_core_v2.node_graph import (
    NodeEdge, NodeExecution, NodeGraph, NodeOutcome, NodeRunner, NodeSpec, ProcessCursor,
)
from sai_core_v2.sigma_warehouse import (
    analytics_archive_stats, enrich_sale_operation, history_period_status,
    rebuild_daily_metrics, save_cash_operation, save_history_period,
    save_sale_operation, save_shift, save_stock_snapshot,
)
from sai_analytics_dataset import write_ai_dataset
from sai_runtime_paths import CACHE_DIR, PRIVATE_CONFIG_PATH
from sai_sigma_session import ensure_sigma_session
from sai_read_queue import read_slot, ARCHIVE

_NAME_PARTS = re.compile(r"[^0-9A-ZА-Я]+")

ANALYTICS_SYNC_GRAPH = NodeGraph.build(
    "analytics_sync",
    nodes=(
        NodeSpec("stock", "Текущие остатки", "network"),
        NodeSpec("history", "История продаж, смен и кассы", "network"),
        NodeSpec("complete", "Аналитическая витрина готова", "terminal"),
    ),
    edges=(NodeEdge("stock", "history"), NodeEdge("history", "complete")),
    entry="stock",
)


def _normalized_name(value: Any) -> str:
    return " ".join(
        part for part in _NAME_PARTS.sub(" ", str(value or "").upper().replace("Ё", "Е")).split()
        if part
    )


def _load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


class SigmaWarehouseSync:
    def __init__(
        self, connection: sqlite3.Connection, location_id: str,
        progress: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self.connection = connection
        self.location_id = str(location_id or "").strip()
        self.progress = progress
        cfg = _load_json(PRIVATE_CONFIG_PATH)
        token_cache = ensure_sigma_session(cfg)
        self.company_id = str(cfg.get("sigma_company_key") or "").strip()
        self.sell_point_id = str(cfg.get("sigma_sell_point_id") or "").strip()
        self.api_base = str(
            token_cache.get("api_base") or cfg.get("sigma_import_api_base") or ""
        ).rstrip("/")
        self.token = str(token_cache.get("token") or "").strip()
        if not self.location_id:
            raise RuntimeError("Не выбрано место хранения")
        if not self.company_id or not self.api_base or not self.token:
            raise RuntimeError("Сессия SIGMA не готова. Сначала обновите каталог или выполните вход.")
        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json",
            "Authorization": f"Bearer {self.token}",
            "Origin": "https://cloud.sigma.ru",
            "Referer": "https://cloud.sigma.ru/",
            "User-Agent": "SAI/WarehouseSync",
        })

    def _progress(self, **payload: Any) -> None:
        if self.progress is not None:
            try:
                self.progress(payload)
            except Exception:
                pass

    def _catalog_maps(self) -> tuple[dict[str, str], dict[str, str]]:
        external: dict[str, str] = {}
        names: dict[str, list[str]] = {}
        rows = self.connection.execute(
            """SELECT i.external_id, i.sai_product_id, COALESCE(p.name, '')
               FROM product_identities i
               LEFT JOIN products p ON p.sigma_id=i.external_id AND p.company_key=i.company_key
               WHERE i.source_system='sigma' AND i.company_key=?""",
            (self.company_id,),
        ).fetchall()
        for external_id, product_id, name in rows:
            external[str(external_id)] = str(product_id)
            key = _normalized_name(name)
            if key:
                names.setdefault(key, []).append(str(product_id))
        unique_names = {key: values[0] for key, values in names.items() if len(set(values)) == 1}
        return external, unique_names

    def _get_any(self, url: str, **kwargs) -> Any:
        request_token = self.token
        with read_slot(ARCHIVE):
            response = self.session.get(url, timeout=20, headers={"Authorization": f"Bearer {request_token}"}, **kwargs)
        if response.status_code == 401:
            self._progress(phase="auth_refresh")
            # Only replay a GET, never a write. Other workers reuse this login.
            old_base = self.api_base
            auth = ensure_sigma_session(rejected_token=request_token)
            self.token = auth["token"]
            self.api_base = str(auth.get("api_base") or old_base).rstrip("/")
            self.session.headers.update({"Authorization": f"Bearer {self.token}"})
            if url.startswith(old_base + "/"):
                url = self.api_base + url[len(old_base):]
            with read_slot(ARCHIVE):
                response = self.session.get(url, timeout=20, headers={"Authorization": f"Bearer {auth['token']}"}, **kwargs)
        response.raise_for_status()
        return response.json()

    def _get(self, url: str, **kwargs) -> dict[str, Any]:
        value = self._get_any(url, **kwargs)
        return value if isinstance(value, dict) else {}

    def sync_stock(self) -> dict[str, int]:
        external, _names = self._catalog_maps()
        captured_at = dt.datetime.now().astimezone().isoformat()
        all_products: list[dict[str, Any]] = []
        page = 0
        finished = False
        while not finished:
            page_numbers = list(range(page, page + 8))
            with ThreadPoolExecutor(max_workers=8, thread_name_prefix="sai-stock") as pool:
                jobs = {
                    number: pool.submit(
                        self._get,
                        f"{self.api_base}/rest/v5/companies/{self.company_id}/products/remainders",
                        params={"sort": "", "page": number},
                    )
                    for number in page_numbers
                }
                for number in page_numbers:
                    payload = jobs[number].result()
                    products = payload.get("products") if isinstance(payload.get("products"), list) else []
                    all_products.extend(item for item in products if isinstance(item, dict))
                    if len(products) < 50:
                        finished = True
                        break
            page += 8
            if page > 1000:
                raise RuntimeError("SIGMA вернула слишком много страниц остатков")
        saved = 0
        changed = 0
        unlinked = 0
        with self.connection:
            for item in all_products:
                sigma_product_id = str(item.get("id") or "")
                product_id = external.get(sigma_product_id, "")
                if not product_id:
                    unlinked += 1
                    continue
                did_change = save_stock_snapshot(
                    self.connection,
                    sai_product_id=product_id,
                    location_id=self.location_id,
                    sigma_product_id=sigma_product_id,
                    quantity=Decimal(str(item.get("remainder") or 0)),
                    buying_price=Decimal(str(item.get("buyingPrice") or 0)),
                    selling_price=Decimal(str(item.get("sellingPrice") or 0)),
                    reliable=bool(item.get("reliable")),
                    captured_at=captured_at,
                    product_created_at=str(item.get("createdDate") or ""),
                )
                saved += 1
                changed += int(did_change)
        self._progress(phase="stock", stock=saved)
        return {"stock": saved, "stock_changed": changed, "stock_unlinked": unlinked}

    def _sale_operations(self, begin: dt.datetime, end: dt.datetime) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        seen: set[str] = set()
        cursor_end = end
        from_id = ""
        for _page in range(1000):
            params: dict[str, Any] = {
                "begin": begin.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                "end": cursor_end.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                "limit": 50,
                "sellPointId": self.sell_point_id,
            }
            if from_id:
                params["fromId"] = from_id
            payload = self._get(
                f"https://chs.sigma.ru/companies/{self.company_id}/sales/payment-operations",
                params=params,
            )
            operations = payload.get("paymentOperations") if isinstance(payload.get("paymentOperations"), list) else []
            fresh = []
            for operation in operations:
                operation_id = str(operation.get("id") or "") if isinstance(operation, dict) else ""
                if operation_id and operation_id not in seen:
                    seen.add(operation_id)
                    fresh.append(operation)
            result.extend(fresh)
            if len(operations) < 50 or not fresh:
                break
            oldest = fresh[-1]
            from_id = str(oldest.get("id") or "")
            try:
                cursor_end = dt.datetime.fromisoformat(
                    str(oldest.get("operationTime") or oldest.get("createdDate")).replace("Z", "+00:00")
                )
            except Exception:
                break
        return result

    def _sale_detail(self, operation: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        operation_id = str(operation.get("id") or "")
        occurred_at = str(operation.get("operationTime") or operation.get("createdDate") or "")
        payload = self._get(
            f"{self.api_base}/rest/v2/companies/{self.company_id}/payment-operations/sales/{operation_id}",
            params={"paymentOperationDate": occurred_at},
        )
        products = (payload.get("operationDetails") or {}).get("products")
        return payload, products if isinstance(products, list) else []

    def sync_sales_period(self, begin_date: dt.date, end_date: dt.date) -> dict[str, int]:
        begin = dt.datetime.combine(begin_date, dt.time.min).astimezone()
        end = dt.datetime.combine(end_date, dt.time.max).astimezone()
        operations = self._sale_operations(begin, end)
        _external, names = self._catalog_maps()
        linked = 0
        unlinked = 0
        staged = 0
        # The operation list already contains product names and quantities.
        # Store those immediately so unit sales become visible in seconds,
        # without waiting for more than a thousand detailed receipt requests.
        for operation in operations:
            operation_id = str(operation.get("id") or "")
            if not operation_id:
                continue
            products = operation.get("orderDetails") if isinstance(operation.get("orderDetails"), list) else []
            prepared: list[dict[str, Any]] = []
            for product in products:
                if not isinstance(product, dict):
                    continue
                name = str(product.get("productName") or product.get("name") or "")
                prepared.append({
                    "external_id": str(product.get("id") or ""),
                    "name": name,
                    "quantity": product.get("quantity") or 0,
                    "unit_price": None,
                    "sai_product_id": names.get(_normalized_name(name), ""),
                })
            with self.connection:
                added, missing = save_sale_operation(
                    self.connection, operation=operation, lines=prepared,
                    location_id=self.location_id,
                )
            linked += added
            unlinked += missing
            staged += int(bool(added or missing))
        self._progress(
            phase="sales_staged", sale_operations=staged,
            sale_lines=linked, sale_unlinked=unlinked,
        )

        # Prices live only in the detailed receipt endpoint. Enrich staged
        # lines progressively; an interrupted run simply continues next time.
        needs_detail = {
            str(row[0]) for row in self.connection.execute(
                """SELECT DISTINCT operation_id FROM sigma_sale_lines
                   WHERE unit_price IS NULL"""
            )
        }
        detail_operations = [
            item for item in operations if str(item.get("id") or "") in needs_detail
        ]
        detailed = 0
        detail_errors = 0
        with ThreadPoolExecutor(max_workers=12, thread_name_prefix="sai-sales") as pool:
            jobs = {pool.submit(self._sale_detail, item): item for item in detail_operations}
            for future in as_completed(jobs):
                try:
                    operation, products = future.result()
                    with self.connection:
                        detailed += enrich_sale_operation(
                            self.connection, str(operation.get("id") or ""), products,
                        )
                except Exception:
                    detail_errors += 1
                if (detailed + detail_errors) % 100 == 0:
                    self._progress(
                        phase="sale_prices", sale_prices=detailed,
                        sale_detail_errors=detail_errors,
                    )
        return {
            "sale_operations": staged,
            "sale_lines": linked,
            "sale_unlinked": unlinked,
            "sale_prices": detailed,
            "sale_detail_errors": detail_errors,
        }

    @staticmethod
    def _periods(begin_date: dt.date, end_date: dt.date, days: int = 7) -> list[tuple[dt.date, dt.date]]:
        result: list[tuple[dt.date, dt.date]] = []
        cursor = begin_date
        width = dt.timedelta(days=max(1, int(days)) - 1)
        while cursor <= end_date:
            period_end = min(end_date, cursor + width)
            result.append((cursor, period_end))
            cursor = period_end + dt.timedelta(days=1)
        return result

    def _devices(self) -> list[dict[str, Any]]:
        payload = self._get_any(f"{self.api_base}/rest/v3/sales/shifts/devices")
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]
        if isinstance(payload, dict):
            nested = payload.get("devices")
            if isinstance(nested, list):
                return [item for item in nested if isinstance(item, dict)]
            if payload.get("deviceId"):
                return [payload]
        return []

    def sync_shifts_period(
        self, begin_date: dt.date, end_date: dt.date, devices: list[dict[str, Any]],
    ) -> dict[str, Any]:
        begin = dt.datetime.combine(begin_date, dt.time.min).astimezone()
        end = dt.datetime.combine(end_date, dt.time.max).astimezone()
        saved = 0
        for device in devices:
            device_id = str(device.get("deviceId") or "")
            sell_point = str(device.get("sellPointId") or self.sell_point_id or "")
            if not device_id:
                continue
            page = 0
            while page < 1000:
                payload = self._get(
                    f"{self.api_base}/rest/v3/sales/shifts",
                    params={
                        "from": begin.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                        "to": end.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                        "deviceId": device_id, "sellPoint": sell_point,
                        "page": page, "size": 100,
                    },
                )
                shifts = payload.get("shifts") if isinstance(payload.get("shifts"), list) else []
                with self.connection:
                    for shift in shifts:
                        if isinstance(shift, dict):
                            saved += int(save_shift(self.connection, shift, sell_point))
                page_info = payload.get("pageInfo") if isinstance(payload.get("pageInfo"), dict) else {}
                total_pages = int(page_info.get("totalPages") or 0)
                if not shifts or (total_pages and page + 1 >= total_pages) or len(shifts) < 100:
                    break
                page += 1
        return {"shifts": saved}

    def _cash_operations(
        self, begin: dt.datetime, end: dt.datetime, device_id: str,
    ) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        seen: set[str] = set()
        cursor_end = end
        from_id = ""
        for _page in range(1000):
            params: dict[str, Any] = {
                "begin": begin.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                "end": cursor_end.astimezone(dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
                "deviceId": device_id,
            }
            if from_id:
                params["fromId"] = from_id
            payload = self._get(
                f"https://chs.sigma.ru/companies/{self.company_id}/sales/cash-operations",
                params=params,
            )
            operations = payload.get("operations") if isinstance(payload.get("operations"), list) else []
            fresh = []
            for operation in operations:
                operation_id = str(operation.get("id") or "") if isinstance(operation, dict) else ""
                if operation_id and operation_id not in seen:
                    seen.add(operation_id)
                    fresh.append(operation)
            result.extend(fresh)
            if len(operations) < 50 or not fresh:
                break
            oldest = fresh[-1]
            from_id = str(oldest.get("id") or "")
            try:
                cursor_end = dt.datetime.fromisoformat(
                    str(oldest.get("date") or "").replace("Z", "+00:00")
                )
            except Exception:
                break
        return result

    def sync_cash_period(
        self, begin_date: dt.date, end_date: dt.date, devices: list[dict[str, Any]],
    ) -> dict[str, int]:
        begin = dt.datetime.combine(begin_date, dt.time.min).astimezone()
        end = dt.datetime.combine(end_date, dt.time.max).astimezone()
        saved = 0
        for device in devices:
            device_id = str(device.get("deviceId") or "")
            if not device_id:
                continue
            operations = self._cash_operations(begin, end, device_id)
            with self.connection:
                for operation in operations:
                    saved += int(save_cash_operation(self.connection, operation, device_id))
        return {"cash_operations": saved}

    def sync_history(
        self, begin_date: dt.date = dt.date(2026, 1, 1),
        end_date: dt.date | None = None,
    ) -> dict[str, Any]:
        final_date = min(end_date or dt.date.today(), dt.date.today())
        periods = self._periods(begin_date, final_date, days=7)
        devices = self._devices()
        totals = {
            "sale_operations": 0, "sale_lines": 0, "sale_unlinked": 0,
            "sale_prices": 0, "sale_detail_errors": 0,
            "shifts": 0, "cash_operations": 0, "periods_completed": 0,
        }
        earliest_refreshed = None
        source_errors = {}
        for index, (period_start, period_end) in enumerate(periods, 1):
            start_text = period_start.isoformat()
            end_text = period_end.isoformat()
            self._progress(
                phase="history_period", period=index, periods=len(periods),
                period_start=start_text, period_end=end_text,
            )
            sources = (
                ("sales", lambda: self.sync_sales_period(period_start, period_end)),
                ("shifts", lambda: self.sync_shifts_period(period_start, period_end, devices)),
                ("cash", lambda: self.sync_cash_period(period_start, period_end, devices)),
            )
            for source, loader in sources:
                closed = period_end < dt.date.today() - dt.timedelta(days=2)
                if closed and history_period_status(self.connection, source, start_text, end_text) == "complete":
                    continue
                earliest_refreshed = min(earliest_refreshed or period_start, period_start)
                try:
                    result = loader()
                    detail_errors = int(result.get("sale_detail_errors", 0))
                    records = sum(int(value or 0) for key, value in result.items() if key != "sale_detail_errors")
                    # Completeness describes the successful fetch. Recency alone
                    # controls rereading above; it must not make August incomplete.
                    status = "complete" if detail_errors == 0 else "partial"
                    with self.connection:
                        save_history_period(
                            self.connection, source=source, period_start=start_text,
                            period_end=end_text, status=status,
                            records_count=records, detail_errors=detail_errors,
                        )
                    for key, value in result.items():
                        if key in totals:
                            totals[key] += int(value or 0)
                except Exception as exc:
                    source_errors[source] = f"Не удалось обновить {source}: {start_text} — {end_text}"
                    with self.connection:
                        save_history_period(
                            self.connection, source=source, period_start=start_text,
                            period_end=end_text, status="error", error=type(exc).__name__,
                        )
                    self._progress(phase="source_error", source=source, message=source_errors[source])
            totals["periods_completed"] += 1
        with self.connection:
            totals["metric_days"] = rebuild_daily_metrics(
                self.connection, self.location_id, earliest_refreshed.isoformat()
            ) if earliest_refreshed is not None else 0
        dataset_path = write_ai_dataset(
            self.connection, location_id=self.location_id,
            begin_date=begin_date.isoformat(),
        )
        totals["ai_dataset"] = str(dataset_path)
        if source_errors:
            totals["source_errors"] = source_errors
        totals.update({f"archive_{key}": value for key, value in analytics_archive_stats(self.connection).items()})
        self._progress(phase="analytics_ready", **totals)
        return totals

    def run(self) -> dict[str, Any]:
        cursor = ProcessCursor.start(ANALYTICS_SYNC_GRAPH, {"result": {}})
        runner = NodeRunner(ANALYTICS_SYNC_GRAPH)

        def stock_node(values: dict[str, Any]) -> NodeExecution:
            result = dict(values.get("result") or {})
            try:
                result.update(self.sync_stock())
            except Exception:
                result["source_errors"] = {"stock": "Остатки не обновлены; используются предыдущие данные"}
                self._progress(phase="source_error", source="stock", message=result["source_errors"]["stock"])
            return NodeExecution(next_node="history", values={"result": result})

        def history_node(values: dict[str, Any]) -> NodeExecution:
            result = dict(values.get("result") or {})
            errors = dict(result.get("source_errors") or {})
            try:
                history = self.sync_history()
                errors.update(history.get("source_errors") or {})
                result.update(history)
            except Exception:
                errors["history"] = "Архив обновлён не полностью; повторите загрузку позже"
            if errors:
                result["source_errors"] = errors
            return NodeExecution(next_node="complete", values={"result": result})

        runner.register("stock", stock_node)
        runner.register("history", history_node)
        runner.register("complete", lambda _values: NodeExecution(NodeOutcome.COMPLETE))
        runner.run(cursor, max_steps=4)
        if cursor.error:
            raise RuntimeError(cursor.error)
        if not cursor.completed:
            raise RuntimeError("Нодовый процесс синхронизации остановился до завершения")
        return dict(cursor.values.get("result") or {})


def run_warehouse_sync_with_session_refresh(
    connection: sqlite3.Connection, location_id: str,
    progress: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """GET-level recovery continues at the failed request, not from the archive start."""
    from sai_sync_coordinator import SyncCoordinator
    cfg = _load_json(PRIVATE_CONFIG_PATH)
    scope = str(cfg.get("sigma_company_key") or "") + ":" + str(location_id)
    return SyncCoordinator().run(
        "warehouse", scope,
        lambda: SigmaWarehouseSync(connection, location_id, progress=progress).run(),
        force=True,
    )
