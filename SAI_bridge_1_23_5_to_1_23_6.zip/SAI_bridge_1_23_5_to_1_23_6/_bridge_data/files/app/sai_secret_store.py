#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Windows DPAPI storage for per-user secrets such as API keys and passwords."""
from __future__ import annotations

import base64
import ctypes
import os
from ctypes import wintypes


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


CONFIG_SECRET_PREFIX = "dpapi:v1:"


def _blob(data: bytes) -> tuple[_DataBlob, object]:
    buffer = ctypes.create_string_buffer(data)
    return _DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte))), buffer


def _crypt(data: bytes, *, protect: bool) -> bytes:
    if os.name != "nt":
        raise RuntimeError("Защищённое хранилище SAI доступно только в Windows")
    source, source_buffer = _blob(data)
    entropy, entropy_buffer = _blob(b"SAI:user-openai-key:v1")
    output = _DataBlob()
    flags = 0x01  # CRYPTPROTECT_UI_FORBIDDEN
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    if protect:
        ok = crypt32.CryptProtectData(
            ctypes.byref(source), "SAI user secret", ctypes.byref(entropy),
            None, None, flags, ctypes.byref(output),
        )
    else:
        ok = crypt32.CryptUnprotectData(
            ctypes.byref(source), None, ctypes.byref(entropy),
            None, None, flags, ctypes.byref(output),
        )
    _ = source_buffer, entropy_buffer
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree(output.pbData)


def protect_secret(value: str) -> str:
    if not value:
        return ""
    return base64.b64encode(_crypt(value.encode("utf-8"), protect=True)).decode("ascii")


def reveal_secret(payload: str) -> str:
    if not payload:
        return ""
    return _crypt(base64.b64decode(payload.encode("ascii")), protect=False).decode("utf-8")


def protect_config_secret(value: str) -> str:
    """Protect a secret that must travel through an existing config field."""
    text = str(value or "")
    if not text:
        return ""
    return CONFIG_SECRET_PREFIX + protect_secret(text)


def reveal_config_secret(value: str) -> str:
    """Reveal a DPAPI config secret; accept old plaintext values for migration."""
    text = str(value or "")
    if not text.startswith(CONFIG_SECRET_PREFIX):
        return text
    return reveal_secret(text[len(CONFIG_SECRET_PREFIX):])


def masked_secret(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return "Не задан"
    return f"••••••••{text[-4:]}"
