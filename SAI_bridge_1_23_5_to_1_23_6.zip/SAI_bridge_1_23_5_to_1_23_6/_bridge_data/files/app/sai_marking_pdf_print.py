#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""PDF-to-thermal-label printing for the marking workspace."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable, Iterable

from PySide6.QtCore import QRect, QSize, Qt
from PySide6.QtGui import QColor, QImage, QPainter
from PySide6.QtPdf import QPdfDocument

from sai_runtime_paths import PRIVATE_CONFIG_PATH
from sai_thermal_printing import (
    THERMAL_LABEL_PROFILES,
    mm_to_dots,
    normalize_thermal_config,
    print_thermal_image,
)


def _private_config() -> dict[str, Any]:
    try:
        data = json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def validate_pdf_paths(paths: Iterable[str | Path]) -> list[Path]:
    result: list[Path] = []
    seen: set[Path] = set()
    for value in paths:
        path = Path(value).resolve()
        if path in seen:
            continue
        if not path.is_file() or path.suffix.lower() != ".pdf":
            raise RuntimeError(f"Для термопечати нужен PDF-файл: {path.name}")
        seen.add(path)
        result.append(path)
    if not result:
        raise RuntimeError("Перетащите хотя бы один PDF-файл.")
    return result


def _fit_pdf_page(document: QPdfDocument, page_index: int, size_key: str) -> QImage:
    profile = THERMAL_LABEL_PROFILES.get(size_key) or THERMAL_LABEL_PROFILES["58x40"]
    width = mm_to_dots(profile["w_mm"])
    height = mm_to_dots(profile["h_mm"])
    points = document.pagePointSize(page_index)
    if points.width() <= 0 or points.height() <= 0:
        raise RuntimeError(f"Не удалось определить размер страницы {page_index + 1}.")
    scale = min(width / points.width(), height / points.height())
    render_size = QSize(
        max(1, int(round(points.width() * scale))),
        max(1, int(round(points.height() * scale))),
    )
    rendered = document.render(page_index, render_size)
    if rendered.isNull():
        raise RuntimeError(f"Не удалось прочитать страницу {page_index + 1}.")
    label = QImage(width, height, QImage.Format.Format_RGB32)
    label.fill(QColor("#ffffff"))
    painter = QPainter(label)
    painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
    try:
        x = (width - rendered.width()) // 2
        y = (height - rendered.height()) // 2
        painter.drawImage(QRect(x, y, rendered.width(), rendered.height()), rendered)
    finally:
        painter.end()
    return label


def print_marking_pdfs(
    paths: Iterable[str | Path],
    progress: Callable[[int, int, str, int], None] | None = None,
) -> dict[str, int]:
    """Print every PDF page as one thermal label."""
    files = validate_pdf_paths(paths)
    cfg = normalize_thermal_config(_private_config())
    documents: list[tuple[Path, QPdfDocument, int]] = []
    total_pages = 0
    try:
        for path in files:
            document = QPdfDocument()
            document.load(str(path))
            count = max(0, int(document.pageCount()))
            if count <= 0:
                document.close()
                raise RuntimeError(f"В PDF нет доступных страниц: {path.name}")
            documents.append((path, document, count))
            total_pages += count

        printed = 0
        for path, document, count in documents:
            for page_index in range(count):
                if progress:
                    progress(printed, total_pages, path.name, page_index + 1)
                image = _fit_pdf_page(document, page_index, cfg["size"])
                print_thermal_image(image, cfg, copies=1)
                printed += 1
        return {"files": len(files), "pages": total_pages, "printed": printed}
    finally:
        for _path, document, _count in documents:
            try:
                document.close()
            except Exception:
                pass


__all__ = ["print_marking_pdfs", "validate_pdf_paths"]
