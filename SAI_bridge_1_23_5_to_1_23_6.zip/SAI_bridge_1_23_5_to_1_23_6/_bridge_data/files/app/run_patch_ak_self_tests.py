#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7ak."""
from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
app_dir = root / "app"
ui_path = app_dir / "sai_pyside_preview.py"
version_path = app_dir / "sai_version.py"
self_tests_path = app_dir / "run_self_tests.py"
wiki_dir = root / "SAI_Ecosystem_Wiki_v0.1"

for source in (ui_path, version_path, self_tests_path, Path(__file__)):
    text = source.read_text(encoding="utf-8-sig")
    ast.parse(text, filename=str(source))

ui = ui_path.read_text(encoding="utf-8-sig")
version = version_path.read_text(encoding="utf-8-sig")
self_tests = self_tests_path.read_text(encoding="utf-8-sig")

assert 'VERSION = "1.22.7ak"' in version
assert 'APP_VERSION == "v1.22.7ak"' in self_tests

converter_start = ui.index('class ConverterPage(QWidget):')
converter_end = ui.index('\ndef make_price_tag_preview_pixmap', converter_start)
converter = ui[converter_start:converter_end]

# The recognition action is named generically and appears only after files exist.
assert 'QPushButton("Распознать данные с ИИ")' in converter
assert 'Распознать через ChatGPT' not in converter
assert 'self.convert_btn.setVisible(False)' in converter
assert 'self.convert_btn.setVisible(bool(self.source_paths))' in converter

# Manual metadata fields and the explanatory API paragraph were removed.
for old_name in ('self.supplier_edit', 'self.date_edit', 'self.invoice_edit', 'Нужен OpenAI API key'):
    assert old_name not in converter
assert 'QLabel("Наценка %")' in converter

# Files can be dropped anywhere in the active SAI window, with a full-window overlay.
assert 'app.installEventFilter(self)' in converter
assert 'host.setAcceptDrops(True)' in converter
assert 'obj.window() is self.window()' in converter
assert 'QFrame(self)' in converter and 'InvoiceDropOverlay' in converter
assert 'Отпустите файлы — они добавятся в накладную' in converter
assert 'self.drop_overlay.setGeometry(host.rect())' in converter
assert 'self.set_source_paths(paths)' in converter

# Source and result controls follow the requested staged flow.
assert 'Выберите файлы в проводнике или перетащите в окно' in converter
assert 'QLabel("")' in converter
assert 'Выбери один или несколько файлов одной накладной.' not in converter
assert 'Сохранить SAI-файл' not in converter
assert 'Продолжить привоз' not in converter
assert 'QPushButton("Продолжить")' in converter
assert 'self.choose_btn.setVisible(False)' in converter

# Continue saves without a Save As dialog, directly to the Windows desktop.
assert 'QStandardPaths.DesktopLocation' in converter
assert 'sai_converter.default_output_path(self.result, self._desktop_directory())' in converter
assert 'QFileDialog.getSaveFileName' not in converter
assert 'self.parent_page.route_sai_file(Path(path))' in converter

# Every table uses the rounded widget mask and explicit rounded header styling.
assert 'class RoundedTableWidget(QTableWidget):' in ui
assert 'self.setMask(QRegion(' in ui
assert 'QTableWidget(' not in ui.replace('class RoundedTableWidget(QTableWidget):', '')
assert 'QTableWidget QHeaderView::section:first' in ui
assert 'QTableWidget QHeaderView::section:last' in ui
assert 'QTableCornerButton::section' in ui

manifest = json.loads((wiki_dir / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.2"
assert manifest["snapshot_sai_version"] == "1.22.7ak"
assert "v1.22.7ak" in (wiki_dir / "README.md").read_text(encoding="utf-8")
assert (wiki_dir / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.2 / SAI 1.22.7ak")

print("PATCH_AK_SELF_TEST_OK")
