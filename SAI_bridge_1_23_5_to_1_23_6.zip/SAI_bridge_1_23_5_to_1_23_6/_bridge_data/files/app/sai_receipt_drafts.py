#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compatibility facade for internal receipt drafts.

Public functions stay stable for the existing UI and patches. Persistence now
lives in ``sai_core_v2.file_drafts.FileReceiptDraftRepository`` so future
warehouse/server implementations can replace the storage without rewriting the
receiving screens.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import sai_converter
from sai_runtime_paths import USER_DATA_DIR
from sai_core_v2.file_drafts import FileReceiptDraftRepository, META_NAME, PACKAGE_NAME
from sai_core_v2.models import STAGE_LABELS

DRAFTS_DIR = USER_DATA_DIR / "receipt_drafts"
MANUAL_AUTOSAVE = USER_DATA_DIR / "free_receipt_autosave.json"


def _repo() -> FileReceiptDraftRepository:
    # Build on every call intentionally: legacy tests and diagnostic tools are
    # allowed to redirect DRAFTS_DIR/MANUAL_AUTOSAVE at runtime.
    return FileReceiptDraftRepository(DRAFTS_DIR, MANUAL_AUTOSAVE)


def ensure_dir() -> Path:
    return _repo().ensure_dir()


def is_deleted(draft_id: str) -> bool:
    return _repo().is_deleted(draft_id)


def restore(draft_id: str) -> None:
    _repo().restore(draft_id)


def new_id(prefix: str = "receipt") -> str:
    return _repo().new_id(prefix)


def draft_dir(draft_id: str) -> Path:
    return _repo().draft_dir(draft_id)


def metadata_path(draft_id: str) -> Path:
    return _repo().metadata_path(draft_id)


def package_path(draft_id: str) -> Path:
    return _repo().package_path(draft_id)


def save_result(
    result: sai_converter.ConvertResult,
    source_paths: Iterable[Path] = (),
    *,
    draft_id: Optional[str] = None,
    stage: str = "ai_review",
    kind: str = "ai",
) -> Dict[str, Any]:
    return _repo().save_result(result, source_paths, draft_id=draft_id, stage=stage, kind=kind)


def register_manual_autosave(payload: Dict[str, Any], *, draft_id: str = "manual_current") -> Dict[str, Any]:
    return _repo().register_manual_autosave(payload, draft_id=draft_id)


def get(draft_id: str) -> Optional[Dict[str, Any]]:
    return _repo().get(draft_id)


def find_by_package(path: Path | str) -> Optional[Dict[str, Any]]:
    return _repo().find_by_package(path)


def update(draft_id: str, **changes: Any) -> Optional[Dict[str, Any]]:
    return _repo().update(draft_id, **changes)


def update_by_package(path: Path | str, **changes: Any) -> Optional[Dict[str, Any]]:
    return _repo().update_by_package(path, **changes)


def mark_completed_by_package(path: Path | str) -> Optional[Dict[str, Any]]:
    return _repo().mark_completed_by_package(path)


def list_all() -> List[Dict[str, Any]]:
    return _repo().list_all()


def list_active() -> List[Dict[str, Any]]:
    return _repo().list_active()


def remove(draft_id: str) -> None:
    _repo().remove(draft_id)
