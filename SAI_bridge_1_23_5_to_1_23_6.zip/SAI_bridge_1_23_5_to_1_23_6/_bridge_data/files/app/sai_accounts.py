#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Application service for local SAI accounts and module access."""
from __future__ import annotations

from contextlib import closing
from typing import Callable
import uuid

import sai_db
from sai_core_v2.accounts import (
    create_user, get_user, has_module, list_users, module_access, secret_mask,
    set_module_access, set_password, set_user_secret, set_user_status, verify_password,
)
from sai_secret_store import masked_secret, protect_secret, reveal_secret


class AccountService:
    OWNER_USERNAME = "mike"
    DEFAULT_AI_MODEL = "gpt-5.6-luna"
    DEFAULT_AI_API_BASE = "https://api.openai.com/v1"

    def owner(self):
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            return get_user(con, self.OWNER_USERNAME)

    def activate_owner(self, password: str) -> None:
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            set_password(con, self.OWNER_USERNAME, password)

    def verify_owner(self, password: str) -> bool:
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            return verify_password(con, self.OWNER_USERNAME, password)

    def owner_has_module(self, module_code: str) -> bool:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            return has_module(con, self.OWNER_USERNAME, module_code)

    def users(self):
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            return list_users(con)

    def user(self, username: str):
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            return get_user(con, username)

    def add_user(self, username: str, display_name: str, role: str = "operator"):
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            return create_user(con, username, display_name, role)

    def modules_for(self, user_id: str):
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            return module_access(con, user_id)

    def set_module(self, user_id: str, module_code: str, enabled: bool) -> None:
        sai_db.init_db()
        owner = self.owner()
        with closing(sai_db.connect()) as con, con:
            set_module_access(con, user_id, module_code, enabled, owner.user_id if owner else "")

    def change_status(self, user_id: str, status: str) -> None:
        sai_db.init_db(); owner = self.owner()
        if owner and owner.user_id == user_id and status == "blocked":
            raise ValueError("Нельзя заблокировать самого владельца")
        with closing(sai_db.connect()) as con, con:
            set_user_status(con, user_id, status, owner.user_id if owner else "")

    def save_openai_key(self, user_id: str, api_key: str) -> str:
        key = api_key.strip()
        if not key.startswith("sk-") or len(key) < 20:
            raise ValueError("Проверьте API-ключ ChatGPT: ожидается ключ, начинающийся с sk-")
        masked = masked_secret(key)
        encrypted = protect_secret(key)
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            set_user_secret(con, user_id, "openai_api_key", encrypted, masked)
            owner = get_user(con, self.OWNER_USERNAME)
            con.execute(
                "INSERT INTO admin_audit_log VALUES (?, ?, ?, 'openai_key_saved', 'masked secret updated', datetime('now'))",
                (str(uuid.uuid4()), owner.user_id if owner else None, user_id),
            )
        return masked

    def delete_openai_key(self, user_id: str) -> bool:
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            removed = bool(con.execute(
                "DELETE FROM user_secrets WHERE user_id=? AND secret_kind='openai_api_key'",
                (user_id,),
            ).rowcount)
            if removed:
                owner = get_user(con, self.OWNER_USERNAME)
                con.execute(
                    "INSERT INTO admin_audit_log VALUES (?, ?, ?, 'openai_key_deleted', 'secret removed', datetime('now'))",
                    (str(uuid.uuid4()), owner.user_id if owner else None, user_id),
                )
        return removed

    def ai_settings(self, user_id: str) -> dict[str, str]:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            row = con.execute(
                "SELECT model, proxy_url, api_base FROM user_ai_settings WHERE user_id=?",
                (user_id,),
            ).fetchone()
        return {
            "model": str(row[0] or self.DEFAULT_AI_MODEL) if row else self.DEFAULT_AI_MODEL,
            "proxy_url": str(row[1] or "") if row else "",
            "api_base": str(row[2] or self.DEFAULT_AI_API_BASE) if row else self.DEFAULT_AI_API_BASE,
        }

    def save_ai_settings(self, user_id: str, model: str, proxy_url: str, api_base: str) -> dict[str, str]:
        selected_model = model.strip() or self.DEFAULT_AI_MODEL
        selected_proxy = proxy_url.strip()
        selected_base = api_base.strip() or self.DEFAULT_AI_API_BASE
        if not selected_base.startswith(("https://", "http://")):
            raise ValueError("Адрес API должен начинаться с https:// или http://")
        sai_db.init_db()
        owner = self.owner()
        with closing(sai_db.connect()) as con, con:
            con.execute(
                """INSERT INTO user_ai_settings(user_id, model, proxy_url, api_base, updated_at)
                   VALUES (?, ?, ?, ?, datetime('now'))
                   ON CONFLICT(user_id) DO UPDATE SET model=excluded.model,
                       proxy_url=excluded.proxy_url, api_base=excluded.api_base,
                       updated_at=excluded.updated_at""",
                (user_id, selected_model, selected_proxy, selected_base),
            )
            con.execute(
                "INSERT INTO admin_audit_log VALUES (?, ?, ?, 'openai_settings_saved', 'connection settings updated', datetime('now'))",
                (str(uuid.uuid4()), owner.user_id if owner else None, user_id),
            )
        return self.ai_settings(user_id)

    def openai_key_mask(self, user_id: str) -> str:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            return secret_mask(con, user_id, "openai_api_key")

    def reveal_openai_key(self, user_id: str) -> str:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            row = con.execute(
                "SELECT encrypted_value FROM user_secrets WHERE user_id=? AND secret_kind='openai_api_key'",
                (user_id,),
            ).fetchone()
        return reveal_secret(str(row[0])) if row else ""

    def save_marking_token(self, user_id: str, token: str) -> str:
        value = str(token or "").strip()
        if len(value) < 20:
            raise ValueError("Проверьте токен ККТ: значение слишком короткое")
        masked = masked_secret(value)
        encrypted = protect_secret(value)
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            set_user_secret(con, user_id, "marking_kkt_token", encrypted, masked)
            owner = get_user(con, self.OWNER_USERNAME)
            con.execute(
                "INSERT INTO admin_audit_log VALUES (?, ?, ?, 'marking_token_saved', 'masked secret updated', datetime('now'))",
                (str(uuid.uuid4()), owner.user_id if owner else None, user_id),
            )
        return masked

    def delete_marking_token(self, user_id: str) -> bool:
        sai_db.init_db()
        with closing(sai_db.connect()) as con, con:
            return bool(con.execute(
                "DELETE FROM user_secrets WHERE user_id=? AND secret_kind='marking_kkt_token'", (user_id,)
            ).rowcount)

    def marking_token_mask(self, user_id: str | None = None) -> str:
        sai_db.init_db()
        if user_id is None:
            owner = self.owner()
            user_id = owner.user_id if owner else ""
        with closing(sai_db.connect()) as con:
            return secret_mask(con, user_id, "marking_kkt_token") if user_id else "Не задан"

    def reveal_marking_token(self, user_id: str) -> str:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            row = con.execute(
                "SELECT encrypted_value FROM user_secrets WHERE user_id=? AND secret_kind='marking_kkt_token'", (user_id,)
            ).fetchone()
        return reveal_secret(str(row[0])) if row else ""

    def effective_owner_marking_token(self) -> str:
        owner = self.owner()
        if not owner:
            return ""
        try:
            return self.reveal_marking_token(owner.user_id)
        except Exception:
            return ""

    def migrate_legacy_owner_openai_key(
        self,
        config_loader: Callable[[], dict] | None = None,
        config_saver: Callable[[dict], dict] | None = None,
    ) -> bool:
        if config_loader is None or config_saver is None:
            from sai_catalog_ready import load_private_config, save_private_config_patch
            config_loader = config_loader or load_private_config
            config_saver = config_saver or save_private_config_patch
        owner = self.owner()
        if not owner:
            return False
        legacy_key = str((config_loader() or {}).get("openai_api_key") or "").strip()
        if self.openai_key_mask(owner.user_id) != "Не задан":
            if legacy_key:
                config_saver({"openai_api_key": ""})
                return True
            return False
        if not legacy_key:
            return False
        try:
            self.save_openai_key(owner.user_id, legacy_key)
        except Exception:
            # Never erase a legacy secret unless encrypted storage succeeded.
            return False
        config_saver({"openai_api_key": ""})
        return True

    def effective_owner_openai_key(self) -> str:
        self.migrate_legacy_owner_ai_settings()
        owner = self.owner()
        if not owner:
            return ""
        try:
            return self.reveal_openai_key(owner.user_id)
        except Exception:
            return ""

    def owner_openai_key_mask(self) -> str:
        self.migrate_legacy_owner_openai_key()
        owner = self.owner()
        return self.openai_key_mask(owner.user_id) if owner else "Не задан"

    def migrate_legacy_owner_ai_settings(
        self,
        config_loader: Callable[[], dict] | None = None,
        config_remover: Callable[[tuple[str, ...]], dict] | None = None,
    ) -> bool:
        if config_loader is None or config_remover is None:
            from sai_catalog_ready import load_private_config, remove_private_config_keys
            config_loader = config_loader or load_private_config
            config_remover = config_remover or remove_private_config_keys
        cfg = dict(config_loader() or {})
        owner = self.owner()
        if not owner:
            return False
        changed = False
        legacy_key = str(cfg.get("openai_api_key") or "").strip()
        if self.openai_key_mask(owner.user_id) == "Не задан" and legacy_key:
            try:
                self.save_openai_key(owner.user_id, legacy_key)
                changed = True
            except Exception:
                pass
        with closing(sai_db.connect()) as con:
            settings_exist = bool(con.execute(
                "SELECT 1 FROM user_ai_settings WHERE user_id=?", (owner.user_id,)
            ).fetchone())
        if not settings_exist:
            self.save_ai_settings(
                owner.user_id,
                str(cfg.get("openai_model") or self.DEFAULT_AI_MODEL),
                str(cfg.get("openai_proxy_url") or ""),
                str(cfg.get("openai_api_base") or self.DEFAULT_AI_API_BASE),
            )
            changed = True
        removable = ["openai_model", "openai_proxy_url", "openai_api_base"]
        if not legacy_key or self.openai_key_mask(owner.user_id) != "Не задан":
            removable.append("openai_api_key")
        if any(key in cfg for key in removable):
            config_remover(tuple(removable))
            changed = True
        return changed

    def effective_owner_ai_configuration(self) -> dict[str, str]:
        self.migrate_legacy_owner_ai_settings()
        owner = self.owner()
        if not owner:
            return {
                "api_key": "", "model": self.DEFAULT_AI_MODEL,
                "proxy_url": "", "api_base": self.DEFAULT_AI_API_BASE,
            }
        result = self.ai_settings(owner.user_id)
        try:
            result["api_key"] = self.reveal_openai_key(owner.user_id)
        except Exception:
            result["api_key"] = ""
        return result
