"""Test-only guard, activated by run_dev_validation, never by normal SAI."""
import os
from pathlib import Path
import sys

_forbidden = os.environ.get("SAI_TEST_FORBIDDEN_DATA_DIR")
if _forbidden:
    _root = Path(_forbidden).resolve()

    def _guard(event, args):
        if event in ("open", "sqlite3.connect", "os.remove", "os.rmdir", "os.mkdir", "os.listdir", "os.scandir", "os.rename"):
            values = args[:2] if event == "os.rename" else args[:1]
            for value in values:
                if isinstance(value, (str, bytes, os.PathLike)):
                    path = Path(os.fsdecode(value)).resolve()
                    if path == _root or _root in path.parents:
                        raise PermissionError("TEST GUARD: access to live SAI data forbidden")
        if event == "socket.connect":
            address = args[1]
            if isinstance(address, tuple) and str(address[0]) not in ("127.0.0.1", "::1", "localhost"):
                raise PermissionError("TEST GUARD: external network forbidden")

    sys.addaudithook(_guard)
