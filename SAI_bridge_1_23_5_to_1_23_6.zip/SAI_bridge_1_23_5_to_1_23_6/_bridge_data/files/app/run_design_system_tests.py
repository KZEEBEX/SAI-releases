"""Offscreen visual and behavior checks for reusable SAI controls."""
import os
from pathlib import Path
import tempfile
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontDatabase, QRawFont, QPalette
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QPushButton, QLabel
from sai_design_tokens import METRICS, component_stylesheet
from sai_ui_components import button, TableEditButton
from sai_design_showcase import create_showcase
from sai_ui_style import ui_polish_stylesheet


def main():
    app = QApplication.instance() or QApplication([])
    # The offscreen Windows plugin may not enumerate installed system fonts.
    font_path = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "segoeui.ttf"
    if font_path.is_file():
        font_id = QFontDatabase.addApplicationFont(str(font_path))
        assert font_id >= 0, "Unable to load the SAI UI font"
        app.setFont(QFont(QFontDatabase.applicationFontFamilies(font_id)[0], 10))
    assert QRawFont.fromFont(app.font()).supportsCharacter(ord("Я")), "Cyrillic font is required for visual validation"
    page = create_showcase()
    with tempfile.TemporaryDirectory(prefix="sai_design_") as temporary:
        target = Path(os.environ.get("SAI_UI_SNAPSHOT_DIR") or temporary)
        target.mkdir(parents=True, exist_ok=True)
        for dark in (False, True):
            app.setProperty("saiNightTheme", dark)
            app.setStyleSheet(ui_polish_stylesheet(dark))
            page.show()
            app.processEvents()
            if dark:
                for label in page.findChildren(QLabel):
                    assert label.palette().color(QPalette.WindowText).lightness() > 100, "Dark theme text must remain readable"
            assert page.grab().save(str(target / ("design_dark.png" if dark else "design_light.png")))
            for widget in page.findChildren(QPushButton):
                assert widget.width() >= 30 and widget.height() >= 30
        edit = page.findChild(TableEditButton)
        clicks = []
        edit.clicked.connect(lambda: clicks.append(True))
        QTest.mouseClick(edit, Qt.LeftButton)
        assert clicks == [True]
        old = METRICS["hero_radius"]
        try:
            before = component_stylesheet(False)
            METRICS["hero_radius"] = 19
            after = component_stylesheet(False)
            assert before != after and "border-radius: 19px" in after
            assert "QPushButton#WorkbenchPrimaryButton" in after and 'saiRole="hero"' in after
        finally:
            METRICS["hero_radius"] = old
    page.close()
    print("SAI design system tests: OK")


if __name__ == "__main__":
    main()
