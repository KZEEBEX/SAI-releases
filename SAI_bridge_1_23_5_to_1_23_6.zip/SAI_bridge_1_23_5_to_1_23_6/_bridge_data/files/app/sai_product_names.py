#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Conservative, local normalization of product names for SAI.

The source literal stays in ``ConvertItem.raw_name``.  This module only produces
an operator-facing/catalog-facing suggestion and never calls an external API.
Rules are deliberately category-aware: stable electrical abbreviations are
canonicalized, while unknown supplier tokens, brands and model codes are kept.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

try:
    from sai_runtime_paths import USER_DATA_DIR
except Exception:  # pragma: no cover - usable as a standalone helper
    USER_DATA_DIR = None

RULES_FILENAME = "product_name_rules.json"
RULES_VERSION = 4

ELECTRICAL_CONTEXT = (
    "РОЗЕТК", "КОЛОДК", "УДЛИНИТЕЛ", "СЕТЕВОЙ ФИЛЬТР", "ВИЛК", "РАЗВЕТВИТЕЛ",
    "ТРОЙНИК", "ВЫКЛЮЧАТЕЛ", "ПЕРЕКЛЮЧАТЕЛ", "ДИММЕР", "ШВВП", "ПВС",
)

FEMININE_CONTEXT = ("РОЗЕТКА", "КОЛОДКА", "КОРОБКА", "ВИЛКА", "ЛАМПА", "ЛОПАТА", "НАСАДКА")
NEUTER_CONTEXT = ("СРЕДСТВО", "ВЕДРО", "КРЕПЛЕНИЕ")

# The operator approved these stable, searchable abbreviations.
SEARCH_EXPANSIONS: Dict[str, str] = {
    "Д/": "ДЛЯ",
    "С/З": "С ЗАЗЕМЛЕНИЕМ",
    "Б/З": "БЕЗ ЗАЗЕМЛЕНИЯ",
    "ОУ": "ОТКРЫТОЙ УСТАНОВКИ",
    "СУ": "СКРЫТОЙ УСТАНОВКИ",
    "ГН": "ГНЕЗДО",
    "1КЛ": "ОДНОКЛАВИШНЫЙ",
    "2КЛ": "ДВУХКЛАВИШНЫЙ",
    "3КЛ": "ТРЁХКЛАВИШНЫЙ",
    "СВ/Д": "СВЕТОДИОДНЫЙ",
}

DEFAULT_CUSTOM_RULES: Dict[str, Any] = {
    "rules_version": RULES_VERSION,
    "literal_replacements": {},
    "remove_prefixes": [],
    "search_aliases": {},
}


@dataclass(frozen=True)
class NameNormalizationResult:
    original: str
    normalized: str
    changes: List[str] = field(default_factory=list)
    search_aliases: List[str] = field(default_factory=list)

    @property
    def changed(self) -> bool:
        return self.original.strip() != self.normalized.strip()


def _safe_str(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _uppercase(text: str) -> str:
    return text.upper().replace("Ё", "Ё")


def _collapse(text: str) -> str:
    text = text.replace("\xa0", " ")
    text = re.sub(r"[\r\n\t]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\s+([,;:)])", r"\1", text)
    text = re.sub(r"([(])\s+", r"\1", text)
    text = re.sub(r"(?<=[A-ZА-ЯЁ0-9])(?=[(])", " ", text)
    text = re.sub(r",(?=[^\s\d])", ", ", text)
    return text.strip(" -–—;,.")


def _rules_path(path: str | Path | None = None) -> Path | None:
    if path:
        return Path(path)
    if USER_DATA_DIR is None:
        return None
    try:
        return Path(USER_DATA_DIR) / RULES_FILENAME
    except Exception:
        return None


def ensure_user_rules_file(path: str | Path | None = None) -> Path | None:
    target = _rules_path(path)
    if target is None:
        return None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_text(json.dumps(DEFAULT_CUSTOM_RULES, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        return target
    except Exception:
        return None


def load_custom_rules(path: str | Path | None = None) -> Dict[str, Any]:
    target = ensure_user_rules_file(path)
    if target is None or not target.is_file():
        return dict(DEFAULT_CUSTOM_RULES)
    try:
        raw = json.loads(target.read_text(encoding="utf-8-sig"))
    except Exception:
        return dict(DEFAULT_CUSTOM_RULES)
    result = dict(DEFAULT_CUSTOM_RULES)
    if isinstance(raw, dict):
        if isinstance(raw.get("literal_replacements"), dict):
            result["literal_replacements"] = {
                _uppercase(_safe_str(key)): _uppercase(_safe_str(value))
                for key, value in raw["literal_replacements"].items()
                if _safe_str(key) and _safe_str(value)
            }
        if isinstance(raw.get("remove_prefixes"), list):
            result["remove_prefixes"] = [_uppercase(_safe_str(x)) for x in raw["remove_prefixes"] if _safe_str(x)]
        if isinstance(raw.get("search_aliases"), dict):
            result["search_aliases"] = {
                _uppercase(_safe_str(key)): _uppercase(_safe_str(value))
                for key, value in raw["search_aliases"].items()
                if _safe_str(key) and _safe_str(value)
            }
    return result


def _record(changes: List[str], label: str, before: str, after: str) -> str:
    if before != after:
        changes.append(label)
    return after


def _remove_known_supplier_noise(text: str, changes: List[str], custom: Mapping[str, Any]) -> str:
    before = text
    # Known service prefixes, not product brands/models.
    text = re.sub(r"^(?:1\s*[-.]\s*2\s*[.-]?\s*SALE)\s+", "", text, flags=re.I)
    for prefix in custom.get("remove_prefixes") or []:
        text = re.sub(rf"^{re.escape(prefix)}(?:\s+|[-:]+\s*)", "", text, flags=re.I)

    # Supplier carton/price notes. Product set quantity without a price/carton
    # marker is intentionally kept.
    text = re.sub(r"\s*\((?:[^()]*(?:ЦЕНА\s*(?:ЗА|/)|/\s*УП|ШТ\s*/\s*УП|УП\.?\s*[,;)]|АНАЛОГ\s+КОД)[^()]*)\)", " ", text)
    text = re.sub(r"\s*\(\s*\d+\s*!\s*\)", " ", text)
    text = re.sub(r"\s*\(\s*АНАЛОГ\s+КОД\s+[^)]*\)", " ", text)
    # Wholesale packing ratios describe the supplier's carton, not the
    # product sold to the customer: (1/12), (12/288), (1/6/36), etc.
    # A parenthesised single ``(1)`` is the same marker in these price lists.
    # Plain product counts such as "3 ШТ" and meaningful parenthesised text
    # remain untouched.
    text = re.sub(r"\s*\(\s*\d+\s*(?:/\s*\d+\s*)+\)", " ", text)
    text = re.sub(r"\s*\(\s*1\s*\)(?=\s|$)", " ", text)
    # Quotes around brands/series are supplier typography, not part of the
    # searchable product name.  Keep the text inside them.
    text = re.sub(r"[\"“”„]", "", text)
    # Exclamation marks are layout/service noise in invoices, not useful catalog data.
    text = re.sub(r"!+", " ", text)
    # Supplier warehouse/carton markers: X20, Х36, X20/2160, Х1000.
    # A real dimension such as 20X30 is preserved because the X is preceded by
    # a digit and therefore does not match this standalone service token.
    text = re.sub(
        r"(?<![0-9A-ZА-ЯЁ])(?:X|Х)\s*\d{1,7}(?:\s*/\s*\d{1,7})*(?![0-9A-ZА-ЯЁ])",
        " ",
        text,
        flags=re.I,
    )
    # Supplier files often append an internal pack/list marker such as ``(200)``.
    # Remove only a trailing digits-only group: measurements and model numbers
    # elsewhere in the product name remain untouched.
    text = re.sub(r"\s*\(\s*\d{1,7}\s*\)\s*$", " ", text)
    return _record(changes, "УДАЛЁН СЛУЖЕБНЫЙ МУСОР ПОСТАВЩИКА", before, _collapse(text))


def _main_context(text: str) -> str:
    if any(token in text for token in FEMININE_CONTEXT):
        return "f"
    if any(token in text for token in NEUTER_CONTEXT):
        return "n"
    return "m"


def _expand_core_words(text: str, changes: List[str]) -> str:
    before = text
    replacements = (
        (r"\bВЫКЛ(?:\.|(?=\s|$))", "ВЫКЛЮЧАТЕЛЬ"),
        (r"\bРОЗ(?:\.|(?=\s|$))", "РОЗЕТКА"),
        (r"\bСВ\s*[-–]?\s*К(?:\.|(?=\s|$))", "СВЕТИЛЬНИК"),
        (r"\bСЕТ(?:\.|(?=\s))\s+(?=УДЛИНИТЕЛ)", "СЕТЕВОЙ "),
        (r"\bРАСПРЕД(?:\.|(?=\s))\s+(?=КОРОБК)", "РАСПРЕДЕЛИТЕЛЬНАЯ "),
        (r"\bТЕРМОУС(?:\.|(?=\s))\s+ТРУБКА\b", "ТРУБКА ТЕРМОУСАДОЧНАЯ"),
        (r"\bКОРП(?:\.|(?=\s|$))", "КОРПУС"),
        (r"\bОСН(?:\.|(?=\s|$))", "ОСНОВАНИЕ"),
        (r"\bИНД(?:\.|(?=\s|$))", "ИНДИКАЦИЯ"),
        (r"\bТЕРМОУС(?:\.|(?=\s|$))", "ТЕРМОУСАДОЧНАЯ"),
        (r"\bТРУБЧ(?:\.|(?=\s|$))", "ТРУБЧАТЫЙ "),
        (r"\bПОВОР(?:\.|(?=\s|$))", "ПОВОРОТНЫЙ "),
        (r"\bВЕРТИК(?:\.|(?=\s|$))", "ВЕРТИКАЛЬНОЕ"),
        (r"\bАЛЮМИН(?:\.|(?=\s|$))", "АЛЮМИНИЙ"),
        (r"\bКЕРАМ(?:\.|(?=\s|$))", "КЕРАМИКА"),
        (r"\bПЛАСТ(?:\.|(?=\s|$))", "ПЛАСТИК"),
    )
    for pattern, replacement in replacements:
        text = re.sub(pattern, replacement, text)
    text = re.sub(r"\bКОРОБКА\s+РАСПРЕД(?:\.|(?=\s|$))", "КОРОБКА РАСПРЕДЕЛИТЕЛЬНАЯ", text)
    text = re.sub(r"\bПОДОШВА\s+КЕРАМ(?:\.|(?=\s|$))", "ПОДОШВА КЕРАМИЧЕСКАЯ", text)
    text = re.sub(r"\bПЛАСТИК\s+ОСНОВАНИЕ\b", "ПЛАСТИКОВОЕ ОСНОВАНИЕ", text)
    text = re.sub(r"\bКЕРАМИКА\s+ОСНОВАНИЕ\b", "КЕРАМИЧЕСКОЕ ОСНОВАНИЕ", text)
    text = re.sub(r"\bС\s+ЗАГЛ(?:\.|(?=\s|$))", "С ЗАГЛУШКОЙ", text)
    text = re.sub(r"\bНАБОР\s+ТРУБКА\s+ТЕРМОУСАДОЧНАЯ\b", "НАБОР ТЕРМОУСАДОЧНЫХ ТРУБОК", text)
    return _record(changes, "РАСКРЫТЫ НАЗВАНИЯ И ПОНЯТНЫЕ КАЧЕСТВА", before, _collapse(text))


def _canonicalize_industry_terms(text: str, changes: List[str]) -> str:
    before = text
    electrical = any(token in text for token in ELECTRICAL_CONTEXT)

    text = re.sub(r"\b(?:ОТКРЫТОЙ|НАРУЖНОЙ)\s+УСТАНОВКИ\b", "ОУ", text)
    text = re.sub(r"\b(?:СКРЫТОЙ|ВНУТРЕННЕЙ)\s+УСТАНОВКИ\b", "СУ", text)
    text = re.sub(r"\bО\s*\.?\s*У(?:\.|(?=\s|$))", "ОУ", text)
    text = re.sub(r"\bС\s*\.?\s*У(?:\.|(?=\s|$))", "СУ", text)

    # Key count is useful and compact; the product noun remains full.
    key_words = {
        "ОДНОКЛАВИШНЫЙ": "1КЛ", "1-КЛАВИШНЫЙ": "1КЛ", "1 КЛАВИШНЫЙ": "1КЛ",
        "ДВУХКЛАВИШНЫЙ": "2КЛ", "2-КЛАВИШНЫЙ": "2КЛ", "2 КЛАВИШНЫЙ": "2КЛ",
        "ТРЕХКЛАВИШНЫЙ": "3КЛ", "ТРЁХКЛАВИШНЫЙ": "3КЛ", "3-КЛАВИШНЫЙ": "3КЛ", "3 КЛАВИШНЫЙ": "3КЛ",
    }
    for source, target in key_words.items():
        text = text.replace(source, target)
    text = re.sub(r"\b([123])\s*КЛ(?:\.|(?=\s|$))", r"\1КЛ", text)

    if electrical:
        text = re.sub(r"\bС\s*/?\s*ЗАЗЕМЛЕНИЕМ\b", "С/З", text)
        text = re.sub(r"\bБЕЗ\s+ЗАЗЕМЛЕНИЯ\b", "Б/З", text)
        text = re.sub(r"\bС\s*/\s*З\b", "С/З", text)
        text = re.sub(r"\bБ\s*/\s*З\b", "Б/З", text)
        text = re.sub(r"\bЗЕМЛЯ\b", "С/З", text)

        # Places/sockets are canonicalized to GN only for electrical products.
        text = re.sub(r"\b(\d+)\s*(?:РОЗ(?:\.|(?=\s|$))|РОЗЕТОК|РОЗЕТКИ|ГНЕЗД(?:А|О)?|ГН(?:\.|(?=\s|$)))", r"\1 ГН", text)
        text = re.sub(r"\b(\d+)\s*(?:МЕСТ(?:\.|(?=\s|$))|МЕСТА|МЕСТО|МЕСТНАЯ|МЕСТНЫЙ)", r"\1 ГН", text)
        text = re.sub(r"\b(\d+)\s*ГН(?:\.|(?=\s|$))", r"\1 ГН", text)
        text = re.sub(r"\bДВОЙНАЯ\s+2\s+ГН\b", "2 ГН", text)
        text = re.sub(r"\bТРОЙНАЯ\s+3\s+ГН\b", "3 ГН", text)

    # Approved compact form of 'для'; keep it attached to the next token.
    text = re.sub(r"\bДЛЯ\s+([0-9A-ZА-ЯЁ])", r"Д/\1", text)
    text = re.sub(r"\bД\s*/\s+", "Д/", text)

    # Approved technical abbreviation. Never shorten the product noun itself.
    text = re.sub(r"\bСВЕТОДИОДН(?:ЫЙ|АЯ|ОЕ|ЫЕ)\b", "СВ/Д", text)
    text = re.sub(r"\bСВ\s*/\s*Д\b", "СВ/Д", text)

    return _record(changes, "ПРИВЕДЕНЫ ОТРАСЛЕВЫЕ СОКРАЩЕНИЯ", before, _collapse(text))


def _normalize_colors_and_shapes(text: str, changes: List[str]) -> str:
    before = text
    gender = _main_context(text)
    forms = {
        "БЕЛ": {"m": "БЕЛЫЙ", "f": "БЕЛАЯ", "n": "БЕЛОЕ"},
        "ЧЕРН": {"m": "ЧЁРНЫЙ", "f": "ЧЁРНАЯ", "n": "ЧЁРНОЕ"},
        "БЕЖ": {"m": "БЕЖЕВЫЙ", "f": "БЕЖЕВАЯ", "n": "БЕЖЕВОЕ"},
        "СЕР": {"m": "СЕРЫЙ", "f": "СЕРАЯ", "n": "СЕРОЕ"},
        "КРАСН": {"m": "КРАСНЫЙ", "f": "КРАСНАЯ", "n": "КРАСНОЕ"},
    }
    for prefix, variants in forms.items():
        text = re.sub(rf"\b{prefix}(?:\.|(?=\s|$))", variants[gender], text)
    if "СВЕТИЛЬНИК" in text or "ПРОЖЕКТОР" in text:
        text = re.sub(r"\bКРУГ\b", "КРУГЛЫЙ", text)
        text = re.sub(r"\bКВАДРАТ\b", "КВАДРАТНЫЙ", text)
        text = re.sub(r"\bМАТ(?:\.|(?=\s|$))", "МАТОВЫЙ", text)
    return _record(changes, "РАСКРЫТЫ ЦВЕТА И ФОРМА", before, _collapse(text))


def _normalize_measure_units(text: str, changes: List[str]) -> str:
    before = text
    # Normalize multiplication sign only where it is clearly numeric.
    text = re.sub(r"(?<=\d)\s*[XХ]\s*(?=\d)", "×", text)

    unit_map = {
        "KW": "КВТ", "КВТ": "КВТ", "W": "ВТ", "ВТ": "ВТ",
        "V": "В", "В": "В", "A": "А", "А": "А",
        "LM": "ЛМ", "ЛМ": "ЛМ", "K": "К", "К": "К",
        "MM": "ММ", "ММ": "ММ", "CM": "СМ", "СМ": "СМ",
        "ML": "МЛ", "МЛ": "МЛ", "KG": "КГ", "КГ": "КГ",
        "G": "Г", "Г": "Г", "L": "Л", "Л": "Л", "M": "М", "М": "М",
        "PCS": "ШТ", "ШТ": "ШТ", "UP": "УП", "УП": "УП",
    }
    units = "|".join(sorted((re.escape(x) for x in unit_map), key=len, reverse=True))
    number = r"(?:\d+(?:[.,]\d+)?)"
    range_number = rf"{number}(?:\s*[-–]\s*{number})?"

    def repl(match: re.Match[str]) -> str:
        raw_number = re.sub(r"\s+", "", match.group("number")).replace(".", ",")
        raw_number = re.sub(r"-", "–", raw_number)
        unit = unit_map[match.group("unit").upper()]
        return f"{raw_number} {unit}"

    # Avoid model tokens such as E1M: the numeric token must not be preceded by
    # a letter/digit. Unit must end at a non-letter boundary.
    pattern = re.compile(
        rf"(?<![0-9A-ZА-ЯЁ-])(?P<number>{range_number})\s*(?P<unit>{units})(?![0-9A-ZА-ЯЁ-])\.?",
        flags=re.I,
    )
    text = pattern.sub(repl, text)
    text = re.sub(r"(?<=\d)×(\d+)\.(\d+)", r"×\1,\2", text)
    text = re.sub(r"\b(\d+)\s*ВХ(?:\.|(?=\s|$))", r"\1 ВХОДА", text)
    text = re.sub(r"\b(\d+)\s*ШТ\.?\b", r"\1 ШТ", text)
    text = re.sub(r"\b(\d+)\s*УП\.?\b", r"\1 УП", text)
    # Supplier shorthand like "6500 K 6 K" repeats the same colour
    # temperature in thousands; the second fragment adds no search value.
    text = re.sub(r"\b([1-9]\d{3})\s+К\s+([1-9])\s+К\b", lambda m: f"{m.group(1)} К" if int(m.group(1)) // 1000 == int(m.group(2)) else m.group(0), text)
    return _record(changes, "ЕДИНИЦЫ ОТДЕЛЕНЫ ПРОБЕЛОМ", before, _collapse(text))


def _apply_custom_literal_rules(text: str, changes: List[str], custom: Mapping[str, Any]) -> str:
    before = text
    for source, target in (custom.get("literal_replacements") or {}).items():
        text = text.replace(source, target)
    return _record(changes, "ПРИМЕНЁН ПОЛЬЗОВАТЕЛЬСКИЙ СЛОВАРЬ", before, _collapse(text))


def search_aliases_for_name(name: str, custom_rules: Mapping[str, Any] | None = None) -> List[str]:
    text = _uppercase(_safe_str(name))
    aliases: List[str] = []
    expanded = text
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])Д/(?=[0-9A-ZА-ЯЁ])", "ДЛЯ ", expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])С/З(?![A-ZА-ЯЁ])", "С ЗАЗЕМЛЕНИЕМ", expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])Б/З(?![A-ZА-ЯЁ])", "БЕЗ ЗАЗЕМЛЕНИЯ", expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])ОУ(?![A-ZА-ЯЁ])", "ОТКРЫТОЙ УСТАНОВКИ", expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])СУ(?![A-ZА-ЯЁ])", "СКРЫТОЙ УСТАНОВКИ", expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])([123])КЛ(?![A-ZА-ЯЁ])", lambda m: {"1":"ОДНОКЛАВИШНЫЙ", "2":"ДВУХКЛАВИШНЫЙ", "3":"ТРЁХКЛАВИШНЫЙ"}[m.group(1)], expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])ГН(?![A-ZА-ЯЁ])", "ГНЕЗД", expanded)
    expanded = re.sub(r"(?<![A-ZА-ЯЁ])СВ/Д(?![A-ZА-ЯЁ])", "СВЕТОДИОДНЫЙ", expanded)
    expanded = _collapse(expanded)
    if expanded and expanded != text:
        aliases.append(expanded)
    custom = custom_rules or load_custom_rules()
    for short, full in (custom.get("search_aliases") or {}).items():
        if short in text:
            candidate = _collapse(text.replace(short, full))
            if candidate and candidate not in aliases:
                aliases.append(candidate)
    return aliases

def strip_leading_article(value: Any, article: Any) -> tuple[str, bool]:
    """Remove an exact supplier article duplicated at the start of a name."""
    source = _collapse(_safe_str(value))
    code = _collapse(_safe_str(article))
    # Short values such as "1" are too ambiguous to remove from product text.
    if len(re.sub(r"[^0-9A-Za-zА-Яа-яЁё]", "", code)) < 3:
        return source, False
    cleaned = re.sub(
        rf"^{re.escape(code)}(?=\s|[:;,._/\\–—-])\s*[:;,._/\\–—-]*\s*",
        "",
        source,
        count=1,
        flags=re.IGNORECASE,
    ).strip()
    return (cleaned, True) if cleaned and cleaned != source else (source, False)


def normalize_product_name(value: Any, *, article: Any = "", custom_rules: Mapping[str, Any] | None = None) -> NameNormalizationResult:
    original = _safe_str(value)
    if not original:
        return NameNormalizationResult(original="", normalized="", changes=[], search_aliases=[])
    custom = dict(custom_rules or load_custom_rules())
    changes: List[str] = []
    without_article, article_removed = strip_leading_article(original, article)
    text = _collapse(_uppercase(without_article))
    if article_removed:
        changes.append("УДАЛЁН АРТИКУЛ ИЗ НАЧАЛА НАЗВАНИЯ")
    text = _remove_known_supplier_noise(text, changes, custom)
    text = _expand_core_words(text, changes)
    text = _canonicalize_industry_terms(text, changes)
    text = _normalize_colors_and_shapes(text, changes)
    text = _normalize_measure_units(text, changes)
    text = _apply_custom_literal_rules(text, changes, custom)
    text = _collapse(text)
    aliases = search_aliases_for_name(text, custom)
    return NameNormalizationResult(original=original, normalized=text, changes=list(dict.fromkeys(changes)), search_aliases=aliases)


def normalize_items(items: Iterable[Any], *, overwrite_manual: bool = False, custom_rules: Mapping[str, Any] | None = None) -> int:
    """Normalize item names in place and return the count of changed rows.

    ``raw_name`` remains untouched. Dynamic metadata attributes are used so the
    existing SAI Package 1.0 contract stays backward compatible.
    """
    custom = dict(custom_rules or load_custom_rules())
    changed = 0
    for item in items:
        if bool(getattr(item, "name_manually_edited", False)) and not overwrite_manual:
            continue
        source = _safe_str(getattr(item, "raw_name", "") or getattr(item, "name", ""))
        result = normalize_product_name(source, article=getattr(item, "article", ""), custom_rules=custom)
        if result.normalized and result.normalized != _safe_str(getattr(item, "name", "")):
            setattr(item, "name", result.normalized)
            changed += 1
        setattr(item, "name_normalization_changes", list(result.changes))
        setattr(item, "name_search_aliases", list(result.search_aliases))
        setattr(item, "name_normalizer_version", RULES_VERSION)
    return changed


def apply_manual_name(item: Any, value: Any) -> str:
    name = _collapse(_uppercase(_safe_str(value)))
    if not name:
        raise ValueError("Название товара не может быть пустым.")
    setattr(item, "name", name)
    setattr(item, "name_manually_edited", True)
    setattr(item, "name_normalization_changes", ["РУЧНАЯ ПРАВКА"])
    return name


def restore_normalized_name(item: Any, *, custom_rules: Mapping[str, Any] | None = None) -> str:
    setattr(item, "name_manually_edited", False)
    source = _safe_str(getattr(item, "raw_name", "") or getattr(item, "name", ""))
    result = normalize_product_name(source, article=getattr(item, "article", ""), custom_rules=custom_rules)
    setattr(item, "name", result.normalized or source.upper())
    setattr(item, "name_normalization_changes", list(result.changes))
    setattr(item, "name_search_aliases", list(result.search_aliases))
    return getattr(item, "name")


def searchable_text(value: Any, *, custom_rules: Mapping[str, Any] | None = None) -> str:
    """Return name plus safe expansions for local token search.

    It does not alter the stored product name. Both ``С/З`` and
    ``С ЗАЗЕМЛЕНИЕМ`` therefore lead to the same searchable vocabulary.
    """
    text = _collapse(_uppercase(_safe_str(value)))
    if not text:
        return ""
    aliases = search_aliases_for_name(text, custom_rules)
    return _collapse(" ".join([text, *aliases]))
