#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""SAI Doctor — read-only SIGMA/API diagnostic utility.

This is intentionally separate from the main SAI UI. It checks the local
configuration, network, browser token capture, SIGMA X-Api-Key API, SIGMA cloud
Bearer API, SQLite cache and XLSX compatibility helpers. It does not create or
modify SIGMA documents.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import platform
import socket
import sqlite3
import sys
import time
import traceback
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

import requests

from sai_version import APP_VERSION

from sai_direct_network import (
    configure_direct_network,
    direct_mode_summary,
    original_proxy_description,
)

configure_direct_network()

from sai_runtime_paths import (
    APP_DIR,
    ROOT_DIR,
    USER_DATA_DIR,
    PROFILE_DIR,
    CACHE_DIR,
    LOGS_DIR,
    PRIVATE_CONFIG_PATH,
    PRIVATE_CONFIG_EXAMPLE_PATH,
    DB_PATH,
    ensure_runtime_dirs,
)

DEFAULT_API_BASE = "https://cloud.sigma.ru"
DEFAULT_CLOUD_URL = "https://cloud.sigma.ru/documents"
PUBLIC_API_BASE = "https://api.sigma.ru/v1"
DOCTOR_VERSION = "v1.1"


def now_stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_str(value: Any) -> str:
    return str(value or "").strip()


def mask_secret(value: Any, keep: int = 4) -> str:
    s = safe_str(value)
    if not s:
        return ""
    if len(s) <= keep * 2:
        return "*" * len(s)
    return s[:keep] + "…" + s[-keep:]


def json_or_text(resp: requests.Response) -> Any:
    text = resp.text or ""
    if not text:
        return None
    try:
        return resp.json()
    except Exception:
        return text[:1000]


def short_payload(payload: Any, max_chars: int = 500) -> str:
    try:
        if isinstance(payload, (dict, list)):
            s = json.dumps(payload, ensure_ascii=False)
        else:
            s = str(payload)
    except Exception:
        s = repr(payload)
    return s[:max_chars].replace("\n", " ").replace("\r", " ")


def collect_list_count(payload: Any) -> int:
    if isinstance(payload, list):
        return len(payload)
    if isinstance(payload, dict):
        for key in ("data", "items", "content", "result", "products", "storehouses", "suppliers"):
            value = payload.get(key)
            if isinstance(value, list):
                return len(value)
        # Some endpoints return dict with nested data.
        for value in payload.values():
            if isinstance(value, list):
                return len(value)
    return -1


@dataclass
class CheckResult:
    group: str
    name: str
    status: str  # OK / WARN / FAIL / SKIP / INFO
    details: str = ""
    duration_ms: int = 0


class Doctor:
    def __init__(self, deep: bool = False, browser: bool = True, visible_browser: Optional[bool] = None):
        ensure_runtime_dirs()
        self.deep = bool(deep)
        self.browser = bool(browser)
        self.visible_browser = visible_browser
        self.results: List[CheckResult] = []
        self.cfg: Dict[str, Any] = {}
        self.runtime_token: str = ""
        self.report_base = LOGS_DIR / f"sai_doctor_{now_stamp()}"
        self.text_lines: List[str] = []

    def log(self, text: str = "") -> None:
        print(text, flush=True)
        self.text_lines.append(text)

    def add(self, group: str, name: str, status: str, details: str = "", duration_ms: int = 0) -> None:
        status = status.upper()
        self.results.append(CheckResult(group, name, status, details, duration_ms))
        icon = {"OK": "OK", "WARN": "WARN", "FAIL": "FAIL", "SKIP": "SKIP", "INFO": "INFO"}.get(status, status)
        dur = f" ({duration_ms} ms)" if duration_ms else ""
        line = f"[{icon}] {group}: {name}{dur}"
        if details:
            line += f" — {details}"
        self.log(line)

    def timed(self, group: str, name: str, func, ok_details: str = "") -> Any:
        started = time.perf_counter()
        try:
            value = func()
            elapsed = int((time.perf_counter() - started) * 1000)
            details = ok_details or self.describe_value(value)
            self.add(group, name, "OK", details, elapsed)
            return value
        except Exception as e:
            elapsed = int((time.perf_counter() - started) * 1000)
            self.add(group, name, "FAIL", f"{type(e).__name__}: {str(e)[:500]}", elapsed)
            return None

    @staticmethod
    def describe_value(value: Any) -> str:
        if isinstance(value, requests.Response):
            return f"HTTP {value.status_code}"
        if isinstance(value, (dict, list)):
            return short_payload(value, 260)
        if value is None:
            return ""
        return str(value)[:260]

    def load_config(self) -> None:
        group = "Конфиг"
        self.add(group, "Папка SAI", "INFO", str(ROOT_DIR))
        self.add(group, "user_data", "INFO", str(USER_DATA_DIR))
        self.add(group, "Profile", "OK" if PROFILE_DIR.exists() else "WARN", str(PROFILE_DIR))
        if not PRIVATE_CONFIG_PATH.exists():
            self.add(group, "sai_private_config.json", "FAIL", f"не найден: {PRIVATE_CONFIG_PATH}")
            return
        try:
            self.cfg = json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8-sig"))
            self.add(group, "sai_private_config.json", "OK", str(PRIVATE_CONFIG_PATH))
        except Exception as e:
            self.add(group, "sai_private_config.json", "FAIL", f"не удалось прочитать JSON: {e}")
            self.cfg = {}
            return

        required = ["sigma_company_key", "sigma_api_token", "sigma_login", "sigma_password"]
        for key in required:
            val = safe_str(self.cfg.get(key))
            if val:
                shown = mask_secret(val) if "token" in key or "password" in key or "key" in key else val
                self.add(group, key, "OK", shown)
            else:
                self.add(group, key, "WARN", "пусто")
        sell = safe_str(self.cfg.get("sigma_sell_point_id"))
        self.add(group, "sigma_sell_point_id", "OK" if sell else "WARN", sell or "не задан; попробуем получить через API")
        storehouse = safe_str(self.cfg.get("storehouse_id"))
        self.add(group, "storehouse_id", "OK" if storehouse else "WARN", storehouse or "не задан; попробуем получить через cloud API")

    def check_environment(self) -> None:
        group = "Среда"
        self.add(group, "Версия SAI", "OK", APP_VERSION)
        self.add(group, "Python", "OK", sys.version.replace("\n", " "))
        self.add(group, "ОС", "OK", f"{platform.system()} {platform.release()} / {platform.machine()}")
        for mod in ["requests", "openpyxl", "playwright", "PySide6"]:
            try:
                __import__(mod)
                self.add(group, f"Модуль {mod}", "OK")
            except Exception as e:
                self.add(group, f"Модуль {mod}", "WARN" if mod == "PySide6" else "FAIL", str(e)[:200])
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                chromium_path = p.chromium.executable_path
                self.add(group, "Chromium Playwright", "OK", chromium_path)
        except Exception as e:
            self.add(group, "Chromium Playwright", "FAIL", str(e)[:400])

    def check_network(self) -> None:
        group = "Сеть"
        self.add(group, "Режим SAI без прокси", "OK", direct_mode_summary())
        detected_proxy = original_proxy_description()
        if detected_proxy != "proxy settings were not detected":
            self.add(group, "Обнаруженные настройки прокси", "INFO", detected_proxy + "; SAI их игнорирует")
        for host in ["api.sigma.ru", "cloud.sigma.ru", "id.atol.ru"]:
            def resolve(host=host):
                return socket.getaddrinfo(host, 443)
            records = self.timed(group, f"DNS {host}", resolve)
            if records:
                addrs = sorted({r[4][0] for r in records})[:4]
                self.results[-1].details = ", ".join(addrs)
                self.text_lines[-1] = self.text_lines[-1].split(" — ")[0] + " — " + self.results[-1].details
        for url in ["https://api.sigma.ru", "https://cloud.sigma.ru", "https://id.atol.ru"]:
            def get(url=url):
                return requests.get(url, timeout=12, headers={"User-Agent": "SAI-Doctor/1.0", "Connection": "close"})
            started = time.perf_counter()
            try:
                r = get()
                elapsed = int((time.perf_counter() - started) * 1000)
                # 200/302/401/403/404 all prove TLS/network is alive; SSL/timeout is the real problem.
                status = "OK" if r.status_code < 500 else "WARN"
                self.add(group, f"HTTPS {url}", status, f"HTTP {r.status_code}", elapsed)
            except requests.exceptions.SSLError as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, f"HTTPS {url}", "FAIL", f"SSL: {e}; часто виноват VPN/антивирус/прокси", elapsed)
            except Exception as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, f"HTTPS {url}", "FAIL", f"{type(e).__name__}: {e}", elapsed)

    def x_api_headers(self) -> Dict[str, str]:
        return {
            "Accept": "application/json",
            "X-Api-Key": safe_str(self.cfg.get("sigma_api_token")),
            "User-Agent": "SAI-Doctor/1.0",
            "Connection": "close",
        }

    def api_get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, timeout: int = 25) -> Tuple[int, Any]:
        company = safe_str(self.cfg.get("sigma_company_key"))
        url = f"{PUBLIC_API_BASE}/companies/{company}/{endpoint.lstrip('/')}"
        r = requests.get(url, headers=self.x_api_headers(), params=params or {}, timeout=timeout)
        return r.status_code, json_or_text(r)

    def check_x_api_key_api(self) -> None:
        group = "SIGMA X-Api-Key API"
        company = safe_str(self.cfg.get("sigma_company_key"))
        token = safe_str(self.cfg.get("sigma_api_token"))
        if not company or not token:
            self.add(group, "Проверка", "SKIP", "нет sigma_company_key или sigma_api_token")
            return
        sell_point_id = safe_str(self.cfg.get("sigma_sell_point_id"))
        endpoints: List[Tuple[str, str, Dict[str, Any]]] = [
            ("sell-points", "sell-points", {}),
            ("units", "units", {}),
            ("taxes", "taxes", {}),
        ]
        if sell_point_id:
            endpoints.append(("product-categories", "product-categories", {"sellPointId": sell_point_id}))
            endpoints.append(("products first page", "products", {"sellPointId": sell_point_id, "limit": 20}))
        else:
            endpoints.append(("product-categories", "product-categories", {}))
            endpoints.append(("products first page", "products", {"limit": 20}))

        for label, endpoint, params in endpoints:
            started = time.perf_counter()
            try:
                status_code, payload = self.api_get(endpoint, params=params)
                elapsed = int((time.perf_counter() - started) * 1000)
                count = collect_list_count(payload)
                details = f"HTTP {status_code}"
                if count >= 0:
                    details += f", элементов={count}"
                elif status_code >= 400:
                    details += f", {short_payload(payload, 250)}"
                self.add(group, label, "OK" if 200 <= status_code < 300 else "FAIL", details, elapsed)
                if label == "sell-points" and not sell_point_id and 200 <= status_code < 300:
                    guessed = self.guess_first_id(payload)
                    if guessed:
                        self.add(group, "sellPointId найден в ответе", "INFO", guessed)
            except requests.exceptions.SSLError as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, label, "FAIL", f"SSL: {e}; проверь VPN/антивирус", elapsed)
            except Exception as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, label, "FAIL", f"{type(e).__name__}: {str(e)[:450]}", elapsed)

        if self.deep and sell_point_id:
            self.check_catalog_pagination(sell_point_id)

    def guess_first_id(self, payload: Any) -> str:
        if isinstance(payload, dict):
            for key in ("data", "items", "content", "result", "sellPoints"):
                v = payload.get(key)
                if isinstance(v, list) and v:
                    first = v[0]
                    if isinstance(first, dict) and safe_str(first.get("id")):
                        return safe_str(first.get("id"))
            for v in payload.values():
                if isinstance(v, list) and v and isinstance(v[0], dict) and safe_str(v[0].get("id")):
                    return safe_str(v[0].get("id"))
        if isinstance(payload, list) and payload and isinstance(payload[0], dict):
            return safe_str(payload[0].get("id"))
        return ""

    def check_catalog_pagination(self, sell_point_id: str) -> None:
        group = "Каталог товаров"
        self.add(group, "Глубокая выгрузка", "INFO", "читаю страницы products; это может занять время")
        total_products = 0
        total_barcodes = 0
        pages = 0
        from_id = ""
        seen_page_signatures = set()
        started_all = time.perf_counter()
        for page in range(20):  # safety limit
            params = {"sellPointId": sell_point_id, "limit": 2000}
            if from_id:
                params["fromId"] = from_id
            started = time.perf_counter()
            try:
                status_code, payload = self.api_get("products", params=params, timeout=45)
                elapsed = int((time.perf_counter() - started) * 1000)
                if not (200 <= status_code < 300):
                    self.add(group, f"products page {page}", "FAIL", f"HTTP {status_code}: {short_payload(payload, 260)}", elapsed)
                    break
                items = self.extract_items(payload)
                if not items:
                    self.add(group, f"products page {page}", "OK", "пустая — выгрузка завершена", elapsed)
                    break
                sig = tuple(safe_str(x.get("id")) for x in items[:5])
                if sig in seen_page_signatures:
                    self.add(group, f"products page {page}", "WARN", "похожа на повтор страницы; остановка", elapsed)
                    break
                seen_page_signatures.add(sig)
                pages += 1
                total_products += len(items)
                total_barcodes += sum(self.count_product_barcodes(x) for x in items)
                from_id = self.extract_latest_id(payload) or safe_str(items[-1].get("id"))
                self.add(group, f"products page {page}", "OK", f"товаров={len(items)}, ШК≈{total_barcodes}, fromId={mask_secret(from_id, 6)}", elapsed)
                if len(items) < 2000:
                    break
            except Exception as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, f"products page {page}", "FAIL", f"{type(e).__name__}: {str(e)[:400]}", elapsed)
                break
        elapsed_all = int((time.perf_counter() - started_all) * 1000)
        self.add(group, "Итого", "OK" if pages else "WARN", f"страниц={pages}, товаров≈{total_products}, ШК≈{total_barcodes}", elapsed_all)

    @staticmethod
    def extract_items(payload: Any) -> List[Dict[str, Any]]:
        if isinstance(payload, list):
            return [x for x in payload if isinstance(x, dict)]
        if isinstance(payload, dict):
            for key in ("data", "items", "content", "result", "products"):
                v = payload.get(key)
                if isinstance(v, list):
                    return [x for x in v if isinstance(x, dict)]
        return []

    @staticmethod
    def extract_latest_id(payload: Any) -> str:
        if isinstance(payload, dict):
            paging = payload.get("paging") or payload.get("page") or {}
            if isinstance(paging, dict):
                for k in ("latestId", "lastId", "fromId", "cursor"):
                    if safe_str(paging.get(k)):
                        return safe_str(paging.get(k))
        return ""

    @staticmethod
    def count_product_barcodes(product: Dict[str, Any]) -> int:
        count = 0
        items = product.get("items")
        if isinstance(items, list):
            for it in items:
                if not isinstance(it, dict):
                    continue
                bcs = it.get("barcodes")
                if isinstance(bcs, list):
                    count += len([b for b in bcs if safe_str(b)])
                elif safe_str(bcs):
                    count += 1
        for key in ("barcodes", "barcode"):
            v = product.get(key)
            if isinstance(v, list):
                count += len([x for x in v if safe_str(x)])
            elif safe_str(v):
                count += 1
        return count

    def load_runtime_token(self) -> str:
        try:
            from sai_api_first_apply import load_runtime_token_cache
            token = load_runtime_token_cache(DEFAULT_API_BASE)
            return safe_str(token)
        except Exception:
            return ""

    def capture_browser_token(self) -> str:
        from sai_api_first_apply import capture_sigma_token, save_runtime_token_cache
        visible = self.visible_browser
        if visible is None:
            visible = bool(self.cfg.get("browser_visible", False))
        token = capture_sigma_token(
            str(PROFILE_DIR),
            DEFAULT_API_BASE,
            DEFAULT_CLOUD_URL,
            safe_str(self.cfg.get("sigma_login")),
            safe_str(self.cfg.get("sigma_password")),
            timeout_sec=90,
            visible=visible,
            prefer_bundled_chromium=bool(self.cfg.get("prefer_bundled_chromium", True)),
            hidden_auto_visible_after=int(self.cfg.get("hidden_browser_auto_visible_after_seconds", 35) or 35),
        )
        try:
            save_runtime_token_cache(token, DEFAULT_API_BASE)
        except Exception:
            pass
        return token

    def bearer_request(self, token: str, method: str, path: str, json_body: Any = None, params: Optional[Dict[str, Any]] = None, timeout: int = 25) -> Tuple[int, Any]:
        url = DEFAULT_API_BASE.rstrip("/") + (path if path.startswith("/") else "/" + path)
        headers = {
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "authorization": "Bearer " + token,
            "user-agent": "SAI-Doctor/1.0",
            "connection": "close",
        }
        r = requests.request(method.upper(), url, headers=headers, json=json_body, params=params or {}, timeout=timeout)
        return r.status_code, json_or_text(r)

    def check_browser_bearer_api(self) -> None:
        group = "SIGMA browser/cloud API"
        token = self.load_runtime_token()
        if token:
            self.add(group, "Runtime token cache", "OK", mask_secret(token, 8))
        elif self.browser:
            self.add(group, "Runtime token cache", "WARN", "нет кэша, попробую получить через браузер")
        else:
            self.add(group, "Runtime token cache", "SKIP", "нет токена и browser=false")

        if not token and self.browser:
            started = time.perf_counter()
            try:
                token = self.capture_browser_token()
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, "Получение токена через Chromium/Playwright", "OK", mask_secret(token, 8), elapsed)
            except Exception as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                self.add(group, "Получение токена через Chromium/Playwright", "FAIL", f"{type(e).__name__}: {str(e)[:500]}", elapsed)
                token = ""
        self.runtime_token = token
        if not token:
            return

        tests: List[Tuple[str, str, str, Any]] = [
            ("account", "GET", "/rest/1.1/account", None),
        ]
        company = safe_str(self.cfg.get("sigma_company_key"))
        if company:
            tests.extend([
                ("storehouses waybill", "GET", f"/rest/v2/companies/{company}/storehouses/waybill?storehouseType=DESTINATION", None),
                ("storehouses all", "GET", f"/rest/v2/companies/{company}/storehouses", None),
            ])
        storehouse_id = safe_str(self.cfg.get("storehouse_id"))
        # Read-only search with harmless nonsense query to verify endpoint shape/access.
        tests.append(("product simple search", "POST", "/rest/v4/products/simple?page=0", {
            "isProduced": None,
            "name": "SAI_DOCTOR_NON_EXISTENT_BARCODE_0000000000000",
            "storehouseId": storehouse_id or None,
            "waybillId": None,
        }))
        optional_cloud_checks = {"product simple search"}
        for label, method, path, body in tests:
            started = time.perf_counter()
            try:
                status_code, payload = self.bearer_request(token, method, path, json_body=body)
                elapsed = int((time.perf_counter() - started) * 1000)
                count = collect_list_count(payload)
                details = f"HTTP {status_code}"
                if count >= 0:
                    details += f", элементов={count}"
                elif status_code >= 400:
                    details += f", {short_payload(payload, 250)}"
                if 200 <= status_code < 300:
                    result_status = "OK"
                elif label in optional_cloud_checks:
                    result_status = "WARN"
                    details += "; необязательный внутренний cloud endpoint, основной сценарий SAI от него не зависит"
                else:
                    result_status = "FAIL"
                self.add(group, label, result_status, details, elapsed)
            except Exception as e:
                elapsed = int((time.perf_counter() - started) * 1000)
                status = "WARN" if label in optional_cloud_checks else "FAIL"
                suffix = "; необязательная проверка" if label in optional_cloud_checks else ""
                self.add(group, label, status, f"{type(e).__name__}: {str(e)[:450]}{suffix}", elapsed)

    def check_sqlite(self) -> None:
        group = "SQLite"
        if not DB_PATH.exists():
            self.add(group, "sai.db", "WARN", f"не найден: {DB_PATH}")
            return
        try:
            size_kb = DB_PATH.stat().st_size / 1024
            self.add(group, "sai.db", "OK", f"{DB_PATH} ({size_kb:.1f} КБ)")
            con = sqlite3.connect(DB_PATH)
            cur = con.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
            tables = [r[0] for r in cur.fetchall()]
            self.add(group, "Таблицы", "OK", ", ".join(tables) if tables else "нет таблиц")
            for table in ["products", "barcodes", "receipt_checks", "receipt_items", "price_history", "apply_history"]:
                if table in tables:
                    try:
                        cur.execute(f"SELECT COUNT(*) FROM {table}")
                        cnt = cur.fetchone()[0]
                        self.add(group, f"{table}", "OK", f"строк={cnt}")
                    except Exception as e:
                        self.add(group, f"{table}", "WARN", str(e)[:200])
            con.close()
        except Exception as e:
            self.add(group, "sai.db", "FAIL", f"{type(e).__name__}: {e}")

    def check_xlsx_compat(self) -> None:
        group = "XLSX импорт"
        try:
            from openpyxl import Workbook, load_workbook
            from sai_app import make_xlsx_sigma_compatible
            path = CACHE_DIR / f"sai_doctor_import_test_{now_stamp()}.xlsx"
            wb = Workbook()
            ws = wb.active
            ws.title = "Для робота SIGMA"
            ws.append(["ШК", "Наименование", "Ед.", "Цена"])
            ws.append(["4600000000000", "ТЕСТ SAI DOCTOR", "штука", 60.0])
            ws["D2"].number_format = "0.0"
            wb.save(path)
            make_xlsx_sigma_compatible(path)
            # Check ZIP internals.
            import zipfile
            with zipfile.ZipFile(path, "r") as z:
                names = set(z.namelist())
                has_shared = "xl/sharedStrings.xml" in names
                sheet_xml = z.read("xl/worksheets/sheet1.xml").decode("utf-8", "replace")
                has_inline = "inlineStr" in sheet_xml
            self.add(group, "sharedStrings", "OK" if has_shared and not has_inline else "FAIL", f"sharedStrings={has_shared}, inlineStr={has_inline}, файл={path.name}")
        except Exception as e:
            self.add(group, "Проверка совместимости XLSX", "FAIL", f"{type(e).__name__}: {e}")

    def summarize(self) -> None:
        counts = {s: 0 for s in ["OK", "WARN", "FAIL", "SKIP", "INFO"]}
        for r in self.results:
            counts[r.status] = counts.get(r.status, 0) + 1
        self.log("")
        self.log("=" * 72)
        self.log(f"ИТОГ: OK={counts.get('OK',0)} WARN={counts.get('WARN',0)} FAIL={counts.get('FAIL',0)} SKIP={counts.get('SKIP',0)} INFO={counts.get('INFO',0)}")
        if counts.get("FAIL", 0):
            self.log("Статус: ЕСТЬ ПРОБЛЕМЫ. Смотри FAIL выше.")
        elif counts.get("WARN", 0):
            self.log("Статус: РАБОТАЕТ, но есть предупреждения.")
        else:
            self.log("Статус: всё выглядит нормально.")
        self.log("=" * 72)

    def save_reports(self) -> Tuple[Path, Path, Path]:
        txt_path = self.report_base.with_suffix(".txt")
        json_path = self.report_base.with_suffix(".json")
        csv_path = self.report_base.with_suffix(".csv")
        txt_path.write_text("\n".join(self.text_lines) + "\n", encoding="utf-8")
        json_path.write_text(json.dumps([asdict(r) for r in self.results], ensure_ascii=False, indent=2), encoding="utf-8")
        with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=["group", "name", "status", "details", "duration_ms"], delimiter=";")
            writer.writeheader()
            for r in self.results:
                writer.writerow(asdict(r))
        return txt_path, json_path, csv_path

    def run(self) -> None:
        self.log("SAI Doctor — жёсткая диагностика SIGMA / SAI")
        self.log(f"Версия SAI: {APP_VERSION}")
        self.log(f"Версия Doctor: {DOCTOR_VERSION}")
        self.log(f"Старт: {dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self.log("ВНИМАНИЕ: диагностика read-only, приходов и товаров не создаёт.")
        self.log("")
        self.check_environment()
        self.load_config()
        self.check_network()
        self.check_x_api_key_api()
        self.check_browser_bearer_api()
        self.check_sqlite()
        self.check_xlsx_compat()
        self.summarize()
        txt, js, csv_path = self.save_reports()
        self.log(f"Отчёт TXT: {txt}")
        self.log(f"Отчёт JSON: {js}")
        self.log(f"Отчёт CSV: {csv_path}")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="SAI Doctor — read-only SIGMA/API diagnostic utility")
    parser.add_argument("--deep", action="store_true", help="глубоко проверить каталог products с пагинацией")
    parser.add_argument("--no-browser", action="store_true", help="не открывать Chromium/Playwright для токена")
    parser.add_argument("--visible-browser", action="store_true", help="принудительно показать браузер")
    parser.add_argument("--hidden-browser", action="store_true", help="принудительно скрыть браузер")
    args = parser.parse_args(argv)

    visible: Optional[bool] = None
    if args.visible_browser:
        visible = True
    if args.hidden_browser:
        visible = False
    doctor = Doctor(deep=args.deep, browser=not args.no_browser, visible_browser=visible)
    try:
        doctor.run()
        return 0 if not any(r.status == "FAIL" for r in doctor.results) else 2
    except KeyboardInterrupt:
        print("\nОстановлено пользователем.")
        return 130
    except Exception:
        ensure_runtime_dirs()
        err_path = LOGS_DIR / f"sai_doctor_crash_{now_stamp()}.txt"
        err_path.write_text(traceback.format_exc(), encoding="utf-8")
        print(f"SAI Doctor crashed: {err_path}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
