#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7at audit merge safety."""
from __future__ import annotations

import ast
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
app = root / "app"

assert 'VERSION = "1.22.7at"' in (app / "sai_version.py").read_text(encoding="utf-8")
assert 'APP_VERSION == "v1.22.7at"' in (app / "run_self_tests.py").read_text(encoding="utf-8")

reconciliation = app / "sai_invoice_ai_reconciliation.py"
tests = app / "run_invoice_ai_reconciliation_tests.py"
for path in (reconciliation, tests):
    assert path.is_file(), path
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

text = reconciliation.read_text(encoding="utf-8")
for token in (
    "ignored_empty_",
    "ignored_empty_barcodes",
    "parsed>0",
):
    assert token in text, token

subprocess.run([sys.executable, str(app / "run_invoice_ai_tests.py"), str(root)], cwd=app, check=True)

wiki = root / "SAI_Ecosystem_Wiki_v0.1"
manifest = json.loads((wiki / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "3.1"
assert manifest["snapshot_sai_version"] == "1.22.7at"
assert (wiki / "decisions" / "ADR-028-NON-DESTRUCTIVE-ROW-AUDIT-MERGE.md").is_file()
assert (wiki / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v3.1 / SAI 1.22.7at")

print("PATCH_AT_SELF_TEST_OK")
