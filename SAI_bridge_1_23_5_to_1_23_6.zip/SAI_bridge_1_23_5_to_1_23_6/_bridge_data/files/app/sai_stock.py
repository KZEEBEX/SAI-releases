#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Application boundary for the optional SAI Warehouse module."""
from __future__ import annotations

import sqlite3
import uuid
import json
import re
import datetime as dt
from decimal import Decimal
from typing import Any

from sai_core_v2.manual_receipt import money_float
from sai_core_v2.stock import (
    StockMovement, balances, ensure_location, link_external_product,
    record_movement, stock_balance, sync_sigma_identities,
)
from sai_core_v2.product_events import (
    ProductEvent, ensure_product_event_schema, product_timeline, record_product_event,
    sync_product_event_journal,
)
from sai_core_v2.sigma_warehouse import (
    actual_balances, analytic_product_name_condition, analytic_quantity_condition,
    ensure_sigma_warehouse_schema, product_summary,
)

_SEARCH_SEPARATOR = re.compile(r"[^0-9A-ZА-Я]+")
_SEARCH_SPACES = re.compile(r"\s+")
_PRICE_KEYS = {
    "sellingCostPerUnit", "sellingCost", "sellingPrice", "productPrice",
    "retailPrice", "salePrice", "price", "cost", "value",
}


def _search_text(value: Any) -> str:
    """Normalize one catalog field without touching disk or user rule files."""
    raw = str(value or "").upper().replace("Ё", "Е")
    return _SEARCH_SPACES.sub(" ", _SEARCH_SEPARATOR.sub(" ", raw)).strip()


def _catalog_price(raw_json: Any) -> Decimal:
    """Extract a catalog price with one JSON decode, even for nested SIGMA items."""
    try:
        root = json.loads(raw_json or "{}") if isinstance(raw_json, str) else raw_json
    except Exception:
        return Decimal("0")
    stack = [root]
    while stack:
        value = stack.pop()
        if isinstance(value, dict):
            for key in _PRICE_KEYS:
                if key in value:
                    number = money_float(value.get(key))
                    if number:
                        return Decimal(str(number))
            stack.extend(value.values())
        elif isinstance(value, (list, tuple)):
            stack.extend(value)
    return Decimal("0")


class StockService:
    """Coordinate catalog identity and stock operations in one transaction."""

    def __init__(self, connection: sqlite3.Connection):
        self.connection = connection
        ensure_product_event_schema(self.connection)
        ensure_sigma_warehouse_schema(self.connection)

    def prepare_sigma_catalog(self, company_key: str) -> int:
        with self.connection:
            return sync_sigma_identities(self.connection, company_key)

    def ensure_location(self, location_id: str, name: str, location_type: str = "store") -> None:
        with self.connection:
            ensure_location(self.connection, location_id, name, location_type)

    def sigma_product_id(self, company_key: str, sigma_id: str) -> str:
        with self.connection:
            return link_external_product(self.connection, "sigma", company_key, sigma_id)

    def post(self, movement: StockMovement) -> tuple[str, bool]:
        with self.connection:
            movement_id, created = record_movement(self.connection, movement)
            if created:
                record_product_event(self.connection, ProductEvent(
                    idempotency_key=f"stock:{movement_id}",
                    sai_product_id=movement.sai_product_id,
                    event_type=movement.movement_type,
                    quantity_delta=movement.quantity_delta,
                    unit_cost=movement.unit_cost,
                    location_id=movement.location_id,
                    source_system=movement.source_system or "sai_stock",
                    source_document_id=movement.source_document_id,
                    occurred_at=movement.occurred_at,
                    note=movement.note,
                    metadata={"stock_movement_id": movement_id},
                ))
            return movement_id, created

    def balance(self, sai_product_id: str, location_id: str) -> Decimal:
        remote = actual_balances(self.connection, location_id)
        if sai_product_id in remote:
            return remote[sai_product_id]
        return stock_balance(self.connection, sai_product_id, location_id)

    def location_balances(self, location_id: str) -> dict[str, Decimal]:
        local = balances(self.connection, location_id)
        remote = actual_balances(self.connection, location_id)
        local.update(remote)
        return local

    def actual_balance_ids(self, location_id: str) -> set[str]:
        return set(actual_balances(self.connection, location_id))

    def sync_all_catalog_identities(self) -> int:
        existing = {
            (str(row[0]), str(row[1]))
            for row in self.connection.execute(
                "SELECT company_key, external_id FROM product_identities WHERE source_system='sigma'"
            )
        }
        missing = [
            (str(row[0]), str(row[1]))
            for row in self.connection.execute("SELECT DISTINCT company_key, sigma_id FROM products")
            if (str(row[0]), str(row[1])) not in existing
        ]
        with self.connection:
            for company_key, sigma_id in missing:
                link_external_product(self.connection, "sigma", company_key, sigma_id)
        return len(missing)

    def locations(self) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            """SELECT location_id, name, location_type
               FROM stock_locations WHERE active=1 ORDER BY name COLLATE NOCASE"""
        )
        return [{"id": str(row[0]), "name": str(row[1]), "type": str(row[2])} for row in rows]

    def catalog_revision(self) -> tuple[int, str, int]:
        product_count, updated_at = self.connection.execute(
            "SELECT COUNT(*), COALESCE(MAX(updated_at), '') FROM products"
        ).fetchone()
        identity_count = self.connection.execute(
            "SELECT COUNT(*) FROM product_identities WHERE source_system='sigma'"
        ).fetchone()[0]
        return int(product_count), str(updated_at), int(identity_count)

    def catalog_rows(self, location_id: str) -> list[dict[str, Any]]:
        current_balances = self.location_balances(location_id)
        actual_ids = self.actual_balance_ids(location_id)
        rows = self.connection.execute(
            """SELECT i.sai_product_id, i.external_id, COALESCE(p.name, i.external_id),
                      COALESCE(p.vendor_code, ''), COALESCE(p.barcodes_json, '[]'),
                      COALESCE(p.raw_json, '{}')
               FROM product_identities i
               LEFT JOIN products p ON p.sigma_id=i.external_id AND p.company_key=i.company_key
               WHERE i.source_system='sigma' ORDER BY 2 COLLATE NOCASE"""
        )
        result: list[dict[str, Any]] = []
        for row in rows:
            product_id = str(row[0])
            price = _catalog_price(row[5])
            try:
                barcode_values = tuple(str(code) for code in json.loads(row[4] or "[]"))
            except Exception:
                barcode_values = ()
            name, article = str(row[2]), str(row[3])
            price_text = format(price.normalize(), "f") if price else "0"
            name_search = _search_text(name)
            article_search = _search_text(article)
            barcode_search = " ".join(barcode_values).upper()
            price_search = _search_text(f"{price_text} {price_text.replace('.', ',')}")
            result.append({
                "sai_product_id": product_id, "sigma_product_id": str(row[1]),
                "name": name, "article": article,
                "barcodes": barcode_values, "price": price,
                "balance": current_balances.get(product_id, Decimal("0")),
                "balance_actual": product_id in actual_ids,
                "_name_search": name_search, "_article_search": article_search,
                "_barcode_search": barcode_search, "_price_search": price_search,
                "_all_search": f"{name_search} {article_search} {barcode_search} {price_search}",
            })
        return result

    @staticmethod
    def search_catalog_rows(
        rows: list[dict[str, Any]], search: str = "", limit: int = 250,
    ) -> tuple[list[dict[str, Any]], int]:
        query = _search_text(search)
        if not query:
            return rows[:max(1, int(limit))], len(rows)
        tokens = tuple(token for token in query.split() if token)
        ranked: list[tuple[int, str, dict[str, Any]]] = []
        for row in rows:
            name = row["_name_search"]
            article = row["_article_search"]
            barcodes = row["_barcode_search"]
            price = row["_price_search"]
            if not all(token in row["_all_search"] for token in tokens):
                continue
            score = 0
            if query == article or query in barcodes.split():
                score += 2000
            if query == name:
                score += 1600
            if name.startswith(query):
                score += 900
            for token in tokens:
                if name.startswith(token) or f" {token}" in f" {name}":
                    score += 180
                elif token in name:
                    score += 110
                if article.startswith(token):
                    score += 150
                if any(code.startswith(token) for code in barcodes.split()):
                    score += 170
                if token in price:
                    score += 80
            ranked.append((-score, name, row))
        ranked.sort(key=lambda item: (item[0], item[1]))
        matches = [item[2] for item in ranked]
        return matches[:max(1, int(limit))], len(matches)

    def stock_rows(self, location_id: str, search: str = "", limit: int = 250) -> list[dict[str, Any]]:
        rows, _total = self.search_catalog_rows(self.catalog_rows(location_id), search, limit)
        return rows

    def movement_rows(self, location_id: str = "", limit: int = 500) -> list[dict[str, Any]]:
        rows = self.connection.execute(
            """SELECT m.event_id, m.occurred_at, m.event_type, m.quantity_delta,
                      COALESCE((SELECT p.name FROM products p
                                WHERE p.sigma_id=i.external_id AND p.company_key=i.company_key
                                ORDER BY p.updated_at DESC LIMIT 1), i.external_id),
                      COALESCE(l.name, ''), m.note, m.source_document_id
               FROM product_events m
               JOIN product_identities i ON i.sai_product_id=m.sai_product_id
               LEFT JOIN stock_locations l ON l.location_id=m.location_id
               WHERE (?='' OR m.location_id=? OR m.location_id IS NULL)
               ORDER BY m.occurred_at DESC, m.recorded_at DESC LIMIT ?""",
            (location_id, location_id, max(1, int(limit))),
        )
        return [
            {"id": str(r[0]), "date": str(r[1]), "type": str(r[2]), "quantity": None if r[3] in (None, "") else Decimal(str(r[3])),
             "product": str(r[4]), "location": str(r[5]), "note": str(r[6] or ""), "document": str(r[7] or "")}
            for r in rows
        ]

    def sync_event_journal(self) -> dict[str, int]:
        with self.connection:
            return sync_product_event_journal(self.connection)

    def product_timeline_rows(self, sai_product_id: str, limit: int = 250) -> list[dict[str, Any]]:
        return product_timeline(self.connection, sai_product_id, limit)

    def product_dashboard(self, sai_product_id: str, location_id: str) -> dict[str, Any]:
        return product_summary(self.connection, sai_product_id, location_id)

    def analytics_overview(self, location_id: str, days: int = 30) -> dict[str, Any]:
        period_days = max(1, int(days))
        start = (dt.date.today() - dt.timedelta(days=period_days - 1)).isoformat()
        daily_rows = self.connection.execute(
            """SELECT metric_date, CAST(net_revenue AS REAL), receipt_count,
                      CAST(units_sold AS REAL)
               FROM sigma_daily_metrics
               WHERE location_id=? AND metric_date>=? ORDER BY metric_date""",
            (location_id, start),
        ).fetchall()
        if not daily_rows:
            # The detailed sales archive becomes useful immediately, even if a
            # long historical sync was interrupted before the final aggregate
            # table was rebuilt.
            quantity_filter = analytic_quantity_condition()
            daily_rows = self.connection.execute(
                f"""SELECT substr(operation_time, 1, 10),
                          COALESCE(SUM(
                              CASE WHEN direction='return' THEN -1 ELSE 1 END *
                              COALESCE(
                                  CAST(line_total AS REAL),
                                  CAST(unit_price AS REAL) * CAST(quantity AS REAL), 0
                              )
                          ), 0),
                          COUNT(DISTINCT CASE WHEN direction='sale' THEN operation_id END),
                          COALESCE(SUM(
                              CASE WHEN direction='sale' AND {quantity_filter}
                                   THEN CAST(quantity AS REAL) ELSE 0 END
                          ), 0)
                   FROM sigma_sale_lines
                   WHERE operation_time>=?
                   GROUP BY substr(operation_time, 1, 10)
                   ORDER BY substr(operation_time, 1, 10)""",
                (start,),
            ).fetchall()
        clean_units = {
            str(row[0]): Decimal(str(row[1] or 0))
            for row in self.connection.execute(
                f"""SELECT substr(operation_time, 1, 10),
                           COALESCE(SUM(CASE WHEN direction='sale'
                                             AND {analytic_quantity_condition()}
                                             THEN CAST(quantity AS REAL) ELSE 0 END), 0)
                    FROM sigma_sale_lines
                    WHERE operation_time>=?
                    GROUP BY substr(operation_time, 1, 10)""",
                (start,),
            )
        }
        daily_rows = [
            (row[0], row[1], row[2], clean_units.get(str(row[0]), Decimal("0")))
            for row in daily_rows
        ]
        revenue = sum(Decimal(str(row[1] or 0)) for row in daily_rows)
        checks = sum(int(row[2] or 0) for row in daily_rows)
        units = sum(Decimal(str(row[3] or 0)) for row in daily_rows)
        stock_row = self.connection.execute(
            """SELECT COUNT(*), COALESCE(SUM(CAST(quantity AS REAL)), 0),
                      COALESCE(SUM(CAST(quantity AS REAL) * CAST(COALESCE(buying_price, '0') AS REAL)), 0)
               FROM sigma_stock_current WHERE location_id=? AND CAST(quantity AS REAL)>0""",
            (location_id,),
        ).fetchone()
        attention = self.attention_rows(location_id, limit=80)
        stock_name = """COALESCE((SELECT p.name FROM product_identities i
                                   JOIN products p ON p.sigma_id=i.external_id AND p.company_key=i.company_key
                                   WHERE i.sai_product_id=s.sai_product_id LIMIT 1), s.sigma_product_id)"""
        sale_filter = analytic_quantity_condition("l")
        attention_count = int(self.connection.execute(
            f"""SELECT COUNT(*) FROM (
                   SELECT s.sai_product_id
                   FROM sigma_stock_current s
                   LEFT JOIN sigma_sale_lines l ON l.sai_product_id=s.sai_product_id
                   WHERE s.location_id=? AND CAST(s.quantity AS REAL)>0
                     AND {analytic_product_name_condition(stock_name)}
                   GROUP BY s.sai_product_id
                   HAVING MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                                   THEN l.operation_time END) IS NULL
                       OR substr(MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                                          THEN l.operation_time END),1,10)<?
               )""",
            (location_id, (dt.date.today() - dt.timedelta(days=90)).isoformat()),
        ).fetchone()[0] or 0)
        return {
            "revenue": revenue,
            "checks": checks,
            "average_check": revenue / checks if checks else Decimal("0"),
            "units_sold": units,
            "stock_products": int(stock_row[0] or 0),
            "stock_units": Decimal(str(stock_row[1] or 0)),
            "stock_cost": Decimal(str(stock_row[2] or 0)),
            "attention_count": attention_count,
            "attention": attention,
            "chart_labels": tuple(str(row[0])[5:] for row in daily_rows),
            "chart_values": tuple(float(row[1] or 0) for row in daily_rows),
        }

    def attention_rows(self, location_id: str, limit: int = 80) -> list[dict[str, Any]]:
        threshold = (dt.date.today() - dt.timedelta(days=90)).isoformat()
        stock_name = """COALESCE((SELECT p.name FROM product_identities i
                                   JOIN products p ON p.sigma_id=i.external_id AND p.company_key=i.company_key
                                   WHERE i.sai_product_id=s.sai_product_id LIMIT 1), s.sigma_product_id)"""
        sale_filter = analytic_quantity_condition("l")
        rows = self.connection.execute(
            f"""SELECT s.sai_product_id,
                      {stock_name},
                      CAST(s.quantity AS REAL),
                      MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                               THEN l.operation_time END),
                      COALESCE(SUM(CASE WHEN l.direction='sale'
                                         AND {sale_filter}
                                         AND l.operation_time>=date('now','-30 day')
                                         THEN CAST(l.quantity AS REAL) ELSE 0 END), 0)
               FROM sigma_stock_current s
               LEFT JOIN sigma_sale_lines l ON l.sai_product_id=s.sai_product_id
               WHERE s.location_id=? AND CAST(s.quantity AS REAL)>0
                 AND {analytic_product_name_condition(stock_name)}
               GROUP BY s.sai_product_id, s.sigma_product_id, s.quantity
               HAVING MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                               THEN l.operation_time END) IS NULL
                   OR substr(MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                                      THEN l.operation_time END),1,10)<?
               ORDER BY CASE WHEN MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                                           THEN l.operation_time END) IS NULL THEN 0 ELSE 1 END,
                        MAX(CASE WHEN l.direction='sale' AND {sale_filter}
                                 THEN l.operation_time END),
                        CAST(s.quantity AS REAL) DESC
               LIMIT ?""",
            (location_id, threshold, max(1, int(limit))),
        ).fetchall()
        result = []
        for product_id, name, balance, last_sale, sold_30 in rows:
            result.append({
                "sai_product_id": str(product_id),
                "name": str(name or ""),
                "balance": Decimal(str(balance or 0)),
                "sold_30": Decimal(str(sold_30 or 0)),
                "last_sale": str(last_sale or ""),
                "reason": "Продаж ещё не найдено" if not last_sale else "Нет продаж более 90 дней",
            })
        return result

    def post_manual(
        self, *, sai_product_id: str, location_id: str, operation: str,
        quantity: Decimal, note: str = "",
    ) -> tuple[str, bool]:
        value = Decimal(str(quantity))
        if operation == "receipt":
            if value <= 0:
                raise ValueError("Количество должно быть больше нуля")
            delta = abs(value)
        elif operation == "writeoff":
            if value <= 0:
                raise ValueError("Количество должно быть больше нуля")
            if self.balance(sai_product_id, location_id) < value:
                raise ValueError("Нельзя списать больше текущего остатка")
            delta = -abs(value)
        elif operation == "adjustment":
            if value < 0:
                raise ValueError("Фактический остаток не может быть отрицательным")
            delta = value - self.balance(sai_product_id, location_id)
        else:
            raise ValueError("Неизвестная складская операция")
        if delta == 0:
            raise ValueError("Остаток уже имеет это значение")
        return self.post(StockMovement(
            idempotency_key=f"manual:{uuid.uuid4()}", sai_product_id=sai_product_id,
            location_id=location_id, movement_type=operation, quantity_delta=delta,
            source_system="sai_manual", note=note,
        ))
