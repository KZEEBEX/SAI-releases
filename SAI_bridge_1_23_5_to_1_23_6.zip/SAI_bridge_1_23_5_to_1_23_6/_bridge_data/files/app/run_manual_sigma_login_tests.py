#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression tests for the credential-blind manual SIGMA login route."""
from __future__ import annotations

import contextlib
import io
import os
from pathlib import Path
import sys
import tempfile
import json
import datetime as dt

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import sai_waybill_creator as creator
import sigma_autoprihod as autoprihod
from sai_secret_store import protect_config_secret, reveal_config_secret
from sigma_autoprihod import wait_until_sigma_logged_in


class _Closable:
    def __init__(self) -> None:
        self.closed = False

    def close(self) -> None:
        self.closed = True

    def stop(self) -> None:
        self.closed = True


def test_manual_cli_contract() -> None:
    captured = {}
    playwright = _Closable()
    context = _Closable()
    page = object()
    client = object()

    def fake_open(
        user_data_dir,
        api_base,
        cloud_url,
        login_timeout,
        sigma_login,
        sigma_password,
        sigma_legacy_login="",
        sigma_legacy_password="",
        sigma_atol_max_attempts=3,
        visible=True,
        prefer_bundled_chromium=True,
        hidden_auto_visible_after=0,
    ):
        captured.update({
            "user_data_dir": user_data_dir,
            "login_timeout": login_timeout,
            "sigma_login": sigma_login,
            "sigma_password": sigma_password,
            "sigma_legacy_login": sigma_legacy_login,
            "sigma_legacy_password": sigma_legacy_password,
            "sigma_atol_max_attempts": sigma_atol_max_attempts,
            "visible": visible,
        })
        return playwright, context, page, client

    original_open = creator.open_sigma_context
    original_discover = creator.discover_company_id
    original_argv = sys.argv[:]
    creator.open_sigma_context = fake_open
    creator.discover_company_id = lambda _client, _preferred="": (
        "company-1",
        [{"id": "supplier-1", "name": "Тестовый поставщик"}],
        {},
    )
    try:
        with tempfile.TemporaryDirectory(prefix="sai_manual_sigma_") as profile:
            sys.argv = [
                "sai_waybill_creator.py",
                "--mode", "list-suppliers",
                "--user-data-dir", profile,
                "--manual-login",
                "--hidden-browser",
                "--sigma-login", "must-not-leak",
                "--sigma-password", "must-not-leak",
                "--login-timeout", "17",
            ]
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                result = creator.main()
    finally:
        creator.open_sigma_context = original_open
        creator.discover_company_id = original_discover
        sys.argv = original_argv

    text = output.getvalue()
    assert result == 0
    assert captured["visible"] is True
    assert captured["sigma_login"] == ""
    assert captured["sigma_password"] == ""
    assert captured["sigma_legacy_login"] == ""
    assert captured["sigma_legacy_password"] == ""
    assert captured["login_timeout"] == 17
    assert "SAI_MANUAL_LOGIN_WAITING:" in text
    assert "SAI_MANUAL_LOGIN_OK" in text
    assert "SAI_SUPPLIERS_JSON:" in text
    assert context.closed and playwright.closed


def test_sigma_password_is_dpapi_protected() -> None:
    encrypted = protect_config_secret("test-sigma-password")
    assert encrypted.startswith("dpapi:v1:")
    assert "test-sigma-password" not in encrypted
    assert reveal_config_secret(encrypted) == "test-sigma-password"
    assert reveal_config_secret("legacy-plaintext") == "legacy-plaintext"


def test_atol_phone_is_canonical_everywhere() -> None:
    assert autoprihod.normalize_sigma_login("8 (999) 000-11-22") == "79990001122"
    assert autoprihod.normalize_sigma_login("+7 999 000 11 22") == "79990001122"
    assert autoprihod.sigma_backend_login("89990001122") == "+79990001122"
    assert autoprihod.sigma_backend_login("79990001122") == "+79990001122"


def test_direct_legacy_oauth_login() -> None:
    calls = {}

    class Response:
        def __init__(self, payload=None, text="", status=200):
            self._payload = payload
            self.text = text or ("" if payload is None else "{}")
            self.status_code = status
            self.ok = 200 <= status < 300

        def json(self):
            return self._payload

        def raise_for_status(self):
            if not self.ok:
                raise RuntimeError(self.status_code)

    original_get = creator.requests.get
    original_post = creator.requests.post
    original_request = creator.requests.request
    original_save = creator.save_runtime_token_cache
    try:
        creator.requests.get = lambda url, timeout=30: Response(
            text='window.CONFIG={clientId:"public-client",clientSecret:"public-secret"}'
        )

        def fake_post(url, auth=None, data=None, timeout=30):
            calls["post"] = {"url": url, "auth": auth, "data": dict(data or {})}
            return Response({"access_token": "header.payload.signature"})

        def fake_request(method, url, headers=None, json=None, timeout=45):
            calls["account"] = {"method": method, "url": url, "headers": dict(headers or {})}
            return Response({"id": "account-1"})

        creator.requests.post = fake_post
        creator.requests.request = fake_request
        creator.save_runtime_token_cache = lambda token, api_base: calls.update(
            {"cache": {"token": token, "api_base": api_base}}
        )
        client = creator.open_legacy_requests_client(
            "https://api-s07.sigma.ru",
            "https://cloud.sigma.ru",
            "89990001122",
            "configured-password",
        )
        assert isinstance(client, creator.LegacyRequestsSigmaClient)
        assert calls["post"]["data"]["username"] == "+79990001122"
        assert calls["post"]["data"]["password"] == "configured-password"
        assert calls["account"]["headers"]["Authorization"] == "Bearer header.payload.signature"
        assert calls["cache"]["token"] == "header.payload.signature"
    finally:
        creator.requests.get = original_get
        creator.requests.post = original_post
        creator.requests.request = original_request
        creator.save_runtime_token_cache = original_save


def test_recent_runtime_token_uses_direct_client() -> None:
    original_cache_dir = creator.CACHE_DIR
    original_request = creator.requests.request
    calls = []

    class Response:
        ok = True
        text = '{"id":"account-1"}'
        status_code = 200

        @staticmethod
        def json():
            return {"id": "account-1"}

    try:
        with tempfile.TemporaryDirectory(prefix="sai_fast_sigma_") as folder:
            creator.CACHE_DIR = Path(folder)
            (creator.CACHE_DIR / "sigma_runtime_token.json").write_text(
                json.dumps({
                    "token": "cached-token",
                    "api_base": "https://api-s07.sigma.ru",
                    "created_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }),
                encoding="utf-8",
            )

            def fake_request(method, url, headers=None, json=None, timeout=45):
                calls.append((method, url, dict(headers or {})))
                return Response()

            creator.requests.request = fake_request
            client, api_base = creator.open_recent_runtime_client("https://unused.invalid")
            assert isinstance(client, creator.LegacyRequestsSigmaClient)
            assert api_base == "https://api-s07.sigma.ru"
            assert calls == [("GET", "https://api-s07.sigma.ru/rest/1.1/account", {
                "Authorization": "Bearer cached-token", "Accept": "application/json",
            })]
    finally:
        creator.CACHE_DIR = original_cache_dir
        creator.requests.request = original_request


def test_settings_wiring() -> None:
    source = (Path(__file__).with_name("sai_pyside_preview.py")).read_text(encoding="utf-8")
    button = 'QPushButton("Ручной вход в SIGMA")'
    assert button in source
    assert source.index("cat_row.addWidget(self.manual_sigma_login_btn)") < source.index(
        "cat_row.addWidget(self.catalog_rebuild_btn)"
    )

    start = source.index("    def start_manual_sigma_login(self)")
    finish = source.index("    def _manual_sigma_suppliers_finished", start)
    next_method = source.index("\n    def ", finish + 5)
    start_body = source[start:finish]
    finish_body = source[finish:next_method]
    assert "manual_login=True" in start_body
    assert "on_finished=self._manual_sigma_suppliers_finished" in start_body
    assert "if not ok:" in finish_body
    assert "self.parent_page.force_catalog_full_rebuild_now()" in finish_body
    assert finish_body.index("if not ok:") < finish_body.index("force_catalog_full_rebuild_now()")
    assert "def _suppliers_process_error" in source
    assert "QProcess.ProcessError.FailedToStart" in source
    assert 'cfg.get("hidden_browser_auto_visible_after_seconds") or 20' in source
    assert '"--hidden-auto-visible-after", str(max(5, auto_after))' in source
    assert "SIGMA требует повторный вход через ATOL ID." in source


def test_legacy_token_cookie_is_supported() -> None:
    source = (Path(__file__).with_name("sigma_autoprihod.py")).read_text(encoding="utf-8")
    assert 'document.cookie' in source
    assert 'startsWith("token=")' in source
    assert '"/oldwaylogin" not in lower_url' in source
    assert autoprihod.is_sigma_login_page("https://cloud.sigma.ru/oldWayLogin")
    assert autoprihod.is_sigma_login_page("https://id.atol.ru/auth/realms/test")
    assert not autoprihod.is_sigma_login_page("https://cloud.sigma.ru/documents")
    assert not autoprihod.is_sigma_login_page("https://cloud.sigma.ru/dashboard")


def test_hidden_supplier_refresh_reopens_visible_login() -> None:
    attempts = []

    class Page:
        pass

    original_launch = creator.launch_persistent_sigma_context
    original_wait = creator.wait_until_sigma_logged_in
    original_install = creator.install_sigma_token_capture
    original_click = creator.click_common_popups
    original_client = creator.SigmaClient
    original_save_token = creator.save_runtime_token_cache

    class Context(_Closable):
        def __init__(self, visible):
            super().__init__()
            self.pages = [Page()]
            self.visible = visible

    class Client:
        def __init__(self, page, api_base, cloud_url, verbose=False):
            pass

        def get_api_access_token(self):
            return "token"

    def fake_launch(playwright, user_data_dir, visible, prefer_bundled_chromium=True):
        attempts.append(bool(visible))
        return Context(visible)

    try:
        creator.launch_persistent_sigma_context = fake_launch
        creator.install_sigma_token_capture = lambda page: None
        creator.click_common_popups = lambda page, rounds=8: None
        creator.SigmaClient = Client
        creator.save_runtime_token_cache = lambda token, api_base: None
        creator.wait_until_sigma_logged_in = lambda *args, **kwargs: bool(attempts[-1])
        playwright, context, page, client = creator.open_sigma_context(
            "profile",
            "https://api.sigma.ru",
            "https://cloud.sigma.ru",
            300,
            "",
            "",
            visible=False,
            hidden_auto_visible_after=20,
        )
        assert attempts == [False, True]
        assert context.visible is True
        context.close()
        playwright.stop()
    finally:
        creator.launch_persistent_sigma_context = original_launch
        creator.wait_until_sigma_logged_in = original_wait
        creator.install_sigma_token_capture = original_install
        creator.click_common_popups = original_click
        creator.SigmaClient = original_client
        creator.save_runtime_token_cache = original_save_token


def test_closed_login_window_cancels_immediately() -> None:
    class ClosedPage:
        def is_closed(self):
            return True

    assert wait_until_sigma_logged_in(
        ClosedPage(),
        "https://cloud.sigma.ru",
        "https://api.sigma.ru",
        timeout_sec=900,
    ) is False


def test_atol_outage_uses_legacy_sigma_login() -> None:
    class LegacyPage:
        def __init__(self) -> None:
            self.url = (
                "https://id.atol.ru/auth/realms/ATOL-ID-External/"
                "protocol/openid-connect/auth"
            )
            self.opened = []

        def is_closed(self):
            return False

        def goto(self, url, **kwargs):
            self.opened.append(url)
            self.url = url

        def wait_for_load_state(self, *args, **kwargs):
            return None

    page = LegacyPage()
    clock = [0.0]
    original_time = autoprihod.time.time
    original_sleep = autoprihod.time.sleep
    original_probe = autoprihod.probe_sigma_login_ready
    original_autofill = autoprihod.try_autofill_sigma_credentials
    original_popups = autoprihod.click_common_popups
    original_entry = autoprihod.click_login_entry_buttons
    attempted_logins = []
    try:
        autoprihod.time.time = lambda: clock[0]

        def fake_sleep(seconds):
            clock[0] += float(seconds)

        autoprihod.time.sleep = fake_sleep
        def fake_autofill(_page, login, _password, return_state=False):
            attempted_logins.append(login)
            state = {
                "clicked": "/oldWayLogin" not in _page.url,
                "hasPasswordInput": True,
            }
            return state if return_state else bool(state["clicked"])

        autoprihod.try_autofill_sigma_credentials = fake_autofill
        autoprihod.click_common_popups = lambda *args, **kwargs: None
        autoprihod.click_login_entry_buttons = lambda *args, **kwargs: None
        autoprihod.probe_sigma_login_ready = lambda current, api_base: {
            "ready": "/oldWayLogin" in current.url,
            "hasToken": "/oldWayLogin" in current.url,
            "accountStatus": 200 if "/oldWayLogin" in current.url else None,
            "reason": "SIGMA_ACCOUNT_OK" if "/oldWayLogin" in current.url else "NO_SIGMA_TOKEN_YET",
        }
        assert autoprihod.wait_until_sigma_logged_in(
            page,
            "https://cloud.sigma.ru",
            "https://api.sigma.ru",
            sigma_login="79990001122",
            sigma_password="configured-password",
            legacy_login="89990001122",
            legacy_password="legacy-password",
            atol_max_attempts=3,
            timeout_sec=60,
        )
        assert page.opened == ["https://cloud.sigma.ru/oldWayLogin"]
        assert attempted_logins[:3] == ["79990001122"] * 3
        assert attempted_logins[-1] == "89990001122"
    finally:
        autoprihod.time.time = original_time
        autoprihod.time.sleep = original_sleep
        autoprihod.probe_sigma_login_ready = original_probe
        autoprihod.try_autofill_sigma_credentials = original_autofill
        autoprihod.click_common_popups = original_popups
        autoprihod.click_login_entry_buttons = original_entry


def test_settings_runtime_sequence() -> None:
    from PySide6.QtWidgets import QApplication, QWidget
    from sai_pyside_preview import SettingsPage

    app = QApplication.instance() or QApplication([])

    class Workbench:
        def __init__(self) -> None:
            self.manual = None
            self.callback = None

        def load_suppliers_async(self, *, manual_login=False, on_finished=None):
            self.manual = manual_login
            self.callback = on_finished
            return True

    class Parent(QWidget):
        def __init__(self) -> None:
            super().__init__()
            self.workbench_page = Workbench()
            self.offline_mode = False
            self._background_catalog_running = False
            self.rebuilds = 0
            self.notifications = []
            self.new_receipt_btn = None

        def notify(self, *parts):
            self.notifications.append(parts)

        def force_catalog_full_rebuild_now(self):
            self.rebuilds += 1

        def force_catalog_refresh_now(self):
            pass

        def launch_doctor(self):
            pass

        def browser_visibility_changed(self):
            pass

        def logs_visibility_changed(self):
            pass

    parent = Parent()
    page = SettingsPage(parent)
    page.start_manual_sigma_login()
    assert page.manual_sigma_login_running
    assert not page.manual_sigma_login_btn.isEnabled()
    assert parent.workbench_page.manual is True

    parent.workbench_page.callback(False, "cancelled")
    assert not page.manual_sigma_login_running
    assert page.manual_sigma_login_btn.isEnabled()
    assert parent.rebuilds == 0

    page.start_manual_sigma_login()
    parent.workbench_page.callback(True, "suppliers ready")
    assert not page.manual_sigma_login_running
    assert parent.rebuilds == 1
    page.deleteLater()
    parent.deleteLater()
    app.processEvents()


def main() -> None:
    test_manual_cli_contract()
    test_sigma_password_is_dpapi_protected()
    test_atol_phone_is_canonical_everywhere()
    test_direct_legacy_oauth_login()
    test_recent_runtime_token_uses_direct_client()
    test_settings_wiring()
    test_legacy_token_cookie_is_supported()
    test_hidden_supplier_refresh_reopens_visible_login()
    test_closed_login_window_cancels_immediately()
    test_atol_outage_uses_legacy_sigma_login()
    test_settings_runtime_sequence()
    print("SAI manual SIGMA login tests: OK")


if __name__ == "__main__":
    main()
