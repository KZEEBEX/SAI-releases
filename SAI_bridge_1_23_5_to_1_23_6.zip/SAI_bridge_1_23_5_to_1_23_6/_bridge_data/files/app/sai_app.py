
import csv
import hashlib
from copy import copy
import datetime as dt
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from tkinter import Tk, StringVar, BooleanVar, Text, END, DISABLED, NORMAL, Menu, filedialog, messagebox, Canvas, Toplevel, simpledialog
from tkinter import ttk

import requests

from sai_direct_network import configure_direct_network

configure_direct_network()

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter


from sai_runtime_paths import (
    APP_DIR, ROOT_DIR, USER_DATA_DIR, PROFILE_DIR, TEMPLATES_DIR, CACHE_DIR, LOGS_DIR, DB_PATH,
    CONFIG_PATH, PRIVATE_CONFIG_PATH, PRIVATE_CONFIG_EXAMPLE_PATH,
    ensure_runtime_dirs, migrate_legacy_user_files,
)
import sai_db
import sai_package
import sai_product_names
from sai_print_routing import require_a4_printer_name
from sai_core import BARCODE_RE, extract_barcode_candidates, classify_barcode
from sai_core_v2.pricing import sale_price_from_purchase

SIGMA_PRODUCTS_CACHE_PATH = CACHE_DIR / "sigma_products_cache.json"
FILE_HISTORY_PATH = CACHE_DIR / "sai_file_history.json"
BARCODE_CONFLICT_RESOLUTIONS_PATH = USER_DATA_DIR / "barcode_conflict_resolutions.json"
BOT_SCRIPT = APP_DIR / "sigma_autoprihod.py"
SUPPLIER_PROBE_SCRIPT = APP_DIR / "sai_supplier_waybill_probe.py"
WAYBILL_CREATOR_SCRIPT = APP_DIR / "sai_waybill_creator.py"
API_FIRST_SCRIPT = APP_DIR / "sai_api_first_apply.py"

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
CREATE_NEW_PROCESS_GROUP = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

DEFAULT_STOREHOUSE_ID = "a6990074-f5f6-468a-a92c-f28965fee7c4"
DEFAULT_SAI_SHEET = "Для робота SIGMA"
from sai_version import APP_VERSION
DEFAULT_PRIVATE_CONFIG = {
    "storehouse_id": DEFAULT_STOREHOUSE_ID,
    "sigma_login": "",
    "sigma_password": "",
    "sigma_company_key": "",
    "sigma_api_token": "",
    "sigma_sell_point_id": "",
    "price_policy": "max",
    "startup_preload": True,
    "catalog_fast_mode": True,
    "catalog_trust_fresh_cache_minutes": 30,
    "post_import_retry_waits_seconds": [3],
    "debug_probe_categories": False,
    "vpn_warning_enabled": True,
    "browser_visible": False,
    "sqlite_cache_enabled": True,
    "sqlite_history_enabled": True,
    "exact_name_duplicate_guard": True,
    "prefer_bundled_chromium": True,
    "hidden_browser_auto_visible_after_seconds": 0,
    "post_import_skip_second_full_refresh_when_remaining_leq": 3,
    "catalog_refresh_on_startup": False,
    "catalog_force_refresh_on_startup": False,
    "catalog_require_session_refresh_for_ready": False,
    "sai_ready_enabled": True,
    "sai_ready_startup_delay_seconds": 45,
    "sai_ready_startup_min_age_minutes": 30,
    "sai_ready_retry_attempts": 4,
    "sai_ready_retry_seconds": 45,
    "catalog_background_refresh_interval_minutes": 360,
    "trust_session_sqlite_for_apply": True,
    "require_live_catalog_before_ready": False,
    "apply_live_preflight": False,
    "receipt_fact_enabled": True,
    "price_history_enabled": True,
    "price_history_warn_buy_percent": 15,
    "price_history_warn_sale_percent": 10
}


def ensure_private_config():
    ensure_runtime_dirs()
    if not PRIVATE_CONFIG_EXAMPLE_PATH.exists():
        PRIVATE_CONFIG_EXAMPLE_PATH.write_text(
            json.dumps(DEFAULT_PRIVATE_CONFIG, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    if not PRIVATE_CONFIG_PATH.exists():
        PRIVATE_CONFIG_PATH.write_text(
            json.dumps(DEFAULT_PRIVATE_CONFIG, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    try:
        data = json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict) and not data.get("startup_defaults_v12119_applied"):
            data["browser_visible"] = False
            data["hidden_browser_auto_visible_after_seconds"] = 0
            data["startup_defaults_v12119_applied"] = True
            PRIVATE_CONFIG_PATH.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )
    except Exception:
        pass


def load_private_config():
    ensure_private_config()
    try:
        data = json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        data = {}

    result = dict(DEFAULT_PRIVATE_CONFIG)
    result.update({k: v for k, v in data.items() if v is not None})
    result["sigma_login"] = normalize_sigma_login(result.get("sigma_login"))
    return result


def save_private_config_template_if_missing():
    ensure_private_config()
    return PRIVATE_CONFIG_PATH


def update_private_config(updates):
    updates = dict(updates or {})
    if "sigma_login" in updates:
        updates["sigma_login"] = normalize_sigma_login(updates.get("sigma_login"))
    cfg = load_private_config()
    cfg.update({k: v for k, v in updates.items() if v is not None})
    PRIVATE_CONFIG_PATH.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    return cfg



def read_json_file(path, default):
    try:
        p = Path(path)
        if not p.exists():
            return default
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if data is not None else default
    except Exception:
        return default


def write_json_file(path, data):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def file_fingerprint(path):
    p = Path(path)
    try:
        st = p.stat()
        return {
            "path": str(p),
            "name": p.name,
            "size": int(st.st_size),
            "mtime": float(st.st_mtime),
            "mtime_iso": dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
        }
    except Exception:
        return {
            "path": str(p),
            "name": p.name,
            "size": 0,
            "mtime": 0,
            "mtime_iso": "",
        }


def sai_file_history_key(info):
    return f"{info.get('path','')}|{info.get('size',0)}|{int(float(info.get('mtime') or 0))}"


def load_sai_file_history():
    data = read_json_file(FILE_HISTORY_PATH, {"version": 1, "files": {}})
    if not isinstance(data, dict):
        data = {"version": 1, "files": {}}
    if not isinstance(data.get("files"), dict):
        data["files"] = {}
    return data


def save_sai_file_history(data):
    if not isinstance(data, dict):
        data = {"version": 1, "files": {}}
    data["version"] = 1
    if not isinstance(data.get("files"), dict):
        data["files"] = {}
    write_json_file(FILE_HISTORY_PATH, data)


def get_sai_file_history_entry(path):
    info = file_fingerprint(path)
    key = sai_file_history_key(info)
    data = load_sai_file_history()
    return data.get("files", {}).get(key) or {}


def desktop_download_dirs(extra_dir=""):
    home = Path.home()
    candidates = [
        home / "Desktop",
        home / "Рабочий стол",
        home / "Downloads",
        home / "Загрузки",
    ]
    userprofile = os.environ.get("USERPROFILE")
    if userprofile:
        up = Path(userprofile)
        candidates += [
            up / "Desktop",
            up / "Рабочий стол",
            up / "Downloads",
            up / "Загрузки",
        ]
        onedrive = os.environ.get("OneDrive") or os.environ.get("OneDriveCommercial") or os.environ.get("OneDriveConsumer")
        if onedrive:
            od = Path(onedrive)
            candidates += [od / "Desktop", od / "Рабочий стол", od / "Downloads", od / "Загрузки"]
    if extra_dir:
        candidates.insert(0, Path(extra_dir))

    result = []
    seen = set()
    for p in candidates:
        try:
            rp = str(Path(p).resolve())
        except Exception:
            rp = str(p)
        if rp in seen:
            continue
        seen.add(rp)
        if Path(p).exists() and Path(p).is_dir():
            result.append(Path(p))
    return result


def find_latest_sai_file(extra_dir="", max_depth=1):
    found = []
    for folder in desktop_download_dirs(extra_dir=extra_dir):
        try:
            # Fast shallow search: Desktop/Downloads should be enough for normal use.
            for p in list(folder.glob("SAI_*.sai")) + list(folder.glob("SAI_*.xml")) + list(folder.glob("SAI_*.xlsx")) + list(folder.glob("SAI_*.xlsm")):
                if p.name.startswith("~$"):
                    continue
                if p.is_file():
                    found.append(p)
            # One shallow level below, useful for browser folders/extracted supplier folders.
            if max_depth >= 1:
                for sub in folder.iterdir():
                    if not sub.is_dir():
                        continue
                    for p in list(sub.glob("SAI_*.sai")) + list(sub.glob("SAI_*.xml")) + list(sub.glob("SAI_*.xlsx")) + list(sub.glob("SAI_*.xlsm")):
                        if p.name.startswith("~$"):
                            continue
                        if p.is_file():
                            found.append(p)
        except Exception:
            continue

    if not found:
        return None

    found = sorted(found, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return found[0]


def format_file_history_status(entry):
    if not isinstance(entry, dict) or not entry:
        return ""
    status = safe_str(entry.get("status"))
    when = safe_str(entry.get("updated_at"))
    waybill = safe_str(entry.get("waybill"))
    parts = []
    if status:
        parts.append(status)
    if when:
        parts.append(when)
    if waybill:
        parts.append(f"черновик {waybill}")
    return " / ".join(parts)


def current_sai_needs_forced_catalog_refresh(path):
    entry = get_sai_file_history_entry(path) if safe_str(path) else {}
    status = safe_str(entry.get("status")).lower() if isinstance(entry, dict) else ""
    import_path = safe_str(entry.get("import_path")) if isinstance(entry, dict) else ""
    return bool(import_path) or ("импорт" in status)



def safe_str(value):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def normalize_sigma_login(value):
    digits = re.sub(r"\D+", "", safe_str(value))
    if digits.startswith("8"):
        digits = "7" + digits[1:]
    return digits


def append_sigma_auth_args(args, cfg):
    if str(cfg.get("sigma_login") or "").strip():
        args += ["--sigma-login", str(cfg.get("sigma_login")).strip()]
    if str(cfg.get("sigma_password") or ""):
        args += ["--sigma-password", str(cfg.get("sigma_password"))]
    if str(cfg.get("sigma_legacy_login") or "").strip():
        args += ["--sigma-legacy-login", str(cfg.get("sigma_legacy_login")).strip()]
    if str(cfg.get("sigma_legacy_password") or ""):
        args += ["--sigma-legacy-password", str(cfg.get("sigma_legacy_password"))]
    args += ["--sigma-atol-max-attempts", str(max(1, int(cfg.get("sigma_atol_max_attempts") or 3)))]
    return args


def normalize_unit(value):
    """Normalize product unit to the two allowed SAI/SIGMA values: 'штука' or 'м'."""
    text = safe_str(value).lower().replace(".", " ").replace(",", " ").strip()
    text = re.sub(r"\s+", " ", text)
    if not text:
        return "штука"
    compact = re.sub(r"[^0-9a-zа-яё]+", "", text)

    meter_values = {
        "м", "m", "meter", "metre", "meters", "metres",
        "метр", "метра", "метров", "погм", "пм", "погонныйметр", "погонныхметров",
        "мп", "мпог",
    }
    piece_values = {
        "шт", "штука", "штуки", "штук", "pcs", "pc", "piece", "pieces", "ед", "единица", "единицы",
    }

    if compact in meter_values or text in {"м", "m"}:
        return "м"
    if compact in piece_values or compact.startswith("шт"):
        return "штука"
    if re.fullmatch(r"(пог\s*)?м", text) or "метр" in compact:
        return "м"
    return "штука"


def parse_int_config(value, default=0):
    try:
        if value is None or value == "":
            return int(default)
        return int(value)
    except Exception:
        return int(default)


def normalize_wait_list(value, default=(3,)):
    if value is None:
        value = default
    if isinstance(value, str):
        parts = re.split(r"[,;\s]+", value.strip())
    elif isinstance(value, (list, tuple)):
        parts = value
    else:
        parts = default
    out = []
    for item in parts:
        try:
            n = int(float(item))
        except Exception:
            continue
        if 0 < n <= 60:
            out.append(n)
    return out


def sigma_network_error_hint(text):
    s = safe_str(text)
    low = s.lower()
    markers = (
        "ssLError".lower(),
        "unexpected_eof".lower(),
        "eof occurred".lower(),
        "max retries exceeded".lower(),
        "connection aborted".lower(),
        "connection reset".lower(),
        "timeout".lower(),
        "api.sigma.ru".lower(),
    )
    if any(m in low for m in markers):
        return (
            "Похоже на сетевой обрыв до SIGMA. Проверьте, что VPN выключен: "
            "SIGMA часто рвёт HTTPS/API-соединения при активном VPN. Также может мешать антивирусная HTTPS-проверка."
        )
    return ""


def norm_header(value):
    s = safe_str(value).upper()
    s = s.replace("Ё", "Е")
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def normalize_barcode(value):
    s = safe_str(value)
    if not s:
        return ""
    # Excel sometimes gives 460123... as 4.60123E+12 if the file was broken.
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return s.strip()


def split_barcodes(value):
    return extract_barcode_candidates(value)


def normalize_product_name_for_match(value):
    """Conservative name key for detecting SIGMA import duplicates.

    SIGMA may reject an import row with: "Товар с таким названием уже есть"
    even when the barcode is new/empty. For that case SAI must detect an
    existing product by name and add the incoming barcode to it instead of
    creating a duplicate. Keep this strict enough to avoid unsafe merges.
    """
    s = safe_str(value).upper().replace("Ё", "Е")
    # Make common latin/cyrillic typo variants comparable in dimensions.
    s = s.replace("X", "Х")
    s = re.sub(r"[\"'`«»„“”()\[\]{}.,;:]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def parse_float(value):
    if value is None or value == "":
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    s = safe_str(value).replace("\u00a0", "").replace(" ", "").replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0


def parse_int_or_float(value):
    v = parse_float(value)
    if abs(v - round(v)) < 1e-9:
        return int(round(v))
    return v


def format_num(value):
    v = parse_float(value)
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return f"{v:.2f}".replace(".", ",")


def sanitize_filename_part(text):
    s = safe_str(text) or "Поставщик"
    s = re.sub(r'[<>:"/\\|?*]+', "_", s)
    s = re.sub(r"\s+", "_", s)
    return s.strip("_") or "Поставщик"


def date_code_from_text(text):
    s = safe_str(text)
    if not s:
        return dt.datetime.now().strftime("%d%m%y")

    try:
        from sai_converter import parse_date as parse_invoice_date
        parsed_iso = parse_invoice_date(s)
        if parsed_iso:
            parsed = dt.date.fromisoformat(parsed_iso)
            return parsed.strftime("%d%m%y")
    except Exception:
        pass

    # dd.mm.yyyy / dd-mm-yy / dd/mm/yyyy
    m = re.search(r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})", s)
    if m:
        d, mo, y = m.groups()
        y = int(y)
        if y < 100:
            y += 2000
        return f"{int(d):02d}{int(mo):02d}{str(y)[-2:]}"

    # ddmmyy / ddmmyyyy
    digits = re.sub(r"\D+", "", s)
    if len(digits) == 6:
        return digits
    if len(digits) == 8:
        return digits[:4] + digits[-2:]

    return dt.datetime.now().strftime("%d%m%y")


def date_display_from_text(text):
    s = safe_str(text)
    try:
        from sai_converter import parse_date as parse_invoice_date
        parsed_iso = parse_invoice_date(s)
        if parsed_iso:
            return dt.date.fromisoformat(parsed_iso).strftime("%d.%m.%Y")
    except Exception:
        pass
    m = re.search(r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})", s)
    if m:
        d, mo, y = m.groups()
        y = int(y)
        if y < 100:
            y += 2000
        return f"{int(d):02d}.{int(mo):02d}.{y:04d}"
    digits = re.sub(r"\D+", "", s)
    if len(digits) == 6:
        return f"{digits[:2]}.{digits[2:4]}.20{digits[4:]}"
    if len(digits) == 8:
        return f"{digits[:2]}.{digits[2:4]}.{digits[4:]}"
    return s or dt.datetime.now().strftime("%d.%m.%Y")


def normalize_waybill(value):
    s = safe_str(value).strip('"').strip("'")
    m = re.search(r"[?&]id=([a-fA-F0-9-]{20,})", s)
    if m:
        return m.group(1)
    m = re.search(r"\bid=([a-fA-F0-9-]{20,})", s)
    if m:
        return m.group(1)
    return s


def find_headers(ws):
    # Find a header row by scanning first 20 rows for name/barcode/qty keywords.
    best = None
    best_score = -1

    for row_idx in range(1, min(ws.max_row, 20) + 1):
        values = [norm_header(ws.cell(row_idx, c).value) for c in range(1, ws.max_column + 1)]
        score = 0
        for h in values:
            if any(k in h for k in ["ШК", "ШТРИХ", "BARCODE"]):
                score += 3
            if any(k in h for k in ["НАИМЕНОВАН", "ТОВАР", "НАЗВАН"]):
                score += 3
            if any(k in h for k in ["КОЛ-ВО", "КОЛИЧ"]):
                score += 2
            if "ЗАКУП" in h:
                score += 2
            if "ПРОДАЖ" in h or "ЦЕНА" == h:
                score += 1
        if score > best_score:
            best_score = score
            best = row_idx

    if best is None or best_score <= 0:
        best = 1

    headers = {}
    for col in range(1, ws.max_column + 1):
        raw = safe_str(ws.cell(best, col).value)
        if raw:
            headers[norm_header(raw)] = col
    return best, headers


def pick_col(headers, variants, contains_any=None):
    normalized_variants = [norm_header(v) for v in variants]
    for v in normalized_variants:
        if v in headers:
            return headers[v]

    if contains_any:
        needles = [norm_header(n) for n in contains_any]
        for h, col in headers.items():
            if all(n in h for n in needles):
                return col

    return None



def sai_companion_xml(path):
    """Prefer a canonical .sai package next to legacy Excel; then legacy XML."""
    try:
        p = Path(path)
        if p.suffix.lower() in (".xlsx", ".xlsm"):
            package = p.with_suffix(".sai")
            if package.exists() and package.is_file():
                return package
            xml = p.with_suffix(".xml")
            if xml.exists() and xml.is_file():
                return xml
    except Exception:
        pass
    return Path(path)


def load_sai_package_rows(path):
    """Read the current SAI Package (.sai) receipt format."""
    try:
        return sai_package.load_rows(path)
    except sai_package.SaiPackageError as exc:
        raise ValueError(f"SAI Package повреждён или невалиден: {exc}")


def load_sai_xml_rows(path):
    """Read the machine SAI XML format: <sai_receipt version='1.0'>."""
    p = Path(path)
    try:
        tree = ET.parse(str(p))
    except ET.ParseError as exc:
        raise ValueError(f"SAI XML повреждён или невалиден: {exc}")
    except Exception as exc:
        raise ValueError(f"Не удалось прочитать SAI XML: {exc}")

    root = tree.getroot()
    if root.tag != "sai_receipt":
        raise ValueError("SAI XML: корневой тег должен быть <sai_receipt>.")

    meta_el = root.find("meta")
    items_el = root.find("items")
    if items_el is None:
        raise ValueError("SAI XML: не найден раздел <items>.")

    meta = {}
    if meta_el is not None:
        for child in list(meta_el):
            meta[str(child.tag)] = safe_str(child.text)

    rows = []
    for idx, item in enumerate(items_el.findall("item"), start=1):
        def text(tag, default=""):
            el = item.find(tag)
            return safe_str(el.text if el is not None else default)

        name = text("name")
        qty = parse_int_or_float(text("quantity"))
        buy = parse_float(text("purchase_price"))
        sale = parse_float(text("sale_price"))
        unit = normalize_unit(text("unit", "штука"))
        article = text("article")
        category = text("category")
        comment = text("comment")
        price_operator_approved = text("price_operator_approved").lower() in {"true", "1", "yes", "да"}
        price_approval_source = text("price_approval_source")
        catalog_price_snapshot = parse_float(text("catalog_price_snapshot"))
        price_approval_barcode = text("price_approval_barcode")
        price_tag_accent = text("price_tag_accent")

        barcodes = []
        barcodes_el = item.find("barcodes")
        if barcodes_el is not None:
            for bc_el in barcodes_el.findall("barcode"):
                raw = safe_str(bc_el.text)
                if raw:
                    cleaned = re.sub(r"\D+", "", raw)
                    if cleaned:
                        barcodes.append(cleaned)
        barcode_cell = normalize_import_barcode_cell(barcodes)

        if not name and not barcode_cell and not qty and not buy and not sale:
            continue

        xml_row_raw = safe_str(item.attrib.get("row"))
        try:
            xml_row = int(float(xml_row_raw)) if xml_row_raw else idx
        except Exception:
            xml_row = idx

        rows.append({
            # Keep Excel-like row numbers for existing fact/APPLY code: header row 1, data starts at 2.
            "excel_row": idx + 1,
            "source_row": xml_row,
            "barcode_cell": barcode_cell,
            "barcodes": barcodes,
            "name": name,
            "qty": qty,
            "buy": buy,
            "sale": sale,
            "unit": unit,
            "article": article,
            "category": category,
            "vat": "Без НДС",
            "type": "Обычный товар",
            "comment": comment,
            "source_format": "xml",
            "price_operator_approved": price_operator_approved,
            "price_approval_source": price_approval_source,
            "catalog_price_snapshot": catalog_price_snapshot,
            "price_approval_barcode": price_approval_barcode,
            "price_tag_accent": price_tag_accent,
        })

    if not rows:
        raise ValueError("SAI XML: в <items> нет товарных строк.")

    missing = []
    for i, r in enumerate(rows, start=1):
        if not safe_str(r.get("name")):
            missing.append(f"item {i}: name")
        if r.get("qty") in (None, ""):
            missing.append(f"item {i}: quantity")
        if r.get("buy") in (None, ""):
            missing.append(f"item {i}: purchase_price")
        if r.get("sale") in (None, ""):
            missing.append(f"item {i}: sale_price")
        if r.get("unit") not in ("штука", "м"):
            missing.append(f"item {i}: unit")
    if missing:
        raise ValueError("SAI XML: не заполнены обязательные поля: " + "; ".join(missing[:20]))

    sheet_name = "SAI XML"
    return sheet_name, rows, meta


def write_sai_rows_to_xlsx(rows, out_path, sheet_name=DEFAULT_SAI_SHEET):
    """Create a temporary Excel SAI file from parsed rows. Useful when XML input needs fact adjustments."""
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name or DEFAULT_SAI_SHEET
    headers = [
        "ШК", "Кол-во", "Ед.", "Закуп цена", "Продажная цена", "Наименование",
        "Артикул", "Категория", "Комментарий", "Цена утверждена оператором",
        "Источник утвержденной цены",
        "Важное отличие",
    ]
    ws.append(headers)
    for row in rows or []:
        ws.append([
            normalize_import_barcode_cell(row.get("barcodes") or split_barcodes(row.get("barcode_cell"))),
            row.get("qty") or 0,
            normalize_unit(row.get("unit") or "штука"),
            row.get("buy") or 0,
            row.get("sale") or 0,
            safe_str(row.get("name")),
            safe_str(row.get("article")),
            safe_str(row.get("category")),
            safe_str(row.get("comment")),
            "ДА" if row.get("price_operator_approved") else "",
            safe_str(row.get("price_approval_source")),
            safe_str(row.get("price_tag_accent") or row.get("accent_text")),
        ])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    widths = [26, 10, 10, 14, 16, 46, 18, 18, 28, 16, 18, 24]
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = width
    for r in range(2, ws.max_row + 1):
        ws.cell(r, 1).number_format = "@"
        ws.cell(r, 4).number_format = "0.00"
        ws.cell(r, 5).number_format = "0.00"
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    return str(out_path)

def load_sai_rows(path):
    path = sai_companion_xml(path)
    suffix = Path(path).suffix.lower()
    if suffix == ".sai":
        sheet_name, rows, _meta = load_sai_package_rows(path)
        return sheet_name, rows
    if suffix == ".xml":
        sheet_name, rows, _meta = load_sai_xml_rows(path)
        return sheet_name, rows
    wb = load_workbook(path, data_only=True)
    sheet_name = DEFAULT_SAI_SHEET if DEFAULT_SAI_SHEET in wb.sheetnames else wb.sheetnames[0]
    ws = wb[sheet_name]
    header_row, headers = find_headers(ws)

    col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
    if not col_barcode:
        col_barcode = pick_col(headers, ["BARCODE"], contains_any=["ШК"])

    col_name = (
        pick_col(headers, ["НАИМЕНОВАНИЕ", "ТОВАР", "НАЗВАНИЕ"], contains_any=["НАИМЕНОВАН"])
        or pick_col(headers, ["ТОВАР"], contains_any=["ТОВАР"])
    )
    col_qty = pick_col(headers, ["КОЛ-ВО", "КОЛИЧЕСТВО", "КОЛ-ВО ЕД."], contains_any=["КОЛ"])
    col_buy = pick_col(headers, ["ЗАКУП ЦЕНА", "ЗАКУПОЧНАЯ ЦЕНА", "ЦЕНА ЗАКУПКИ"], contains_any=["ЗАКУП"])
    col_sale = pick_col(headers, ["ПРОДАЖНАЯ ЦЕНА", "ЦЕНА ПРОДАЖИ", "РОЗНИЧНАЯ ЦЕНА"], contains_any=["ПРОДАЖ"])
    if not col_sale:
        # Fall back to any exact "Цена" only if no sale price is present.
        col_sale = pick_col(headers, ["ЦЕНА"])
    col_unit = pick_col(headers, ["ЕД.", "ЕД", "ЕДИНИЦА", "ЕДИНИЦА ИЗМЕРЕНИЯ"], contains_any=["ЕД"])
    col_art = pick_col(headers, ["АРТИКУЛ", "КОД", "КОД ТОВАРА", "КОД ПОСТАВЩИКА"])
    col_category = pick_col(headers, ["КАТЕГОРИЯ", "КАТЕГОРИИ", "ГРУППА", "РАЗДЕЛ", "КАТЕГОРИЯ ТОВАРА"], contains_any=["КАТЕГОР"])
    col_vat = pick_col(headers, ["НДС"])
    col_type = pick_col(headers, ["ТИП"])
    col_price_approved = pick_col(headers, ["ЦЕНА УТВЕРЖДЕНА ОПЕРАТОРОМ"])
    col_price_source = pick_col(headers, ["ИСТОЧНИК УТВЕРЖДЕННОЙ ЦЕНЫ"])
    col_price_tag_accent = pick_col(headers, ["ВАЖНОЕ ОТЛИЧИЕ", "АКЦЕНТ ЦЕННИКА"])

    required = {
        "ШК": col_barcode,
        "НАИМЕНОВАНИЕ": col_name,
        "КОЛ-ВО": col_qty,
        "ЗАКУП ЦЕНА": col_buy,
        "ПРОДАЖНАЯ ЦЕНА": col_sale,
    }
    missing = [k for k, v in required.items() if not v]
    if missing:
        raise ValueError("В SAI-файле не найдены обязательные колонки: " + ", ".join(missing))

    rows = []
    for r in range(header_row + 1, ws.max_row + 1):
        name = safe_str(ws.cell(r, col_name).value)
        barcode_cell = normalize_barcode(ws.cell(r, col_barcode).value)
        qty = parse_int_or_float(ws.cell(r, col_qty).value)
        buy = parse_float(ws.cell(r, col_buy).value)
        sale = parse_float(ws.cell(r, col_sale).value)
        price_approved_text = safe_str(ws.cell(r, col_price_approved).value).upper() if col_price_approved else ""

        if not name and not barcode_cell and not qty and not buy and not sale:
            continue

        rows.append({
            "excel_row": r,
            "barcode_cell": barcode_cell,
            "barcodes": split_barcodes(barcode_cell),
            "name": name,
            "qty": qty,
            "buy": buy,
            "sale": sale,
            "unit": normalize_unit(ws.cell(r, col_unit).value if col_unit else "штука"),
            "article": safe_str(ws.cell(r, col_art).value) if col_art else "",
            "category": safe_str(ws.cell(r, col_category).value) if col_category else "",
            "vat": safe_str(ws.cell(r, col_vat).value) if col_vat else "Без НДС",
            "type": safe_str(ws.cell(r, col_type).value) if col_type else "Обычный товар",
            "price_operator_approved": price_approved_text in {"ДА", "TRUE", "1", "YES"},
            "price_approval_source": safe_str(ws.cell(r, col_price_source).value) if col_price_source else "",
            "price_tag_accent": safe_str(ws.cell(r, col_price_tag_accent).value) if col_price_tag_accent else "",
        })

    return sheet_name, rows


def find_catalog_barcodes(path):
    wb = load_workbook(path, data_only=True, read_only=True)
    all_codes = set()
    debug = []

    for ws in wb.worksheets:
        header_row, headers = find_headers(ws)
        candidate_cols = []

        for h, col in headers.items():
            if "ШК" in h or "ШТРИХ" in h or "BARCODE" in h:
                candidate_cols.append(col)

        # If no barcode-looking headers found, fall back to all columns but only collect 8-16 digits.
        # This avoids mistaking short article codes/prices for barcodes too often.
        if not candidate_cols:
            candidate_cols = list(range(1, ws.max_column + 1))
            fallback_regex = re.compile(r"\d{8,16}")
        else:
            fallback_regex = BARCODE_RE

        before = len(all_codes)
        for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
            for col in candidate_cols:
                if col <= len(row):
                    val = row[col - 1]
                    s = safe_str(val)
                    for code in fallback_regex.findall(s):
                        all_codes.add(code)
        debug.append(f"{ws.title}: +{len(all_codes)-before} ШК")

    return all_codes, debug



SIGMA_IMPORT_HEADERS = [
    "Наименование",
    "Артикул",
    "Единица измерения",
    "Штрихкод",
    "Категория",
    "НДС",
    "Цена",
    "Тип",
    "Товар 18+",
]
SIGMA_IMPORT_TEMPLATE_PATH = TEMPLATES_DIR / "Импорт SIGMA.xlsx"
# SIGMA import is sensitive to Excel number formats.
# Real-world tests showed:
# - General / integer-looking prices can be rejected by SIGMA;
# - forced three decimals (0,000) can also be rejected;
# - one decimal place (60,0) is accepted.
# Keep the cell numeric, but display exactly one decimal place.
SIGMA_IMPORT_PRICE_NUMBER_FORMAT = "0.0"


def _xml_text_from_si(si):
    """Return plain text from a shared-string <si> item, including rich-text runs."""
    if si is None:
        return ""
    parts = []
    for elem in si.iter():
        if elem.tag.endswith("}t") or elem.tag == "t":
            if elem.text:
                parts.append(elem.text)
    return "".join(parts)


def make_xlsx_sigma_compatible(path):
    """
    Make generated XLSX files easier for the SIGMA importer to read.

    openpyxl writes text cells as inlineStr. Excel/LibreOffice often rewrites the
    same workbook using xl/sharedStrings.xml. Real SIGMA tests showed that the
    importer may reject the inlineStr workbook and accept the sharedStrings one,
    even when the visible table contents are identical.

    This function converts inline strings in worksheet XML to shared strings
    without changing visible cell values.
    """
    path = Path(path)
    if not path or not path.exists() or path.suffix.lower() != ".xlsx":
        return False

    main_ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    rel_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    ct_ns = "http://schemas.openxmlformats.org/package/2006/content-types"
    rel_type_shared = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings"
    ct_shared = "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"

    ET.register_namespace("", main_ns)
    ET.register_namespace("", rel_ns)
    ET.register_namespace("", ct_ns)

    def q(ns, tag):
        return f"{{{ns}}}{tag}"

    tmp_path = path.with_suffix(path.suffix + ".tmp")

    with zipfile.ZipFile(path, "r") as zin:
        names = zin.namelist()
        old_shared = []
        if "xl/sharedStrings.xml" in names:
            try:
                sst_root = ET.fromstring(zin.read("xl/sharedStrings.xml"))
                for si in sst_root.findall(q(main_ns, "si")):
                    old_shared.append(_xml_text_from_si(si))
            except Exception:
                old_shared = []

        shared_values = []
        shared_index = {}

        def add_shared(value):
            value = "" if value is None else str(value)
            if value in shared_index:
                return shared_index[value]
            idx = len(shared_values)
            shared_values.append(value)
            shared_index[value] = idx
            return idx

        converted_files = {}
        total_string_refs = 0

        sheet_names = [n for n in names if n.startswith("xl/worksheets/") and n.endswith(".xml")]
        for sheet_name in sheet_names:
            raw = zin.read(sheet_name)
            root = ET.fromstring(raw)
            changed = False

            for c in root.iter(q(main_ns, "c")):
                cell_type = c.attrib.get("t")
                if cell_type == "inlineStr":
                    is_node = c.find(q(main_ns, "is"))
                    value = _xml_text_from_si(is_node)
                    idx = add_shared(value)

                    for child in list(c):
                        if child.tag in (q(main_ns, "is"), q(main_ns, "v")):
                            c.remove(child)
                    c.attrib["t"] = "s"
                    v = ET.Element(q(main_ns, "v"))
                    v.text = str(idx)
                    c.append(v)
                    total_string_refs += 1
                    changed = True

                elif cell_type == "s":
                    v = c.find(q(main_ns, "v"))
                    if v is not None and v.text is not None:
                        try:
                            old_idx = int(v.text)
                            value = old_shared[old_idx] if 0 <= old_idx < len(old_shared) else ""
                            v.text = str(add_shared(value))
                            total_string_refs += 1
                            changed = True
                        except Exception:
                            pass

            if changed:
                converted_files[sheet_name] = ET.tostring(root, encoding="utf-8", xml_declaration=True)

        if not converted_files and "xl/sharedStrings.xml" in names:
            return True

        # Build sharedStrings.xml.
        sst = ET.Element(q(main_ns, "sst"), {
            "count": str(total_string_refs),
            "uniqueCount": str(len(shared_values)),
        })
        for value in shared_values:
            si = ET.SubElement(sst, q(main_ns, "si"))
            t = ET.SubElement(si, q(main_ns, "t"))
            # Preserve leading/trailing whitespace if ever present.
            if value != value.strip():
                t.attrib["{http://www.w3.org/XML/1998/namespace}space"] = "preserve"
            t.text = value
        shared_xml = ET.tostring(sst, encoding="utf-8", xml_declaration=True)

        # Patch [Content_Types].xml.
        content_types = zin.read("[Content_Types].xml")
        ct_root = ET.fromstring(content_types)
        has_shared_override = False
        for override in ct_root.findall(q(ct_ns, "Override")):
            if override.attrib.get("PartName") == "/xl/sharedStrings.xml":
                override.attrib["ContentType"] = ct_shared
                has_shared_override = True
                break
        if not has_shared_override:
            ET.SubElement(ct_root, q(ct_ns, "Override"), {
                "PartName": "/xl/sharedStrings.xml",
                "ContentType": ct_shared,
            })
        content_types_xml = ET.tostring(ct_root, encoding="utf-8", xml_declaration=True)

        # Patch workbook relationships.
        rels_name = "xl/_rels/workbook.xml.rels"
        rels_root = ET.fromstring(zin.read(rels_name))
        has_shared_rel = False
        used_ids = []
        for rel in rels_root.findall(q(rel_ns, "Relationship")):
            rid = rel.attrib.get("Id", "")
            m = re.match(r"rId(\d+)$", rid)
            if m:
                used_ids.append(int(m.group(1)))
            if rel.attrib.get("Type") == rel_type_shared:
                rel.attrib["Target"] = "sharedStrings.xml"
                has_shared_rel = True
        if not has_shared_rel:
            next_id = max(used_ids or [0]) + 1
            ET.SubElement(rels_root, q(rel_ns, "Relationship"), {
                "Id": f"rId{next_id}",
                "Type": rel_type_shared,
                "Target": "sharedStrings.xml",
            })
        rels_xml = ET.tostring(rels_root, encoding="utf-8", xml_declaration=True)

        with zipfile.ZipFile(tmp_path, "w", compression=zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                name = item.filename
                if name == "xl/sharedStrings.xml":
                    continue
                if name == "[Content_Types].xml":
                    zout.writestr(name, content_types_xml)
                elif name == rels_name:
                    zout.writestr(name, rels_xml)
                elif name in converted_files:
                    zout.writestr(name, converted_files[name])
                else:
                    zout.writestr(item, zin.read(name))
            zout.writestr("xl/sharedStrings.xml", shared_xml)

    tmp_path.replace(path)
    return True


def normalize_import_barcode_cell(codes):
    cleaned = []
    for code in codes or []:
        s = safe_str(code).strip().strip(",")
        if s:
            cleaned.append(s)
    # Важно для SIGMA: через запятую, без запятой после последнего ШК.
    return ", ".join(cleaned).rstrip(" ,")


def copy_cell_style(src, dst):
    if src.has_style:
        dst._style = copy(src._style)
    if src.number_format:
        dst.number_format = src.number_format
    if src.alignment:
        dst.alignment = copy(src.alignment)
    if src.protection:
        dst.protection = copy(src.protection)


def copy_row_template(ws, src_row, dst_row, max_col=8):
    ws.row_dimensions[dst_row].height = ws.row_dimensions[src_row].height
    for c in range(1, max_col + 1):
        src = ws.cell(src_row, c)
        dst = ws.cell(dst_row, c)
        copy_cell_style(src, dst)
        dst.value = None


def prepare_sigma_import_workbook(row_count):
    """
    SIGMA import is very picky. We always start from the exact known-working file:
    app/templates/Импорт SIGMA.xlsx

    The generated workbook must keep:
    - sheet name: Лист1
    - columns A:I in exact order
    - header text exactly as SIGMA expects
    - barcode column as text
    - comma-separated barcodes with no trailing comma
    - Category column filled from SAI when present
    """
    if SIGMA_IMPORT_TEMPLATE_PATH.exists():
        wb = load_workbook(SIGMA_IMPORT_TEMPLATE_PATH)
        ws = wb.active
    else:
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active

    # SIGMA is sensitive to sheet/header layout. Keep only one sheet and name it like the working template.
    for extra in list(wb.worksheets)[1:]:
        wb.remove(extra)
    ws.title = "Лист1"

    for c, h in enumerate(SIGMA_IMPORT_HEADERS, start=1):
        ws.cell(1, c).value = h

    # SIGMA's current import contract has exactly A:I.  Column I is mandatory
    # even for ordinary goods and must explicitly say whether the item is 18+.
    expected_cols = len(SIGMA_IMPORT_HEADERS)
    if ws.max_column > expected_cols:
        ws.delete_cols(expected_cols + 1, ws.max_column - expected_cols)

    # Keep exactly header + product rows.  Old versions kept the template at
    # A1:H16, but that creates phantom empty rows for small imports after the
    # category/VAT/type normalizer runs.
    total_rows = max(1, int(row_count or 0)) + 1

    if ws.max_row < total_rows:
        # Copy the known data-row formatting. The template has row 2 styled correctly.
        src_row = 2 if ws.max_row >= 2 else 1
        for r in range(ws.max_row + 1, total_rows + 1):
            copy_row_template(ws, src_row, r, max_col=9)

    if ws.max_row > total_rows:
        ws.delete_rows(total_rows + 1, ws.max_row - total_rows)

    # Clear data below header but preserve the exact styles/formats from the template.
    for r in range(2, total_rows + 1):
        for c in range(1, 10):
            ws.cell(r, c).value = None

    # Exact working-template widths.
    widths = [45, 16, 18, 22, 32, 14, 12, 18, 14]
    for c, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c)].width = w

    # Make sure barcode column stays text, including multi-barcode cells.
    # Price column: plain numeric value, neutral Excel format.
    for r in range(2, total_rows + 1):
        ws.cell(r, 4).number_format = "@"
        ws.cell(r, 7).number_format = SIGMA_IMPORT_PRICE_NUMBER_FORMAT

    # Working template has frozen header.
    ws.freeze_panes = "A2"

    return wb, ws, total_rows


def fill_sigma_import_rows(ws, rows):
    for idx, row in enumerate(rows, start=2):
        barcode_cell = normalize_import_barcode_cell(row.get("barcodes") or [])
        ws.cell(idx, 1).value = row.get("name") or ""
        ws.cell(idx, 2).value = row.get("article") or ""
        ws.cell(idx, 3).value = normalize_unit(row.get("unit") or "штука")
        ws.cell(idx, 4).value = barcode_cell
        # v1.16.1: keep the category from the SAI file.
        # Earlier versions intentionally left this empty so a human could choose it in SIGMA,
        # but that broke the real workflow: SAI already has the category column.
        ws.cell(idx, 5).value = row.get("category") or ""
        ws.cell(idx, 6).value = row.get("vat") or "Без НДС"
        ws.cell(idx, 7).value = row.get("sale")
        ws.cell(idx, 7).number_format = SIGMA_IMPORT_PRICE_NUMBER_FORMAT
        ws.cell(idx, 8).value = row.get("type") or "Обычный товар"
        # The shop does not trade age-restricted goods.  SIGMA requires this
        # column to be present and accepts the explicit Да/Нет value.
        ws.cell(idx, 9).value = "Нет"
        ws.cell(idx, 4).number_format = "@"




def duplicate_article_warnings(rows, limit=5):
    by_article = {}
    for row in rows or []:
        art = safe_str(row.get("article")).strip()
        if not art:
            continue
        by_article.setdefault(art, []).append(row)

    warnings = []
    for art, group in sorted(by_article.items(), key=lambda kv: len(kv[1]), reverse=True):
        if len(group) <= 1:
            continue
        names = []
        for r in group:
            name = safe_str(r.get("name"))
            if name and name not in names:
                names.append(name)
            if len(names) >= 3:
                break
        warnings.append({
            "article": art,
            "count": len(group),
            "examples": names,
        })
        if len(warnings) >= limit:
            break
    return warnings

def create_import_file(sai_path, catalog_path, supplier, invoice_date, out_dir=None):
    sheet_name, rows = load_sai_rows(sai_path)
    catalog_codes, cat_debug = find_catalog_barcodes(catalog_path)

    missing = []
    no_barcode = []
    ok = []

    for row in rows:
        codes = row["barcodes"]
        if not codes:
            no_barcode.append(row)
            continue

        if any(code in catalog_codes for code in codes):
            ok.append(row)
        else:
            missing.append(row)

    supplier_part = sanitize_filename_part(supplier)
    date_part = date_code_from_text(invoice_date)
    out_dir = Path(out_dir) if out_dir else Path(sai_path).resolve().parent
    out_path = out_dir / f"Импорт_{supplier_part}_{date_part}.xlsx"

    if missing:
        wb, ws, _ = prepare_sigma_import_workbook(len(missing))
        fill_sigma_import_rows(ws, missing)
        wb.save(out_path)
        make_xlsx_sigma_compatible(out_path)
    else:
        out_path = None

    return {
        "sheet_name": sheet_name,
        "total": len(rows),
        "ok": len(ok),
        "missing": len(missing),
        "no_barcode": len(no_barcode),
        "import_path": str(out_path) if out_path else "",
        "missing_rows": missing,
        "no_barcode_rows": no_barcode,
        "catalog_debug": cat_debug,
        "catalog_count": len(catalog_codes),
    }


def write_import_file_for_missing(missing, sai_path, supplier, invoice_date, out_dir=None):
    supplier_part = sanitize_filename_part(supplier)
    date_part = date_code_from_text(invoice_date)
    out_dir = Path(out_dir) if out_dir else Path(sai_path).resolve().parent
    out_path = out_dir / f"Импорт_{supplier_part}_{date_part}.xlsx"

    if not missing:
        return None

    wb, ws, _ = prepare_sigma_import_workbook(len(missing))
    fill_sigma_import_rows(ws, missing)
    wb.save(out_path)
    make_xlsx_sigma_compatible(out_path)
    return out_path


def extract_data_list(payload):
    if isinstance(payload, list):
        return payload
    if not isinstance(payload, dict):
        return []

    data = payload.get("data")
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in ("items", "content", "rows", "data", "records", "values"):
            val = data.get(key)
            if isinstance(val, list):
                return val

    for key in ("items", "content", "rows", "records", "values"):
        val = payload.get(key)
        if isinstance(val, list):
            return val

    return []


def extract_paging(payload):
    if not isinstance(payload, dict):
        return {}
    paging = payload.get("paging") or payload.get("page") or payload.get("pagination") or {}
    return paging if isinstance(paging, dict) else {}


def extract_product_barcodes(product):
    """
    v1.9 strict extraction:
    Official SIGMA /products returns barcodes under product.items[].barcodes.
    Do NOT scan the entire JSON anymore: UUID/id digits are not barcodes.
    """
    codes = set()

    def add_code(value):
        if value is None:
            return
        if isinstance(value, (int, float)):
            value = str(int(value)) if isinstance(value, float) and value.is_integer() else str(value)
        if isinstance(value, str):
            for code in BARCODE_RE.findall(value):
                codes.add(code)
        elif isinstance(value, dict):
            for key in ("barcode", "barCode", "value", "code", "ean", "gtin"):
                if key in value:
                    add_code(value.get(key))
        elif isinstance(value, list):
            for item in value:
                add_code(item)

    if not isinstance(product, dict):
        return codes

    items = product.get("items")
    if isinstance(items, list):
        for item in items:
            if isinstance(item, dict):
                add_code(item.get("barcodes"))
                add_code(item.get("barcode"))
                add_code(item.get("barCode"))
                add_code(item.get("ean"))
                add_code(item.get("gtin"))

    add_code(product.get("barcodes"))
    add_code(product.get("barcode"))
    add_code(product.get("barCode"))
    add_code(product.get("ean"))
    add_code(product.get("gtin"))

    return codes


def collect_ids_from_json(obj):
    ids = []
    names = []

    def walk(x):
        if isinstance(x, dict):
            found_id = None
            for key in ("id", "uuid", "sellPointId", "shopId", "pointId"):
                val = x.get(key)
                if isinstance(val, str) and val:
                    found_id = val
                    break
            if found_id:
                ids.append(found_id)
                names.append((found_id, str(x.get("name") or x.get("title") or x.get("displayName") or "")))
            for v in x.values():
                walk(v)
        elif isinstance(x, list):
            for item in x:
                walk(item)

    walk(obj)
    unique = []
    seen = set()
    for item in ids:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique, names


def sigma_api_headers(api_token):
    # Connection: close уменьшает шанс SSL EOF на api.sigma.ru при повторном использовании keep-alive соединений.
    return {
        "Accept": "application/json",
        "X-Api-Key": api_token,
        "User-Agent": f"SAI-GUI/{APP_VERSION.lstrip('v')}",
        "Connection": "close",
    }


def sigma_api_request(company_key, api_token, method, endpoint, params=None, json_body=None, timeout=25, retries=3):
    url = f"https://api.sigma.ru/v1/companies/{company_key}/{endpoint}"
    last_error = None
    for attempt in range(1, max(1, int(retries or 1)) + 1):
        try:
            return requests.request(
                method.upper(),
                url,
                headers=sigma_api_headers(api_token),
                params=params or {},
                json=json_body,
                timeout=timeout,
            )
        except (requests.exceptions.SSLError, requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            last_error = e
            if attempt >= max(1, int(retries or 1)):
                raise
            time.sleep(min(5.0, 0.8 * attempt))
    if last_error:
        raise last_error
    raise RuntimeError(f"SIGMA API: request failed without response: {method} {endpoint}")


def sigma_api_get(company_key, api_token, endpoint, params=None, timeout=25):
    from sai_read_queue import read_slot, REFERENCE
    with read_slot(REFERENCE):
        return sigma_api_request(company_key, api_token, "GET", endpoint, params=params, timeout=timeout)


def get_sigma_sell_point_id(company_key, api_token, cfg, log_callback=None):
    saved = safe_str(cfg.get("sigma_sell_point_id"))
    if saved:
        if log_callback:
            log_callback(f"SIGMA API: использую sellPointId из private config: {saved}")
        return saved

    resp = sigma_api_get(company_key, api_token, "sell-points")
    resp.raise_for_status()
    payload = resp.json()
    ids, named = collect_ids_from_json(payload)
    if not ids:
        raise RuntimeError("SIGMA API: sell-points ответил, но id торговой точки не найден.")

    sell_point_id = ids[0]
    update_private_config({"sigma_sell_point_id": sell_point_id})
    if log_callback:
        name = next((nm for sid, nm in named if sid == sell_point_id and nm), "")
        if name:
            log_callback(f"SIGMA API: найден и сохранён sellPointId: {name} — {sell_point_id}")
        else:
            log_callback(f"SIGMA API: найден и сохранён sellPointId: {sell_point_id}")
    return sell_point_id



def summarize_sigma_product(product):
    if not isinstance(product, dict):
        return {
            "id": "",
            "name": "",
            "vendor_code": "",
            "barcodes": [],
            "raw": None,
        }

    pid = safe_str(
        product.get("id")
        or product.get("uuid")
        or product.get("productId")
        or product.get("extProductId")
    )
    name = safe_str(
        product.get("name")
        or product.get("title")
        or product.get("productName")
        or product.get("displayName")
    )
    vendor_code = safe_str(product.get("vendorCode") or product.get("article") or product.get("code"))
    codes = sorted(extract_product_barcodes(product))

    if not pid:
        # Fallback only for internal comparison. Official products usually have id.
        pid = "NO_ID:" + (name or vendor_code or (codes[0] if codes else "UNKNOWN"))

    return {
        "id": pid,
        "name": name,
        "vendor_code": vendor_code,
        "barcodes": codes,
        "raw": product,
    }


def fetch_sigma_api_catalog(company_key, api_token, sell_point_id, log_callback=None):
    """
    v1.11.4:
    Builds a real barcode index:
    - barcode -> existing SIGMA product;
    - product id -> product summary with all known barcodes.

    This allows SAI to detect partial matches:
    one barcode exists, another barcode from the same supplier row is missing.
    """
    def log(msg):
        if log_callback:
            log_callback(msg)

    page_limit = 2000
    max_pages = 80
    base_params = {"sellPointId": sell_point_id, "limit": page_limit}

    cursor_param_candidates = [
        "latestId",
        "lastId",
        "afterId",
        "cursor",
        "fromId",
        "lastProductId",
        "after",
        "startingAfter",
    ]
    # Remember the last confirmed strategy, but still validate the next page.
    try:
        from contextlib import closing
        with closing(sai_db.connect()) as connection:
            previous = connection.execute(
                "SELECT strategy FROM catalog_sync WHERE company_key=? AND sell_point_id=?",
                (company_key, sell_point_id),
            ).fetchone()
        remembered = safe_str(previous[0] if previous else "").removeprefix("cursor_")
        if remembered in cursor_param_candidates:
            cursor_param_candidates.remove(remembered)
            cursor_param_candidates.insert(0, remembered)
    except Exception:
        pass

    def get_products(params):
        return sigma_api_get(company_key, api_token, "products", params=params, timeout=45)

    def records_signature(records):
        parts = []
        for rec in records[:10]:
            if isinstance(rec, dict):
                parts.append(safe_str(rec.get("id") or rec.get("uuid") or rec.get("extProductId") or rec.get("name")))
            else:
                parts.append(safe_str(rec)[:80])
        return "|".join(parts)

    def get_latest_id(payload):
        paging = extract_paging(payload)
        latest = (
            paging.get("latestId")
            or paging.get("lastId")
            or paging.get("cursor")
            or paging.get("nextCursor")
            or paging.get("next")
        )
        return safe_str(latest)

    def save_sample(payload, strategy_name, page_no, first_with_barcodes=None):
        try:
            records = extract_data_list(payload)
            sample = {
                "strategy": strategy_name,
                "page": page_no,
                "record_count_on_page": len(records),
                "paging": extract_paging(payload),
                "first_record_keys": list(records[0].keys()) if records and isinstance(records[0], dict) else [],
                "first_records": records[:3],
                "first_record_with_barcodes": first_with_barcodes,
            }
            out = LOGS_DIR / "api_products_sample.json"
            out.write_text(json.dumps(sample, ensure_ascii=False, indent=2), encoding="utf-8")
            log(f"SIGMA API products: образец ответа сохранён в {out}")
            if sample["first_record_keys"]:
                log(f"SIGMA API products: ключи первого товара: {', '.join(sample['first_record_keys'][:30])}")
        except Exception as e:
            log(f"SIGMA API products: не смог сохранить образец ответа — {str(e)[:180]}")

    code_to_products = {}
    products_by_id = {}

    def add_product_to_index(rec):
        summary = summarize_sigma_product(rec)
        pid = summary["id"]
        old = products_by_id.get(pid)
        if old:
            merged = sorted(set(old.get("barcodes", [])) | set(summary.get("barcodes", [])))
            old["barcodes"] = merged
            if not old.get("name") and summary.get("name"):
                old["name"] = summary["name"]
            if not old.get("raw") and summary.get("raw"):
                old["raw"] = summary["raw"]
            summary = old
        else:
            products_by_id[pid] = summary

        for code in summary.get("barcodes", []):
            code_to_products.setdefault(code, {})[pid] = summary

        return summary

    def process_page(payload, page_label, all_codes, seen_product_ids):
        records = extract_data_list(payload)
        page_codes_before = len(all_codes)
        first_with_barcodes = None
        skipped_repeated = 0
        new_products = 0

        for rec in records:
            rec_id = ""
            if isinstance(rec, dict):
                rec_id = safe_str(rec.get("id") or rec.get("uuid") or rec.get("productId") or rec.get("extProductId"))
            if rec_id and rec_id in seen_product_ids:
                skipped_repeated += 1
                continue
            if rec_id:
                seen_product_ids.add(rec_id)
            new_products += 1

            rec_codes = extract_product_barcodes(rec)
            if rec_codes and first_with_barcodes is None:
                first_with_barcodes = rec
            all_codes.update(rec_codes)
            # v1.17.1: index every product, including products without barcodes.
            # SIGMA import may reject a new row by product name even when SAI
            # did not find the barcode. The name duplicate guard needs these
            # no-barcode products in products_by_id.
            add_product_to_index(rec)

        new_codes = len(all_codes) - page_codes_before
        log(
            f"SIGMA API products: страница {page_label}, товаров={len(records)}, "
            f"новых товаров={new_products}, повторов={skipped_repeated}, "
            f"новых ШК={new_codes}, всего ШК={len(all_codes)}"
        )
        return records, new_codes, first_with_barcodes

    log(f"SIGMA API products: старт, strict barcodes from items[].barcodes, params={base_params}")

    resp = get_products(base_params)
    if not (200 <= resp.status_code < 300):
        raise RuntimeError(f"/products HTTP {resp.status_code}: {resp.text[:500]}")

    payload = resp.json()
    records = extract_data_list(payload)
    if not records:
        raise RuntimeError("/products вернул пустой список товаров.")

    all_codes = set()
    seen_product_ids = set()
    _, _, first_with_barcodes = process_page(payload, 0, all_codes, seen_product_ids)
    first_signature = records_signature(records)
    latest_id = get_latest_id(payload)

    save_sample(payload, "cursor_probe", 0, first_with_barcodes=first_with_barcodes)

    strategy = "single_page_no_cursor"

    if not latest_id:
        if len(records) < page_limit:
            log("SIGMA API products: latestId отсутствует, но страница меньше лимита — считаю выгрузку полной.")
        else:
            raise RuntimeError("SIGMA API /products не дал paging.latestId, а страница полная. Нельзя безопасно получить весь каталог.")
    else:
        log(f"SIGMA API products: paging.latestId первой страницы = {latest_id}")

        chosen_cursor_param = None
        chosen_payload = None

        for param_name in cursor_param_candidates:
            probe_params = dict(base_params)
            probe_params[param_name] = latest_id

            try:
                probe = get_products(probe_params)
                if not (200 <= probe.status_code < 300):
                    log(f"SIGMA API products: cursor probe {param_name}=... HTTP {probe.status_code}")
                    continue

                probe_payload = probe.json()
                probe_records = extract_data_list(probe_payload)
                probe_sig = records_signature(probe_records)

                if probe_records and probe_sig and probe_sig != first_signature:
                    chosen_cursor_param = param_name
                    chosen_payload = probe_payload
                    log(f"SIGMA API products: рабочая cursor-пагинация: {param_name}=paging.latestId")
                    break
                else:
                    log(f"SIGMA API products: cursor probe {param_name}=... вернул ту же страницу или пусто")
            except Exception as e:
                log(f"SIGMA API products: cursor probe {param_name}=... ошибка — {str(e)[:160]}")

        if not chosen_cursor_param:
            if len(records) < page_limit:
                log("SIGMA API products: cursor не найден, но первая страница меньше лимита — считаю выгрузку полной.")
                strategy = "single_page_cursor_not_needed"
            else:
                raise RuntimeError(
                    "SIGMA API /products дал paging.latestId, но SAI не подобрал имя cursor-параметра "
                    "(latestId/lastId/afterId/cursor...). Проверка API остановлена, чтобы не выдать ложные отсутствующие товары. "
                    "Пришли app\\api_products_sample.json и лог cursor probe."
                )
        else:
            strategy = f"cursor_{chosen_cursor_param}"
            current_payload = chosen_payload
            page_no = 1
            process_page(current_payload, page_no, all_codes, seen_product_ids)
            current_latest_id = get_latest_id(current_payload)

            while page_no < max_pages:
                if not current_latest_id:
                    log("SIGMA API products: latestId закончился — выгрузка завершена.")
                    break

                params = dict(base_params)
                params[chosen_cursor_param] = current_latest_id

                resp = get_products(params)
                if not (200 <= resp.status_code < 300):
                    raise RuntimeError(f"Каталог SIGMA загружен не полностью: страница {page_no + 1}, HTTP {resp.status_code}. Сохранённый каталог не заменён.")

                payload = resp.json()
                records = extract_data_list(payload)
                if not records:
                    log(f"SIGMA API products: страница {page_no+1} пустая — выгрузка завершена.")
                    break

                new_latest_id = get_latest_id(payload)
                before_products = len(seen_product_ids)
                page_no += 1
                process_page(payload, page_no, all_codes, seen_product_ids)

                if len(seen_product_ids) == before_products:
                    raise RuntimeError("SIGMA повторила страницу каталога. Полнота выгрузки не подтверждена; сохранённый каталог не заменён.")

                if new_latest_id == current_latest_id:
                    raise RuntimeError("SIGMA не продвинула курсор каталога. Полнота выгрузки не подтверждена; сохранённый каталог не заменён.")

                current_latest_id = new_latest_id

            if page_no >= max_pages:
                raise RuntimeError(f"SIGMA API products: достигнут лимит {max_pages} страниц. Остановлено для безопасности.")

    log(
        f"SIGMA API products: выгрузка завершена. "
        f"strategy={strategy}, товаров={len(seen_product_ids)}, реальных ШК={len(all_codes)}"
    )

    if not all_codes:
        raise RuntimeError(
            "SIGMA API /products прочитан, но реальные ШК из items[].barcodes не найдены. "
            "Вероятно, официальный API не отдаёт ШК в этом методе или нужна другая детализация товара."
        )

    return {
        "codes": all_codes,
        "product_count": len(seen_product_ids),
        "strategy": strategy,
        "code_to_products": code_to_products,
        "products_by_id": products_by_id,
    }



def catalog_to_cache_payload(catalog, company_key, sell_point_id):
    return {
        "version": 1,
        "created_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "company_key": safe_str(company_key),
        "sell_point_id": safe_str(sell_point_id),
        "strategy": safe_str(catalog.get("strategy")),
        "product_count": int(catalog.get("product_count") or 0),
        "codes": sorted(catalog.get("codes") or []),
        "code_to_products": catalog.get("code_to_products") or {},
        "products_by_id": catalog.get("products_by_id") or {},
    }


def catalog_from_cache_payload(payload):
    codes = set(str(x) for x in (payload.get("codes") or []) if str(x))
    return {
        "codes": codes,
        "product_count": int(payload.get("product_count") or len(payload.get("products_by_id") or {})),
        "strategy": "cache_" + safe_str(payload.get("strategy") or "unknown"),
        "code_to_products": payload.get("code_to_products") or {},
        "products_by_id": payload.get("products_by_id") or {},
        "cache_created_at": safe_str(payload.get("created_at")),
    }


def load_sigma_catalog_cache(company_key, sell_point_id, log_callback=None):
    # v1.17: SQLite is the preferred local catalog cache. JSON stays as fallback
    # so a damaged sai.db never blocks a working receiving flow.
    try:
        cfg = load_private_config()
        if bool(cfg.get("sqlite_cache_enabled", True)):
            catalog = sai_db.load_catalog(company_key, sell_point_id)
            if catalog and catalog.get("codes"):
                if log_callback:
                    log_callback(
                        f"SIGMA каталог: использую SQLite-кэш от {catalog.get('cache_created_at') or 'неизвестно'}, "
                        f"товаров={catalog['product_count']}, ШК={len(catalog['codes'])}"
                    )
                return catalog
    except Exception as e:
        if log_callback:
            log_callback(f"SIGMA каталог: SQLite-кэш не читается, пробую старый JSON-кэш — {str(e)[:160]}")

    if not SIGMA_PRODUCTS_CACHE_PATH.exists():
        return None
    try:
        payload = json.loads(SIGMA_PRODUCTS_CACHE_PATH.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return None
        if safe_str(payload.get("company_key")) != safe_str(company_key):
            return None
        if safe_str(payload.get("sell_point_id")) != safe_str(sell_point_id):
            return None
        catalog = catalog_from_cache_payload(payload)
        if not catalog["codes"]:
            return None
        if log_callback:
            log_callback(
                f"SIGMA каталог: использую JSON-кэш от {catalog.get('cache_created_at') or 'неизвестно'}, "
                f"товаров={catalog['product_count']}, ШК={len(catalog['codes'])}"
            )
        # Opportunistic migration JSON -> SQLite.
        try:
            cfg = load_private_config()
            if bool(cfg.get("sqlite_cache_enabled", True)):
                sai_db.save_catalog(catalog, company_key, sell_point_id, app_version=APP_VERSION)
                if log_callback:
                    log_callback(f"SIGMA каталог: JSON-кэш перенесён в SQLite: {DB_PATH}")
        except Exception as e:
            if log_callback:
                log_callback(f"SIGMA каталог: не смог перенести JSON-кэш в SQLite — {str(e)[:160]}")
        return catalog
    except Exception as e:
        if log_callback:
            log_callback(f"SIGMA каталог: кэш повреждён или не читается, обновляю заново — {str(e)[:160]}")
        return None


def parse_cache_created_at(value):
    s = safe_str(value)
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f"):
        try:
            return dt.datetime.strptime(s.replace("Z", ""), fmt)
        except Exception:
            pass
    try:
        return dt.datetime.fromisoformat(s.replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return None


def sigma_catalog_cache_age_seconds(company_key, sell_point_id):
    try:
        cfg = load_private_config()
        if bool(cfg.get("sqlite_cache_enabled", True)):
            age = sai_db.catalog_age_seconds(company_key, sell_point_id)
            if age is not None:
                return age
    except Exception:
        pass

    if not SIGMA_PRODUCTS_CACHE_PATH.exists():
        return None
    try:
        payload = json.loads(SIGMA_PRODUCTS_CACHE_PATH.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return None
        if safe_str(payload.get("company_key")) != safe_str(company_key):
            return None
        if safe_str(payload.get("sell_point_id")) != safe_str(sell_point_id):
            return None
        created = parse_cache_created_at(payload.get("created_at"))
        if not created:
            return None
        return max(0.0, (dt.datetime.now() - created).total_seconds())
    except Exception:
        return None


def save_sigma_catalog_cache(catalog, company_key, sell_point_id, log_callback=None):
    sqlite_saved = False
    try:
        cfg = load_private_config()
        if bool(cfg.get("sqlite_cache_enabled", True)):
            counters = sai_db.save_catalog(catalog, company_key, sell_point_id, app_version=APP_VERSION)
            sqlite_saved = True
            if log_callback:
                log_callback(
                    f"SIGMA каталог: SQLite-кэш сохранён, товаров={counters.get('product_count')}, "
                    f"ШК={counters.get('barcode_count')} — {DB_PATH}"
                )
    except Exception as e:
        if log_callback:
            log_callback(f"SIGMA каталог: не смог сохранить SQLite-кэш, сохраняю JSON — {str(e)[:180]}")

    try:
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        if sqlite_saved and SIGMA_PRODUCTS_CACHE_PATH.exists() and time.time() - SIGMA_PRODUCTS_CACHE_PATH.stat().st_mtime < 24 * 3600:
            if log_callback:
                log_callback("SQLite-каталог обновлён; суточная резервная JSON-копия уже существует.")
            return
        payload = catalog_to_cache_payload(catalog, company_key, sell_point_id)
        tmp = SIGMA_PRODUCTS_CACHE_PATH.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(SIGMA_PRODUCTS_CACHE_PATH)
        if log_callback:
            prefix = "резервный JSON-кэш" if sqlite_saved else "JSON-кэш"
            log_callback(
                f"SIGMA каталог: {prefix} сохранён, товаров={payload['product_count']}, ШК={len(payload['codes'])}"
            )
    except Exception as e:
        if log_callback:
            log_callback(f"SIGMA каталог: не смог сохранить кэш — {str(e)[:180]}")


def get_sigma_api_catalog_cached(company_key, api_token, sell_point_id, log_callback=None, force_refresh=False):
    if not force_refresh:
        cached = load_sigma_catalog_cache(company_key, sell_point_id, log_callback=log_callback)
        if cached:
            return cached

    if log_callback:
        if force_refresh:
            log_callback("SIGMA каталог: принудительно обновляю локальный кэш...")
        else:
            log_callback("SIGMA каталог: локального кэша нет, скачиваю каталог SIGMA...")

    catalog = fetch_sigma_api_catalog(company_key, api_token, sell_point_id, log_callback=log_callback)
    save_sigma_catalog_cache(catalog, company_key, sell_point_id, log_callback=log_callback)
    return catalog


def fetch_sigma_api_barcodes(company_key, api_token, sell_point_id, log_callback=None):
    catalog = fetch_sigma_api_catalog(company_key, api_token, sell_point_id, log_callback=log_callback)
    return catalog["codes"], catalog["product_count"], catalog["strategy"]



def unwrap_sigma_data(payload):
    if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
        return payload.get("data")
    return payload


def deep_json_copy(value):
    return json.loads(json.dumps(value, ensure_ascii=False))


def product_payload_with_added_barcodes(raw_product, matched_codes, missing_codes, sell_point_id):
    """
    Make a conservative full-product payload:
    - copy the product JSON SIGMA returned;
    - add missing barcodes only to the item that already has the matched barcode;
    - if item cannot be detected, add to the first item;
    - never remove existing barcodes.
    """
    if not isinstance(raw_product, dict):
        return None

    payload = deep_json_copy(raw_product)
    matched = set(str(c) for c in matched_codes or [])
    missing = [str(c) for c in missing_codes or [] if str(c)]
    if not missing:
        return payload

    if sell_point_id and not payload.get("sellPointId"):
        payload["sellPointId"] = sell_point_id

    def merge_into_container(container):
        existing = []
        if isinstance(container, dict):
            current = container.get("barcodes")
            if isinstance(current, list):
                existing = [safe_str(x) for x in current if safe_str(x)]
            elif current:
                existing = [safe_str(current)]
            merged = list(dict.fromkeys(existing + missing))
            container["barcodes"] = merged
            return True
        return False

    items = payload.get("items")
    target_item = None
    if isinstance(items, list):
        for item in items:
            if not isinstance(item, dict):
                continue
            item_codes = extract_product_barcodes({"items": [item]})
            if item_codes & matched:
                target_item = item
                break
        if target_item is None:
            target_item = next((item for item in items if isinstance(item, dict)), None)

    if target_item is not None:
        merge_into_container(target_item)
    elif isinstance(payload.get("barcodes"), list) or payload.get("barcodes"):
        merge_into_container(payload)
    else:
        payload["barcodes"] = list(dict.fromkeys(missing))

    return payload


def fetch_sigma_product_detail(company_key, api_token, sell_point_id, product_id, fallback_raw=None, log_callback=None):
    """
    Try to read a single product before updating. If SIGMA does not support detail GET,
    use the product object from the catalog page.
    """
    candidates = [
        (f"products/{product_id}", {"sellPointId": sell_point_id}),
        (f"products/{product_id}", {}),
    ]

    for endpoint, params in candidates:
        try:
            resp = sigma_api_get(company_key, api_token, endpoint, params=params, timeout=25)
            if 200 <= resp.status_code < 300:
                data = unwrap_sigma_data(resp.json())
                if isinstance(data, dict):
                    if log_callback:
                        log_callback(f"Авто-ШК: detail GET OK {endpoint}")
                    return data
            else:
                if log_callback:
                    log_callback(f"Авто-ШК: detail GET {endpoint} HTTP {resp.status_code}")
        except Exception as e:
            if log_callback:
                log_callback(f"Авто-ШК: detail GET {endpoint} ошибка — {str(e)[:160]}")

    return fallback_raw if isinstance(fallback_raw, dict) else None


def try_update_sigma_product_barcodes(company_key, api_token, sell_point_id, product, matched_codes, missing_codes, log_callback=None):
    """
    Experimental official API update.

    Safety:
    - Only exact product update endpoints are tried first.
    - No product creation endpoint is called.
    - Existing barcodes are never removed from the outgoing payload.
    - If SIGMA rejects all variants, returns failure and SAI falls back to the manual XLSX task.
    """
    def log(msg):
        if log_callback:
            log_callback(msg)

    product_id = safe_str(product.get("id"))
    if not product_id or product_id.startswith("NO_ID:"):
        return {
            "ok": False,
            "product_id": product_id,
            "message": "нет надёжного ID товара SIGMA",
            "attempts": [],
        }

    raw = fetch_sigma_product_detail(
        company_key,
        api_token,
        sell_point_id,
        product_id,
        fallback_raw=product.get("raw"),
        log_callback=log,
    )

    if not isinstance(raw, dict):
        return {
            "ok": False,
            "product_id": product_id,
            "message": "не удалось получить JSON товара для обновления",
            "attempts": [],
        }

    payload = product_payload_with_added_barcodes(raw, matched_codes, missing_codes, sell_point_id)
    if not isinstance(payload, dict):
        return {
            "ok": False,
            "product_id": product_id,
            "message": "не удалось собрать payload товара",
            "attempts": [],
        }

    attempts = []
    candidates = [
        ("PUT", f"products/{product_id}", {"sellPointId": sell_point_id}),
        ("PATCH", f"products/{product_id}", {"sellPointId": sell_point_id}),
        ("PUT", f"products/{product_id}", {}),
        ("PATCH", f"products/{product_id}", {}),
        # Some integrations accept PUT to collection with id inside body.
        # This is still an update-style request, not POST/create.
        ("PUT", "products", {"sellPointId": sell_point_id}),
    ]

    for method, endpoint, params in candidates:
        try:
            resp = sigma_api_request(
                company_key,
                api_token,
                method,
                endpoint,
                params=params,
                json_body=payload,
                timeout=35,
            )
            text_preview = safe_str(resp.text)[:500]
            attempts.append({
                "method": method,
                "endpoint": endpoint,
                "params": params,
                "status": resp.status_code,
                "text": text_preview,
            })

            if 200 <= resp.status_code < 300:
                log(
                    f"Авто-ШК: SIGMA приняла обновление товара {product.get('name') or product_id}; "
                    f"{method} /{endpoint}; добавлено: {', '.join(missing_codes)}"
                )
                return {
                    "ok": True,
                    "product_id": product_id,
                    "product_name": product.get("name"),
                    "added_barcodes": list(missing_codes),
                    "method": method,
                    "endpoint": endpoint,
                    "status": resp.status_code,
                    "attempts": attempts,
                }

            log(f"Авто-ШК: {method} /{endpoint} HTTP {resp.status_code} — {text_preview[:220]}")
        except Exception as e:
            attempts.append({
                "method": method,
                "endpoint": endpoint,
                "params": params,
                "status": "ERROR",
                "text": str(e)[:500],
            })
            log(f"Авто-ШК: {method} /{endpoint} ошибка — {str(e)[:220]}")

    return {
        "ok": False,
        "product_id": product_id,
        "product_name": product.get("name"),
        "added_barcodes": list(missing_codes),
        "message": "SIGMA не приняла ни один вариант обновления",
        "attempts": attempts,
    }


def auto_add_missing_barcodes(company_key, api_token, sell_point_id, add_needed, sai_path, supplier, invoice_date, log_callback=None):
    if not add_needed:
        return {
            "attempted": 0,
            "success": 0,
            "failed": 0,
            "results": [],
            "report_path": "",
        }

    def log(msg):
        if log_callback:
            log_callback(msg)

    supplier_part = sanitize_filename_part(supplier)
    date_part = date_code_from_text(invoice_date)
    out_dir = Path(sai_path).resolve().parent
    report_path = out_dir / f"Авто_добавление_ШК_{supplier_part}_{date_part}.json"

    log(f"Авто-ШК: пробую добавить недостающие ШК к существующим товарам, позиций: {len(add_needed)}")
    results = []

    for item in add_needed:
        row = item["row"]
        product = item["product"]
        missing_codes = item.get("missing_codes") or []
        matched_codes = item.get("matched_codes") or []

        reason = item.get("match_reason") or "barcode_partial"
        reason_text = "найден по точному названию" if reason == "exact_name" else "найден по ШК"
        log(
            f"Авто-ШК: Excel row {row.get('excel_row')} — {row.get('name')} | "
            f"товар SIGMA: {product.get('name') or product.get('id')} ({reason_text}) | "
            f"добавить: {', '.join(missing_codes)}"
        )

        result = try_update_sigma_product_barcodes(
            company_key,
            api_token,
            sell_point_id,
            product,
            matched_codes,
            missing_codes,
            log_callback=log,
        )
        result["excel_row"] = row.get("excel_row")
        result["sai_name"] = row.get("name")
        result["matched_codes"] = matched_codes
        results.append(result)

    success = sum(1 for r in results if r.get("ok"))
    failed = len(results) - success

    report = {
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "supplier": supplier,
        "invoice_date": invoice_date,
        "attempted": len(results),
        "success": success,
        "failed": failed,
        "results": results,
    }
    try:
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        log(f"Авто-ШК: отчёт сохранён: {report_path}")
    except Exception as e:
        log(f"Авто-ШК: не смог сохранить отчёт — {str(e)[:160]}")
        report_path = Path("")

    if failed:
        log(f"Авто-ШК: добавлено успешно {success}, не добавлено {failed}. Нужна ручная проверка.")
    else:
        log(f"Авто-ШК: все недостающие ШК добавлены успешно: {success}")

    return {
        "attempted": len(results),
        "success": success,
        "failed": failed,
        "results": results,
        "report_path": str(report_path) if report_path else "",
    }



def product_human_label(product):
    name = safe_str(product.get("name")) or "без названия"
    pid = safe_str(product.get("id"))
    vendor = safe_str(product.get("vendorCode"))
    parts = [name]
    if vendor:
        parts.append(f"Артикул: {vendor}")
    if pid:
        parts.append(f"ID: {pid}")
    return "\n".join(parts)


def row_human_label(row, codes=None):
    name = safe_str(row.get("name")) or "без названия"
    codes = codes if codes is not None else (row.get("barcodes") or [])
    codes_text = ", ".join(codes) if codes else "нет ШК"
    return f"{name}\nШК в строке: {codes_text}"


def write_barcode_update_file(add_needed, conflicts, sai_path, supplier, invoice_date, out_dir=None):
    if not add_needed and not conflicts:
        return None

    from openpyxl import Workbook

    supplier_part = sanitize_filename_part(supplier)
    date_part = date_code_from_text(invoice_date)
    out_dir = Path(out_dir) if out_dir else Path(sai_path).resolve().parent
    out_path = out_dir / f"ШК_к_существующим_товарам_{supplier_part}_{date_part}.xlsx"

    wb = Workbook()
    ws = wb.active
    ws.title = "Безопасно добавить ШК"

    headers = [
        "Статус",
        "Excel row",
        "Товар из накладной",
        "Найденный товар SIGMA",
        "Все ШК найденного товара",
        "Совпавшие ШК",
        "Добавить ШК",
        "Почему безопасно",
        "Решение",
    ]
    for c, h in enumerate(headers, start=1):
        ws.cell(1, c).value = h

    r = 2
    for item in add_needed:
        row = item["row"]
        product = item["product"]
        row_codes = row.get("barcodes") or []
        product_codes = product.get("barcodes") or []
        matched_codes = item.get("matched_codes", [])
        match_reason = item.get("match_reason") or "barcode_partial"
        matched_text = ", ".join(matched_codes) if matched_codes else ("точное совпадение названия" if match_reason == "exact_name" else "")
        why_safe = (
            "ШК не найден, но в SIGMA уже есть ровно один товар с таким же точным названием. "
            "Импорт такого товара SIGMA отклонит как дубль; нужно добавить ШК к найденному товару."
            if match_reason == "exact_name"
            else "Все найденные ШК из этой строки ведут к одному товару SIGMA, а этот ШК свободен."
        )
        for code in item["missing_codes"]:
            ws.cell(r, 1).value = "МОЖНО АВТОМАТИЧЕСКИ"
            ws.cell(r, 2).value = row.get("excel_row")
            ws.cell(r, 3).value = row_human_label(row, row_codes)
            ws.cell(r, 4).value = product_human_label(product)
            ws.cell(r, 5).value = ", ".join(product_codes)
            ws.cell(r, 6).value = matched_text
            ws.cell(r, 7).value = code
            ws.cell(r, 8).value = why_safe
            ws.cell(r, 9).value = "Добавить этот ШК к найденному товару. Новую позицию НЕ импортировать."
            ws.cell(r, 7).number_format = "@"
            r += 1

    # Conflict sheet: readable product blocks. Each conflicting SIGMA product gets 3 columns:
    # product description, all its barcodes, and the barcode(s) from the invoice that pointed to it.
    ws2 = wb.create_sheet("Конфликты ШК")

    max_products = max((len(item.get("products", [])) for item in conflicts), default=0)
    max_products = max(max_products, 2)  # keep a stable shape even for 2-way conflicts

    headers2 = [
        "Статус",
        "Excel row",
        "Товар из накладной",
        "ШК в строке накладной",
    ]
    for i in range(1, max_products + 1):
        headers2.extend([
            f"SIGMA товар {i}",
            f"Все ШК товара {i}",
            f"Конфликтный ШК → товар {i}",
        ])
    headers2.extend([
        "Свободные/не найденные ШК из строки",
        "Что это значит",
        "Что сделать вручную",
    ])

    for c, h in enumerate(headers2, start=1):
        ws2.cell(1, c).value = h

    r = 2
    for item in conflicts:
        row = item["row"]
        codes = item.get("codes", []) or []
        products = item.get("products", []) or []

        matched_all = set()
        for p in products:
            for code in p.get("matched_codes", []) or []:
                matched_all.add(code)
        free_codes = [code for code in codes if code not in matched_all]

        ws2.cell(r, 1).value = "РУЧНАЯ ПРОВЕРКА"
        ws2.cell(r, 2).value = row.get("excel_row")
        ws2.cell(r, 3).value = row_human_label(row, codes)
        ws2.cell(r, 4).value = ", ".join(codes)

        col = 5
        for p in products:
            ws2.cell(r, col).value = product_human_label(p)
            ws2.cell(r, col + 1).value = ", ".join(p.get("barcodes", []) or [])
            ws2.cell(r, col + 2).value = ", ".join(p.get("matched_codes", []) or [])
            col += 3

        ws2.cell(r, 5 + max_products * 3).value = ", ".join(free_codes)
        ws2.cell(r, 6 + max_products * 3).value = (
            "ШК из одной строки накладной уже привязаны к разным товарам SIGMA. "
            "SAI не может безопасно решить, какой товар правильный."
        )
        ws2.cell(r, 7 + max_products * 3).value = (
            "Открой SIGMA, проверь товары и реши: оставить как есть, перенести ШК, удалить ошибочный ШК "
            "или исправить строку SAI. После ручного исправления повтори проверку."
        )
        r += 1

    # Optional short guide sheet.
    ws3 = wb.create_sheet("Как читать")
    guide_rows = [
        ("Лист", "Что значит"),
        ("Безопасно добавить ШК", "SAI нашёл ровно один товар SIGMA: либо по ШК, либо по точному названию. Свободный ШК нужно добавить к этому товару, а новую позицию не импортировать."),
        ("Конфликты ШК", "ШК из одной строки накладной ведут к разным товарам SIGMA. Это нельзя исправлять автоматически."),
        ("Конфликтный ШК → товар N", "Именно этот ШК из строки накладной уже привязан к указанному товару SIGMA."),
        ("Свободные/не найденные ШК", "Эти ШК из строки пока не найдены в SIGMA. Их нельзя добавлять, пока не решён конфликт между найденными товарами."),
        ("Главное правило", "Если все найденные ШК ведут к одному товару — безопасно. Если найденные ШК ведут к двум и более товарам — ручная проверка."),
    ]
    for rr, values in enumerate(guide_rows, start=1):
        ws3.cell(rr, 1).value = values[0]
        ws3.cell(rr, 2).value = values[1]

    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(bold=True, color="FFFFFF")
    stop_fill = PatternFill("solid", fgColor="FCE4D6")
    safe_fill = PatternFill("solid", fgColor="E2F0D9")
    thin = Side(style="thin", color="D9E2F3")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for sheet in (ws, ws2, ws3):
        for cell in sheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row_cells in sheet.iter_rows(min_row=1, max_row=sheet.max_row):
            for cell in row_cells:
                cell.border = border
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        sheet.freeze_panes = "A2"

    for row_cells in ws.iter_rows(min_row=2, max_row=ws.max_row):
        row_cells[0].fill = safe_fill

    for row_cells in ws2.iter_rows(min_row=2, max_row=ws2.max_row):
        row_cells[0].fill = stop_fill

    widths = [24, 12, 52, 52, 52, 28, 24, 52, 58]
    for c, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c)].width = w

    widths2 = [20, 12, 58, 42]
    for _ in range(max_products):
        widths2.extend([58, 52, 34])
    widths2.extend([36, 58, 70])
    for c, w in enumerate(widths2, start=1):
        ws2.column_dimensions[get_column_letter(c)].width = w

    ws3.column_dimensions["A"].width = 28
    ws3.column_dimensions["B"].width = 110

    wb.save(out_path)
    make_xlsx_sigma_compatible(out_path)
    return out_path




def build_catalog_name_index(catalog):
    """Build normalized exact-name index from catalog products.

    Only exact normalized names are used. Fuzzy matching is deliberately not used
    here: this guard is for SIGMA's duplicate-name import rejection, not for
    guessing similar products.
    """
    name_to_products = {}
    for product in (catalog.get("products_by_id") or {}).values():
        if not isinstance(product, dict):
            continue
        key = normalize_product_name_for_match(product.get("name"))
        if not key:
            continue
        pid = safe_str(product.get("id")) or safe_str(product.get("sigma_id"))
        bucket = name_to_products.setdefault(key, {})
        bucket[pid or f"NO_ID:{key}"] = product
    return name_to_products


def barcode_conflict_resolution_key(row):
    codes = ",".join(sorted(set(row.get("barcodes") or [])))
    name = normalize_product_name_for_match(row.get("name"))
    return f"{codes}|{name}"


def load_barcode_conflict_resolutions():
    try:
        payload = json.loads(BARCODE_CONFLICT_RESOLUTIONS_PATH.read_text(encoding="utf-8"))
        return dict(payload) if isinstance(payload, dict) else {}
    except Exception:
        return {}


def save_barcode_conflict_resolution(row, product_id):
    key = barcode_conflict_resolution_key(row)
    pid = safe_str(product_id)
    if not key or not pid:
        raise ValueError("Не выбран товар SIGMA для разрешения конфликта ШК.")
    ensure_runtime_dirs()
    payload = load_barcode_conflict_resolutions()
    payload[key] = {
        "product_id": pid,
        "row_name": safe_str(row.get("name")),
        "barcodes": list(dict.fromkeys(row.get("barcodes") or [])),
        "saved_at": dt.datetime.now().astimezone().isoformat(),
    }
    temp = BARCODE_CONFLICT_RESOLUTIONS_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(BARCODE_CONFLICT_RESOLUTIONS_PATH)
    return key


def analyze_multi_barcode_rows(rows, catalog, exact_name_guard=True, conflict_resolutions=None):
    code_to_products = catalog["code_to_products"]
    name_to_products = build_catalog_name_index(catalog) if exact_name_guard else {}

    ok_full = []
    add_needed = []
    missing = []
    no_barcode = []
    conflicts = []
    resolved_name_conflicts = []
    resolved_manual_conflicts = []
    resolution_map = conflict_resolutions if conflict_resolutions is not None else load_barcode_conflict_resolutions()

    for row in rows:
        codes = list(dict.fromkeys(row.get("barcodes") or []))
        if not codes:
            no_barcode.append(row)
            continue

        matched_by_product = {}
        for code in codes:
            products_for_code = code_to_products.get(code) or {}
            for pid, product in products_for_code.items():
                entry = matched_by_product.setdefault(pid, {"product": product, "matched_codes": []})
                if code not in entry["matched_codes"]:
                    entry["matched_codes"].append(code)

        if not matched_by_product:
            # v1.17.1: SIGMA import also rejects duplicates by exact product name.
            # If the barcode is absent but the name already exists, this is not a
            # new product. It is a missing barcode for an existing product.
            name_key = normalize_product_name_for_match(row.get("name"))
            name_matches = list((name_to_products.get(name_key) or {}).values()) if name_key else []
            if len(name_matches) == 1:
                product = name_matches[0]
                existing_codes = set(product.get("barcodes") or [])
                missing_codes = [code for code in codes if code not in existing_codes]
                if missing_codes:
                    add_needed.append({
                        "row": row,
                        "product": product,
                        "matched_codes": [],
                        "missing_codes": missing_codes,
                        "match_reason": "exact_name",
                    })
                    continue
            elif len(name_matches) > 1:
                conflict_products = []
                for product in name_matches:
                    p = dict(product)
                    p["matched_codes"] = []
                    p["name_match"] = True
                    conflict_products.append(p)
                conflicts.append({
                    "row": row,
                    "codes": codes,
                    "products": conflict_products,
                    "reason": "duplicate_name_many",
                })
                continue

            missing.append(row)
            continue

        if len(matched_by_product) > 1:
            saved = resolution_map.get(barcode_conflict_resolution_key(row)) or {}
            saved_product_id = safe_str(saved.get("product_id") if isinstance(saved, dict) else saved)
            saved_entry = matched_by_product.get(saved_product_id)
            if saved_entry is not None:
                product = saved_entry["product"]
                existing_codes = set(product.get("barcodes") or [])
                missing_codes = [code for code in codes if code not in existing_codes]
                resolved_manual_conflicts.append({
                    "row": row,
                    "product": product,
                    "codes": codes,
                    "reason": "operator_saved_choice",
                })
                if missing_codes:
                    add_needed.append({
                        "row": row,
                        "product": product,
                        "matched_codes": saved_entry["matched_codes"],
                        "missing_codes": missing_codes,
                        "match_reason": "operator_saved_choice",
                    })
                else:
                    ok_full.append(row)
                continue
            # SIGMA can temporarily (or permanently) return the same barcode on
            # two product cards. If exactly one of those cards has the same
            # normalized name as the invoice row, that is a deterministic
            # operator-visible tie-breaker rather than an endless conflict.
            row_name_key = normalize_product_name_for_match(row.get("name"))
            exact_entries = [
                entry for entry in matched_by_product.values()
                if row_name_key
                and normalize_product_name_for_match(entry["product"].get("name")) == row_name_key
            ]
            if len(exact_entries) == 1:
                entry = exact_entries[0]
                product = entry["product"]
                existing_codes = set(product.get("barcodes") or [])
                missing_codes = [code for code in codes if code not in existing_codes]
                resolved_name_conflicts.append({
                    "row": row,
                    "product": product,
                    "codes": codes,
                    "ignored_product_ids": [
                        pid for pid, candidate in matched_by_product.items()
                        if candidate is not entry
                    ],
                    "reason": "unique_exact_name_among_barcode_duplicates",
                })
                if missing_codes:
                    add_needed.append({
                        "row": row,
                        "product": product,
                        "matched_codes": entry["matched_codes"],
                        "missing_codes": missing_codes,
                        "match_reason": "exact_name_barcode_conflict",
                    })
                else:
                    ok_full.append(row)
                continue
            conflict_products = []
            for pid, entry in matched_by_product.items():
                p = dict(entry["product"])
                p["matched_codes"] = entry["matched_codes"]
                conflict_products.append(p)
            conflicts.append({
                "row": row,
                "codes": codes,
                "products": conflict_products,
                "reason": "barcode_conflict",
            })
            continue

        entry = next(iter(matched_by_product.values()))
        product = entry["product"]
        existing_codes = set(product.get("barcodes") or [])
        missing_codes = [code for code in codes if code not in existing_codes]

        if missing_codes:
            add_needed.append({
                "row": row,
                "product": product,
                "matched_codes": entry["matched_codes"],
                "missing_codes": missing_codes,
                "match_reason": "barcode_partial",
            })
        else:
            ok_full.append(row)

    return {
        "ok_full": ok_full,
        "add_needed": add_needed,
        "missing": missing,
        "no_barcode": no_barcode,
        "conflicts": conflicts,
        "resolved_name_conflicts": resolved_name_conflicts,
        "resolved_manual_conflicts": resolved_manual_conflicts,
    }


def recover_imported_products_from_dashboard(missing_rows, catalog, private_cfg, log_callback=None):
    """Find freshly imported products through the dashboard's live search.

    SIGMA's old X-Api-Key catalogue can lag behind (or omit) products that are
    already visible in the web cabinet.  The v5 remainder search is the same
    endpoint used by that cabinet and returns the product id and barcode
    immediately.  It is used only as a targeted post-import fallback.
    """
    rows = list(missing_rows or [])
    if not rows:
        return 0
    try:
        from sai_api_first_apply import load_runtime_token_cache_payload
        runtime = load_runtime_token_cache_payload(max_age_seconds=30 * 24 * 60 * 60)
    except Exception:
        runtime = {}
    token = safe_str(runtime.get("token"))
    api_base = safe_str(runtime.get("api_base")).rstrip("/")
    company_id = safe_str(private_cfg.get("sigma_internal_company_id"))
    if not token or not api_base or not company_id:
        return 0
    url = f"{api_base}/rest/v5/companies/{company_id}/products/remainders"
    headers = {"Accept": "application/json", "Authorization": "Bearer " + token, "User-Agent": f"SAI/{APP_VERSION}"}

    def lookup(row):
        wanted = set(str(code) for code in (row.get("barcodes") or []) if str(code))
        queries = list(wanted) or [safe_str(row.get("name"))]
        found = []
        for query in queries[:4]:
            try:
                response = requests.get(url, params={"search": query, "sort": "", "page": 0}, headers=headers, timeout=15)
                if not (200 <= response.status_code < 300):
                    continue
                payload = response.json()
                products = payload.get("products") if isinstance(payload, dict) else []
                for product in products or []:
                    codes = extract_product_barcodes(product)
                    if wanted and not (wanted & codes):
                        continue
                    found.append(product)
                if found:
                    break
            except Exception:
                continue
        return found

    recovered = {}
    with ThreadPoolExecutor(max_workers=min(6, max(1, len(rows))), thread_name_prefix="sai-import-search") as pool:
        for products in pool.map(lookup, rows):
            for product in products:
                summary = summarize_sigma_product(product)
                if summary.get("id"):
                    recovered[summary["id"]] = summary
    for pid, summary in recovered.items():
        catalog.setdefault("products_by_id", {})[pid] = summary
        for code in summary.get("barcodes") or []:
            catalog.setdefault("codes", set()).add(code)
            catalog.setdefault("code_to_products", {}).setdefault(code, {})[pid] = summary
    if recovered and log_callback:
        log_callback(
            f"SIGMA live-поиск: найдено уже импортированных карточек {len(recovered)}. "
            "Продолжаю без ожидания старого каталога."
        )
    return len(recovered)



def create_import_file_from_sigma_api(sai_path, supplier, invoice_date, private_cfg, out_dir=None, log_callback=None):
    def log(msg):
        if log_callback:
            log_callback(msg)

    sheet_name, rows = load_sai_rows(sai_path)
    rows_with_category = sum(1 for r in rows if safe_str(r.get("category")))
    if rows:
        log(f"SAI категории: прочитано {rows_with_category}/{len(rows)} строк с заполненной категорией.")
        for warn in duplicate_article_warnings(rows):
            examples = "; ".join(warn.get("examples") or [])
            log(
                f"ВНИМАНИЕ: артикул '{warn['article']}' повторяется в {warn['count']} строках SAI. "
                f"Если SIGMA использует артикул для поиска дублей, импорт может пройти не полностью. Примеры: {examples}"
            )

    company_key = safe_str(private_cfg.get("sigma_company_key"))
    api_token = safe_str(private_cfg.get("sigma_api_token"))
    if not company_key or not api_token:
        raise RuntimeError("В user_data/sai_private_config.json не заполнены sigma_company_key и/или sigma_api_token.")

    sell_point_id = get_sigma_sell_point_id(company_key, api_token, private_cfg, log_callback=log)

    # Categories are not required for barcode matching and slow down every check.
    # Keep this probe only for diagnostics; category values for Import_*.xlsx are read directly from SAI.
    if bool(private_cfg.get("debug_probe_categories", False)):
        try:
            resp_cat = sigma_api_get(company_key, api_token, "product-categories", params={"sellPointId": sell_point_id}, timeout=25)
            if 200 <= resp_cat.status_code < 300:
                cat_count = len(extract_data_list(resp_cat.json()))
                log(f"SIGMA API categories: OK, категорий на первой странице={cat_count}")
            else:
                log(f"SIGMA API categories: HTTP {resp_cat.status_code} — {resp_cat.text[:250]}")
        except Exception as e:
            log(f"SIGMA API categories: не критично, пропускаю — {str(e)[:180]}")

    force_initial_refresh = current_sai_needs_forced_catalog_refresh(sai_path)
    fast_mode = bool(private_cfg.get("catalog_fast_mode", True))
    exact_name_guard = bool(private_cfg.get("exact_name_duplicate_guard", True))
    trust_minutes = parse_int_config(private_cfg.get("catalog_trust_fresh_cache_minutes"), 30)
    cache_age = sigma_catalog_cache_age_seconds(company_key, sell_point_id)
    cache_is_fresh = cache_age is not None and cache_age <= max(1, trust_minutes) * 60
    session_refreshed = bool(private_cfg.get("_catalog_refreshed_this_session"))
    require_session_refresh = bool(private_cfg.get("catalog_require_session_refresh_for_ready", True))
    force_session_refresh = bool(require_session_refresh and not session_refreshed and not force_initial_refresh)
    force_catalog_refresh = bool(force_initial_refresh or force_session_refresh)

    if force_initial_refresh:
        log("SIGMA каталог: нажата повторная проверка после импорта. Обновляю SIGMA → SQLite перед проверкой...")
    elif force_session_refresh:
        log("SIGMA каталог: в этой сессии ещё не было live-обновления. Обновляю SIGMA → SQLite перед проверкой...")
    elif fast_mode and cache_is_fresh:
        log(f"SIGMA каталог: использую SQLite-каталог текущей сессии, возраст {int(cache_age)} сек. Полную перечитку не делаю.")
    catalog = get_sigma_api_catalog_cached(company_key, api_token, sell_point_id, log_callback=log, force_refresh=force_catalog_refresh)
    analysis = analyze_multi_barcode_rows(rows, catalog, exact_name_guard=exact_name_guard)

    missing = analysis["missing"]
    no_barcode = analysis["no_barcode"]
    ok_full = analysis["ok_full"]
    add_needed = analysis["add_needed"]
    conflicts = analysis["conflicts"]
    resolved_name_conflicts = analysis.get("resolved_name_conflicts") or []
    resolved_manual_conflicts = analysis.get("resolved_manual_conflicts") or []

    # v1.15.2:
    # Before returning a blocking result, always verify against live SIGMA at least once.
    # If the current SAI file previously produced Import_...xlsx, do a second delayed refresh:
    # SIGMA sometimes accepts the import in UI but the official products endpoint lags a few seconds.
    if (missing or add_needed or conflicts) and not force_initial_refresh:
        if fast_mode and cache_is_fresh:
            log(
                "SIGMA каталог: быстрый режим — не делаю вторую полную перечитку перед созданием импорта, "
                "потому что кэш свежий. При сомнении нажмите «Обновить каталог SIGMA» вручную."
            )
        else:
            log(
                "SIGMA каталог: проверка показывает новые товары/ШК-конфликты. "
                "Обновляю каталог SIGMA перед окончательным решением..."
            )
            catalog = get_sigma_api_catalog_cached(company_key, api_token, sell_point_id, log_callback=log, force_refresh=True)
            analysis = analyze_multi_barcode_rows(rows, catalog, exact_name_guard=exact_name_guard)
            missing = analysis["missing"]
            no_barcode = analysis["no_barcode"]
            ok_full = analysis["ok_full"]
            add_needed = analysis["add_needed"]
            conflicts = analysis["conflicts"]
            resolved_name_conflicts = analysis.get("resolved_name_conflicts") or []
            resolved_manual_conflicts = analysis.get("resolved_manual_conflicts") or []

    if (missing or add_needed or conflicts) and force_initial_refresh:
        # SIGMA may accept the UI import before the product endpoint sees every new row.
        # v1.16.3: keep this short by default; long waiting made repeated checks feel frozen.
        # A successful manual XLSX import can appear in SIGMA's products API
        # noticeably later than it appears in the browser.  Keep polling before
        # declaring the same products missing and rebuilding the import.
        waits = normalize_wait_list(
            private_cfg.get("post_import_retry_waits_seconds"),
            default=(3, 8, 15, 30),
        )
        skip_when_leq = parse_int_config(private_cfg.get("post_import_skip_second_full_refresh_when_remaining_leq"), 3)
        remaining_problem_count = len(missing or []) + len(add_needed or []) + len(conflicts or [])
        if remaining_problem_count and remaining_problem_count <= max(0, skip_when_leq):
            log(
                "SIGMA каталог: после импорта осталось мало спорных строк "
                f"({remaining_problem_count}). Вторую полную перечитку не делаю — быстрее показать точечный список для проверки."
            )
            waits = []
        if not waits:
            log("SIGMA каталог: быстрый режим после импорта — дополнительные ожидания/перечитки отключены.")
        for wait_seconds in waits:
            if not (missing or add_needed or conflicts):
                break
            log(
                "SIGMA каталог: после импорта товары всё ещё не найдены. "
                f"Жду {wait_seconds} сек. и обновляю каталог ещё раз — у SIGMA бывает задержка индексации..."
            )
            time.sleep(wait_seconds)
            catalog = get_sigma_api_catalog_cached(company_key, api_token, sell_point_id, log_callback=log, force_refresh=True)
            analysis = analyze_multi_barcode_rows(rows, catalog, exact_name_guard=exact_name_guard)
            missing = analysis["missing"]
            no_barcode = analysis["no_barcode"]
            ok_full = analysis["ok_full"]
            add_needed = analysis["add_needed"]
            conflicts = analysis["conflicts"]
            resolved_name_conflicts = analysis.get("resolved_name_conflicts") or []
            resolved_manual_conflicts = analysis.get("resolved_manual_conflicts") or []

    if missing:
        recovered_count = recover_imported_products_from_dashboard(missing, catalog, private_cfg, log_callback=log)
        if recovered_count:
            analysis = analyze_multi_barcode_rows(rows, catalog, exact_name_guard=exact_name_guard)
            missing = analysis["missing"]
            no_barcode = analysis["no_barcode"]
            ok_full = analysis["ok_full"]
            add_needed = analysis["add_needed"]
            conflicts = analysis["conflicts"]
            resolved_name_conflicts = analysis.get("resolved_name_conflicts") or []
            resolved_manual_conflicts = analysis.get("resolved_manual_conflicts") or []

    auto_add_report = {
        "attempted": 0,
        "success": 0,
        "failed": 0,
        "results": [],
        "report_path": "",
    }

    if add_needed:
        auto_add_report = auto_add_missing_barcodes(
            company_key,
            api_token,
            sell_point_id,
            add_needed,
            sai_path,
            supplier,
            invoice_date,
            log_callback=log,
        )

        if auto_add_report.get("success"):
            log("Авто-ШК: перечитываю каталог SIGMA после попытки добавления ШК...")
            catalog = get_sigma_api_catalog_cached(company_key, api_token, sell_point_id, log_callback=log, force_refresh=True)
            analysis = analyze_multi_barcode_rows(rows, catalog, exact_name_guard=exact_name_guard)
            missing = analysis["missing"]
            no_barcode = analysis["no_barcode"]
            ok_full = analysis["ok_full"]
            add_needed = analysis["add_needed"]
            conflicts = analysis["conflicts"]
            resolved_name_conflicts = analysis.get("resolved_name_conflicts") or []
            resolved_manual_conflicts = analysis.get("resolved_manual_conflicts") or []

    if add_needed:
        log(f"ШК к существующим товарам: найдено строк, где новую позицию импортировать не надо: {len(add_needed)}")
        for item in add_needed[:15]:
            row = item["row"]
            product = item["product"]
            reason = item.get("match_reason") or "barcode_partial"
            found_by = "точному названию" if reason == "exact_name" else (", ".join(item.get("matched_codes") or []) or "ШК")
            log(
                f"  добавить ШК: Excel row {row['excel_row']} — {row['name']} | "
                f"товар SIGMA: {product.get('name') or product.get('id')} | "
                f"найдено по: {found_by} | "
                f"добавить: {', '.join(item['missing_codes'])}"
            )
        if len(add_needed) > 15:
            log(f"  ...ещё {len(add_needed) - 15}")

    if conflicts:
        log(f"Конфликты сопоставления: требуется ручная проверка, строк: {len(conflicts)}")
        for item in conflicts[:10]:
            row = item["row"]
            parts = []
            reason = item.get("reason") or "barcode_conflict"
            for p in item.get("products", []):
                if reason == "duplicate_name_many":
                    parts.append(f"{p.get('name') or p.get('id')} (точное совпадение названия)")
                else:
                    parts.append(f"{p.get('name') or p.get('id')} по {', '.join(p.get('matched_codes', []))}")
            log(f"  конфликт: Excel row {row['excel_row']} — {row['name']} | " + " / ".join(parts))
        if len(conflicts) > 10:
            log(f"  ...ещё {len(conflicts) - 10}")

    if resolved_name_conflicts:
        for item in resolved_name_conflicts[:10]:
            row = item["row"]
            product = item["product"]
            log(
                "Дубль ШК разрешён по единственному точному названию: "
                f"Excel row {row['excel_row']} — {row['name']} → "
                f"{product.get('name') or product.get('id')}"
            )

    if resolved_manual_conflicts:
        for item in resolved_manual_conflicts[:10]:
            row = item["row"]
            product = item["product"]
            log(
                "Дубль ШК разрешён сохранённым выбором пользователя: "
                f"Excel row {row['excel_row']} — {row['name']} → "
                f"{product.get('name') or product.get('id')}"
            )

    import_path = write_import_file_for_missing(missing, sai_path, supplier, invoice_date, out_dir=out_dir)
    barcode_update_path = write_barcode_update_file(add_needed, conflicts, sai_path, supplier, invoice_date, out_dir=out_dir)

    return {
        "mode": "SIGMA API",
        "sheet_name": sheet_name,
        "total": len(rows),
        "ok": len(ok_full) + len(add_needed),
        "ok_full": len(ok_full),
        "barcode_add_needed": len(add_needed),
        "conflicts": len(conflicts),
        "resolved_name_conflicts": len(resolved_name_conflicts),
        "resolved_manual_conflicts": len(resolved_manual_conflicts),
        "missing": len(missing),
        "no_barcode": len(no_barcode),
        "import_path": str(import_path) if import_path else "",
        "barcode_update_path": str(barcode_update_path) if barcode_update_path else "",
        "barcode_auto_add_attempted": auto_add_report.get("attempted", 0),
        "barcode_auto_add_success": auto_add_report.get("success", 0),
        "barcode_auto_add_failed": auto_add_report.get("failed", 0),
        "barcode_auto_add_report_path": auto_add_report.get("report_path", ""),
        "missing_rows": missing,
        "barcode_add_rows": add_needed,
        "conflict_rows": conflicts,
        "no_barcode_rows": no_barcode,
        "source_rows": rows,
        "catalog_force_refreshed": bool(force_catalog_refresh),
        "catalog_session_refreshed": bool(session_refreshed or force_catalog_refresh),
        "catalog_debug": [
            f"SIGMA API products strategy={catalog['strategy']}",
            f"SIGMA API product records read={catalog['product_count']}",
            f"SIGMA API catalog cache={catalog.get('cache_created_at', 'updated_now')}",
            "multi-barcode/name duplicate/session-catalog/fact/ndp-template guard=v1.17.6",
        ],
        "catalog_count": len(catalog["codes"]),
    }



def find_latest_log(log_dir):
    log_dir = Path(log_dir)
    if not log_dir.exists():
        return None
    files = sorted(log_dir.glob("sigma_autoprihod_*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


def read_bot_log_rows(log_path):
    if not log_path or not Path(log_path).exists():
        return []
    rows = []
    with open(log_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=";")
        for row in reader:
            rows.append(row)
    return rows



def enforce_ndp_reference_header(ws, last_data_row=None, dual_prices=False):
    """
    Keep the generated seller invoice visually identical to the reference НДП.xlsx.

    The template is intentionally minimal:
    - A1:F1 is the top summary band.
    - B1:C1 = supplier + date.
    - D1:E1 = label "Итог по цене продажи:".
    - F1 = total.
    - Row 2 is the table header.
    - Rows 3+ are goods.

    This function is called after all value/formula writes because Excel/openpyxl can
    slightly disturb merged-cell borders. It enforces all printable borders every time.
    """
    thin = Side(style="thin", color="000000")
    no_side = Side(style=None)

    # Required merges from the reference template.
    for rng in list(ws.merged_cells.ranges):
        s = str(rng)
        if s in {"B1:C1", "D1:E1"}:
            continue
    existing_merges = {str(rng) for rng in ws.merged_cells.ranges}
    if "B1:C1" not in existing_merges:
        try:
            ws.merge_cells("B1:C1")
        except Exception:
            pass
    existing_merges = {str(rng) for rng in ws.merged_cells.ranges}
    if "D1:E1" not in existing_merges:
        try:
            ws.merge_cells("D1:E1")
        except Exception:
            pass

    # Top summary band. The only intentional missing vertical line is between E1 and F1:
    # visually the label and amount must look like one summary block.
    ws["A1"].border = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["B1"].border = Border(left=thin, right=no_side, top=thin, bottom=thin)
    ws["C1"].border = Border(left=no_side, right=thin, top=thin, bottom=thin)
    ws["D1"].border = Border(left=thin, right=no_side, top=thin, bottom=thin)
    ws["E1"].border = Border(left=no_side, right=no_side, top=thin, bottom=thin)
    ws["F1"].border = Border(left=no_side, right=thin, top=thin, bottom=thin)

    # Header row and body: all visible grid borders from A to F.
    last_row = max(2, int(last_data_row or ws.max_row or 2))
    for r in range(2, last_row + 1):
        for c in range(1, 7):
            ws.cell(r, c).border = Border(left=thin, right=thin, top=thin, bottom=thin)

    # Reference values/formatting for the fixed header.
    ws["A2"] = "✔"
    ws["B2"] = "№"
    ws["C2"] = "Наименование"
    ws["D2"] = "Кол-во"
    ws["E2"] = "Закупочная" if dual_prices else "Цена"
    ws["F2"] = "Продажная" if dual_prices else None

    ws["B1"].alignment = Alignment(horizontal="left", vertical="center", wrap_text=False)
    ws["D1"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws["F1"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
    ws["A2"].alignment = Alignment(horizontal="center", vertical="center")
    ws["B2"].alignment = Alignment(horizontal="center", vertical="center")
    ws["C2"].alignment = Alignment(horizontal="left", vertical="center")
    ws["D2"].alignment = Alignment(horizontal="center", vertical="center")
    ws["E2"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws["F2"].alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws["B1"].font = Font(name="Arial", size=10, bold=True)
    ws["D1"].font = Font(name="Arial", size=10, bold=True)
    ws["F1"].font = Font(name="Arial", size=10, bold=True)
    ws["A2"].font = Font(name="Arial", size=10)
    ws["B2"].font = Font(name="Arial", size=10, bold=True)
    for cell in ("C2", "D2", "E2", "F2"):
        ws[cell].font = Font(name="Arial", size=10, bold=True)

    # Keep the amount in rubles, without kopecks, as in the provided template.
    ws["F1"].number_format = '#,##0\\ [$₽-419];\\-#,##0\\ [$₽-419]'
    ws["D1"].number_format = "General"
    ws["D2"].number_format = "General"
    ws["E2"].number_format = "General"
    ws["F2"].number_format = "General"

    # Do not show Excel gridlines; printable borders are controlled explicitly above.
    try:
        ws.sheet_view.showGridLines = False
        ws.print_options.gridLines = False
    except Exception:
        pass


def apply_ndp_print_settings(ws, last_data_row):
    """Stable print settings for seller invoice: only A:F, one page wide."""
    last_data_row = max(2, int(last_data_row or 2))
    ws.print_area = f"A1:F{last_data_row}"
    ws.print_title_rows = "1:2"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_setup.orientation = "portrait"
    ws.page_setup.paperSize = 9  # A4
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    try:
        ws.page_margins.left = 0.25
        ws.page_margins.right = 0.25
        ws.page_margins.top = 0.35
        ws.page_margins.bottom = 0.35
    except Exception:
        pass

def create_ndp_file(
    sai_path,
    supplier,
    invoice_date,
    log_path=None,
    out_dir=None,
    rows_override=None,
    price_source="sale",
    sale_price_resolver=None,
):
    supplier_part = sanitize_filename_part(supplier)
    date_part = date_code_from_text(invoice_date)
    date_display = date_display_from_text(invoice_date)
    out_dir = Path(out_dir) if out_dir else Path(sai_path).resolve().parent
    out_path = out_dir / f"Накладная_для_продавцов_{supplier_part}_{date_part}.xlsx"

    # Prefer bot log because it contains final_selling_price.
    price_mode = str(price_source or "").strip().lower()
    use_purchase_price = price_mode == "buy"
    dual_prices = price_mode in {"buy_and_sale", "buy+sale", "both"}
    default_markup = parse_float(load_private_config().get("default_markup_percent") or 60)
    log_rows = read_bot_log_rows(log_path) if log_path and not use_purchase_price else []
    ok_rows = [r for r in log_rows if safe_str(r.get("status")).upper() == "OK"]

    def seller_name(value, *, normalize=False):
        # Names are already normalized and then approved by the operator.  A
        # second cleanup here used to remove meaningful manual characters such
        # as the inch mark in 1/2\" and made NDP differ from the final review.
        source = safe_str(value)
        if not normalize:
            return source
        normalized = sai_product_names.normalize_product_name(source).normalized
        return normalized or source

    def resolved_sale(row, fallback):
        if sale_price_resolver is None:
            return fallback
        try:
            catalog_sale = parse_float(sale_price_resolver(row))
        except Exception:
            return fallback
        return catalog_sale if catalog_sale > 0 else fallback

    data = []
    if rows_override is not None:
        for r in list(rows_override or []):
            name = seller_name(r.get("name"), normalize=True)
            qty = parse_int_or_float(r.get("qty") or r.get("quantity"))
            if dual_prices:
                buy = parse_float(r.get("buy") or r.get("purchase_price"))
                sale = parse_float(r.get("sale") or r.get("sale_price") or r.get("price"))
                sale = resolved_sale(r, sale)
                if sale <= 0 and buy > 0:
                    sale = sale_price_from_purchase(
                        buy,
                        r.get("markup") or r.get("markup_percent") or default_markup,
                    )
                price = (buy, sale)
            elif use_purchase_price:
                price = parse_float(r.get("buy") or r.get("purchase_price") or r.get("price"))
            else:
                price = parse_float(r.get("sale") or r.get("sale_price") or r.get("price"))
            if name and float(qty or 0) > 0:
                data.append([name, qty, price])
    elif ok_rows:
        for r in ok_rows:
            name = seller_name(r.get("name"))
            qty = parse_int_or_float(r.get("quantity"))
            price = parse_float(r.get("final_selling_price") or r.get("incoming_selling_price"))
            if name:
                data.append([name, qty, price])
    else:
        # Fallback: use SAI file sale price.
        _, rows = load_sai_rows(sai_path)
        for r in rows:
            qty = parse_int_or_float(r.get("qty"))
            # Effective SAI workbooks mark skipped/returned/full-shortage rows with
            # quantity 0. They must not reappear in the seller invoice.
            if r.get("name") and float(qty or 0) > 0:
                if dual_prices:
                    buy = parse_float(r.get("buy"))
                    sale = parse_float(r.get("sale"))
                    sale = resolved_sale(r, sale)
                    if sale <= 0 and buy > 0:
                        sale = sale_price_from_purchase(buy, default_markup)
                    price = (buy, sale)
                else:
                    price = r.get("buy") if use_purchase_price else r.get("sale")
                data.append([seller_name(r["name"]), qty, price])

    template = TEMPLATES_DIR / "НДП.xlsx"
    if not template.exists():
        raise FileNotFoundError("Не найден шаблон НДП.xlsx в templates")

    wb = load_workbook(template)
    ws = wb.active
    if dual_prices:
        # Preserve the overall A4 width while giving both price headers enough room.
        ws.column_dimensions["C"].width = 42
        ws.column_dimensions["E"].width = 13
        ws.column_dimensions["F"].width = 14
    enforce_ndp_reference_header(ws, last_data_row=24, dual_prices=dual_prices)

    # Based on user-provided template:
    # B1 supplier+date, F1 total, row 2 headers, rows 3+ goods.
    ws["B1"] = f"{supplier} {date_display}".strip()

    start_row = 3

    # Clear a generous body area while keeping styles.
    max_body = max(ws.max_row, start_row + len(data) + 50)
    for r in range(start_row, max_body + 1):
        for c in range(1, 7):
            ws.cell(r, c).value = None
        ws.row_dimensions[r].hidden = False

    # Copy style from first data row if present.
    style_source_row = start_row
    for i, (name, qty, price) in enumerate(data, start=start_row):
        buy_price, sale_price = price if dual_prices else (price, None)
        ws.cell(i, 1).value = ""  # checkbox column
        ws.cell(i, 2).value = i - start_row + 1
        ws.cell(i, 3).value = name
        ws.cell(i, 4).value = qty
        ws.cell(i, 5).value = buy_price
        ws.cell(i, 6).value = sale_price

        for c in range(1, 7):
            if i != style_source_row:
                ws.cell(i, c)._style = ws.cell(style_source_row, c)._style

        # NDP formatting:
        # - product name wraps to several lines;
        # - quantity and price are centered;
        # - row height is adjusted approximately because XLSX has no reliable "auto-fit row height" flag.
        ws.cell(i, 1).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.cell(i, 2).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.cell(i, 3).alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        ws.cell(i, 4).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.cell(i, 5).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.cell(i, 6).alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.cell(i, 4).number_format = "0"
        ws.cell(i, 5).number_format = "0"
        ws.cell(i, 6).number_format = "0"

        name_len = len(str(name or ""))
        ws.row_dimensions[i].height = max(22, min(72, 18 * ((name_len // 42) + 1)))

    # Total sale amount in F1.
    last_data_row = max(2, start_row + len(data) - 1)
    if data:
        total_price_column = "F" if dual_prices else "E"
        ws["F1"] = f"=SUMPRODUCT(D{start_row}:D{last_data_row},{total_price_column}{start_row}:{total_price_column}{last_data_row})"
    else:
        ws["F1"] = 0

    # Restore reference header borders after all value/formula edits.
    # Especially important: no visible border between "Итог по цене продажи:" and F1 total.
    enforce_ndp_reference_header(ws, last_data_row=last_data_row, dual_prices=dual_prices)

    # Hide excess rows after data, preserving print template.
    hide_from = start_row + len(data)
    for r in range(hide_from, max_body + 1):
        ws.row_dimensions[r].hidden = True

    # Sensible print settings. Keep Excel from treating old template ghosts up to XFD as printable area.
    apply_ndp_print_settings(ws, last_data_row)

    wb.save(out_path)
    return str(out_path), len(data)


class SAIApp(Tk):
    def __init__(self):
        super().__init__()
        self.title(f"SAI — мастер приёмки {APP_VERSION}")
        self.geometry("1080x680")
        self.minsize(860, 560)
        self.after(50, self.center_window)

        self.sai_path = StringVar()
        self.catalog_path = StringVar()
        self.waybill = StringVar()
        self.supplier = StringVar()
        self.invoice_date = StringVar()
        self.supplier_choice = StringVar()
        self.supplier_id = StringVar()
        self.runtime_storehouse_id = StringVar()
        self.last_sai_dir = StringVar()
        self.status_var = StringVar(value="Мастер SAI готов. Начните с подготовки накладной.")
        self.catalog_ready = False
        self.last_log_path = ""
        self.last_run_apply = False
        self.last_ndp_path = ""
        self.run_started_at = None
        self.last_heartbeat_at = 0.0
        self.queue = queue.Queue()
        self.running = False
        self.suppliers = []
        self.pending_check_after_waybill = False
        self.pending_waybill_created = None
        self.child_processes = []
        self.closing = False
        self.last_bot_status = StringVar(value="SAI ждёт действия")
        self.breath_on = False
        self.startup_warmup_running = False
        self.startup_warmup_done = False
        self.startup_warmup_error = ""
        self.catalog_refreshed_this_session = False
        self.catalog_session_refreshed_at = ""
        self.startup_progress = 0.0
        self.startup_progress_target = 8.0
        self.startup_stage_text = "Подготавливаю SAI…"
        self.startup_tip_text = ""
        self.splash_phase = 0
        self.splash_canvas = None
        self.splash_items = {}
        self.browser_visible = BooleanVar(value=bool(load_private_config().get("browser_visible", False)))

        self.load_config()
        self.build_ui()
        self.after(250, self.auto_select_latest_sai_file)
        self.after(450, self.startup_warmup)
        self.after(150, self.poll_queue)

    def center_window(self):
        """Place the main SAI window in the center of the current screen."""
        try:
            self.update_idletasks()
            w = self.winfo_width() or 1080
            h = self.winfo_height() or 680
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            x = max(0, int((sw - w) / 2))
            y = max(0, int((sh - h) / 2))
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

    def set_startup_chrome(self, enabled):
        """Show the clean white startup screen before the normal SAI interface exists visually."""
        try:
            startup = getattr(self, "startup_full_frame", None)
            main = getattr(self, "main_root_frame", None)
            if enabled:
                if main is not None and main.winfo_ismapped():
                    main.pack_forget()
                if startup is not None and not startup.winfo_ismapped():
                    startup.pack(fill="both", expand=True)
            else:
                if startup is not None and startup.winfo_ismapped():
                    startup.pack_forget()
                if main is not None and not main.winfo_ismapped():
                    main.pack(fill="both", expand=True)
        except Exception:
            pass

    def load_config(self):
        if CONFIG_PATH.exists():
            try:
                data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                self.sai_path.set(data.get("sai_path", ""))
                self.catalog_path.set(data.get("catalog_path", ""))
                self.supplier.set(data.get("supplier", ""))
                self.supplier_choice.set(data.get("supplier_choice", data.get("supplier", "")))
                self.supplier_id.set(data.get("supplier_id", ""))
                self.runtime_storehouse_id.set(data.get("runtime_storehouse_id", ""))
                self.last_sai_dir.set(data.get("last_sai_dir", ""))
                self.invoice_date.set(data.get("invoice_date", ""))
                self.waybill.set(data.get("waybill", ""))
            except Exception:
                pass
        save_private_config_template_if_missing()

    def save_config(self):
        data = {
            "sai_path": self.sai_path.get(),
            "catalog_path": self.catalog_path.get(),
            "supplier": self.supplier.get(),
            "supplier_choice": self.supplier_choice.get(),
            "supplier_id": self.supplier_id.get(),
            "runtime_storehouse_id": self.runtime_storehouse_id.get(),
            "last_sai_dir": self.last_sai_dir.get(),
            "invoice_date": self.invoice_date.get(),
            "waybill": self.waybill.get(),
        }
        try:
            CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def build_ui(self):
        self.configure(bg="#f6f8ff")

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass

        style.configure("Root.TFrame", background="#f6f8ff")
        style.configure("Startup.TFrame", background="#ffffff")
        style.configure("Shell.TFrame", background="#ffffff", relief="flat")
        style.configure("Card.TFrame", background="#ffffff", relief="flat")
        style.configure("Soft.TFrame", background="#f8fafc", relief="flat")
        style.configure("Log.TFrame", background="#0f172a", relief="flat")

        style.configure("Brand.TLabel", font=("Segoe UI", 20, "bold"), background="#f6f8ff", foreground="#172033")
        style.configure("BrandSub.TLabel", font=("Segoe UI", 10), background="#f6f8ff", foreground="#64748b")
        style.configure("Logo.TLabel", font=("Segoe UI", 14, "bold"), background="#2563eb", foreground="#ffffff", padding=(12, 8))
        style.configure("Title.TLabel", font=("Segoe UI", 24, "bold"), background="#ffffff", foreground="#172033")
        style.configure("Text.TLabel", font=("Segoe UI", 12), background="#ffffff", foreground="#334155")
        style.configure("Muted.TLabel", font=("Segoe UI", 10), background="#ffffff", foreground="#64748b")
        style.configure("Hint.TLabel", font=("Segoe UI", 10), background="#f8fafc", foreground="#475569")
        style.configure("Field.TLabel", font=("Segoe UI", 10, "bold"), background="#ffffff", foreground="#334155")
        style.configure("LogTitle.TLabel", font=("Segoe UI", 11, "bold"), background="#0f172a", foreground="#d1fae5")

        style.configure("Badge.TLabel", font=("Segoe UI", 10, "bold"), background="#eff6ff", foreground="#1d4ed8", padding=(10, 6))
        style.configure("BadgeGreen.TLabel", font=("Segoe UI", 10, "bold"), background="#ecfdf5", foreground="#047857", padding=(10, 6))
        style.configure("BadgeYellow.TLabel", font=("Segoe UI", 10, "bold"), background="#fffbeb", foreground="#b45309", padding=(10, 6))
        style.configure("BadgeRed.TLabel", font=("Segoe UI", 10, "bold"), background="#fef2f2", foreground="#b91c1c", padding=(10, 6))

        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 10))
        style.configure("Secondary.TButton", font=("Segoe UI", 10), padding=(14, 10))
        style.configure("Success.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 10))
        style.configure("Warning.TButton", font=("Segoe UI", 10, "bold"), padding=(14, 10))
        style.configure("Tiny.TButton", font=("Segoe UI", 9), padding=(8, 5))
        style.configure("Guide.TEntry", font=("Segoe UI", 10), padding=(6, 5))

        style.configure("ProgressTodo.TFrame", background="#dbe3ef")
        style.configure("ProgressActive.TFrame", background="#2563eb")
        style.configure("ProgressDone.TFrame", background="#22c55e")

        self.guide_history = []
        self.guide_state = "input"
        self.last_check_result = {}
        self.receipt_adjustments = {}
        self.current_apply_excel_path = ""
        self.guide_error_text = ""
        self.supplier_probe_report_path = ""

        root = ttk.Frame(self, style="Root.TFrame", padding=(0, 0, 0, 0))
        root.pack(fill="both", expand=True)
        self.root_frame = root

        self.startup_full_frame = ttk.Frame(root, style="Startup.TFrame")
        self.guide_state = "input"

        self.main_root_frame = ttk.Frame(root, style="Root.TFrame", padding=(16, 14, 16, 12))
        self.main_root_frame.pack(fill="both", expand=True)

        top = ttk.Frame(self.main_root_frame, style="Root.TFrame")
        self.top_frame = top
        top.pack(fill="x", pady=(0, 12))

        brand = ttk.Frame(top, style="Root.TFrame")
        brand.pack(side="left", fill="x", expand=True)

        ttk.Label(brand, text="SAI", style="Logo.TLabel").pack(side="left", padx=(0, 12))
        brand_text = ttk.Frame(brand, style="Root.TFrame")
        brand_text.pack(side="left", fill="x", expand=True)
        ttk.Label(brand_text, text="SAI — мастер приёмки SIGMA", style="Brand.TLabel").pack(anchor="w")
        ttk.Label(brand_text, text="Приёмка, импорт товаров и заполнение черновика SIGMA", style="BrandSub.TLabel").pack(anchor="w")

        top_buttons = ttk.Frame(top, style="Root.TFrame")
        top_buttons.pack(side="right")
        self.main_menu = Menu(self, tearoff=0)
        self.main_menu.add_checkbutton(
            label="Показывать браузер SIGMA",
            variable=self.browser_visible,
            command=self.toggle_browser_visible,
        )
        self.main_menu.add_separator()
        self.main_menu.add_command(label="Найти свежий SAI-файл", command=lambda: self.auto_select_latest_sai_file(force=True))
        self.main_menu.add_separator()
        self.main_menu.add_command(label="Настройки: открыть private config", command=self.open_private_config)
        self.main_menu.add_command(label="Проверить официальный SIGMA API", command=self.check_sigma_api)
        self.main_menu.add_separator()
        self.main_menu.add_command(label="Обновить каталог SIGMA", command=self.refresh_catalog_cache)
        self.main_menu.add_command(label="Статус SQLite-базы", command=self.show_sqlite_status)
        self.main_menu.add_command(label="История приёмок и цен", command=self.show_price_history_status)
        self.main_menu.add_command(label="Открыть папку SAI", command=self.open_sai_folder)
        self.main_menu.add_command(label="Открыть папку логов", command=self.open_logs_folder)
        self.main_menu.add_separator()
        self.main_menu.add_command(label="Сбросить браузерную сессию SAI", command=self.reset_service_browser)
        self.main_menu.add_command(label="Диагностика черновика", command=self.run_supplier_waybill_probe)
        ttk.Menubutton(top_buttons, text="Меню", menu=self.main_menu, style="Secondary.TButton").pack(side="left", padx=3)

        shell = ttk.Frame(self.main_root_frame, style="Shell.TFrame", padding=(14, 14, 14, 14))
        self.shell_frame = shell
        shell.pack(fill="both", expand=True)

        self.progress_frame = ttk.Frame(shell, style="Shell.TFrame")
        self.progress_frame.pack(fill="x", pady=(0, 12))
        self.progress_segments = []
        for _ in range(10):
            seg = ttk.Frame(self.progress_frame, height=8, style="ProgressTodo.TFrame")
            seg.pack(side="left", fill="x", expand=True, padx=3)
            seg.pack_propagate(False)
            self.progress_segments.append(seg)

        content = ttk.Frame(shell, style="Shell.TFrame")
        content.pack(fill="both", expand=True)

        self.card = ttk.Frame(content, style="Card.TFrame", padding=(26, 22, 26, 18))
        self.card.pack(side="left", fill="both", expand=True, padx=(0, 12))

        self.badge_label = ttk.Label(self.card, text="", style="Badge.TLabel")
        self.badge_label.pack(anchor="w", pady=(0, 12))

        self.card_title = ttk.Label(self.card, text="", style="Title.TLabel", wraplength=650, justify="left")
        self.card_title.pack(fill="x", anchor="w", pady=(0, 8))

        self.card_text = ttk.Label(self.card, text="", style="Text.TLabel", wraplength=680, justify="left")
        self.card_text.pack(fill="x", anchor="w", pady=(0, 10))

        self.card_body = ttk.Frame(self.card, style="Card.TFrame")
        self.card_body.pack(fill="both", expand=True, pady=(4, 4))

        self.card_actions = ttk.Frame(self.card, style="Card.TFrame")
        self.card_actions.pack(fill="x", pady=(12, 0))

        log_panel = ttk.Frame(content, style="Log.TFrame", padding=(12, 12, 12, 12))
        self.log_panel = log_panel
        log_panel.pack(side="right", fill="both", expand=False)
        log_panel.configure(width=360)
        log_panel.pack_propagate(False)

        log_top = ttk.Frame(log_panel, style="Log.TFrame")
        log_top.pack(fill="x", pady=(0, 8))
        ttk.Label(log_top, text="SAI-бот", style="LogTitle.TLabel").pack(side="left")
        ttk.Button(log_top, text="Очистить", command=lambda: self.log.delete("1.0", "end"), style="Tiny.TButton").pack(side="right")

        self.bot_status_label = ttk.Label(log_panel, textvariable=self.last_bot_status, style="LogTitle.TLabel", wraplength=320, justify="left")
        self.bot_status_label.pack(fill="x", pady=(0, 8))

        self.log = Text(
            log_panel,
            height=24,
            width=44,
            wrap="word",
            font=("Consolas", 9),
            bg="#0f172a",
            fg="#d1fae5",
            insertbackground="#ffffff",
            relief="flat",
            padx=8,
            pady=8,
        )
        self.log.pack(side="left", fill="both", expand=True)

        log_scroll = ttk.Scrollbar(log_panel, orient="vertical", command=self.log.yview)
        log_scroll.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=log_scroll.set)

        self.status_label = ttk.Label(self.main_root_frame, textvariable=self.status_var, style="BrandSub.TLabel", wraplength=1000, justify="left")
        self.status_label.pack(fill="x", pady=(10, 0))

        self.log_line(f"SAI GUI {APP_VERSION} готов. Загрузочный экран отключён; рабочее окно открывается сразу.")
        self.log_line("Жёсткое правило: приход заблокирован, пока все позиции не найдены через SIGMA API/локальный кэш.")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.show_guide_step("input", push=False)
        self.animate_bot_status()

    def guide_step_data(self, state):
        result = self.last_check_result or {}
        import_path = result.get("import_path", "")
        barcode_path = result.get("barcode_update_path", "")

        if state == "startup_loading":
            return {
                "idx": 0,
                "badge": "Загрузка",
                "tone": "blue",
                "title": "",
                "text": "",
                "splash": True,
                "actions": [],
            }

        if state == "input":
            return {
                "idx": 0,
                "badge": "Старт",
                "tone": "blue",
                "title": "Подготовьте накладную для ChatGPT",
                "text": "Передайте ChatGPT входную накладную поставщика и укажите наценку: 50%, 60% или 70%.",
                "bullets": [
                    "Если прислали зелёный файл НТВ — передайте его ChatGPT.",
                    "Если накладная бумажная — отсканируйте или сфотографируйте все страницы.",
                    "Свободный привоз и рукописные накладные сначала составляются вручную.",
                ],
                "hint": "Результат этого шага — готовый SAI-файл от ChatGPT.",
                "actions": [
                    ("SAI-файл уже готов", lambda: self.show_guide_step("review"), "primary"),
                ],
            }

        if state == "review":
            return {
                "idx": 1,
                "badge": "Проверка файла",
                "tone": "blue",
                "title": "Проверьте SAI-файл",
                "text": "Откройте файл в Excel и проверьте позиции, которые могут быть важны для приёмки.",
                "bullets": [
                    "Проверьте наименования.",
                    "Единицы измерения: только штука или м. Всё остальное SAI нормализует автоматически.",
                    "Проверьте количество, закупочные и продажные цены.",
                    "Проверьте штрихкоды.",
                ],
                "hint": "После этого SAI будет вводить в SIGMA именно эти данные.",
                "actions": [
                    ("Открыть SAI", lambda: self.show_guide_step("prepare"), "primary"),
                ],
            }

        if state == "prepare":
            return {
                "idx": 2,
                "badge": "SAI",
                "tone": "blue",
                "title": "SAI-файл и поставщик",
                "text": "SAI сам ищет свежий SAI_*.xml или SAI_*.xlsx на Рабочем столе и в Загрузках. Поставщика выберите перед созданием прихода.",
                "fields": True,
                "hint": "Дата берётся из последних 6 цифр имени файла, например SAI_Вертикаль_120526.xlsx → 12.05.2026.",
                "actions": [
                    ("Найти свежий SAI-файл", lambda: self.auto_select_latest_sai_file(force=True), "secondary"),
                    ("Обновить поставщиков", self.refresh_suppliers, "secondary"),
                    ("Создать черновик и проверить товары", self.create_waybill_and_check, "primary"),
                ],
            }

        if state == "checking":
            return {
                "idx": 3,
                "badge": "Проверка",
                "tone": "blue",
                "title": "SAI проверяет товары",
                "text": "Идёт проверка по живому каталогу SIGMA. SAI также подтянет поставщика из черновика прихода.",
                "bullets": [
                    "Если найдутся новые товары — появится файл импорта.",
                    "Если не хватит штрихкодов — SAI попробует добавить их автоматически.",
                    "Если будет конфликт — мастер остановится и покажет, что разобрать вручную.",
                ],
                "hint": "Подробности идут в лог справа.",
                "actions": [],
            }

        if state == "api_error":
            return {
                "idx": 3,
                "badge": "Нужна настройка",
                "tone": "red",
                "title": "API SIGMA не настроен",
                "text": "Для проверки товаров нужен private config с ключом и токеном SIGMA.",
                "bullets": [
                    "Откройте приватный конфиг.",
                    "Заполните данные локально на этом ПК.",
                    "После этого снова запустите проверку.",
                ],
                "actions": [
                    ("Открыть конфиг", self.open_private_config, "primary"),
                    ("Проверить API", self.check_sigma_api, "secondary"),
                ],
            }

        if state == "check_error":
            return {
                "idx": 3,
                "badge": "Ошибка проверки",
                "tone": "red",
                "title": "Проверка товаров не завершилась",
                "text": self.guide_error_text or "SAI получил ошибку во время проверки товаров.",
                "hint": "Подробности есть в логе справа.",
                "actions": [
                    ("Вернуться к данным", lambda: self.show_guide_step("prepare"), "secondary"),
                    ("Проверить снова", self.check_catalog, "primary"),
                ],
            }

        if state == "all_found":
            auto_ok = result.get("barcode_auto_add_success", 0)
            bullets = [
                "Все товары найдены в SIGMA.",
                "Пустых штрихкодов нет.",
                "Конфликтов штрихкодов нет.",
            ]
            if auto_ok:
                bullets.append(f"Недостающие штрихкоды добавлены автоматически: {auto_ok}.")
            return {
                "idx": 5,
                "badge": "Готово",
                "tone": "green",
                "title": "Все позиции найдены",
                "text": "Проверка прошла успешно. Приход можно проверять без записи.",
                "bullets": bullets,
                "hint": self.receipt_fact_hint_text(),
                "actions": [
                    ("Факт пришло / недовоз / возврат", self.open_receipt_fact_window, "secondary"),
                    ("Заполнить приход SIGMA", lambda: self.run_bot(apply=True), "primary"),
                ],
            }

        if state == "import_created":
            return {
                "idx": 4,
                "badge": "Новые товары",
                "tone": "yellow",
                "title": "Создан файл импорта",
                "text": "В SIGMA не найдены новые товары. Их нужно загрузить через импорт, а затем проверить файл снова.",
                "bullets": [
                    "Откройте созданный файл Импорт_...xlsx.",
                    "Загрузите его в SIGMA через импорт товаров.",
                    "Вернитесь сюда и запустите проверку повторно.",
                ],
                "hint": "К заполнению прихода переходить нельзя, пока SAI не напишет, что все позиции найдены.",
                "actions": [
                    ("Открыть импорт", lambda p=import_path: self.open_path(p), "secondary"),
                    ("Импорт выполнен — обновить каталог и проверить", self.check_catalog, "primary"),
                ],
            }

        if state == "manual_barcodes":
            return {
                "idx": 4,
                "badge": "Штрихкоды",
                "tone": "yellow",
                "title": "Нужно вручную добавить ШК",
                "text": "SAI нашёл существующие товары, но не все недостающие штрихкоды удалось добавить автоматически.",
                "bullets": [
                    "Откройте файл ШК_к_существующим_товарам_...",
                    "Добавьте указанные ШК к существующим карточкам SIGMA.",
                    "Не импортируйте эти позиции как новые товары.",
                ],
                "hint": "После ручного исправления запустите проверку снова.",
                "actions": [
                    ("Открыть файл ШК", lambda p=barcode_path: self.open_path(p), "secondary"),
                    ("Я исправил — проверить снова", self.check_catalog, "primary"),
                ],
            }

        if state == "conflict":
            return {
                "idx": 4,
                "badge": "Стоп",
                "tone": "red",
                "title": "Конфликт штрихкодов",
                "text": "Штрихкоды из одной строки уже привязаны к разным товарам SIGMA. Автоматически исправлять это опасно.",
                "bullets": [
                    "Откройте SAI-файл и строку, указанную в логе.",
                    "Проверьте, не попали ли в одну строку ШК от разных товаров.",
                    "Исправьте SAI-файл или карточки SIGMA и проверьте снова.",
                ],
                "hint": "SAI специально ставит СТОП, чтобы не склеить разные товары.",
                "actions": [
                    ("Открыть файл ШК/конфликтов", lambda p=barcode_path: self.open_path(p), "secondary"),
                    ("После исправления — проверить снова", self.check_catalog, "primary"),
                ],
            }

        if state == "no_barcode":
            return {
                "idx": 4,
                "badge": "Стоп",
                "tone": "red",
                "title": "Есть строки без штрихкодов",
                "text": "В SAI-файле есть строки без ШК. Приход заблокирован.",
                "bullets": [
                    "Откройте SAI-файл.",
                    "Заполните ШК в указанных строках.",
                    "Сохраните файл и проверьте снова.",
                ],
                "actions": [
                    ("Открыть SAI-файл", lambda: self.open_path(self.sai_path.get()), "secondary"),
                    ("После исправления — проверить снова", self.check_catalog, "primary"),
                ],
            }

        if state == "suppliers_loading":
            return {
                "idx": 2,
                "badge": "Поставщики",
                "tone": "blue",
                "title": "Загружаю поставщиков из SIGMA",
                "text": "SAI открывает SIGMA, проверяет вход и получает список поставщиков.",
                "hint": "Если появится приветственное окно SIGMA — SAI попробует закрыть его сам.",
                "actions": [],
            }

        if state == "suppliers_loaded":
            return {
                "idx": 2,
                "badge": "Поставщики готовы",
                "tone": "green",
                "title": "Список поставщиков загружен",
                "text": "Теперь выберите поставщика из выпадающего списка и создайте черновик прихода.",
                "fields": True,
                "actions": [
                    ("Создать черновик и проверить товары", self.create_waybill_and_check, "primary"),
                ],
            }

        if state == "creating_waybill":
            return {
                "idx": 3,
                "badge": "Черновик",
                "tone": "blue",
                "title": "SAI создаёт черновик прихода",
                "text": "SAI создаёт новый черновик прихода в SIGMA по выбранному поставщику.",
                "bullets": [
                    "Дата берётся из имени SAI-файла.",
                    "Номер прихода генерирует SIGMA.",
                    "После создания SAI сам запустит проверку товаров.",
                ],
                "hint": "Подробности идут справа.",
                "actions": [],
            }

        if state == "waybill_error":
            return {
                "idx": 3,
                "badge": "Ошибка черновика",
                "tone": "red",
                "title": "SAI не смог создать черновик прихода",
                "text": self.guide_error_text or "Создание черновика завершилось с ошибкой.",
                "hint": "Подробности есть справа. Часто помогает повторный вход в SIGMA или обновление списка поставщиков.",
                "actions": [
                    ("Обновить поставщиков", self.refresh_suppliers, "secondary"),
                    ("Повторить создание", self.create_waybill_and_check, "primary"),
                ],
            }

        if state == "supplier_probe":
            return {
                "idx": 3,
                "badge": "Диагностика",
                "tone": "blue",
                "title": "Поймать создание черновика прихода",
                "text": "SAI открыл SIGMA и записывает сетевые запросы. Создайте один тестовый черновик прихода вручную.",
                "bullets": [
                    "В открывшемся окне SIGMA создайте приход так, как обычно.",
                    "Выберите тестового поставщика.",
                    "После открытия черновика ничего больше добавлять не нужно.",
                    "SAI сохранит отчёт, по которому мы встроим создание черновика прямо в SAI.",
                ],
                "hint": "Диагностика длится несколько минут. Подробности идут справа.",
                "actions": [],
            }

        if state == "supplier_probe_done":
            return {
                "idx": 3,
                "badge": "Диагностика готова",
                "tone": "green",
                "title": "Отчёт создания черновика сохранён",
                "text": "SAI записал сетевые запросы SIGMA. Этот файл нужен мне, чтобы встроить выбор поставщика и автосоздание черновика.",
                "bullets": [
                    "Пришлите мне JSON-отчёт из лога.",
                    "Если в отчёте есть запрос создания черновика, следующим патчем сделаем выпадающий список поставщиков.",
                    "Пока это только диагностика, черновики SAI сам ещё не создаёт.",
                ],
                "hint": f"Отчёт: {self.supplier_probe_report_path or 'путь будет указан в логе'}",
                "actions": [
                    ("Открыть отчёт", lambda: self.open_path(self.supplier_probe_report_path), "secondary"),
                    ("Вернуться к SAI", lambda: self.show_guide_step("prepare"), "primary"),
                ],
            }

        if state == "supplier_probe_error":
            return {
                "idx": 3,
                "badge": "Ошибка диагностики",
                "tone": "red",
                "title": "Диагностика создания черновика не завершилась",
                "text": self.guide_error_text or "SAI не смог выполнить диагностику.",
                "hint": "Подробности есть в логе справа.",
                "actions": [
                    ("Повторить диагностику", self.run_supplier_waybill_probe, "primary"),
                    ("Вернуться", lambda: self.show_guide_step("prepare"), "secondary"),
                ],
            }

        if state == "dryrun_running":
            return {
                "idx": 6,
                "badge": "Без записи",
                "tone": "blue",
                "title": "SAI проверяет SIGMA без записи",
                "text": "Идёт безопасный прогон. Черновик прихода пока не меняется.",
                "hint": "Если ошибок нет, мастер предложит реальное заполнение прихода.",
                "actions": [],
            }

        if state == "dryrun_ok":
            return {
                "idx": 6,
                "badge": "Проверка пройдена",
                "tone": "green",
                "title": "Проверка без записи завершена",
                "text": "SAI смог найти товары и подготовиться к заполнению. Теперь можно заполнять черновик.",
                "bullets": [
                    "Следующее действие уже изменит черновик прихода.",
                    "SAI добавит товары, количество, закупочные и продажные цены.",
                ],
                "actions": [
                    ("Заполнить приход SIGMA", lambda: self.run_bot(apply=True), "primary"),
                ],
            }

        if state == "apply_running":
            return {
                "idx": 7,
                "badge": "Заполнение",
                "tone": "blue",
                "title": "SAI заполняет приход",
                "text": "Идёт реальная запись в черновик SIGMA. Не закрывайте окно до завершения.",
                "hint": "SAI не проводит приход, он только заполняет черновик.",
                "actions": [],
            }

        if state == "bot_error":
            return {
                "idx": 7,
                "badge": "Ошибка",
                "tone": "red",
                "title": "Бот завершился с ошибкой",
                "text": self.guide_error_text or "Посмотрите подробности в логе справа.",
                "actions": [
                    ("Вернуться к проверке", lambda: self.show_guide_step("all_found"), "secondary"),
                    ("Повторить без записи", lambda: self.run_bot(apply=False), "primary"),
                ],
            }

        if state == "ndp":
            return {
                "idx": 8,
                "badge": "Проверка черновика",
                "tone": "green",
                "title": "Приход заполнен",
                "text": "Откройте черновик в SIGMA и проверьте товары, количество, закупочные и продажные цены.",
                "bullets": [
                    "SAI уже заполнил черновик.",
                    "Проведение прихода остаётся за человеком.",
                    "После проверки можно создать накладную для продавцов.",
                ],
                "actions": [
                    ("Сохранить накладную", lambda: self.create_ndp(print_after=False), "primary"),
                    ("СРАЗУ ПЕЧАТАТЬ", lambda: self.create_ndp(print_after=True), "secondary"),
                ],
            }

        if state == "finish":
            return {
                "idx": 9,
                "badge": "Готово",
                "tone": "green",
                "title": "Привоз обработан",
                "text": "Накладная для продавцов создана. Проверьте, что приход проведён по обычным правилам магазина.",
                "bullets": [
                    "Новые товары импортированы.",
                    "Недостающие ШК добавлены.",
                    "Черновик прихода заполнен.",
                    "НДП сохранена или отправлена на печать.",
                ],
                "actions": [
                    ("Начать новый привоз", lambda: self.show_guide_step("input"), "primary"),
                    ("Закрыть SAI", self.on_close, "secondary"),
                ],
            }

        return self.guide_step_data("input")

    def show_guide_step(self, state, push=True):
        if push and getattr(self, "guide_state", None) and self.guide_state != state:
            self.guide_history.append(self.guide_state)
        self.guide_state = state
        self.render_guide_state()

    def go_guide_back(self):
        if self.guide_history:
            self.guide_state = self.guide_history.pop()
            self.render_guide_state()
        else:
            self.show_guide_step("input", push=False)


    def set_startup_progress(self, percent, stage=None, tip=None):
        try:
            self.startup_progress_target = max(0.0, min(100.0, float(percent)))
        except Exception:
            pass
        if stage:
            self.startup_stage_text = safe_str(stage)
        if tip:
            self.startup_tip_text = safe_str(tip)
        if getattr(self, "guide_state", "") == "startup_loading":
            self.update_startup_splash()

    def render_startup_splash(self, parent):
        """Pure startup screen: only title, version, warmup hint, and animated three dots."""
        for child in parent.winfo_children():
            child.destroy()

        self.splash_canvas = Canvas(
            parent,
            bg="#ffffff",
            highlightthickness=0,
            bd=0,
        )
        self.splash_canvas.pack(fill="both", expand=True)
        c = self.splash_canvas
        self.splash_items = {}

        self.splash_items["title"] = c.create_text(
            0, 0,
            anchor="center",
            text="SAI — мастер приёмки SIGMA",
            fill="#172033",
            font=("Segoe UI", 25, "bold"),
        )
        self.splash_items["version"] = c.create_text(
            0, 0,
            anchor="center",
            text=APP_VERSION,
            fill="#94a3b8",
            font=("Segoe UI", 10),
        )
        self.splash_items["warmup"] = c.create_text(
            0, 0,
            anchor="center",
            text="SAI прогревает SIGMA: сессия, поставщики, каталог",
            fill="#64748b",
            font=("Segoe UI", 10),
        )
        self.splash_items["dots"] = []
        for _ in range(3):
            dot = c.create_oval(-10, -10, -2, -2, fill="#cbd5e1", outline="")
            self.splash_items["dots"].append(dot)

        c.bind("<Configure>", lambda _event: self.update_startup_splash())
        self.update_startup_splash()

    def update_startup_splash(self):
        c = getattr(self, "splash_canvas", None)
        if not c or not getattr(self, "splash_items", None):
            return
        try:
            w = max(1, c.winfo_width())
            h = max(1, c.winfo_height())
            cx = w / 2
            cy = h / 2

            c.coords(self.splash_items["title"], cx, cy - 54)
            c.coords(self.splash_items["version"], cx, cy - 18)
            c.coords(self.splash_items["warmup"], cx, cy + 48)

            phase = int(getattr(self, "splash_phase", 0))
            colors = ["#cbd5e1", "#94a3b8", "#2563eb"]
            xs = (cx - 22, cx, cx + 22)
            y = cy + 20
            for i, dot in enumerate(self.splash_items.get("dots", [])):
                level = (phase // 4 + i) % 3
                r = 4 + (2 if level == 2 else 0)
                c.coords(dot, xs[i] - r, y - r, xs[i] + r, y + r)
                c.itemconfigure(dot, fill=colors[level])
        except Exception:
            pass

    def animate_startup_splash(self):
        try:
            self.splash_phase = int(getattr(self, "splash_phase", 0)) + 1
            if getattr(self, "guide_state", "") == "startup_loading":
                self.update_startup_splash()
        except Exception:
            pass
        try:
            self.after(80, self.animate_startup_splash)
        except Exception:
            pass

    def render_progress(self, idx):
        for i, seg in enumerate(getattr(self, "progress_segments", [])):
            if i < idx:
                seg.configure(style="ProgressDone.TFrame")
            elif i == idx:
                seg.configure(style="ProgressActive.TFrame")
            else:
                seg.configure(style="ProgressTodo.TFrame")

    def badge_style_for_tone(self, tone):
        if tone == "green":
            return "BadgeGreen.TLabel"
        if tone == "yellow":
            return "BadgeYellow.TLabel"
        if tone == "red":
            return "BadgeRed.TLabel"
        return "Badge.TLabel"

    def render_guide_state(self):
        data = self.guide_step_data(self.guide_state)

        if data.get("splash"):
            self.set_startup_chrome(True)
            self.render_startup_splash(self.startup_full_frame)
            return

        self.set_startup_chrome(False)
        self.render_progress(int(data.get("idx", 0)))

        self.badge_label.configure(text=data.get("badge", ""), style=self.badge_style_for_tone(data.get("tone")))
        self.card_title.configure(text=data.get("title", ""))
        self.card_text.configure(text=data.get("text", ""))

        for child in self.card_body.winfo_children():
            child.destroy()
        for child in self.card_actions.winfo_children():
            child.destroy()

        if data.get("fields"):
            self.render_prepare_fields(self.card_body)

        for bullet in data.get("bullets", []) or []:
            row = ttk.Frame(self.card_body, style="Card.TFrame")
            row.pack(fill="x", anchor="w", pady=4)
            ttk.Label(row, text="✓", style="BadgeGreen.TLabel", width=3).pack(side="left", anchor="n", padx=(0, 8))
            ttk.Label(row, text=bullet, style="Text.TLabel", wraplength=620, justify="left").pack(side="left", fill="x", expand=True, anchor="w")

        if data.get("hint"):
            hint_frame = ttk.Frame(self.card_body, style="Soft.TFrame", padding=(12, 10, 12, 10))
            hint_frame.pack(fill="x", pady=(14, 0))
            ttk.Label(hint_frame, text=data.get("hint"), style="Hint.TLabel", wraplength=620, justify="left").pack(fill="x", anchor="w")

        actions = data.get("actions") or []
        if self.guide_history and self.guide_state not in ("input", "checking", "dryrun_running", "apply_running"):
            ttk.Button(self.card_actions, text="Назад", command=self.go_guide_back, style="Secondary.TButton").pack(side="left", padx=(0, 8))

        if not actions:
            ttk.Label(self.card_actions, text="SAI работает… подробности справа в логе.", style="Muted.TLabel").pack(side="left", anchor="w")
        else:
            for label, command, kind in actions:
                style = "Primary.TButton"
                if kind == "secondary":
                    style = "Secondary.TButton"
                elif kind == "success":
                    style = "Success.TButton"
                elif kind in ("warning", "danger"):
                    style = "Warning.TButton"
                ttk.Button(self.card_actions, text=label, command=command, style=style).pack(side="left", padx=(0, 8), pady=2)

    def render_prepare_fields(self, parent):
        self.add_guide_file_row(parent, "SAI-файл", self.sai_path, self.choose_sai)

        file_hint = ttk.Frame(parent, style="Card.TFrame")
        file_hint.pack(fill="x", pady=(0, 6))
        ttk.Label(file_hint, text="", style="Field.TLabel", width=16).pack(side="left")
        entry = get_sai_file_history_entry(self.sai_path.get()) if self.sai_path.get() else {}
        status = format_file_history_status(entry)
        hint_text = "SAI ищет свежий SAI_*.xml или SAI_*.xlsx на Рабочем столе и в Загрузках."
        if status:
            hint_text += f" Этот файл уже был в работе: {status}."
        ttk.Label(file_hint, text=hint_text, style="Muted.TLabel", wraplength=620, justify="left").pack(side="left", fill="x", expand=True)

        # Скрытая дата: берётся из имени файла и сохраняется в invoice_date для старой логики НДП/импорта.
        file_date = self.invoice_date_from_sai_file()
        if file_date:
            self.invoice_date.set(file_date)

        date_frame = ttk.Frame(parent, style="Card.TFrame")
        date_frame.pack(fill="x", pady=6)
        ttk.Label(date_frame, text="Дата", style="Field.TLabel", width=16).pack(side="left")
        ttk.Label(date_frame, text=file_date or "будет взята из имени SAI-файла", style="Muted.TLabel", wraplength=520, justify="left").pack(side="left", fill="x", expand=True)

        supplier_frame = ttk.Frame(parent, style="Card.TFrame")
        supplier_frame.pack(fill="x", pady=6)
        ttk.Label(supplier_frame, text="Поставщик", style="Field.TLabel", width=16).pack(side="left")

        names = [safe_str(x.get("name")) for x in getattr(self, "suppliers", []) if safe_str(x.get("name"))]
        self.supplier_combo = ttk.Combobox(
            supplier_frame,
            textvariable=self.supplier_choice,
            values=names,
            state="readonly" if names else "normal",
            font=("Segoe UI", 10),
        )
        self.supplier_combo.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.supplier_combo.bind("<<ComboboxSelected>>", self.on_supplier_selected)

        ttk.Button(supplier_frame, text="Обновить", command=self.refresh_suppliers, style="Secondary.TButton").pack(side="right")

        draft_frame = ttk.Frame(parent, style="Card.TFrame")
        draft_frame.pack(fill="x", pady=6)
        ttk.Label(draft_frame, text="Черновик", style="Field.TLabel", width=16).pack(side="left")
        draft_text = normalize_waybill(self.waybill.get()) or "будет создан автоматически"
        ttk.Label(draft_frame, text=draft_text, style="Muted.TLabel", wraplength=520, justify="left").pack(side="left", fill="x", expand=True)


    def add_guide_file_row(self, parent, label, var, command):
        frame = ttk.Frame(parent, style="Card.TFrame")
        frame.pack(fill="x", pady=6)
        ttk.Label(frame, text=label, style="Field.TLabel", width=16).pack(side="left")
        ttk.Entry(frame, textvariable=var, style="Guide.TEntry").pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(frame, text="Выбрать другой", command=command, style="Secondary.TButton").pack(side="right")

    def add_guide_entry_row(self, parent, label, var):
        frame = ttk.Frame(parent, style="Card.TFrame")
        frame.pack(fill="x", pady=6)
        ttk.Label(frame, text=label, style="Field.TLabel", width=16).pack(side="left")
        ttk.Entry(frame, textvariable=var, style="Guide.TEntry").pack(side="left", fill="x", expand=True)

    def open_path(self, path):
        path = safe_str(path)
        if not path:
            messagebox.showinfo("SAI", "Файл пока не создан.")
            return
        try:
            p = Path(path)
            if not p.exists():
                messagebox.showwarning("SAI", f"Файл не найден:\n{path}")
                return
            if hasattr(os, "startfile"):
                os.startfile(str(p))
            else:
                messagebox.showinfo("SAI", str(p))
        except Exception as e:
            messagebox.showerror("SAI", str(e))


    def friendly_status_from_log(self, text):
        s = safe_str(text)
        low = s.lower()
        if "поставщики" in low and ("загруж" in low or "список" in low):
            return "Загружаю поставщиков…"
        if "создаю черновик прихода" in low:
            return "Создаю черновик прихода…"
        if "черновик прихода создан" in low:
            return "Черновик создан"
        if "проверяю sai-файл" in low or "выгрузка завершена" in low:
            return "Проверяю накладную…"
        if "sigma api products: старт" in low or ("страница" in low and "товаров" in low):
            return "Проверяю товары в SIGMA…"
        if "авто-шк" in low or "добавить шк" in low:
            return "Проверяю штрихкоды…"
        if "запускаю sigma bot" in low or "запускаю api-first" in low:
            return "Заполняю приход через API…"
        if "бот завершил работу" in low or "ок:" in low:
            return "Готово"
        if "ошибка" in low or "traceback" in low:
            return "Нужна проверка"
        if "login" in low or "открываю sigma" in low or "вхожу" in low:
            return "Вхожу в SIGMA…"
        if "служебный браузер закрыт" in low:
            return "Готовлю следующий шаг…"
        return ""

    def log_line(self, text):
        text = safe_str(text)
        ts = dt.datetime.now().strftime("%H:%M:%S")
        try:
            status = self.friendly_status_from_log(text)
            if status:
                self.last_bot_status.set(status)
        except Exception:
            pass
        try:
            self.log.insert("end", f"[{ts}] {text}\n")
            self.log.see("end")
        except Exception:
            pass

    def animate_bot_status(self):
        try:
            base = safe_str(self.last_bot_status.get()) or "SAI ждёт действия"
            base = base.replace("● ", "").replace("○ ", "")
            if bool(getattr(self, "running", False)):
                dot = "●" if self.breath_on else "○"
                if "…" not in base and not base.endswith("..."):
                    base = base + "…"
                self.bot_status_label.configure(foreground="#bbf7d0" if self.breath_on else "#d1fae5")
                self.last_bot_status.set(f"{dot} {base}")
            else:
                self.bot_status_label.configure(foreground="#d1fae5")
                self.last_bot_status.set(base)
            self.breath_on = not self.breath_on
        except Exception:
            pass
        try:
            self.after(750, self.animate_bot_status)
        except Exception:
            pass



    def set_sai_file_path(self, path, source="manual"):
        path = safe_str(path)
        if not path:
            return False
        p = Path(path)
        if p.suffix.lower() in (".xlsx", ".xlsm"):
            package = p.with_suffix(".sai")
            xml = p.with_suffix(".xml")
            if package.exists() and package.is_file():
                p = package
            elif xml.exists() and xml.is_file():
                p = xml
        if not p.exists():
            return False

        old_path = safe_str(self.sai_path.get())
        self.sai_path.set(str(p))
        self.last_sai_dir.set(str(p.parent))
        self.catalog_ready = False

        file_date = self.invoice_date_from_sai_file()
        if file_date:
            self.invoice_date.set(file_date)

        self.save_config()

        entry = get_sai_file_history_entry(p)
        status = format_file_history_status(entry)
        if source == "auto":
            if old_path != str(p):
                self.log_line(f"SAI сам нашёл свежий файл: {p.name}")
            if status:
                self.log_line(f"ВНИМАНИЕ: этот SAI-файл уже использовался: {status}")
        else:
            self.log_line(f"Выбран SAI-файл: {p.name}")
            if status:
                self.log_line(f"ВНИМАНИЕ: этот SAI-файл уже использовался: {status}")

        try:
            if getattr(self, "guide_state", "") == "prepare":
                self.render_guide_state()
        except Exception:
            pass
        return True

    def auto_select_latest_sai_file(self, force=False):
        latest = find_latest_sai_file(extra_dir=self.last_sai_dir.get())
        if not latest:
            if force:
                messagebox.showinfo("SAI", "Не нашёл SAI_*.sai, SAI_*.xml или SAI_*.xlsx на Рабочем столе и в Загрузках.")
            return

        current = Path(self.sai_path.get()) if self.sai_path.get() else None
        choose = force or not current or not current.exists()
        if current and current.exists() and not choose:
            try:
                choose = latest.stat().st_mtime > current.stat().st_mtime
            except Exception:
                choose = True

        if choose:
            self.set_sai_file_path(latest, source="auto")
        elif force:
            self.log_line(f"Свежий SAI-файл уже выбран: {current.name}")

    def record_current_sai_file_status(self, status, extra=None):
        path = safe_str(self.sai_path.get())
        if not path or not Path(path).exists():
            return
        info = file_fingerprint(path)
        key = sai_file_history_key(info)
        data = load_sai_file_history()
        files = data.setdefault("files", {})
        entry = dict(files.get(key) or {})
        entry.update(info)
        entry["status"] = safe_str(status)
        entry["updated_at"] = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry["supplier"] = safe_str(self.supplier_choice.get() or self.supplier.get())
        entry["waybill"] = normalize_waybill(self.waybill.get())
        if isinstance(extra, dict):
            entry.update(extra)
        if status in ("проверен: все позиции найдены", "приход заполнен"):
            entry.pop("import_path", None)
        files[key] = entry
        save_sai_file_history(data)


    def choose_sai(self):
        p = filedialog.askopenfilename(title="Выбери SAI-файл", filetypes=[("SAI Package", "*.sai"), ("Все SAI-файлы", "*.sai *.xml *.xlsx *.xlsm"), ("Старый SAI XML", "*.xml"), ("Excel", "*.xlsx *.xlsm"), ("Все файлы", "*.*")])
        if p:
            self.set_sai_file_path(p, source="manual")

    def choose_catalog(self):
        p = filedialog.askopenfilename(title="Выбери Каталог.xlsx", filetypes=[("Excel", "*.xlsx *.xlsm"), ("All files", "*.*")])
        if p:
            self.catalog_path.set(p)
            self.catalog_ready = False
            self.save_config()

    def validate_basic(self, need_catalog=False, need_waybill=False):
        if not self.sai_path.get() or not Path(self.sai_path.get()).exists():
            messagebox.showerror("SAI", "Выбери существующий SAI-файл.")
            return False
        if need_catalog and (not self.catalog_path.get() or not Path(self.catalog_path.get()).exists()):
            messagebox.showerror("SAI", "Резервный Каталог.xlsx не выбран.")
            return False
        if need_waybill and not normalize_waybill(self.waybill.get()):
            messagebox.showerror("SAI", "Черновик прихода ещё не создан.")
            return False
        if not self.invoice_date.get().strip():
            messagebox.showerror("SAI", "Не смог определить дату накладной из имени SAI-файла.")
            return False
        return True

    def set_ndp_actions_enabled(self, enabled: bool):
        state = "normal" if enabled else "disabled"
        try:
            self.btn_save_ndp.configure(state=state)
            self.btn_print_ndp.configure(state=state)
        except Exception:
            pass

    def hide_ndp_actions(self):
        self.set_ndp_actions_enabled(False)

    def show_ndp_actions(self):
        self.set_ndp_actions_enabled(True)
        try:
            self.show_guide_step("ndp")
        except Exception:
            pass

    def build_bot_base_args(self, sheet_name=None):
        private_cfg = load_private_config()
        storehouse_id = (
            safe_str(self.runtime_storehouse_id.get())
            or safe_str(private_cfg.get("storehouse_id"))
            or DEFAULT_STOREHOUSE_ID
        )
        args = [
            sys.executable,
            "-u",
            str(BOT_SCRIPT),
            "--excel", self.sai_path.get(),
            "--sheet", sheet_name or "Для робота SIGMA",
            "--waybill-id", normalize_waybill(self.waybill.get()),
            "--storehouse-id", storehouse_id,
            "--user-data-dir", str(PROFILE_DIR),
            "--limit", "0",
        ]
        args += self.browser_visibility_args()
        return append_sigma_auth_args(args, private_cfg)

    def build_api_first_args(self, sheet_name=None):
        private_cfg = load_private_config()
        storehouse_id = (
            safe_str(self.runtime_storehouse_id.get())
            or safe_str(private_cfg.get("storehouse_id"))
            or DEFAULT_STOREHOUSE_ID
        )
        excel_for_apply = safe_str(getattr(self, "current_apply_excel_path", "")) or self.sai_path.get()
        args = [
            sys.executable,
            "-u",
            str(API_FIRST_SCRIPT),
            "--excel", excel_for_apply,
            "--sheet", sheet_name or "Для робота SIGMA",
            "--waybill-id", normalize_waybill(self.waybill.get()),
            "--storehouse-id", storehouse_id,
            "--user-data-dir", str(PROFILE_DIR),
            "--price-policy", "max",
        ]
        args += self.browser_visibility_args()
        if bool(private_cfg.get("apply_live_preflight", False)):
            args.append("--live-preflight")
        return append_sigma_auth_args(args, private_cfg)

    def parse_waybill_metadata_line(self, line):
        marker = "SAI_WAYBILL_METADATA_JSON:"
        if marker not in line:
            return None
        raw = line.split(marker, 1)[1].strip()
        try:
            return json.loads(raw)
        except Exception:
            return None

    def supplier_value_for_files(self):
        s = safe_str(self.supplier.get())
        if not s or s.lower().startswith("автоматически") or s.lower() == "не выбран":
            return "Поставщик"
        return s

    def run_metadata_probe_sync(self, sheet_name):
        """
        Opens SIGMA draft through the bot, reads supplier from waybill JSON,
        forwards bot log lines to GUI log, and returns supplier name or "".
        """
        args = self.build_bot_base_args(sheet_name=sheet_name)
        args.append("--metadata-only")

        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        env["PYTHONUNBUFFERED"] = "1"

        self.queue.put(("log", "Пытаюсь автоматически получить поставщика из черновика прихода..."))
        supplier_name = ""

        proc = subprocess.Popen(
            args,
            cwd=str(APP_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
            env=env,
        )

        for line in proc.stdout:
            line = line.rstrip()
            meta = self.parse_waybill_metadata_line(line)
            if meta is not None:
                supplier_name = safe_str(meta.get("supplier_name"))
                if supplier_name:
                    self.queue.put(("supplier_detected", supplier_name))
                continue
            self.queue.put(("log", line))

        code = proc.wait()
        if code != 0:
            self.queue.put(("log", f"Автополучение поставщика завершилось с кодом {code}."))
        return supplier_name

    def check_catalog(self):
        self.hide_ndp_actions()
        if not self.validate_basic(need_catalog=False, need_waybill=True):
            return
        self.show_guide_step("checking")
        self.save_config()
        self.catalog_ready = False

        try:
            sheet_name, _ = load_sai_rows(self.sai_path.get())
        except Exception as e:
            messagebox.showerror("SAI", f"Не могу прочитать SAI-файл: {e}")
            return

        private_cfg = load_private_config()
        has_api = bool(safe_str(private_cfg.get("sigma_company_key")) and safe_str(private_cfg.get("sigma_api_token")))

        if not has_api:
            self.status_var.set("Не настроен API SIGMA.")
            self.log_line("API SIGMA не настроен: заполни sigma_company_key и sigma_api_token в приватном конфиге.")
            self.show_guide_step("api_error")
            messagebox.showerror(
                "SAI",
                "Для проверки товаров нужен API SIGMA в user_data/sai_private_config.json."
            )
            return

        self.running = True
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.status_var.set("Проверяю товары через SIGMA API...")
        if getattr(self, "catalog_refreshed_this_session", False):
            self.log_line(f"Каталог текущей сессии уже обновлён: {self.catalog_session_refreshed_at or 'сейчас'}. Проверка может использовать SQLite.")
        else:
            self.log_line("Каталог ещё не обновлялся в этой сессии — проверка принудительно обновит SIGMA перед решением.")
        self.log_line("Проверяю SAI-файл через каталог SIGMA/SQLite текущей сессии...")
        private_cfg = dict(private_cfg)
        private_cfg["_catalog_refreshed_this_session"] = bool(getattr(self, "catalog_refreshed_this_session", False))
        threading.Thread(target=self._check_products_worker, args=("api", private_cfg, sheet_name), daemon=True).start()

    def _check_products_worker(self, mode, private_cfg, sheet_name):
        try:
            # v1.14 API-first:
            # supplier is already selected/known from the created draft, so do not launch
            # an extra browser just to read waybill metadata.
            supplier_name = self.supplier_value_for_files()
            self.queue.put(("log", f"Поставщик для Импорта/НДП: {supplier_name}"))

            result = create_import_file_from_sigma_api(
                self.sai_path.get(),
                supplier_name,
                self.invoice_date.get(),
                private_cfg,
                log_callback=lambda msg: self.queue.put(("log", msg)),
            )

            if bool(private_cfg.get("sqlite_history_enabled", True)):
                try:
                    receipt_id = sai_db.save_receipt_check(
                        self.sai_path.get(),
                        supplier_name,
                        self.invoice_date.get(),
                        result.get("source_rows") or [],
                        result,
                    )
                    self.queue.put(("log", f"SQLite: проверка приёмки сохранена в sai.db, запись #{receipt_id}"))
                except Exception as db_error:
                    self.queue.put(("log", f"SQLite: не смог сохранить историю проверки, продолжаю без неё — {str(db_error)[:180]}"))

            self.queue.put(("product_check_result", result))
        except Exception as e:
            self.queue.put(("product_check_error", str(e)))

    def handle_product_check_result(self, result):
        self.running = False
        self.run_started_at = None
        self.last_check_result = result or {}
        if bool(result.get("catalog_force_refreshed")):
            self.catalog_refreshed_this_session = True
            self.catalog_session_refreshed_at = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mode = result.get("mode") or "проверка"
        for line in result.get("catalog_debug", []):
            self.log_line(f"{mode}: {line}")

        self.log_line("Источник проверки: SIGMA API")
        self.log_line(f"В SIGMA найдено ШК: {result['catalog_count']}")
        self.log_line(f"Строк в SAI: {result['total']}")
        self.log_line(f"Найдено полностью: {result.get('ok_full', result.get('ok', 0))}")
        self.log_line(f"Найдено частично, нужно добавить ШК: {result.get('barcode_add_needed', 0)}")
        self.log_line(f"Конфликтов ШК: {result.get('conflicts', 0)}")
        self.log_line(f"Авто-добавление ШК: попыток {result.get('barcode_auto_add_attempted', 0)}, успешно {result.get('barcode_auto_add_success', 0)}, ошибок {result.get('barcode_auto_add_failed', 0)}")
        self.log_line(f"Новых к импорту: {result['missing']}")
        self.log_line(f"Без ШК: {result['no_barcode']}")

        if result.get("barcode_auto_add_report_path"):
            self.log_line(f"Отчёт авто-добавления ШК: {result['barcode_auto_add_report_path']}")

        if result.get("barcode_update_path"):
            self.log_line(f"Создан файл по недостающим/конфликтным ШК: {result['barcode_update_path']}")

        if result.get("import_path"):
            self.log_line(f"Создан Импорт новых товаров: {result['import_path']}")

        if result["no_barcode"] > 0:
            self.catalog_ready = False
            self.record_current_sai_file_status("стоп: строки без ШК")
            self.status_var.set(f"СТОП: в SAI-файле {result['no_barcode']} строк без ШК. Заполни ШК и проверь снова.")
            self.log_line("СТОП: есть строки без ШК. Импорт/приход заблокированы.")
            for r in result["no_barcode_rows"][:15]:
                self.log_line(f"  без ШК: Excel row {r['excel_row']} — {r['name']}")
            if result["no_barcode"] > 15:
                self.log_line(f"  ...ещё {result['no_barcode'] - 15}")
            self.show_guide_step("no_barcode")
            return

        if result.get("conflicts", 0) > 0:
            self.catalog_ready = False
            self.record_current_sai_file_status("стоп: конфликты ШК")
            self.status_var.set(f"СТОП: {result.get('conflicts', 0)} конфликтов ШК. Нельзя автоматически склеивать разные товары.")
            self.log_line("СТОП: часть ШК из одной строки уже привязана к разным товарам SIGMA.")
            for item in result.get("conflict_rows", [])[:10]:
                row = item["row"]
                self.log_line(f"  конфликт: Excel row {row['excel_row']} — {row['name']} — {', '.join(item.get('codes', []))}")
            self.show_guide_step("conflict")
            return

        if result.get("barcode_add_needed", 0) > 0:
            self.catalog_ready = False
            self.record_current_sai_file_status("стоп: ручное добавление ШК")
            self.status_var.set(
                f"НЕ ГОТОВО: {result.get('barcode_add_needed', 0)} позиций требуют добавления ШК к существующим товарам."
            )
            self.log_line("СТОП: эти позиции НЕ импортируются дублями. Авто-добавление не сработало для всех ШК, нужна ручная проверка и повторная проверка.")
            for item in result.get("barcode_add_rows", [])[:15]:
                row = item["row"]
                product = item["product"]
                self.log_line(
                    f"  добавить ШК: Excel row {row['excel_row']} — {row['name']} | "
                    f"товар SIGMA: {product.get('name') or product.get('id')} | "
                    f"добавить: {', '.join(item.get('missing_codes', []))}"
                )
            if result.get("barcode_add_needed", 0) > 15:
                self.log_line(f"  ...ещё {result.get('barcode_add_needed', 0) - 15}")
            self.show_guide_step("manual_barcodes")
            return

        if result["missing"] > 0:
            self.catalog_ready = False
            self.record_current_sai_file_status("создан импорт новых товаров", {"import_path": result.get("import_path", "")})
            self.status_var.set(f"НЕ ГОТОВО: {result['missing']} товаров не найдены. Создан файл импорта. После импорта в SIGMA нажмите кнопку «Импорт выполнен — обновить каталог и проверить».")
            self.log_line("СТОП: есть товары, которых нет в SIGMA.")
            for r in result["missing_rows"][:15]:
                self.log_line(f"  импорт: Excel row {r['excel_row']} — {r['name']} — {', '.join(r['barcodes'])}")
            if result["missing"] > 15:
                self.log_line(f"  ...ещё {result['missing'] - 15}")
            self.show_guide_step("import_created")
            return

        self.catalog_ready = True
        self.load_receipt_adjustments()
        summary = self.receipt_fact_summary()
        self.record_current_sai_file_status("проверен: все позиции найдены")
        self.status_var.set("ГОТОВО: все позиции найдены. Приход разрешён.")
        self.log_line("ОК: все позиции найдены по каталогу текущей сессии. Можно открыть факт приёмки или заполнить приход.")
        self.log_price_history_warnings(result)
        if summary.get("changed"):
            self.log_line(
                f"Факт приёмки: сохранены правки — частично {summary.get('partial', 0)}, "
                f"не принимать/возврат {summary.get('skip', 0)}."
            )
        self.show_guide_step("all_found")


    def receipt_adjustments_path(self):
        """Stable JSON sidecar for fact/shortage/return edits for the current SAI file."""
        try:
            src = safe_str(self.sai_path.get())
            if not src:
                return CACHE_DIR / "receipt_adjustments_empty.json"
            key = hashlib.sha1(src.encode("utf-8", errors="ignore")).hexdigest()[:12]
            return CACHE_DIR / f"receipt_adjustments_{key}.json"
        except Exception:
            return CACHE_DIR / "receipt_adjustments_unknown.json"

    def _default_receipt_adjustment_for_row(self, row):
        qty = parse_int_or_float(row.get("qty"))
        return {
            "excel_row": int(row.get("excel_row") or 0),
            "status": "accept",
            "fact_qty": qty,
            "sale_override": "",
            "comment": "",
        }

    def load_receipt_adjustments(self):
        """Load saved fact/shortage/return edits and merge them with current checked rows."""
        rows = (self.last_check_result or {}).get("source_rows") or []
        merged = {}
        for row in rows:
            key = str(row.get("excel_row"))
            merged[key] = self._default_receipt_adjustment_for_row(row)
        try:
            path = self.receipt_adjustments_path()
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                saved = data.get("items") if isinstance(data, dict) else {}
                if isinstance(saved, dict):
                    for key, value in saved.items():
                        if key in merged and isinstance(value, dict):
                            merged[key].update({k: v for k, v in value.items() if k in ("status", "fact_qty", "sale_override", "comment")})
        except Exception as e:
            self.log_line(f"Факт приёмки: не смог прочитать сохранённые правки — {str(e)[:160]}")
        self.receipt_adjustments = merged
        return merged

    def save_receipt_adjustments(self):
        try:
            ensure_runtime_dirs()
            path = self.receipt_adjustments_path()
            payload = {
                "version": APP_VERSION,
                "sai_file": safe_str(self.sai_path.get()),
                "saved_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "items": self.receipt_adjustments or {},
            }
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(path)
            return str(path)
        except Exception as e:
            self.log_line(f"Факт приёмки: не смог сохранить правки — {str(e)[:160]}")
            return ""

    def receipt_fact_summary(self):
        rows = (self.last_check_result or {}).get("source_rows") or []
        if not rows:
            return {"total": 0, "accept": 0, "partial": 0, "skip": 0, "changed": 0}
        if not self.receipt_adjustments:
            self.load_receipt_adjustments()
        total = len(rows)
        skip = partial = changed = accept = 0
        for row in rows:
            key = str(row.get("excel_row"))
            adj = self.receipt_adjustments.get(key) or self._default_receipt_adjustment_for_row(row)
            status = safe_str(adj.get("status") or "accept")
            fact_qty = parse_int_or_float(adj.get("fact_qty"))
            orig_qty = parse_int_or_float(row.get("qty"))
            if status in ("skip", "return", "not_accept") or fact_qty <= 0:
                skip += 1
                changed += 1
            elif abs(float(fact_qty) - float(orig_qty)) > 1e-9:
                partial += 1
                changed += 1
            else:
                accept += 1
            if safe_str(adj.get("sale_override")):
                changed += 1
        return {"total": total, "accept": accept, "partial": partial, "skip": skip, "changed": changed}

    def receipt_fact_hint_text(self):
        summary = self.receipt_fact_summary()
        if not summary.get("total"):
            return "Фактическая приёмка пока не открывалась."
        if not summary.get("changed"):
            return "Факт приёмки без изменений: все строки принимаются как в SAI-файле."
        return (
            "Факт приёмки изменён: "
            f"частично {summary.get('partial', 0)}, не принимать/возврат {summary.get('skip', 0)}. "
            "При заполнении SAI создаст временный рабочий файл и не тронет оригинал."
        )

    def open_receipt_fact_window(self):
        result = self.last_check_result or {}
        rows = result.get("source_rows") or []
        if not rows:
            messagebox.showinfo("SAI", "Сначала проверьте товары в SIGMA, чтобы SAI знал строки приёмки.")
            return
        self.load_receipt_adjustments()

        win = Toplevel(self)
        win.title("SAI — фактическая приёмка")
        win.geometry("1120x620")
        win.minsize(920, 520)
        try:
            win.transient(self)
            win.grab_set()
        except Exception:
            pass

        root = ttk.Frame(win, style="Root.TFrame", padding=(14, 12, 14, 12))
        root.pack(fill="both", expand=True)

        ttk.Label(root, text="Факт пришло / недовоз / возврат", style="Brand.TLabel").pack(anchor="w")
        ttk.Label(
            root,
            text="Оригинальный SAI-файл не меняется. Перед заполнением прихода будет создан временный рабочий файл с фактическими количествами.",
            style="BrandSub.TLabel",
            wraplength=1050,
            justify="left",
        ).pack(anchor="w", pady=(0, 10))

        table_frame = ttk.Frame(root, style="Card.TFrame")
        table_frame.pack(fill="both", expand=True)
        columns = ("excel_row", "status", "name", "barcode", "qty", "fact_qty", "buy", "sale", "sale_override", "comment")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="extended")
        headings = {
            "excel_row": "Стр.",
            "status": "Статус",
            "name": "Товар",
            "barcode": "ШК",
            "qty": "По накл.",
            "fact_qty": "Факт",
            "buy": "Закуп",
            "sale": "Продажа",
            "sale_override": "Продажа факт",
            "comment": "Комментарий",
        }
        widths = {
            "excel_row": 48, "status": 110, "name": 310, "barcode": 150, "qty": 74,
            "fact_qty": 74, "buy": 74, "sale": 74, "sale_override": 94, "comment": 210,
        }
        for col in columns:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], anchor="w")
        tree.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        scroll.pack(side="right", fill="y")
        tree.configure(yscrollcommand=scroll.set)
        tree.tag_configure("accept", background="#ecfdf5")
        tree.tag_configure("partial", background="#fffbeb")
        tree.tag_configure("skip", background="#f1f5f9")
        tree.tag_configure("return", background="#fef2f2")

        row_by_key = {str(r.get("excel_row")): r for r in rows}

        def status_label(status, fact_qty, orig_qty):
            status = safe_str(status or "accept")
            if status in ("skip", "not_accept") or parse_int_or_float(fact_qty) <= 0:
                return "Не принимать"
            if status == "return":
                return "Возврат"
            if abs(float(parse_int_or_float(fact_qty)) - float(parse_int_or_float(orig_qty))) > 1e-9:
                return "Недовоз/частично"
            return "Принять"

        def row_tag(status, fact_qty, orig_qty):
            label = status_label(status, fact_qty, orig_qty)
            if label == "Возврат":
                return "return"
            if label == "Не принимать":
                return "skip"
            if label == "Недовоз/частично":
                return "partial"
            return "accept"

        def fmt(v):
            try:
                f = float(parse_int_or_float(v))
                if abs(f - int(f)) < 1e-9:
                    return str(int(f))
                return (f"{f:.3f}").rstrip("0").rstrip(".")
            except Exception:
                return safe_str(v)

        def refresh_tree():
            tree.delete(*tree.get_children())
            for row in rows:
                key = str(row.get("excel_row"))
                adj = self.receipt_adjustments.get(key) or self._default_receipt_adjustment_for_row(row)
                orig_qty = row.get("qty")
                fact_qty = adj.get("fact_qty", orig_qty)
                status = adj.get("status", "accept")
                tag = row_tag(status, fact_qty, orig_qty)
                tree.insert("", "end", iid=key, tags=(tag,), values=(
                    row.get("excel_row"),
                    status_label(status, fact_qty, orig_qty),
                    row.get("name", ""),
                    row.get("barcode_cell") or ", ".join(row.get("barcodes") or []),
                    fmt(orig_qty),
                    fmt(fact_qty),
                    fmt(row.get("buy")),
                    fmt(row.get("sale")),
                    fmt(adj.get("sale_override")) if safe_str(adj.get("sale_override")) else "",
                    safe_str(adj.get("comment")),
                ))
            summary = self.receipt_fact_summary()
            summary_var.set(
                f"Строк: {summary.get('total')} | без изменений: {summary.get('accept')} | "
                f"частично: {summary.get('partial')} | не принимать/возврат: {summary.get('skip')}"
            )

        def selected_keys():
            keys = list(tree.selection())
            if not keys:
                messagebox.showinfo("SAI", "Выберите одну или несколько строк.", parent=win)
            return keys

        def set_accept():
            for key in selected_keys():
                row = row_by_key.get(key)
                if not row:
                    continue
                adj = self.receipt_adjustments.setdefault(key, self._default_receipt_adjustment_for_row(row))
                adj["status"] = "accept"
                adj["fact_qty"] = parse_int_or_float(row.get("qty"))
            self.save_receipt_adjustments()
            refresh_tree()

        def set_skip(status="skip"):
            for key in selected_keys():
                row = row_by_key.get(key)
                if not row:
                    continue
                adj = self.receipt_adjustments.setdefault(key, self._default_receipt_adjustment_for_row(row))
                adj["status"] = status
                adj["fact_qty"] = 0
                if status == "return" and not safe_str(adj.get("comment")):
                    adj["comment"] = "возврат / не принимать"
            self.save_receipt_adjustments()
            refresh_tree()

        def set_fact_qty():
            keys = selected_keys()
            if not keys:
                return
            first = keys[0]
            row = row_by_key.get(first) or {}
            adj = self.receipt_adjustments.get(first) or self._default_receipt_adjustment_for_row(row)
            value = simpledialog.askfloat(
                "Факт пришло",
                "Введите фактическое количество для выбранных строк:",
                initialvalue=float(parse_int_or_float(adj.get("fact_qty", row.get("qty")))),
                minvalue=0,
                parent=win,
            )
            if value is None:
                return
            for key in keys:
                row = row_by_key.get(key)
                if not row:
                    continue
                adj = self.receipt_adjustments.setdefault(key, self._default_receipt_adjustment_for_row(row))
                adj["fact_qty"] = value
                if value <= 0:
                    adj["status"] = "skip"
                elif abs(float(value) - float(parse_int_or_float(row.get("qty")))) > 1e-9:
                    adj["status"] = "partial"
                else:
                    adj["status"] = "accept"
            self.save_receipt_adjustments()
            refresh_tree()

        def set_sale_override():
            keys = selected_keys()
            if not keys:
                return
            value = simpledialog.askstring(
                "Продажная цена",
                "Введите продажную цену для выбранных строк. Пусто = оставить цену из SAI:",
                parent=win,
            )
            if value is None:
                return
            value = safe_str(value).replace(",", ".")
            if value:
                try:
                    value = str(float(value))
                except Exception:
                    messagebox.showwarning("SAI", "Цена должна быть числом.", parent=win)
                    return
            for key in keys:
                row = row_by_key.get(key)
                if not row:
                    continue
                adj = self.receipt_adjustments.setdefault(key, self._default_receipt_adjustment_for_row(row))
                adj["sale_override"] = value
            self.save_receipt_adjustments()
            refresh_tree()

        def set_comment():
            keys = selected_keys()
            if not keys:
                return
            first = keys[0]
            current = safe_str((self.receipt_adjustments.get(first) or {}).get("comment"))
            value = simpledialog.askstring("Комментарий", "Комментарий к выбранным строкам:", initialvalue=current, parent=win)
            if value is None:
                return
            for key in keys:
                row = row_by_key.get(key)
                if not row:
                    continue
                adj = self.receipt_adjustments.setdefault(key, self._default_receipt_adjustment_for_row(row))
                adj["comment"] = safe_str(value)
            self.save_receipt_adjustments()
            refresh_tree()

        actions = ttk.Frame(root, style="Root.TFrame")
        actions.pack(fill="x", pady=(10, 0))
        ttk.Button(actions, text="Принять как в накладной", command=set_accept, style="Success.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Факт пришло…", command=set_fact_qty, style="Primary.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Не принимать", command=lambda: set_skip("skip"), style="Warning.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Возврат", command=lambda: set_skip("return"), style="Warning.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Продажная цена…", command=set_sale_override, style="Secondary.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Комментарий…", command=set_comment, style="Secondary.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(actions, text="Сохранить и закрыть", command=lambda: (self.save_receipt_adjustments(), win.destroy(), self.show_guide_step("all_found", push=False)), style="Primary.TButton").pack(side="right")

        summary_var = StringVar(value="")
        ttk.Label(root, textvariable=summary_var, style="BrandSub.TLabel").pack(anchor="w", pady=(8, 0))
        refresh_tree()

    def create_effective_sai_for_apply(self, sheet_name):
        """Create temporary SAI workbook with fact quantities and skipped rows removed from APPLY."""
        cfg = load_private_config()
        if not bool(cfg.get("receipt_fact_enabled", True)):
            return self.sai_path.get()
        rows = (self.last_check_result or {}).get("source_rows") or []
        if not rows:
            return self.sai_path.get()
        if not self.receipt_adjustments:
            self.load_receipt_adjustments()

        # Build only when there are real changes. Otherwise use original file.
        has_changes = bool(self.receipt_fact_summary().get("changed"))
        if not has_changes:
            self.current_apply_excel_path = ""
            return self.sai_path.get()

        src = Path(self.sai_path.get())
        if not src.exists():
            return self.sai_path.get()
        ensure_runtime_dirs()
        out = CACHE_DIR / f"SAI_рабочий_факт_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        if src.suffix.lower() in (".xml", ".sai"):
            write_sai_rows_to_xlsx(rows, out, sheet_name=DEFAULT_SAI_SHEET)
        else:
            shutil.copy2(src, out)
        wb = load_workbook(out)
        ws = wb[sheet_name] if sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
        _header_row, headers = find_headers(ws)
        col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
        if not col_barcode:
            col_barcode = pick_col(headers, ["BARCODE"], contains_any=["ШК"])
        col_qty = pick_col(headers, ["КОЛ-ВО", "КОЛИЧЕСТВО", "КОЛ-ВО ЕД."], contains_any=["КОЛ"])
        col_unit = pick_col(headers, ["ЕД.", "ЕД", "ЕДИНИЦА", "ЕДИНИЦА ИЗМЕРЕНИЯ"], contains_any=["ЕД"])
        col_sale = pick_col(headers, ["ПРОДАЖНАЯ ЦЕНА", "ЦЕНА ПРОДАЖИ", "РОЗНИЧНАЯ ЦЕНА"], contains_any=["ПРОДАЖ"])
        if not col_sale:
            col_sale = pick_col(headers, ["ЦЕНА"])
        if not col_barcode or not col_qty:
            raise RuntimeError("Не могу подготовить рабочий SAI-файл: не найдены колонки ШК/КОЛ-ВО.")

        # Keep units canonical even in temporary fact workbooks: only 'штука' or 'м'.
        if col_unit:
            for row in rows:
                excel_row = int(row.get("excel_row") or 0)
                if excel_row > 0:
                    ws.cell(excel_row, col_unit).value = normalize_unit(row.get("unit") or ws.cell(excel_row, col_unit).value)

        skipped = partial = sale_changed = 0
        for row in rows:
            excel_row = int(row.get("excel_row") or 0)
            if excel_row <= 0:
                continue
            key = str(excel_row)
            adj = self.receipt_adjustments.get(key) or self._default_receipt_adjustment_for_row(row)
            status = safe_str(adj.get("status") or "accept")
            fact_qty = parse_int_or_float(adj.get("fact_qty", row.get("qty")))
            orig_qty = parse_int_or_float(row.get("qty"))
            if status in ("skip", "return", "not_accept") or fact_qty <= 0:
                ws.cell(excel_row, col_barcode).value = ""
                ws.cell(excel_row, col_qty).value = 0
                skipped += 1
            else:
                if abs(float(fact_qty) - float(orig_qty)) > 1e-9:
                    partial += 1
                ws.cell(excel_row, col_qty).value = fact_qty
            sale_override = safe_str(adj.get("sale_override"))
            if sale_override and col_sale:
                ws.cell(excel_row, col_sale).value = float(sale_override.replace(",", "."))
                sale_changed += 1
        wb.save(out)
        self.current_apply_excel_path = str(out)
        self.log_line(
            "Факт приёмки: создан рабочий SAI-файл для заполнения "
            f"({out.name}); пропущено/возврат {skipped}, частично {partial}, изменены цены {sale_changed}."
        )
        self.save_receipt_adjustments()
        return str(out)



    def invoice_date_from_sai_file(self):
        path = safe_str(self.sai_path.get())
        if not path:
            return ""
        p = Path(path)
        if p.suffix.lower() == ".sai":
            try:
                _sheet, _rows, meta = load_sai_package_rows(p)
                value = safe_str(meta.get("date"))
                if value:
                    return date_display_from_text(value)
            except Exception:
                pass
        stem = p.stem
        digits = re.sub(r"\D+", "", stem)
        if len(digits) >= 6:
            return date_display_from_text(digits[-6:])
        return ""

    def extract_storehouse_from_waybill_payload(self, payload):
        wb = payload.get("waybill") if isinstance(payload, dict) else {}
        if not isinstance(wb, dict):
            wb = {}
        storehouse_id = safe_str(payload.get("storehouse_id")) if isinstance(payload, dict) else ""
        storehouse_name = safe_str(payload.get("storehouse_name")) if isinstance(payload, dict) else ""

        if not storehouse_id:
            for key in ("storehouseDestination", "destinationStorehouse", "recipientStorehouse", "storehouse"):
                obj = wb.get(key)
                if isinstance(obj, dict):
                    storehouse_id = safe_str(obj.get("id"))
                    storehouse_name = storehouse_name or safe_str(obj.get("name"))
                    if storehouse_id:
                        break

        return storehouse_id, storehouse_name


    def on_supplier_selected(self, event=None):
        name = safe_str(self.supplier_choice.get())
        found = None
        for s in getattr(self, "suppliers", []):
            if safe_str(s.get("name")) == name:
                found = s
                break
        if found:
            self.supplier_id.set(safe_str(found.get("id")))
            self.supplier.set(safe_str(found.get("name")))
        else:
            self.supplier_id.set("")
            self.supplier.set(name)
        self.save_config()

    def is_browser_visible(self):
        try:
            return bool(self.browser_visible.get())
        except Exception:
            return bool(load_private_config().get("browser_visible", False))

    def toggle_browser_visible(self):
        visible = self.is_browser_visible()
        update_private_config({"browser_visible": visible})
        self.log_line("Браузер SIGMA: " + ("видимый режим" if visible else "скрытый режим"))

    def browser_visibility_args(self):
        cfg = load_private_config()
        args = ["--visible-browser"] if self.is_browser_visible() else ["--hidden-browser"]
        if bool(cfg.get("prefer_bundled_chromium", True)):
            args.append("--prefer-bundled-chromium")
        auto_after = parse_int_config(cfg.get("hidden_browser_auto_visible_after_seconds"), 0)
        if auto_after > 0:
            args += ["--hidden-auto-visible-after", str(auto_after)]
        return args

    def build_waybill_creator_args(self, mode):
        private_cfg = load_private_config()
        args = [
            sys.executable,
            "-u",
            str(WAYBILL_CREATOR_SCRIPT),
            "--mode", mode,
            "--user-data-dir", str(PROFILE_DIR),
        ] + self.browser_visibility_args()
        append_sigma_auth_args(args, private_cfg)
        if str(private_cfg.get("storehouse_id") or DEFAULT_STOREHOUSE_ID).strip():
            args += ["--storehouse-id", str(private_cfg.get("storehouse_id") or DEFAULT_STOREHOUSE_ID).strip()]
        if str(private_cfg.get("sigma_internal_company_id") or "").strip():
            args += ["--company-id", str(private_cfg.get("sigma_internal_company_id")).strip()]
        return args

    def startup_warmup(self):
        cfg = load_private_config()
        if not bool(cfg.get("startup_preload", True)):
            self.log_line("Стартовый прогрев SIGMA отключён в private config: startup_preload=false.")
            self.startup_warmup_done = True
            if getattr(self, "guide_state", "") == "startup_loading":
                self.show_guide_step("input", push=False)
            return

        company_key = safe_str(cfg.get("sigma_company_key"))
        api_token = safe_str(cfg.get("sigma_api_token"))
        if not company_key or not api_token:
            self.set_startup_progress(100, "Private config не заполнен — пропускаю прогрев SIGMA.", "Заполните sigma_company_key и sigma_api_token в private config, когда будете готовы.")
            self.log_line("Стартовый прогрев пропущен: в private config нет sigma_company_key/sigma_api_token.")
            self.startup_warmup_done = True
            if getattr(self, "guide_state", "") == "startup_loading":
                self.show_guide_step("input", push=False)
            return

        if self.running:
            self.after(1000, self.startup_warmup)
            return

        self.startup_warmup_running = True
        self.running = True
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.status_var.set("SAI прогревает SIGMA: сессия, поставщики, каталог...")
        self.set_startup_progress(8, "Проверяю настройки и готовлю старт…", "")
        self.log_line("Стартовый прогрев: проверяю SIGMA, поставщиков и каталог. Если включён VPN — лучше выключить.")
        threading.Thread(target=self._startup_warmup_worker, args=(cfg,), daemon=True).start()

    def _startup_warmup_worker(self, cfg):
        try:
            self.queue.put(("startup_progress", {"percent": 14, "stage": "Проверяю private config и доступ к SIGMA…"}))
            suppliers_loaded = False
            if WAYBILL_CREATOR_SCRIPT.exists():
                args = self.build_waybill_creator_args("list-suppliers")
                env = os.environ.copy()
                env["PYTHONIOENCODING"] = "utf-8"
                env["PYTHONUTF8"] = "1"
                env["PYTHONUNBUFFERED"] = "1"
                self.queue.put(("startup_progress", {"percent": 24, "stage": "Открываю служебную сессию SIGMA и подтягиваю поставщиков…"}))
                proc = subprocess.Popen(
                    args,
                    cwd=str(APP_DIR),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                    env=env,
                    creationflags=CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP,
                )
                self.register_child_process(proc)
                for line in proc.stdout:
                    line = line.rstrip()
                    if "SAI_SUPPLIERS_JSON:" in line:
                        raw = line.split("SAI_SUPPLIERS_JSON:", 1)[1].strip()
                        try:
                            self.queue.put(("suppliers_json", json.loads(raw)))
                            self.queue.put(("startup_progress", {"percent": 42, "stage": "Поставщики загружены. Готовлю каталог товаров…"}))
                            suppliers_loaded = True
                        except Exception as e:
                            self.queue.put(("log", f"Стартовый прогрев: не смог прочитать список поставщиков: {e}"))
                        continue
                    self.queue.put(("log", line))
                code = proc.wait()
                self.unregister_child_process(proc)
                if code != 0:
                    self.queue.put(("log", f"Стартовый прогрев: поставщики загрузились с кодом {code}. Продолжаю каталог, если API доступен."))
            else:
                self.queue.put(("log", f"Стартовый прогрев: не найден {WAYBILL_CREATOR_SCRIPT}."))

            company_key = safe_str(cfg.get("sigma_company_key"))
            api_token = safe_str(cfg.get("sigma_api_token"))
            self.queue.put(("startup_progress", {"percent": 55, "stage": "Проверяю точку продаж SIGMA…"}))
            sell_point_id = get_sigma_sell_point_id(
                company_key,
                api_token,
                cfg,
                log_callback=lambda msg: self.queue.put(("log", msg)),
            )
            force_startup_refresh = bool(cfg.get("catalog_refresh_on_startup", True))
            self.queue.put(("startup_progress", {"percent": 70, "stage": "Готовлю локальный каталог товаров и штрихкодов…"}))
            if force_startup_refresh:
                self.queue.put(("log", "Стартовый прогрев: обновляю каталог SIGMA в SQLite, чтобы в этой сессии SAI доверял свежей базе."))
            catalog = get_sigma_api_catalog_cached(
                company_key,
                api_token,
                sell_point_id,
                log_callback=lambda msg: self.queue.put(("log", msg)),
                force_refresh=force_startup_refresh,
            )
            self.queue.put(("startup_progress", {"percent": 96, "stage": "Финальная проверка готовности…"}))
            self.queue.put(("startup_done", {
                "suppliers_loaded": suppliers_loaded,
                "product_count": catalog.get("product_count", 0),
                "barcode_count": len(catalog.get("codes") or []),
                "path": str(DB_PATH),
                "force_refreshed": force_startup_refresh,
            }))
        except Exception as e:
            self.queue.put(("startup_progress", {"percent": 100, "stage": "Прогрев не завершился. Можно работать дальше, но проверьте SIGMA/VPN."}))
            self.queue.put(("startup_error", str(e)))

    def refresh_suppliers(self):
        if self.running:
            messagebox.showwarning("SAI", "Сейчас уже выполняется операция. Дождитесь завершения.")
            return
        if not WAYBILL_CREATOR_SCRIPT.exists():
            messagebox.showerror("SAI", f"Не найден скрипт:\n{WAYBILL_CREATOR_SCRIPT}")
            return
        self.cleanup_profile_browsers()
        self.running = True
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.status_var.set("SAI загружает поставщиков...")
        self.show_guide_step("suppliers_loading")
        self.log_line("Загружаю список поставщиков из SIGMA...")
        args = self.build_waybill_creator_args("list-suppliers")
        threading.Thread(target=self._run_waybill_creator_subprocess, args=(args,), daemon=True).start()

    def create_waybill_and_check(self):
        if self.running:
            messagebox.showwarning("SAI", "Сейчас уже выполняется операция. Дождитесь завершения.")
            return
        if not self.sai_path.get() or not Path(self.sai_path.get()).exists():
            messagebox.showerror("SAI", "Выбери существующий SAI-файл.")
            return

        file_date = self.invoice_date_from_sai_file()
        if not file_date:
            messagebox.showerror("SAI", "Не смог взять дату из имени SAI-файла. В имени файла должны быть последние 6 цифр даты, например 120526.")
            return
        self.invoice_date.set(file_date)

        self.on_supplier_selected()
        supplier_id = safe_str(self.supplier_id.get())
        supplier_name = safe_str(self.supplier_choice.get() or self.supplier.get())
        if not supplier_id and not supplier_name:
            messagebox.showerror("SAI", "Выберите поставщика из списка. Если список пустой — нажмите «Обновить поставщиков».")
            return

        if not WAYBILL_CREATOR_SCRIPT.exists():
            messagebox.showerror("SAI", f"Не найден скрипт:\n{WAYBILL_CREATOR_SCRIPT}")
            return

        self.record_current_sai_file_status("создаю черновик")
        self.cleanup_profile_browsers()
        self.running = True
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.catalog_ready = False
        self.waybill.set("")
        self.runtime_storehouse_id.set("")
        self.status_var.set("SAI создаёт черновик прихода...")
        self.show_guide_step("creating_waybill")
        self.log_line(f"Создаю черновик прихода: поставщик «{supplier_name}», дата {file_date}")

        args = self.build_waybill_creator_args("create-waybill")
        args += ["--invoice-date", file_date]
        if supplier_id:
            args += ["--supplier-id", supplier_id]
        if supplier_name:
            args += ["--supplier-name", supplier_name]
        # Не открываем созданный черновик отдельной страницей: это держало браузерный профиль
        # занятым и иногда мешало следующей проверке товаров открыть Playwright.
        self.pending_check_after_waybill = True
        self.pending_waybill_created = None

        self.save_config()
        threading.Thread(target=self._run_waybill_creator_subprocess, args=(args,), daemon=True).start()

    def _run_waybill_creator_subprocess(self, args):
        try:
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            env["PYTHONUNBUFFERED"] = "1"

            proc = subprocess.Popen(
                args,
                cwd=str(APP_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP,
            )
            self.register_child_process(proc)

            for line in proc.stdout:
                line = line.rstrip()
                if "SAI_SUPPLIERS_JSON:" in line:
                    raw = line.split("SAI_SUPPLIERS_JSON:", 1)[1].strip()
                    try:
                        self.queue.put(("suppliers_json", json.loads(raw)))
                    except Exception as e:
                        self.queue.put(("waybill_creator_error", f"Не смог прочитать список поставщиков: {e}"))
                    continue
                if "SAI_WAYBILL_CREATED_JSON:" in line:
                    raw = line.split("SAI_WAYBILL_CREATED_JSON:", 1)[1].strip()
                    try:
                        self.queue.put(("waybill_created_json", json.loads(raw)))
                    except Exception as e:
                        self.queue.put(("waybill_creator_error", f"Не смог прочитать результат создания черновика: {e}"))
                    continue
                self.queue.put(("log", line))

            code = proc.wait()
            self.unregister_child_process(proc)
            self.queue.put(("waybill_creator_done", code))
        except Exception as e:
            self.queue.put(("waybill_creator_error", str(e)))


    def register_child_process(self, proc):
        try:
            self.child_processes.append(proc)
        except Exception:
            pass

    def unregister_child_process(self, proc):
        try:
            self.child_processes = [p for p in self.child_processes if p is not proc and p.poll() is None]
        except Exception:
            pass

    def terminate_process_tree(self, proc_or_pid):
        try:
            pid = proc_or_pid if isinstance(proc_or_pid, int) else proc_or_pid.pid
        except Exception:
            return
        if not pid:
            return
        if os.name == "nt":
            try:
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW, timeout=8)
                return
            except Exception:
                pass
        try:
            if not isinstance(proc_or_pid, int):
                proc_or_pid.terminate()
        except Exception:
            pass

    def cleanup_child_processes(self):
        procs = list(getattr(self, "child_processes", []) or [])
        self.child_processes = []
        for proc in procs:
            try:
                if proc.poll() is None:
                    self.terminate_process_tree(proc)
            except Exception:
                pass

    def cleanup_profile_browsers(self):
        """Закрывает только браузеры, запущенные с профилем SAI Profile."""
        if os.name != "nt":
            return
        profile = str(PROFILE_DIR.resolve()).replace("\\", "\\\\")
        ps = ("$p='" + profile.replace("'", "''") + "';"
              "Get-CimInstance Win32_Process | "
              "Where-Object { $_.CommandLine -and $_.CommandLine -like ('*' + $p + '*') } | "
              "ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }")
        try:
            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW, timeout=10)
        except Exception:
            pass

    def abort_current_operation(self):
        if not getattr(self, "running", False):
            self.log_line("Стоп: активных операций нет.")
            self.last_bot_status.set("SAI ждёт действия")
            return
        self.log_line("Стоп: останавливаю текущую операцию и служебные процессы...")
        self.running = False
        self.run_started_at = None
        self.pending_check_after_waybill = False
        self.cleanup_child_processes()
        self.cleanup_profile_browsers()
        self.status_var.set("Операция остановлена. Можно повторить действие.")
        self.last_bot_status.set("Остановлено")

    def reset_service_browser(self):
        if getattr(self, "running", False):
            self.abort_current_operation()
        self.log_line("Сброс браузера: закрываю зависшие окна браузера SAI...")
        self.cleanup_child_processes()
        self.cleanup_profile_browsers()
        self.status_var.set("Служебный браузер сброшен. Можно повторить действие.")
        self.last_bot_status.set("Браузер сброшен")

    def on_close(self):
        self.closing = True
        try:
            self.status_var.set("Закрываю SAI и служебные процессы...")
        except Exception:
            pass
        self.cleanup_child_processes()
        self.cleanup_profile_browsers()
        try:
            self.destroy()
        except Exception:
            pass


    def run_supplier_waybill_probe(self):
        if self.running:
            messagebox.showwarning("SAI", "Сейчас уже выполняется операция. Дождитесь завершения.")
            return
        if not SUPPLIER_PROBE_SCRIPT.exists():
            messagebox.showerror("SAI", f"Не найден диагностический скрипт:\n{SUPPLIER_PROBE_SCRIPT}")
            return

        self.cleanup_profile_browsers()
        self.running = True
        self.last_run_apply = False
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.supplier_probe_report_path = ""
        self.status_var.set("SAI записывает создание черновика прихода...")
        self.show_guide_step("supplier_probe")
        self.log_line("Диагностика черновика: запускаю браузер и запись сетевых запросов.")
        self.log_line("В открывшемся SIGMA создайте один тестовый черновик прихода вручную.")

        args = [
            sys.executable,
            "-u",
            str(SUPPLIER_PROBE_SCRIPT),
            "--user-data-dir", str(PROFILE_DIR),
            "--duration", "240",
        ]

        threading.Thread(target=self._run_supplier_probe_subprocess, args=(args,), daemon=True).start()

    def _run_supplier_probe_subprocess(self, args):
        try:
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            env["PYTHONUNBUFFERED"] = "1"

            proc = subprocess.Popen(
                args,
                cwd=str(APP_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP,
            )
            self.register_child_process(proc)

            for line in proc.stdout:
                line = line.rstrip()
                marker = "SAI_SUPPLIER_PROBE_REPORT:"
                if marker in line:
                    report_path = line.split(marker, 1)[1].strip()
                    self.queue.put(("supplier_probe_report", report_path))
                    continue
                self.queue.put(("log", line))

            code = proc.wait()
            self.unregister_child_process(proc)
            self.queue.put(("supplier_probe_done", code))
        except Exception as e:
            self.queue.put(("supplier_probe_error", str(e)))


    def run_bot(self, apply=False):
        self.hide_ndp_actions()
        if not self.validate_basic(need_catalog=False, need_waybill=True):
            return
        if not self.catalog_ready:
            messagebox.showerror(
                "Приход заблокирован",
                "Сначала нажмите «Проверить товары в SIGMA». Приход разрешён только когда все позиции найдены через SIGMA API.",
            )
            return
        if self.running:
            messagebox.showwarning("SAI", "Бот уже запущен.")
            return

        try:
            sheet_name, _ = load_sai_rows(self.sai_path.get())
        except Exception as e:
            messagebox.showerror("SAI", f"Не могу прочитать SAI-файл: {e}")
            return

        self.save_config()
        self.running = True
        self.last_run_apply = bool(apply)
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.cleanup_profile_browsers()
        self.status_var.set("Бот работает...")
        mode = "APPLY" if apply else "DRY-RUN"
        self.show_guide_step("apply_running" if apply else "dryrun_running")
        self.log_line(f"Запускаю API-first заполнение SIGMA: {mode}")

        if not API_FIRST_SCRIPT.exists():
            messagebox.showerror("SAI", f"Не найден API-first скрипт:\n{API_FIRST_SCRIPT}")
            self.running = False
            return

        try:
            # Dry-run and APPLY both use the effective receipt file, so “Факт пришло”
            # can be checked safely before the real write.
            self.create_effective_sai_for_apply(sheet_name)
        except Exception as e:
            self.running = False
            self.status_var.set("Не смог подготовить факт приёмки.")
            self.log_line(f"ОШИБКА факта приёмки: {e}")
            messagebox.showerror("SAI", f"Не смог подготовить рабочий SAI-файл для фактической приёмки:\n{e}")
            return

        args = self.build_api_first_args(sheet_name=sheet_name)
        if apply:
            args.append("--apply")
            args.append("--stop-on-error")

        threading.Thread(target=self._run_subprocess, args=(args,), daemon=True).start()

    def _run_subprocess(self, args):
        try:
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            env["PYTHONUNBUFFERED"] = "1"

            proc = subprocess.Popen(
                args,
                cwd=str(APP_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                env=env,
                creationflags=CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP,
            )
            self.register_child_process(proc)
            for line in proc.stdout:
                line = line.rstrip()
                meta = self.parse_waybill_metadata_line(line)
                if meta is not None:
                    supplier_name = safe_str(meta.get("supplier_name"))
                    if supplier_name:
                        self.queue.put(("supplier_detected", supplier_name))
                    else:
                        self.queue.put(("log", "Поставщик из черновика не найден в metadata JSON."))
                    continue
                self.queue.put(("log", line))
            code = proc.wait()
            self.unregister_child_process(proc)
            self.queue.put(("done", code))
        except Exception as e:
            self.queue.put(("error", str(e)))

    def poll_queue(self):
        try:
            while True:
                typ, payload = self.queue.get_nowait()
                if typ == "log":
                    self.log_line(payload)
                    m = re.search(r"Log:\s*(.+\.csv)", payload)
                    if m:
                        p = m.group(1).strip()
                        lp = Path(p)
                        if not lp.is_absolute():
                            lp = APP_DIR / lp
                        self.last_log_path = str(lp)
                elif typ == "startup_progress":
                    if isinstance(payload, dict):
                        self.set_startup_progress(
                            payload.get("percent", self.startup_progress_target),
                            payload.get("stage"),
                            payload.get("tip"),
                        )
                    else:
                        self.set_startup_progress(payload)
                elif typ == "suppliers_json":
                    self.suppliers = payload.get("suppliers") or []
                    if self.suppliers:
                        self.status_var.set(f"Поставщики загружены: {len(self.suppliers)}")
                        self.log_line(f"Поставщики загружены: {len(self.suppliers)}")
                        # Try to keep current selected supplier.
                        current = safe_str(self.supplier_choice.get() or self.supplier.get())
                        names = [safe_str(x.get("name")) for x in self.suppliers]
                        if current not in names and names:
                            self.supplier_choice.set(names[0])
                        self.on_supplier_selected()
                        self.save_config()
                        if getattr(self, "guide_state", "") in ("suppliers_loading", "prepare", "suppliers_loaded"):
                            self.show_guide_step("suppliers_loaded")
                    else:
                        self.guide_error_text = "SIGMA вернула пустой список поставщиков."
                        self.show_guide_step("waybill_error")
                elif typ == "waybill_created_json":
                    wb = payload.get("waybill") or {}
                    waybill_id = safe_str(payload.get("waybill_id") or wb.get("id"))
                    supplier_name = safe_str(payload.get("supplier_name") or self.supplier_choice.get())
                    if waybill_id:
                        self.waybill.set(waybill_id)
                        if supplier_name:
                            self.supplier.set(supplier_name)
                            self.supplier_choice.set(supplier_name)
                        if payload.get("invoice_date"):
                            self.invoice_date.set(safe_str(payload.get("invoice_date")))
                        storehouse_id, storehouse_name = self.extract_storehouse_from_waybill_payload(payload)
                        if storehouse_id:
                            self.runtime_storehouse_id.set(storehouse_id)
                            if storehouse_name:
                                self.log_line(f"Склад черновика: {storehouse_name} ({storehouse_id})")
                            else:
                                self.log_line(f"Склад черновика: {storehouse_id}")
                        else:
                            self.log_line("ВНИМАНИЕ: не смог определить склад черновика. Будет использован storehouse_id из приватного конфига.")
                        self.save_config()
                        self.record_current_sai_file_status("черновик создан")
                        self.pending_waybill_created = payload
                        self.log_line(f"Черновик прихода создан: {waybill_id}")
                        self.log_line("Черновик создан. Запускаю проверку товаров...")
                    else:
                        self.guide_error_text = "SIGMA создала ответ без waybillId."
                        self.pending_check_after_waybill = False
                        self.show_guide_step("waybill_error")
                elif typ == "waybill_creator_done":
                    code = int(payload)
                    was_waiting_for_check = bool(getattr(self, "pending_check_after_waybill", False))
                    has_waybill = bool(normalize_waybill(self.waybill.get()))
                    self.running = False
                    self.run_started_at = None

                    if code == 0 and was_waiting_for_check and has_waybill:
                        self.pending_check_after_waybill = False
                        self.log_line("Запускаю проверку товаров в SIGMA...")
                        self.after(800, self.check_catalog)
                    elif code == 0:
                        if getattr(self, "guide_state", "") == "suppliers_loading":
                            self.show_guide_step("suppliers_loaded")
                    elif getattr(self, "guide_state", "") not in ("checking", "suppliers_loaded"):
                        self.pending_check_after_waybill = False
                        self.guide_error_text = f"Создание/загрузка завершилась с кодом {payload}."
                        self.show_guide_step("waybill_error")
                elif typ == "waybill_creator_error":
                    self.running = False
                    self.run_started_at = None
                    self.status_var.set("Ошибка создания черновика/загрузки поставщиков.")
                    self.log_line(f"ОШИБКА черновика: {payload}")
                    hint = sigma_network_error_hint(payload)
                    if hint:
                        self.log_line("ПОДСКАЗКА: " + hint)
                    self.guide_error_text = str(payload) + (("\n\n" + hint) if hint else "")
                    self.show_guide_step("waybill_error")
                elif typ == "supplier_probe_report":
                    self.supplier_probe_report_path = str(payload)
                    self.log_line(f"Отчёт диагностики черновика: {payload}")
                elif typ == "supplier_probe_done":
                    self.running = False
                    self.run_started_at = None
                    if int(payload) == 0:
                        self.status_var.set("Диагностика создания черновика завершена.")
                        self.log_line("Диагностика создания черновика завершена без кода ошибки.")
                        self.show_guide_step("supplier_probe_done")
                    else:
                        self.status_var.set(f"Диагностика завершилась с кодом {payload}.")
                        self.log_line(f"Диагностика создания черновика завершилась с кодом {payload}.")
                        self.guide_error_text = f"Диагностика завершилась с кодом {payload}."
                        self.show_guide_step("supplier_probe_error")
                elif typ == "supplier_probe_error":
                    self.running = False
                    self.run_started_at = None
                    self.status_var.set("Ошибка диагностики создания черновика.")
                    self.log_line(f"ОШИБКА диагностики черновика: {payload}")
                    self.guide_error_text = str(payload)
                    self.show_guide_step("supplier_probe_error")
                elif typ == "done":
                    self.running = False
                    self.run_started_at = None
                    latest = find_latest_log(LOGS_DIR)
                    if latest:
                        self.last_log_path = str(latest)
                    if payload == 0:
                        self.status_var.set("Бот завершил работу.")
                        self.log_line("Бот завершил работу без кода ошибки.")
                        if self.last_run_apply:
                            self.record_current_sai_file_status("приход заполнен")
                            self.save_apply_history_from_last_log()
                            self.status_var.set("Приход заполнен. Можно сохранить или сразу напечатать НДП.")
                            self.log_line("Приход заполнен. Доступны кнопки: «Сохранить накладную» и «СРАЗУ ПЕЧАТАТЬ».")
                            self.show_ndp_actions()
                        else:
                            self.show_guide_step("dryrun_ok")
                    else:
                        self.status_var.set(f"Бот завершился с кодом {payload}.")
                        self.log_line(f"Бот завершился с кодом {payload}.")
                        self.guide_error_text = f"Бот завершился с кодом {payload}."
                        self.show_guide_step("bot_error")
                elif typ == "catalog_cache_refreshed":
                    self.running = False
                    self.run_started_at = None
                    self.catalog_refreshed_this_session = True
                    self.catalog_session_refreshed_at = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.status_var.set("Каталог SIGMA обновлён.")
                    self.log_line(
                        f"Каталог SIGMA обновлён: товаров={payload.get('product_count')}, ШК={payload.get('barcode_count')}"
                    )
                    self.log_line(f"Кэш каталога: {payload.get('path')}")
                elif typ == "catalog_cache_error":
                    self.running = False
                    self.run_started_at = None
                    self.status_var.set("Ошибка обновления каталога SIGMA.")
                    self.log_line(f"ОШИБКА обновления каталога SIGMA: {payload}")
                    hint = sigma_network_error_hint(payload)
                    if hint:
                        self.log_line("ПОДСКАЗКА: " + hint)
                    messagebox.showerror("Ошибка обновления каталога SIGMA", str(payload) + (("\n\n" + hint) if hint else ""))
                elif typ == "startup_done":
                    self.running = False
                    self.run_started_at = None
                    self.startup_warmup_running = False
                    self.startup_warmup_done = True
                    if bool(payload.get("force_refreshed")):
                        self.catalog_refreshed_this_session = True
                        self.catalog_session_refreshed_at = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.set_startup_progress(100, "SAI готов к приёмке.", "Можно создавать черновик прихода и проверять товары.")
                    self.status_var.set("SAI прогрел SIGMA и готов к работе.")
                    self.log_line(
                        f"Стартовый прогрев готов: товаров={payload.get('product_count')}, ШК={payload.get('barcode_count')}"
                    )
                    self.log_line(f"Кэш каталога: {payload.get('path')}")
                    if self.suppliers:
                        self.show_guide_step("suppliers_loaded", push=False)
                    else:
                        self.show_guide_step("input", push=False)
                elif typ == "startup_error":
                    self.running = False
                    self.run_started_at = None
                    self.startup_warmup_running = False
                    self.startup_warmup_done = True
                    self.startup_warmup_error = str(payload)
                    self.set_startup_progress(100, "Прогрев SIGMA не завершился.", "Чаще всего причина — активный VPN, интернет-защита антивируса или временный сбой SIGMA API.")
                    self.status_var.set("Стартовый прогрев SIGMA не завершился.")
                    self.log_line(f"ОШИБКА стартового прогрева: {payload}")
                    hint = sigma_network_error_hint(payload)
                    if hint:
                        self.log_line("ПОДСКАЗКА: " + hint)
                    if getattr(self, "guide_state", "") == "startup_loading":
                        self.show_guide_step("input", push=False)
                elif typ == "api_done":
                    self.status_var.set(payload)
                    self.log_line(payload)
                elif typ == "supplier_detected":
                    self.supplier.set(payload)
                    self.save_config()
                    self.log_line(f"Поставщик автоматически подтянут из черновика: {payload}")
                elif typ == "product_check_result":
                    self.handle_product_check_result(payload)
                elif typ == "product_check_error":
                    self.catalog_ready = False
                    self.running = False
                    self.run_started_at = None
                    self.status_var.set("Ошибка проверки товаров.")
                    self.log_line(f"ОШИБКА проверки товаров: {payload}")
                    hint = sigma_network_error_hint(payload)
                    if hint:
                        self.log_line("ПОДСКАЗКА: " + hint)
                    self.guide_error_text = str(payload) + (("\n\n" + hint) if hint else "")
                    self.show_guide_step("check_error")
                    messagebox.showerror("Ошибка проверки товаров", str(payload) + (("\n\n" + hint) if hint else ""))
                elif typ == "error":
                    self.running = False
                    self.run_started_at = None
                    self.status_var.set("Ошибка запуска бота.")
                    self.log_line(f"ОШИБКА subprocess: {payload}")
                    self.guide_error_text = str(payload)
                    self.show_guide_step("bot_error")
        except queue.Empty:
            pass

        # GUI heartbeat: shows that the subprocess is still alive even if SIGMA/API is slow.
        if self.running and self.run_started_at:
            now = time.time()
            if now - self.last_heartbeat_at >= 5:
                elapsed = int(now - self.run_started_at)
                self.log_line(f"…бот работает, прошло {elapsed} сек.")
                self.last_heartbeat_at = now

        self.after(100, self.poll_queue)

    def open_sai_folder(self):
        try:
            if hasattr(os, "startfile"):
                os.startfile(str(ROOT_DIR))
            else:
                messagebox.showinfo("SAI", str(ROOT_DIR))
        except Exception as e:
            messagebox.showerror("SAI", str(e))

    def open_logs_folder(self):
        try:
            logs = LOGS_DIR
            logs.mkdir(parents=True, exist_ok=True)
            if hasattr(os, "startfile"):
                os.startfile(str(logs))
            else:
                messagebox.showinfo("SAI", str(logs))
        except Exception as e:
            messagebox.showerror("SAI", str(e))

    def refresh_catalog_cache(self):
        if self.running:
            messagebox.showwarning("SAI", "Сейчас уже выполняется операция. Дождитесь завершения.")
            return

        cfg = load_private_config()
        company_key = safe_str(cfg.get("sigma_company_key"))
        api_token = safe_str(cfg.get("sigma_api_token"))
        if not company_key or not api_token:
            messagebox.showwarning("SAI", "В user_data/sai_private_config.json не заполнены sigma_company_key и/или sigma_api_token.")
            return

        self.running = True
        self.run_started_at = time.time()
        self.last_heartbeat_at = 0.0
        self.status_var.set("Обновляю локальный каталог SIGMA...")
        self.log_line("Обновляю локальный каталог SIGMA...")
        threading.Thread(target=self._refresh_catalog_cache_worker, args=(cfg,), daemon=True).start()

    def _refresh_catalog_cache_worker(self, cfg):
        try:
            company_key = safe_str(cfg.get("sigma_company_key"))
            api_token = safe_str(cfg.get("sigma_api_token"))
            sell_point_id = get_sigma_sell_point_id(company_key, api_token, cfg, log_callback=lambda msg: self.queue.put(("log", msg)))
            self.queue.put(("startup_progress", {"percent": 70, "stage": "Готовлю локальный каталог товаров и штрихкодов…"}))
            catalog = get_sigma_api_catalog_cached(
                company_key,
                api_token,
                sell_point_id,
                log_callback=lambda msg: self.queue.put(("log", msg)),
                force_refresh=True,
            )
            self.queue.put(("catalog_cache_refreshed", {
                "product_count": catalog.get("product_count", 0),
                "barcode_count": len(catalog.get("codes") or []),
                "path": str(DB_PATH),
                "force_refreshed": True,
            }))
        except Exception as e:
            self.queue.put(("catalog_cache_error", str(e)))



    def log_price_history_warnings(self, check_result=None):
        """Log useful price changes from previous successful APPLY runs.

        SQLite is advisory here: it does not block receiving. It only warns when the
        current SAI file differs noticeably from the last stored price for the same
        barcode/product name.
        """
        try:
            cfg = load_private_config()
            if not bool(cfg.get("price_history_enabled", True)):
                return
            rows = (check_result or {}).get("source_rows") or []
            if not rows:
                return
            buy_threshold = float(cfg.get("price_history_warn_buy_percent", 15) or 15)
            sale_threshold = float(cfg.get("price_history_warn_sale_percent", 10) or 10)
            warnings = sai_db.price_warnings_for_rows(rows, buy_threshold, sale_threshold, limit=8)
            if not warnings:
                self.log_line("История цен: заметных изменений по прошлым приёмкам не найдено.")
                return
            self.log_line(f"История цен: найдено заметных изменений: {len(warnings)}")
            for w in warnings[:8]:
                bits = []
                if w.get("buy_change_pct") is not None:
                    bits.append(f"закуп {w.get('old_buying')} → {w.get('new_buying')} ({w.get('buy_change_pct'):+.1f}%)")
                if w.get("sale_change_pct") is not None:
                    bits.append(f"продажа {w.get('old_selling')} → {w.get('new_selling')} ({w.get('sale_change_pct'):+.1f}%)")
                self.log_line(f"  цена: {w.get('name')} — " + "; ".join(bits))
        except Exception as e:
            self.log_line(f"История цен: не смог проверить изменения, продолжаю без предупреждений — {str(e)[:160]}")

    def save_apply_history_from_last_log(self):
        """Persist successful APPLY CSV into SQLite price history."""
        try:
            cfg = load_private_config()
            if not bool(cfg.get("price_history_enabled", True)):
                return
            log_path = safe_str(getattr(self, "last_log_path", ""))
            if not log_path:
                self.log_line("История цен: нет CSV-лога APPLY, сохранять нечего.")
                return
            audit_path = ""
            try:
                lp = Path(log_path)
                audit_candidate = lp.with_name(lp.stem.replace("sigma_api_first", "price_audit") + ".xlsx")
                if audit_candidate.exists():
                    audit_path = str(audit_candidate)
            except Exception:
                pass
            summary = sai_db.record_apply_log(
                log_path=log_path,
                sai_path=safe_str(self.current_apply_excel_path or self.sai_path.get()),
                supplier_name=self.supplier_value_for_files(),
                invoice_date=safe_str(self.invoice_date.get()),
                waybill_id=normalize_waybill(self.waybill.get()),
                audit_path=audit_path,
                app_version=APP_VERSION,
            )
            self.log_line(
                "История цен: сохранена приёмка "
                f"#{summary.get('apply_run_id')} — OK {summary.get('ok_count')}, ошибок {summary.get('error_count')}, "
                f"закуп {summary.get('buying_total'):.2f}, продажа {summary.get('selling_total'):.2f}"
            )
        except Exception as e:
            self.log_line(f"История цен: не смог сохранить APPLY в sai.db, продолжаю — {str(e)[:180]}")

    def show_price_history_status(self):
        try:
            available = sai_db.is_available()
            if not available:
                messagebox.showerror("SAI история", "SQLite-база недоступна.")
                return
            runs = sai_db.latest_apply_summary(limit=8)
            stats = sai_db.price_history_stats()
            lines = [
                f"SQLite-база: {DB_PATH}",
                f"Позиций в истории цен: {stats.get('price_rows', 0)}",
                f"Заполненных приёмок в истории: {stats.get('apply_runs', 0)}",
            ]
            if runs:
                lines.append("")
                lines.append("Последние заполненные приёмки:")
                for r in runs:
                    lines.append(
                        f"#{r.get('id')} {r.get('created_at')} — {r.get('supplier_name') or ''} "
                        f"{r.get('invoice_date') or ''}: OK {r.get('ok_count')}, "
                        f"закуп {float(r.get('buying_total') or 0):.2f}, продажа {float(r.get('selling_total') or 0):.2f}"
                    )
            else:
                lines.append("")
                lines.append("История заполненных приёмок пока пустая. Она появится после первого успешного APPLY.")
            self.log_line("История цен: " + " | ".join(lines[:3]))
            messagebox.showinfo("SAI — история приёмок и цен", "\n".join(lines))
        except Exception as e:
            self.log_line(f"История цен: ошибка статуса — {e}")
            messagebox.showerror("SAI история", str(e))

    def show_sqlite_status(self):
        try:
            available = sai_db.is_available()
            latest = sai_db.latest_receipt_summary(limit=3) if available else []
            cfg = load_private_config()
            company_key = safe_str(cfg.get("sigma_company_key"))
            sell_point_id = safe_str(cfg.get("sigma_sell_point_id"))
            age = sai_db.catalog_age_seconds(company_key, sell_point_id) if company_key and sell_point_id else None
            lines = [
                f"SQLite-база: {DB_PATH}",
                "Статус: " + ("OK" if available else "не доступна"),
            ]
            if age is not None:
                lines.append(f"Возраст каталога: {int(age)} сек.")
            if latest:
                lines.append("Последние проверки:")
                for r in latest:
                    lines.append(
                        f"#{r.get('id')} {r.get('sai_file_name') or ''} — {r.get('status')} "
                        f"(строк {r.get('total')}, импорт {r.get('missing_count')}, конфликтов {r.get('conflicts_count')})"
                    )
            else:
                lines.append("История проверок пока пустая.")
            self.log_line("SQLite: " + " | ".join(lines[:3]))
            messagebox.showinfo("SAI SQLite", "\n".join(lines))
        except Exception as e:
            self.log_line(f"SQLite: ошибка статуса базы — {e}")
            messagebox.showerror("SAI SQLite", str(e))


    def open_private_config(self):
        try:
            path = save_private_config_template_if_missing()
            if hasattr(os, "startfile"):
                os.startfile(str(path))
            else:
                messagebox.showinfo("SAI", f"Приватный конфиг:\n{path}")
            self.log_line(f"Открыт приватный конфиг: {path}")
        except Exception as e:
            self.log_line(f"ОШИБКА открытия private config: {e}")
            messagebox.showerror("SAI", str(e))

    def check_sigma_api(self):
        cfg = load_private_config()
        company_key = str(cfg.get("sigma_company_key") or "").strip()
        api_token = str(cfg.get("sigma_api_token") or "").strip()

        if not company_key or not api_token:
            messagebox.showwarning(
                "SAI",
                "В user_data/sai_private_config.json не заполнены sigma_company_key и/или sigma_api_token."
            )
            self.log_line("API SIGMA: не заполнены ключ/токен в user_data/sai_private_config.json.")
            self.open_private_config()
            return

        self.log_line("Проверяю официальный API SIGMA...")
        threading.Thread(target=self._check_sigma_api_worker, args=(company_key, api_token), daemon=True).start()

    def _check_sigma_api_worker(self, company_key, api_token):
        """
        Extended official API probe.
        The first v1.5 check confirmed that auth works, but products/categories require parameters.
        Here we:
        - print full useful error messages;
        - read sell-points and extract ids;
        - brute-probe common parameter combinations for products/product-categories;
        - save working variants to api_probe_results.json.
        """
        base = f"https://api.sigma.ru/v1/companies/{company_key}"
        headers = {
            "Accept": "application/json",
            "X-Api-Key": api_token,
        }

        results = {
            "base": base,
            "sell_point_ids": [],
            "working": [],
            "errors": [],
            "checked_at": dt.datetime.now().isoformat(timespec="seconds"),
        }

        def clean_text(s, limit=1800):
            s = (s or "").replace("\r", " ").replace("\n", " ")
            s = re.sub(r"\s+", " ", s).strip()
            return s[:limit]

        def extract_message(resp):
            try:
                data = resp.json()
                if isinstance(data, dict):
                    msg = data.get("message") or data.get("error") or data.get("detail")
                    if msg:
                        return str(msg)
            except Exception:
                pass
            return clean_text(resp.text)

        def collect_ids(obj):
            ids = []
            names = []

            def walk(x):
                if isinstance(x, dict):
                    found_id = None
                    for key in ("id", "uuid", "sellPointId", "shopId", "pointId"):
                        val = x.get(key)
                        if isinstance(val, str) and val:
                            found_id = val
                            break
                    if found_id:
                        ids.append(found_id)
                        nm = x.get("name") or x.get("title") or x.get("displayName") or ""
                        names.append((found_id, str(nm)))
                    for v in x.values():
                        walk(v)
                elif isinstance(x, list):
                    for item in x:
                        walk(item)

            walk(obj)
            unique = []
            seen = set()
            for item in ids:
                if item not in seen:
                    seen.add(item)
                    unique.append(item)
            return unique, names

        def request(ep, params=None, timeout=20, retries=3):
            url = f"{base}/{ep}"
            req_headers = dict(headers)
            req_headers.setdefault("User-Agent", f"SAI-GUI/{APP_VERSION.lstrip('v')}")
            req_headers.setdefault("Connection", "close")
            last_error = None
            for attempt in range(1, max(1, int(retries or 1)) + 1):
                try:
                    return requests.get(url, headers=req_headers, params=params or {}, timeout=timeout)
                except (requests.exceptions.SSLError, requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
                    last_error = e
                    if attempt >= max(1, int(retries or 1)):
                        raise
                    self.queue.put(("log", f"API SIGMA {ep}: SSL/сеть оборвалась, повтор {attempt + 1}/{max(1, int(retries or 1))}..."))
                    time.sleep(min(5.0, 0.8 * attempt))
            if last_error:
                raise last_error
            raise RuntimeError(f"SIGMA API: request failed without response: {ep}")

        def log(msg):
            self.queue.put(("log", msg))

        log("API SIGMA: расширенная проверка. Полные ошибки 400 больше не обрезаются.")

        ok_count = 0

        # 1) Basic endpoints and sell-point discovery.
        for ep in ["sell-points", "units", "taxes"]:
            try:
                resp = request(ep)
                status = resp.status_code
                if 200 <= status < 300:
                    ok_count += 1
                    log(f"API SIGMA {ep}: OK {status}")
                    if ep == "sell-points":
                        try:
                            data = resp.json()
                            ids, named = collect_ids(data)
                            results["sell_point_ids"] = ids[:20]
                            if ids:
                                update_private_config({"sigma_sell_point_id": ids[0]})
                                log(f"API SIGMA sell-points: найдено id: {', '.join(ids[:5])}")
                                log(f"API SIGMA: первый sellPointId сохранён в private config.")
                            for sid, nm in named[:5]:
                                if nm:
                                    log(f"  sell-point: {nm} — id={sid}")
                        except Exception as e:
                            log(f"API SIGMA sell-points: не смог разобрать JSON — {str(e)[:180]}")
                else:
                    msg = extract_message(resp)
                    results["errors"].append({"endpoint": ep, "status": status, "message": msg})
                    log(f"API SIGMA {ep}: HTTP {status} — {msg}")
            except Exception as e:
                results["errors"].append({"endpoint": ep, "error": str(e)})
                log(f"API SIGMA {ep}: ОШИБКА — {str(e)[:300]}")

        sell_point_ids = results["sell_point_ids"][:3]

        # 2) Show why raw products/categories fail, with full meaningful message.
        for ep in ["product-categories", "products"]:
            try:
                resp = request(ep)
                status = resp.status_code
                if 200 <= status < 300:
                    log(f"API SIGMA {ep}: OK без параметров {status}")
                    results["working"].append({"endpoint": ep, "params": {}, "status": status, "mode": "raw"})
                else:
                    msg = extract_message(resp)
                    log(f"API SIGMA {ep}: HTTP {status} без параметров — {msg}")
                    results["errors"].append({"endpoint": ep, "params": {}, "status": status, "message": msg})
            except Exception as e:
                log(f"API SIGMA {ep}: ОШИБКА без параметров — {str(e)[:300]}")
                results["errors"].append({"endpoint": ep, "params": {}, "error": str(e)})

        # 3) Brute-probe common query parameters.
        base_param_variants = [
            {"limit": 1},
            {"page": 0, "size": 1},
            {"page": 0, "limit": 1},
            {"offset": 0, "limit": 1},
            {"from": 0, "limit": 1},
            {"revision": 0},
            {"revision": 0, "limit": 1},
            {"rev": 0},
            {"rev": 0, "limit": 1},
            {"fromRevision": 0},
            {"fromRevision": 0, "limit": 1},
            {"lastRevision": 0},
            {"lastRevision": 0, "limit": 1},
            {"updatedFrom": "1970-01-01T00:00:00.000Z"},
            {"updatedFrom": "1970-01-01T00:00:00.000Z", "limit": 1},
        ]

        sp_keys = ["sellPointId", "sellPointIds", "pointId", "shopId", "storeId", "departmentId", "warehouseId"]
        param_variants = list(base_param_variants)

        for sid in sell_point_ids:
            for key in sp_keys:
                param_variants.append({key: sid})
                for base_params in base_param_variants:
                    merged = dict(base_params)
                    merged[key] = sid
                    param_variants.append(merged)

        # De-duplicate while preserving order.
        dedup = []
        seen = set()
        for params in param_variants:
            key = tuple(sorted((str(k), str(v)) for k, v in params.items()))
            if key not in seen:
                seen.add(key)
                dedup.append(params)
        param_variants = dedup

        for ep in ["product-categories", "products"]:
            log(f"API SIGMA {ep}: подбираю обязательные параметры, вариантов: {len(param_variants)}")
            found = []
            first_errors = []

            for params in param_variants:
                try:
                    resp = request(ep, params=params, timeout=15)
                    status = resp.status_code
                    if 200 <= status < 300:
                        preview = ""
                        try:
                            data = resp.json()
                            if isinstance(data, list):
                                preview = f"list len={len(data)}"
                            elif isinstance(data, dict):
                                keys = list(data.keys())[:8]
                                preview = "dict keys=" + ",".join(keys)
                            else:
                                preview = type(data).__name__
                        except Exception:
                            preview = clean_text(resp.text, limit=200)

                        log(f"API SIGMA {ep}: НАЙДЕН РАБОЧИЙ ВАРИАНТ {status} params={params} [{preview}]")
                        found.append({"endpoint": ep, "params": params, "status": status, "preview": preview})
                        results["working"].append(found[-1])
                        break
                    else:
                        if len(first_errors) < 5:
                            first_errors.append({"params": params, "status": status, "message": extract_message(resp)})
                except Exception as e:
                    if len(first_errors) < 5:
                        first_errors.append({"params": params, "error": str(e)})

            if not found:
                log(f"API SIGMA {ep}: рабочий вариант не найден.")
                for er in first_errors[:5]:
                    log(f"  пример отказа: params={er.get('params')} status={er.get('status')} msg={er.get('message') or er.get('error')}")
                results["errors"].append({"endpoint": ep, "probe_failed": True, "examples": first_errors[:5]})

        # 4) Save results for the next development step.
        out = LOGS_DIR / "api_probe_results.json"
        try:
            out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
            log(f"API SIGMA: результаты проверки сохранены в {out}")
        except Exception as e:
            log(f"API SIGMA: не смог сохранить api_probe_results.json — {e}")

        if results["working"]:
            self.queue.put(("api_done", f"API SIGMA: найдено рабочих вариантов: {len(results['working'])}. Можно смотреть api_probe_results.json."))
        elif ok_count:
            self.queue.put(("api_done", f"API SIGMA отвечает, но параметры для товаров/категорий пока не подобраны. Базовых OK: {ok_count}/3."))
        else:
            self.queue.put(("api_done", "API SIGMA не подтвердился. Проверь ключ/токен или доступ."))


    def create_ndp(self, print_after=False):
        if not self.validate_basic(need_catalog=False):
            return
        self.save_config()
        log_path = self.last_log_path or str(find_latest_log(LOGS_DIR) or "")
        try:
            out_path, count = create_ndp_file(
                self.sai_path.get(),
                self.supplier_value_for_files(),
                self.invoice_date.get(),
                log_path=log_path if log_path else None,
            )
            self.last_ndp_path = out_path
            self.log_line(f"Создана Накладная для продавцов: {out_path}")
            self.log_line(f"Строк в НДП: {count}")

            if print_after:
                self.print_file(out_path)
                self.status_var.set("НДП создана и отправлена на печать.")
                messagebox.showinfo("SAI", f"НДП создана и отправлена на печать:\n{out_path}")
            else:
                self.status_var.set("НДП сохранена.")
                messagebox.showinfo("SAI", f"НДП сохранена:\n{out_path}")
            self.show_guide_step("finish")
        except Exception as e:
            self.status_var.set("Ошибка создания НДП.")
            self.log_line(f"ОШИБКА НДП: {e}")
            messagebox.showerror("Ошибка НДП", str(e))

    def print_file(self, path):
        path = str(path)
        try:
            cfg = load_private_config()
            printer = require_a4_printer_name(
                cfg.get("a4_printer") or cfg.get("document_printer") or cfg.get("price_tags_printer")
            )
            import ctypes
            rc = ctypes.windll.shell32.ShellExecuteW(None, "printto", path, f'"{printer}"', None, 0)
            if int(rc) <= 32:
                raise RuntimeError(f"Windows не принял задание печати (код {int(rc)}).")
            self.log_line(f"Файл A4 отправлен на обычный принтер «{printer}»: {path}")
        except Exception as e:
            self.log_line(f"ОШИБКА ПЕЧАТИ: {e}")
            messagebox.showwarning(
                "Печать",
                "Не получилось автоматически отправить файл на печать.\n"
                "Файл сохранён, открой его в Excel и напечатай вручную.\n\n"
                + path,
            )


if __name__ == "__main__":
    migrate_legacy_user_files()
    ensure_runtime_dirs()
    app = SAIApp()
    app.mainloop()
