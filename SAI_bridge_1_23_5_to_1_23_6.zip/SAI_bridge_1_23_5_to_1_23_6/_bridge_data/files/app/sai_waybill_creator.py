#!/usr/bin/env python
# -*- coding: utf-8 -*-

import argparse
import datetime as dt
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from sai_runtime_paths import APP_DIR, PRIVATE_CONFIG_PATH, CACHE_DIR
from sai_secret_store import reveal_config_secret

from playwright.sync_api import sync_playwright

from sai_direct_network import configure_direct_network, direct_chromium_args

configure_direct_network()

try:
    from sigma_autoprihod import (
        DEFAULT_API_BASE,
        DEFAULT_CLOUD_URL,
        SigmaClient,
        click_common_popups,
        install_sigma_token_capture,
        normalize_sigma_login,
        sigma_backend_login,
        wait_until_sigma_logged_in,
    )
except Exception as e:
    print(f"ERROR: не могу импортировать sigma_autoprihod.py: {e}", flush=True)
    raise


UUID_RE = re.compile(r"^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$", re.I)


def safe_str(value):
    return "" if value is None else str(value)


class LegacyRequestsSigmaClient:
    """Minimal SIGMA REST client backed by the emergency password grant."""

    def __init__(self, api_base: str, token: str):
        self.api_base = str(api_base or "").rstrip("/")
        self.token = str(token or "")

    def request(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        url = path if str(path).startswith(("http://", "https://")) else self.api_base + "/" + str(path).lstrip("/")
        from contextlib import nullcontext
        from sai_read_queue import read_slot, REFERENCE
        with read_slot(REFERENCE) if str(method or "GET").upper() == "GET" else nullcontext():
            response = requests.request(
                str(method or "GET").upper(),
                url,
                headers={"Authorization": "Bearer " + self.token, "Accept": "application/json"},
                json=body,
                timeout=45,
            )
        if not response.ok:
            raise RuntimeError(f"SIGMA HTTP {response.status_code}: {response.text[:240]}")
        if not response.text:
            return None
        try:
            return response.json()
        except Exception:
            return response.text


def _legacy_public_client_config(cloud_url: str) -> Tuple[str, str]:
    response = requests.get(cloud_url.rstrip("/") + "/configs/config.js", timeout=30)
    response.raise_for_status()
    text = response.text

    def setting(name: str) -> str:
        patterns = (
            rf'{re.escape(name)}\s*:\s*"([^"]+)"',
            rf"{re.escape(name)}\s*:\s*'([^']+)'",
        )
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        raise RuntimeError(f"SIGMA config.js не содержит {name}.")

    return setting("clientId"), setting("clientSecret")


def open_legacy_requests_client(
    api_base: str,
    cloud_url: str,
    sigma_login: str,
    sigma_password: str,
) -> LegacyRequestsSigmaClient:
    """Use SIGMA's own oldWayLogin password grant without browser automation."""
    login = normalize_sigma_login(sigma_login)
    password = str(sigma_password or "")
    if not login or not password:
        raise RuntimeError("Аварийный вход SIGMA не настроен.")
    backend_login = sigma_backend_login(login)
    client_id, client_secret = _legacy_public_client_config(cloud_url)
    response = requests.post(
        api_base.rstrip("/") + "/oauth/token",
        auth=(client_id, client_secret),
        data={
            "grant_type": "password",
            "scope": "read write",
            "username": backend_login,
            "password": password,
        },
        timeout=30,
    )
    if not response.ok:
        try:
            payload = response.json()
            reason = payload.get("error_description") or payload.get("error") or "AUTH_FAILED"
        except Exception:
            reason = "AUTH_FAILED"
        raise RuntimeError(f"Аварийный вход SIGMA отклонён: {str(reason)[:160]}")
    token = str((response.json() or {}).get("access_token") or "")
    if not token:
        raise RuntimeError("SIGMA не вернула access_token аварийного входа.")
    client = LegacyRequestsSigmaClient(api_base, token)
    client.request("GET", "/rest/1.1/account")
    save_runtime_token_cache(token, api_base)
    return client


def load_private_config():
    try:
        return json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_runtime_token_cache(token: str, api_base: str):
    try:
        from sai_sigma_session import save_session
        save_session(token, api_base, CACHE_DIR / "sigma_runtime_token.json")
    except Exception:
        pass


def open_recent_runtime_client(preferred_api_base: str, max_age_seconds: int = 4 * 3600):
    """Open a direct SIGMA client from the recent verified token cache.

    This is the normal fast path.  It deliberately validates the token with
    /account before any write; callers fall back to the browser login when the
    cache is missing, expired or rejected by SIGMA.
    """
    from sai_sigma_session import load_session
    payload = load_session(CACHE_DIR / "sigma_runtime_token.json")
    if not payload:
        raise RuntimeError("сохранённая сессия SIGMA отсутствует или истекла")
    token = safe_str(payload.get("token")).strip()
    api_base = safe_str(payload.get("api_base")).strip().rstrip("/")
    if not token:
        raise RuntimeError("в сохранённой сессии нет токена SIGMA")
    if not api_base:
        api_base = safe_str(preferred_api_base).strip().rstrip("/")
    if not api_base:
        raise RuntimeError("в сохранённой сессии нет адреса SIGMA API")
    client = LegacyRequestsSigmaClient(api_base, token)
    client.request("GET", "/rest/1.1/account")
    return client, api_base


def parse_date(value: str) -> dt.date:
    s = safe_str(value).strip()
    # SAI Package stores the invoice date in ISO form.  Check it before the
    # legacy dd-mm-yy matcher: without this guard, "2026-07-23" was matched
    # from the second character as "26-07-23" and became 26.07.2023.
    iso = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T].*)?", s)
    if iso:
        y, mo, d = iso.groups()
        return dt.date(int(y), int(mo), int(d))

    m = re.search(r"(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{2,4})", s)
    if m:
        d, mo, y = m.groups()
        y = int(y)
        if y < 100:
            y += 2000
        return dt.date(y, int(mo), int(d))

    digits = re.sub(r"\D+", "", s)
    if len(digits) >= 6:
        digits = digits[-6:]
        d = int(digits[:2])
        mo = int(digits[2:4])
        y = 2000 + int(digits[4:])
        return dt.date(y, mo, d)

    return dt.date.today()


def waybill_time_from_date(date_text: str) -> str:
    day = parse_date(date_text)
    now = dt.datetime.now()
    return f"{day.isoformat()} {now.hour:02d}:{now.minute:02d}:{now.second:02d}.{int(now.microsecond/1000):03d}"


def walk_json(value: Any, path: str = ""):
    if isinstance(value, dict):
        yield path, value
        for k, v in value.items():
            yield from walk_json(v, f"{path}.{k}" if path else str(k))
    elif isinstance(value, list):
        for i, v in enumerate(value):
            yield from walk_json(v, f"{path}[{i}]")


def collect_uuid_candidates(value: Any) -> List[Tuple[int, str, str]]:
    out = []
    seen = set()

    def score_path(path: str) -> int:
        p = path.lower()
        score = 0
        if "compan" in p or "organization" in p or "legal" in p or "shop" in p:
            score += 100
        if "current" in p or "selected" in p or "active" in p:
            score += 30
        if "user" in p or "employee" in p or "owner" in p:
            score -= 80
        if "sellpoint" in p or "sell_point" in p:
            score -= 20
        return score

    def rec(x: Any, path: str):
        if isinstance(x, str) and UUID_RE.match(x):
            if x not in seen:
                seen.add(x)
                out.append((score_path(path), path, x))
        elif isinstance(x, dict):
            for k, v in x.items():
                rec(v, f"{path}.{k}" if path else str(k))
        elif isinstance(x, list):
            for i, v in enumerate(x):
                rec(v, f"{path}[{i}]")

    rec(value, "")
    return sorted(out, reverse=True)


def extract_user(account: Any) -> Dict[str, Any]:
    # SIGMA accepts user object in waybill payload; this helper finds a safe minimal one.
    candidates = []
    for path, obj in walk_json(account):
        if not isinstance(obj, dict):
            continue
        uid = obj.get("id")
        email = obj.get("email")
        full = obj.get("fullName") or obj.get("name")
        if safe_str(uid) and (safe_str(email) or safe_str(full)):
            score = 0
            p = path.lower()
            if "user" in p or "account" in p:
                score += 50
            if "company" in p:
                score -= 30
            candidates.append((score, {"id": uid, "email": email, "fullName": full}))
    if candidates:
        candidates.sort(key=lambda x: x[0], reverse=True)
        return {k: v for k, v in candidates[0][1].items() if v is not None}
    return {}


def get_suppliers(client: SigmaClient, company_id: str) -> List[Dict[str, Any]]:
    data = client.request("GET", f"/rest/1.1/companies/{company_id}/suppliers")
    if isinstance(data, dict) and isinstance(data.get("suppliers"), list):
        return [x for x in data["suppliers"] if isinstance(x, dict)]
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    return []


def discover_company_id(client: SigmaClient, preferred: str = "") -> Tuple[str, List[Dict[str, Any]], Any]:
    account = None
    try:
        account = client.request("GET", "/rest/1.1/account")
    except Exception as e:
        print(f"company discovery: account read failed: {str(e)[:180]}", flush=True)

    candidates = []
    if preferred and UUID_RE.match(preferred):
        candidates.append((999, "private_config", preferred))

    cfg = load_private_config()
    for key in ("sigma_internal_company_id", "sigma_company_id", "company_id", "sigma_company_key"):
        val = safe_str(cfg.get(key)).strip()
        if val and UUID_RE.match(val):
            candidates.append((900, f"private_config.{key}", val))

    if account is not None:
        candidates.extend(collect_uuid_candidates(account))

    seen = set()
    for score, path, cid in candidates:
        if cid in seen:
            continue
        seen.add(cid)
        try:
            suppliers = get_suppliers(client, cid)
            if suppliers:
                print(f"company discovery: OK {path} -> suppliers={len(suppliers)}", flush=True)
                return cid, suppliers, account
            print(f"company discovery: {path} -> no suppliers", flush=True)
        except Exception as e:
            print(f"company discovery: {path} failed: {str(e)[:160]}", flush=True)

    raise RuntimeError("Не удалось определить companyId SIGMA для списка поставщиков.")


def simplify_suppliers(suppliers: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    simple = []
    for s in suppliers:
        sid = safe_str(s.get("id")).strip()
        name = safe_str(s.get("name")).strip()
        if sid and name:
            simple.append({"id": sid, "name": name})
    simple.sort(key=lambda x: x["name"].lower())
    return simple


def choose_supplier(suppliers: List[Dict[str, Any]], supplier_id: str = "", supplier_name: str = "") -> Dict[str, Any]:
    supplier_id = safe_str(supplier_id).strip()
    supplier_name = safe_str(supplier_name).strip().lower()

    if supplier_id:
        for s in suppliers:
            if safe_str(s.get("id")) == supplier_id:
                return s

    if supplier_name:
        exact = [s for s in suppliers if safe_str(s.get("name")).strip().lower() == supplier_name]
        if exact:
            return exact[0]
        contains = [s for s in suppliers if supplier_name in safe_str(s.get("name")).strip().lower()]
        if len(contains) == 1:
            return contains[0]

    raise RuntimeError("Поставщик не найден в списке SIGMA. Нажмите «Обновить поставщиков» и выберите из списка.")


def extract_storehouse_list(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ("data", "storehouses", "items", "content", "result"):
            val = data.get(key)
            if isinstance(val, list):
                return [x for x in val if isinstance(x, dict)]
    return []


def normalize_storehouse_obj(h: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "id": h.get("id"),
        "name": h.get("name"),
    }


def choose_storehouse(client: SigmaClient, company_id: str, preferred_storehouse_id: str = "") -> Dict[str, Any]:
    """
    SIGMA uses a special endpoint for waybill destination storehouses.
    v1.13 used /storehouses and could pick a storehouse that product search did not like.
    """
    preferred_storehouse_id = safe_str(preferred_storehouse_id).strip()
    endpoints = [
        f"/rest/v2/companies/{company_id}/storehouses/waybill?storehouseType=DESTINATION",
        f"/rest/v2/companies/{company_id}/storehouses",
    ]

    all_houses: List[Dict[str, Any]] = []
    errors = []

    for endpoint in endpoints:
        try:
            data = client.request("GET", endpoint)
            houses = [x for x in extract_storehouse_list(data) if safe_str(x.get("id"))]
            if houses:
                print(f"storehouse discovery: {endpoint} -> {len(houses)}", flush=True)
                all_houses = houses
                break
            errors.append(f"{endpoint}: empty")
        except Exception as e:
            errors.append(f"{endpoint}: {str(e)[:160]}")

    if not all_houses:
        raise RuntimeError("SIGMA не вернула склады/storehouses: " + "; ".join(errors))

    if preferred_storehouse_id:
        for h in all_houses:
            if safe_str(h.get("id")) == preferred_storehouse_id:
                return normalize_storehouse_obj(h)
        print(f"storehouse warning: preferred storehouse_id not found in waybill destination list: {preferred_storehouse_id}", flush=True)

    # Prefer explicit default/current flags when SIGMA sends them.
    for flag in ("isDefault", "default", "current", "selected"):
        for h in all_houses:
            if h.get(flag) is True:
                return normalize_storehouse_obj(h)

    return normalize_storehouse_obj(all_houses[0])



def create_waybill(client: SigmaClient, company_id: str, supplier: Dict[str, Any], invoice_date: str, storehouse_id: str = "") -> Dict[str, Any]:
    storehouse = choose_storehouse(client, company_id, storehouse_id)
    try:
        account = client.request("GET", "/rest/1.1/account")
    except Exception:
        account = {}
    user = extract_user(account)

    number = client.request("POST", f"/waybills/generate-waybill-number?waybillType=INCOME&companyId={company_id}")
    number = safe_str(number).strip().strip('"') or ""

    payload = {
        "waybillTime": waybill_time_from_date(invoice_date),
        "comment": "",
        "number": number,
        "isDefault": True,
        "storehouseDestination": storehouse,
        "storehouseSource": {"id": None, "name": None},
        "supplier": supplier,
        "type": "INCOME",
        "status": "DRAFT",
        "totalSum": 0,
        "egaisWaybillRegId": None,
        "serverTime": None,
    }
    if user:
        payload["user"] = user

    created = client.request("POST", "/waybills", payload)
    if not isinstance(created, dict) or not safe_str(created.get("id")):
        raise RuntimeError(f"SIGMA вернула неожиданный ответ при создании черновика: {str(created)[:500]}")

    # Some SIGMA responses omit the destination object even though the payload was accepted.
    # Keep it in the returned JSON for SAI, so the filling bot uses the same storehouse.
    if isinstance(created, dict):
        created.setdefault("storehouseDestination", storehouse)

    return created


def launch_persistent_sigma_context(playwright, user_data_dir: str, visible: bool, prefer_bundled_chromium: bool = True):
    """Launch SIGMA browser profile.

    prefer_bundled_chromium=True avoids a slow failed System Chrome probe on PCs
    where Chrome is not available to Playwright or is blocked by policy.
    """
    browser_kwargs = {
        "headless": not visible,
        "args": direct_chromium_args(["--start-maximized"] if visible else []),
    }
    user_data_dir = str(Path(user_data_dir).resolve())
    if prefer_bundled_chromium:
        return playwright.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            **browser_kwargs,
        )
    try:
        return playwright.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            channel="chrome",
            **browser_kwargs,
        )
    except Exception:
        print("System Chrome did not start, trying bundled Chromium.", flush=True)
        return playwright.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            **browser_kwargs,
        )


def open_sigma_context(
    user_data_dir: str,
    api_base: str,
    cloud_url: str,
    login_timeout: int,
    sigma_login: str,
    sigma_password: str,
    sigma_legacy_login: str = "",
    sigma_legacy_password: str = "",
    sigma_atol_max_attempts: int = 3,
    visible: bool = True,
    prefer_bundled_chromium: bool = True,
    hidden_auto_visible_after: int = 0,
):
    """Service context for supplier list / waybill creation.

    visible=True shows Chrome for manual login/control.
    visible=False starts headless first; if the saved session/token is not ready quickly,
    SAI closes the hidden browser and reopens a visible one so the user is not staring at
    a silent splash screen while ATOL/SIGMA wants attention.
    """
    attempts = []
    if visible:
        attempts.append((True, login_timeout, "видимый режим"))
    else:
        auto_visible_after = int(hidden_auto_visible_after or 0)
        quick_timeout = max(5, min(int(login_timeout or 300), auto_visible_after)) if auto_visible_after > 0 else int(login_timeout or 300)
        attempts.append((False, quick_timeout, "скрытый режим"))
        if auto_visible_after > 0:
            attempts.append((True, int(login_timeout or 300), "видимый режим после неудачного скрытого входа"))

    last_error = None
    for attempt_index, (attempt_visible, attempt_timeout, attempt_label) in enumerate(attempts, start=1):
        p = sync_playwright().start()
        context = None
        try:
            context = launch_persistent_sigma_context(
                p,
                user_data_dir,
                attempt_visible,
                prefer_bundled_chromium=prefer_bundled_chromium,
            )

            page = context.pages[0] if context.pages else context.new_page()
            install_sigma_token_capture(page)

            login_url = cloud_url.rstrip("/") + "/documents"
            print(f"Открываю SIGMA для входа/проверки сессии... ({attempt_label})", flush=True)
            try:
                page.goto(login_url, wait_until="domcontentloaded", timeout=60000)
            except Exception as e:
                print(f"Начальная навигация SIGMA прервана редиректом: {str(e)[:180]}", flush=True)

            ok = wait_until_sigma_logged_in(
                page,
                cloud_url,
                api_base,
                sigma_login=sigma_login,
                sigma_password=sigma_password,
                timeout_sec=attempt_timeout,
                legacy_login=sigma_legacy_login,
                legacy_password=sigma_legacy_password,
                atol_max_attempts=sigma_atol_max_attempts,
            )
            if not ok:
                raise RuntimeError("SIGMA не завершила вход за отведённое время.")

            click_common_popups(page, rounds=8)
            client = SigmaClient(page, api_base, cloud_url, verbose=False)
            token = client.get_api_access_token()
            if not token:
                raise RuntimeError("Не удалось получить токен SIGMA из браузера.")
            save_runtime_token_cache(token, api_base)
            print("SIGMA token captured and cached for faster API filling.", flush=True)
            return p, context, page, client
        except Exception as e:
            last_error = e
            try:
                if context is not None:
                    context.close()
            except Exception:
                pass
            try:
                p.stop()
            except Exception:
                pass
            if (not attempt_visible) and attempt_index < len(attempts):
                print(
                    f"Скрытая сессия SIGMA не стала готовой за {attempt_timeout} сек. "
                    "Открываю видимый браузер — возможно, SIGMA/АТОЛ просит вход.",
                    flush=True,
                )
                continue
            break
    raise RuntimeError(f"SIGMA не завершила вход. {str(last_error)[:240] if last_error else ''}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["list-suppliers", "create-waybill"], required=True)
    parser.add_argument("--user-data-dir", required=True)
    parser.add_argument("--api-base", default=DEFAULT_API_BASE)
    parser.add_argument("--cloud-url", default=DEFAULT_CLOUD_URL)
    parser.add_argument("--login-timeout", type=int, default=300)
    parser.add_argument("--sigma-login", default="")
    parser.add_argument("--sigma-password", default="")
    parser.add_argument("--sigma-legacy-login", default="")
    parser.add_argument("--sigma-legacy-password", default="")
    parser.add_argument("--sigma-atol-max-attempts", type=int, default=3)
    parser.add_argument("--company-id", default="")
    parser.add_argument("--storehouse-id", default="")
    parser.add_argument("--supplier-id", default="")
    parser.add_argument("--supplier-name", default="")
    parser.add_argument("--invoice-date", default="")
    parser.add_argument("--open-created", action="store_true")
    parser.add_argument("--visible-browser", action="store_true", help="Show SIGMA browser window")
    parser.add_argument("--hidden-browser", action="store_true", help="Run SIGMA browser headless when possible")
    parser.add_argument(
        "--manual-login",
        action="store_true",
        help="Always show the browser and wait for the user; never submit stored credentials",
    )
    parser.add_argument("--prefer-bundled-chromium", action="store_true", help="Skip System Chrome probe and use Playwright bundled Chromium")
    parser.add_argument("--hidden-auto-visible-after", type=int, default=0, help="When hidden browser cannot login quickly, reopen visible browser after N seconds; 0 = never")
    args = parser.parse_args()
    args.sigma_password = reveal_config_secret(args.sigma_password)
    args.sigma_legacy_password = reveal_config_secret(args.sigma_legacy_password)

    if args.manual_login:
        # This route is intentionally credential-blind. The user types ATOL ID
        # data only into SIGMA's own page; SAI waits for an authenticated session.
        args.sigma_login = ""
        args.sigma_password = ""
        args.sigma_legacy_login = ""
        args.sigma_legacy_password = ""
        args.visible_browser = True
        args.hidden_browser = False
        print(
            "SAI_MANUAL_LOGIN_WAITING: Войдите в SIGMA вручную. "
            "После успешного входа окно закроется автоматически.",
            flush=True,
        )

    visible = True
    if args.hidden_browser:
        visible = False
    elif args.visible_browser:
        visible = True

    p = context = page = None
    client = None
    rejected_token = ""
    if not args.manual_login:
        try:
            client, cached_api_base = open_recent_runtime_client(args.api_base)
            args.api_base = cached_api_base
            print("Быстрая сессия SIGMA готова — браузер не требуется.", flush=True)
        except Exception as e:
            from sai_sigma_session import load_session
            cached = load_session(CACHE_DIR / "sigma_runtime_token.json")
            if cached:
                if "HTTP 401" not in str(e):
                    # A network/server failure is not evidence that login expired.
                    raise
                rejected_token = cached["token"]
            print(
                "Быстрая сессия SIGMA недоступна: " + str(e)[:180] +
                ". Перехожу к обычному входу через браузер.",
                flush=True,
            )
    if client is None:
        def open_browser():
            return open_sigma_context(
                args.user_data_dir, args.api_base, args.cloud_url, args.login_timeout,
                args.sigma_login, args.sigma_password, args.sigma_legacy_login,
                args.sigma_legacy_password, args.sigma_atol_max_attempts,
                visible=visible, prefer_bundled_chromium=bool(args.prefer_bundled_chromium),
                hidden_auto_visible_after=args.hidden_auto_visible_after,
            )

        if args.manual_login:
            p, context, page, client = open_browser()
        else:
            from sai_sigma_session import SigmaSessionManager
            def login_for_manager():
                nonlocal p, context, page, client
                p, context, page, client = open_browser()
                return {"token": client.get_api_access_token(), "api_base": args.api_base}
            try:
                auth = SigmaSessionManager(CACHE_DIR / "sigma_runtime_token.json").ensure(
                    login_for_manager, rejected_token=rejected_token,
                )
                if client is None:
                    client = LegacyRequestsSigmaClient(auth["api_base"], auth["token"])
                args.api_base = auth["api_base"]
            except Exception:
                if context is not None:
                    context.close()
                if p is not None:
                    p.stop()
                raise

    try:
        company_id, suppliers, account = discover_company_id(client, args.company_id)
        simple = simplify_suppliers(suppliers)

        if args.mode == "list-suppliers":
            print(f"Поставщики SIGMA загружены: {len(simple)}", flush=True)
            if args.manual_login:
                print("SAI_MANUAL_LOGIN_OK", flush=True)
            print("SAI_SUPPLIERS_JSON:" + json.dumps({
                "company_id": company_id,
                "suppliers": simple,
            }, ensure_ascii=False), flush=True)
            return 0

        supplier = choose_supplier(suppliers, args.supplier_id, args.supplier_name)
        invoice_date = args.invoice_date or dt.date.today().strftime("%d.%m.%Y")
        print(f"Создаю черновик прихода: поставщик «{supplier.get('name')}», дата {invoice_date}", flush=True)

        created = create_waybill(client, company_id, supplier, invoice_date, args.storehouse_id)
        waybill_id = safe_str(created.get("id"))

        print(f"Черновик прихода создан: {waybill_id}", flush=True)
        storehouse_obj = created.get("storehouseDestination") if isinstance(created, dict) else {}
        if not isinstance(storehouse_obj, dict):
            storehouse_obj = {}
        print("SAI_WAYBILL_CREATED_JSON:" + json.dumps({
            "company_id": company_id,
            "waybill_id": waybill_id,
            "invoice_date": invoice_date,
            "supplier_id": supplier.get("id"),
            "supplier_name": supplier.get("name"),
            "storehouse_id": storehouse_obj.get("id"),
            "storehouse_name": storehouse_obj.get("name"),
            "waybill": created,
        }, ensure_ascii=False), flush=True)

        if args.open_created and waybill_id and page is not None:
            try:
                page.goto(f"{args.cloud_url.rstrip()}/documents/INCOME/one?id={waybill_id}", wait_until="domcontentloaded", timeout=60000)
                time.sleep(2)
                click_common_popups(page, rounds=4)
            except Exception as e:
                print(f"Черновик создан, но открыть страницу не удалось: {str(e)[:180]}", flush=True)

        return 0
    finally:
        # Не закрываем мгновенно при open-created: пусть пользователь увидит созданный черновик.
        if args.open_created and args.mode == "create-waybill":
            time.sleep(3)
        if context is not None:
            try:
                context.close()
            except Exception:
                pass
        if p is not None:
            try:
                p.stop()
            except Exception:
                pass


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Остановлено пользователем.", flush=True)
        raise SystemExit(130)
    except Exception as e:
        print(f"ERROR: {e}", flush=True)
        raise SystemExit(2)
