#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for v1.22.7bf premium hero, normalized rail and startup state."""
from __future__ import annotations

import ast
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
UI = APP / "sai_pyside_preview.py"
RECEIPT_HUB = APP / "sai_receipt_hub.py"


def static_tests() -> None:
    text = UI.read_text(encoding="utf-8-sig")
    ast.parse(text, filename=str(UI))
    hub_text = RECEIPT_HUB.read_text(encoding="utf-8-sig")
    ast.parse(hub_text, filename=str(RECEIPT_HUB))
    assert "AnimatedStartupSplash" not in text
    assert not (APP / "sai_intro.py").exists()
    assert "win.showMaximized()" in text
    assert "win.fit_to_available_screen(force=True)\n    win.show()" not in text
    assert '"assets" / "sai_logo_transparent.png"' in hub_text
    assert "painter.rotate(-13.0 + 4.0 * hover)" in hub_text
    assert "Fine constellation" in hub_text
    assert "self._motion_timer.setInterval(16)" in hub_text
    assert "from sai_ui_style import ui_polish_stylesheet" in text
    assert "+ ui_polish_stylesheet(dark)" in text
    assert "ReceiptWorkflowTracker" in text
    assert 'self.set_receipt_stage("draft")' in text
    assert 'self.set_receipt_stage("catalog")' in text
    assert 'self.set_receipt_stage("fact")' in text
    assert 'self.set_receipt_stage("apply")' in text
    assert 'self.set_receipt_stage("documents")' in text
    logo = APP / "assets" / "sai_logo_transparent.png"
    assert logo.is_file() and logo.stat().st_size > 100_000
    for mode in ("icons_light", "icons_dark"):
        for name in ("arrival.svg", "history.svg", "tag.svg", "marking.svg", "settings.svg", "panel-collapse.svg", "panel-expand.svg"):
            assert (APP / "assets" / mode / name).is_file(), (mode, name)


def runtime_tests() -> None:
    from PySide6.QtCore import QEvent, QPointF
    from PySide6.QtGui import QEnterEvent, QImage
    from PySide6.QtWidgets import QApplication

    sys.path.insert(0, str(APP))
    from sai_pyside_preview import NewReceiptHeroButton, RailIconButton
    from sai_ui_components import ReceiptWorkflowTracker

    app = QApplication.instance() or QApplication([])
    app.setProperty("saiNightTheme", False)

    hero = NewReceiptHeroButton("НОВЫЙ ПРИВОЗ", "Загрузить накладную и начать приёмку")
    hero.resize(1040, 172)
    hero.show()
    app.processEvents()
    assert not hero._logo.isNull()
    before = QImage(hero.size(), QImage.Format.Format_ARGB32)
    before.fill(0)
    hero.render(before)
    hero._hover_progress = 1.0
    hero._motion_phase = 0.7
    after = QImage(hero.size(), QImage.Format.Format_ARGB32)
    after.fill(0)
    hero.render(after)
    assert before != after
    assert before.pixelColor(before.width() - 80, before.height() // 2).alpha() > 0

    button = RailIconButton("history", "История")
    button.resize(196, 42)
    button.show()
    app.processEvents()
    assert button.icon_label.pixmap() is not None
    light_style = button.text_label.styleSheet()
    app.setProperty("saiNightTheme", True)
    button.refresh_theme()
    dark_style = button.text_label.styleSheet()
    assert light_style != dark_style

    marking = RailIconButton("marking", "Маркировка")
    marking.resize(196, 42)
    marking.show()
    app.processEvents()
    assert marking.icon_label.pixmap() is not None
    assert not marking.icon_label.pixmap().isNull()

    tracker = ReceiptWorkflowTracker()
    tracker.set_current("products")
    assert tracker.state("catalog") == "done"
    assert tracker.state("products") == "current"
    assert tracker.state("fact") == "pending"
    tracker.set_current("fact", skipped={"products"})
    assert tracker.state("products") == "skipped"
    assert tracker.state("fact") == "current"
    tracker.set_current("apply", error=True)
    assert tracker.state("apply") == "error"
    tracker.set_current("documents", complete=True)
    assert tracker.state("documents") == "done"

    tracker.close(); marking.close(); button.close(); hero.close(); app.processEvents()


def main() -> int:
    static_tests()
    runtime_tests()
    print("SAI UI polish tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
