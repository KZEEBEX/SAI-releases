#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sqlite3
import sys
import tempfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

from sai_core_v2.events import DomainEvent, EventBus
from sai_core_v2.migrations import Migration, applied_versions, run_migrations
from sai_core_v2.models import ReceiptDraft, ReceiptStage
from sai_core_v2.workflow import InvalidStageTransition, ReceiptWorkflow
from sai_core_v2.receipt_routing import (
    DraftResumeKind, ReceiptRouteKind, build_draft_resume_plan, build_receipt_route_plan, missing_barcode_indices,
    numeric_barcodes, receipt_quantity, resolve_prepared_receipt_path,
)
import sai_converter
import sai_receipt_drafts


def test_module_boundaries() -> None:
    main_text = (APP_DIR / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    assert "AnimatedStartupSplash" not in main_text
    assert not (APP_DIR / "sai_intro.py").exists()
    assert (APP_DIR / "sai_core_v2" / "file_drafts.py").is_file()
    assert (APP_DIR / "sai_core_v2" / "receipt_routing.py").is_file()
    assert (APP_DIR / "sai_core_v2" / "manual_receipt.py").is_file()
    assert (APP_DIR / "sai_manual_receipt.py").is_file()
    assert (APP_DIR / "sai_core_v2" / "semi_auto_receipt.py").is_file()
    assert (APP_DIR / "sai_semi_auto.py").is_file()
    assert "from sai_manual_receipt import ManualReceiptService" in main_text
    assert "from sai_semi_auto import SemiAutoReceiptService" in main_text
    assert (APP_DIR / "sai_receipt_hub.py").is_file()
    assert "from sai_receipt_hub import" in main_text
    for class_name in ("UxTwoLineButton", "DraftsTileButton", "NewReceiptHeroButton", "ReceiptDraftsDialog"):
        assert f"class {class_name}" not in main_text
    hub_text = (APP_DIR / "sai_receipt_hub.py").read_text(encoding="utf-8-sig")
    assert "class ReceiptDraftsDialog" in hub_text
    assert "class NewReceiptHeroButton" in hub_text
    facade = (APP_DIR / "sai_receipt_drafts.py").read_text(encoding="utf-8-sig")
    assert "FileReceiptDraftRepository" in facade
    assert len(facade.splitlines()) < 140


def test_workflow() -> None:
    assert ReceiptWorkflow.at(ReceiptStage.AI_REVIEW).can_move_to(ReceiptStage.SEMI_AUTO)
    assert ReceiptWorkflow.at(ReceiptStage.SEMI_AUTO).can_move_to(ReceiptStage.AUTOMATIC)
    assert ReceiptWorkflow.at(ReceiptStage.AUTOMATIC).can_move_to(ReceiptStage.COMPLETED)
    try:
        ReceiptWorkflow.at(ReceiptStage.COMPLETED).move_to(ReceiptStage.AI_REVIEW)
    except InvalidStageTransition:
        pass
    else:
        raise AssertionError("completed receipt must not return to AI review")
    model = ReceiptDraft.from_mapping({"id": "x", "kind": "ai", "status": "active", "stage": "semi_auto"})
    assert model.stage_label == "Нужны штрихкоды"



def test_receipt_routing() -> None:
    rows = [
        {"qty": "2", "barcodes": ["4601234567890"]},
        {"quantity": "3,5", "barcode_cell": ""},
        {"qty": 0, "barcode": ""},
        {"qty": 1, "ШК": "12345, 67890"},
    ]
    assert numeric_barcodes(rows[0]) == ("4601234567890",)
    assert numeric_barcodes(rows[3]) == ("12345", "67890")
    assert receipt_quantity(rows[1]) == 3.5
    assert missing_barcode_indices(rows) == (1,)
    semi = build_receipt_route_plan(Path("receipt.sai"), rows)
    assert semi.kind is ReceiptRouteKind.SEMI_AUTO
    assert semi.stage == "semi_auto" and semi.missing_count == 1 and semi.item_count == 4
    automatic = build_receipt_route_plan(Path("ready.sai"), [rows[0], rows[3]])
    assert automatic.kind is ReceiptRouteKind.AUTOMATIC
    assert not automatic.requires_barcode_completion
    with tempfile.TemporaryDirectory(prefix="sai_route_") as td:
        xlsx = Path(td) / "receipt.xlsx"
        xlsx.write_bytes(b"")
        sibling = xlsx.with_suffix(".sai")
        sibling.write_bytes(b"SAI")
        assert resolve_prepared_receipt_path(xlsx) == sibling
    manual = build_draft_resume_plan({"kind": "manual", "package_path": ""})
    assert manual.kind is DraftResumeKind.MANUAL
    packaged = build_draft_resume_plan({"kind": "ai", "package_path": "x.sai"})
    assert packaged.kind is DraftResumeKind.PACKAGE and packaged.package_path == Path("x.sai")


def test_event_bus() -> None:
    bus = EventBus()
    received: list[str] = []
    unsubscribe = bus.subscribe("receipt.saved", lambda event: received.append(event.payload["id"]))
    bus.publish(DomainEvent("receipt.saved", {"id": "a"}))
    unsubscribe()
    bus.publish(DomainEvent("receipt.saved", {"id": "b"}))
    assert received == ["a"]


def test_migration_ledger() -> None:
    con = sqlite3.connect(":memory:")
    calls: list[int] = []

    def m1(db: sqlite3.Connection) -> None:
        calls.append(1)
        db.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY)")

    assert run_migrations(con, [Migration(100, "sample", m1)]) == [100]
    assert run_migrations(con, [Migration(100, "sample", m1)]) == []
    assert 100 in applied_versions(con)
    assert calls == [1]


def test_draft_facade() -> None:
    with tempfile.TemporaryDirectory(prefix="sai_core_v2_drafts_") as td:
        root = Path(td)
        old_drafts = sai_receipt_drafts.DRAFTS_DIR
        old_manual = sai_receipt_drafts.MANUAL_AUTOSAVE
        sai_receipt_drafts.DRAFTS_DIR = root / "receipt_drafts"
        sai_receipt_drafts.MANUAL_AUTOSAVE = root / "manual.json"
        try:
            result = sai_converter.ConvertResult(
                source_path="invoice.pdf",
                source_type="AI",
                supplier="ООО ТЕСТ",
                date="2026-07-21",
                items=[
                    sai_converter.ConvertItem(
                        row=1,
                        name="ТЕСТОВЫЙ ТОВАР",
                        quantity=2,
                        purchase_price=10,
                        sale_price=20,
                        article="A-1",
                        barcodes=[],
                    )
                ],
            )
            meta = sai_receipt_drafts.save_result(result, stage="ai_review")
            assert Path(meta["package_path"]).is_file()
            updated = sai_receipt_drafts.update(meta["id"], stage="semi_auto")
            assert updated and updated["stage_label"] == "Нужны штрихкоды"
            sai_receipt_drafts.remove(meta["id"])
            assert sai_receipt_drafts.is_deleted(meta["id"])
            assert not sai_receipt_drafts.list_active()
        finally:
            sai_receipt_drafts.DRAFTS_DIR = old_drafts
            sai_receipt_drafts.MANUAL_AUTOSAVE = old_manual


def main() -> int:
    test_module_boundaries()
    test_workflow()
    test_receipt_routing()
    test_event_bus()
    test_migration_ledger()
    test_draft_facade()
    print("SAI Core v2 refactor tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
