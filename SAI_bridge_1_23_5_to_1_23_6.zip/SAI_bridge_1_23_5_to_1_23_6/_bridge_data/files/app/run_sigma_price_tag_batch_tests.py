#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression tests for safe bulk SIGMA updates from the price-tag list."""
from __future__ import annotations

from decimal import Decimal

from sai_sigma_price_tag_batch import (
    PriceTagCatalogChange,
    apply_price_tag_batch,
    normalize_price_tag_changes,
)
from sai_sigma_product_editor import ProductCardEditResult, SigmaProductEditError


def change(product_id: str, name: str, price: str) -> PriceTagCatalogChange:
    return PriceTagCatalogChange(
        product_id=product_id,
        name=name,
        price=Decimal(price),
        vendor_code=f"ART-{product_id}",
        barcodes=(f"46000000000{product_id[-1]}",),
    )


class FakeEditor:
    def __init__(self, fail_product: str = ""):
        self.fail_product = fail_product
        self.values = {
            "product-1": ("СТАРОЕ 1", Decimal("10")),
            "product-2": ("СТАРОЕ 2", Decimal("20")),
        }
        self.apply_calls = []

    def _card(self, product_id):
        name, price = self.values[product_id]
        return {
            "id": f"menu-{product_id}",
            "name": name,
            "vendorCode": f"ART-{product_id}",
            "variations": [{
                "price": {"value": float(price)},
                "barcodes": (f"46000000000{product_id[-1]}",),
            }],
        }

    def prepare(self, product_id, changes):
        original = self._card(product_id)
        return original, {}, {}, ("name", "price")

    def apply(self, product_id, changes):
        self.apply_calls.append((
            product_id, changes.name, changes.price,
            changes.vendor_code, changes.barcodes,
        ))
        if product_id == self.fail_product and changes.name.startswith("НОВОЕ"):
            raise SigmaProductEditError("planned")
        before = self.values[product_id]
        after = (changes.name, Decimal(changes.price))
        self.values[product_id] = after
        changed = before != after
        return ProductCardEditResult(
            product_id,
            f"menu-{product_id}",
            ("name", "price") if changed else (),
            changed,
            changed,
        )


def main() -> int:
    rows = (change("product-1", "НОВОЕ 1", "15"), change("product-2", "НОВОЕ 2", "25"))
    assert normalize_price_tag_changes(rows) == rows

    editor = FakeEditor()
    result = apply_price_tag_batch(rows, editor=editor)
    assert result.requested == 2 and result.changed == 2 and result.verified == 2
    assert editor.values["product-1"] == ("НОВОЕ 1", Decimal("15"))
    assert editor.values["product-2"] == ("НОВОЕ 2", Decimal("25"))
    assert editor.apply_calls[0][3] == "ART-product-1"
    assert editor.apply_calls[0][4] == ("460000000001",)

    stale = change("product-1", "НОВОЕ 1", "15")
    stale = PriceTagCatalogChange(
        stale.product_id, stale.name, stale.price,
        "УСТАРЕВШИЙ-АРТИКУЛ", ("99999999",),
    )
    preserve = FakeEditor()
    apply_price_tag_batch((stale,), editor=preserve)
    assert preserve.apply_calls[0][3] == "ART-product-1"
    assert preserve.apply_calls[0][4] == ("460000000001",)

    rollback = FakeEditor(fail_product="product-2")
    try:
        apply_price_tag_batch(rows, editor=rollback)
    except SigmaProductEditError as exc:
        assert "обратный откат" in str(exc)
    else:
        raise AssertionError("partial failure must stop the batch")
    assert rollback.values["product-1"] == ("СТАРОЕ 1", Decimal("10"))
    assert rollback.values["product-2"] == ("СТАРОЕ 2", Decimal("20"))

    try:
        normalize_price_tag_changes((
            change("product-1", "ОДНО ИМЯ", "10"),
            change("product-1", "ДРУГОЕ ИМЯ", "11"),
        ))
    except SigmaProductEditError:
        pass
    else:
        raise AssertionError("conflicting duplicate rows must be rejected")

    try:
        normalize_price_tag_changes((
            PriceTagCatalogChange("", "БЕЗ СВЯЗИ", Decimal("10"), "", ("12345678",)),
        ))
    except SigmaProductEditError:
        pass
    else:
        raise AssertionError("unlinked price tag must be rejected")

    print("SAI SIGMA price-tag batch tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
