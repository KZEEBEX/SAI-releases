"""Validate an isolated source copy while the owner's SAI may remain open."""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def main():
    root = Path(__file__).resolve().parent.parent
    reports = root / "tmp" / "optimization_validation"
    reports.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="sai_dev_shadow_") as temporary:
        shadow = Path(temporary) / "SAI"
        ignore = shutil.ignore_patterns(".venv", "__pycache__", "cache", "logs", "Profile", "*.pyc", "sai_private_config.json", "sai_config.json")
        shutil.copytree(root / "app", shadow / "app", ignore=ignore)
        shutil.copytree(root / "config", shadow / "config", ignore=ignore)
        for source in root.iterdir():
            if source.is_file() and source.suffix.lower() in (".py", ".cmd", ".vbs", ".md", ".ico"):
                shutil.copy2(source, shadow / source.name)
        env = os.environ.copy()
        env.update({
            "SAI_USER_DATA_DIR": str(shadow / "user_data"),
            "SAI_PROFILE_DIR": str(shadow / "user_data" / "Profile"),
            "SAI_TEST_FORBIDDEN_DATA_DIR": str(root / "user_data"),
            "PYTHONPATH": str(shadow / "app" / "test_support"),
            "QT_QPA_PLATFORM": "offscreen", "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONUNBUFFERED": "1",
            "SAI_UI_SNAPSHOT_DIR": str(reports / "screenshots"),
        })
        with (reports / "acceptance.log").open("w", encoding="utf-8") as log:
            result = subprocess.run(
                [sys.executable, str(shadow / "app" / "run_patch_acceptance.py"), "--root", str(shadow),
                 "--python", sys.executable, "--keep-going", "--report", str(reports / "acceptance.json")],
                cwd=shadow, env=env, stdout=log, stderr=subprocess.STDOUT,
            )
        print(f"Validation exit: {result.returncode}; report: {reports}")
        return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
