#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Install the minimal GitHub bootstrap into an existing SAI 1.23.1."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import sys
import traceback
from pathlib import Path


HOOK = (
    "        from sai_github_bootstrap import maybe_install_available_update\n"
    "        if maybe_install_available_update(APP_VERSION, console=args.console):\n"
    "            return 0\n"
)
ANCHOR = "        _backup_database_once_per_day()\n"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def version(root: Path) -> str:
    text = (root / "app" / "sai_version.py").read_text(encoding="utf-8-sig", errors="replace")
    match = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
    return match.group(1).strip().lstrip("v") if match else ""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--no-launch", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    root = args.target.resolve()
    log_path = package / "SAI_GITHUB_BOOTSTRAP_LAST_LOG.txt"

    def log(value: object = "") -> None:
        text = str(value)
        print(text, flush=True)
        with log_path.open("a", encoding="utf-8") as stream:
            stream.write(text + "\n")

    log_path.write_text("SAI GitHub bootstrap patch\n", encoding="utf-8")
    backup = root / "user_data" / "backups" / ("github_bootstrap_" + dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
    try:
        installed = version(root)
        if installed != "1.23.1":
            raise RuntimeError(f"Патч предназначен для SAI 1.23.1; найдена версия {installed or 'неизвестно'}.")
        launcher = root / "app" / "sai_launcher.py"
        if not launcher.is_file():
            raise RuntimeError("Не найден app\\sai_launcher.py.")
        payload = package / "_bootstrap_data"
        manifest = json.loads((payload / "manifest.json").read_text(encoding="utf-8"))
        for item in manifest.get("files") or []:
            source = payload / str(item["name"])
            if not source.is_file() or source.stat().st_size != int(item["size"]) or sha256(source) != item["sha256"]:
                raise RuntimeError(f"Повреждён файл микропатча: {item['name']}")

        backup.mkdir(parents=True, exist_ok=False)
        shutil.copy2(launcher, backup / "sai_launcher.py")
        for name in ("sai_github_updates.py", "sai_github_bootstrap.py"):
            destination = root / "app" / name
            if destination.is_file():
                shutil.copy2(destination, backup / name)
            temporary = destination.with_suffix(".py.bootstrap.tmp")
            shutil.copy2(payload / name, temporary)
            os.replace(temporary, destination)

        text = launcher.read_text(encoding="utf-8-sig")
        if "maybe_install_available_update(APP_VERSION" not in text:
            if ANCHOR not in text:
                raise RuntimeError("Структура sai_launcher.py отличается от ожидаемой; изменения отменены.")
            text = text.replace(ANCHOR, HOOK + ANCHOR, 1)
            temporary = launcher.with_suffix(".py.bootstrap.tmp")
            temporary.write_text(text, encoding="utf-8")
            os.replace(temporary, launcher)
        installed_launcher = launcher.read_text(encoding="utf-8-sig")
        if installed_launcher.count("maybe_install_available_update(APP_VERSION") != 1:
            raise RuntimeError("Проверка обновлений не встроилась в реальный launcher SAI.")
        compile(installed_launcher, str(launcher), "exec")
        for name in ("sai_github_updates.py", "sai_github_bootstrap.py"):
            compile((root / "app" / name).read_text(encoding="utf-8-sig"), name, "exec")

        # Bootstrap V1 could cache a check made before the release existed.
        state_path = root / "user_data" / "github_update_bootstrap.json"
        try:
            state_path.unlink(missing_ok=True)
        except OSError:
            pass

        sys.path.insert(0, str(root / "app"))
        import sai_github_updates
        available = sai_github_updates.check_for_update("v" + installed, channel="production")
        if available is None:
            raise RuntimeError("GitHub доступен, но production-релиз новее 1.23.1 не найден.")
        (backup / "PATCH_REPORT.json").write_text(json.dumps({
            "status": "INSTALLED",
            "source_version": installed,
            "repository": "KZEEBEX/SAI-releases",
            "installed_at": dt.datetime.now().astimezone().isoformat(),
            "available_version": available.version,
            "launcher": str(launcher),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        log(f"Готово. Реальный launcher подключён; GitHub предлагает SAI {available.version}.")
        if not args.no_launch:
            starter = next((path for path in (
                root / "Start SAI Hub.vbs",
                root / "Запустить SAI Hub.vbs",
                root / "START_SAI.cmd",
            ) if path.is_file()), None)
            if starter is None:
                raise RuntimeError("Патч установлен, но реальный файл запуска SAI не найден.")
            os.startfile(str(starter))  # type: ignore[attr-defined]
            log("SAI запущен: сейчас должна появиться проверка обновления.")
        return 0
    except Exception as exc:
        log("ОШИБКА: " + str(exc))
        log(traceback.format_exc())
        if backup.is_dir():
            saved_launcher = backup / "sai_launcher.py"
            if saved_launcher.is_file():
                shutil.copy2(saved_launcher, root / "app" / "sai_launcher.py")
            for name in ("sai_github_updates.py", "sai_github_bootstrap.py"):
                saved = backup / name
                destination = root / "app" / name
                if saved.is_file():
                    shutil.copy2(saved, destination)
                elif destination.exists():
                    destination.unlink()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
