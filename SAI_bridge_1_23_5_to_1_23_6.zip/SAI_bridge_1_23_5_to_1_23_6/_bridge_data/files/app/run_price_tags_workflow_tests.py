#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Runtime acceptance for the fast editable price-tags workflow."""
from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_price_tags_ui_")

APP = Path(__file__).resolve().parent
sys.path.insert(0, str(APP))

from PySide6.QtWidgets import QApplication

import sai_pyside_preview as ui
import sai_price_tag_sigma_ui as sigma_ui


class Parent:
    def __init__(self) -> None:
        self.messages = []

    def notify(self, title, text, kind="info") -> None:
        self.messages.append((title, text, kind))


class FastCatalog:
    catalog_ready = True

    def search(self, **kwargs):
        query = str(kwargs.get("name_query") or "")
        if not query:
            return []
        if query == "99999999":
            return []
        return [{
            "id": "product-1",
            "name": "МОЛОТОК СТАЛЬНОЙ",
            "vendor_code": "ART-77",
            "barcodes": ["4601234567893"],
            "price": 250,
            "unit": "штука",
            "exact_barcode_match": query.isdigit(),
        }]


def main() -> int:
    app = QApplication.instance() or QApplication([])
    parent = Parent()
    page = ui.PriceTagsPage(parent)
    page.catalog_service = FastCatalog()

    assert page.name_edit.placeholderText() == "Наименование / ШК / артикул"
    assert page.table.columnCount() == 6
    assert page.accent_edit.placeholderText().startswith("Например:")
    assert page.print_all_btn.text() == "Обновить SIGMA и напечатать"
    assert page.table.editTriggers()
    assert page.table.property("saiInlineEdit") is True

    page.name_edit.setText("99999999")
    page.run_product_search()
    assert page.pending_unknown_barcode == "99999999"
    assert not page.add_missing_barcode_btn.isHidden()
    page.add_missing_barcode()
    assert page.current_barcode == "99999999"
    assert page.name_edit.text() == ""
    page.clear_manual_form()

    page.mass_scan_switch.setChecked(True)
    assert not page.mass_unknown_panel.isHidden()
    assert page.accent_edit.isHidden()
    page.name_edit.setText("4601234567893")
    page.run_product_search()
    app.processEvents()
    assert len(page.items) == 1
    assert page.items[0]["barcode"] == "4601234567893"
    assert page.name_edit.text() == ""
    page.name_edit.setText("99999999")
    page.run_product_search()
    app.processEvents()
    assert page.mass_unknown_barcodes == ["99999999"]
    assert "99999999" in page.mass_unknown_text.text()
    assert page.name_edit.text() == ""
    page.mass_scan_switch.setChecked(False)
    page.remove_price_tag_row(0)

    page.name_edit.setText("ART-77")
    page.run_product_search()
    assert page.search_results and page.search_results[0]["name"] == "МОЛОТОК СТАЛЬНОЙ"
    page.apply_product_result(page.search_results[0])
    assert page.current_barcode == "4601234567893"
    assert page.barcode_status.text() == "ШК: 4601234567893"
    assert not page.add_missing_barcode_btn.isVisible()

    page.accent_edit.setText("УСИЛЕННЫЙ")
    page.add_manual_tag()
    assert len(page.items) == 1
    assert page.items[0]["sigma_product_id"] == "product-1"
    assert page.items[0]["accent_text"] == "УСИЛЕННЫЙ"
    assert page.table.item(0, 1).text() == "УСИЛЕННЫЙ"
    assert page.table.cellWidget(0, 5) is not None
    page.table.item(0, 0).setText("МОЛОТОК УСИЛЕННЫЙ")
    app.processEvents()
    assert page.items[0]["name"] == "МОЛОТОК УСИЛЕННЫЙ"
    page.table.item(0, 3).setText("275")
    app.processEvents()
    assert page.items[0]["price"] == 275

    opened = []
    printed = []
    with tempfile.TemporaryDirectory(prefix="sai_price_tags_print_") as temporary:
        output = Path(temporary) / "tags.pdf"
        old_unique = ui._unique_desktop_path
        old_create = ui.create_price_tags_pdf
        old_open = ui.open_path
        old_print = ui.print_price_tags_a4
        old_warning = ui.QMessageBox.warning
        old_batch = sigma_ui.apply_price_tag_batch
        old_question = sigma_ui.QMessageBox.question
        ui._unique_desktop_path = lambda *_args, **_kwargs: output
        ui.create_price_tags_pdf = lambda items, path: (Path(path).write_bytes(b"%PDF-test") and Path(path))
        ui.open_path = lambda path: opened.append(Path(path))
        ui.print_price_tags_a4 = lambda items, printer_name="": (
            printed.append((len(items), printer_name)) or "A4 TEST PRINTER"
        )
        sigma_ui.apply_price_tag_batch = lambda changes: SimpleNamespace(
            requested=len(changes), changed=len(changes), verified=len(changes),
        )
        sigma_ui.QMessageBox.question = lambda *_args, **_kwargs: sigma_ui.QMessageBox.Yes
        try:
            page.print_price_tags_now()
            deadline = time.monotonic() + 5
            while page._sigma_batch_job and time.monotonic() < deadline:
                app.processEvents()
                time.sleep(0.02)
            app.processEvents()
            assert opened == []
            assert printed and printed[0][0] == 1

            blocked_prints = []
            blocked_messages = []
            real_verified_print = page._print_verified_price_tags
            real_critical = sigma_ui.QMessageBox.critical
            page._print_verified_price_tags = lambda: blocked_prints.append(True)
            sigma_ui.QMessageBox.critical = lambda *_args, **_kwargs: blocked_messages.append(_args)
            page._sigma_batch_job = {
                "done": True,
                "error": None,
                "result": SimpleNamespace(requested=1, changed=1, verified=0),
                "changes": (),
            }
            page._poll_price_tag_sigma_batch()
            assert blocked_prints == []
            assert blocked_messages and "0 из 1" in str(blocked_messages[-1])
            page._print_verified_price_tags = real_verified_print
            sigma_ui.QMessageBox.critical = real_critical

            warnings = []
            ui.print_price_tags_a4 = lambda *_args, **_kwargs: (_ for _ in ()).throw(
                RuntimeError("printer rejected test job")
            )
            ui.QMessageBox.warning = lambda *_args, **_kwargs: warnings.append(_args)
            page._print_verified_price_tags()
            assert opened == [output]
            assert warnings and "printer rejected test job" in str(warnings[-1])
        finally:
            ui._unique_desktop_path = old_unique
            ui.create_price_tags_pdf = old_create
            ui.open_path = old_open
            ui.print_price_tags_a4 = old_print
            ui.QMessageBox.warning = old_warning
            sigma_ui.apply_price_tag_batch = old_batch
            sigma_ui.QMessageBox.question = old_question
    assert parent.messages and parent.messages[-1][2] == "success"
    assert page._sigma_batch_job is None

    page.remove_price_tag_row(0)
    assert page.items == []
    assert not page.print_all_btn.isEnabled()
    source = (APP / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    section = source[source.index("class PriceTagsPage"):source.index("class WelcomeDialog")]
    assert "SELECT sigma_id" not in section
    assert "self.catalog_service.search(" in section
    assert "non_blocking=True" in section
    assert "self.catalog_service = shared_free_catalog_service()" in section
    assert 'self.setProperty("saiInlineEdit"' not in section
    assert 'self.table.setProperty("saiInlineEdit", True)' in section
    assert 'QLabel("1. SAI-файл")' not in section
    assert 'QPushButton("Удалить выбранный")' not in section
    assert '"stock": "mdi/package-variant-closed.svg"' in source
    assert "print_file_to_windows_printer" not in section
    assert "print_price_tags_a4(print_items, configured_printer)" in section
    assert "open_path(self.last_pdf_path)" in section  # automatic-print failure fallback only
    assert (APP / "assets" / "icons" / "mdi" / "package-variant-closed.svg").is_file()
    page.close()
    app.processEvents()
    print("SAI price-tags workflow tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
