#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sqlite3
import tempfile
import time
from contextlib import closing
from decimal import Decimal
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QDialog, QPushButton
from PySide6.QtCore import Qt, QTimer
from PySide6.QtTest import QTest

from sai_core_v2.accounts import (
    ACCOUNT_ADMIN_MIGRATIONS, ACCOUNT_MIGRATIONS, get_user, has_module,
    module_access, set_password, verify_password,
)
from sai_core_v2.migrations import run_migrations
from sai_secret_store import protect_secret, reveal_secret
from sai_stock import StockService
from sai_stock_ui import WarehousePage


def main() -> None:
    preview_source = (Path(__file__).parent / "sai_pyside_preview.py").read_text(encoding="utf-8")
    assert 'add_rail_button("stock_btn", "stock", "Склад", self.show_stock)' in preview_source
    assert "Кабинет" not in preview_source and "def show_admin(self)" not in preview_source
    assert "self.openai_key_edit" not in preview_source
    assert "self.openai_model_edit" not in preview_source and "self.openai_proxy_edit" not in preview_source
    assert "AccountService().effective_owner_ai_configuration()" in preview_source
    admin_source = (Path(__file__).parent / "sai_admin.py").read_text(encoding="utf-8")
    assert "class AdminWindow" in admin_source and "moduleState" in admin_source and "delete_api_key" in admin_source
    con = sqlite3.connect(":memory:")
    con.execute("PRAGMA foreign_keys=ON")
    assert run_migrations(con, ACCOUNT_MIGRATIONS) == [5]
    assert run_migrations(con, ACCOUNT_ADMIN_MIGRATIONS) == [6, 7]
    owner = get_user(con, "MIKE")
    assert owner and owner.role == "owner" and owner.status == "pending_activation"
    assert owner.modules == ("stock",) and has_module(con, "mike", "stock")
    con.execute("UPDATE module_entitlements SET status='inactive' WHERE user_id=? AND module_code='stock'", (owner.user_id,))
    assert has_module(con, "mike", "stock"), "legacy inactive entitlement must not disable core stock"
    set_password(con, "mike", "correct horse battery")
    assert verify_password(con, "Mike", "correct horse battery")
    assert not verify_password(con, "mike", "wrong password")
    stored = con.execute("SELECT password_hash FROM sai_users WHERE username='mike'").fetchone()[0]
    assert stored != "correct horse battery" and len(stored) == 64
    modules = module_access(con, owner.user_id)
    assert len(modules) >= 6 and any(item.code == "stock" and item.enabled for item in modules)
    encrypted = protect_secret("sk-test-12345678901234567890")
    assert "sk-test" not in encrypted
    assert reveal_secret(encrypted) == "sk-test-12345678901234567890"

    import sai_db
    with tempfile.TemporaryDirectory(prefix="sai_account_ui_") as temporary:
        sai_db.DB_PATH = Path(temporary) / "sai.db"
        sai_db.init_db()
        sai_db.save_catalog(
            {
                "products_by_id": {
                    "milk-1": {
                        "id": "milk-1",
                        "name": "Молоко тестовое",
                        "vendor_code": "MILK-01",
                        "barcodes": ["460000000001"],
                        "raw": {"sellingPrice": 89.5},
                    }
                }
            },
            "test-company",
            "test-point",
        )
        legacy = sai_db.connect()
        try:
            legacy.execute("UPDATE module_entitlements SET status='inactive' WHERE module_code='stock'")
            legacy.commit()
        finally:
            legacy.close()
        with closing(sai_db.connect()) as stock_connection:
            stock_service = StockService(stock_connection)
            stock_service.ensure_location("main-store", "Основной магазин")
        app = QApplication.instance() or QApplication([])
        from sai_accounts import AccountService
        from sai_admin import ADMIN_STYLE, AdminWindow, ModuleTile
        from sai_ui_style import ui_polish_stylesheet
        app.setStyleSheet(ui_polish_stylesheet(False) + ADMIN_STYLE)
        service = AccountService(); warehouse = WarehousePage(); admin = AdminWindow(service)
        admin.show(); app.processEvents()
        assert warehouse.balance_table.columnCount() == 5
        assert warehouse.location_combo.currentData() == "main-store"
        assert warehouse.balance_table.rowCount() == 1
        assert warehouse.balance_table.item(0, 0).text() == "Молоко тестовое"
        assert warehouse.balance_table.item(0, 3).text() == "89,50 ₽"
        assert warehouse.balance_table.item(0, 4).text() == "—"
        warehouse.balance_table.selectRow(0); app.processEvents()
        assert warehouse.receipt_action.isEnabled() and warehouse.writeoff_action.isEnabled()
        assert warehouse.operations_btn.isEnabled() and warehouse.timeline_btn.isEnabled()
        warehouse.balance_cell_double_clicked(0, 2)
        assert QApplication.clipboard().text() == "460000000001"
        assert warehouse.balance_table.item(0, 0).data(Qt.UserRole + 1) == "milk-1"
        # The visible cell may elide barcodes; the dashboard must retain all.
        codes = ("000000000001", "000000000002", "000000000003", "000000000004")
        barcode_item = warehouse.balance_table.item(0, 0)
        previous_codes = barcode_item.data(Qt.UserRole + 2)
        barcode_item.setData(Qt.UserRole + 2, codes)
        dashboard_result = []
        def inspect_dashboard():
            dialog = QApplication.activeModalWidget()
            try:
                assert isinstance(dialog, QDialog)
                copy_button = next(b for b in dialog.findChildren(QPushButton) if b.text() == "Копировать ШК")
                QTest.mouseClick(copy_button, Qt.LeftButton)
                dashboard_result.append(QApplication.clipboard().text())
            finally:
                if isinstance(dialog, QDialog):
                    dialog.accept()
        QTimer.singleShot(0, inspect_dashboard)
        warehouse.open_product_timeline()
        assert dashboard_result == ["\n".join(codes)]
        barcode_item.setData(Qt.UserRole + 2, previous_codes)
        warehouse.post_selected_movement("receipt", Decimal("10"), "Первичный остаток")
        warehouse.balance_table.selectRow(0); app.processEvents()
        assert warehouse.balance_table.item(0, 4).text() == "10"
        warehouse.post_selected_movement("writeoff", Decimal("2"), "Порча")
        warehouse.balance_table.selectRow(0); app.processEvents()
        assert warehouse.balance_table.item(0, 4).text() == "8"
        warehouse.post_selected_movement("adjustment", Decimal("5"), "Пересчёт")
        assert warehouse.balance_table.item(0, 4).text() == "5"
        assert warehouse.movement_table.rowCount() == 3
        warehouse.search.setText("460000000001"); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        warehouse.search.setText("мол тест"); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        warehouse.search.setText("MILK-01"); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        warehouse.search.setText("89,5"); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        with closing(sai_db.connect()) as stock_connection:
            stock_service = StockService(stock_connection)
            product_id = stock_service.stock_rows("main-store")[0]["sai_product_id"]
            try:
                stock_service.post_manual(
                    sai_product_id=product_id, location_id="main-store",
                    operation="writeoff", quantity=Decimal("6"),
                )
            except ValueError:
                pass
            else:
                raise AssertionError("write-off above current balance must be rejected")
        bulk_products = {
            f"bulk-{index}": {
                "id": f"bulk-{index}",
                "name": f"Товар быстрый тест {index}",
                "vendor_code": f"ART-{index:05d}",
                "barcodes": [f"4609{index:09d}"],
                "raw": {"sellingPrice": index + 0.5},
            }
            for index in range(6000)
        }
        sai_db.save_catalog(
            {"products_by_id": bulk_products}, "performance-company", "performance-point",
        )
        started = time.perf_counter(); warehouse.search.clear(); warehouse.refresh(); app.processEvents()
        refresh_elapsed = time.perf_counter() - started
        assert refresh_elapsed < 3.0, f"large catalog refresh took {refresh_elapsed:.2f}s"
        assert len(warehouse._catalog_rows) == 6001 and warehouse.balance_table.rowCount() == 250
        started = time.perf_counter(); warehouse.refresh(); app.processEvents()
        cached_refresh_elapsed = time.perf_counter() - started
        assert cached_refresh_elapsed < 0.75, f"cached warehouse entry took {cached_refresh_elapsed:.2f}s"
        warehouse.search.clear(); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 250
        # Keep keystrokes comfortably inside the 180 ms debounce window.
        # An 80 ms synthetic delay becomes flaky under a heavily loaded full suite.
        QTest.keyClicks(warehouse.search, "ART-05999", Qt.NoModifier, 20)
        assert warehouse.search_timer.isActive()
        assert warehouse.balance_table.rowCount() == 250, "results must not redraw while the user is typing"
        QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        started = time.perf_counter()
        warehouse.search.setText("4609000005999")
        QTest.keyClick(warehouse.search, Qt.Key_Return); app.processEvents()
        assert time.perf_counter() - started < 0.2
        assert warehouse.balance_table.rowCount() == 1 and not warehouse.search_timer.isActive()
        started = time.perf_counter(); warehouse.search.setText("быстр 5999")
        assert time.perf_counter() - started < 0.2, "typing must not execute the catalog query synchronously"
        QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        assert warehouse.balance_table.item(0, 1).text() == "ART-05999"
        warehouse.search.setText("4609000005999"); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        warehouse.search.setText("5999,5"); QTest.qWait(200); app.processEvents()
        assert warehouse.balance_table.rowCount() == 1
        warehouse.balance_table.selectRow(0); app.processEvents()
        started = time.perf_counter()
        warehouse.post_selected_movement("receipt", Decimal("3"), "Большой каталог")
        assert time.perf_counter() - started < 0.75, "stock action must not freeze on a large catalog"
        assert warehouse.balance_table.item(0, 4).text() == "3"
        assert admin.user_list.count() == 1 and "@mike" in admin.user_list.item(0).text()
        new_user = service.add_user("anna", "Анна")
        service.set_module(new_user.user_id, "price_tags", True)
        assert any(item.code == "price_tags" and item.enabled for item in service.modules_for(new_user.user_id))
        try:
            service.set_module(new_user.user_id, "stock", False)
        except ValueError:
            pass
        else:
            raise AssertionError("base stock module must not be disabled")
        service.change_status(new_user.user_id, "blocked")
        assert service.user("anna").status == "blocked"
        service.change_status(new_user.user_id, "active")
        assert service.user("anna").status == "pending_activation"
        mask = service.save_openai_key(new_user.user_id, "sk-test-12345678901234567890")
        assert mask.endswith("7890") and service.reveal_openai_key(new_user.user_id).endswith("7890")
        check = sai_db.connect()
        try:
            assert check.execute("SELECT COUNT(*) FROM admin_audit_log WHERE target_user_id=?", (new_user.user_id,)).fetchone()[0] == 4
            encrypted_db = check.execute("SELECT encrypted_value FROM user_secrets WHERE user_id=?", (new_user.user_id,)).fetchone()[0]
            assert "sk-test" not in encrypted_db
        finally:
            check.close()
        assert service.delete_openai_key(new_user.user_id)
        assert service.openai_key_mask(new_user.user_id) == "Не задан"
        assert service.reveal_openai_key(new_user.user_id) == ""
        legacy_cfg = {"openai_api_key": "invalid-old-key"}
        def save_legacy_patch(patch):
            legacy_cfg.update(patch)
            return dict(legacy_cfg)
        assert not service.migrate_legacy_owner_openai_key(lambda: dict(legacy_cfg), save_legacy_patch)
        assert legacy_cfg["openai_api_key"] == "invalid-old-key"
        legacy_cfg["openai_api_key"] = "sk-legacy-12345678901234567890"
        assert service.migrate_legacy_owner_openai_key(lambda: dict(legacy_cfg), save_legacy_patch)
        owner_user = service.owner()
        assert owner_user and service.reveal_openai_key(owner_user.user_id).endswith("7890")
        assert legacy_cfg["openai_api_key"] == ""
        legacy_ai_cfg = {
            "openai_api_key": "",
            "openai_model": "gpt-admin-test",
            "openai_proxy_url": "http://127.0.0.1:1080",
            "openai_api_base": "https://example.test/v1",
        }
        removed_ai_keys = []
        def remove_legacy_ai(keys):
            removed_ai_keys.extend(keys)
            for key in keys:
                legacy_ai_cfg.pop(key, None)
            return dict(legacy_ai_cfg)
        assert service.migrate_legacy_owner_ai_settings(lambda: dict(legacy_ai_cfg), remove_legacy_ai)
        owner_ai = service.ai_settings(owner_user.user_id)
        assert owner_ai == {
            "model": "gpt-admin-test",
            "proxy_url": "http://127.0.0.1:1080",
            "api_base": "https://example.test/v1",
        }
        assert not legacy_ai_cfg and {"openai_model", "openai_proxy_url", "openai_api_base"} <= set(removed_ai_keys)
        service.save_ai_settings(owner_user.user_id, "gpt-replaced", "", "https://api.openai.com/v1")
        assert service.ai_settings(owner_user.user_id)["model"] == "gpt-replaced"
        check = sai_db.connect()
        try:
            assert check.execute("SELECT COUNT(*) FROM admin_audit_log WHERE target_user_id=?", (new_user.user_id,)).fetchone()[0] == 5
        finally:
            check.close()
        admin.current_username = "anna"; admin.refresh_users(); app.processEvents(); assert admin.user_list.count() == 2
        assert admin.current_username == "anna" and admin.user_title.text() == "Анна"
        ai_tile = admin.module_tiles["invoice_ai"]
        assert not ai_tile.module.enabled and ai_tile.action_button.text() == "+" and ai_tile.action_button.isEnabled()
        hits = []; ai_tile.action_button.clicked.connect(lambda: hits.append(1))
        ai_tile.action_button.click(); QTest.qWait(10); app.processEvents(); assert hits == [1]
        assert any(item.code == "invoice_ai" and item.enabled for item in service.modules_for(new_user.user_id))
        price_tile = admin.module_tiles["price_tags"]
        QTest.mouseClick(price_tile.action_button, Qt.LeftButton, pos=price_tile.action_button.rect().center()); QTest.qWait(10); app.processEvents()
        assert not any(item.code == "price_tags" and item.enabled for item in service.modules_for(new_user.user_id))
        assert not price_tile.module.enabled and price_tile.action_button.text() == "+"
        core = {code: tile for code, tile in admin.module_tiles.items() if tile.module.locked}
        assert {"receipt", "stock"} <= set(core) and all(not tile.action_button.isEnabled() for tile in core.values())
        snapshot_dir = os.environ.get("SAI_UI_SNAPSHOT_DIR", "").strip()
        if snapshot_dir:
            target = Path(snapshot_dir); target.mkdir(parents=True, exist_ok=True)
            for page, name in ((warehouse, "warehouse.png"), (admin, "admin.png")):
                page.resize(1180, 760); page.show(); app.processEvents()
                assert page.grab().save(str(target / name))
        warehouse.close(); admin.close(); app.processEvents()
    print("SAI account and stock UI tests: OK")


if __name__ == "__main__":
    main()
