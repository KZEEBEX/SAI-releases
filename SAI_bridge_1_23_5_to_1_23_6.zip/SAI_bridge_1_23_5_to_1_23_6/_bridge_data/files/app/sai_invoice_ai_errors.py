#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Shared exception types for the SAI invoice AI subsystem."""
from __future__ import annotations


class OpenAIInvoiceError(RuntimeError):
    """Expected operator-facing failure in invoice AI processing."""
