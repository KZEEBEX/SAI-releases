#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Durable operator choices for SIGMA XLSX imports."""
from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from openpyxl import load_workbook

import sai_product_names
from sai_runtime_paths import USER_DATA_DIR


def text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def normalized_name(value: Any) -> str:
    value = sai_product_names.searchable_text(value).upper().replace("Ё", "Е")
    value = re.sub(r"[^0-9A-ZА-Я]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def header_map(ws) -> Dict[str, int]:
    result: Dict[str, int] = {}
    for cell in ws[1]:
        key = text(cell.value).lower().replace("ё", "е")
        if key:
            result[key] = int(cell.column)
    return result


def pick(headers: Dict[str, int], *names: str) -> int:
    for name in names:
        key = text(name).lower().replace("ё", "е")
        if key in headers:
            return headers[key]
    for key, column in headers.items():
        if any(text(name).lower().replace("ё", "е") in key for name in names):
            return column
    return 0


def read_import_xlsx_category_memory(path: str | Path) -> Dict[str, str]:
    """Read completed categories before the product check rebuilds Import_*.xlsx."""
    workbook = load_workbook(str(path), data_only=False, read_only=True)
    try:
        sheet = workbook[workbook.sheetnames[0]]
        headers = header_map(sheet)
        c_name = pick(headers, "Наименование")
        c_barcode = pick(headers, "Штрихкод", "ШК")
        c_category = pick(headers, "Категория")
        memory: Dict[str, str] = {}
        if not c_name or not c_category:
            return memory
        for row in range(2, sheet.max_row + 1):
            name = text(sheet.cell(row, c_name).value)
            category = text(sheet.cell(row, c_category).value)
            barcode = text(sheet.cell(row, c_barcode).value) if c_barcode else ""
            if not category:
                continue
            if barcode:
                memory["barcode:" + barcode] = category
            name_key = normalized_name(name)
            if name_key:
                memory["name:" + name_key] = category
        return memory
    finally:
        workbook.close()


def category_memory_path() -> Path:
    return USER_DATA_DIR / "cache" / "sigma_import_category_memory.json"


def load_import_category_memory(path: Optional[Path] = None) -> Dict[str, str]:
    target = Path(path or category_memory_path())
    try:
        payload = json.loads(target.read_text(encoding="utf-8"))
        values = payload.get("categories") if isinstance(payload, dict) else {}
        return {
            text(key): text(value)
            for key, value in (values or {}).items()
            if text(key) and text(value)
        }
    except Exception:
        return {}


def save_import_category_memory(memory: Dict[str, str], path: Optional[Path] = None) -> None:
    target = Path(path or category_memory_path())
    target.parent.mkdir(parents=True, exist_ok=True)
    values = {
        text(key): text(value)
        for key, value in (memory or {}).items()
        if text(key) and text(value)
    }
    values = dict(list(values.items())[-10_000:])
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_text(
        json.dumps(
            {
                "version": 1,
                "updated_at": dt.datetime.now().astimezone().isoformat(),
                "categories": values,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    temp.replace(target)


def remembered_categories_by_row(
    rows: List[Dict[str, Any]],
    memory: Dict[str, str],
) -> Dict[int, str]:
    remembered: Dict[int, str] = {}
    for row in rows or []:
        barcode_key = "barcode:" + text(row.get("barcode"))
        name_key = "name:" + normalized_name(row.get("name"))
        category = text(memory.get(barcode_key) or memory.get(name_key))
        excel_row = int(row.get("excel_row") or 0)
        if category and excel_row >= 2:
            remembered[excel_row] = category
    return remembered


__all__ = [
    "load_import_category_memory",
    "read_import_xlsx_category_memory",
    "remembered_categories_by_row",
    "save_import_category_memory",
]
