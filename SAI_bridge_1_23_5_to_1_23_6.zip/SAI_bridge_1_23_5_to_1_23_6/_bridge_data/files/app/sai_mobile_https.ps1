param(
    [Parameter(Mandatory = $true)]
    [string]$OutputDir,
    [Parameter(Mandatory = $true)]
    [string]$IpAddress
)

$ErrorActionPreference = "Stop"
[System.IO.Directory]::CreateDirectory($OutputDir) | Out-Null

$rootSubject = "CN=SAI Local Mobile Scanner CA"
$now = Get-Date
$root = Get-ChildItem -Path "Cert:\CurrentUser\My" |
    Where-Object {
        $_.Subject -eq $rootSubject -and
        $_.HasPrivateKey -and
        $_.NotAfter -gt $now.AddYears(1)
    } |
    Sort-Object NotAfter -Descending |
    Select-Object -First 1

if (-not $root) {
    $root = New-SelfSignedCertificate `
        -Type Custom `
        -Subject $rootSubject `
        -FriendlyName "SAI Local Mobile Scanner CA" `
        -CertStoreLocation "Cert:\CurrentUser\My" `
        -KeyAlgorithm RSA `
        -KeyLength 2048 `
        -HashAlgorithm SHA256 `
        -KeyExportPolicy Exportable `
        -KeyUsage CertSign, CRLSign, DigitalSignature `
        -TextExtension @("2.5.29.19={critical}{text}ca=1&pathlength=1") `
        -NotAfter $now.AddYears(10)
}

$server = New-SelfSignedCertificate `
    -Type Custom `
    -Subject "CN=SAI Mobile Scanner" `
    -FriendlyName "SAI Mobile Scanner $IpAddress" `
    -Signer $root `
    -CertStoreLocation "Cert:\CurrentUser\My" `
    -KeyAlgorithm RSA `
    -KeyLength 2048 `
    -HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable `
    -KeyUsage DigitalSignature, KeyEncipherment `
    -TextExtension @(
        "2.5.29.17={text}IPAddress=$IpAddress&IPAddress=127.0.0.1",
        "2.5.29.37={text}1.3.6.1.5.5.7.3.1"
    ) `
    -NotAfter $now.AddDays(365)

function Write-Pem {
    param(
        [string]$Label,
        [byte[]]$Bytes,
        [string]$Path
    )
    $body = [Convert]::ToBase64String(
        $Bytes,
        [Base64FormattingOptions]::InsertLineBreaks
    )
    [IO.File]::WriteAllText(
        $Path,
        "-----BEGIN $Label-----`r`n$body`r`n-----END $Label-----`r`n",
        [Text.Encoding]::ASCII
    )
}

$rootCer = Join-Path $OutputDir "sai-local-ca.cer"
$serverPem = Join-Path $OutputDir "sai-mobile-server.pem"
$serverKeyPem = Join-Path $OutputDir "sai-mobile-server-key.pem"
$statePath = Join-Path $OutputDir "state.json"

Export-Certificate -Cert $root -FilePath $rootCer -Force | Out-Null
Write-Pem -Label "CERTIFICATE" -Bytes $server.RawData -Path $serverPem

$rsa = [Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($server)
try {
    if ($rsa -is [Security.Cryptography.RSACng]) {
        $privateKey = $rsa.Key.Export(
            [Security.Cryptography.CngKeyBlobFormat]::Pkcs8PrivateBlob
        )
    }
    else {
        $privateKey = $rsa.ExportPkcs8PrivateKey()
    }
    Write-Pem -Label "PRIVATE KEY" -Bytes $privateKey -Path $serverKeyPem
}
finally {
    if ($rsa) { $rsa.Dispose() }
}

@{
    ip = $IpAddress
    root_thumbprint = $root.Thumbprint
    server_thumbprint = $server.Thumbprint
    server_not_after = $server.NotAfter.ToUniversalTime().ToString("o")
} | ConvertTo-Json | Set-Content -LiteralPath $statePath -Encoding UTF8

# The exported server key is used by Python. Keep only the root CA in the
# Windows certificate store so repeated IP changes do not fill it with leaves.
Remove-Item -LiteralPath ("Cert:\CurrentUser\My\" + $server.Thumbprint) -Force

Write-Output $statePath
