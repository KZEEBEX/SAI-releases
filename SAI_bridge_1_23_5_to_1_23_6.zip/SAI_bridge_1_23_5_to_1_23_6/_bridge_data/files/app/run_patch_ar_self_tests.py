#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused installation checks for SAI v1.22.7ar boundary refactor."""
from __future__ import annotations

import ast
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
app = root / "app"

assert 'VERSION = "1.22.7ar"' in (app / "sai_version.py").read_text(encoding="utf-8")
assert 'APP_VERSION == "v1.22.7ar"' in (app / "run_self_tests.py").read_text(encoding="utf-8")

main_path = app / "sai_openai_invoice.py"
source_path = app / "sai_invoice_ai_sources.py"
contract_path = app / "sai_invoice_ai_contract.py"
errors_path = app / "sai_invoice_ai_errors.py"
source_test = app / "run_invoice_ai_source_tests.py"
for path in (main_path, source_path, contract_path, errors_path, source_test):
    assert path.is_file(), path
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

main_text = main_path.read_text(encoding="utf-8")
assert len(main_text.splitlines()) <= 1320
assert "import base64" not in main_text
assert "import mimetypes" not in main_text
assert "import sai_invoice_ai_sources as _invoice_sources" in main_text
assert "import sai_invoice_ai_contract as _invoice_contract" in main_text
assert "class OpenAIInvoiceError" not in main_text

source_text = source_path.read_text(encoding="utf-8")
for token in (
    "def validate_source_paths", "def render_prepared_visual_views",
    "def append_sources", "def row_groups_for_targets",
):
    assert token in source_text
contract_text = contract_path.read_text(encoding="utf-8")
for token in (
    "def load_invoice_schema", "def invoice_contract_metadata", "def instruction_text",
):
    assert token in contract_text

subprocess.run([sys.executable, str(source_test), str(root)], cwd=app, check=True)
subprocess.run([sys.executable, str(app / "run_invoice_ai_pipeline_tests.py"), str(root)], cwd=app, check=True)

wiki = root / "SAI_Ecosystem_Wiki_v0.1"
manifest = json.loads((wiki / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.9"
assert manifest["snapshot_sai_version"] == "1.22.7ar"
assert (wiki / "decisions" / "ADR-026-INVOICE-AI-CONTRACT-AND-SOURCE-BOUNDARIES.md").is_file()
assert (wiki / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.9 / SAI 1.22.7ar")

print("PATCH_AR_SELF_TEST_OK")
