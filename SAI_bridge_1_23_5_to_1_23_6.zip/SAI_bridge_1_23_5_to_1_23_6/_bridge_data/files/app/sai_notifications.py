#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Unified notification and message-dialog system for SAI.

The rest of the application talks to this module instead of mixing native-looking
QMessageBox windows, custom banners and ad-hoc toast widgets.  It intentionally
keeps a QMessageBox-compatible surface so existing business workflows do not
need risky rewrites just to receive the new visual system.
"""
from __future__ import annotations

import time
from typing import Dict, Iterable, Optional

from PySide6.QtCore import (
    QEasingCurve,
    QEvent,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    QSize,
    Qt,
    QTimer,
)
from PySide6.QtGui import QColor, QKeyEvent, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QLabel,
    QMessageBox as QtMessageBox,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)


_TONE_COLORS = {
    "info": "#2563eb",
    "success": "#16a34a",
    "warning": "#d97706",
    "error": "#dc2626",
    "question": "#7c3aed",
}


def _normal_tone(tone: str) -> str:
    value = str(tone or "info").strip().lower()
    if value == "critical":
        value = "error"
    return value if value in _TONE_COLORS else "info"


def _is_dark() -> bool:
    app = QApplication.instance()
    return bool(app and app.property("saiNightTheme"))


class StatusGlyph(QWidget):
    """Small vector status icon that is independent of Windows icon themes."""

    def __init__(self, tone: str = "info", size: int = 34, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._tone = _normal_tone(tone)
        self.setFixedSize(size, size)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)

    def set_tone(self, tone: str) -> None:
        self._tone = _normal_tone(tone)
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        color = QColor(_TONE_COLORS[self._tone])
        rect = QRectF(self.rect()).adjusted(1.0, 1.0, -1.0, -1.0)
        painter.setPen(Qt.PenStyle.NoPen)
        fill = QColor(color)
        fill.setAlpha(34 if not _is_dark() else 48)
        painter.setBrush(fill)
        painter.drawEllipse(rect)
        painter.setPen(QPen(color, 2.1, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))

        cx = rect.center().x()
        cy = rect.center().y()
        radius = rect.width() * 0.22
        if self._tone == "success":
            path = QPainterPath()
            path.moveTo(cx - radius * 1.00, cy + radius * 0.02)
            path.lineTo(cx - radius * 0.20, cy + radius * 0.78)
            path.lineTo(cx + radius * 1.18, cy - radius * 0.78)
            painter.drawPath(path)
        elif self._tone == "warning":
            painter.drawLine(QPoint(int(cx), int(cy - radius)), QPoint(int(cx), int(cy + radius * 0.42)))
            painter.drawPoint(QPoint(int(cx), int(cy + radius * 0.92)))
        elif self._tone == "error":
            painter.drawLine(QPoint(int(cx - radius), int(cy - radius)), QPoint(int(cx + radius), int(cy + radius)))
            painter.drawLine(QPoint(int(cx + radius), int(cy - radius)), QPoint(int(cx - radius), int(cy + radius)))
        elif self._tone == "question":
            # A compact question mark drawn as vector strokes.
            path = QPainterPath()
            path.moveTo(cx - radius * 0.68, cy - radius * 0.48)
            path.cubicTo(cx - radius * 0.30, cy - radius * 1.10, cx + radius * 0.82, cy - radius * 0.88, cx + radius * 0.72, cy - radius * 0.15)
            path.cubicTo(cx + radius * 0.65, cy + radius * 0.18, cx + radius * 0.08, cy + radius * 0.18, cx + radius * 0.04, cy + radius * 0.58)
            painter.drawPath(path)
            painter.drawPoint(QPoint(int(cx), int(cy + radius * 1.02)))
        else:
            painter.drawLine(QPoint(int(cx), int(cy - radius * 0.35)), QPoint(int(cx), int(cy + radius * 0.78)))
            painter.drawPoint(QPoint(int(cx), int(cy - radius * 0.88)))


class NotificationToast(QFrame):
    """Compact neutral toast with a coloured status accent, never a colour flood."""

    def __init__(
        self,
        parent: QWidget,
        title: str,
        message: str,
        tone: str = "info",
        duration_ms: int | None = None,
    ) -> None:
        super().__init__(parent)
        self.tone = _normal_tone(tone)
        self.title = str(title or "SAI").strip().upper()
        self.message = str(message or "").strip()
        self.duration_ms = int(duration_ms or {
            "success": 3600,
            "info": 4600,
            "warning": 6800,
            "error": 9000,
            "question": 6800,
        }[self.tone])
        self._closing = False
        self._on_closed = None
        self.setObjectName("NotificationToast")
        self.setProperty("tone", self.tone)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedWidth(328)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum)

        shadow = QGraphicsDropShadowEffect(self)
        # A deeper, soft shadow makes the card visibly float above both the
        # light canvas and the nearly same-coloured night workspace.
        shadow.setBlurRadius(44)
        shadow.setOffset(0, 11)
        shadow.setColor(QColor(2, 6, 23, 92 if not _is_dark() else 215))
        self.setGraphicsEffect(shadow)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Qt style-sheet radii do not clip child widgets. Keep the status accent
        # visibly inside the card instead of letting it touch and protrude through
        # the rounded outer border.
        body = QWidget(self)
        body.setObjectName("NotificationBody")
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(6, 2, 2, 2)
        body_layout.setSpacing(0)

        accent = QFrame(body)
        accent.setObjectName("NotificationAccent")
        accent.setFixedWidth(4)
        accent.setMinimumHeight(48)
        accent.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        accent.setStyleSheet(
            f"background: {_TONE_COLORS[self.tone]}; border: none; border-radius: 2px;"
        )
        body_layout.addWidget(accent, 0, Qt.AlignmentFlag.AlignVCenter)

        content = QWidget(body)
        content.setObjectName("NotificationContent")
        content.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        layout = QHBoxLayout(content)
        layout.setContentsMargins(13, 11, 9, 11)
        layout.setSpacing(10)

        self.glyph = StatusGlyph(self.tone, 30, content)
        layout.addWidget(self.glyph, 0, Qt.AlignmentFlag.AlignTop)

        text_box = QVBoxLayout()
        text_box.setContentsMargins(0, 0, 0, 0)
        text_box.setSpacing(3)
        title_label = QLabel(self.title, content)
        title_label.setObjectName("NotificationTitle")
        title_label.setWordWrap(True)
        title_label.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        title_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        message_label = QLabel(self.message, content)
        message_label.setObjectName("NotificationMessage")
        message_label.setWordWrap(True)
        message_label.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        message_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        text_box.addWidget(title_label)
        if self.message:
            text_box.addWidget(message_label)
        layout.addLayout(text_box, 1)

        close_btn = QPushButton("×", content)
        close_btn.setObjectName("NotificationClose")
        close_btn.setFixedSize(24, 24)
        close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        close_btn.setToolTip("Закрыть")
        close_btn.clicked.connect(self.close_animated)
        layout.addWidget(close_btn, 0, Qt.AlignmentFlag.AlignTop)

        body_layout.addWidget(content, 1)
        outer.addWidget(body, 1)
        self._title_label = title_label
        self._message_label = message_label
        self._body = body
        self._content = content
        self._sync_geometry()

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.close_animated)

    def _sync_geometry(self) -> None:
        """Resolve wrapped text before Qt positions the toast.

        QLabel reports an unreliable height through nested layouts while its
        width is still unconstrained.  That used to leave the second message
        line painted below the white card.  The toast width is fixed, so its
        actual text column and required height can be calculated explicitly.
        """
        # 328 card - body/content margins - accent - glyph - close button - gaps.
        text_width = 220
        self._title_label.setFixedWidth(text_width)
        self._message_label.setFixedWidth(text_width)
        self.ensurePolished()
        self._title_label.ensurePolished()
        self._message_label.ensurePolished()

        wrap_flags = int(
            Qt.AlignmentFlag.AlignLeft
            | Qt.AlignmentFlag.AlignTop
            | Qt.TextFlag.TextWordWrap
        )

        def wrapped_height(label: QLabel, value: str) -> int:
            if not value:
                return 0
            bounds = label.fontMetrics().boundingRect(
                QRect(0, 0, text_width, 10_000),
                wrap_flags,
                value,
            )
            return max(label.fontMetrics().height(), bounds.height())

        title_height = wrapped_height(self._title_label, self.title)
        message_height = wrapped_height(self._message_label, self.message)
        self._title_label.setFixedHeight(title_height)
        if self.message:
            self._message_label.setFixedHeight(message_height)

        text_height = title_height + (3 + message_height if self.message else 0)
        # content margins: 11 px top/bottom; body margins: 2 px top/bottom.
        # Leave a small reserve because Windows can repolish fonts while the
        # available desktop changes (notably when an auto-hidden taskbar moves).
        card_height = max(30, 24, text_height) + 22 + 4 + 10
        self.setFixedHeight(max(92, card_height))
        self.layout().activate()

    def set_closed_callback(self, callback) -> None:
        self._on_closed = callback

    def show_at(self, target: QPoint, animate: bool = True) -> None:
        self._sync_geometry()
        if animate:
            self.move(target + QPoint(28, 0))
            self._move_anim = QPropertyAnimation(self, b"pos", self)
            self._move_anim.setDuration(230)
            self._move_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
            self._move_anim.setStartValue(self.pos())
            self._move_anim.setEndValue(target)
            self._move_anim.start()
        else:
            self.move(target)
        self.show()
        self.raise_()
        self._timer.start(self.duration_ms)

    def move_to(self, target: QPoint) -> None:
        if self._closing:
            return
        if self.pos() == target:
            return
        # Taskbar auto-hide can emit a burst of resize events. Moving the whole
        # toast atomically avoids competing animations and graphics-effect
        # caches placing the body and its text at different coordinates.
        move_anim = getattr(self, "_move_anim", None)
        if move_anim is not None:
            move_anim.stop()
        self.move(target)
        self.raise_()

    def close_animated(self) -> None:
        if self._closing:
            return
        self._closing = True
        self._timer.stop()
        self._close_anim = QPropertyAnimation(self, b"pos", self)
        self._close_anim.setDuration(140)
        self._close_anim.setEasingCurve(QEasingCurve.Type.InCubic)
        self._close_anim.setStartValue(self.pos())
        self._close_anim.setEndValue(self.pos() + QPoint(24, 0))

        def finish() -> None:
            callback = self._on_closed
            self.deleteLater()
            if callback:
                callback(self)

        self._close_anim.finished.connect(finish)
        self._close_anim.start()


class NotificationCenter(QObject):
    """Queues, deduplicates and positions in-app notifications."""

    def __init__(self, host: QWidget, max_visible: int = 3) -> None:
        super().__init__(host)
        self.host = host
        self.max_visible = max(1, int(max_visible))
        self.toasts: list[NotificationToast] = []
        self._recent: Dict[tuple[str, str, str], float] = {}
        host.installEventFilter(self)

    def eventFilter(self, obj, event):  # noqa: N802 - Qt override
        if obj is self.host and event.type() in (QEvent.Type.Resize, QEvent.Type.Show):
            QTimer.singleShot(0, self.reflow)
        return super().eventFilter(obj, event)

    def notify(self, title: str, message: str, tone: str = "info", duration_ms: int | None = None) -> None:
        title = str(title or "SAI").strip()
        message = str(message or "").strip()
        tone = _normal_tone(tone)
        key = (title.casefold(), message.casefold(), tone)
        now = time.monotonic()
        if now - self._recent.get(key, 0.0) < 2.0:
            return
        self._recent[key] = now
        self._recent = {k: stamp for k, stamp in self._recent.items() if now - stamp < 30.0}

        toast = NotificationToast(self.host, title, message, tone, duration_ms)
        toast.set_closed_callback(self._toast_closed)
        self.toasts.append(toast)
        while len(self.toasts) > self.max_visible:
            self.toasts[0].close_animated()
            if len(self.toasts) <= self.max_visible:
                break
            # close_animated is asynchronous; do not create an unbounded queue.
            self.toasts.pop(0)
        self.reflow(new_toast=toast)

    def _toast_closed(self, toast: NotificationToast) -> None:
        if toast in self.toasts:
            self.toasts.remove(toast)
        self.reflow()

    def clear(self) -> None:
        for toast in list(self.toasts):
            toast.close_animated()

    def reflow(self, new_toast: NotificationToast | None = None) -> None:
        if not self.host.isVisible() and new_toast is None:
            return
        # Leave enough breathing room for the expanded drop shadow.
        margin = 26
        gap = 12
        bottom = max(margin, self.host.height() - margin)
        for toast in reversed(self.toasts):
            toast._sync_geometry()
            bottom -= toast.height()
            target = QPoint(max(margin, self.host.width() - toast.width() - margin), max(margin, bottom))
            if toast is new_toast and not toast.isVisible():
                toast.show_at(target, animate=True)
            else:
                toast.move_to(target)
            bottom -= gap


class CatalogStatusBadge(QFrame):
    """Quiet persistent catalog status for the navigation rail."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("CatalogStatusBadge")
        self.setProperty("tone", "info")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFixedHeight(58)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._compact = False
        self._title_text = "КАТАЛОГ"
        self._detail_text = "ПРОВЕРЯЮ СОСТОЯНИЕ"

        layout = QHBoxLayout(self)
        layout.setContentsMargins(13, 9, 9, 9)
        layout.setSpacing(10)
        self._layout = layout
        self.glyph = StatusGlyph("info", 24, self)
        layout.addWidget(self.glyph, 0, Qt.AlignmentFlag.AlignVCenter)
        labels = QVBoxLayout()
        labels.setContentsMargins(0, 0, 0, 0)
        labels.setSpacing(1)
        self.title_label = QLabel(self._title_text, self)
        self.title_label.setObjectName("CatalogStatusTitle")
        self.detail_label = QLabel(self._detail_text, self)
        self.detail_label.setObjectName("CatalogStatusDetail")
        self.detail_label.setWordWrap(True)
        labels.addWidget(self.title_label)
        labels.addWidget(self.detail_label)
        layout.addLayout(labels, 1)
        self._labels = labels
        self.setToolTip(f"{self._title_text}\n{self._detail_text}")

    def set_status(self, title: str, detail: str, tone: str = "info") -> None:
        tone = _normal_tone(tone)
        self._title_text = str(title or "КАТАЛОГ").upper()
        self._detail_text = str(detail or "").upper()
        self.setProperty("tone", tone)
        self.glyph.set_tone(tone)
        self.title_label.setText(self._title_text)
        self.detail_label.setText(self._detail_text)
        self.setToolTip(f"{self._title_text}\n{self._detail_text}".strip())
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()

    def set_compact(self, compact: bool) -> None:
        self._compact = bool(compact)
        # The glyph remains inside the exact same 58 px box with the same
        # margins. Compact mode hides only text and paint, never layout metrics.
        self.title_label.setVisible(not self._compact)
        self.detail_label.setVisible(not self._compact)
        self.setProperty("compactBadge", self._compact)
        style = self.style()
        if style is not None:
            style.unpolish(self)
            style.polish(self)
        self.update()


def _dialog_title(title: str, icon: QtMessageBox.Icon) -> str:
    value = str(title or "").strip()
    if value and value.casefold() != "sai":
        return value.upper()
    return {
        QtMessageBox.Icon.Warning: "НУЖНО ВНИМАНИЕ",
        QtMessageBox.Icon.Critical: "ОШИБКА",
        QtMessageBox.Icon.Question: "ПОДТВЕРЖДЕНИЕ",
        QtMessageBox.Icon.Information: "SAI",
    }.get(icon, "SAI")


def _split_dialog_text(text: str) -> tuple[str, str]:
    value = str(text or "").strip()
    if not value:
        return "", ""
    if "\n\n" in value:
        main, detail = value.split("\n\n", 1)
        return main.strip(), detail.strip()
    lines = [line.strip() for line in value.splitlines() if line.strip()]
    if len(lines) > 1:
        return lines[0], "\n".join(lines[1:])
    if len(value) > 190:
        for separator in (". ", ": "):
            pos = value.find(separator)
            if 35 <= pos <= 135:
                return value[: pos + 1].strip(), value[pos + len(separator):].strip()
    return value, ""


class SAIMessageBox(QDialog):
    """Modern QMessageBox-compatible dialog used by every SAI message window."""

    Icon = QtMessageBox.Icon
    ButtonRole = QtMessageBox.ButtonRole
    StandardButton = QtMessageBox.StandardButton

    NoIcon = QtMessageBox.Icon.NoIcon
    Information = QtMessageBox.Icon.Information
    Warning = QtMessageBox.Icon.Warning
    Critical = QtMessageBox.Icon.Critical
    Question = QtMessageBox.Icon.Question

    NoButton = QtMessageBox.StandardButton.NoButton
    Ok = QtMessageBox.StandardButton.Ok
    Save = QtMessageBox.StandardButton.Save
    Cancel = QtMessageBox.StandardButton.Cancel
    Close = QtMessageBox.StandardButton.Close
    Yes = QtMessageBox.StandardButton.Yes
    No = QtMessageBox.StandardButton.No

    InvalidRole = QtMessageBox.ButtonRole.InvalidRole
    AcceptRole = QtMessageBox.ButtonRole.AcceptRole
    RejectRole = QtMessageBox.ButtonRole.RejectRole
    DestructiveRole = QtMessageBox.ButtonRole.DestructiveRole
    ActionRole = QtMessageBox.ButtonRole.ActionRole
    HelpRole = QtMessageBox.ButtonRole.HelpRole
    YesRole = QtMessageBox.ButtonRole.YesRole
    NoRole = QtMessageBox.ButtonRole.NoRole
    ApplyRole = QtMessageBox.ButtonRole.ApplyRole
    ResetRole = QtMessageBox.ButtonRole.ResetRole

    _STANDARD_ORDER = (
        QtMessageBox.StandardButton.Yes,
        QtMessageBox.StandardButton.No,
        QtMessageBox.StandardButton.Ok,
        QtMessageBox.StandardButton.Save,
        QtMessageBox.StandardButton.Cancel,
        QtMessageBox.StandardButton.Close,
    )
    _STANDARD_TEXT = {
        QtMessageBox.StandardButton.Yes: "Да",
        QtMessageBox.StandardButton.No: "Нет",
        QtMessageBox.StandardButton.Ok: "ОК",
        QtMessageBox.StandardButton.Save: "Сохранить",
        QtMessageBox.StandardButton.Cancel: "Отмена",
        QtMessageBox.StandardButton.Close: "Закрыть",
    }
    _STANDARD_ROLE = {
        QtMessageBox.StandardButton.Yes: QtMessageBox.ButtonRole.YesRole,
        QtMessageBox.StandardButton.No: QtMessageBox.ButtonRole.NoRole,
        QtMessageBox.StandardButton.Ok: QtMessageBox.ButtonRole.AcceptRole,
        QtMessageBox.StandardButton.Save: QtMessageBox.ButtonRole.AcceptRole,
        QtMessageBox.StandardButton.Cancel: QtMessageBox.ButtonRole.RejectRole,
        QtMessageBox.StandardButton.Close: QtMessageBox.ButtonRole.RejectRole,
    }

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("SAIMessageDialog")
        self.setModal(True)
        self.setWindowFlag(Qt.WindowType.FramelessWindowHint, True)
        self.setWindowFlag(Qt.WindowType.Dialog, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setMinimumWidth(460)
        self.setMaximumWidth(680)
        self._icon = QtMessageBox.Icon.Information
        self._tone = "info"
        self._clicked_button: QPushButton | None = None
        self._clicked_standard = QtMessageBox.StandardButton.NoButton
        self._button_roles: Dict[QPushButton, QtMessageBox.ButtonRole] = {}
        self._button_standards: Dict[QPushButton, QtMessageBox.StandardButton] = {}
        self._standard_buttons: Dict[QtMessageBox.StandardButton, QPushButton] = {}
        self._default_button: QPushButton | None = None
        self._drag_offset: QPoint | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 19)
        root.setSpacing(0)
        self.panel = QFrame(self)
        self.panel.setObjectName("SAIMessagePanel")
        root.addWidget(self.panel)

        shadow = QGraphicsDropShadowEffect(self.panel)
        shadow.setBlurRadius(24)
        shadow.setOffset(0, 5)
        shadow.setColor(QColor(15, 23, 42, 72 if not _is_dark() else 108))
        self.panel.setGraphicsEffect(shadow)

        panel_layout = QVBoxLayout(self.panel)
        panel_layout.setContentsMargins(22, 18, 22, 20)
        panel_layout.setSpacing(0)

        header = QHBoxLayout()
        header.setSpacing(12)
        self.glyph = StatusGlyph("info", 38, self.panel)
        header.addWidget(self.glyph, 0, Qt.AlignmentFlag.AlignTop)
        self.title_label = QLabel("SAI", self.panel)
        self.title_label.setObjectName("SAIMessageTitle")
        self.title_label.setWordWrap(True)
        header.addWidget(self.title_label, 1, Qt.AlignmentFlag.AlignVCenter)
        self.close_button = QPushButton("×", self.panel)
        self.close_button.setObjectName("SAIMessageClose")
        self.close_button.setFixedSize(30, 30)
        self.close_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_button.setToolTip("Закрыть")
        self.close_button.clicked.connect(self.reject)
        header.addWidget(self.close_button, 0, Qt.AlignmentFlag.AlignTop)
        panel_layout.addLayout(header)

        self.text_label = QLabel("", self.panel)
        self.text_label.setObjectName("SAIMessageText")
        self.text_label.setWordWrap(True)
        self.text_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        panel_layout.addSpacing(15)
        panel_layout.addWidget(self.text_label)

        self.info_label = QLabel("", self.panel)
        self.info_label.setObjectName("SAIMessageInfo")
        self.info_label.setWordWrap(True)
        self.info_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.info_label.setVisible(False)
        panel_layout.addWidget(self.info_label)

        self.button_row = QHBoxLayout()
        self.button_row.setContentsMargins(0, 18, 0, 0)
        self.button_row.setSpacing(9)
        self.button_row.addStretch(1)
        panel_layout.addLayout(self.button_row)
        self.setIcon(self._icon)

    def setWindowTitle(self, title: str) -> None:  # noqa: N802 - Qt compatibility
        super().setWindowTitle(str(title or "SAI"))
        if hasattr(self, "title_label"):
            normalized = str(title or "SAI").strip()
            self.title_label.setText(normalized.upper())

    def setText(self, text: str) -> None:  # noqa: N802
        self.text_label.setText(str(text or ""))

    def text(self) -> str:
        return self.text_label.text()

    def setInformativeText(self, text: str) -> None:  # noqa: N802
        value = str(text or "").strip()
        self.info_label.setText(value)
        self.info_label.setVisible(bool(value))
        if value:
            self.info_label.setContentsMargins(0, 10, 0, 0)

    def informativeText(self) -> str:
        return self.info_label.text()

    def setIcon(self, icon) -> None:  # noqa: N802
        try:
            self._icon = QtMessageBox.Icon(icon)
        except Exception:
            self._icon = QtMessageBox.Icon.Information
        self._tone = {
            QtMessageBox.Icon.Warning: "warning",
            QtMessageBox.Icon.Critical: "error",
            QtMessageBox.Icon.Question: "question",
            QtMessageBox.Icon.Information: "info",
            QtMessageBox.Icon.NoIcon: "info",
        }.get(self._icon, "info")
        self.setProperty("tone", self._tone)
        if hasattr(self, "glyph"):
            self.glyph.set_tone(self._tone)
        if hasattr(self, "panel"):
            self.panel.setProperty("tone", self._tone)
            self.panel.style().unpolish(self.panel)
            self.panel.style().polish(self.panel)

    def addButton(self, button, role=None):  # noqa: N802 - QMessageBox compatibility
        if isinstance(button, QPushButton):
            btn = button
            btn_role = role if role is not None else QtMessageBox.ButtonRole.ActionRole
            standard = QtMessageBox.StandardButton.NoButton
        elif isinstance(button, str):
            btn = QPushButton(button, self.panel)
            btn_role = role if role is not None else QtMessageBox.ButtonRole.ActionRole
            standard = QtMessageBox.StandardButton.NoButton
        else:
            standard = QtMessageBox.StandardButton(button)
            btn = QPushButton(self._STANDARD_TEXT.get(standard, "ОК"), self.panel)
            btn_role = self._STANDARD_ROLE.get(standard, QtMessageBox.ButtonRole.AcceptRole)
            self._standard_buttons[standard] = btn
        btn.setObjectName("SAIMessageButton")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._button_roles[btn] = QtMessageBox.ButtonRole(btn_role)
        self._button_standards[btn] = standard
        self._apply_button_kind(btn)
        btn.clicked.connect(lambda checked=False, value=btn: self._button_clicked(value))
        self.button_row.addWidget(btn)
        return btn

    def _apply_button_kind(self, btn: QPushButton) -> None:
        role = self._button_roles.get(btn, QtMessageBox.ButtonRole.ActionRole)
        kind = "secondary"
        if role == QtMessageBox.ButtonRole.DestructiveRole:
            kind = "danger"
        elif role in (
            QtMessageBox.ButtonRole.AcceptRole,
            QtMessageBox.ButtonRole.YesRole,
            QtMessageBox.ButtonRole.ApplyRole,
        ):
            kind = "primary"
        elif role == QtMessageBox.ButtonRole.ActionRole and not any(
            other.property("kind") == "primary" for other in self._button_roles if other is not btn
        ):
            kind = "primary"
        btn.setProperty("kind", kind)
        btn.style().unpolish(btn)
        btn.style().polish(btn)

    def setStandardButtons(self, buttons) -> None:  # noqa: N802
        for standard in self._STANDARD_ORDER:
            if buttons & standard:
                self.addButton(standard)

    def setDefaultButton(self, button) -> None:  # noqa: N802
        if isinstance(button, QPushButton):
            btn = button
        else:
            btn = self._standard_buttons.get(QtMessageBox.StandardButton(button))
        if btn is None:
            return
        self._default_button = btn
        btn.setDefault(True)
        btn.setAutoDefault(True)
        # Only one ordinary action should look primary. A destructive action keeps
        # its red treatment while the safe default remains visually dominant.
        for other, other_role in self._button_roles.items():
            if other is btn or other_role == QtMessageBox.ButtonRole.DestructiveRole:
                continue
            if other.property("kind") == "primary":
                other.setProperty("kind", "secondary")
                other.style().unpolish(other)
                other.style().polish(other)
        if self._button_roles.get(btn) != QtMessageBox.ButtonRole.DestructiveRole:
            btn.setProperty("kind", "primary")
            btn.style().unpolish(btn)
            btn.style().polish(btn)

    def clickedButton(self):  # noqa: N802
        return self._clicked_button

    def _button_clicked(self, btn: QPushButton) -> None:
        self._clicked_button = btn
        self._clicked_standard = self._button_standards.get(btn, QtMessageBox.StandardButton.NoButton)
        role = self._button_roles.get(btn, QtMessageBox.ButtonRole.ActionRole)
        if role in (QtMessageBox.ButtonRole.RejectRole, QtMessageBox.ButtonRole.NoRole):
            super().reject()
        else:
            super().accept()

    def reject(self) -> None:
        # Match QMessageBox: closing the window returns Cancel, otherwise NoButton.
        cancel_btn = self._standard_buttons.get(QtMessageBox.StandardButton.Cancel)
        no_btn = self._standard_buttons.get(QtMessageBox.StandardButton.No)
        if cancel_btn is not None:
            self._clicked_button = cancel_btn
            self._clicked_standard = QtMessageBox.StandardButton.Cancel
        elif no_btn is not None:
            self._clicked_button = no_btn
            self._clicked_standard = QtMessageBox.StandardButton.No
        super().reject()

    def exec(self) -> int:
        if not self._button_roles:
            self.addButton(QtMessageBox.StandardButton.Ok)
        if self._default_button is None:
            buttons = list(self._button_roles)
            if buttons:
                self.setDefaultButton(buttons[0])
        self.adjustSize()
        result = super().exec()
        if self._clicked_standard != QtMessageBox.StandardButton.NoButton:
            return self._clicked_standard
        return result

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        if event.key() in (Qt.Key.Key_Escape,):
            self.reject()
            return
        super().keyPressEvent(event)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton and event.position().y() < 72:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        self._drag_offset = None
        super().mouseReleaseEvent(event)

    @classmethod
    def _show_static(
        cls,
        parent: QWidget | None,
        title: str,
        text: str,
        icon: QtMessageBox.Icon,
        buttons: QtMessageBox.StandardButton,
        default_button: QtMessageBox.StandardButton,
    ) -> QtMessageBox.StandardButton:
        box = cls(parent)
        box.setIcon(icon)
        box.setWindowTitle(_dialog_title(title, icon))
        main_text, detail_text = _split_dialog_text(text)
        box.setText(main_text)
        box.setInformativeText(detail_text)
        box.setStandardButtons(buttons)
        if default_button != QtMessageBox.StandardButton.NoButton:
            box.setDefaultButton(default_button)
        result = box.exec()
        try:
            return QtMessageBox.StandardButton(result)
        except Exception:
            return QtMessageBox.StandardButton.NoButton

    @classmethod
    def information(
        cls,
        parent,
        title,
        text,
        buttons=QtMessageBox.StandardButton.Ok,
        defaultButton=QtMessageBox.StandardButton.NoButton,
    ):
        return cls._show_static(parent, title, text, QtMessageBox.Icon.Information, buttons, defaultButton)

    @classmethod
    def warning(
        cls,
        parent,
        title,
        text,
        buttons=QtMessageBox.StandardButton.Ok,
        defaultButton=QtMessageBox.StandardButton.NoButton,
    ):
        return cls._show_static(parent, title, text, QtMessageBox.Icon.Warning, buttons, defaultButton)

    @classmethod
    def critical(
        cls,
        parent,
        title,
        text,
        buttons=QtMessageBox.StandardButton.Ok,
        defaultButton=QtMessageBox.StandardButton.NoButton,
    ):
        return cls._show_static(parent, title, text, QtMessageBox.Icon.Critical, buttons, defaultButton)

    @classmethod
    def question(
        cls,
        parent,
        title,
        text,
        buttons=QtMessageBox.StandardButton.Yes | QtMessageBox.StandardButton.No,
        defaultButton=QtMessageBox.StandardButton.NoButton,
    ):
        box = cls(parent)
        box.setIcon(QtMessageBox.Icon.Question)
        box.setWindowTitle(_dialog_title(title, QtMessageBox.Icon.Question))
        main_text, detail_text = _split_dialog_text(text)
        box.setText(main_text)
        box.setInformativeText(detail_text)
        box.setStandardButtons(buttons)
        destructive = any(word in (str(title) + " " + str(text)).casefold() for word in ("удалить", "удалена", "стереть", "сбросить"))
        if destructive:
            yes = box._standard_buttons.get(QtMessageBox.StandardButton.Yes)
            if yes is not None:
                box._button_roles[yes] = QtMessageBox.ButtonRole.DestructiveRole
                box._apply_button_kind(yes)
        if defaultButton != QtMessageBox.StandardButton.NoButton:
            box.setDefaultButton(defaultButton)
        result = box.exec()
        try:
            return QtMessageBox.StandardButton(result)
        except Exception:
            return QtMessageBox.StandardButton.NoButton


# Public compatibility name.  Importing ``QMessageBox`` from this module is
# intentional: existing SAI code can keep its proven control flow while every
# window receives one visual and behavioural standard.
QMessageBox = SAIMessageBox


__all__ = [
    "CatalogStatusBadge",
    "NotificationCenter",
    "NotificationToast",
    "QMessageBox",
    "SAIMessageBox",
    "StatusGlyph",
]
