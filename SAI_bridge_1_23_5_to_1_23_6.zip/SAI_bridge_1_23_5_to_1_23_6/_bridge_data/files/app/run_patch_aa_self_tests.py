#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import os,sys,tempfile,json
from pathlib import Path
root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_aa_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as m
assert m.CONTRACT_VERSION=='invoice_ai_contract_v6'
assert m.AUDIT_SCHEMA_VERSION=='invoice_audit_schema_v3'
assert m.build_audit_schema()['title']=='SAI Material Invoice Audit v3'
forbidden=m._OPENAI_UNSUPPORTED_SCHEMA_KEYWORDS

def scan(value,path=''):
    hits=[]
    if isinstance(value,dict):
        for key,child in value.items():
            p=f'{path}.{key}' if path else key
            if key in forbidden: hits.append(p)
            hits.extend(scan(child,p))
    elif isinstance(value,list):
        for i,child in enumerate(value): hits.extend(scan(child,f'{path}[{i}]'))
    return hits

invoice_schema=m.build_invoice_schema()
audit_schema=m.build_audit_schema()
assert not scan(invoice_schema), scan(invoice_schema)
assert not scan(audit_schema), scan(audit_schema)
changed=audit_schema['properties']['corrections']['items']['properties']['changed_fields']
assert 'uniqueItems' not in changed
# Build the exact strict response_format section that is sent to OpenAI.
class DummyPath:
    pass
# Avoid source files here: verify the schema block directly.
format_block={'type':'json_schema','name':'sai_material_invoice_audit_v3','strict':True,'schema':audit_schema}
assert format_block['strict'] is True and not scan(format_block['schema'])
# Ensure the local guard catches a future regression before any HTTP request.
bad=json.loads(json.dumps(audit_schema)); bad['properties']['corrections']['items']['properties']['changed_fields']['uniqueItems']=True
try:
    m._assert_openai_schema_compatible(bad,'test')
except m.OpenAIInvoiceError as exc:
    assert 'uniqueItems' in str(exc)
else:
    raise AssertionError('local schema guard did not reject uniqueItems')
print('PATCH_AA_SELF_TEST_OK')
