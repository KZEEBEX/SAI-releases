@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "sai_catalog_ready.py" --force
) else (
  py -3 "sai_catalog_ready.py" --force
)
pause
