"""Small dependency-free ECC200 Data Matrix encoder for product barcodes.

Thermal price labels only need short ASCII identifiers.  Keeping this encoder
inside SAI makes printing deterministic and fully offline on shop computers.
"""
from __future__ import annotations

from typing import Iterable


_SYMBOLS = (
    # symbol rows/cols, data rows/cols, data codewords, error codewords
    (10, 10, 8, 8, 3, 5),
    (12, 12, 10, 10, 5, 7),
    (14, 14, 12, 12, 8, 10),
    (16, 16, 14, 14, 12, 12),
    (18, 18, 16, 16, 18, 14),
    (20, 20, 18, 18, 22, 18),
    (22, 22, 20, 20, 30, 20),
    (24, 24, 22, 22, 36, 24),
    (26, 26, 24, 24, 44, 28),
)

_FACTORS = {
    5: (228, 48, 15, 111, 62),
    7: (23, 68, 144, 134, 240, 92, 254),
    10: (28, 24, 185, 166, 223, 248, 116, 255, 110, 61),
    12: (41, 153, 158, 91, 61, 42, 142, 213, 97, 178, 100, 242),
    14: (156, 97, 192, 252, 95, 9, 157, 119, 138, 45, 18, 186, 83, 185),
    18: (83, 195, 100, 39, 188, 75, 66, 61, 241, 213, 109, 129, 94, 254, 225, 48, 90, 188),
    20: (15, 195, 244, 9, 233, 71, 168, 2, 188, 160, 153, 145, 253, 79, 108, 82, 27, 174, 186, 172),
    24: (52, 190, 88, 205, 109, 39, 176, 21, 155, 197, 251, 223, 155, 21, 5, 172, 254, 124, 12, 181, 184, 96, 50, 193),
    28: (211, 231, 43, 97, 71, 96, 103, 174, 37, 151, 170, 53, 75, 34, 249, 121, 17, 138, 110, 213, 141, 136, 120, 151, 233, 168, 93, 255),
}


def _ascii_codewords(value: str) -> list[int]:
    raw = str(value or "").encode("latin-1", errors="strict")
    out: list[int] = []
    index = 0
    while index < len(raw):
        if index + 1 < len(raw) and 48 <= raw[index] <= 57 and 48 <= raw[index + 1] <= 57:
            out.append(130 + (raw[index] - 48) * 10 + raw[index + 1] - 48)
            index += 2
            continue
        code = raw[index]
        if code <= 127:
            out.append(code + 1)
        else:
            out.extend((235, code - 127))
        index += 1
    return out


def _pad(codewords: list[int], capacity: int) -> list[int]:
    result = list(codewords)
    if len(result) < capacity:
        result.append(129)
    while len(result) < capacity:
        position = len(result) + 1
        value = 129 + ((149 * position) % 253) + 1
        result.append(value if value <= 254 else value - 254)
    return result


def _gf_tables() -> tuple[list[int], list[int]]:
    alog = [0] * 255
    log = [0] * 256
    value = 1
    for index in range(255):
        alog[index] = value
        log[value] = index
        value <<= 1
        if value & 0x100:
            value ^= 0x12D
    return alog, log


_ALOG, _LOG = _gf_tables()


def _reed_solomon(data: Iterable[int], count: int) -> list[int]:
    factors = _FACTORS[count]
    ecc = [0] * count
    for codeword in data:
        feedback = ecc[-1] ^ int(codeword)
        for index in range(count - 1, 0, -1):
            product = 0 if feedback == 0 else _ALOG[(_LOG[feedback] + _LOG[factors[index]]) % 255]
            ecc[index] = ecc[index - 1] ^ product
        ecc[0] = 0 if feedback == 0 else _ALOG[(_LOG[feedback] + _LOG[factors[0]]) % 255]
    ecc.reverse()
    return ecc


def _place(codewords: list[int], rows: int, cols: int) -> list[list[bool]]:
    bits: list[list[bool | None]] = [[None for _ in range(cols)] for _ in range(rows)]

    def module(row: int, col: int, pos: int, bit: int) -> None:
        if row < 0:
            row += rows
            col += 4 - ((rows + 4) % 8)
        if col < 0:
            col += cols
            row += 4 - ((cols + 4) % 8)
        bits[row][col] = bool(codewords[pos] & (1 << (8 - bit)))

    def utah(row: int, col: int, pos: int) -> None:
        for bit, (dr, dc) in enumerate(((-2, -2), (-2, -1), (-1, -2), (-1, -1), (-1, 0), (0, -2), (0, -1), (0, 0)), 1):
            module(row + dr, col + dc, pos, bit)

    def corner1(pos: int) -> None:
        for bit, (row, col) in enumerate(((rows-1, 0), (rows-1, 1), (rows-1, 2), (0, cols-2), (0, cols-1), (1, cols-1), (2, cols-1), (3, cols-1)), 1): module(row, col, pos, bit)

    def corner2(pos: int) -> None:
        for bit, (row, col) in enumerate(((rows-3, 0), (rows-2, 0), (rows-1, 0), (0, cols-4), (0, cols-3), (0, cols-2), (0, cols-1), (1, cols-1)), 1): module(row, col, pos, bit)

    def corner3(pos: int) -> None:
        for bit, (row, col) in enumerate(((rows-3, 0), (rows-2, 0), (rows-1, 0), (0, cols-2), (0, cols-1), (1, cols-1), (2, cols-1), (3, cols-1)), 1): module(row, col, pos, bit)

    def corner4(pos: int) -> None:
        for bit, (row, col) in enumerate(((rows-1, 0), (rows-1, cols-1), (0, cols-3), (0, cols-2), (0, cols-1), (1, cols-3), (1, cols-2), (1, cols-1)), 1): module(row, col, pos, bit)

    row, col, pos = 4, 0, 0
    while True:
        if row == rows and col == 0:
            corner1(pos); pos += 1
        if row == rows - 2 and col == 0 and cols % 4 != 0:
            corner2(pos); pos += 1
        if row == rows - 2 and col == 0 and cols % 8 == 4:
            corner3(pos); pos += 1
        if row == rows + 4 and col == 2 and cols % 8 == 0:
            corner4(pos); pos += 1
        while True:
            if row < rows and col >= 0 and bits[row][col] is None:
                utah(row, col, pos); pos += 1
            row -= 2; col += 2
            if row < 0 or col >= cols:
                break
        row += 1; col += 3
        while True:
            if row >= 0 and col < cols and bits[row][col] is None:
                utah(row, col, pos); pos += 1
            row += 2; col -= 2
            if row >= rows or col < 0:
                break
        row += 3; col += 1
        if row >= rows and col >= cols:
            break
    if bits[rows - 1][cols - 1] is None:
        bits[rows - 1][cols - 1] = True
        bits[rows - 2][cols - 2] = True
    return [[bool(cell) for cell in line] for line in bits]


def encode_ecc200(value: str) -> list[list[bool]]:
    """Encode a short Latin-1 value as a square ECC200 symbol matrix."""
    data = _ascii_codewords(value)
    symbol = next((item for item in _SYMBOLS if len(data) <= item[4]), None)
    if symbol is None:
        raise ValueError("Data Matrix для этикетки поддерживает до 44 кодовых байтов.")
    symbol_rows, symbol_cols, data_rows, data_cols, capacity, error_count = symbol
    payload = _pad(data, capacity)
    placed = _place(payload + _reed_solomon(payload, error_count), data_rows, data_cols)
    matrix = [[False for _ in range(symbol_cols)] for _ in range(symbol_rows)]
    # All compact profiles have one data region: alternating top/right edges,
    # solid left/bottom edges form the standard ECC200 finder pattern.
    for col in range(symbol_cols):
        matrix[0][col] = col % 2 == 0
        matrix[-1][col] = True
    for row in range(1, symbol_rows - 1):
        matrix[row][0] = True
        matrix[row][-1] = row % 2 == 1
        for col in range(data_cols):
            matrix[row][col + 1] = placed[row - 1][col]
    return matrix


__all__ = ["encode_ecc200"]
