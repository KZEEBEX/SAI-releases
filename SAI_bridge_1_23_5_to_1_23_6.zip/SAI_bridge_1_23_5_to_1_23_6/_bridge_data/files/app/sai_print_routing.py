"""Strict printer routing for SAI documents and thermal labels."""
from __future__ import annotations

from typing import Any, Iterable


THERMAL_PRINTER_NAME_HINTS = (
    "4barcode",
    "xprinter",
    "gprinter",
    "label",
    "этикет",
    "tsc",
    "zebra",
    "argox",
    "godex",
    "pos",
)


def printer_name(value: Any) -> str:
    return str(value or "").strip()


def is_thermal_printer_name(value: Any) -> bool:
    compact = printer_name(value).casefold().replace(" ", "")
    return any(hint in compact for hint in THERMAL_PRINTER_NAME_HINTS)


def resolve_a4_printer_name(
    configured: Any,
    installed: Iterable[Any],
    default_printer: Any = "",
) -> str:
    """Choose an installed non-thermal printer for every A4 document.

    A thermal queue is never returned, even if it is configured or is the
    Windows default. This is the final safety boundary protecting label stock
    from NDP, invoices and A4 price-tag sheets.
    """
    names = [printer_name(item) for item in installed if printer_name(item)]
    by_casefold = {name.casefold(): name for name in names}
    requested = by_casefold.get(printer_name(configured).casefold(), "")
    if requested and not is_thermal_printer_name(requested):
        return requested
    default_name = by_casefold.get(printer_name(default_printer).casefold(), "")
    if default_name and not is_thermal_printer_name(default_name):
        return default_name
    return next((name for name in names if not is_thermal_printer_name(name)), "")


def require_a4_printer_name(value: Any) -> str:
    selected = printer_name(value)
    if not selected:
        raise RuntimeError("В настройках не выбран принтер «Обычная печать (A4)».")
    if is_thermal_printer_name(selected):
        raise RuntimeError(
            f"Печать A4 на термопринтер «{selected}» запрещена. "
            "Выберите обычный принтер в разделе «Настройки → Принтеры»."
        )
    return selected


__all__ = [
    "THERMAL_PRINTER_NAME_HINTS",
    "is_thermal_printer_name",
    "printer_name",
    "require_a4_printer_name",
    "resolve_a4_printer_name",
]
