#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
SAI API-first waybill filler.

v1.14:
- Browser is used only to make sure the SIGMA session is alive and to capture access token.
- Product search, waybill element creation and field updates are done through REST API by Python requests.
- No browser navigation to the draft page.
"""

import argparse
import csv
import concurrent.futures
import datetime as dt
import json
import math
import os
import re
import sqlite3
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

try:
    _sai_original_print = print
    def print(*args, **kwargs):
        kwargs.setdefault("flush", True)
        return _sai_original_print(*args, **kwargs)
except Exception:
    pass

import requests
from playwright.sync_api import sync_playwright

from sai_direct_network import configure_direct_network, direct_chromium_args

configure_direct_network()

from sigma_autoprihod import (
    DEFAULT_API_BASE,
    DEFAULT_CLOUD_URL,
    read_excel_rows,
    split_barcode_candidates,
    normalize_waybill_id,
    install_sigma_token_capture,
    wait_until_sigma_logged_in,
    click_common_popups,
    SigmaClient,
    recursive_find_first,
    extract_list_candidates,
    extract_product_id,
    extract_element_id,
    recursive_find_price,
    choose_selling_price,
    price_source_label,
    format_num,
)


from sai_runtime_paths import APP_DIR, USER_DATA_DIR, LOGS_DIR, PROFILE_DIR, CACHE_DIR, DB_PATH, ensure_runtime_dirs
from sai_secret_store import reveal_config_secret
from sai_core import classify_barcode


class ApiFirstError(RuntimeError):
    pass


class SigmaTransientError(ApiFirstError):
    """SIGMA request failed for a temporary network/server reason."""


def resolve_final_selling_price(
    row: Dict[str, Any],
    existing_selling_price: Optional[float],
    default_policy: str = "max",
) -> Tuple[float, str, str]:
    """Honor an explicit operator choice; otherwise always keep the highest price.

    The CLI still accepts legacy policy values for compatibility, but an
    unattended receipt must never lower a live product-card or waybill price.
    Only the semi-auto dialog's persisted ``price_operator_approved`` decision
    may deliberately keep the newly entered lower price.
    """
    operator_approved = bool(row.get("price_operator_approved"))
    policy = "incoming" if operator_approved else "max"
    final_price = choose_selling_price(row["selling_price"], existing_selling_price, policy)
    source = (
        "OPERATOR_APPROVED_" + safe_str(row.get("price_approval_source") or "incoming").upper()
        if operator_approved
        else price_source_label(row["selling_price"], existing_selling_price, final_price, policy)
    )
    return final_price, source, policy


def highest_known_price(*values: Any) -> Optional[float]:
    """Return the highest valid price received from SIGMA.

    The product search response and the waybill-element response can contain
    different prices. A new/partly filled draft may report zero or an older
    value for the element while the product card still contains the current
    retail price, so neither source may silently override the other.
    """
    prices: List[float] = []
    for value in values:
        if value is None:
            continue
        try:
            number = float(value)
        except (TypeError, ValueError):
            continue
        # SIGMA currently returns zero in some product-search and new-waybill
        # responses even when the product card has a real retail price.  Zero
        # therefore means "price was not supplied", not a price that may take
        # part in the max-price policy.
        if math.isfinite(number) and number > 0:
            prices.append(number)
    return max(prices) if prices else None


def catalog_selling_price(product_id: str, db_path: Optional[Path] = None) -> Optional[float]:
    """Read the last official catalog price cached by SAI for a SIGMA product."""
    wanted = safe_str(product_id)
    path = Path(db_path) if db_path is not None else Path(DB_PATH)
    if not wanted or not path.exists():
        return None
    try:
        con = sqlite3.connect(str(path), timeout=5)
        try:
            row = con.execute(
                "SELECT raw_json FROM products WHERE sigma_id=? LIMIT 1",
                (wanted,),
            ).fetchone()
        finally:
            con.close()
        raw = json.loads(row[0]) if row and row[0] else {}
        return highest_known_price(recursive_find_price(raw))
    except Exception:
        # A damaged or temporarily locked cache must not stop the receipt.  The
        # live SIGMA values still participate in the comparison below.
        return None


def safe_str(value: Any) -> str:
    return str(value or "").strip()


def json_or_text(response: requests.Response) -> Any:
    text = response.text or ""
    if not text:
        return None
    try:
        return response.json()
    except Exception:
        return text


RUNTIME_TOKEN_CACHE_PATH = CACHE_DIR / "sigma_runtime_token.json"

# SIGMA may route different companies to different api-sNN shards.  The cloud
# frontend can create a waybill successfully while a hard-coded shard answers
# 404 for the same id.  Probe only official SIGMA API shards and remember the
# one that actually owns the current waybill.
KNOWN_SIGMA_API_BASES = tuple(f"https://api-s{i:02d}.sigma.ru" for i in range(1, 13))


def api_base_candidates(preferred: str = "", cached: str = "") -> List[str]:
    out: List[str] = []
    for value in (preferred, cached, *KNOWN_SIGMA_API_BASES):
        base = safe_str(value).rstrip("/")
        if base and base not in out:
            out.append(base)
    return out


def load_runtime_token_cache_payload(max_age_seconds: int = 3600) -> Dict[str, str]:
    # Retain the public argument for callers; freshness has one shared policy.
    from sai_sigma_session import load_session
    payload = load_session(RUNTIME_TOKEN_CACHE_PATH)
    return {"token": payload["token"], "api_base": payload["api_base"]} if payload else {}


def _probe_waybill_on_base(token: str, waybill_id: str, api_base: str, timeout: int = 8) -> Dict[str, Any]:
    url = api_base.rstrip("/") + f"/waybills/{waybill_id}"
    try:
        response = requests.get(
            url,
            headers={
                "accept": "application/json, text/plain, */*",
                "authorization": "Bearer " + token,
            },
            timeout=timeout,
        )
        data = json_or_text(response)
        return {
            "api_base": api_base.rstrip("/"),
            "status": int(response.status_code),
            "data": data,
            "error": "",
        }
    except Exception as exc:
        return {
            "api_base": api_base.rstrip("/"),
            "status": 0,
            "data": None,
            "error": str(exc)[:240],
        }


def resolve_waybill_api_base(
    token: str,
    waybill_id: str,
    preferred: str = "",
    cached: str = "",
    attempts: int = 3,
) -> Tuple[str, Any, Dict[str, int]]:
    """Locate the SIGMA shard that owns a waybill.

    A 404 on one shard is not treated as an authentication failure.  We probe
    official shards in parallel and retry briefly because SIGMA can be
    eventually consistent immediately after creating a draft.
    """
    candidates = api_base_candidates(preferred, cached)
    last_statuses: Dict[str, int] = {}
    last_errors: Dict[str, str] = {}

    for attempt in range(1, max(1, int(attempts)) + 1):
        results: List[Dict[str, Any]] = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(candidates) or 1)) as pool:
            futures = [pool.submit(_probe_waybill_on_base, token, waybill_id, base) for base in candidates]
            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())

        # Prefer the explicitly requested/cached hosts when several return 200.
        by_base = {safe_str(item.get("api_base")): item for item in results}
        for base in candidates:
            item = by_base.get(base)
            if item and item.get("status") == 200:
                return base, item.get("data"), {safe_str(x.get("api_base")): int(x.get("status") or 0) for x in results}

        last_statuses = {safe_str(x.get("api_base")): int(x.get("status") or 0) for x in results}
        last_errors = {safe_str(x.get("api_base")): safe_str(x.get("error")) for x in results if safe_str(x.get("error"))}
        if attempt < attempts:
            print(
                f"SIGMA draft shard lookup: waybill not visible yet (attempt {attempt}/{attempts}); retrying..."
            )
            time.sleep(1.5 * attempt)

    status_summary = ", ".join(f"{base.rsplit('/', 1)[-1]}={status}" for base, status in last_statuses.items())
    error_summary = "; ".join(f"{base}: {err}" for base, err in list(last_errors.items())[:3])
    details = status_summary or error_summary or "no responses"
    raise ApiFirstError(
        "SIGMA created the draft, but the waybill was not found on any known API shard. "
        f"waybillId={waybill_id}. Probe results: {details}. "
        "The draft may have been deleted in SIGMA or the account may use a new shard. "
        "Open the draft in SIGMA and retry; SAI has not written any receipt rows."
    )


def save_runtime_token_cache(token: str, api_base: str):
    try:
        from sai_sigma_session import save_session
        save_session(token, api_base, RUNTIME_TOKEN_CACHE_PATH)
    except Exception:
        pass


def load_runtime_token_cache(api_base: str, max_age_seconds: int = 3600) -> str:
    payload = load_runtime_token_cache_payload(max_age_seconds=max_age_seconds)
    if not payload:
        return ""
    if safe_str(payload.get("api_base")).rstrip("/") != api_base.rstrip("/"):
        return ""
    return safe_str(payload.get("token"))


def extract_storehouse_from_waybill(data: Any) -> str:
    for key in ("storehouseDestination", "destinationStorehouse", "recipientStorehouse", "storehouse"):
        obj = recursive_find_first(data, (key,))
        if isinstance(obj, dict) and obj.get("id"):
            return safe_str(obj.get("id"))

    found = recursive_find_first(data, (
        "storehouseId",
        "storeHouseId",
        "warehouseId",
        "targetStorehouseId",
        "destinationStorehouseId",
        "recipientStorehouseId",
    ))
    return safe_str(found)


def launch_persistent_sigma_context(playwright, user_data_dir: str, visible: bool, prefer_bundled_chromium: bool = True):
    browser_kwargs = {
        "headless": not visible,
        "args": direct_chromium_args(["--start-maximized"] if visible else []),
    }
    user_data_dir = str(Path(user_data_dir).resolve())
    if prefer_bundled_chromium:
        return playwright.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            **browser_kwargs,
        )
    try:
        return playwright.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            channel="chrome",
            **browser_kwargs,
        )
    except Exception:
        print("System Chrome did not start, trying bundled Chromium.")
        return playwright.chromium.launch_persistent_context(
            user_data_dir=user_data_dir,
            **browser_kwargs,
        )


def capture_sigma_token(
    user_data_dir: str,
    api_base: str,
    cloud_url: str,
    sigma_login: str,
    sigma_password: str,
    sigma_legacy_login: str = "",
    sigma_legacy_password: str = "",
    sigma_atol_max_attempts: int = 3,
    timeout_sec: int = 120,
    visible: bool = True,
    prefer_bundled_chromium: bool = True,
    hidden_auto_visible_after: int = 0,
) -> str:
    attempts = []
    if visible:
        attempts.append((True, timeout_sec, "visible browser"))
    else:
        auto_visible_after = int(hidden_auto_visible_after or 0)
        quick_timeout = max(5, min(int(timeout_sec or 120), auto_visible_after)) if auto_visible_after > 0 else int(timeout_sec or 120)
        attempts.append((False, quick_timeout, "hidden browser"))
        if auto_visible_after > 0:
            attempts.append((True, int(timeout_sec or 120), "visible browser after hidden fallback"))

    last_error = None
    for attempt_index, (attempt_visible, attempt_timeout, attempt_label) in enumerate(attempts, start=1):
        print("PHASE 1/2: SIGMA session/token check" + f" ({attempt_label})")
        p = sync_playwright().start()
        context = None
        try:
            context = launch_persistent_sigma_context(
                p,
                user_data_dir,
                attempt_visible,
                prefer_bundled_chromium=prefer_bundled_chromium,
            )

            page = context.pages[0] if context.pages else context.new_page()
            install_sigma_token_capture(page)

            login_url = cloud_url.rstrip("/") + "/documents"
            print(f"Opening SIGMA once for API token: {login_url}")
            try:
                page.goto(login_url, wait_until="domcontentloaded", timeout=60000)
            except Exception as e:
                print(f"Initial SIGMA navigation interrupted: {str(e)[:180]}")

            ok = wait_until_sigma_logged_in(
                page,
                cloud_url,
                api_base,
                sigma_login=sigma_login,
                sigma_password=sigma_password,
                timeout_sec=attempt_timeout,
                legacy_login=sigma_legacy_login,
                legacy_password=sigma_legacy_password,
                atol_max_attempts=sigma_atol_max_attempts,
            )
            if not ok:
                raise ApiFirstError("SIGMA login/token check did not finish in time.")

            click_common_popups(page, rounds=6)
            client = SigmaClient(page, api_base, cloud_url, verbose=False)
            token = client.get_api_access_token()
            if not token:
                raise ApiFirstError("SIGMA access token not found after login.")

            print("SIGMA token captured. Browser is no longer needed for filling.")
            return token
        except Exception as e:
            last_error = e
            try:
                if context is not None:
                    context.close()
            except Exception:
                pass
            try:
                p.stop()
            except Exception:
                pass
            if (not attempt_visible) and attempt_index < len(attempts):
                print(
                    f"Hidden SIGMA session did not become ready in {attempt_timeout} sec; "
                    "reopening visible browser so login can be completed."
                )
                continue
            break
    raise ApiFirstError(str(last_error) if last_error else "SIGMA login/token check failed.")


class SigmaRestClient:
    def __init__(self, token: str, api_base: str = DEFAULT_API_BASE):
        self.api_base = api_base.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "authorization": "Bearer " + token,
        })

    def url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return self.api_base + path

    def request(
        self,
        method: str,
        path: str,
        body: Any = None,
        params: Optional[dict] = None,
        timeout: int = 45,
        attempts: Optional[int] = None,
    ) -> Any:
        url = self.url(path)
        verb = method.upper()
        # Product search is a read operation despite using POST. GET and PUT are
        # idempotent as well, so a timeout can be retried without duplicating a
        # receipt row. Mutating POST is reconciled separately below.
        retry_safe = verb in {"GET", "PUT"} or "/rest/v4/products/simple" in path
        total_attempts = max(1, int(attempts if attempts is not None else (4 if retry_safe else 1)))
        transient_statuses = {408, 425, 429, 500, 502, 503, 504}
        last_error: Optional[BaseException] = None
        for attempt in range(1, total_attempts + 1):
            try:
                response = self.session.request(verb, url, json=body, params=params, timeout=timeout)
                data = json_or_text(response)
                if 200 <= response.status_code < 300:
                    return data
                preview = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)[:700]
                message = f"{verb} {url} -> HTTP {response.status_code}: {preview}"
                if response.status_code not in transient_statuses:
                    raise ApiFirstError(message)
                last_error = SigmaTransientError(message)
            except (requests.Timeout, requests.ConnectionError) as exc:
                last_error = exc
            if attempt < total_attempts:
                delay = min(6, attempt * 2)
                print(f"  SIGMA temporarily unavailable; retry {attempt + 1}/{total_attempts} in {delay} sec...")
                time.sleep(delay)
        raise SigmaTransientError(str(last_error or f"{verb} {url}: temporary SIGMA error"))

    def get_waybill_info(self, waybill_id: str) -> Any:
        return self.request("GET", f"/waybills/{waybill_id}")

    def find_product_by_barcode(self, barcode: str, storehouse_id: Optional[str], waybill_id: Optional[str] = None) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]]]:
        body = {
            "isProduced": None,
            "name": barcode,
            "storehouseId": storehouse_id,
            "waybillId": waybill_id,
        }
        data = self.request("POST", "/rest/v4/products/simple?page=0", body)
        candidates = extract_list_candidates(data)
        return (candidates[0] if candidates else None, candidates)

    def get_existing_element(self, waybill_id: str, product_id: str) -> Any:
        return self.request("GET", f"/waybills/{waybill_id}/elements/product/{product_id}")

    def add_product_to_waybill(self, waybill_id: str, product_id: str) -> Any:
        path = f"/waybills/{waybill_id}/elements/product/{product_id}"
        last_error: Optional[BaseException] = None
        for attempt in range(1, 4):
            try:
                return self.request("POST", path, {"productId": product_id}, attempts=1)
            except SigmaTransientError as exc:
                last_error = exc
                # The server may have accepted the POST before the connection
                # timed out. Read the draft before ever sending the POST again.
                try:
                    existing = self.get_existing_element(waybill_id, product_id)
                    if extract_element_id(existing):
                        print("  add response was lost, but the product is already present; continuing safely")
                        return existing
                except Exception:
                    pass
                if attempt < 3:
                    delay = attempt * 2
                    print(f"  add product retry {attempt + 1}/3 in {delay} sec...")
                    time.sleep(delay)
        raise SigmaTransientError(str(last_error or "SIGMA did not confirm product addition"))

    def set_quantity(self, waybill_id: str, element_id: str, value: float) -> Any:
        return self.request("PUT", f"/waybills/{waybill_id}/elements/{element_id}/quantity", {"value": value})

    def set_buying_price(self, waybill_id: str, element_id: str, value: float) -> Any:
        return self.request("PUT", f"/waybills/{waybill_id}/elements/{element_id}/buying-cost-per-unit", {"value": value})

    def set_selling_price(self, waybill_id: str, element_id: str, value: float) -> Any:
        return self.request("PUT", f"/waybills/{waybill_id}/elements/{element_id}/selling-cost-per-unit", {"value": value})

    def get_totals(self, waybill_id: str) -> Tuple[Any, Any]:
        buying = self.request("GET", f"/waybills/{waybill_id}/buying-amount")
        selling = self.request("GET", f"/waybills/{waybill_id}/selling-amount")
        return buying, selling


def _json_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    text = safe_str(value)
    if not text:
        return {}
    try:
        parsed = json.loads(text)
    except Exception:
        return {}
    return dict(parsed) if isinstance(parsed, dict) else {}


def _normalized_product_name(value: Any) -> str:
    text = safe_str(value).casefold().replace("ё", "е")
    return re.sub(r"[^0-9a-zа-я]+", "", text)


def _conflict_resolution_name_key(value: Any) -> str:
    text = safe_str(value).upper().replace("Ё", "Е").replace("X", "Х")
    text = re.sub(r"[\"'`«»„“”()\[\]{}.,;:]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _unique_exact_name_candidate(
    candidates: List[Dict[str, Any]],
    row_name: str,
) -> Optional[Dict[str, Any]]:
    expected = _normalized_product_name(row_name)
    if not expected:
        return None
    matches = [
        candidate for candidate in candidates
        if _normalized_product_name(candidate.get("name")) == expected
    ]
    return matches[0] if len(matches) == 1 else None


def _saved_conflict_product_id(row: Dict[str, Any]) -> str:
    path = USER_DATA_DIR / "barcode_conflict_resolutions.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return ""
    codes = ",".join(sorted(set(split_barcode_candidates(row.get("barcode")))))
    key = f"{codes}|{_conflict_resolution_name_key(row.get('name'))}"
    saved = payload.get(key) if isinstance(payload, dict) else None
    return safe_str(saved.get("product_id") if isinstance(saved, dict) else saved)


def _candidate_by_id(candidates: List[Dict[str, Any]], product_id: str) -> Optional[Dict[str, Any]]:
    wanted = safe_str(product_id)
    if not wanted:
        return None
    matches = [
        candidate for candidate in candidates
        if safe_str(candidate.get("id") or candidate.get("productId")) == wanted
    ]
    return matches[0] if len(matches) == 1 else None


def find_product_in_refreshed_catalog(
    barcode: str,
    row_name: str = "",
    preferred_product_id: str = "",
) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]], str]:
    """Resolve a barcode through SAI's refreshed official SIGMA catalog.

    SIGMA's cloud `/rest/v4/products/simple` search does not reliably return
    short internal barcodes (for example six-digit codes), while the official
    X-Api-Key `/products` catalog does contain them.  SAI stores that catalog in
    SQLite immediately before receipt validation.  A unique barcode->productId
    mapping is therefore a safe fallback; ambiguous mappings are never guessed.
    """
    code = safe_str(barcode)
    if not code or not Path(DB_PATH).exists():
        return None, [], "catalog database is unavailable"

    try:
        con = sqlite3.connect(str(DB_PATH), timeout=5)
        con.row_factory = sqlite3.Row
        try:
            rows = con.execute(
                """
                SELECT DISTINCT b.product_id, p.name, p.raw_json, p.barcodes_json
                FROM barcodes b
                LEFT JOIN products p
                  ON p.sigma_id = b.product_id
                 AND p.company_key = b.company_key
                 AND p.sell_point_id = b.sell_point_id
                WHERE b.barcode = ?
                """,
                (code,),
            ).fetchall()
        finally:
            con.close()
    except Exception as exc:
        return None, [], f"catalog lookup error: {str(exc)[:160]}"

    by_id: Dict[str, Dict[str, Any]] = {}
    for row in rows:
        product_id = safe_str(row["product_id"])
        if not product_id:
            continue
        raw = _json_dict(row["raw_json"])
        raw.setdefault("id", product_id)
        raw.setdefault("productId", product_id)
        if safe_str(row["name"]):
            raw.setdefault("name", safe_str(row["name"]))
        raw["_sai_lookup_source"] = "refreshed_sqlite_catalog"
        raw["_sai_lookup_barcode"] = code
        by_id[product_id] = raw

    candidates = list(by_id.values())
    if len(candidates) == 1:
        return candidates[0], candidates, "unique productId from refreshed SIGMA catalog"
    if len(candidates) > 1:
        preferred = _candidate_by_id(candidates, preferred_product_id)
        if preferred is not None:
            return preferred, candidates, "barcode duplicate resolved by saved operator choice"
        exact = _unique_exact_name_candidate(candidates, row_name)
        if exact is not None:
            return exact, candidates, "barcode duplicate resolved by unique exact product name"
        ids = ", ".join(sorted(by_id)[:5])
        return None, candidates, f"barcode conflict in refreshed catalog: {ids}"
    return None, [], "barcode absent from refreshed catalog"


def get_rest_client_with_cached_token_or_browser(args) -> SigmaRestClient:
    cache = load_runtime_token_cache_payload()
    cached_token = safe_str(cache.get("token"))
    cached_base = safe_str(cache.get("api_base")).rstrip("/")

    if cached_token:
        try:
            resolved_base, _waybill, statuses = resolve_waybill_api_base(
                cached_token,
                args.waybill_id,
                preferred=args.api_base,
                cached=cached_base,
            )
            args.api_base = resolved_base
            save_runtime_token_cache(cached_token, resolved_base)
            if resolved_base != safe_str(cached_base).rstrip("/"):
                print(f"SIGMA API shard resolved: {resolved_base} (cached shard was {cached_base or 'unknown'}).")
            else:
                print("SIGMA token: using cached runtime token, browser token check skipped.")
            return SigmaRestClient(cached_token, resolved_base)
        except Exception as e:
            # A 404 is a shard/draft lookup problem, not proof that the token is bad.
            # We still refresh the token once because an expired/changed session can
            # produce misleading responses on some SIGMA installations.
            print(f"SIGMA cached token/draft check failed, opening browser once: {str(e)[:260]}")

    visible = True
    if bool(getattr(args, "hidden_browser", False)):
        visible = False
    elif bool(getattr(args, "visible_browser", False)):
        visible = True

    token = capture_sigma_token(
        args.user_data_dir,
        args.api_base,
        args.cloud_url,
        args.sigma_login,
        args.sigma_password,
        args.sigma_legacy_login,
        args.sigma_legacy_password,
        args.sigma_atol_max_attempts,
        timeout_sec=args.login_timeout,
        visible=visible,
        prefer_bundled_chromium=bool(getattr(args, "prefer_bundled_chromium", False)),
        hidden_auto_visible_after=int(getattr(args, "hidden_auto_visible_after", 0) or 0),
    )
    resolved_base, _waybill, statuses = resolve_waybill_api_base(
        token,
        args.waybill_id,
        preferred=args.api_base,
        cached=cached_base,
    )
    args.api_base = resolved_base
    save_runtime_token_cache(token, resolved_base)
    print(f"SIGMA API shard for current draft: {resolved_base}")
    return SigmaRestClient(token, resolved_base)


def resolve_product_for_row(args, client: SigmaRestClient, row: Dict[str, Any], storehouse_id: str) -> Tuple[Dict[str, Any], str, List[Dict[str, Any]], List[str]]:
    """Find a live SIGMA product for an Excel row by barcode candidates.

    This intentionally uses the same live API search as APPLY, not the local
    SQLite/JSON catalog cache. v1.17.3 uses it for a preflight guard so stale
    cache entries cannot cause partial writes after products were deleted in SIGMA.
    """
    barcode_candidates = split_barcode_candidates(row["barcode"])
    if not barcode_candidates:
        raise ApiFirstError("barcode is empty")

    product = None
    candidates: List[Dict[str, Any]] = []
    used_barcode = ""
    not_found_codes: List[str] = []
    preferred_product_id = _saved_conflict_product_id(row)

    for code in barcode_candidates:
        attempts = []
        if storehouse_id:
            attempts.append(("storehouse", storehouse_id, None))
            attempts.append(("storehouse+waybill", storehouse_id, args.waybill_id))
        attempts.append(("waybill", None, args.waybill_id))
        attempts.append(("global", None, None))

        for label, sid, wid in attempts:
            try:
                product, candidates = client.find_product_by_barcode(code, sid, wid)
            except Exception as e:
                not_found_codes.append(f"{code}/{label}: {str(e)[:160]}")
                continue

            if product and len(candidates) <= 1:
                used_barcode = code
                return product, used_barcode, candidates, not_found_codes
            if candidates:
                preferred = _candidate_by_id(candidates, preferred_product_id)
                if preferred is not None:
                    used_barcode = code
                    not_found_codes.append(f"{code}/{label}: barcode duplicate resolved by saved choice")
                    return preferred, used_barcode, candidates, not_found_codes
                exact = _unique_exact_name_candidate(candidates, safe_str(row.get("name")))
                if exact is not None:
                    used_barcode = code
                    not_found_codes.append(f"{code}/{label}: barcode duplicate resolved by exact name")
                    return exact, used_barcode, candidates, not_found_codes

        # The cloud text-search endpoint is known to miss short/internal barcodes.
        # Fall back to the official catalog that SAI refreshed into SQLite.
        fallback_product, fallback_candidates, fallback_note = find_product_in_refreshed_catalog(
            code,
            safe_str(row.get("name")),
            preferred_product_id,
        )
        if fallback_product:
            used_barcode = code
            not_found_codes.append(f"{code}/catalog-fallback: {fallback_note}")
            return fallback_product, used_barcode, fallback_candidates, not_found_codes
        if fallback_candidates:
            not_found_codes.append(f"{code}/catalog-fallback: {fallback_note}")
        else:
            not_found_codes.append(code)

    details = ", ".join(not_found_codes[:8]) or ", ".join(barcode_candidates)
    raise ApiFirstError("product not found by any barcode: " + details)


def preflight_verify_rows(args, client: SigmaRestClient, rows: List[Dict[str, Any]], storehouse_id: str) -> Tuple[int, Path]:
    """Before APPLY, verify every row live before writing anything.

    If some products were deleted from SIGMA while still present in SAI's SQLite
    cache, the old flow could write the found half and then fail on the rest.
    This guard stops before the first write.
    """
    ensure_runtime_dirs()
    log_path = LOGS_DIR / f"sigma_api_preflight_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    fieldnames = ["excel_row", "barcode", "used_barcode", "barcode_status", "name", "status", "product_id", "message"]
    errors = 0
    print("")
    print("SAI safety preflight: checking all products live before APPLY...")
    with open(log_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        for idx, row in enumerate(rows, 1):
            log_row = {
                "excel_row": row.get("excel_row", ""),
                "barcode": row.get("barcode", ""),
                "used_barcode": "",
                "barcode_status": "",
                "name": row.get("name", ""),
                "status": "",
                "product_id": "",
                "message": "",
            }
            try:
                product, used_barcode, _candidates, _notes = resolve_product_for_row(args, client, row, storehouse_id)
                product_id = extract_product_id(product)
                if not product_id:
                    raise ApiFirstError("cannot extract productId from SIGMA response")
                # Read-only waybill lookup validates the productId before APPLY writes
                # any row. It also works when the product is not yet in the waybill.
                client.get_existing_element(args.waybill_id, product_id)
                log_row["used_barcode"] = used_barcode
                log_row["barcode_status"] = classify_barcode(used_barcode)
                log_row["product_id"] = product_id
                log_row["status"] = "OK"
                log_row["message"] = "live product found"
                print(f"  preflight OK [{idx}/{len(rows)}]: {used_barcode} — {row.get('name', '')}")
            except Exception as e:
                errors += 1
                log_row["status"] = "ERROR"
                log_row["message"] = str(e)
                print(f"  PREFLIGHT ERROR [{idx}/{len(rows)}]: {row.get('barcode', '')} — {row.get('name', '')}: {e}")
            writer.writerow(log_row)
    return errors, log_path


def process_rows(args, client: SigmaRestClient, rows: List[Dict[str, Any]], storehouse_id: str) -> Tuple[int, int, Path]:
    ensure_runtime_dirs()
    log_path = LOGS_DIR / f"sigma_api_first_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    fieldnames = [
        "excel_row",
        "barcode",
        "used_barcode",
        "barcode_status",
        "name",
        "quantity",
        "buying_price",
        "incoming_selling_price",
        "sigma_existing_selling_price",
        "final_selling_price",
        "price_source",
        "status",
        "product_id",
        "element_id",
        "message",
    ]

    processed = 0
    errors = 0

    with open(log_path, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for idx, row in enumerate(rows, 1):
            print("")
            print(f"[{idx}/{len(rows)}] Barcode {row['barcode']} — {row.get('name', '')}")

            log_row = {
                "excel_row": row["excel_row"],
                "barcode": row["barcode"],
                "used_barcode": "",
                "barcode_status": "",
                "name": row.get("name", ""),
                "quantity": row["quantity"],
                "buying_price": row["buying_price"],
                "incoming_selling_price": row["selling_price"],
                "sigma_existing_selling_price": "",
                "final_selling_price": "",
                "price_source": "",
                "status": "",
                "product_id": "",
                "element_id": "",
                "message": "",
            }

            try:
                barcode_candidates = split_barcode_candidates(row["barcode"])
                product, used_barcode, candidates, _notes = resolve_product_for_row(args, client, row, storehouse_id)

                log_row["used_barcode"] = used_barcode
                log_row["barcode_status"] = classify_barcode(used_barcode)

                if len(barcode_candidates) > 1:
                    print(f"  multiple barcodes in cell: {', '.join(barcode_candidates)}")
                    print(f"  used barcode: {used_barcode}")

                product_id = extract_product_id(product)
                if not product_id:
                    raise ApiFirstError("cannot extract productId from SIGMA response")

                log_row["product_id"] = product_id
                print(f"  productId: {product_id}")
                if safe_str(product.get("_sai_lookup_source")) == "refreshed_sqlite_catalog":
                    print("  lookup source: refreshed SAI catalog fallback (short/internal barcode supported)")

                product_existing_price = recursive_find_price(product)
                cached_catalog_price = catalog_selling_price(product_id)

                existing = client.get_existing_element(args.waybill_id, product_id)
                element_id = extract_element_id(existing)
                element_existing_price = recursive_find_price(existing)

                existing_selling_price = highest_known_price(
                    product_existing_price,
                    element_existing_price,
                    cached_catalog_price,
                )
                final_selling_price, price_source, policy = resolve_final_selling_price(
                    row, existing_selling_price, args.price_policy,
                )

                log_row["sigma_existing_selling_price"] = "" if existing_selling_price is None else existing_selling_price
                log_row["final_selling_price"] = final_selling_price
                log_row["price_source"] = price_source

                if existing_selling_price is None:
                    print(f"  SIGMA existing selling price: not found, using incoming {format_num(row['selling_price'])}")
                else:
                    print(f"  incoming selling price: {format_num(row['selling_price'])}")
                    print(f"  SIGMA existing selling price: {format_num(existing_selling_price)}")
                    if cached_catalog_price is not None:
                        print(f"  refreshed SAI catalog price: {format_num(cached_catalog_price)}")
                    print(f"  final selling price ({policy}): {format_num(final_selling_price)}")
                print(f"  price source: {price_source}")

                if element_id:
                    print(f"  product already in waybill, elementId: {element_id}")
                else:
                    print("  product not yet in waybill")
                    if args.apply:
                        added = client.add_product_to_waybill(args.waybill_id, product_id)
                        element_id = extract_element_id(added)
                        if not element_id:
                            raise ApiFirstError("product added, but elementId not found in response")
                        print(f"  added, elementId: {element_id}")

                        added_price = recursive_find_price(added)
                        # A newly added SIGMA element may explicitly return
                        # sellingPrice=null or 0 until its fields are written.
                        # Such a value means "not supplied" and must not enter
                        # the price comparison or be formatted as a number.
                        if highest_known_price(added_price) is not None:
                            existing_selling_price = highest_known_price(existing_selling_price, added_price)
                            final_selling_price, price_source, policy = resolve_final_selling_price(
                                row, existing_selling_price, args.price_policy,
                            )
                            log_row["sigma_existing_selling_price"] = existing_selling_price
                            log_row["final_selling_price"] = final_selling_price
                            log_row["price_source"] = price_source
                            print(f"  SIGMA existing selling price after add: {format_num(existing_selling_price)}")
                            print(f"  final selling price ({policy}): {format_num(final_selling_price)}")
                            print(f"  price source: {price_source}")
                    else:
                        element_id = "DRY-RUN"
                        print("  DRY-RUN: add skipped")

                log_row["element_id"] = element_id

                if args.apply:
                    # Sequential is deliberate: old parallel mode was unsafe on SIGMA.
                    client.set_quantity(args.waybill_id, element_id, row["quantity"])
                    print(f"  quantity: {format_num(row['quantity'])}")

                    client.set_buying_price(args.waybill_id, element_id, row["buying_price"])
                    print(f"  buying price: {format_num(row['buying_price'])}")

                    client.set_selling_price(args.waybill_id, element_id, final_selling_price)
                    print(f"  selling price written: {format_num(final_selling_price)}")
                else:
                    print(f"  DRY-RUN: would set quantity {format_num(row['quantity'])}, buying {format_num(row['buying_price'])}, selling {format_num(final_selling_price)}")

                log_row["status"] = "OK"
                log_row["message"] = "processed" if args.apply else "dry-run ok"
                processed += 1

            except Exception as e:
                errors += 1
                log_row["status"] = "ERROR"
                log_row["message"] = str(e)
                print(f"  ERROR: {e}")
                if args.stop_on_error:
                    writer.writerow(log_row)
                    print("Stopped because --stop-on-error is enabled.")
                    break

            writer.writerow(log_row)

    return processed, errors, log_path


def create_price_audit_xlsx(log_path: Path) -> Optional[Path]:
    """Create a human-readable XLSX report explaining totals and selected prices."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
        from openpyxl.utils import get_column_letter
    except Exception as e:
        print(f"Price audit XLSX skipped: openpyxl unavailable: {e}")
        return None

    if not log_path or not Path(log_path).exists():
        return None

    def to_float(v: Any) -> float:
        s = str(v or "").strip().replace("\xa0", "").replace(" ", "").replace(",", ".")
        try:
            return float(s)
        except Exception:
            return 0.0

    with open(log_path, "r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f, delimiter=";"))

    wb = Workbook()
    ws = wb.active
    ws.title = "Разбор цен"
    headers = [
        "№", "Строка Excel", "ШК", "Исп. ШК", "Статус ШК", "Наименование", "Кол-во",
        "Закуп", "Продажа SAI", "Продажа SIGMA", "Итоговая продажа", "Источник цены",
        "Сумма закуп", "Сумма продажи", "Статус", "Сообщение",
    ]
    ws.append(headers)
    ok_buying = 0.0
    ok_selling = 0.0
    for i, r in enumerate(rows, 1):
        qty = to_float(r.get("quantity"))
        buying = to_float(r.get("buying_price"))
        final_selling = to_float(r.get("final_selling_price") or r.get("incoming_selling_price"))
        status = str(r.get("status") or "").upper()
        buy_sum = qty * buying
        sell_sum = qty * final_selling
        if status == "OK":
            ok_buying += buy_sum
            ok_selling += sell_sum
        ws.append([
            i, r.get("excel_row"), r.get("barcode"), r.get("used_barcode"), r.get("barcode_status"),
            r.get("name"), qty, buying, to_float(r.get("incoming_selling_price")),
            "" if str(r.get("sigma_existing_selling_price") or "").strip() == "" else to_float(r.get("sigma_existing_selling_price")),
            final_selling, r.get("price_source"), buy_sum, sell_sum, status, r.get("message"),
        ])

    total_row = ws.max_row + 2
    ws.cell(total_row, 12).value = "ИТОГО OK"
    ws.cell(total_row, 13).value = ok_buying
    ws.cell(total_row, 14).value = ok_selling
    ws.cell(total_row, 12).font = Font(bold=True)
    ws.cell(total_row, 13).font = Font(bold=True)
    ws.cell(total_row, 14).font = Font(bold=True)

    header_fill = PatternFill("solid", fgColor="1F4E79")
    thin = Side(style="thin", color="D9E2F3")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
        for cell in row:
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
    for col in range(1, ws.max_column + 1):
        width = 12
        if col in (6, 16):
            width = 42
        elif col in (3, 4):
            width = 20
        elif col in (11, 12):
            width = 18
        ws.column_dimensions[get_column_letter(col)].width = width
    for col in (7, 8, 9, 10, 11, 13, 14):
        for cell in ws.iter_cols(min_col=col, max_col=col, min_row=2, max_row=ws.max_row):
            for c in cell:
                c.number_format = "0.00"
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:P{max(1, ws.max_row)}"

    out_path = Path(log_path).with_name(Path(log_path).stem.replace("sigma_api_first", "price_audit") + ".xlsx")
    wb.save(out_path)
    return out_path


def parse_args():
    parser = argparse.ArgumentParser(description="SAI API-first SIGMA waybill filler")
    parser.add_argument("--excel", required=True)
    parser.add_argument("--sheet", default="Для робота SIGMA")
    parser.add_argument("--waybill-id", required=True)
    parser.add_argument("--storehouse-id", default="")
    parser.add_argument("--user-data-dir", default=str(PROFILE_DIR))
    parser.add_argument("--api-base", default=DEFAULT_API_BASE)
    parser.add_argument("--cloud-url", default=DEFAULT_CLOUD_URL)
    parser.add_argument("--sigma-login", default="")
    parser.add_argument("--sigma-password", default="")
    parser.add_argument("--sigma-legacy-login", default="")
    parser.add_argument("--sigma-legacy-password", default="")
    parser.add_argument("--sigma-atol-max-attempts", type=int, default=3)
    parser.add_argument("--login-timeout", type=int, default=120)
    parser.add_argument("--price-policy", choices=["max", "incoming", "sigma", "keep_sigma"], default=os.environ.get("SAI_PRICE_POLICY", "max"))
    parser.add_argument("--visible-browser", action="store_true", help="Show SIGMA browser when a fresh token is needed")
    parser.add_argument("--hidden-browser", action="store_true", help="Use hidden browser when a fresh token is needed")
    parser.add_argument("--prefer-bundled-chromium", action="store_true", help="Skip System Chrome probe and use Playwright bundled Chromium")
    parser.add_argument("--hidden-auto-visible-after", type=int, default=0, help="When hidden browser cannot login quickly, reopen visible browser after N seconds; 0 = never")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--stop-on-error", action="store_true")
    parser.add_argument("--live-preflight", action="store_true", help="Optional paranoid live check of every row before APPLY")
    return parser.parse_args()


def main():
    args = parse_args()
    args.sigma_password = reveal_config_secret(args.sigma_password)
    args.sigma_legacy_password = reveal_config_secret(args.sigma_legacy_password)
    args.waybill_id = normalize_waybill_id(args.waybill_id)

    rows = read_excel_rows(args.excel, args.sheet)
    print("=" * 72)
    print("SAI API-FIRST SIGMA FILL")
    print(f"Excel: {args.excel}")
    print(f"Sheet: {args.sheet}")
    print(f"waybillId: {args.waybill_id}")
    print("Mode: APPLY / REST write" if args.apply else "Mode: DRY-RUN / no write")
    print("Browser: token only, no draft-page automation" + (" / hidden" if getattr(args, "hidden_browser", False) else " / visible"))
    print(f"Rows: {len(rows)}")
    print("=" * 72)

    # v1.22.7g: resolve the actual SIGMA api-sNN shard by waybillId before any row processing.
    client = get_rest_client_with_cached_token_or_browser(args)

    print("")
    print("PHASE 2/2: REST API waybill filling")
    waybill = client.get_waybill_info(args.waybill_id)

    storehouse_id = safe_str(args.storehouse_id) or extract_storehouse_from_waybill(waybill)
    if not storehouse_id:
        raise SystemExit("Cannot determine storehouseId for product search.")

    inferred = extract_storehouse_from_waybill(waybill)
    if inferred and inferred != storehouse_id:
        print(f"storehouse override: using waybill storehouse {inferred} instead of passed {storehouse_id}")
        storehouse_id = inferred
    print(f"storehouseId: {storehouse_id}")

    if args.apply:
        # Normal SAI flow trusts the catalog that was refreshed into SQLite at startup
        # or after the user pressed “Импорт выполнен — обновить каталог и проверить”.
        # But APPLY must not continue after a live SIGMA row error, otherwise a stale
        # catalog can smear ERROR rows across half of the waybill.
        args.stop_on_error = True
        print("APPLY safety: stop on first row error is enabled.")

    if args.apply and getattr(args, "live_preflight", False):
        preflight_errors, preflight_log_path = preflight_verify_rows(args, client, rows, storehouse_id)
        rel_preflight = preflight_log_path
        try:
            rel_preflight = preflight_log_path.relative_to(APP_DIR)
        except Exception:
            pass
        print(f"Preflight log: {rel_preflight}")
        if preflight_errors:
            print("")
            print("SAI STOP: APPLY blocked before writing anything.")
            print(f"Reason: live SIGMA preflight found missing/deleted products: {preflight_errors}")
            print("Refresh catalog / re-import / add missing barcodes, then check again.")
            raise SystemExit(6)

    processed, errors, log_path = process_rows(args, client, rows, storehouse_id)

    audit_path = create_price_audit_xlsx(log_path)
    if audit_path:
        try:
            rel_audit = audit_path.relative_to(APP_DIR.parent)
        except Exception:
            rel_audit = audit_path
        print(f"Price audit: {rel_audit}")

    if args.apply:
        try:
            buying, selling = client.get_totals(args.waybill_id)
            print("")
            print("SIGMA totals after API-first run:")
            print(f"  Buying: {buying}")
            print(f"  Selling: {selling}")
        except Exception as e:
            print(f"Cannot read totals: {e}")

    print("")
    print("Done.")
    print(f"OK: {processed}")
    print(f"Errors: {errors}")
    rel_log = log_path
    try:
        rel_log = log_path.relative_to(APP_DIR)
    except Exception:
        pass
    print(f"Log: {rel_log}")

    if errors:
        print("")
        if args.apply and args.stop_on_error:
            print(f"SAI STOP: stopped on first row error. Errors: {errors}")
            print("Catalog may be stale or the product/card changed in SIGMA. Refresh catalog and check again.")
        else:
            print(f"ERROR: completed with row errors: {errors}")
        raise SystemExit(5)


if __name__ == "__main__":
    main()
