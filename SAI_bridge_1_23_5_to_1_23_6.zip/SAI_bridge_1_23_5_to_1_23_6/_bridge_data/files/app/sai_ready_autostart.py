#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Install/remove the per-user Windows Startup entry for SAI Ready."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

from sai_runtime_paths import ROOT_DIR

AUTOSTART_FILE_NAME = "SAI Ready Catalog.vbs"


def windows_startup_dir() -> Optional[Path]:
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def render_vbs(root: Path) -> str:
    root_text = str(Path(root).resolve()).replace('"', '""')
    return "\r\n".join([
        "Option Explicit",
        "Dim Shell, FSO, RootDir, PythonExe, ScriptFile, Command",
        'Set Shell = CreateObject("WScript.Shell")',
        'Set FSO = CreateObject("Scripting.FileSystemObject")',
        f'RootDir = "{root_text}"',
        'PythonExe = RootDir & "\\app\\.venv\\Scripts\\pythonw.exe"',
        'If Not FSO.FileExists(PythonExe) Then PythonExe = RootDir & "\\app\\.venv\\Scripts\\python.exe"',
        'If Not FSO.FileExists(PythonExe) Then WScript.Quit 0',
        'ScriptFile = RootDir & "\\app\\sai_catalog_ready.py"',
        'If Not FSO.FileExists(ScriptFile) Then WScript.Quit 0',
        'Command = Chr(34) & PythonExe & Chr(34) & " " & Chr(34) & ScriptFile & Chr(34) & " --startup"',
        'Shell.Run Command, 0, False',
        "",
    ])


def install_autostart(root: Path = ROOT_DIR, startup_dir: Optional[Path] = None) -> Optional[Path]:
    folder = Path(startup_dir) if startup_dir is not None else windows_startup_dir()
    if folder is None:
        return None
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / AUTOSTART_FILE_NAME
    target.write_bytes(b"\xff\xfe" + render_vbs(Path(root)).encode("utf-16le"))
    return target


def remove_autostart(startup_dir: Optional[Path] = None) -> bool:
    folder = Path(startup_dir) if startup_dir is not None else windows_startup_dir()
    if folder is None:
        return False
    target = folder / AUTOSTART_FILE_NAME
    try:
        target.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def autostart_path(startup_dir: Optional[Path] = None) -> Optional[Path]:
    folder = Path(startup_dir) if startup_dir is not None else windows_startup_dir()
    return None if folder is None else folder / AUTOSTART_FILE_NAME


def is_autostart_installed(startup_dir: Optional[Path] = None) -> bool:
    path = autostart_path(startup_dir)
    return bool(path and path.is_file())
