#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7ap shadow economy telemetry."""
from __future__ import annotations

import ast
import json
import os
import sys
import tempfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
telemetry_root = Path(tempfile.mkdtemp(prefix="sai_patch_ap_"))
os.environ["SAI_USER_DATA_DIR"] = str(telemetry_root / "user_data")
sys.path.insert(0, str(root / "app"))

import sai_openai_invoice as ai

assert ai.SHADOW_ECONOMY_VERSION == "adaptive_second_luna_shadow_v1"
assert ai.AI_ECONOMY_TELEMETRY_PATH.parent.name == "logs"


def response(data, input_tokens=1000, output_tokens=200):
    return {
        "output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(data, ensure_ascii=False)}]}],
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "input_tokens_details": {"cached_tokens": 0},
        },
    }


def item(row, page, total, name="ТОВАР", barcode="4607136256514", article=None, quantity=1.0, confidence=0.9):
    return {
        "source_row": row,
        "source_page": page,
        "raw_name": name,
        "name": name,
        "quantity": quantity,
        "unit": "шт",
        "purchase_price": total / max(quantity, 1),
        "line_total": total,
        "article": article if article is not None else f"A{row}",
        "barcodes": ([barcode] if barcode else []),
        "confidence": confidence,
        "note": "",
    }


def doc(items, total=0.0, supplier="ТЕСТОВЫЙ ПОСТАВЩИК", date="2026-07-18", number="AP-1"):
    return {
        "supplier": supplier,
        "invoice_date": date,
        "invoice_number": number,
        "currency": "RUB",
        "document_total": total,
        "document_total_note": "",
        "items": items,
        "warnings": [],
    }


clean = ai._shadow_page_risk(doc([item(1, 1, 100.0)], 100.0), 1)
assert clean["decision"] == "skip" and clean["risk_score"] == 0
missing_quantity = ai._shadow_page_risk(doc([item(1, 1, 100.0, quantity=0)], 100.0), 1)
assert missing_quantity["decision"] == "verify"
gap = ai._shadow_page_risk(doc([item(2, 1, 100.0), item(4, 1, 100.0)], 200.0), 1)
assert gap["decision"] == "verify"

impact_cosmetic = ai._shadow_actual_impact([], [], {1: ["raw_name", "article"]})
assert impact_cosmetic["material_change_rows"] == []
impact_barcode = ai._shadow_actual_impact([], [2], {})
assert impact_barcode["material_change_rows"] == [2]
summary = ai._summarize_shadow_pages([
    {**clean, "verification_route_cost_usd": 0.01, "actual": impact_cosmetic},
    {**clean, "page": 2, "verification_route_cost_usd": 0.02, "actual": impact_barcode},
])
assert summary["candidate_skip_pages"] == [1, 2]
assert summary["validated_safe_skip_pages"] == [1]
assert summary["material_false_negative_pages"] == [2]
assert abs(summary["predicted_savings_usd"] - 0.03) < 1e-9
assert abs(summary["validated_savings_usd"] - 0.01) < 1e-9

# End-to-end shadow run: the production route still performs both Luna reads.
work = Path(tempfile.mkdtemp(prefix="sai_ap_case_"))
p1 = work / "page1.png"
p2 = work / "page2.png"
p1.write_bytes(b"fake1")
p2.write_bytes(b"fake2")
plan = {str(p1.resolve()): [0], str(p2.resolve()): [0]}
calls = []
original_build = ai.build_request_payload
original_call = ai.call_openai


def fake_build(paths, model="", supplier_hint="", date_hint="", invoice_hint="", stage="extract", draft=None,
               target_rows=None, audit_notes=None, orientation_plan=None, target_global_pages=None):
    return {
        "model": model or ai.DEFAULT_MODEL,
        "_stage": stage,
        "_page": int((target_global_pages or [0])[0]),
        "_target_rows": list(target_rows or []),
        "_sai_precision_views_used": True,
        "_sai_precision_views_count": 5,
    }


def fake_call(payload, *args, **kwargs):
    calls.append((payload["_stage"], payload["_page"]))
    page = payload["_page"]
    stage = payload["_stage"]
    if page == 1 and stage == "extract_luna":
        return response(doc([item(1, 1, 100, name="РОТАТО СМЕСИТЕЛЬ", article="")], 0, date=""))
    if page == 1 and stage == "extract_luna_verify":
        return response(doc([item(1, 1, 100, name="POTATO СМЕСИТЕЛЬ", article="59279638")], 0, date="16.07.2026"))
    if page == 2 and stage == "extract_luna":
        return response(doc([item(2, 2, 200, barcode="4607136256514")], 300, date="", supplier="", number=""))
    if page == 2 and stage == "extract_luna_verify":
        return response(doc([item(2, 2, 200, barcode="")], 300, date="", supplier="", number=""))
    raise AssertionError(f"unexpected call: {payload}")


ai.build_request_payload = fake_build
ai.call_openai = fake_call
try:
    result = ai.analyze_invoice([p1, p2], "sk-test", orientation_plan=plan)
finally:
    ai.build_request_payload = original_build
    ai.call_openai = original_call

assert calls == [
    ("extract_luna", 1), ("extract_luna_verify", 1),
    ("extract_luna", 2), ("extract_luna_verify", 2),
]
shadow = result.validation["economy_shadow"]
assert shadow["actual_route_unchanged"] is True
assert shadow["candidate_skip_pages"] == [1, 2]
assert shadow["validated_safe_skip_pages"] == [1]
assert shadow["material_false_negative_pages"] == [2]
assert shadow["validated_savings_usd"] > 0

telemetry_path = ai.AI_ECONOMY_TELEMETRY_PATH
assert telemetry_path.is_file()
telemetry_text = telemetry_path.read_text(encoding="utf-8")
record = json.loads(telemetry_text.strip().splitlines()[-1])
assert record["status"] == "ok"
assert record["economy_shadow"]["material_false_negative_pages"] == [2]
# Privacy guard: telemetry contains no line names, articles, or GTIN values.
for secret in ("РОТАТО", "POTATO", "59279638", "4607136256514"):
    assert secret not in telemetry_text

version_text = (root / "app" / "sai_version.py").read_text(encoding="utf-8")
assert 'VERSION = "1.22.7ap"' in version_text
self_tests = (root / "app" / "run_self_tests.py").read_text(encoding="utf-8")
assert 'APP_VERSION == "v1.22.7ap"' in self_tests
ui_path = root / "app" / "sai_pyside_preview.py"
ui_text = ui_path.read_text(encoding="utf-8")
ast.parse(ui_text, filename=str(ui_path))
assert "теневой экономрежим" in ui_text
assert "validated_savings_usd" in ui_text
wiki_dir = root / "SAI_Ecosystem_Wiki_v0.1"
manifest = json.loads((wiki_dir / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.7"
assert manifest["snapshot_sai_version"] == "1.22.7ap"
assert (wiki_dir / "decisions" / "ADR-024-SHADOW-ADAPTIVE-SECOND-LUNA.md").is_file()
assert (wiki_dir / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.7 / SAI 1.22.7ap")

print("PATCH_AP_SELF_TEST_OK")
