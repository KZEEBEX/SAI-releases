#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path
import xml.etree.ElementTree as ET

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))
_TEST_RUNTIME = Path(tempfile.mkdtemp(prefix="sai_semi_auto_tests_"))
os.environ["SAI_USER_DATA_DIR"] = str(_TEST_RUNTIME / "user_data")

from openpyxl import Workbook, load_workbook

import sai_package
from sai_core_v2.semi_auto_receipt_refactor import (
    approve_operator_sale_price,
    BarcodeParseResult,
    ScanParseResult,
    SemiAutoProgress,
    CollectionProgress,
    collection_progress,
    find_barcode_owner,
    is_zero_quantity,
    label_copies,
    merge_barcodes,
    missing_barcode_indices,
    next_internal_barcode,
    next_missing_index,
    parse_scan_barcodes,
    receipt_quantity_int,
    row_barcodes,
)
from sai_core_v2.free_receipt import catalog_name_match_percent
from sai_semi_auto import SemiAutoReceiptService as SemiAutoWorkflowService
from sai_semi_auto_receipt import SemiAutoReceiptService as SemiAutoPersistenceService, package_item_from_row
from sai_free_receipt import FreeReceiptCatalogService

ui_source = (APP_DIR / "sai_pyside_preview.py").read_text(encoding="utf-8")
semi_page_source = ui_source.split("class SemiAutoReceiptPage(QWidget):", 1)[1].split(
    "class PageOrientationDialog(QDialog):", 1
)[0]
assert 'id=\\"scanButton\\" class=\\"dockBtn scan\\" onclick=\\"focusScanner()\\">Сканировать</button>' in ui_source
assert 'onclick=\\"act(\'skip\')\\">Пропустить</button>' in ui_source
assert 'onclick=\\"generateBarcode()\\">Товар без ШК</button>' in ui_source
assert 'id=\\"remainingBadge\\"' in ui_source
assert "backdrop-filter" not in ui_source
assert "function focusScanner()" in ui_source
assert "scannerArmed=true" in ui_source
assert "async function toggleTorch()" in ui_source
assert "frameRate:{{ideal:20,max:24}}" in ui_source
assert "scanDeadline=Date.now()+8000" in ui_source
assert "cameraSleepTimer=setTimeout(()=>stopCamera(true),12000)" in ui_source
assert "if(scannerArmed)scanLoopTimer=setTimeout(scanCurrentFrame,380)" in ui_source
assert "object-position:center center" in ui_source
assert "const cropHeight=Math.max(1,Math.min(sourceHeight-visibleTop/coverScale" in ui_source
assert "cropY=Math.max(0,visibleTop/coverScale)" in ui_source
assert "nativeBarcodeDetector.detect(canvas)" in ui_source
assert "overflow:hidden; overscroll-behavior:none" in ui_source
assert "el('scanDock').classList.toggle('hidden',!s.has_current)" in ui_source
assert "SemiFixedActionBar" not in ui_source
assert 'parsed.path == "/api/https"' in ui_source
assert "BrowserMultiFormatReader" in ui_source
assert "async function setTorch(enabled)" in ui_source
assert 'id=\\"cameraFile\\"' in ui_source
assert "decodeCapturedImage" in ui_source
assert 'parsed.path in {"/sai-local-ca.cer", "/sai-local-ca.crt", "/sai-local-ca.mobileconfig"}' in ui_source
assert "ssl.PROTOCOL_TLS_SERVER" in ui_source
assert "ensure_mobile_https_material" in ui_source
assert '"/manifest.webmanifest"' in ui_source
assert '"/mobile-sw.js"' in ui_source
assert 'QPushButton("Товар без ШК ⇒ Создать ШК")' in semi_page_source
assert 'QPushButton("Пропустить")' in semi_page_source
assert 'QPushButton("Принять ШК")' not in semi_page_source
assert "Выбрать другой SAI-файл" not in semi_page_source
assert 'QLabel("1. SAI-файл")' not in semi_page_source
assert "self.print_thermal_check = SaiToggleSwitch()" in semi_page_source
assert 'section3 = QLabel("Товары")' in semi_page_source
assert 'QLabel("Полуавтоматический привоз")' not in semi_page_source
assert 'self.progress_label.setVisible(False)' in semi_page_source
assert 'self.scan_state_label.setVisible(False)' in semi_page_source
assert 'self.barcode_edit.setPlaceholderText("Готов к скану")' in semi_page_source
assert "find_exact_barcode(barcode, non_blocking=True)" in semi_page_source
assert 'QPushButton("Добавить товар")' in semi_page_source
assert 'QPushButton("＋ Добавить товар")' not in semi_page_source
assert "＋  Добавить товар вручную" not in semi_page_source
assert "self.table_lock_btn = QPushButton" not in semi_page_source
assert "table.setRowCount(data_rows)" in semi_page_source
assert "self._mobile_dashboard_last_seen = time.monotonic()" in semi_page_source
assert 'QLabel("Сбор штрихкодов")' in semi_page_source
assert 'self.qty_print_hint.setVisible(False)' in semi_page_source
assert 'self.current_sale_hint.setVisible(False)' in semi_page_source
assert 'self.label_qty_hint.setVisible(False)' in semi_page_source
assert 'thermal_title = QLabel("Термоэтикетки")' in semi_page_source
assert 'QPushButton("Своё")' not in semi_page_source
assert 'def select_current_label_qty_auto(self)' in semi_page_source
assert 'label_qty_label = QLabel("Количество")' in semi_page_source
assert 'group_title: str' in semi_page_source
assert 'make_edit_group("Основные данные")' in semi_page_source
assert 'make_edit_group("Учёт и цены")' in semi_page_source
assert 'make_edit_group("Штрихкоды")' in semi_page_source
assert 'print_title = QLabel("Печать термоэтикеток")' in semi_page_source
assert "current_layout.addLayout(receipt_values)" in semi_page_source
assert 'self.mobile_dashboard_qr = RoundedQrLabel(' in semi_page_source
assert 'self.table.setProperty("saiRoundedByShell", True)' in semi_page_source
assert 'table_shell.setObjectName("RoundedTableShell")' in semi_page_source
assert "sl.addLayout(scan_row)\n        sl.addWidget(self.progress_bar)" in semi_page_source
assert "semi_header = RoundedTopHeaderView(" in semi_page_source
assert 'semi_header.setObjectName("SemiProductsHeader")' in semi_page_source


def test_legacy_result_name_compatibility() -> None:
    # Compatibility aliases live inside the isolated refactor module.
    # The package-level API is deliberately left under control of the
    # already installed BS branch.
    assert BarcodeParseResult is ScanParseResult
    assert SemiAutoProgress is CollectionProgress


def test_scan_rules() -> None:
    valid = parse_scan_barcodes("4006381333931")
    assert valid.accepted and valid.codes == ("4006381333931",) and not valid.warnings
    incomplete = parse_scan_barcodes("1234567")
    assert incomplete.wait_more and not incomplete.error
    forced = parse_scan_barcodes("1234567", force=True)
    assert forced.accepted and "нестандартная длина" in forced.warnings[0]
    junk = parse_scan_barcodes("12345ABC", force=True)
    assert junk.error.startswith("Мусор")
    broken = parse_scan_barcodes("4006381333930")
    assert broken.accepted and "контрольная цифра" in broken.warnings[0]
    multiple = parse_scan_barcodes("4006381333931, 4006381333931; 12345678", force=True)
    assert multiple.codes == ("4006381333931", "12345678")


def test_collection_rules() -> None:
    rows = [
        {"name": "A", "qty": 2, "barcodes": ["4006381333931"]},
        {"name": "B", "qty": "3,5", "barcode_cell": ""},
        {"name": "C", "qty": 0, "barcode_cell": ""},
        {"name": "D", "qty": 1, "barcodes": "12345, 67890"},
    ]
    assert row_barcodes(rows[3]) == ("12345", "67890")
    assert missing_barcode_indices(rows) == (1,)
    assert find_barcode_owner(rows, "67890", current_index=1) == 3
    assert find_barcode_owner(rows, "4006381333931", current_index=0, exclude_current=True) is None
    assert is_zero_quantity(rows[2])
    assert receipt_quantity_int(rows[1]) == 4
    assert label_copies({"qty": 3}) == 3
    assert label_copies({"qty": 3, "label_qty": 5}) == 5
    assert label_copies({"qty": 0, "label_qty": 5}) == 0
    progress = collection_progress(rows)
    assert (progress.total, progress.missing, progress.zero_quantity, progress.done, progress.percent) == (4, 1, 1, 3, 75)
    assert next_missing_index(rows, start=-1) == 1
    assert next_missing_index(rows, start=1, wrap=False) is None
    assert next_missing_index(rows, start=1, wrap=True) == 1


def test_catalog_name_matching_ignores_weak_units() -> None:
    assert catalog_name_match_percent("Лампа светодиодная 12 Вт", "Лампа светодиодная 12Вт") >= 90
    assert catalog_name_match_percent("Лампа 10 Вт", "Лампа 10 Вт") >= 90
    assert catalog_name_match_percent("Лампа 10 Вт", "Лампа 10Вт") >= 85
    assert catalog_name_match_percent("Лампа 10 Вт", "Лампа 20 Вт") < 74
    assert catalog_name_match_percent("Кабель 10 мм", "Труба 10 мм") == 0
    assert catalog_name_match_percent("10 мм", "10 мм") == 0
    assert catalog_name_match_percent("Муфта д/ трубы 20 мм", "Муфта для трубы 20 мм") >= 85
    assert catalog_name_match_percent(
        "С/БАНКА СКО 1-82-500 (КОРКИНО Б/С) X20/2160",
        "С/БАНКА СКО 1-82-650 (КОРКИНО Б/С) X20/1800",
    ) == 0


def test_immutable_row_update_and_internal_code() -> None:
    original = {"name": "A", "barcodes": ["11111"], "future": {"keep": True}}
    updated = merge_barcodes(original, ["22222", "11111"], warnings=["check"])
    assert original["barcodes"] == ["11111"]
    assert updated["barcodes"] == ["11111", "22222"]
    assert updated["future"] == {"keep": True}
    candidate = next_internal_barcode("77", 0, set())
    assert candidate is not None
    code, counter = candidate
    assert len(code) == 13 and code.startswith("77") and counter == 1
    second = next_internal_barcode("77", 0, {code})
    assert second and second[0] != code and second[1] == 2


def test_manual_price_is_an_operator_decision() -> None:
    original = {"sale": 180, "price": 180, "barcodes": ["4006381333931"]}
    updated = approve_operator_sale_price(original, 150, source="manual_card")
    assert original["sale"] == 180
    assert updated["sale"] == 150 and updated["price"] == 150
    assert updated["price_operator_approved"] is True
    assert updated["price_approval_source"] == "manual_card"
    assert updated["price_approval_barcode"] == "4006381333931"


def sample_rows() -> list[dict]:
    return [
        {
            "source_row": 1,
            "name": "ТОВАР 1",
            "qty": 2,
            "unit": "шт.",
            "buy": 100,
            "sale": 160,
            "article": "A-1",
            "barcodes": ["4006381333931"],
            "comment": "",
        },
        {
            "source_row": 2,
            "name": "ТОВАР НЕДОВОЗ",
            "qty": 0,
            "unit": "м",
            "buy": 50,
            "sale": 80,
            "article": "A-2",
            "barcodes": [],
            "comment": "",
        },
    ]


def test_package_persistence() -> None:
    service = SemiAutoPersistenceService()
    with tempfile.TemporaryDirectory(prefix="sai_semi_package_") as td:
        root = Path(td)
        created = service.save_rows(
            sample_rows(), source_path=None, output_path=root / "receipt.sai", default_markup_percent=60,
        )
        assert sai_package.is_sai_package(created)
        receipt = sai_package.read_receipt(created)
        assert receipt["items"][0]["barcodes"] == ["4006381333931"]
        assert "Недовоз" in receipt["items"][1]["comment"]
        approved = approve_operator_sale_price(receipt["items"][0], 145, source="manual_card")
        service.save_rows([approved, receipt["items"][1]], source_path=created, output_path=created)
        approved_saved = sai_package.read_receipt(created)["items"][0]
        assert approved_saved["sale_price"] == 145
        assert approved_saved["price_operator_approved"] is True
        assert approved_saved["price_approval_source"] == "manual_card"
        rows = sample_rows()
        rows[0]["barcodes"].append("1234567")
        rewritten = service.save_rows(rows, source_path=created, output_path=created)
        assert sai_package.read_receipt(rewritten)["items"][0]["barcodes"] == ["4006381333931", "1234567"]


def test_legacy_xml_and_excel_persistence() -> None:
    service = SemiAutoPersistenceService()
    with tempfile.TemporaryDirectory(prefix="sai_semi_legacy_") as td:
        root = Path(td)
        xml_path = root / "receipt.xml"
        xml_path.write_text(
            "<?xml version='1.0' encoding='utf-8'?><sai_receipt><items><item row='1'><name>OLD</name><barcodes/></item></items></sai_receipt>",
            encoding="utf-8",
        )
        rows = [sample_rows()[0]]
        service.save_rows(rows, source_path=xml_path, output_path=xml_path)
        tree = ET.parse(xml_path)
        assert tree.findtext("./items/item/name") == "ТОВАР 1"
        assert tree.findtext("./items/item/barcodes/barcode") == "4006381333931"

        xlsx = root / "receipt.xlsx"
        wb = Workbook()
        ws = wb.active
        ws.title = "Для робота SIGMA"
        ws.append(["ШК", "Кол-во", "Закуп цена", "Продажная цена", "Наименование", "Ед.", "Артикул"])
        ws.append(["", 2, 100, 160, "OLD", "шт.", "OLD"])
        wb.save(xlsx)
        excel_rows = [dict(sample_rows()[0], excel_row=2)]
        service.save_rows(excel_rows, source_path=xlsx, output_path=xlsx, sheet_name="Для робота SIGMA")
        check = load_workbook(xlsx, data_only=True)
        sheet = check["Для робота SIGMA"]
        assert sheet.cell(2, 1).value == "4006381333931"
        assert sheet.cell(2, 5).value == "ТОВАР 1"
        check.close()


def test_boundaries() -> None:
    main_text = (APP_DIR / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    core_text = (APP_DIR / "sai_core_v2" / "semi_auto_receipt_refactor.py").read_text(encoding="utf-8-sig")
    service_text = (APP_DIR / "sai_semi_auto_receipt.py").read_text(encoding="utf-8-sig")
    section = main_text[main_text.index("class SemiAutoReceiptPage"):main_text.index("class AIInvoiceSignals")]
    assert "from sai_semi_auto_receipt import SemiAutoReceiptService as SemiAutoPersistenceService" in main_text
    assert "from sai_semi_auto import SemiAutoReceiptService as SemiAutoWorkflowService" in main_text
    assert "self.semi_service = SemiAutoWorkflowService()" in section
    assert "self.semi_auto_service = SemiAutoPersistenceService()" in section
    assert hasattr(SemiAutoPersistenceService(), "save_rows")
    assert not hasattr(SemiAutoWorkflowService(), "save_rows")
    assert 'QPushButton("Сохранить и ввести приход в SIGMA")' in section
    completion = section[section.index("if snapshot.missing == 0:"):section.index("return False", section.index("if snapshot.missing == 0:"))]
    assert "self.enter_sigma_btn.setVisible(True)" in completion
    assert "self.enter_sigma_btn.setEnabled(True)" in completion
    assert "self.retry_save_btn.setVisible(True)" in completion
    assert "path = self.save_updated_sai_file(show_message=False)" in section[section.index("def open_in_auto_receipt"):]
    assert 'sale_label = QLabel("Продажная цена")' in section
    assert "def apply_current_sale_from_edit" in section
    assert "def open_semi_product_card" in section
    assert 'print_save_btn = QPushButton("Печатать и сохранить")' in section
    assert "edit_btn = TableEditButton(" in section
    assert "self.open_semi_product_card(row_index)" in section
    assert "self.semi_service.parse_scan" in section and "self.semi_service.merge_barcodes" in section
    assert "sai_package.rewrite_receipt" not in section
    assert "load_workbook(" not in section
    assert "PySide6" not in core_text
    assert "PySide6" not in service_text
    assert "sai_pyside_preview" not in core_text
    assert "sai_pyside_preview" not in service_text
    assert package_item_from_row({"name": "X", "qty": 1, "barcodes": ["12-345", "12345"]}, 0)["barcodes"] == ["12345"]


def main() -> int:
    test_legacy_result_name_compatibility()
    test_scan_rules()
    test_collection_rules()
    test_catalog_name_matching_ignores_weak_units()
    test_immutable_row_update_and_internal_code()
    test_manual_price_is_an_operator_decision()
    test_package_persistence()
    test_legacy_xml_and_excel_persistence()
    test_boundaries()
    print("Semi-auto receipt refactor tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
