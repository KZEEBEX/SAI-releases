"""Small pure-Python runtime dependencies shipped with SAI."""
