Material Design Icons 7.4.47 by Pictogrammers.

License: Apache-2.0
Source: https://pictogrammers.com/library/mdi/
Distribution: https://cdn.jsdelivr.net/npm/@mdi/svg@7.4.47/

SAI stores only the icons used by the interface. Colors are adapted for the
SAI light, dark, hover and selected states without changing icon geometry.
