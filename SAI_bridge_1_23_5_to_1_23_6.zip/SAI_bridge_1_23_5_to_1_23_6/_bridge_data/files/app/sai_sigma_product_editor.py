#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Safe SIGMA product-card editing reconstructed from recorded browser traffic."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
import copy
import json
from pathlib import Path
import time
from typing import Any, Callable

import requests
from contextlib import nullcontext
from sai_read_queue import read_slot, INTERACTIVE

from sai_runtime_paths import CACHE_DIR, PRIVATE_CONFIG_PATH


class SigmaProductEditError(RuntimeError):
    pass


@dataclass(frozen=True)
class ProductCardChanges:
    name: str
    vendor_code: str
    price: Decimal
    barcodes: tuple[str, ...]
    unit_short_name: str


@dataclass(frozen=True)
class ProductCardEditResult:
    catalog_product_id: str
    menu_product_id: str
    changed_fields: tuple[str, ...]
    applied: bool
    verified: bool


@dataclass(frozen=True)
class PreparedProductCardEdit:
    catalog_product_id: str
    menu_product_id: str
    matrix_row: dict
    original: dict
    payload: dict
    catalog_payload: dict
    changed_fields: tuple[str, ...]


class SigmaProductHttp:
    def __init__(self, token: str, api_base: str, *, session=None, refresh_auth: bool = False):
        if not token:
            raise SigmaProductEditError("Нет активной сессии SIGMA. Сначала выполните вход или обычный приход.")
        if not str(api_base).startswith("https://api-s") or not str(api_base).endswith(".sigma.ru"):
            raise SigmaProductEditError("Не определён безопасный API-сервер SIGMA.")
        self.api_base = api_base.rstrip("/")
        self.token = token
        self.refresh_auth = refresh_auth
        self.session = session or requests.Session()
        self.session.headers.update({
            "accept": "application/json, text/plain, */*",
            "content-type": "application/json",
            "authorization": "Bearer " + token,
        })

    def request(self, method: str, path: str, body=None, params=None, timeout: int = 45):
        with read_slot(INTERACTIVE) if str(method).upper() == "GET" else nullcontext():
            response = self.session.request(
                method, self.api_base + path, json=body, params=params, timeout=timeout,
            )
        if response.status_code == 401 and str(method).upper() == "GET" and self.refresh_auth:
            from sai_sigma_session import ensure_sigma_session
            auth = ensure_sigma_session(rejected_token=self.token)
            base = str(auth.get("api_base") or self.api_base).rstrip("/")
            if not base.startswith("https://api-s") or not base.endswith(".sigma.ru"):
                raise SigmaProductEditError("Не определён безопасный API-сервер SIGMA")
            self.token, self.api_base = auth["token"], base
            self.session.headers.update({"authorization": "Bearer " + self.token})
            with read_slot(INTERACTIVE):
                response = self.session.request(method, self.api_base + path, json=body, params=params, timeout=timeout)
        try:
            data = response.json()
        except Exception:
            data = response.text
        if not 200 <= response.status_code < 300:
            raise SigmaProductEditError(
                f"SIGMA отклонила запрос: HTTP {response.status_code}. Изменения не подтверждены."
            )
        return data


class SigmaProductEditor:
    """Read/merge/write/verify boundary; never sends a partial menu-product body."""

    MENU_KEYS = (
        "name", "image", "type", "taxationSystemType", "showOnDevice",
        "workshopIds", "modifierGroups", "categoryId", "id", "parentIds",
        "variations", "menuId", "alcoholDetails", "extCategoryId",
        "extProductId", "hasVariationOnTap", "vendorCode",
    )

    def __init__(
        self,
        http: SigmaProductHttp,
        company_id: str,
        menu_id: str,
        *,
        sleep_func: Callable[[float], None] = time.sleep,
        verification_delays: tuple[float, ...] = (0.0, 0.35, 0.85, 1.8),
    ):
        self.http = http
        self.company_id = str(company_id)
        self.menu_id = str(menu_id)
        if not self.company_id or not self.menu_id:
            raise SigmaProductEditError("В настройках SIGMA отсутствует companyId или menuId.")
        self._menu_matrix_by_product: dict[str, list[dict]] | None = None
        self._product_units_cache: dict[str, str] | None = None
        self._sleep = sleep_func
        self._verification_delays = verification_delays or (0.0,)

    def _company(self, suffix: str) -> str:
        return f"/rest/v2/companies/{self.company_id}/{suffix.lstrip('/')}"

    def resolve_menu_product(self, catalog_product_id: str) -> tuple[dict, dict]:
        target = str(catalog_product_id)
        if self._menu_matrix_by_product is None:
            index: dict[str, list[dict]] = {}
            # SIGMA accepts a large page. With a 5,000+ item catalog this turns
            # roughly 115 sequential requests into one response.
            page_size = 10_000
            for page in range(10):
                data = self.http.request("GET", self._company("menu-matrix"), params={
                    "page": page, "size": page_size, "menuId": self.menu_id,
                    "groupId": "", "sort": "createdDate,desc",
                })
                rows = data.get("rows", []) if isinstance(data, dict) else []
                for row in rows:
                    product_id = str(row.get("id") or "")
                    if product_id:
                        index.setdefault(product_id, []).append(row)
                if len(rows) < page_size:
                    break
            self._menu_matrix_by_product = index
        rows = self._menu_matrix_by_product.get(target, [])
        if len(rows) != 1:
            raise SigmaProductEditError("Не удалось однозначно найти товар в меню SIGMA.")
        row = rows[0]
        variations = row.get("variations") or []
        matches = [
            variation for variation in variations
            if str((variation.get("menu") or {}).get("id") or "") == self.menu_id
            and str((variation.get("menuProduct") or {}).get("id") or "")
        ]
        ids = {str(item["menuProduct"]["id"]) for item in matches}
        if len(ids) != 1:
            raise SigmaProductEditError(
                "Товар связан с несколькими позициями меню. SAI не будет выбирать наугад."
            )
        return row, matches[0]

    def read_menu_product(self, menu_product_id: str) -> dict:
        data = self.http.request(
            "GET",
            self._company(f"menus/{self.menu_id}/menu-products/{menu_product_id}"),
        )
        if not isinstance(data, dict) or not data.get("variations"):
            raise SigmaProductEditError("SIGMA вернула неполную карточку товара.")
        return data

    def product_units(self) -> dict[str, str]:
        if self._product_units_cache is not None:
            return dict(self._product_units_cache)
        data = self.http.request(
            "GET", f"/rest/1.1/companies/{self.company_id}/product-units",
        )
        rows = data if isinstance(data, list) else data.get("rows", data.get("content", []))
        result = {}
        for row in rows or []:
            short = str(row.get("shortName") or row.get("name") or "").strip().lower()
            unit_id = str(row.get("id") or "")
            if short and unit_id:
                result[short] = unit_id
        self._product_units_cache = result
        return dict(result)

    @classmethod
    def _menu_payload(cls, source: dict) -> dict:
        payload = {key: copy.deepcopy(source.get(key)) for key in cls.MENU_KEYS if key in source}
        payload.setdefault("workshopIds", [])
        payload.setdefault("modifierGroups", [])
        payload.setdefault("parentIds", [])
        payload.setdefault("variations", [])
        return payload

    @staticmethod
    def _clean_barcodes(values: tuple[str, ...]) -> list[str]:
        result = []
        for value in values:
            code = "".join(str(value).split())
            if not code:
                continue
            if not code.isdigit():
                raise SigmaProductEditError(f"Штрихкод должен состоять из цифр: {code}")
            if code not in result:
                result.append(code)
        if not result:
            raise SigmaProductEditError("У товара должен остаться хотя бы один штрихкод.")
        return result

    def prepare_edit(
        self,
        catalog_product_id: str,
        changes: ProductCardChanges,
        *,
        current: PreparedProductCardEdit | None = None,
    ) -> PreparedProductCardEdit:
        """Prepare a safe full payload, optionally reusing one live snapshot."""
        if current is None:
            matrix_row, variation_ref = self.resolve_menu_product(catalog_product_id)
            menu_product_id = str(variation_ref["menuProduct"]["id"])
            original = self.read_menu_product(menu_product_id)
        else:
            if str(current.catalog_product_id) != str(catalog_product_id):
                raise SigmaProductEditError("Подготовленная карточка относится к другому товару.")
            matrix_row = current.matrix_row
            menu_product_id = current.menu_product_id
            original = current.original
        payload = self._menu_payload(original)
        variation = payload["variations"][0]
        unit_key = changes.unit_short_name.strip().lower()
        units = self.product_units() if unit_key else {}
        if unit_key and unit_key not in units:
            raise SigmaProductEditError(f"SIGMA не знает единицу измерения «{changes.unit_short_name}».")

        fields = []
        desired_barcodes = self._clean_barcodes(changes.barcodes)
        desired_price = float(Decimal(changes.price))
        comparisons = (
            ("name", str(payload.get("name") or ""), changes.name.strip()),
            ("vendorCode", str(payload.get("vendorCode") or matrix_row.get("vendorCode") or ""), changes.vendor_code.strip()),
            ("price", float((variation.get("price") or {}).get("value") or 0), desired_price),
            ("barcodes", set(variation.get("barcodes") or []), set(desired_barcodes)),
        )
        for field, before, after in comparisons:
            if before != after:
                fields.append(field)

        payload["name"] = changes.name.strip()
        payload["vendorCode"] = changes.vendor_code.strip()
        variation["catalogProductName"] = changes.name.strip()
        variation["catalogVendorCode"] = changes.vendor_code.strip()
        variation["barcodes"] = desired_barcodes
        variation["price"] = {"value": desired_price, "type": "Rb"}
        if unit_key:
            if str(variation.get("productUnitId") or "") != units[unit_key]:
                fields.append("productUnitId")
            variation["productUnitId"] = units[unit_key]

        catalog_payload = {
            "productType": str(matrix_row.get("productType") or "OTHER"),
            "isMarked": bool(matrix_row.get("isMarked") or matrix_row.get("marked")),
            "name": changes.name.strip(),
            "vendorCode": changes.vendor_code.strip(),
            "isExcise": bool(matrix_row.get("isExcise") or matrix_row.get("excise")),
            "isPrescription": bool(matrix_row.get("isPrescription") or matrix_row.get("prescription")),
        }
        return PreparedProductCardEdit(
            catalog_product_id=str(catalog_product_id),
            menu_product_id=menu_product_id,
            matrix_row=matrix_row,
            original=original,
            payload=payload,
            catalog_payload=catalog_payload,
            changed_fields=tuple(fields),
        )

    def prepare(
        self, catalog_product_id: str, changes: ProductCardChanges,
    ) -> tuple[dict, dict, dict, tuple[str, ...]]:
        """Compatibility wrapper for callers using the original public API."""
        prepared = self.prepare_edit(catalog_product_id, changes)
        return (
            prepared.original,
            prepared.payload,
            prepared.catalog_payload,
            prepared.changed_fields,
        )

    @staticmethod
    def _verification_mismatches(
        verified: dict,
        expected: dict,
        fields: tuple[str, ...],
    ) -> tuple[str, ...]:
        check = (verified.get("variations") or [{}])[0]
        wanted = (expected.get("variations") or [{}])[0]
        mismatches: list[str] = []
        for field in fields:
            if field == "name" and str(verified.get("name") or "") != str(expected.get("name") or ""):
                mismatches.append(field)
            elif field == "vendorCode" and str(verified.get("vendorCode") or "") != str(expected.get("vendorCode") or ""):
                mismatches.append(field)
            elif field == "barcodes" and set(check.get("barcodes") or []) != set(wanted.get("barcodes") or []):
                mismatches.append(field)
            elif field == "price" and Decimal(str((check.get("price") or {}).get("value") or 0)) != Decimal(
                str((wanted.get("price") or {}).get("value") or 0)
            ):
                mismatches.append(field)
            elif field == "productUnitId" and str(check.get("productUnitId") or "") != str(
                wanted.get("productUnitId") or ""
            ):
                mismatches.append(field)
        return tuple(mismatches)

    def _verify_with_retry(
        self,
        menu_product_id: str,
        expected: dict,
        fields: tuple[str, ...],
    ) -> tuple[bool, tuple[str, ...]]:
        last_mismatches: tuple[str, ...] = fields
        for delay in self._verification_delays:
            if delay > 0:
                self._sleep(delay)
            verified = self.read_menu_product(menu_product_id)
            last_mismatches = self._verification_mismatches(verified, expected, fields)
            if not last_mismatches:
                return True, ()
        return False, last_mismatches

    def apply(
        self, catalog_product_id: str, changes: ProductCardChanges, *, dry_run: bool = False,
    ) -> ProductCardEditResult:
        return self.apply_prepared(
            self.prepare_edit(catalog_product_id, changes),
            dry_run=dry_run,
        )

    def apply_prepared(
        self,
        prepared: PreparedProductCardEdit,
        *,
        dry_run: bool = False,
    ) -> ProductCardEditResult:
        """Write a payload built from the batch's live preflight snapshot."""
        catalog_product_id = prepared.catalog_product_id
        original = prepared.original
        payload = prepared.payload
        catalog_payload = prepared.catalog_payload
        fields = prepared.changed_fields
        menu_product_id = prepared.menu_product_id
        if dry_run or not fields:
            return ProductCardEditResult(str(catalog_product_id), menu_product_id, fields, False, False)

        catalog_changed = bool({"name", "vendorCode"} & set(fields))
        old_catalog = {
            "productType": str((original["variations"][0]).get("productType") or "OTHER"),
            "isMarked": bool((original["variations"][0]).get("isMarked")),
            "name": str(original["variations"][0].get("catalogProductName") or original.get("name") or ""),
            "vendorCode": str(original["variations"][0].get("catalogVendorCode") or original.get("vendorCode") or ""),
            "isExcise": bool((original["variations"][0]).get("isExcise")),
            "isPrescription": bool((original["variations"][0]).get("isPrescription")),
        }
        if catalog_changed:
            self.http.request(
                "PUT", self._company(f"products/{catalog_product_id}"), catalog_payload,
            )
        try:
            self.http.request(
                "PUT",
                self._company(f"menus/{self.menu_id}/menu-products/{menu_product_id}"),
                payload,
            )
        except Exception:
            if catalog_changed:
                try:
                    self.http.request(
                        "PUT", self._company(f"products/{catalog_product_id}"), old_catalog,
                    )
                except Exception:
                    pass
            raise

        ok, mismatches = self._verify_with_retry(menu_product_id, payload, fields)
        if not ok:
            rollback_errors: list[str] = []
            if catalog_changed:
                try:
                    self.http.request(
                        "PUT", self._company(f"products/{catalog_product_id}"), old_catalog,
                    )
                except Exception as exc:
                    rollback_errors.append(f"каталог: {exc}")
            original_payload = self._menu_payload(original)
            try:
                self.http.request(
                    "PUT",
                    self._company(f"menus/{self.menu_id}/menu-products/{menu_product_id}"),
                    original_payload,
                )
            except Exception as exc:
                rollback_errors.append(f"карточка: {exc}")
            rollback_ok = False
            if not rollback_errors:
                rollback_ok, rollback_mismatches = self._verify_with_retry(
                    menu_product_id,
                    original_payload,
                    fields,
                )
                if not rollback_ok:
                    rollback_errors.append(
                        "контроль: " + ", ".join(rollback_mismatches)
                    )
            failed = ", ".join(mismatches)
            if rollback_ok:
                raise SigmaProductEditError(
                    "SIGMA приняла запись, но не подтвердила поля "
                    f"({failed}). Текущая карточка возвращена назад; откат подтверждён."
                )
            raise SigmaProductEditError(
                "SIGMA приняла запись, но не подтвердила поля "
                f"({failed}). Откат текущей карточки не подтверждён: "
                + "; ".join(rollback_errors)
            )
        return ProductCardEditResult(str(catalog_product_id), menu_product_id, fields, True, True)


def editor_from_current_session() -> SigmaProductEditor:
    try:
        cfg = json.loads(Path(PRIVATE_CONFIG_PATH).read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    from sai_sigma_session import ensure_sigma_session
    cache = ensure_sigma_session(cfg)
    token = str(cache.get("token") or "")
    api_base = str(cache.get("api_base") or cfg.get("sigma_import_api_base") or "").rstrip("/")
    if not api_base:
        host = str(cfg.get("sigma_import_api_host") or "").strip()
        api_base = f"https://{host}" if host else ""
    return SigmaProductEditor(
        SigmaProductHttp(token, api_base, refresh_auth=True),
        str(cfg.get("sigma_company_key") or ""),
        str(cfg.get("sigma_import_menu_id") or ""),
    )
