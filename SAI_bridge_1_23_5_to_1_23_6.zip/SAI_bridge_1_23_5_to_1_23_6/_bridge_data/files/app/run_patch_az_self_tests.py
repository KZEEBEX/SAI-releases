#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic regression checks for SAI v1.22.7az."""
from __future__ import annotations

import tempfile
from pathlib import Path

import sai_converter
import sai_receipt_drafts
from sai_version import APP_VERSION



def runtime_ui_tests() -> None:
    try:
        import os
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        from sai_pyside_preview import NewReceiptHeroButton, ReceiptUxPreviewPage
    except Exception as exc:
        print(f"SKIP: PySide6 v1.22.7az runtime tests ({exc})")
        return
    app = QApplication.instance() or QApplication([])
    hero = NewReceiptHeroButton("НОВЫЙ ПРИВОЗ", "Тест")
    hero.resize(900, 156)
    hero.show()
    app.processEvents()
    assert hero.height() >= 156
    assert hero.title_label.text() == "НОВЫЙ ПРИВОЗ"
    assert not hero._logo.isNull()
    page = ReceiptUxPreviewPage(None)
    page.resize(1000, 700)
    page.show()
    app.processEvents()
    assert page.new_receipt_btn.title_label.text() == "НОВЫЙ ПРИВОЗ"
    assert page.new_receipt_btn.minimumHeight() == 156
    page.deleteLater()
    hero.deleteLater()
    app.processEvents()

def main() -> None:
    app_dir = Path(__file__).resolve().parent
    text = (app_dir / "sai_pyside_preview.py").read_text(encoding="utf-8")
    assert APP_VERSION == "v1.22.7az"
    assert "class NewReceiptHeroButton" in text
    assert '"НОВЫЙ ПРИВОЗ"' in text
    assert 'self.new_receipt_btn.clicked.connect(self.start_new_receipt)' in text
    assert 'secondary.addWidget(self._source_tile("Ручная накладная"' in text
    assert 'secondary.addWidget(self._source_tile("Черновики"' in text
    empty = text[text.index("    def _build_empty_state"):text.index("    def _build_final_state")]
    assert "Выбрать файл" not in empty
    assert "Накладная с AI" not in empty
    assert "найти свежий SAI-файл" not in empty
    assert 'sai_receipt_drafts.save_result' in text
    assert 'self.persist_internal_draft("ai_review")' in text
    assert 'sai_receipt_drafts.mark_completed_by_package' in text
    assert 'QFrame#RailTopBlock' in text and 'QFrame#RailBottomBlock' in text
    assert "Быстрые категории свободного привоза" not in text
    assert "free_receipt_category_mode" not in text
    assert (app_dir / "assets" / "sai_logo.png").is_file()

    with tempfile.TemporaryDirectory(prefix="sai_az_drafts_") as td:
        root = Path(td)
        sai_receipt_drafts.DRAFTS_DIR = root / "receipt_drafts"
        sai_receipt_drafts.MANUAL_AUTOSAVE = root / "free_receipt_autosave.json"
        result = sai_converter.ConvertResult(
            source_path="invoice.pdf",
            source_type="AI",
            supplier="ООО ТЕСТ",
            date="2026-07-20",
            items=[
                sai_converter.ConvertItem(
                    row=1,
                    name="ТРУБА 110 ММ",
                    quantity=2,
                    purchase_price=100,
                    sale_price=160,
                    article="A-1",
                    barcodes=[],
                ),
                sai_converter.ConvertItem(
                    row=2,
                    name="МУФТА 110 ММ",
                    quantity=1,
                    purchase_price=50,
                    sale_price=80,
                    article="A-2",
                    barcodes=["4600000000000"],
                ),
            ],
        )
        meta = sai_receipt_drafts.save_result(result, (), stage="ai_review")
        package = Path(meta["package_path"])
        assert package.is_file()
        assert meta["purchase_total"] == 250.0
        assert meta["missing_barcodes"] == 1
        assert len(sai_receipt_drafts.list_active()) == 1
        updated = sai_receipt_drafts.update_by_package(package, stage="semi_auto")
        assert updated and updated["stage_label"] == "Нужны штрихкоды"
        sai_receipt_drafts.mark_completed_by_package(package)
        assert not sai_receipt_drafts.list_active()

        manual = sai_receipt_drafts.register_manual_autosave({
            "supplier_name": "РУЧНАЯ НАКЛАДНАЯ",
            "date": "20.07.2026",
            "rows": [{"qty": 2, "buy": 10}],
            "current_card": {},
        })
        assert manual["kind"] == "manual"
        assert sai_receipt_drafts.list_active()[0]["stage"] == "manual_entry"

    runtime_ui_tests()
    print("OK: SAI v1.22.7az tests passed")


if __name__ == "__main__":
    main()
