#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""SAI Ready: keep the local SIGMA catalog warm before the UI is opened.

This module intentionally has no PySide dependency.  It can be started by the
current user's Windows Startup folder, by SAI itself, or manually from a console.
Only local status/counters are written to disk; credentials stay in the existing
private config and are never copied to logs or command-line arguments.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
import time
import uuid
from contextlib import closing
from pathlib import Path
from typing import Any, Dict, Optional

from sai_runtime_paths import APP_DIR, CACHE_DIR, LOGS_DIR, PRIVATE_CONFIG_PATH, PROFILE_DIR, ROOT_DIR, USER_DATA_DIR, ensure_runtime_dirs
from sai_version import APP_VERSION
from sai_core_v2.free_receipt import highest_internal_counter, normalized_internal_prefix
import sai_db

for _browser_dir in (
    ROOT_DIR / "_runtime" / "ms-playwright",
    ROOT_DIR / "_offline" / "ms-playwright",
):
    if _browser_dir.is_dir():
        os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(_browser_dir))
        break

STATUS_PATH = CACHE_DIR / "sai_ready_status.json"
LOCK_PATH = CACHE_DIR / "sai_ready_catalog.lock"
LOG_PATH = LOGS_DIR / "sai_ready.log"
SUPPLIERS_CACHE_PATH = USER_DATA_DIR / "suppliers_cache.json"
DEFAULT_STARTUP_DELAY_SECONDS = 45
DEFAULT_STARTUP_MIN_AGE_MINUTES = 30
DEFAULT_APP_REFRESH_MINUTES = 360
LOCK_STALE_SECONDS = 2 * 60 * 60


def _safe_str(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _now_text() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _read_json(path: Path, default: Any) -> Any:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value
    except Exception:
        return default


def _write_json_atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_private_config() -> Dict[str, Any]:
    value = _read_json(PRIVATE_CONFIG_PATH, {})
    return dict(value) if isinstance(value, dict) else {}


def save_private_config_patch(patch: Dict[str, Any]) -> Dict[str, Any]:
    ensure_runtime_dirs()
    cfg = load_private_config()
    cfg.update(dict(patch or {}))
    _write_json_atomic(PRIVATE_CONFIG_PATH, cfg)
    return cfg


def remove_private_config_keys(keys) -> Dict[str, Any]:
    """Remove migrated settings instead of leaving misleading empty USER fields."""
    ensure_runtime_dirs()
    cfg = load_private_config()
    for key in keys:
        cfg.pop(str(key), None)
    _write_json_atomic(PRIVATE_CONFIG_PATH, cfg)
    return cfg


def _append_log(message: str) -> None:
    try:
        ensure_runtime_dirs()
        LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(f"[{_now_text()}] {message}\n")
    except Exception:
        pass


def read_status() -> Dict[str, Any]:
    value = _read_json(STATUS_PATH, {})
    return dict(value) if isinstance(value, dict) else {}


def write_status(state: str, message: str = "", **extra: Any) -> Dict[str, Any]:
    payload: Dict[str, Any] = {
        "state": _safe_str(state),
        "message": _safe_str(message),
        "updated_at": _now_text(),
        "app_version": APP_VERSION,
        "pid": os.getpid(),
    }
    payload.update({key: value for key, value in extra.items() if value is not None})
    try:
        _write_json_atomic(STATUS_PATH, payload)
    except Exception:
        pass
    if message:
        _append_log(f"{state}: {message}")
    return payload


def _catalog_meta(company_key: str, sell_point_id: str) -> Optional[Dict[str, Any]]:
    company_key = _safe_str(company_key)
    sell_point_id = _safe_str(sell_point_id)
    if not company_key or not sell_point_id:
        return None
    try:
        sai_db.init_db()
        with closing(sai_db.connect()) as con:
            row = con.execute(
                """
                SELECT created_at, strategy, product_count, barcode_count, app_version
                FROM catalog_sync
                WHERE company_key=? AND sell_point_id=?
                """,
                (company_key, sell_point_id),
            ).fetchone()
        if not row:
            return None
        age = sai_db.catalog_age_seconds(company_key, sell_point_id)
        return {
            "created_at": _safe_str(row["created_at"]),
            "strategy": _safe_str(row["strategy"]),
            "product_count": int(row["product_count"] or 0),
            "barcode_count": int(row["barcode_count"] or 0),
            "app_version": _safe_str(row["app_version"]),
            "age_seconds": None if age is None else float(age),
        }
    except Exception:
        return None


def catalog_snapshot(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    cfg = dict(cfg or load_private_config())
    company = _safe_str(cfg.get("sigma_company_key"))
    sell_point = _safe_str(cfg.get("sigma_sell_point_id"))
    if company and not sell_point:
        try:
            sai_db.init_db()
            with closing(sai_db.connect()) as con:
                row = con.execute(
                    "SELECT sell_point_id FROM catalog_sync WHERE company_key=? ORDER BY created_at DESC LIMIT 1",
                    (company,),
                ).fetchone()
            if row:
                sell_point = _safe_str(row["sell_point_id"])
                if sell_point:
                    save_private_config_patch({"sigma_sell_point_id": sell_point})
        except Exception:
            pass
    meta = _catalog_meta(company, sell_point)
    return {
        "company_key_present": bool(company),
        "sell_point_id_present": bool(sell_point),
        "catalog_present": bool(meta and meta.get("product_count")),
        "company_key": company,
        "sell_point_id": sell_point,
        **(meta or {}),
    }


def human_age(age_seconds: Any) -> str:
    try:
        seconds = max(0, int(float(age_seconds)))
    except Exception:
        return "неизвестно"
    if seconds < 90:
        return "меньше минуты"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes} мин"
    hours = minutes // 60
    if hours < 48:
        return f"{hours} ч"
    return f"{hours // 24} дн"


def synchronize_internal_barcode_counter(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Restore the SAI 77… counter from the refreshed catalog and local history."""
    cfg = dict(cfg or load_private_config())
    prefix = normalized_internal_prefix(cfg.get("free_receipt_barcode_prefix") or "7700")
    values: set[str] = set()
    try:
        sai_db.init_db()
        with closing(sai_db.connect()) as connection:
            try:
                for row in connection.execute(
                    "SELECT barcode FROM barcodes WHERE barcode LIKE ?",
                    (prefix + "%",),
                ).fetchall():
                    code = _safe_str(row[0])
                    if code:
                        values.add(code)
            except Exception:
                pass
            try:
                for row in connection.execute(
                    "SELECT barcodes_json FROM products WHERE barcodes_json LIKE ?",
                    ("%" + prefix + "%",),
                ).fetchall():
                    try:
                        codes = json.loads(row[0] or "[]")
                    except Exception:
                        codes = []
                    for code in codes if isinstance(codes, list) else ():
                        normalized = _safe_str(code)
                        if normalized:
                            values.add(normalized)
            except Exception:
                pass
    except Exception:
        pass
    history_path = USER_DATA_DIR / "free_receipt_generated_barcodes.json"
    try:
        history = _read_json(history_path, {})
        codes = history.get("barcodes", ()) if isinstance(history, dict) else history
        for code in codes if isinstance(codes, list) else ():
            normalized = _safe_str(code)
            if normalized:
                values.add(normalized)
    except Exception:
        pass
    remembered_raw = max(0, int(float(cfg.get("free_receipt_barcode_last_counter") or 0)))
    max_counter = (10 ** max(1, 12 - len(prefix))) - 1
    remembered = remembered_raw if remembered_raw <= max_counter else 0
    observed = highest_internal_counter(values, prefix)
    counter = max(remembered, observed)
    if counter != remembered_raw or _safe_str(cfg.get("free_receipt_barcode_prefix")) != prefix:
        save_private_config_patch({
            "free_receipt_barcode_prefix": prefix,
            "free_receipt_barcode_last_counter": counter,
        })
        _append_log(f"Восстановлен счётчик внутренних ШК: {counter}.")
    return {
        "prefix": prefix,
        "remembered_counter": remembered_raw,
        "observed_counter": observed,
        "counter": counter,
        "barcode_count": len(values),
        "updated": counter != remembered_raw or _safe_str(cfg.get("free_receipt_barcode_prefix")) != prefix,
    }


def _cached_supplier_count() -> int:
    payload = _read_json(SUPPLIERS_CACHE_PATH, {})
    suppliers = payload.get("suppliers") if isinstance(payload, dict) else []
    return len(suppliers) if isinstance(suppliers, list) else 0


def _save_suppliers_cache(company_id: str, suppliers: list[Dict[str, Any]]) -> Dict[str, Any]:
    clean: list[Dict[str, str]] = []
    seen: set[str] = set()
    for supplier in suppliers:
        if not isinstance(supplier, dict):
            continue
        supplier_id = _safe_str(supplier.get("id"))
        name = _safe_str(supplier.get("name"))
        if not supplier_id or not name or supplier_id in seen:
            continue
        seen.add(supplier_id)
        item = {"id": supplier_id, "name": name}
        inn = _safe_str(supplier.get("inn") or supplier.get("taxpayerIdentificationNumber"))
        if inn:
            item["inn"] = inn
        clean.append(item)
    clean.sort(key=lambda item: item["name"].lower())
    payload = {
        "company_id": _safe_str(company_id),
        "updated_at": _now_text(),
        "suppliers": clean,
    }
    _write_json_atomic(SUPPLIERS_CACHE_PATH, payload)
    return payload


def refresh_suppliers(cfg: Optional[Dict[str, Any]] = None, *, force: bool = True) -> Dict[str, Any]:
    from sai_sync_coordinator import SyncCoordinator
    config = dict(cfg or load_private_config())
    scope = _safe_str(config.get("sigma_company_key")) + ":" + _safe_str(config.get("sigma_internal_company_id"))
    return SyncCoordinator().run("suppliers", scope, lambda: _refresh_suppliers(config), force=force)


def _refresh_suppliers(cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Refresh suppliers with at most one SIGMA browser login session."""
    ensure_runtime_dirs()
    cfg = dict(cfg or load_private_config())
    browser_runtime = None
    try:
        from sai_sigma_session import ensure_sigma_session
        from sai_waybill_creator import (
            LegacyRequestsSigmaClient,
            discover_company_id,
            open_sigma_context,
            simplify_suppliers,
        )
        from sigma_autoprihod import DEFAULT_API_BASE, DEFAULT_CLOUD_URL

        cached_auth = ensure_sigma_session(cfg)
        token = _safe_str(cached_auth.get("token"))
        api_base = _safe_str(cached_auth.get("api_base")) or DEFAULT_API_BASE
        client = None
        if token:
            cached_client = LegacyRequestsSigmaClient(api_base, token)
            try:
                cached_client.request("GET", "/rest/1.1/account")
                client = cached_client
                _append_log("Поставщики: используется сохранённая авторизация SIGMA.")
            except Exception as exc:
                if "HTTP 401" not in str(exc):
                    raise
                auth = ensure_sigma_session(cfg, rejected_token=token)
                client = LegacyRequestsSigmaClient(auth["api_base"], auth["token"])

        if client is None:
            raise RuntimeError("Сессия SIGMA не готова")

        preferred_company = _safe_str(cfg.get("sigma_internal_company_id"))
        company_id, suppliers, _account = discover_company_id(client, preferred_company)
        simple = simplify_suppliers(suppliers)
        if not simple:
            raise RuntimeError("SIGMA вернула пустой список поставщиков")
        payload = _save_suppliers_cache(company_id, simple)
        save_private_config_patch({
            "sigma_internal_company_id": company_id,
            "sai_ready_last_suppliers_at": payload["updated_at"],
            "sai_ready_last_supplier_count": len(simple),
        })
        _append_log(f"Поставщики готовы: {len(simple)}.")
        return {"ok": True, "refreshed": True, "supplier_count": len(simple), "company_id": company_id}
    except Exception as exc:
        cached_count = _cached_supplier_count()
        message = "Обновление поставщиков не удалось: " + _safe_str(exc)[:220]
        _append_log(message)
        return {
            "ok": bool(cached_count),
            "refreshed": False,
            "stale": bool(cached_count),
            "supplier_count": cached_count,
            "message": message,
        }
    finally:
        if browser_runtime is not None:
            playwright, context, _page, _client = browser_runtime
            try:
                context.close()
            except Exception:
                pass
            try:
                playwright.stop()
            except Exception:
                pass


def _process_running(pid: int) -> Optional[bool]:
    """False only when the owner is demonstrably gone; access denied is unknown."""
    if pid <= 0:
        return None
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetExitCodeProcess.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return False if ctypes.get_last_error() == 87 else None
        try:
            code = wintypes.DWORD()
            if not kernel.GetExitCodeProcess(handle, ctypes.byref(code)):
                return None
            return code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except (PermissionError, OSError):
        return None


class CatalogRefreshLock:
    """Legacy-compatible owner marker, with guarded dead-owner recovery."""

    def __init__(self, path: Path = LOCK_PATH, stale_seconds: int = LOCK_STALE_SECONDS) -> None:
        self.path = Path(path)
        self.stale_seconds = max(60, int(stale_seconds))
        self.acquired = False
        self.owner_token = uuid.uuid4().hex

    def _guard(self):
        from sai_sigma_session import ProcessLock
        return ProcessLock(self.path.with_suffix(self.path.suffix + ".guard"), timeout=1)

    def _remove_if_stale(self) -> None:
        try:
            age = time.time() - self.path.stat().st_mtime
            payload = _read_json(self.path, {})
            try:
                pid = int(payload.get("pid") or 0) if isinstance(payload, dict) else 0
            except (ValueError, TypeError):
                pid = 0
            owner = _process_running(pid) if pid > 0 else None
            # Never steal a live (or inaccessible) owner's long-running download.
            if owner is False or (pid <= 0 and age > self.stale_seconds):
                self.path.unlink(missing_ok=True)
        except Exception:
            pass

    def acquire(self) -> bool:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self._guard():
                return self._acquire_guarded()
        except (OSError, RuntimeError):
            return False

    def _acquire_guarded(self) -> bool:
        self._remove_if_stale()
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except OSError:
            return False
        try:
            os.write(fd, json.dumps({"pid": os.getpid(), "started_at": _now_text(), "owner_token": self.owner_token}).encode("utf-8"))
        finally:
            os.close(fd)
        self.acquired = True
        return True

    def release(self) -> None:
        if not self.acquired:
            return
        try:
            with self._guard():
                owner = _read_json(self.path, {})
                if isinstance(owner, dict) and owner.get("owner_token") == self.owner_token:
                    self.path.unlink(missing_ok=True)
        except Exception:
            pass
        self.acquired = False

    def __enter__(self) -> "CatalogRefreshLock":
        if not self.acquire():
            raise RuntimeError("catalog refresh is already running")
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.release()


def _resolve_sell_point(cfg: Dict[str, Any]) -> str:
    current = _safe_str(cfg.get("sigma_sell_point_id"))
    if current:
        return current
    company = _safe_str(cfg.get("sigma_company_key"))
    token = _safe_str(cfg.get("sigma_api_token"))
    if not company or not token:
        return ""
    import requests

    url = f"https://api.sigma.ru/v1/companies/{company}/sell-points"
    response = requests.get(
        url,
        headers={"Accept": "application/json", "X-Api-Key": token, "User-Agent": f"SAI-Ready/{APP_VERSION}"},
        timeout=15,
    )
    if not (200 <= response.status_code < 300):
        raise RuntimeError(f"sell-points HTTP {response.status_code}: {response.text[:160]}")
    payload = response.json()
    values = []
    if isinstance(payload, list):
        values = payload
    elif isinstance(payload, dict):
        for key in ("data", "items", "result", "sellPoints"):
            candidate = payload.get(key)
            if isinstance(candidate, list):
                values = candidate
                break
            if isinstance(candidate, dict):
                for inner in ("items", "data", "list"):
                    nested = candidate.get(inner)
                    if isinstance(nested, list):
                        values = nested
                        break
                if values:
                    break
    for item in values:
        if not isinstance(item, dict):
            continue
        value = _safe_str(item.get("id") or item.get("uuid") or item.get("sellPointId"))
        if value:
            save_private_config_patch({"sigma_sell_point_id": value})
            return value
    return ""


def refresh_catalog(
    *,
    reason: str = "background",
    force: bool = False,
    min_age_minutes: Optional[int] = None,
    cfg: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Refresh the SQLite catalog, or return the already-fresh local mirror.

    The returned dict always contains ``ok`` and ``state``.  ``ok=True`` also
    covers the safe "fresh cache, no network call needed" path.
    """
    ensure_runtime_dirs()
    cfg = dict(cfg or load_private_config())
    barcode_sync = synchronize_internal_barcode_counter(cfg)
    if not bool(cfg.get("sai_ready_enabled", True)) and reason in {"windows-startup", "app-open"}:
        return write_status(
            "disabled",
            "SAI Ready отключён в настройках.",
            reason=reason,
            ok=True,
            internal_barcode_counter=barcode_sync.get("counter"),
        )

    company = _safe_str(cfg.get("sigma_company_key"))
    token = _safe_str(cfg.get("sigma_api_token"))
    sell_point = _safe_str(cfg.get("sigma_sell_point_id"))
    if not company or not token:
        return write_status(
            "missing_config",
            "Фоновое обновление пропущено: не заполнены company key или API token.",
            reason=reason,
            ok=False,
        )

    lock = CatalogRefreshLock()
    if not lock.acquire():
        current = read_status()
        return {
            "ok": True,
            "state": "busy",
            "message": _safe_str(current.get("message")) or "Каталог уже обновляется другим процессом.",
            "reason": reason,
        }
    try:
        if not sell_point:
            write_status("resolving_sell_point", "Определяю торговую точку SIGMA…", reason=reason)
            sell_point = _resolve_sell_point(cfg)
            cfg["sigma_sell_point_id"] = sell_point
        if not sell_point:
            return write_status(
                "missing_sell_point",
                "Не удалось определить торговую точку SIGMA.",
                reason=reason,
                ok=False,
            )

        before = _catalog_meta(company, sell_point)
        default_min_age = int(cfg.get("sai_ready_startup_min_age_minutes", DEFAULT_STARTUP_MIN_AGE_MINUTES) or DEFAULT_STARTUP_MIN_AGE_MINUTES)
        threshold_minutes = max(0, int(default_min_age if min_age_minutes is None else min_age_minutes))
        age_seconds = None if before is None else before.get("age_seconds")
        if not force and age_seconds is not None and float(age_seconds) < threshold_minutes * 60:
            message = (
                f"Каталог уже свежий: {before.get('product_count', 0)} товаров, "
                f"{before.get('barcode_count', 0)} ШК, возраст {human_age(age_seconds)}."
            )
            payload = write_status(
                "ready",
                message,
                reason=reason,
                ok=True,
                refreshed=False,
                internal_barcode_counter=barcode_sync.get("counter"),
                **before,
            )
            return payload

        write_status(
            "refreshing",
            "SAI Ready обновляет локальный каталог SIGMA…",
            reason=reason,
            ok=False,
            previous_age_seconds=age_seconds,
        )
        from sai_app import get_sigma_api_catalog_cached

        catalog = get_sigma_api_catalog_cached(company, token, sell_point, log_callback=_append_log, force_refresh=True)
        product_count = int(catalog.get("product_count") or 0)
        barcode_count = len(catalog.get("codes") or [])
        if product_count <= 0 or barcode_count <= 0:
            raise RuntimeError("SIGMA вернула пустой каталог")
        after = _catalog_meta(company, sell_point) or {}
        message = f"Каталог готов: {product_count} товаров, {barcode_count} ШК."
        save_private_config_patch({
            "sai_ready_last_success_at": _now_text(),
            "sai_ready_last_product_count": product_count,
            "sai_ready_last_barcode_count": barcode_count,
            "sai_ready_last_error": "",
        })
        barcode_sync = synchronize_internal_barcode_counter()
        payload = write_status(
            "ready",
            message,
            reason=reason,
            ok=True,
            refreshed=True,
            product_count=product_count,
            barcode_count=barcode_count,
            internal_barcode_counter=barcode_sync.get("counter"),
            **{key: value for key, value in after.items() if key not in {"product_count", "barcode_count"}},
        )
        return payload
    except Exception as exc:
        cfg = load_private_config()
        company = _safe_str(cfg.get("sigma_company_key"))
        sell_point = _safe_str(cfg.get("sigma_sell_point_id"))
        fallback = _catalog_meta(company, sell_point) if company and sell_point else None
        message = "Фоновое обновление каталога не удалось: " + _safe_str(exc)[:240]
        save_private_config_patch({"sai_ready_last_error": message, "sai_ready_last_error_at": _now_text()})
        if fallback and fallback.get("product_count"):
            return write_status(
                "ready_stale",
                message + f" Используется локальная версия возрастом {human_age(fallback.get('age_seconds'))}.",
                reason=reason,
                ok=True,
                refreshed=False,
                **fallback,
            )
        return write_status("error", message, reason=reason, ok=False)
    finally:
        lock.release()


def spawn_background_refresh(*, reason: str = "app-open", force: bool = False) -> bool:
    """Start an invisible one-shot refresh process and return immediately."""
    try:
        python_exe = Path(sys.executable)
        if os.name == "nt" and python_exe.name.lower() == "python.exe":
            pythonw = python_exe.with_name("pythonw.exe")
            if pythonw.is_file():
                python_exe = pythonw
        args = [str(python_exe), str(Path(__file__).resolve()), "--once", "--reason", reason]
        if force:
            args.append("--force")
        flags = 0
        if os.name == "nt":
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
        subprocess.Popen(
            args,
            cwd=str(APP_DIR),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=(os.name != "nt"),
            creationflags=flags,
        )
        return True
    except Exception as exc:
        _append_log("Не удалось запустить фоновый процесс: " + _safe_str(exc)[:220])
        return False


def run_startup_worker(force: bool = False) -> int:
    cfg = load_private_config()
    if not bool(cfg.get("sai_ready_enabled", True)):
        write_status("disabled", "SAI Ready отключён в настройках.", reason="windows-startup", ok=True)
        return 0
    delay = max(0, min(300, int(cfg.get("sai_ready_startup_delay_seconds", DEFAULT_STARTUP_DELAY_SECONDS) or 0)))
    if delay:
        write_status("waiting", f"Жду {delay} сек., пока Windows и сеть закончат запуск…", reason="windows-startup", ok=True)
        time.sleep(delay)
    attempts = max(1, min(8, int(cfg.get("sai_ready_retry_attempts", 4) or 4)))
    retry_seconds = max(15, min(300, int(cfg.get("sai_ready_retry_seconds", 45) or 45)))
    for index in range(attempts):
        result = refresh_catalog(reason="windows-startup", force=force)
        if bool(result.get("ok")):
            supplier_result = refresh_suppliers(force=force)
            supplier_count = int(supplier_result.get("supplier_count") or 0)
            if supplier_result.get("refreshed") or supplier_result.get("_sync_state") == "fresh":
                state = "ready"
                message = (
                    f"SAI Ready завершён: каталог — {int(result.get('product_count') or 0)} товаров; "
                    f"поставщики — {supplier_count}."
                )
            else:
                state = "ready_suppliers_stale"
                message = (
                    f"Каталог готов; поставщики не обновлены. "
                    f"Используется сохранённый список: {supplier_count}."
                )
            write_status(
                state,
                message,
                reason="windows-startup",
                ok=True,
                product_count=int(result.get("product_count") or 0),
                barcode_count=int(result.get("barcode_count") or 0),
                supplier_count=supplier_count,
                suppliers_refreshed=bool(supplier_result.get("refreshed")),
                internal_barcode_counter=result.get("internal_barcode_counter"),
            )
            return 0
        if index + 1 < attempts:
            write_status(
                "retry_wait",
                f"Сеть или SIGMA пока недоступны. Повтор через {retry_seconds} сек. ({index + 2}/{attempts}).",
                reason="windows-startup",
                ok=False,
            )
            time.sleep(retry_seconds)
    return 1


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="SAI Ready catalog preloader")
    parser.add_argument("--once", action="store_true", help="run a single refresh decision")
    parser.add_argument("--startup", action="store_true", help="run delayed Windows-startup workflow")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--reason", default="manual")
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args(argv)
    ensure_runtime_dirs()
    if args.check:
        print(f"OK: SAI Ready {APP_VERSION}")
        return 0
    if args.status:
        print(json.dumps({"catalog": catalog_snapshot(), "worker": read_status()}, ensure_ascii=False, indent=2))
        return 0
    if args.startup:
        return run_startup_worker(force=args.force)
    result = refresh_catalog(reason=args.reason, force=args.force)
    if not args.once:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if bool(result.get("ok")) else 1


if __name__ == "__main__":
    raise SystemExit(main())
