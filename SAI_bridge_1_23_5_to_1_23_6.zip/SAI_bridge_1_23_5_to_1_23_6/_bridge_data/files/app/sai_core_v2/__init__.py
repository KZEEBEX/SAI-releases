#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""SAI Core v2 foundations.

This package contains framework-independent contracts that new warehouse,
checkout and multi-device features should build on. Existing public modules
remain as compatibility facades while implementation moves here gradually.
"""
from .models import DraftStatus, ReceiptDraft, ReceiptStage, STAGE_LABELS
from .workflow import ReceiptWorkflow, InvalidStageTransition
from .node_graph import (
    NodeEdge, NodeExecution, NodeGraph, NodeGraphError, NodeOutcome,
    NodeRunner, NodeSpec, ProcessCursor,
)
from .events import DomainEvent, EventBus, domain_events
from .receipt_routing import (
    DraftResumeKind, DraftResumePlan, ReceiptRouteKind, ReceiptRoutePlan,
    build_draft_resume_plan, build_receipt_route_plan,
)
from .manual_receipt import (
    ManualReceiptDocument, ManualReceiptDocumentItem, ManualReceiptRow,
    build_document as build_manual_receipt_document, merge_row as merge_manual_receipt_row,
)
from .pricing import (
    LOW_PURCHASE_THRESHOLD, LOW_RETAIL_THRESHOLD, RETAIL_PRICE_STEP,
    sale_price_from_purchase,
)
from .semi_auto_receipt import (
    BarcodeParseResult, SemiAutoProgress, missing_indices as semi_auto_missing_indices,
    parse_scan_barcodes as parse_semi_auto_barcodes, progress as semi_auto_progress,
)

__all__ = [
    "DraftStatus",
    "ReceiptDraft",
    "ReceiptStage",
    "STAGE_LABELS",
    "ReceiptWorkflow",
    "InvalidStageTransition",
    "NodeEdge",
    "NodeExecution",
    "NodeGraph",
    "NodeGraphError",
    "NodeOutcome",
    "NodeRunner",
    "NodeSpec",
    "ProcessCursor",
    "DomainEvent",
    "EventBus",
    "domain_events",
    "DraftResumeKind",
    "DraftResumePlan",
    "build_draft_resume_plan",
    "ReceiptRouteKind",
    "ReceiptRoutePlan",
    "build_receipt_route_plan",
    "ManualReceiptRow",
    "ManualReceiptDocumentItem",
    "ManualReceiptDocument",
    "build_manual_receipt_document",
    "merge_manual_receipt_row",
    "LOW_PURCHASE_THRESHOLD",
    "LOW_RETAIL_THRESHOLD",
    "RETAIL_PRICE_STEP",
    "sale_price_from_purchase",
    "BarcodeParseResult",
    "SemiAutoProgress",
    "parse_semi_auto_barcodes",
    "semi_auto_missing_indices",
    "semi_auto_progress",
]
