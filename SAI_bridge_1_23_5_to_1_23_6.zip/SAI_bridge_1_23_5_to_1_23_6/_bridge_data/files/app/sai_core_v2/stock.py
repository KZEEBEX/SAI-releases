#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Warehouse domain: stable product identity and immutable stock ledger."""
from __future__ import annotations

import datetime as dt
import sqlite3
import uuid
from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from .migrations import Migration

_IDENTITY_NAMESPACE = uuid.UUID("09a03e70-92d8-4dbb-9643-2e537ab6c4e8")


def _now() -> str:
    return dt.datetime.now().astimezone().isoformat()


def stable_product_id(source_system: str, company_key: str, external_id: str) -> str:
    """Return the same SAI id for the same external product on every machine."""
    key = "\x1f".join(part.strip() for part in (source_system, company_key, external_id))
    if not all(part.strip() for part in (source_system, company_key, external_id)):
        raise ValueError("source_system, company_key and external_id are required")
    return str(uuid.uuid5(_IDENTITY_NAMESPACE, key))


def _create_stock_schema(con: sqlite3.Connection) -> None:
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS product_identities (
            sai_product_id TEXT PRIMARY KEY,
            source_system TEXT NOT NULL,
            company_key TEXT NOT NULL,
            external_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL,
            UNIQUE(source_system, company_key, external_id)
        );
        CREATE INDEX IF NOT EXISTS idx_product_identity_external
            ON product_identities(source_system, company_key, external_id);

        CREATE TABLE IF NOT EXISTS stock_locations (
            location_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            location_type TEXT NOT NULL DEFAULT 'store',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS stock_movements (
            movement_id TEXT PRIMARY KEY,
            idempotency_key TEXT NOT NULL UNIQUE,
            sai_product_id TEXT NOT NULL,
            location_id TEXT NOT NULL,
            movement_type TEXT NOT NULL,
            quantity_delta TEXT NOT NULL,
            unit_cost TEXT,
            source_system TEXT NOT NULL,
            source_document_id TEXT,
            occurred_at TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            note TEXT,
            FOREIGN KEY(sai_product_id) REFERENCES product_identities(sai_product_id),
            FOREIGN KEY(location_id) REFERENCES stock_locations(location_id)
        );
        CREATE INDEX IF NOT EXISTS idx_stock_movement_balance
            ON stock_movements(location_id, sai_product_id, occurred_at);
        CREATE INDEX IF NOT EXISTS idx_stock_movement_source
            ON stock_movements(source_system, source_document_id);
        CREATE TRIGGER IF NOT EXISTS stock_movements_no_update
        BEFORE UPDATE ON stock_movements
        BEGIN
            SELECT RAISE(ABORT, 'stock movements are immutable');
        END;
        CREATE TRIGGER IF NOT EXISTS stock_movements_no_delete
        BEFORE DELETE ON stock_movements
        BEGIN
            SELECT RAISE(ABORT, 'stock movements are immutable');
        END;
        """
    )
    # Existing SIGMA mirror rows receive stable SAI identities immediately.
    # The mirror may later be refreshed or removed without losing these links.
    try:
        rows = con.execute("SELECT DISTINCT company_key, sigma_id FROM products").fetchall()
    except sqlite3.OperationalError:
        rows = ()
    now = _now()
    for company_key, sigma_id in rows:
        source, company, external = "sigma", str(company_key), str(sigma_id)
        con.execute(
            """INSERT OR IGNORE INTO product_identities(
                   sai_product_id, source_system, company_key, external_id, created_at, last_seen_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (stable_product_id(source, company, external), source, company, external, now, now),
        )


STOCK_MIGRATIONS = (Migration(4, "catalog_identity_and_stock_ledger", _create_stock_schema),)


@dataclass(frozen=True, slots=True)
class StockMovement:
    idempotency_key: str
    sai_product_id: str
    location_id: str
    movement_type: str
    quantity_delta: Decimal
    source_system: str
    source_document_id: str = ""
    unit_cost: Decimal | None = None
    occurred_at: str = ""
    note: str = ""


def ensure_location(con: sqlite3.Connection, location_id: str, name: str, location_type: str = "store") -> None:
    if not location_id.strip() or not name.strip():
        raise ValueError("location_id and name are required")
    con.execute(
        """INSERT INTO stock_locations(location_id, name, location_type, created_at)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(location_id) DO UPDATE SET name=excluded.name,
               location_type=excluded.location_type, active=1""",
        (location_id.strip(), name.strip(), location_type.strip() or "store", _now()),
    )


def link_external_product(con: sqlite3.Connection, source_system: str, company_key: str, external_id: str) -> str:
    product_id = stable_product_id(source_system, company_key, external_id)
    now = _now()
    con.execute(
        """INSERT INTO product_identities(
               sai_product_id, source_system, company_key, external_id, created_at, last_seen_at)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(source_system, company_key, external_id)
           DO UPDATE SET last_seen_at=excluded.last_seen_at""",
        (product_id, source_system.strip(), company_key.strip(), external_id.strip(), now, now),
    )
    return product_id


def sync_sigma_identities(con: sqlite3.Connection, company_key: str) -> int:
    rows = con.execute(
        "SELECT sigma_id FROM products WHERE company_key=?", (company_key,)
    ).fetchall()
    for row in rows:
        link_external_product(con, "sigma", company_key, str(row[0]))
    return len(rows)


def record_movement(con: sqlite3.Connection, movement: StockMovement) -> tuple[str, bool]:
    if not movement.idempotency_key.strip():
        raise ValueError("idempotency_key is required")
    if movement.quantity_delta == 0:
        raise ValueError("quantity_delta must not be zero")
    existing = con.execute(
        "SELECT movement_id FROM stock_movements WHERE idempotency_key=?",
        (movement.idempotency_key,),
    ).fetchone()
    if existing:
        return str(existing[0]), False
    movement_id = str(uuid.uuid4())
    con.execute(
        """INSERT INTO stock_movements(
               movement_id, idempotency_key, sai_product_id, location_id, movement_type,
               quantity_delta, unit_cost, source_system, source_document_id,
               occurred_at, recorded_at, note)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            movement_id, movement.idempotency_key.strip(), movement.sai_product_id,
            movement.location_id, movement.movement_type.strip(), str(movement.quantity_delta),
            None if movement.unit_cost is None else str(movement.unit_cost),
            movement.source_system.strip(), movement.source_document_id.strip(),
            movement.occurred_at or _now(), _now(), movement.note.strip(),
        ),
    )
    return movement_id, True


def stock_balance(con: sqlite3.Connection, sai_product_id: str, location_id: str) -> Decimal:
    rows = con.execute(
        "SELECT quantity_delta FROM stock_movements WHERE sai_product_id=? AND location_id=?",
        (sai_product_id, location_id),
    )
    return sum((Decimal(str(row[0])) for row in rows), Decimal("0"))


def balances(con: sqlite3.Connection, location_id: str) -> dict[str, Decimal]:
    result: dict[str, Decimal] = {}
    rows: Iterable[sqlite3.Row] = con.execute(
        "SELECT sai_product_id, quantity_delta FROM stock_movements WHERE location_id=?",
        (location_id,),
    )
    for product_id, delta in rows:
        result[str(product_id)] = result.get(str(product_id), Decimal("0")) + Decimal(str(delta))
    return result
