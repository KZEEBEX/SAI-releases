#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Stable domain values used by receipt workflows."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class ReceiptStage(str, Enum):
    AI_REVIEW = "ai_review"
    SEMI_AUTO = "semi_auto"
    AUTOMATIC = "automatic"
    MANUAL_ENTRY = "manual_entry"
    IMPORT = "import"
    COMPLETED = "completed"


class DraftStatus(str, Enum):
    ACTIVE = "active"
    COMPLETED = "completed"
    DELETED = "deleted"


STAGE_LABELS: dict[str, str] = {
    ReceiptStage.AI_REVIEW.value: "Результат AI готов",
    ReceiptStage.SEMI_AUTO.value: "Нужны штрихкоды",
    ReceiptStage.AUTOMATIC.value: "Готов к приходу",
    ReceiptStage.MANUAL_ENTRY.value: "Ручная накладная",
    ReceiptStage.IMPORT.value: "Подготовка прихода",
    ReceiptStage.COMPLETED.value: "Завершён",
}


def stage_value(value: ReceiptStage | str) -> str:
    return value.value if isinstance(value, ReceiptStage) else str(value or "")


@dataclass(frozen=True, slots=True)
class ReceiptDraft:
    """Typed read model for a persisted receipt draft.

    Unknown fields are retained in ``extra`` so old and future metadata remain
    forward-compatible while the core fields become explicit and testable.
    """

    id: str
    kind: str
    status: str
    stage: str
    supplier: str = ""
    invoice_date: str = ""
    invoice_number: str = ""
    item_count: int = 0
    purchase_total: float = 0.0
    missing_barcodes: int = 0
    package_path: str = ""
    created_at: str = ""
    updated_at: str = ""
    extra: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, payload: Mapping[str, Any]) -> "ReceiptDraft":
        known = {
            "id", "kind", "status", "stage", "supplier", "invoice_date",
            "invoice_number", "item_count", "purchase_total",
            "missing_barcodes", "package_path", "created_at", "updated_at",
        }
        return cls(
            id=str(payload.get("id") or ""),
            kind=str(payload.get("kind") or ""),
            status=str(payload.get("status") or DraftStatus.ACTIVE.value),
            stage=str(payload.get("stage") or ""),
            supplier=str(payload.get("supplier") or ""),
            invoice_date=str(payload.get("invoice_date") or ""),
            invoice_number=str(payload.get("invoice_number") or ""),
            item_count=int(payload.get("item_count") or 0),
            purchase_total=float(payload.get("purchase_total") or 0),
            missing_barcodes=int(payload.get("missing_barcodes") or 0),
            package_path=str(payload.get("package_path") or ""),
            created_at=str(payload.get("created_at") or ""),
            updated_at=str(payload.get("updated_at") or ""),
            extra={key: value for key, value in payload.items() if key not in known},
        )

    @property
    def stage_label(self) -> str:
        return STAGE_LABELS.get(self.stage, self.stage)
