#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Local account and module-entitlement foundation for the SAI ecosystem."""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import secrets
import sqlite3
import uuid
from dataclasses import dataclass

from .migrations import Migration


def _now() -> str:
    return dt.datetime.now().astimezone().isoformat()


def _create_account_schema(con: sqlite3.Connection) -> None:
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS sai_users (
            user_id TEXT PRIMARY KEY,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            display_name TEXT NOT NULL,
            role TEXT NOT NULL,
            status TEXT NOT NULL,
            password_salt TEXT,
            password_hash TEXT,
            password_iterations INTEGER,
            created_at TEXT NOT NULL,
            activated_at TEXT,
            last_login_at TEXT
        );
        CREATE TABLE IF NOT EXISTS module_entitlements (
            entitlement_id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            module_code TEXT NOT NULL,
            status TEXT NOT NULL,
            source TEXT NOT NULL,
            valid_from TEXT NOT NULL,
            valid_until TEXT,
            created_at TEXT NOT NULL,
            UNIQUE(user_id, module_code),
            FOREIGN KEY(user_id) REFERENCES sai_users(user_id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_entitlements_user
            ON module_entitlements(user_id, status);
        """
    )
    now = _now()
    owner_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "sai.local/users/mike"))
    con.execute(
        """INSERT OR IGNORE INTO sai_users(
               user_id, username, display_name, role, status, created_at)
           VALUES (?, 'mike', 'Mike', 'owner', 'pending_activation', ?)""",
        (owner_id, now),
    )
    con.execute(
        """INSERT OR IGNORE INTO module_entitlements(
               entitlement_id, user_id, module_code, status, source,
               valid_from, created_at)
           VALUES (?, ?, 'stock', 'active', 'owner_bootstrap', ?, ?)""",
        (str(uuid.uuid5(uuid.NAMESPACE_URL, "sai.local/entitlements/mike/stock")), owner_id, now, now),
    )


ACCOUNT_MIGRATIONS = (Migration(5, "local_owner_and_module_entitlements", _create_account_schema),)


@dataclass(frozen=True, slots=True)
class UserAccount:
    user_id: str
    username: str
    display_name: str
    role: str
    status: str
    modules: tuple[str, ...]
    created_at: str = ""
    activated_at: str = ""
    last_login_at: str = ""


@dataclass(frozen=True, slots=True)
class ModuleAccess:
    code: str
    name: str
    description: str
    enabled: bool
    locked: bool = False


CORE_MODULES = frozenset({"receipt", "stock"})


def _create_admin_schema(con: sqlite3.Connection) -> None:
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS module_catalog (
            module_code TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            description TEXT NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 100,
            available INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS user_secrets (
            user_id TEXT NOT NULL,
            secret_kind TEXT NOT NULL,
            encrypted_value TEXT NOT NULL,
            masked_value TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(user_id, secret_kind),
            FOREIGN KEY(user_id) REFERENCES sai_users(user_id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS admin_audit_log (
            event_id TEXT PRIMARY KEY,
            actor_user_id TEXT,
            target_user_id TEXT,
            action TEXT NOT NULL,
            details TEXT,
            created_at TEXT NOT NULL
        );
        """
    )
    modules = (
        ("receipt", "Приёмка SAI", "Накладные, привозы и передача прихода в SIGMA", 10),
        ("stock", "Склад", "Остатки, движения и инвентаризация", 20),
        ("price_tags", "Ценники", "PDF и термоценники", 30),
        ("invoice_ai", "ChatGPT для накладных", "Распознавание входящих документов", 40),
        ("pos", "Касса", "Продажи, возвраты и чеки", 50),
        ("analytics", "Аналитика", "Продажи, остатки и показатели магазина", 60),
    )
    con.executemany(
        """INSERT OR IGNORE INTO module_catalog(
               module_code, display_name, description, sort_order) VALUES (?, ?, ?, ?)""",
        modules,
    )


def _create_user_ai_settings_schema(con: sqlite3.Connection) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS user_ai_settings (
            user_id TEXT PRIMARY KEY,
            model TEXT NOT NULL DEFAULT '',
            proxy_url TEXT NOT NULL DEFAULT '',
            api_base TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES sai_users(user_id) ON DELETE CASCADE
        )
        """
    )


ACCOUNT_ADMIN_MIGRATIONS = (
    Migration(6, "admin_users_modules_and_secrets", _create_admin_schema),
    Migration(7, "admin_owned_ai_settings", _create_user_ai_settings_schema),
)


def get_user(con: sqlite3.Connection, username: str) -> UserAccount | None:
    row = con.execute(
        """SELECT user_id, username, display_name, role, status,
                  created_at, activated_at, last_login_at
           FROM sai_users WHERE username=? COLLATE NOCASE""",
        (username.strip(),),
    ).fetchone()
    if not row:
        return None
    modules = tuple(str(item[0]) for item in con.execute(
        "SELECT module_code FROM module_entitlements WHERE user_id=? AND status='active' ORDER BY module_code",
        (row[0],),
    ))
    return UserAccount(
        str(row[0]), str(row[1]), str(row[2]), str(row[3]), str(row[4]), modules,
        str(row[5] or ""), str(row[6] or ""), str(row[7] or ""),
    )


def set_password(con: sqlite3.Connection, username: str, password: str) -> None:
    if len(password) < 8:
        raise ValueError("Пароль должен содержать не менее 8 символов")
    salt = secrets.token_bytes(16)
    iterations = 310_000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    changed = con.execute(
        """UPDATE sai_users SET password_salt=?, password_hash=?, password_iterations=?,
               status='active', activated_at=COALESCE(activated_at, ?)
           WHERE username=? COLLATE NOCASE""",
        (salt.hex(), digest.hex(), iterations, _now(), username.strip()),
    ).rowcount
    if not changed:
        raise ValueError("Пользователь не найден")


def verify_password(con: sqlite3.Connection, username: str, password: str) -> bool:
    row = con.execute(
        """SELECT password_salt, password_hash, password_iterations
           FROM sai_users WHERE username=? COLLATE NOCASE AND status='active'""",
        (username.strip(),),
    ).fetchone()
    if not row or not row[0] or not row[1]:
        return False
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(row[0]), int(row[2]))
    accepted = hmac.compare_digest(actual.hex(), str(row[1]))
    if accepted:
        con.execute("UPDATE sai_users SET last_login_at=? WHERE username=? COLLATE NOCASE", (_now(), username.strip()))
    return accepted


def has_module(con: sqlite3.Connection, username: str, module_code: str) -> bool:
    if module_code.strip() in CORE_MODULES:
        # Receipt and stock are product foundations, not subscription
        # entitlements. Legacy databases may still contain an inactive row
        # from the early admin prototype; it must never disable these modules.
        return bool(con.execute(
            "SELECT 1 FROM sai_users WHERE username=? COLLATE NOCASE",
            (username.strip(),),
        ).fetchone())
    row = con.execute(
        """SELECT 1 FROM module_entitlements e JOIN sai_users u ON u.user_id=e.user_id
           WHERE u.username=? COLLATE NOCASE AND e.module_code=? AND e.status='active'
             AND (e.valid_until IS NULL OR e.valid_until > ?)""",
        (username.strip(), module_code.strip(), _now()),
    ).fetchone()
    return bool(row)


def list_users(con: sqlite3.Connection) -> list[UserAccount]:
    names = [str(row[0]) for row in con.execute("SELECT username FROM sai_users ORDER BY display_name COLLATE NOCASE")]
    return [account for name in names if (account := get_user(con, name)) is not None]


def create_user(con: sqlite3.Connection, username: str, display_name: str, role: str = "operator") -> UserAccount:
    login = username.strip().lower()
    name = display_name.strip()
    if len(login) < 3 or not login.replace("_", "").replace("-", "").isalnum():
        raise ValueError("Логин: не менее 3 букв или цифр")
    if not name:
        raise ValueError("Укажите имя пользователя")
    user_id = str(uuid.uuid4())
    con.execute(
        """INSERT INTO sai_users(user_id, username, display_name, role, status, created_at)
           VALUES (?, ?, ?, ?, 'pending_activation', ?)""",
        (user_id, login, name, role.strip() or "operator", _now()),
    )
    return get_user(con, login)  # type: ignore[return-value]


def module_access(con: sqlite3.Connection, user_id: str) -> list[ModuleAccess]:
    rows = con.execute(
        """SELECT c.module_code, c.display_name, c.description,
                  CASE WHEN e.status='active' AND (e.valid_until IS NULL OR e.valid_until > ?) THEN 1 ELSE 0 END
           FROM module_catalog c
           LEFT JOIN module_entitlements e ON e.module_code=c.module_code AND e.user_id=?
           WHERE c.available=1 ORDER BY c.sort_order, c.display_name""",
        (_now(), user_id),
    )
    return [
        ModuleAccess(str(a), str(b), str(c), True if str(a) in CORE_MODULES else bool(d), str(a) in CORE_MODULES)
        for a, b, c, d in rows
    ]


def set_module_access(con: sqlite3.Connection, user_id: str, module_code: str, enabled: bool, actor_user_id: str = "") -> None:
    if module_code in CORE_MODULES:
        raise ValueError("Приёмка SAI и Склад являются базовыми и всегда доступны")
    if not con.execute("SELECT 1 FROM module_catalog WHERE module_code=? AND available=1", (module_code,)).fetchone():
        raise ValueError("Неизвестный модуль")
    now = _now()
    con.execute(
        """INSERT INTO module_entitlements(
               entitlement_id, user_id, module_code, status, source, valid_from, created_at)
           VALUES (?, ?, ?, ?, 'admin', ?, ?)
           ON CONFLICT(user_id, module_code) DO UPDATE SET
               status=excluded.status, source='admin', valid_from=excluded.valid_from,
               valid_until=NULL""",
        (str(uuid.uuid4()), user_id, module_code, "active" if enabled else "inactive", now, now),
    )
    con.execute(
        "INSERT INTO admin_audit_log VALUES (?, ?, ?, ?, ?, ?)",
        (str(uuid.uuid4()), actor_user_id or None, user_id, "module_enabled" if enabled else "module_disabled", module_code, now),
    )


def set_user_secret(con: sqlite3.Connection, user_id: str, kind: str, encrypted: str, masked: str) -> None:
    con.execute(
        """INSERT INTO user_secrets(user_id, secret_kind, encrypted_value, masked_value, updated_at)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(user_id, secret_kind) DO UPDATE SET encrypted_value=excluded.encrypted_value,
               masked_value=excluded.masked_value, updated_at=excluded.updated_at""",
        (user_id, kind, encrypted, masked, _now()),
    )


def secret_mask(con: sqlite3.Connection, user_id: str, kind: str) -> str:
    row = con.execute("SELECT masked_value FROM user_secrets WHERE user_id=? AND secret_kind=?", (user_id, kind)).fetchone()
    return str(row[0]) if row else "Не задан"


def set_user_status(con: sqlite3.Connection, user_id: str, status: str, actor_user_id: str = "") -> None:
    value = status.strip().lower()
    if value not in {"active", "blocked", "pending_activation"}:
        raise ValueError("Недопустимый статус пользователя")
    if value == "active":
        password = con.execute("SELECT password_hash FROM sai_users WHERE user_id=?", (user_id,)).fetchone()
        if password and not password[0]:
            value = "pending_activation"
    if not con.execute("UPDATE sai_users SET status=? WHERE user_id=?", (value, user_id)).rowcount:
        raise ValueError("Пользователь не найден")
    con.execute(
        "INSERT INTO admin_audit_log VALUES (?, ?, ?, 'user_status_changed', ?, ?)",
        (str(uuid.uuid4()), actor_user_id or None, user_id, value, _now()),
    )
