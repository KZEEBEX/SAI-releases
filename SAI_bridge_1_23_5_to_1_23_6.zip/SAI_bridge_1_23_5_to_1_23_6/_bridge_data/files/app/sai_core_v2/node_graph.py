#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Framework-independent node graph and process runner for SAI workflows."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, Mapping


class NodeGraphError(ValueError):
    pass


class NodeOutcome(str, Enum):
    CONTINUE = "continue"
    WAIT = "wait"
    COMPLETE = "complete"
    FAIL = "fail"


@dataclass(frozen=True, slots=True)
class NodeSpec:
    key: str
    label: str
    kind: str = "action"
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class NodeEdge:
    source: str
    target: str
    label: str = ""


@dataclass(frozen=True, slots=True)
class NodeExecution:
    outcome: NodeOutcome = NodeOutcome.CONTINUE
    next_node: str | None = None
    values: Mapping[str, Any] = field(default_factory=dict)
    message: str = ""


NodeHandler = Callable[[dict[str, Any]], NodeExecution | None]


@dataclass(frozen=True, slots=True)
class NodeGraph:
    """Immutable process topology that can be shared by UI and services."""

    graph_id: str
    nodes: Mapping[str, NodeSpec]
    edges: tuple[NodeEdge, ...]
    entry: str

    @classmethod
    def build(
        cls,
        graph_id: str,
        nodes: Iterable[NodeSpec],
        edges: Iterable[NodeEdge],
        entry: str,
    ) -> "NodeGraph":
        node_map = {node.key: node for node in nodes}
        graph = cls(str(graph_id), node_map, tuple(edges), str(entry))
        graph.validate()
        return graph

    def validate(self) -> None:
        if not self.graph_id:
            raise NodeGraphError("У нодового процесса отсутствует идентификатор")
        if not self.nodes:
            raise NodeGraphError(f"Нодовый процесс {self.graph_id} не содержит узлов")
        if self.entry not in self.nodes:
            raise NodeGraphError(f"Стартовый узел {self.entry!r} отсутствует")
        for edge in self.edges:
            if edge.source not in self.nodes or edge.target not in self.nodes:
                raise NodeGraphError(
                    f"Ребро {edge.source!r} → {edge.target!r} ссылается на неизвестный узел"
                )

    def targets(self, source: str) -> tuple[str, ...]:
        return tuple(edge.target for edge in self.edges if edge.source == source)

    def can_transition(self, source: str, target: str) -> bool:
        return source in self.nodes and target in self.targets(source)

    def to_dict(self) -> dict[str, Any]:
        return {
            "graph_id": self.graph_id,
            "entry": self.entry,
            "nodes": [
                {
                    "key": node.key,
                    "label": node.label,
                    "kind": node.kind,
                    "metadata": dict(node.metadata),
                }
                for node in self.nodes.values()
            ],
            "edges": [
                {"source": edge.source, "target": edge.target, "label": edge.label}
                for edge in self.edges
            ],
        }


@dataclass(slots=True)
class ProcessCursor:
    """Serializable position and data of one process execution."""

    graph_id: str
    current: str
    values: dict[str, Any] = field(default_factory=dict)
    history: list[str] = field(default_factory=list)
    waiting: bool = False
    completed: bool = False
    error: str = ""

    @classmethod
    def start(cls, graph: NodeGraph, values: Mapping[str, Any] | None = None) -> "ProcessCursor":
        return cls(graph.graph_id, graph.entry, dict(values or {}))

    def move_to(self, graph: NodeGraph, target: str) -> None:
        if graph.graph_id != self.graph_id:
            raise NodeGraphError("Курсор принадлежит другому нодовому процессу")
        if not graph.can_transition(self.current, target):
            raise NodeGraphError(f"Недопустимый переход: {self.current} → {target}")
        self.history.append(self.current)
        self.current = target
        self.waiting = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "graph_id": self.graph_id,
            "current": self.current,
            "values": dict(self.values),
            "history": list(self.history),
            "waiting": self.waiting,
            "completed": self.completed,
            "error": self.error,
        }


class NodeRunner:
    """Executes registered node handlers until pause, completion or failure."""

    def __init__(self, graph: NodeGraph, handlers: Mapping[str, NodeHandler] | None = None) -> None:
        self.graph = graph
        self.handlers: dict[str, NodeHandler] = dict(handlers or {})

    def register(self, node_key: str, handler: NodeHandler) -> None:
        if node_key not in self.graph.nodes:
            raise NodeGraphError(f"Нельзя назначить обработчик неизвестному узлу {node_key!r}")
        self.handlers[node_key] = handler

    def step(self, cursor: ProcessCursor) -> ProcessCursor:
        if cursor.completed or cursor.waiting or cursor.error:
            return cursor
        handler = self.handlers.get(cursor.current)
        if handler is None:
            cursor.waiting = True
            return cursor
        try:
            execution = handler(cursor.values) or NodeExecution()
            cursor.values.update(execution.values)
            if execution.outcome == NodeOutcome.WAIT:
                cursor.waiting = True
                return cursor
            if execution.outcome == NodeOutcome.COMPLETE:
                cursor.completed = True
                return cursor
            if execution.outcome == NodeOutcome.FAIL:
                cursor.error = execution.message or "Нодовый процесс завершился с ошибкой"
                return cursor
            target = execution.next_node
            if target is None:
                targets = self.graph.targets(cursor.current)
                if len(targets) != 1:
                    cursor.waiting = True
                    return cursor
                target = targets[0]
            cursor.move_to(self.graph, target)
            return cursor
        except Exception as exc:
            cursor.error = str(exc)
            return cursor

    def run(self, cursor: ProcessCursor, max_steps: int = 100) -> ProcessCursor:
        for _ in range(max(1, int(max_steps))):
            before = (cursor.current, cursor.waiting, cursor.completed, cursor.error)
            self.step(cursor)
            after = (cursor.current, cursor.waiting, cursor.completed, cursor.error)
            if cursor.waiting or cursor.completed or cursor.error or after == before:
                return cursor
        cursor.error = f"Превышен предел выполнения нодового процесса: {max_steps} узлов"
        return cursor
