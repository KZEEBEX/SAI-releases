#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Unified, immutable product event journal for Warehouse and SAI Analytic."""
from __future__ import annotations

import datetime as dt
import json
import sqlite3
import uuid
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from .migrations import Migration


def _now() -> str:
    return dt.datetime.now().astimezone().isoformat()


def _event_time(invoice_date: Any, fallback: Any) -> str:
    """Use a trustworthy document date; otherwise preserve the recorded time."""
    raw = str(invoice_date or "").strip()
    for pattern in ("%Y-%m-%d", "%d.%m.%Y"):
        try:
            parsed = dt.datetime.strptime(raw, pattern)
            return parsed.replace(hour=12).astimezone().isoformat()
        except ValueError:
            pass
    return str(fallback or _now())


def _create_product_event_schema(con: sqlite3.Connection) -> None:
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS product_events (
            event_id TEXT PRIMARY KEY,
            idempotency_key TEXT NOT NULL UNIQUE,
            sai_product_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            quantity_delta TEXT,
            unit_cost TEXT,
            selling_price TEXT,
            location_id TEXT,
            source_system TEXT NOT NULL,
            source_document_id TEXT,
            occurred_at TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            note TEXT,
            metadata_json TEXT NOT NULL DEFAULT '{}',
            FOREIGN KEY(sai_product_id) REFERENCES product_identities(sai_product_id),
            FOREIGN KEY(location_id) REFERENCES stock_locations(location_id)
        );
        CREATE INDEX IF NOT EXISTS idx_product_events_timeline
            ON product_events(sai_product_id, occurred_at DESC, recorded_at DESC);
        CREATE INDEX IF NOT EXISTS idx_product_events_type
            ON product_events(event_type, occurred_at DESC);
        CREATE INDEX IF NOT EXISTS idx_product_events_source
            ON product_events(source_system, source_document_id);
        CREATE TRIGGER IF NOT EXISTS product_events_no_update
        BEFORE UPDATE ON product_events
        BEGIN
            SELECT RAISE(ABORT, 'product events are immutable');
        END;
        CREATE TRIGGER IF NOT EXISTS product_events_no_delete
        BEFORE DELETE ON product_events
        BEGIN
            SELECT RAISE(ABORT, 'product events are immutable');
        END;
        """
    )


def ensure_product_event_schema(con: sqlite3.Connection) -> None:
    """Prepare the journal for service-level and legacy database callers.

    The application initializer records the numbered migration.  Domain
    services are also used directly by tests, recovery tools and older local
    databases, so they must not assume that ``sai_db.init_db`` ran first.
    """
    _create_product_event_schema(con)


PRODUCT_EVENT_MIGRATIONS = (
    Migration(8, "unified_product_event_journal", _create_product_event_schema),
)


@dataclass(frozen=True, slots=True)
class ProductEvent:
    idempotency_key: str
    sai_product_id: str
    event_type: str
    source_system: str
    occurred_at: str
    source_document_id: str = ""
    quantity_delta: Decimal | None = None
    unit_cost: Decimal | None = None
    selling_price: Decimal | None = None
    location_id: str = ""
    note: str = ""
    metadata: dict[str, Any] | None = None


def record_product_event(con: sqlite3.Connection, event: ProductEvent) -> tuple[str, bool]:
    key = event.idempotency_key.strip()
    product_id = event.sai_product_id.strip()
    event_type = event.event_type.strip()
    if not key or not product_id or not event_type:
        raise ValueError("idempotency_key, sai_product_id and event_type are required")
    existing = con.execute(
        "SELECT event_id FROM product_events WHERE idempotency_key=?", (key,)
    ).fetchone()
    if existing:
        return str(existing[0]), False
    event_id = str(uuid.uuid4())
    con.execute(
        """INSERT INTO product_events(
               event_id, idempotency_key, sai_product_id, event_type,
               quantity_delta, unit_cost, selling_price, location_id,
               source_system, source_document_id, occurred_at, recorded_at,
               note, metadata_json)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            event_id,
            key,
            product_id,
            event_type,
            None if event.quantity_delta is None else str(event.quantity_delta),
            None if event.unit_cost is None else str(event.unit_cost),
            None if event.selling_price is None else str(event.selling_price),
            event.location_id.strip() or None,
            event.source_system.strip(),
            event.source_document_id.strip(),
            event.occurred_at or _now(),
            _now(),
            event.note.strip(),
            json.dumps(event.metadata or {}, ensure_ascii=False, separators=(",", ":"), default=str),
        ),
    )
    return event_id, True


def _identity_for_receipt_row(
    con: sqlite3.Connection, external_id: str, barcode: str,
) -> str:
    external_id = str(external_id or "").strip()
    if external_id:
        rows = con.execute(
            """SELECT sai_product_id FROM product_identities
               WHERE source_system='sigma' AND external_id=?""",
            (external_id,),
        ).fetchall()
        identities = {str(row[0]) for row in rows}
        if len(identities) == 1:
            return identities.pop()
    barcode = str(barcode or "").strip()
    if barcode:
        rows = con.execute(
            """SELECT DISTINCT i.sai_product_id
               FROM barcodes b
               JOIN product_identities i
                 ON i.source_system='sigma'
                AND i.external_id=b.product_id
                AND i.company_key=b.company_key
               WHERE b.barcode=?""",
            (barcode,),
        ).fetchall()
        identities = {str(row[0]) for row in rows}
        if len(identities) == 1:
            return identities.pop()
    return ""


def sync_receipt_events(con: sqlite3.Connection, apply_run_id: int = 0) -> tuple[int, int]:
    """Materialize successful receipt rows into the journal, idempotently."""
    params: tuple[Any, ...] = ()
    where_run = ""
    if int(apply_run_id or 0) > 0:
        where_run = "AND ph.apply_run_id=?"
        params = (int(apply_run_id),)
    rows = con.execute(
        f"""SELECT ph.id, ph.apply_run_id, ph.product_id,
                   COALESCE(NULLIF(ph.used_barcode, ''), ph.barcode, ''),
                   ph.name, ph.quantity, ph.buying_price, ph.final_selling_price,
                   ph.supplier_name, ph.invoice_date, ph.waybill_id, ph.created_at
            FROM price_history ph
            JOIN apply_runs ar ON ar.id=ph.apply_run_id
            LEFT JOIN product_events pe ON pe.idempotency_key='receipt:' || ph.apply_run_id || ':' || ph.id
            WHERE UPPER(COALESCE(ph.status, ''))='OK'
              AND LOWER(COALESCE(ar.status, ''))='ok'
              AND pe.event_id IS NULL
              {where_run}
            ORDER BY ph.id""",
        params,
    ).fetchall()
    added = 0
    unlinked = 0
    for row in rows:
        product_id = _identity_for_receipt_row(con, str(row[2] or ""), str(row[3] or ""))
        if not product_id:
            unlinked += 1
            continue
        _, created = record_product_event(con, ProductEvent(
            idempotency_key=f"receipt:{int(row[1])}:{int(row[0])}",
            sai_product_id=product_id,
            event_type="receipt",
            quantity_delta=Decimal(str(row[5] or 0)),
            unit_cost=Decimal(str(row[6] or 0)),
            selling_price=Decimal(str(row[7] or 0)),
            source_system="sai_receipt",
            source_document_id=str(row[10] or row[1]),
            occurred_at=_event_time(row[9], row[11]),
            note=f"Приход от {str(row[8] or 'поставщика не указан')}",
            metadata={
                "apply_run_id": int(row[1]),
                "price_history_id": int(row[0]),
                "name_at_event": str(row[4] or ""),
                "barcode": str(row[3] or ""),
                "invoice_date": str(row[9] or ""),
            },
        ))
        added += int(created)
    return added, unlinked


def sync_stock_movement_events(con: sqlite3.Connection) -> int:
    """Mirror existing immutable stock movements into the common journal."""
    rows = con.execute(
        """SELECT m.movement_id, m.sai_product_id, m.movement_type,
                  m.quantity_delta, m.unit_cost, m.location_id, m.source_system,
                  m.source_document_id, m.occurred_at, m.note
           FROM stock_movements m
           LEFT JOIN product_events pe ON pe.idempotency_key='stock:' || m.movement_id
           WHERE pe.event_id IS NULL
           ORDER BY m.recorded_at"""
    ).fetchall()
    added = 0
    for row in rows:
        _, created = record_product_event(con, ProductEvent(
            idempotency_key=f"stock:{row[0]}",
            sai_product_id=str(row[1]),
            event_type=str(row[2]),
            quantity_delta=Decimal(str(row[3])),
            unit_cost=None if row[4] in (None, "") else Decimal(str(row[4])),
            location_id=str(row[5] or ""),
            source_system=str(row[6] or "sai_stock"),
            source_document_id=str(row[7] or ""),
            occurred_at=str(row[8] or _now()),
            note=str(row[9] or ""),
            metadata={"stock_movement_id": str(row[0])},
        ))
        added += int(created)
    return added


def sync_product_event_journal(con: sqlite3.Connection) -> dict[str, int]:
    stock_added = sync_stock_movement_events(con)
    receipt_added, unlinked = sync_receipt_events(con)
    return {
        "stock_added": stock_added,
        "receipt_added": receipt_added,
        "receipt_unlinked": unlinked,
    }


def product_timeline(con: sqlite3.Connection, sai_product_id: str, limit: int = 250) -> list[dict[str, Any]]:
    rows = con.execute(
        """SELECT e.event_id, e.occurred_at, e.event_type, e.quantity_delta,
                  e.unit_cost, COALESCE(sl.unit_price, e.selling_price), e.source_system,
                  e.source_document_id, e.note, e.metadata_json,
                  COALESCE(l.name, '')
           FROM product_events e
           LEFT JOIN stock_locations l ON l.location_id=e.location_id
           LEFT JOIN sigma_sale_lines sl ON 'sigma-sale:' || sl.line_key=e.idempotency_key
           WHERE e.sai_product_id=?
           ORDER BY e.occurred_at DESC, e.recorded_at DESC
           LIMIT ?""",
        (sai_product_id, max(1, int(limit))),
    ).fetchall()
    result: list[dict[str, Any]] = []
    for row in rows:
        try:
            metadata = json.loads(row[9] or "{}")
        except Exception:
            metadata = {}
        result.append({
            "id": str(row[0]),
            "date": str(row[1]),
            "type": str(row[2]),
            "quantity": None if row[3] in (None, "") else Decimal(str(row[3])),
            "unit_cost": None if row[4] in (None, "") else Decimal(str(row[4])),
            "selling_price": None if row[5] in (None, "") else Decimal(str(row[5])),
            "source": str(row[6] or ""),
            "document": str(row[7] or ""),
            "note": str(row[8] or ""),
            "metadata": metadata,
            "location": str(row[10] or ""),
        })
    return result
