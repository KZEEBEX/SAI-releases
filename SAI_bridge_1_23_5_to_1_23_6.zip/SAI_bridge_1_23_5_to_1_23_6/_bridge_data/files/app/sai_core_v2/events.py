#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Small thread-safe in-process domain event bus."""
from __future__ import annotations

import datetime as dt
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, DefaultDict


@dataclass(frozen=True, slots=True)
class DomainEvent:
    name: str
    payload: dict[str, Any] = field(default_factory=dict)
    occurred_at: str = field(default_factory=lambda: dt.datetime.now().astimezone().isoformat())


EventHandler = Callable[[DomainEvent], None]


class EventBus:
    def __init__(self) -> None:
        self._handlers: DefaultDict[str, list[EventHandler]] = defaultdict(list)
        self._lock = threading.RLock()

    def subscribe(self, event_name: str, handler: EventHandler) -> Callable[[], None]:
        with self._lock:
            self._handlers[event_name].append(handler)

        def unsubscribe() -> None:
            with self._lock:
                handlers = self._handlers.get(event_name, [])
                if handler in handlers:
                    handlers.remove(handler)

        return unsubscribe

    def publish(self, event: DomainEvent) -> None:
        with self._lock:
            handlers = tuple(self._handlers.get(event.name, ())) + tuple(self._handlers.get("*", ()))
        for handler in handlers:
            try:
                handler(event)
            except Exception:
                # Domain notifications must never break the shop workflow.
                continue


domain_events = EventBus()
