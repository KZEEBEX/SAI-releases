#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""File-backed receipt draft repository.

The old public module ``sai_receipt_drafts`` delegates here, preserving its API
while isolating persistence from UI and workflow code.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import secrets
import shutil
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import sai_converter

from .events import DomainEvent, EventBus, domain_events
from .manual_receipt import card_has_data
from .models import DraftStatus, ReceiptStage, STAGE_LABELS
from .workflow import ReceiptWorkflow

META_NAME = "draft.json"
PACKAGE_NAME = "receipt.sai"


def _now() -> str:
    # Fast consecutive edits must remain distinct during cross-computer sync.
    return dt.datetime.now().isoformat(sep=" ", timespec="microseconds")


def _safe_id(value: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "", str(value or ""))[:80]


def _atomic_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


class FileReceiptDraftRepository:
    def __init__(
        self,
        drafts_dir: Path,
        manual_autosave: Path,
        *,
        event_bus: EventBus = domain_events,
    ) -> None:
        self.drafts_dir = Path(drafts_dir)
        self.manual_autosave = Path(manual_autosave)
        self.events = event_bus

    def ensure_dir(self) -> Path:
        self.drafts_dir.mkdir(parents=True, exist_ok=True)
        return self.drafts_dir

    @property
    def tombstone_path(self) -> Path:
        return self.ensure_dir() / "_deleted.json"

    def _load_tombstones(self) -> Dict[str, str]:
        try:
            payload = json.loads(self.tombstone_path.read_text(encoding="utf-8")) or {}
            rows = payload.get("drafts") if isinstance(payload, dict) else {}
            return {str(key): str(value) for key, value in (rows or {}).items() if str(key)}
        except Exception:
            return {}

    def _save_tombstones(self, rows: Dict[str, str]) -> None:
        _atomic_json(self.tombstone_path, {"drafts": dict(sorted(rows.items()))})

    def is_deleted(self, draft_id: str) -> bool:
        return _safe_id(draft_id) in self._load_tombstones()

    def restore(self, draft_id: str) -> None:
        safe = _safe_id(draft_id)
        if not safe:
            return
        rows = self._load_tombstones()
        if safe in rows:
            rows.pop(safe, None)
            self._save_tombstones(rows)
            self.events.publish(DomainEvent("receipt_draft.restored", {"draft_id": safe}))

    def _mark_deleted(self, draft_id: str) -> None:
        safe = _safe_id(draft_id)
        if not safe:
            return
        rows = self._load_tombstones()
        rows[safe] = _now()
        self._save_tombstones(rows)

    def new_id(self, prefix: str = "receipt") -> str:
        return f"{prefix}_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(4)}"

    def draft_dir(self, draft_id: str) -> Path:
        return self.ensure_dir() / _safe_id(draft_id)

    def metadata_path(self, draft_id: str) -> Path:
        return self.draft_dir(draft_id) / META_NAME

    def package_path(self, draft_id: str) -> Path:
        return self.draft_dir(draft_id) / PACKAGE_NAME

    @staticmethod
    def _result_summary(result: sai_converter.ConvertResult) -> Dict[str, Any]:
        items = list(result.items or [])
        total_buy = sum(float(item.quantity or 0) * float(item.purchase_price or 0) for item in items)
        missing = sum(1 for item in items if float(item.quantity or 0) > 0 and not list(item.barcodes or []))
        return {
            "supplier": str(result.supplier or "").strip() or "ПОСТАВЩИК НЕ УКАЗАН",
            "invoice_date": str(result.date or "").strip(),
            "invoice_number": str(result.invoice_number or "").strip(),
            "item_count": len(items),
            "purchase_total": round(total_buy, 2),
            "missing_barcodes": missing,
        }

    def save_result(
        self,
        result: sai_converter.ConvertResult,
        source_paths: Iterable[Path] = (),
        *,
        draft_id: Optional[str] = None,
        stage: str = ReceiptStage.AI_REVIEW.value,
        kind: str = "ai",
    ) -> Dict[str, Any]:
        self.ensure_dir()
        requested_id = _safe_id(draft_id or "")
        if requested_id and self.is_deleted(requested_id):
            return {"id": requested_id, "status": DraftStatus.DELETED.value, "deleted": True}
        draft_id = requested_id or _safe_id(self.new_id(kind))
        folder = self.draft_dir(draft_id)
        folder.mkdir(parents=True, exist_ok=True)
        meta_file = folder / META_NAME
        old: Dict[str, Any] = {}
        if meta_file.exists():
            try:
                old = json.loads(meta_file.read_text(encoding="utf-8")) or {}
            except Exception:
                old = {}
        old_stage = str(old.get("stage") or stage)
        ReceiptWorkflow.at(old_stage).move_to(stage)
        target = folder / PACKAGE_NAME
        sources = [Path(path) for path in source_paths]
        sai_converter.write_sai_package(result, target, source_paths=sources)
        payload: Dict[str, Any] = {
            "id": draft_id,
            "kind": kind,
            "status": DraftStatus.ACTIVE.value,
            "stage": stage,
            "stage_label": STAGE_LABELS.get(stage, stage),
            "package_path": str(target),
            "source_names": [path.name for path in sources],
            "created_at": old.get("created_at") or _now(),
            "updated_at": _now(),
            **self._result_summary(result),
        }
        _atomic_json(meta_file, payload)
        self.events.publish(DomainEvent("receipt_draft.saved", {"draft_id": draft_id, "stage": stage, "kind": kind}))
        return payload

    def register_manual_autosave(self, payload: Dict[str, Any], *, draft_id: str = "manual_current") -> Dict[str, Any]:
        self.ensure_dir()
        if self.is_deleted(draft_id):
            return {"id": _safe_id(draft_id), "status": DraftStatus.DELETED.value, "deleted": True}
        rows = list(payload.get("rows") or [])
        card = dict(payload.get("current_card") or {})
        has_card = card_has_data(card)
        if not rows and not has_card:
            folder = self.draft_dir(draft_id)
            if folder.exists():
                shutil.rmtree(folder, ignore_errors=True)
            try:
                self.manual_autosave.unlink(missing_ok=True)
            except Exception:
                pass
            return {}
        _atomic_json(self.manual_autosave, payload)
        folder = self.draft_dir(draft_id)
        folder.mkdir(parents=True, exist_ok=True)
        total = 0.0
        missing_barcodes = 0
        for row in rows:
            try:
                total += float(row.get("buy") or 0) * float(row.get("qty") or 0)
            except Exception:
                pass
            try:
                if float(row.get("qty") or 0) > 0 and not list(row.get("barcodes") or []):
                    missing_barcodes += 1
            except Exception:
                pass
        old = self.get(draft_id) or {}
        meta = {
            "id": draft_id,
            "kind": "manual",
            "status": DraftStatus.ACTIVE.value,
            "stage": ReceiptStage.MANUAL_ENTRY.value,
            "stage_label": STAGE_LABELS[ReceiptStage.MANUAL_ENTRY.value],
            "manual_payload_path": str(self.manual_autosave),
            "supplier": str(payload.get("supplier_name") or "РУЧНАЯ НАКЛАДНАЯ"),
            "invoice_date": str(payload.get("date") or ""),
            "invoice_number": "",
            # The editor card is only an unfinished input form. It is restored
            # with the draft, but it is not an added invoice position yet.
            "item_count": len(rows),
            "purchase_total": round(total, 2),
            "missing_barcodes": missing_barcodes,
            "created_at": old.get("created_at") or _now(),
            "updated_at": _now(),
        }
        _atomic_json(folder / META_NAME, meta)
        self.events.publish(DomainEvent("receipt_draft.saved", {"draft_id": draft_id, "stage": meta["stage"], "kind": "manual"}))
        return meta

    def get(self, draft_id: str) -> Optional[Dict[str, Any]]:
        if self.is_deleted(draft_id):
            return None
        path = self.metadata_path(draft_id)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8")) or {}
            return data if isinstance(data, dict) else None
        except Exception:
            return None

    def find_by_package(self, path: Path | str) -> Optional[Dict[str, Any]]:
        try:
            wanted = Path(path).resolve()
        except Exception:
            return None
        for row in self.list_active():
            raw = row.get("package_path")
            if not raw:
                continue
            try:
                if Path(raw).resolve() == wanted:
                    return row
            except Exception:
                continue
        return None

    def update(self, draft_id: str, **changes: Any) -> Optional[Dict[str, Any]]:
        meta = self.get(draft_id)
        if not meta:
            return None
        old_stage = str(meta.get("stage") or "")
        new_stage = str(changes.get("stage") or old_stage)
        ReceiptWorkflow.at(old_stage).move_to(new_stage)
        meta.update(changes)
        meta["stage"] = new_stage
        meta["stage_label"] = STAGE_LABELS.get(new_stage, new_stage)
        meta["updated_at"] = _now()
        _atomic_json(self.metadata_path(draft_id), meta)
        self.events.publish(DomainEvent("receipt_draft.updated", {"draft_id": draft_id, "stage": new_stage, "changes": sorted(changes)}))
        return meta

    def update_by_package(self, path: Path | str, **changes: Any) -> Optional[Dict[str, Any]]:
        meta = self.find_by_package(path)
        if not meta:
            return None
        return self.update(str(meta.get("id") or ""), **changes)

    def mark_completed_by_package(self, path: Path | str) -> Optional[Dict[str, Any]]:
        return self.update_by_package(path, status=DraftStatus.COMPLETED.value, stage=ReceiptStage.COMPLETED.value)

    def list_all(self) -> List[Dict[str, Any]]:
        self.ensure_dir()
        rows: List[Dict[str, Any]] = []
        for meta_file in self.drafts_dir.glob(f"*/{META_NAME}"):
            try:
                data = json.loads(meta_file.read_text(encoding="utf-8")) or {}
                if isinstance(data, dict) and data.get("id") and not self.is_deleted(str(data.get("id"))):
                    rows.append(data)
            except Exception:
                continue
        rows.sort(key=lambda item: str(item.get("updated_at") or ""), reverse=True)
        return rows

    def list_active(self) -> List[Dict[str, Any]]:
        rows: List[Dict[str, Any]] = []
        for row in self.list_all():
            if str(row.get("status") or DraftStatus.ACTIVE.value) != DraftStatus.ACTIVE.value:
                continue
            package = Path(str(row.get("package_path") or "")) if row.get("package_path") else None
            if row.get("kind") == "manual":
                if not self.manual_autosave.exists() and not (package and package.exists()):
                    continue
            elif not (package and package.exists()):
                continue
            rows.append(row)
        return rows

    def remove(self, draft_id: str) -> None:
        safe = _safe_id(draft_id)
        if not safe:
            return
        self._mark_deleted(safe)
        folder = self.draft_dir(safe)
        if folder.exists():
            shutil.rmtree(folder, ignore_errors=True)
        if safe == "manual_current":
            try:
                self.manual_autosave.unlink(missing_ok=True)
            except Exception:
                pass
        self.events.publish(DomainEvent("receipt_draft.deleted", {"draft_id": safe}))
