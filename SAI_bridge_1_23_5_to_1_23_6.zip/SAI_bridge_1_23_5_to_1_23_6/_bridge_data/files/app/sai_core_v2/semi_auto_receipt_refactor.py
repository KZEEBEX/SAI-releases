#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Framework-independent rules for semi-automatic receipt barcode collection.

The Qt page and the mobile dashboard are adapters.  Barcode parsing, duplicate
checks, shortage handling, label quantities and progress calculations live here
so future clients cannot silently diverge from the desktop workflow.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import re
from typing import Any, Mapping, Sequence

STANDARD_BARCODE_LENGTHS = (8, 12, 13, 14)


def text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def number(value: Any, default: float = 0.0) -> float:
    raw = text(value).replace(" ", "").replace(",", ".")
    if not raw:
        return default
    try:
        return float(raw)
    except Exception:
        return default


def ean_checksum(base_digits: str) -> int:
    digits = [int(ch) for ch in text(base_digits) if ch.isdigit()]
    total = 0
    for index, digit in enumerate(reversed(digits)):
        total += digit * (3 if index % 2 == 0 else 1)
    return (10 - (total % 10)) % 10


def is_valid_ean(code: Any) -> bool:
    value = text(code)
    return (
        len(value) in STANDARD_BARCODE_LENGTHS
        and bool(re.fullmatch(r"\d+", value))
        and int(value[-1]) == ean_checksum(value[:-1])
    )


@dataclass(frozen=True, slots=True)
class ScanParseResult:
    codes: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    error: str = ""
    wait_more: bool = False

    @property
    def accepted(self) -> bool:
        return bool(self.codes) and not self.error and not self.wait_more

    def legacy_tuple(self) -> tuple[list[str], list[str], str, bool]:
        """Compatibility shape used by the existing Qt page."""
        return list(self.codes), list(self.warnings), self.error, self.wait_more


# Compatibility with the first 1.22.7bs branch, which published this older
# public name before the final class name was standardised.  Keep it as an
# identity alias so mixed BS builds can import either name safely.
BarcodeParseResult = ScanParseResult


def valid_barcodes_from_text(value: Any) -> tuple[str, ...]:
    result: list[str] = []
    for chunk in re.split(r"[,;\s]+", text(value)):
        code = chunk.strip()
        if re.fullmatch(r"\d+", code) and len(code) in STANDARD_BARCODE_LENGTHS and code not in result:
            result.append(code)
    return tuple(result)


def parse_scan_barcodes(value: Any, *, force: bool = False) -> ScanParseResult:
    raw = text(value)
    if not raw:
        return ScanParseResult(wait_more=True)
    chunks = [chunk.strip() for chunk in re.split(r"[,;\s]+", raw) if chunk.strip()]
    if not chunks:
        return ScanParseResult(wait_more=True)

    codes: list[str] = []
    warnings: list[str] = []
    for chunk in chunks:
        if not re.fullmatch(r"\d+", chunk):
            return ScanParseResult(error="Мусор в поле ШК: нужны только цифры. Отсканируй ещё раз.")
        size = len(chunk)
        if size in STANDARD_BARCODE_LENGTHS:
            if chunk not in codes:
                codes.append(chunk)
            if not is_valid_ean(chunk):
                warnings.append(f"{chunk}: нестандартный ШК / не сходится контрольная цифра")
            continue
        if size < min(STANDARD_BARCODE_LENGTHS) and not force:
            return ScanParseResult(wait_more=True)
        if force and 5 <= size <= 32:
            if chunk not in codes:
                codes.append(chunk)
            warnings.append(f"{chunk}: нестандартная длина, принят вручную")
            continue
        if size < 5:
            return ScanParseResult(error="Слишком короткий код. Похоже на обрывок скана.")
        return ScanParseResult(
            error="Нестандартная длина ШК. Нажми Enter/«Принять ШК», если это реальный код с товара."
        )
    return ScanParseResult(tuple(codes), tuple(warnings))


def row_barcodes(row: Mapping[str, Any] | None) -> tuple[str, ...]:
    data = row or {}
    result: list[str] = []
    raw = data.get("barcodes")
    values = raw if isinstance(raw, (list, tuple, set)) else (() if raw in (None, "") else (raw,))
    for value in values:
        for chunk in re.split(r"[,;\s]+", text(value)):
            code = chunk.strip()
            if code and code not in result:
                result.append(code)
    if not result:
        result.extend(valid_barcodes_from_text(data.get("barcode_cell")))
    return tuple(result)


def quantity_value(row: Mapping[str, Any] | None) -> float:
    data = row or {}
    raw = data.get("qty")
    if raw in (None, "") and "quantity" in data:
        raw = data.get("quantity")
    return number(raw, 0.0)


def is_zero_quantity(row: Mapping[str, Any] | None) -> bool:
    data = row or {}
    raw = data.get("qty")
    if raw in (None, ""):
        raw = data.get("quantity")
    if raw is None or text(raw) == "":
        return False
    return quantity_value(data) <= 0


def missing_barcode_indices(rows: Sequence[Mapping[str, Any]]) -> tuple[int, ...]:
    return tuple(
        index for index, row in enumerate(rows)
        if not is_zero_quantity(row) and not row_barcodes(row)
    )


def find_barcode_owner(
    rows: Sequence[Mapping[str, Any]],
    barcode: Any,
    *,
    current_index: int = -1,
    exclude_current: bool = True,
) -> int | None:
    code = text(barcode)
    if not code:
        return None
    for index, row in enumerate(rows):
        if exclude_current and index == current_index:
            continue
        if code in row_barcodes(row):
            return index
    return None


def merge_barcodes(
    row: Mapping[str, Any],
    codes: Sequence[Any],
    *,
    warnings: Sequence[Any] = (),
) -> dict[str, Any]:
    """Return an updated row without mutating caller-owned data."""
    updated = dict(row)
    merged = list(row_barcodes(row))
    for value in codes:
        code = text(value)
        if code and code not in merged:
            merged.append(code)
    updated["barcodes"] = merged
    updated["barcode_cell"] = ", ".join(merged)
    warning_text = "; ".join(text(value) for value in warnings if text(value))
    if warning_text:
        updated["barcode_warning"] = warning_text
    else:
        updated.pop("barcode_warning", None)
    return updated


def approve_operator_sale_price(
    row: Mapping[str, Any],
    sale_price: Any,
    *,
    source: str = "manual",
) -> dict[str, Any]:
    """Persist an operator-entered sale price as the final price choice.

    Automatic receipt entry normally keeps the higher of the incoming and
    catalogue prices.  A price deliberately edited by the operator is a
    decision, not a forecast, so the apply stage must not replace it.
    """
    price = round(number(sale_price, 0.0), 2)
    if not math.isfinite(price) or price <= 0:
        raise ValueError("Продажная цена должна быть больше нуля.")
    updated = dict(row)
    updated["sale"] = price
    updated["price"] = price
    updated["price_operator_approved"] = True
    updated["price_approval_source"] = text(source) or "manual"
    codes = row_barcodes(updated)
    if codes:
        updated["price_approval_barcode"] = codes[0]
    return updated


def lock_sale_price_for_thermal_label(row: Mapping[str, Any]) -> dict[str, Any]:
    """Make the price physically printed on a label authoritative end to end.

    Once a label exists on a product, a later max-price comparison must never
    silently make that label wrong.  Existing explicit operator choices keep
    their original audit source; an untouched incoming price becomes approved
    at the moment thermal printing is requested.
    """
    price = row.get("sale") if row.get("sale") not in (None, "") else row.get("price")
    updated = approve_operator_sale_price(
        row,
        price,
        source=text(row.get("price_approval_source")) or "thermal_label",
    )
    return updated


def receipt_quantity_int(row: Mapping[str, Any] | None) -> int:
    return max(0, int(round(quantity_value(row))))


def label_quantity_is_manual(row: Mapping[str, Any] | None) -> bool:
    return "label_qty" in (row or {})


def label_copies(row: Mapping[str, Any] | None) -> int:
    data = row or {}
    receipt_qty = receipt_quantity_int(data)
    if receipt_qty <= 0:
        return 0
    if "label_qty" in data:
        return max(0, int(round(number(data.get("label_qty"), 0.0))))
    return receipt_qty


@dataclass(frozen=True, slots=True)
class CollectionProgress:
    total: int
    missing: int
    zero_quantity: int
    done: int
    percent: int


# Compatibility with the other 1.22.7bs branch.  That branch exported
# the progress value object as SemiAutoProgress.  Keep both names as the
# exact same class so mixed installations cannot fail during package import.
SemiAutoProgress = CollectionProgress


def collection_progress(rows: Sequence[Mapping[str, Any]]) -> CollectionProgress:
    total = len(rows)
    missing = len(missing_barcode_indices(rows))
    zero = sum(1 for row in rows if is_zero_quantity(row))
    done = max(0, total - missing)
    percent = int(round((done / total) * 100)) if total else 0
    return CollectionProgress(total=total, missing=missing, zero_quantity=zero, done=done, percent=percent)


def next_missing_index(
    rows: Sequence[Mapping[str, Any]],
    *,
    start: int = -1,
    wrap: bool = False,
) -> int | None:
    missing = missing_barcode_indices(rows)
    for index in missing:
        if index > start:
            return index
    return missing[0] if wrap and missing else None


def next_internal_barcode(prefix: Any, last_counter: Any, existing: Sequence[Any] | set[Any]) -> tuple[str, int] | None:
    """Find the next free EAN-13 internal code without touching config/files."""
    clean_prefix = re.sub(r"\D+", "", text(prefix))[:11] or "77"
    counter_digits = 12 - len(clean_prefix)
    start = max(1, int(number(last_counter, 0.0)) + 1)
    occupied = {text(value) for value in existing if text(value)}
    for counter in range(start, 10 ** max(1, counter_digits)):
        base = clean_prefix + str(counter).zfill(counter_digits)
        code = base + str(ean_checksum(base))
        if code not in occupied:
            return code, counter
    return None
