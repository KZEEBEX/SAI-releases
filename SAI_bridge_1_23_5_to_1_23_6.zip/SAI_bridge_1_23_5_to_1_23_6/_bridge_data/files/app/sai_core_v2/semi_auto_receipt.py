#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Qt-independent rules for barcode completion in semi-automatic receipts.

This module owns the rules that must stay identical for the desktop scanner,
mobile dashboard and future clients: barcode parsing, duplicate detection,
shortage handling, progress, receipt/label quantities and internal barcode
allocation. It deliberately has no PySide, filesystem, database or printer
imports.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping, Sequence

STANDARD_BARCODE_LENGTHS = (8, 12, 13, 14)


def text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def number_float(value: Any, default: float = 0.0) -> float:
    raw = text(value).replace("\xa0", " ").replace(" ", "").replace(",", ".")
    if not raw:
        return default
    try:
        return float(raw)
    except Exception:
        return default


def formatted_number(value: Any) -> int | float:
    number = number_float(value)
    if abs(number - round(number)) < 1e-9:
        return int(round(number))
    return round(number, 3)


def ean_checksum(base_digits: Any) -> int:
    digits = text(base_digits)
    if not digits or not digits.isdigit():
        raise ValueError("EAN base must contain digits only")
    total = 0
    for offset, char in enumerate(reversed(digits)):
        total += int(char) * (3 if offset % 2 == 0 else 1)
    return (10 - total % 10) % 10


def is_valid_ean(code: Any, size: int | None = None) -> bool:
    value = text(code)
    expected = int(size or len(value))
    return bool(re.fullmatch(rf"\d{{{expected}}}", value)) and int(value[-1]) == ean_checksum(value[:-1])


@dataclass(frozen=True, slots=True)
class BarcodeParseResult:
    codes: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    error: str = ""
    wait_more: bool = False

    @property
    def accepted(self) -> bool:
        return bool(self.codes) and not self.error and not self.wait_more


def split_codes(value: Any) -> tuple[str, ...]:
    result: list[str] = []
    for chunk in re.split(r"[,;\s]+", text(value)):
        code = chunk.strip()
        if code and code not in result:
            result.append(code)
    return tuple(result)


def valid_standard_barcodes(value: Any) -> tuple[str, ...]:
    return tuple(
        code for code in split_codes(value)
        if code.isdigit() and len(code) in STANDARD_BARCODE_LENGTHS
    )


def parse_scan_barcodes(
    value: Any,
    *,
    force: bool = False,
    checksum_validator: Callable[[str, int], bool] | None = is_valid_ean,
) -> BarcodeParseResult:
    raw = text(value)
    if not raw:
        return BarcodeParseResult(wait_more=True)
    chunks = split_codes(raw)
    if not chunks:
        return BarcodeParseResult(wait_more=True)

    codes: list[str] = []
    warnings: list[str] = []
    for chunk in chunks:
        if not chunk.isdigit():
            return BarcodeParseResult(error="Мусор в поле ШК: нужны только цифры. Отсканируй ещё раз.")
        size = len(chunk)
        if size in STANDARD_BARCODE_LENGTHS:
            if chunk not in codes:
                codes.append(chunk)
            if checksum_validator is not None:
                try:
                    if not checksum_validator(chunk, size):
                        warnings.append(f"{chunk}: нестандартный ШК / не сходится контрольная цифра")
                except Exception:
                    warnings.append(f"{chunk}: нестандартный ШК")
            continue
        if size < 8 and not force:
            return BarcodeParseResult(wait_more=True)
        if force and 5 <= size <= 32:
            if chunk not in codes:
                codes.append(chunk)
            warnings.append(f"{chunk}: нестандартная длина, принят вручную")
            continue
        if size < 5:
            return BarcodeParseResult(error="Слишком короткий код. Похоже на обрывок скана.")
        return BarcodeParseResult(
            error="Нестандартная длина ШК. Нажми Enter/«Принять ШК», если это реальный код с товара."
        )
    return BarcodeParseResult(tuple(codes), tuple(warnings))


def row_barcodes(row: Mapping[str, Any]) -> tuple[str, ...]:
    values = row.get("barcodes") or ()
    if isinstance(values, (str, bytes)):
        result = split_codes(values)
    else:
        result_list: list[str] = []
        for value in values:
            for code in split_codes(value):
                if code not in result_list:
                    result_list.append(code)
        result = tuple(result_list)
    if result:
        return result
    # Historical compatibility: barcode_cell fallback accepts only regular
    # scanner lengths. Explicitly accepted short codes are persisted in barcodes.
    return valid_standard_barcodes(row.get("barcode_cell"))


def quantity_value(row: Mapping[str, Any] | None) -> float:
    return number_float((row or {}).get("qty"))


def is_zero_quantity(row: Mapping[str, Any] | None) -> bool:
    raw = (row or {}).get("qty")
    if raw is None or text(raw) == "":
        return False
    return quantity_value(row) <= 0


def receipt_quantity_int(row: Mapping[str, Any] | None) -> int:
    return max(0, int(round(quantity_value(row))))


def label_quantity_is_manual(row: Mapping[str, Any] | None) -> bool:
    return "label_qty" in (row or {})


def label_copies(row: Mapping[str, Any] | None) -> int:
    data = row or {}
    receipt_qty = receipt_quantity_int(data)
    if receipt_qty <= 0:
        return 0
    if "label_qty" in data:
        return max(0, int(round(number_float(data.get("label_qty")))))
    return receipt_qty


def missing_indices(rows: Sequence[Mapping[str, Any]]) -> tuple[int, ...]:
    # qty=0 is a handled full shortage and never requires a barcode.
    return tuple(i for i, row in enumerate(rows) if not is_zero_quantity(row) and not row_barcodes(row))


def find_barcode_owner(
    rows: Sequence[Mapping[str, Any]],
    barcode: Any,
    *,
    current_index: int = -1,
    exclude_current: bool = True,
) -> int | None:
    code = text(barcode)
    if not code:
        return None
    for index, row in enumerate(rows):
        if exclude_current and index == current_index:
            continue
        if code in row_barcodes(row):
            return index
    return None


def next_missing_index(
    rows: Sequence[Mapping[str, Any]],
    *,
    start: int = -1,
    wrap: bool = False,
) -> int | None:
    missing = missing_indices(rows)
    for index in missing:
        if index > start:
            return index
    return missing[0] if wrap and missing else None


def merge_barcodes(
    row: Mapping[str, Any],
    codes: Iterable[Any],
    *,
    warnings: Iterable[Any] = (),
) -> dict[str, Any]:
    result = dict(row)
    merged = list(row_barcodes(result))
    for value in codes:
        code = text(value)
        if code and code not in merged:
            merged.append(code)
    result["barcodes"] = merged
    result["barcode_cell"] = ", ".join(merged)
    warning_text = "; ".join(text(value) for value in warnings if text(value))
    if warning_text:
        result["barcode_warning"] = warning_text
    else:
        result.pop("barcode_warning", None)
    return result


def with_shortage_comment(row: Mapping[str, Any]) -> dict[str, Any]:
    result = dict(row)
    if is_zero_quantity(result) and "недовоз" not in text(result.get("comment")).lower():
        result["comment"] = (text(result.get("comment")) + " Недовоз: фактическое количество 0.").strip()
    return result


def with_quantity(row: Mapping[str, Any], value: Any) -> dict[str, Any]:
    quantity = formatted_number(value)
    if float(quantity) < 0:
        raise ValueError("Кол-во не может быть отрицательным. 0 = полный недовоз.")
    result = dict(row)
    result["qty"] = quantity
    return with_shortage_comment(result)


def with_label_quantity(row: Mapping[str, Any], value: Any) -> dict[str, Any]:
    raw = text(value).replace(" ", "").replace(",", ".")
    if not raw or not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", raw):
        raise ValueError("Количество ценников должно быть целым числом от 0 и выше.")
    quantity = int(round(float(raw)))
    if quantity < 0:
        raise ValueError("Количество ценников должно быть целым числом от 0 и выше.")
    result = dict(row)
    result["label_qty"] = quantity
    return result


@dataclass(frozen=True, slots=True)
class SemiAutoProgress:
    total: int
    done: int
    missing: int
    zero_quantity: int

    @property
    def percent(self) -> int:
        return int(round((self.done / self.total) * 100)) if self.total else 0

    @property
    def complete(self) -> bool:
        return bool(self.total) and self.missing == 0


def progress(rows: Sequence[Mapping[str, Any]]) -> SemiAutoProgress:
    total = len(rows)
    missing = len(missing_indices(rows))
    zero_quantity = sum(1 for row in rows if is_zero_quantity(row))
    return SemiAutoProgress(total=total, done=max(0, total - missing), missing=missing, zero_quantity=zero_quantity)


def existing_barcodes(rows: Sequence[Mapping[str, Any]]) -> set[str]:
    return {code for row in rows for code in row_barcodes(row) if code}


def normalized_internal_prefix(value: Any, default: str = "77") -> str:
    prefix = re.sub(r"\D+", "", text(value))[:11]
    return prefix or default


def next_internal_barcode(
    existing: Iterable[Any],
    *,
    prefix: Any = "77",
    start_counter: Any = 1,
) -> tuple[str, int] | None:
    used = {text(value) for value in existing if text(value)}
    normalized_prefix = normalized_internal_prefix(prefix)
    counter_digits = 12 - len(normalized_prefix)
    start = max(1, int(number_float(start_counter, 1.0)))
    for counter in range(start, 10 ** max(1, counter_digits)):
        base = normalized_prefix + str(counter).zfill(counter_digits)
        code = base + str(ean_checksum(base))
        if code not in used:
            return code, counter
    return None
