#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Explicit state machine for receipt processing."""
from __future__ import annotations

from dataclasses import dataclass

from .models import ReceiptStage, stage_value
from .node_graph import NodeEdge, NodeGraph, NodeSpec


class InvalidStageTransition(ValueError):
    pass


_ALLOWED: dict[str, frozenset[str]] = {
    ReceiptStage.AI_REVIEW.value: frozenset({
        ReceiptStage.AI_REVIEW.value,
        ReceiptStage.SEMI_AUTO.value,
        ReceiptStage.AUTOMATIC.value,
        ReceiptStage.IMPORT.value,
        ReceiptStage.COMPLETED.value,
    }),
    ReceiptStage.SEMI_AUTO.value: frozenset({
        ReceiptStage.SEMI_AUTO.value,
        ReceiptStage.AUTOMATIC.value,
        ReceiptStage.IMPORT.value,
        ReceiptStage.COMPLETED.value,
    }),
    ReceiptStage.AUTOMATIC.value: frozenset({
        # An operator can discover during the automatic check that a product
        # marked absent actually exists. Returning to barcode collection is a
        # correction of the same saved receipt, not a new workflow.
        ReceiptStage.SEMI_AUTO.value,
        ReceiptStage.AUTOMATIC.value,
        ReceiptStage.IMPORT.value,
        ReceiptStage.COMPLETED.value,
    }),
    ReceiptStage.MANUAL_ENTRY.value: frozenset({
        ReceiptStage.MANUAL_ENTRY.value,
        ReceiptStage.IMPORT.value,
        ReceiptStage.COMPLETED.value,
    }),
    ReceiptStage.IMPORT.value: frozenset({
        ReceiptStage.SEMI_AUTO.value,
        ReceiptStage.AUTOMATIC.value,
        ReceiptStage.IMPORT.value,
        ReceiptStage.COMPLETED.value,
    }),
    ReceiptStage.COMPLETED.value: frozenset({ReceiptStage.COMPLETED.value}),
}


RECEIPT_NODE_GRAPH = NodeGraph.build(
    graph_id="receipt",
    nodes=(
        NodeSpec(stage.value, stage.name.replace("_", " ").title(), kind="stage")
        for stage in ReceiptStage
    ),
    edges=(
        NodeEdge(source, target)
        for source, targets in _ALLOWED.items()
        for target in targets
    ),
    entry=ReceiptStage.AI_REVIEW.value,
)


@dataclass(frozen=True, slots=True)
class ReceiptWorkflow:
    current: str

    @classmethod
    def at(cls, stage: ReceiptStage | str) -> "ReceiptWorkflow":
        return cls(stage_value(stage))

    def can_move_to(self, target: ReceiptStage | str) -> bool:
        target_value = stage_value(target)
        # Unknown legacy/custom stages remain permissive during migration.
        if self.current not in _ALLOWED or target_value not in _ALLOWED:
            return True
        return RECEIPT_NODE_GRAPH.can_transition(self.current, target_value)

    def move_to(self, target: ReceiptStage | str) -> "ReceiptWorkflow":
        target_value = stage_value(target)
        if not self.can_move_to(target_value):
            raise InvalidStageTransition(f"Недопустимый переход привоза: {self.current} → {target_value}")
        return ReceiptWorkflow(target_value)
