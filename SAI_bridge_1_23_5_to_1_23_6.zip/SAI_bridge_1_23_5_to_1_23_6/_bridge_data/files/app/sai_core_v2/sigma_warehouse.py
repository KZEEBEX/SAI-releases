#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Persistent SIGMA stock snapshots and item-level sales."""
from __future__ import annotations

import datetime as dt
import json
import sqlite3
from decimal import Decimal
from typing import Any

from .migrations import Migration
from .product_events import ProductEvent, record_product_event


_GENERIC_SALE_NAMES = (
    "УБОРКАИХРАНЕНИЕ", "КУХОННЫЕПРИНАДЛЕЖНОСТИ", "ЭЛЕКТРИКА",
    "ИНСТРУМЕНТЫ", "САДОГОРОД", "ГАЛАНТЕРЕЯ", "СКОБЯНЫЕИЗДЕЛИЯ",
    "БЫТОВАЯХИМИЯ", "САНТЕХНИКА", "ЛАКОКРАСОЧНЫЕМАТЕРИАЛЫ",
    "ЛАКОКРАСОЧНЫЕМАТЕРИАЛЛЫ",
)


def analytic_product_name_condition(name: str) -> str:
    """Trusted SQL fragment excluding generic departments and weight counters."""
    compact = (
        f"REPLACE(REPLACE(REPLACE(UPPER(TRIM({name})), ' ', ''), '-', ''), 'Ё', 'Е')"
    )
    variants = (
        *_GENERIC_SALE_NAMES,
        *(value.lower() for value in _GENERIC_SALE_NAMES),
        *(value.capitalize() for value in _GENERIC_SALE_NAMES),
    )
    names = ",".join(f"'{value}'" for value in variants)
    return (
        f"{name} NOT LIKE '%/грамм%' AND {name} NOT LIKE '%/Грамм%' "
        f"AND {name} NOT LIKE '%/ГРАММ%' "
        f"AND {compact} NOT IN ({names})"
    )


def analytic_quantity_condition(alias: str = "") -> str:
    """Trusted SQL fragment for quantities that represent real product units."""
    prefix = f"{alias}." if alias else ""
    name = f"{prefix}product_name"
    product_id = f"{prefix}sai_product_id"
    quantity = f"{prefix}quantity"
    bulk_fastener = (
        f"(({name} LIKE '%Саморез%' OR {name} LIKE '%САМОРЕЗ%' "
        f"OR {name} LIKE '%Гвозд%' OR {name} LIKE '%ГВОЗД%' "
        f"OR {name} LIKE '%Прессшайб%' OR {name} LIKE '%ПРЕССШАЙБ%') "
        f"AND ABS(CAST({quantity} AS REAL))>=50)"
    )
    return (
        f"{product_id} IS NOT NULL AND COALESCE({product_id}, '')<>'' "
        f"AND {analytic_product_name_condition(name)} AND NOT {bulk_fastener}"
    )


def _now() -> str:
    return dt.datetime.now().astimezone().isoformat()


def _value_text(value: Any) -> str:
    if isinstance(value, dict):
        value = value.get("value", value.get("amount", value.get("total", 0)))
    return str(0 if value in (None, "") else value)


def _create_sigma_warehouse_schema(con: sqlite3.Connection) -> None:
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS sigma_stock_current (
            sai_product_id TEXT NOT NULL,
            location_id TEXT NOT NULL,
            sigma_product_id TEXT NOT NULL,
            quantity TEXT NOT NULL,
            buying_price TEXT,
            selling_price TEXT,
            reliable INTEGER NOT NULL DEFAULT 0,
            captured_at TEXT NOT NULL,
            PRIMARY KEY (sai_product_id, location_id),
            FOREIGN KEY(sai_product_id) REFERENCES product_identities(sai_product_id),
            FOREIGN KEY(location_id) REFERENCES stock_locations(location_id)
        );
        CREATE INDEX IF NOT EXISTS idx_sigma_stock_captured
            ON sigma_stock_current(location_id, captured_at DESC);

        CREATE TABLE IF NOT EXISTS sigma_sale_operations (
            operation_id TEXT PRIMARY KEY,
            operation_time TEXT NOT NULL,
            operation_type TEXT NOT NULL,
            check_number TEXT,
            cashier_name TEXT,
            sell_point_id TEXT,
            imported_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sigma_sale_operation_time
            ON sigma_sale_operations(operation_time DESC);

        CREATE TABLE IF NOT EXISTS sigma_sale_lines (
            line_key TEXT PRIMARY KEY,
            operation_id TEXT NOT NULL,
            line_number INTEGER NOT NULL,
            sai_product_id TEXT,
            sigma_line_product_id TEXT,
            product_name TEXT NOT NULL,
            quantity TEXT NOT NULL,
            unit_price TEXT,
            line_total TEXT,
            direction TEXT NOT NULL,
            operation_time TEXT NOT NULL,
            imported_at TEXT NOT NULL,
            FOREIGN KEY(operation_id) REFERENCES sigma_sale_operations(operation_id),
            FOREIGN KEY(sai_product_id) REFERENCES product_identities(sai_product_id)
        );
        CREATE INDEX IF NOT EXISTS idx_sigma_sale_line_product
            ON sigma_sale_lines(sai_product_id, operation_time DESC);
        CREATE INDEX IF NOT EXISTS idx_sigma_sale_line_operation
            ON sigma_sale_lines(operation_id, line_number);
        """
    )


def _add_column(con: sqlite3.Connection, table: str, definition: str) -> None:
    column = definition.split()[0]
    existing = {str(row[1]) for row in con.execute(f"PRAGMA table_info({table})")}
    if column not in existing:
        con.execute(f"ALTER TABLE {table} ADD COLUMN {definition}")


def _create_sigma_analytics_schema(con: sqlite3.Connection) -> None:
    _create_sigma_warehouse_schema(con)
    for definition in (
        "settlement_type TEXT",
        "trading_type TEXT",
        "payment_method TEXT",
        "gross_total TEXT",
        "discount_total TEXT",
        "raw_json TEXT",
        "details_loaded INTEGER NOT NULL DEFAULT 0",
    ):
        _add_column(con, "sigma_sale_operations", definition)
    _add_column(con, "sigma_sale_lines", "raw_json TEXT")
    con.executescript(
        """
        CREATE TABLE IF NOT EXISTS sigma_history_periods (
            source TEXT NOT NULL,
            period_start TEXT NOT NULL,
            period_end TEXT NOT NULL,
            status TEXT NOT NULL,
            records_count INTEGER NOT NULL DEFAULT 0,
            detail_errors INTEGER NOT NULL DEFAULT 0,
            attempts INTEGER NOT NULL DEFAULT 0,
            error TEXT,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(source, period_start, period_end)
        );
        CREATE INDEX IF NOT EXISTS idx_sigma_history_status
            ON sigma_history_periods(source, status, period_start);

        CREATE TABLE IF NOT EXISTS sigma_shifts (
            shift_id TEXT PRIMARY KEY,
            device_id TEXT,
            sell_point_id TEXT,
            shift_number TEXT,
            opened_at TEXT,
            closed_at TEXT,
            cashier_name TEXT,
            register_name TEXT,
            total TEXT,
            receipts_total TEXT,
            cash_payments TEXT,
            card_payments TEXT,
            cash_in_total TEXT,
            collections_total TEXT,
            raw_json TEXT NOT NULL,
            imported_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sigma_shifts_opened
            ON sigma_shifts(opened_at DESC);

        CREATE TABLE IF NOT EXISTS sigma_cash_operations (
            operation_id TEXT PRIMARY KEY,
            device_id TEXT,
            operation_type TEXT,
            occurred_at TEXT,
            cashier_name TEXT,
            amount TEXT,
            comment TEXT,
            raw_json TEXT NOT NULL,
            imported_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sigma_cash_operations_date
            ON sigma_cash_operations(occurred_at DESC);

        CREATE TABLE IF NOT EXISTS sigma_daily_metrics (
            metric_date TEXT NOT NULL,
            location_id TEXT NOT NULL,
            gross_revenue TEXT NOT NULL DEFAULT '0',
            returns_total TEXT NOT NULL DEFAULT '0',
            net_revenue TEXT NOT NULL DEFAULT '0',
            discount_total TEXT NOT NULL DEFAULT '0',
            receipt_count INTEGER NOT NULL DEFAULT 0,
            return_count INTEGER NOT NULL DEFAULT 0,
            units_sold TEXT NOT NULL DEFAULT '0',
            units_returned TEXT NOT NULL DEFAULT '0',
            average_check TEXT NOT NULL DEFAULT '0',
            cash_total TEXT NOT NULL DEFAULT '0',
            card_total TEXT NOT NULL DEFAULT '0',
            updated_at TEXT NOT NULL,
            PRIMARY KEY(metric_date, location_id)
        );
        """
    )


def ensure_sigma_warehouse_schema(con: sqlite3.Connection) -> None:
    """Prepare snapshot tables for direct service and legacy DB callers."""
    _create_sigma_analytics_schema(con)


SIGMA_WAREHOUSE_MIGRATIONS = (
    Migration(9, "sigma_stock_snapshots_and_item_sales", _create_sigma_warehouse_schema),
    Migration(10, "sigma_2026_history_and_analytics_archive", _create_sigma_analytics_schema),
)


def save_stock_snapshot(
    con: sqlite3.Connection, *, sai_product_id: str, location_id: str,
    sigma_product_id: str, quantity: Decimal, buying_price: Decimal | None,
    selling_price: Decimal | None, reliable: bool, captured_at: str,
    product_created_at: str = "",
) -> bool:
    previous = con.execute(
        """SELECT quantity FROM sigma_stock_current
           WHERE sai_product_id=? AND location_id=?""",
        (sai_product_id, location_id),
    ).fetchone()
    changed = previous is None or Decimal(str(previous[0])) != quantity
    con.execute(
        """INSERT INTO sigma_stock_current(
               sai_product_id, location_id, sigma_product_id, quantity,
               buying_price, selling_price, reliable, captured_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(sai_product_id, location_id) DO UPDATE SET
               sigma_product_id=excluded.sigma_product_id,
               quantity=excluded.quantity,
               buying_price=excluded.buying_price,
               selling_price=excluded.selling_price,
               reliable=excluded.reliable,
               captured_at=excluded.captured_at""",
        (
            sai_product_id, location_id, sigma_product_id, str(quantity),
            None if buying_price is None else str(buying_price),
            None if selling_price is None else str(selling_price),
            int(bool(reliable)), captured_at,
        ),
    )
    if changed:
        record_product_event(con, ProductEvent(
            idempotency_key=(
                f"sigma-stock:{location_id}:{sigma_product_id}:"
                f"{captured_at}:{quantity}"
            ),
            sai_product_id=sai_product_id,
            event_type="stock_snapshot",
            source_system="sigma_stock",
            occurred_at=captured_at,
            selling_price=selling_price,
            unit_cost=buying_price,
            location_id=location_id,
            note=f"Остаток SIGMA: {quantity}",
            metadata={"actual_balance": str(quantity), "reliable": bool(reliable)},
        ))
    if str(product_created_at or "").strip():
        record_product_event(con, ProductEvent(
            idempotency_key=f"sigma-product-created:{sigma_product_id}",
            sai_product_id=sai_product_id,
            event_type="product_created",
            source_system="sigma_catalog",
            occurred_at=str(product_created_at),
            note="Карточка товара появилась в SIGMA",
            metadata={"sigma_product_id": sigma_product_id},
        ))
    return changed


def save_sale_operation(
    con: sqlite3.Connection, *, operation: dict[str, Any],
    lines: list[dict[str, Any]], location_id: str,
) -> tuple[int, int]:
    operation_id = str(operation.get("id") or "").strip()
    if not operation_id:
        return 0, 0
    exists = con.execute(
        "SELECT 1 FROM sigma_sale_operations WHERE operation_id=?", (operation_id,)
    ).fetchone()
    raw_json = json.dumps(operation, ensure_ascii=False, separators=(",", ":"), default=str)
    if exists:
        con.execute(
            """UPDATE sigma_sale_operations SET
                   settlement_type=?, trading_type=?, payment_method=?,
                   gross_total=?, discount_total=?, raw_json=?
               WHERE operation_id=?""",
            (
                str(operation.get("settlementType") or ""),
                str(operation.get("tradingType") or ""),
                str(operation.get("paymentScriptMethod") or operation.get("method") or ""),
                _value_text(operation.get("sum") or operation.get("total")),
                _value_text(operation.get("discount") or operation.get("totalDiscount")),
                raw_json, operation_id,
            ),
        )
        for index, line in enumerate(lines):
            product_id = str(line.get("sai_product_id") or "")
            con.execute(
                """UPDATE sigma_sale_lines SET
                       sai_product_id=COALESCE(NULLIF(?, ''), sai_product_id),
                       sigma_line_product_id=COALESCE(NULLIF(?, ''), sigma_line_product_id),
                       raw_json=COALESCE(NULLIF(?, ''), raw_json)
                   WHERE line_key=?""",
                (
                    product_id, str(line.get("external_id") or ""),
                    json.dumps(line, ensure_ascii=False, separators=(",", ":"), default=str),
                    f"{operation_id}:{index}",
                ),
            )
        return 0, 0
    occurred_at = str(
        operation.get("date") or operation.get("operationTime")
        or operation.get("createdDate") or _now()
    )
    operation_type = str(
        operation.get("transactionType") or operation.get("type") or "Payment"
    )
    direction = "return" if operation_type.lower() in {"refund", "return"} else "sale"
    con.execute(
        """INSERT INTO sigma_sale_operations(
               operation_id, operation_time, operation_type, check_number,
               cashier_name, sell_point_id, imported_at, settlement_type,
               trading_type, payment_method, gross_total, discount_total,
               raw_json, details_loaded)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)""",
        (
            operation_id, occurred_at, operation_type,
            str(operation.get("number") or ""),
            str((operation.get("cashier") or {}).get("name") or operation.get("cashierName") or ""),
            str(operation.get("sellPointId") or ""), _now(),
            str(operation.get("settlementType") or ""),
            str(operation.get("tradingType") or ""),
            str(operation.get("paymentScriptMethod") or operation.get("method") or ""),
            _value_text(operation.get("sum") or operation.get("total")),
            _value_text(operation.get("discount") or operation.get("totalDiscount")),
            raw_json,
        ),
    )
    linked = 0
    unlinked = 0
    for index, line in enumerate(lines):
        quantity = abs(Decimal(str(line.get("quantity") or 0)))
        price_value = line.get("unit_price")
        price = None if price_value in (None, "") else Decimal(str(price_value))
        delta = quantity if direction == "return" else -quantity
        product_id = str(line.get("sai_product_id") or "")
        line_key = f"{operation_id}:{index}"
        con.execute(
                """INSERT INTO sigma_sale_lines(
                   line_key, operation_id, line_number, sai_product_id,
                   sigma_line_product_id, product_name, quantity, unit_price,
                   line_total, direction, operation_time, imported_at, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                line_key, operation_id, index, product_id or None,
                str(line.get("external_id") or ""), str(line.get("name") or ""),
                str(quantity), None if price is None else str(price),
                None if price is None else str(price * quantity),
                direction, occurred_at, _now(),
                json.dumps(line, ensure_ascii=False, separators=(",", ":"), default=str),
            ),
        )
        if not product_id:
            unlinked += 1
            continue
        record_product_event(con, ProductEvent(
            idempotency_key=f"sigma-sale:{line_key}",
            sai_product_id=product_id,
            event_type=direction,
            quantity_delta=delta,
            selling_price=price,
            location_id=location_id,
            source_system="sigma_sales",
            source_document_id=operation_id,
            occurred_at=occurred_at,
            note=(
                f"Чек {str(operation.get('number') or operation_id)[:24]}"
                + (f" · {str((operation.get('cashier') or {}).get('name') or '')}" if (operation.get("cashier") or {}).get("name") else "")
            ),
            metadata={
                "line_number": index,
                "external_line_product_id": str(line.get("external_id") or ""),
                "name_at_event": str(line.get("name") or ""),
            },
        ))
        linked += 1
    return linked, unlinked


def enrich_sale_operation(
    con: sqlite3.Connection, operation_id: str, products: list[dict[str, Any]],
) -> int:
    """Add prices to previously staged sale lines without duplicating quantities."""
    rows = con.execute(
        """SELECT line_key, line_number, product_name, quantity
           FROM sigma_sale_lines WHERE operation_id=? ORDER BY line_number""",
        (operation_id,),
    ).fetchall()
    by_name: dict[str, list[dict[str, Any]]] = {}
    for product in products:
        if isinstance(product, dict):
            key = " ".join(str(product.get("name") or "").upper().replace("Ё", "Е").split())
            by_name.setdefault(key, []).append(product)
    changed = 0
    for line_key, line_number, product_name, quantity in rows:
        key = " ".join(str(product_name or "").upper().replace("Ё", "Е").split())
        matches = by_name.get(key) or []
        product = matches.pop(0) if matches else (
            products[int(line_number)] if int(line_number) < len(products) else {}
        )
        price_data = product.get("salePrice") if isinstance(product, dict) and isinstance(product.get("salePrice"), dict) else {}
        value = price_data.get("value")
        if value in (None, ""):
            continue
        price = Decimal(str(value))
        con.execute(
            """UPDATE sigma_sale_lines SET unit_price=?, line_total=?, raw_json=?
               WHERE line_key=?""",
            (
                str(price), str(price * Decimal(str(quantity or 0))),
                json.dumps(product, ensure_ascii=False, separators=(",", ":"), default=str),
                str(line_key),
            ),
        )
        changed += 1
    remaining = con.execute(
        "SELECT COUNT(*) FROM sigma_sale_lines WHERE operation_id=? AND unit_price IS NULL",
        (operation_id,),
    ).fetchone()[0]
    con.execute(
        "UPDATE sigma_sale_operations SET details_loaded=? WHERE operation_id=?",
        (int(int(remaining or 0) == 0), operation_id),
    )
    return changed


def history_period_loaded(status: str, detail_errors: int = 0, error: str = "") -> bool:
    """Older builds used partial for successful periods that need a later reread.

    Failed detail loads have a positive detail_errors count; request failures
    have status=error. Interpret legacy successful partials without rewriting
    history or treating genuine failures as complete.
    """
    return status in {"complete", "partial"} and int(detail_errors or 0) == 0 and not str(error or "").strip()


def history_period_status(
    con: sqlite3.Connection, source: str, period_start: str, period_end: str,
) -> str:
    row = con.execute(
        """SELECT status, detail_errors, error FROM sigma_history_periods
           WHERE source=? AND period_start=? AND period_end=?""",
        (source, period_start, period_end),
    ).fetchone()
    if row is None:
        return ""
    return "complete" if history_period_loaded(str(row[0]), row[1], row[2]) else str(row[0] or "")


def save_history_period(
    con: sqlite3.Connection, *, source: str, period_start: str, period_end: str,
    status: str, records_count: int = 0, detail_errors: int = 0, error: str = "",
) -> None:
    con.execute(
        """INSERT INTO sigma_history_periods(
               source, period_start, period_end, status, records_count,
               detail_errors, attempts, error, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
           ON CONFLICT(source, period_start, period_end) DO UPDATE SET
               status=excluded.status,
               records_count=excluded.records_count,
               detail_errors=excluded.detail_errors,
               attempts=sigma_history_periods.attempts + 1,
               error=excluded.error,
               updated_at=excluded.updated_at""",
        (
            source, period_start, period_end, status, int(records_count),
            int(detail_errors), str(error or ""), _now(),
        ),
    )


def save_shift(con: sqlite3.Connection, shift: dict[str, Any], sell_point_id: str = "") -> bool:
    shift_id = str(shift.get("id") or "").strip()
    if not shift_id:
        return False
    before = con.total_changes
    con.execute(
        """INSERT INTO sigma_shifts(
               shift_id, device_id, sell_point_id, shift_number, opened_at,
               closed_at, cashier_name, register_name, total, receipts_total,
               cash_payments, card_payments, cash_in_total, collections_total,
               raw_json, imported_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(shift_id) DO UPDATE SET
               closed_at=excluded.closed_at,
               total=excluded.total,
               receipts_total=excluded.receipts_total,
               cash_payments=excluded.cash_payments,
               card_payments=excluded.card_payments,
               cash_in_total=excluded.cash_in_total,
               collections_total=excluded.collections_total,
               raw_json=excluded.raw_json,
               imported_at=excluded.imported_at""",
        (
            shift_id, str(shift.get("deviceId") or ""),
            str(shift.get("sellPointId") or sell_point_id or ""),
            str(shift.get("number") or ""), str(shift.get("openTime") or ""),
            str(shift.get("closeTime") or ""), str(shift.get("cashierName") or ""),
            str(shift.get("registerName") or ""), _value_text(shift.get("total")),
            _value_text(shift.get("receiptsTotal")), _value_text(shift.get("cashPayments")),
            _value_text(shift.get("cardPayments")), _value_text(shift.get("cashInTotal")),
            _value_text(shift.get("collectionsTotal")),
            json.dumps(shift, ensure_ascii=False, separators=(",", ":"), default=str),
            _now(),
        ),
    )
    return con.total_changes > before


def save_cash_operation(
    con: sqlite3.Connection, operation: dict[str, Any], device_id: str = "",
) -> bool:
    operation_id = str(operation.get("id") or "").strip()
    if not operation_id:
        return False
    before = con.total_changes
    con.execute(
        """INSERT INTO sigma_cash_operations(
               operation_id, device_id, operation_type, occurred_at,
               cashier_name, amount, comment, raw_json, imported_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(operation_id) DO UPDATE SET
               operation_type=excluded.operation_type,
               occurred_at=excluded.occurred_at,
               cashier_name=excluded.cashier_name,
               amount=excluded.amount,
               comment=excluded.comment,
               raw_json=excluded.raw_json,
               imported_at=excluded.imported_at""",
        (
            operation_id, str(operation.get("deviceId") or device_id or ""),
            str(operation.get("operationType") or ""), str(operation.get("date") or ""),
            str(operation.get("cashierName") or ""),
            _value_text(operation.get("operationAmount") or operation.get("operationSummary")),
            str(operation.get("comment") or ""),
            json.dumps(operation, ensure_ascii=False, separators=(",", ":"), default=str),
            _now(),
        ),
    )
    return con.total_changes > before


def rebuild_daily_metrics(con: sqlite3.Connection, location_id: str, begin_date: str = "2026-01-01") -> int:
    con.execute(
        "DELETE FROM sigma_daily_metrics WHERE location_id=? AND metric_date>=?",
        (location_id, begin_date),
    )
    days = {
        str(row[0]) for row in con.execute(
            """SELECT DISTINCT substr(operation_time, 1, 10)
               FROM sigma_sale_operations WHERE operation_time>=?""",
            (begin_date,),
        ) if row[0]
    }
    for day in sorted(days):
        operations = con.execute(
            """SELECT operation_id, operation_type, payment_method,
                      CAST(COALESCE(gross_total, '0') AS REAL),
                      CAST(COALESCE(discount_total, '0') AS REAL)
               FROM sigma_sale_operations WHERE substr(operation_time, 1, 10)=?""",
            (day,),
        ).fetchall()
        gross = Decimal("0")
        returns = Decimal("0")
        discounts = Decimal("0")
        receipts = 0
        return_count = 0
        cash_total = Decimal("0")
        card_total = Decimal("0")
        for _op_id, op_type, method, total, discount in operations:
            value = Decimal(str(total or 0))
            is_return = str(op_type or "").lower() in {"refund", "return"}
            if is_return:
                returns += abs(value)
                return_count += 1
            else:
                gross += value
                receipts += 1
                payment = str(method or "").lower()
                if "cash" in payment or "нал" in payment:
                    cash_total += value
                elif "card" in payment or "карт" in payment:
                    card_total += value
            discounts += abs(Decimal(str(discount or 0)))
        quantity_filter = analytic_quantity_condition()
        unit_row = con.execute(
            f"""SELECT
                   COALESCE(SUM(CASE WHEN direction='sale' AND {quantity_filter}
                                     THEN CAST(quantity AS REAL) ELSE 0 END), 0),
                   COALESCE(SUM(CASE WHEN direction='return' AND {quantity_filter}
                                     THEN CAST(quantity AS REAL) ELSE 0 END), 0)
               FROM sigma_sale_lines WHERE substr(operation_time, 1, 10)=?""",
            (day,),
        ).fetchone()
        units_sold = Decimal(str(unit_row[0] or 0))
        units_returned = Decimal(str(unit_row[1] or 0))
        net = gross - returns
        average = net / receipts if receipts else Decimal("0")
        con.execute(
            """INSERT INTO sigma_daily_metrics(
                   metric_date, location_id, gross_revenue, returns_total,
                   net_revenue, discount_total, receipt_count, return_count,
                   units_sold, units_returned, average_check, cash_total,
                   card_total, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                day, location_id, str(gross), str(returns), str(net), str(discounts),
                receipts, return_count, str(units_sold), str(units_returned),
                str(average), str(cash_total), str(card_total), _now(),
            ),
        )
    return len(days)


def analytics_archive_stats(con: sqlite3.Connection) -> dict[str, Any]:
    first, last, operations = con.execute(
        """SELECT MIN(operation_time), MAX(operation_time), COUNT(*)
           FROM sigma_sale_operations"""
    ).fetchone()
    return {
        "first_sale": str(first or ""),
        "last_sale": str(last or ""),
        "sale_operations": int(operations or 0),
        "sale_lines": int(con.execute("SELECT COUNT(*) FROM sigma_sale_lines").fetchone()[0]),
        "shifts": int(con.execute("SELECT COUNT(*) FROM sigma_shifts").fetchone()[0]),
        "cash_operations": int(con.execute("SELECT COUNT(*) FROM sigma_cash_operations").fetchone()[0]),
        "days": int(con.execute("SELECT COUNT(*) FROM sigma_daily_metrics").fetchone()[0]),
        "unpriced_lines": int(con.execute(
            "SELECT COUNT(*) FROM sigma_sale_lines WHERE unit_price IS NULL"
        ).fetchone()[0]),
        "unlinked_lines": int(con.execute(
            "SELECT COUNT(*) FROM sigma_sale_lines WHERE sai_product_id IS NULL"
        ).fetchone()[0]),
    }


def actual_balances(con: sqlite3.Connection, location_id: str) -> dict[str, Decimal]:
    result: dict[str, Decimal] = {}
    rows = con.execute(
        """SELECT s.sai_product_id, s.quantity,
                  COALESCE((SELECT SUM(CAST(m.quantity_delta AS REAL))
                            FROM stock_movements m
                            WHERE m.sai_product_id=s.sai_product_id
                              AND m.location_id=s.location_id
                              AND m.occurred_at>s.captured_at), 0)
           FROM sigma_stock_current s WHERE s.location_id=?""",
        (location_id,),
    )
    for product_id, snapshot, later_local_delta in rows:
        result[str(product_id)] = Decimal(str(snapshot)) + Decimal(str(later_local_delta or 0))
    return result


def product_summary(con: sqlite3.Connection, sai_product_id: str, location_id: str) -> dict[str, Any]:
    stock = con.execute(
        """SELECT quantity, captured_at, buying_price, selling_price, reliable
           FROM sigma_stock_current WHERE sai_product_id=? AND location_id=?""",
        (sai_product_id, location_id),
    ).fetchone()
    rows = con.execute(
        """SELECT event_type, quantity_delta, selling_price, occurred_at
           FROM product_events WHERE sai_product_id=? AND event_type='receipt'""",
        (sai_product_id,),
    ).fetchall()
    now = dt.datetime.now().astimezone()
    sold_7 = Decimal("0")
    sold_30 = Decimal("0")
    revenue_30 = Decimal("0")
    last_receipt = ""
    for event_type, quantity_delta, selling_price, occurred_at in rows:
        try:
            moment = dt.datetime.fromisoformat(str(occurred_at).replace("Z", "+00:00"))
            if moment.tzinfo is None:
                moment = moment.astimezone()
            age = now - moment.astimezone(now.tzinfo)
        except Exception:
            age = dt.timedelta.max
        qty = Decimal(str(quantity_delta or 0))
        if str(event_type) == "receipt" and (not last_receipt or str(occurred_at) > last_receipt):
            last_receipt = str(occurred_at)
    sale_rows = con.execute(
        f"""SELECT direction, quantity, unit_price, operation_time
            FROM sigma_sale_lines
            WHERE sai_product_id=? AND {analytic_quantity_condition()}""",
        (sai_product_id,),
    ).fetchall()
    for direction, quantity, unit_price, occurred_at in sale_rows:
        try:
            moment = dt.datetime.fromisoformat(str(occurred_at).replace("Z", "+00:00"))
            if moment.tzinfo is None:
                moment = moment.astimezone()
            age = now - moment.astimezone(now.tzinfo)
        except Exception:
            continue
        units = Decimal(str(quantity or 0))
        sign = Decimal("-1") if str(direction) == "return" else Decimal("1")
        if age <= dt.timedelta(days=7):
            sold_7 += sign * units
        if age <= dt.timedelta(days=30):
            sold_30 += sign * units
            revenue_30 += sign * units * Decimal(str(unit_price or 0))
    current = actual_balances(con, location_id).get(sai_product_id)
    return {
        "actual_balance": current,
        "captured_at": "" if stock is None else str(stock[1]),
        "buying_price": None if stock is None or stock[2] is None else Decimal(str(stock[2])),
        "selling_price": None if stock is None or stock[3] is None else Decimal(str(stock[3])),
        "reliable": False if stock is None else bool(stock[4]),
        "sold_7": sold_7,
        "sold_30": sold_30,
        "revenue_30": revenue_30,
        "last_receipt": last_receipt,
    }
