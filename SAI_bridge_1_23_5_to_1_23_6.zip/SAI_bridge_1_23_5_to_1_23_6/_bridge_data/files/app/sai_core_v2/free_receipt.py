#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Qt-independent rules for the free/manual receipt catalog card.

The widget owns focus, dialogs and painting.  This module owns deterministic
search scoring, barcode merging/generation rules, category extraction and price
forecasting so desktop, mobile and future import clients behave identically.
"""
from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from .manual_receipt import money_float, price_text, round_sale_from_purchase, text


BARCODE_LIMIT = 8


def normalized_internal_prefix(value: Any = "7700") -> str:
    """Keep legacy ``77`` settings inside SAI's narrower ``7700…`` namespace."""
    prefix = barcode_digits(value)[:11] or "7700"
    return "7700" if prefix == "77" else prefix


def normalize_search_text(value: Any) -> str:
    raw: Any = value
    try:
        import sai_product_names
        raw = sai_product_names.searchable_text(value)
    except Exception:
        pass
    raw = text(raw).upper().replace("Ё", "Е")
    raw = re.sub(r"[^0-9A-ZА-Я]+", " ", raw)
    return re.sub(r"\s+", " ", raw).strip()


def search_tokens(value: Any) -> tuple[str, ...]:
    return tuple(token for token in normalize_search_text(value).split() if token)


_NAME_MATCH_NOISE = {
    "Д", "ДЛЯ", "И", "ИЛИ", "В", "ВО", "НА", "С", "СО", "ПО", "ПОД", "ШТ", "ШТУКА",
    "ШТУК", "ММ", "СМ", "М", "КМ", "МЛ", "Л", "Г", "КГ", "МГ", "ВТ", "КВТ", "В",
    "А", "МА", "УП", "УПАК", "УПАКОВКА", "КОМПЛ", "КОМПЛЕКТ", "РУЛ", "РУЛОН",
}


def _meaningful_name_tokens(value: Any) -> tuple[str, ...]:
    return tuple(
        token for token in search_tokens(value)
        if len(token) >= 3
        and not token.isdigit()
        and token not in _NAME_MATCH_NOISE
        and not re.fullmatch(r"\d+(?:ММ|СМ|М|МЛ|Л|Г|КГ|МГ|ВТ|КВТ|В|А|МА)", token)
    )


def _technical_name_features(value: Any) -> set[str]:
    compact = normalize_search_text(value)
    compact = re.sub(r"(?<=\d)\s+(?=(?:ММ|СМ|М|МЛ|Л|Г|КГ|МГ|ВТ|КВТ|В|А|МА)\b)", "", compact)
    return set(re.findall(r"\d+(?:[.,]\d+)?(?:ММ|СМ|М|МЛ|Л|Г|КГ|МГ|ВТ|КВТ|В|А|МА)\b", compact))


def _name_token_matches(left: str, right: str) -> bool:
    if left == right:
        return True
    shorter, longer = sorted((left, right), key=len)
    return len(shorter) >= 3 and len(longer) >= 5 and longer.startswith(shorter)


def catalog_name_match_percent(source: Any, candidate: Any) -> int:
    """Conservative product-name similarity for barcode suggestions.

    Units and short technical fragments never create a match on their own.
    Numbers act as compatibility guards, so ``Лампа 10 Вт`` does not suggest
    ``Лампа 20 Вт`` merely because the generic word and unit coincide.
    """
    source_norm = normalize_search_text(source)
    candidate_norm = normalize_search_text(candidate)
    if not source_norm or not candidate_norm:
        return 0

    source_all_tokens = search_tokens(source)
    candidate_all_tokens = search_tokens(candidate)
    source_tokens = _meaningful_name_tokens(source)
    candidate_tokens = _meaningful_name_tokens(candidate)
    if not source_tokens or not candidate_tokens:
        return 0
    if source_norm == candidate_norm:
        return 100

    used: set[int] = set()
    shared: list[tuple[str, str]] = []
    for left in source_tokens:
        best = next(
            (index for index, right in enumerate(candidate_tokens) if index not in used and _name_token_matches(left, right)),
            None,
        )
        if best is not None:
            used.add(best)
            shared.append((left, candidate_tokens[best]))
    shared_weight = sum(max(len(left), len(right)) for left, right in shared)
    source_weight = sum(len(token) for token in source_tokens)
    candidate_weight = sum(len(token) for token in candidate_tokens)
    source_numbers = set(re.findall(r"\d+(?:[.,]\d+)?", source_norm))
    candidate_numbers = set(re.findall(r"\d+(?:[.,]\d+)?", candidate_norm))
    # Different numeric characteristics identify different products.  This is
    # deliberately a hard stop: 500/650 ml, 10/20 W and 1800/2160 package
    # markings must never be outweighed by otherwise similar words.
    if source_numbers and candidate_numbers and source_numbers != candidate_numbers:
        return 0
    shared_numbers = source_numbers & candidate_numbers
    source_units = set(source_all_tokens) & _NAME_MATCH_NOISE
    candidate_units = set(candidate_all_tokens) & _NAME_MATCH_NOISE
    shared_units = source_units & candidate_units
    shared_features = _technical_name_features(source) & _technical_name_features(candidate)
    strong_single = len(shared) == 1 and max(len(shared[0][0]), len(shared[0][1])) >= 7
    described_single = (
        len(shared) == 1
        and len(source_tokens) == len(candidate_tokens) == 1
        and bool(shared_numbers or shared_features)
        and bool(shared_units or shared_features)
    )
    if len(shared) < 2 and not strong_single and not described_single:
        return 0

    recall = shared_weight / max(1, source_weight)
    precision = shared_weight / max(1, candidate_weight)
    source_core = " ".join(source_tokens)
    candidate_core = " ".join(candidate_tokens)
    sequence = SequenceMatcher(None, source_core, candidate_core).ratio()
    score = 55 * min(1.0, recall) + 25 * min(1.0, precision) + 20 * sequence

    if described_single:
        score = max(score, 90)
    return max(0, min(99, int(round(score))))


def barcode_digits(value: Any) -> str:
    return re.sub(r"\D+", "", text(value))


def is_barcode_like_query(value: Any) -> bool:
    raw = text(value)
    digits = barcode_digits(raw)
    return bool(digits and len(digits) >= 5 and (digits == raw or len(digits) in (8, 12, 13, 14)))


def normalize_unit(value: Any) -> str:
    raw = text(value).lower().replace(".", " ").replace(",", " ").strip()
    compact = re.sub(r"[^0-9a-zа-яё]+", "", raw)
    if compact in {"кг", "kg", "kgs", "килограмм", "килограмма", "килограммов"}:
        return "кг"
    if compact in {"г", "гр", "g", "gr", "gram", "grams", "грамм", "грамма", "граммов"}:
        return "г"
    if compact in {"пара", "пары", "пар", "pair", "pairs"}:
        return "пара"
    if compact in {"шт", "штука", "штуки", "штук", "piece", "pieces", "pcs"}:
        return "штука"
    try:
        from sai_product_names import normalize_unit as shared_normalize_unit
        return shared_normalize_unit(value)
    except Exception:
        return raw or "штука"


def _decoded_json(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value


def category_name_from_raw(value: Any) -> str:
    obj = _decoded_json(value)
    if isinstance(obj, Mapping):
        for key in (
            "categoryName", "productCategoryName", "category", "groupName",
            "productGroupName", "assortmentGroupName", "parentCategoryName",
        ):
            got = obj.get(key)
            if isinstance(got, str) and got.strip():
                return text(got)
        for key in (
            "category", "productCategory", "product_category", "group",
            "productGroup", "assortmentGroup", "parentCategory",
        ):
            nested = obj.get(key)
            if isinstance(nested, Mapping):
                for name_key in ("name", "title", "displayName", "fullName"):
                    got = nested.get(name_key)
                    if isinstance(got, str) and got.strip():
                        return text(got)
        for nested in obj.values():
            got = category_name_from_raw(nested)
            if got:
                return got
    elif isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
        for nested in obj:
            got = category_name_from_raw(nested)
            if got:
                return got
    return ""


def category_id_from_raw(value: Any) -> str:
    obj = _decoded_json(value)
    if isinstance(obj, Mapping):
        for key in (
            "categoryId", "productCategoryId", "product_category_id", "groupId",
            "productGroupId", "assortmentGroupId",
        ):
            got = obj.get(key)
            if got:
                return text(got)
        for key in ("category", "productCategory", "product_category", "group", "productGroup", "assortmentGroup"):
            nested = obj.get(key)
            if isinstance(nested, Mapping):
                for id_key in ("id", "uuid", "categoryId"):
                    got = nested.get(id_key)
                    if got:
                        return text(got)
        for nested in obj.values():
            got = category_id_from_raw(nested)
            if got:
                return got
    elif isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
        for nested in obj:
            got = category_id_from_raw(nested)
            if got:
                return got
    return ""


def json_pick(value: Any, keys: Iterable[str], default: Any = "") -> Any:
    obj = _decoded_json(value)
    if not isinstance(obj, Mapping):
        return default
    for key in keys:
        if key in obj and obj.get(key) not in (None, ""):
            return obj.get(key)
    for nested in obj.values():
        if isinstance(nested, Mapping):
            got = json_pick(nested, keys, None)
            if got not in (None, ""):
                return got
    return default


def recursive_price(value: Any) -> float:
    obj = _decoded_json(value)
    price_keys = {
        "sellingCostPerUnit", "sellingCost", "sellingPrice", "productPrice",
        "retailPrice", "salePrice", "price", "cost", "value",
    }
    if isinstance(obj, Mapping):
        for key, got in obj.items():
            if key in price_keys:
                number = money_float(got)
                if number:
                    return number
        for nested in obj.values():
            number = recursive_price(nested)
            if number:
                return number
    elif isinstance(obj, Sequence) and not isinstance(obj, (str, bytes, bytearray)):
        for nested in obj:
            number = recursive_price(nested)
            if number:
                return number
    return 0.0


@dataclass(frozen=True, slots=True)
class BarcodeMergeResult:
    barcodes: tuple[str, ...]
    added: tuple[str, ...]
    rejected: tuple[str, ...]
    limit_reached: bool


def merge_barcodes(current: Iterable[Any], incoming: Iterable[Any], *, limit: int = BARCODE_LIMIT) -> BarcodeMergeResult:
    result: list[str] = []
    for value in current:
        code = text(value)
        if code and code not in result:
            result.append(code)
    added: list[str] = []
    rejected: list[str] = []
    limit_reached = False
    for value in incoming:
        for chunk in re.split(r"[\s,;]+", text(value)):
            code = chunk.strip()
            if not code or code in result:
                continue
            if len(result) >= max(1, int(limit)):
                rejected.append(code)
                limit_reached = True
                continue
            result.append(code)
            added.append(code)
    return BarcodeMergeResult(tuple(result), tuple(added), tuple(rejected), limit_reached)


def ean_checksum(base_digits: Any) -> int:
    digits = [int(ch) for ch in text(base_digits) if ch.isdigit()]
    total = 0
    for index, digit in enumerate(reversed(digits)):
        total += digit * (3 if index % 2 == 0 else 1)
    return (10 - (total % 10)) % 10


def internal_barcode(prefix: Any, counter: Any) -> str:
    normalized_prefix = normalized_internal_prefix(prefix)
    digits_for_counter = 12 - len(normalized_prefix)
    if digits_for_counter < 1:
        normalized_prefix = normalized_prefix[:11]
        digits_for_counter = 1
    number = max(1, int(money_float(counter)))
    base = normalized_prefix + str(number).zfill(digits_for_counter)
    return base + str(ean_checksum(base))


def next_internal_barcode(prefix: Any, start_counter: Any, existing: Iterable[Any]) -> tuple[str, int]:
    used = {text(value) for value in existing if text(value)}
    normalized_prefix = normalized_internal_prefix(prefix)
    digits_for_counter = max(1, 12 - len(normalized_prefix))
    first = max(1, int(money_float(start_counter)))
    for counter in range(first, 10 ** digits_for_counter):
        code = internal_barcode(normalized_prefix, counter)
        if code not in used:
            return code, counter
    raise RuntimeError("Не удалось подобрать свободный внутренний штрихкод.")


def internal_barcode_counter(value: Any, prefix: Any = "77") -> int | None:
    """Return the embedded counter only for a valid SAI EAN-13 code."""
    code = barcode_digits(value)
    normalized_prefix = normalized_internal_prefix(prefix)
    if len(code) != 13 or not code.startswith(normalized_prefix):
        return None
    base = code[:12]
    if int(code[-1]) != ean_checksum(base):
        return None
    counter_text = base[len(normalized_prefix):]
    if not counter_text:
        return None
    counter = int(counter_text)
    return counter if counter > 0 else None


def highest_internal_counter(values: Iterable[Any], prefix: Any = "77") -> int:
    counters = (
        internal_barcode_counter(value, prefix)
        for value in values
    )
    return max((counter for counter in counters if counter is not None), default=0)


@dataclass(frozen=True, slots=True)
class PriceForecast:
    purchase: float
    markup_percent: float
    sale: float
    old_sale: float
    uses_purchase: bool


def normalize_markup(value: Any, default: Any = 60.0) -> float:
    raw = money_float(value)
    if text(value) == "":
        raw = money_float(default)
    return max(0.0, raw)


def price_forecast(purchase: Any, markup_percent: Any, old_sale: Any = 0.0) -> PriceForecast:
    buy = money_float(purchase)
    markup = normalize_markup(markup_percent)
    old = money_float(old_sale)
    sale = round_sale_from_purchase(buy, markup) if buy > 0 else old
    return PriceForecast(buy, markup, sale, old, buy > 0)


def product_search_score(*, name: Any, barcodes: Iterable[Any], query: Any, barcode_mode: bool) -> tuple[int, bool]:
    raw_query = text(query)
    if barcode_mode:
        digit_query = barcode_digits(raw_query)
        if not digit_query:
            return 0, False
        score = 0
        exact = False
        for raw_barcode in barcodes:
            barcode_text = text(raw_barcode)
            digits = barcode_digits(barcode_text)
            if digits == digit_query:
                score = max(score, 220)
                exact = True
            elif digits.startswith(digit_query):
                score = max(score, 150 + min(40, len(digit_query) * 2))
            elif digit_query in digits:
                score = max(score, 95 + min(30, len(digit_query)))
            elif raw_query and raw_query.upper() in barcode_text.upper():
                score = max(score, 90)
        return score, exact

    normalized_name = normalize_search_text(name)
    if not normalized_name:
        return 0, False
    score = 0
    for token in search_tokens(raw_query):
        if normalized_name.startswith(token):
            score += 90
        elif f" {token}" in f" {normalized_name}":
            score += 55
        elif token in normalized_name:
            score += 30
        else:
            stem = token[:-1] if len(token) >= 5 else token
            score += 18 if stem and stem in normalized_name else -60
    if text(name).upper().startswith(raw_query.upper()):
        score += 25
    return max(0, score), False


__all__ = [
    "BARCODE_LIMIT", "BarcodeMergeResult", "PriceForecast", "barcode_digits",
    "category_id_from_raw", "category_name_from_raw", "ean_checksum",
    "highest_internal_counter", "internal_barcode", "internal_barcode_counter",
    "is_barcode_like_query", "json_pick", "merge_barcodes",
    "money_float", "next_internal_barcode", "normalize_markup", "normalize_search_text",
    "normalized_internal_prefix",
    "normalize_unit", "price_forecast", "price_text", "product_search_score",
    "recursive_price", "round_sale_from_purchase", "search_tokens", "text",
]
