#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Shared retail pricing policy for every SAI receipt route."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_HALF_UP
from typing import Any


LOW_RETAIL_THRESHOLD = Decimal("25")
# Compatibility alias for integrations that imported the previous name.
LOW_PURCHASE_THRESHOLD = LOW_RETAIL_THRESHOLD
RETAIL_PRICE_STEP = Decimal("5")


def _decimal(value: Any) -> Decimal:
    try:
        text = str(value or "").strip().replace("\xa0", "").replace(" ", "").replace("₽", "").replace(",", ".")
        result = Decimal(text) if text else Decimal("0")
        return result if result.is_finite() else Decimal("0")
    except (InvalidOperation, ValueError):
        return Decimal("0")


def sale_price_from_purchase(purchase: Any, markup_percent: Any) -> float:
    """Calculate a sale price using the shop's two-tier rounding rule.

    - calculated retail below 25 ₽: discard kopecks upward to a ruble;
    - calculated retail from 25 ₽: round to the nearest 0 or 5.
    """
    buy = _decimal(purchase)
    markup = max(Decimal("0"), _decimal(markup_percent))
    if buy <= 0:
        return 0.0
    calculated = buy * (Decimal("1") + markup / Decimal("100"))
    if calculated < LOW_RETAIL_THRESHOLD:
        rounded = calculated.to_integral_value(rounding=ROUND_CEILING)
    else:
        rounded = (
            calculated / RETAIL_PRICE_STEP
        ).to_integral_value(rounding=ROUND_HALF_UP) * RETAIL_PRICE_STEP
    return float(rounded)


__all__ = [
    "LOW_PURCHASE_THRESHOLD",
    "LOW_RETAIL_THRESHOLD",
    "RETAIL_PRICE_STEP",
    "sale_price_from_purchase",
]
