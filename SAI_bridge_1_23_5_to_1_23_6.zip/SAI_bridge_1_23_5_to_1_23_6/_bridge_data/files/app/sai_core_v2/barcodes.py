"""Pure barcode validation and rendering primitives, independent of Qt."""
from __future__ import annotations

import re
from typing import Any, Iterable

EAN_L = ("0001101", "0011001", "0010011", "0111101", "0100011", "0110001", "0101111", "0111011", "0110111", "0001011")
EAN_G = ("0100111", "0110011", "0011011", "0100001", "0011101", "0111001", "0000101", "0010001", "0001001", "0010111")
EAN_R = ("1110010", "1100110", "1101100", "1000010", "1011100", "1001110", "1010000", "1000100", "1001000", "1110100")
EAN13_PARITY = ("LLLLLL", "LLGLGG", "LLGGLG", "LLGGGL", "LGLLGG", "LGGLLG", "LGGGLL", "LGLGLG", "LGLGGL", "LGGLGL")
CODE128_PATTERNS = (
    "212222", "222122", "222221", "121223", "121322", "131222", "122213", "122312", "132212", "221213", "221312", "231212", "112232", "122132", "122231", "113222", "123122", "123221", "223211", "221132", "221231", "213212", "223112", "312131", "311222", "321122", "321221", "312212", "322112", "322211", "212123", "212321", "232121", "111323", "131123", "131321", "112313", "132113", "132311", "211313", "231113", "231311", "112133", "112331", "132131", "113123", "113321", "133121", "313121", "211331", "231131", "213113", "213311", "213131", "311123", "311321", "331121", "312113", "312311", "332111", "314111", "221411", "431111", "111224", "111422", "121124", "121421", "141122", "141221", "112214", "112412", "122114", "122411", "142112", "142211", "241211", "221114", "413111", "241112", "134111", "111242", "121142", "121241", "114212", "124112", "124211", "411212", "421112", "421211", "212141", "214121", "412121", "111143", "111341", "131141", "114113", "114311", "411113", "411311", "113141", "114131", "311141", "411131", "211412", "211214", "211232", "2331112",
)


def digits_only(value: Any) -> str:
    return "".join(ch for ch in str(value or "") if ch.isdigit())


def ean_checksum(base_digits: Any) -> int:
    digits = [int(ch) for ch in digits_only(base_digits)]
    total = sum(digit * (3 if index % 2 == 0 else 1) for index, digit in enumerate(reversed(digits)))
    return (10 - total % 10) % 10


def is_valid_ean(code: Any, size: int | None = None) -> bool:
    value = str(code or "").strip()
    expected = len(value) if size is None else int(size)
    return bool(value) and bool(re.fullmatch(rf"\d{{{expected}}}", value)) and int(value[-1]) == ean_checksum(value[:-1])


def ean13_modules(code: Any) -> str:
    value = str(code)
    if len(value) != 13 or not value.isdigit():
        raise ValueError("EAN-13 requires exactly 13 digits")
    parity = EAN13_PARITY[int(value[0])]
    left = "".join(EAN_L[int(d)] if kind == "L" else EAN_G[int(d)] for d, kind in zip(value[1:7], parity))
    right = "".join(EAN_R[int(d)] for d in value[7:])
    return "101" + left + "01010" + right + "101"


def ean8_modules(code: Any) -> str:
    value = str(code)
    if len(value) != 8 or not value.isdigit():
        raise ValueError("EAN-8 requires exactly 8 digits")
    return "101" + "".join(EAN_L[int(d)] for d in value[:4]) + "01010" + "".join(EAN_R[int(d)] for d in value[4:]) + "101"


def _code128_values_to_modules(values: Iterable[int]) -> str:
    modules: list[str] = []
    for value in values:
        black = True
        for width in CODE128_PATTERNS[value]:
            modules.append(("1" if black else "0") * int(width))
            black = not black
    return "".join(modules)


def code128b_modules(text: Any) -> str:
    values = [104]
    for char in str(text):
        ordinal = ord(char)
        if not 32 <= ordinal <= 126:
            ordinal = ord("?")
        values.append(ordinal - 32)
    checksum = values[0] + sum(index * value for index, value in enumerate(values[1:], start=1))
    return _code128_values_to_modules([*values, checksum % 103, 106])


def code128c_modules(digits: Any) -> str:
    value = digits_only(digits)
    if not value or len(value) % 2:
        return code128b_modules(value)
    values = [105, *(int(value[index:index + 2]) for index in range(0, len(value), 2))]
    checksum = values[0] + sum(index * item for index, item in enumerate(values[1:], start=1))
    return _code128_values_to_modules([*values, checksum % 103, 106])


def barcode_kind(value: Any) -> str:
    code = str(value or "").strip()
    if re.fullmatch(r"\d{13}", code):
        return "EAN-13 · OK" if is_valid_ean(code, 13) else "Code128-C · внутренний код (EAN-13 checksum неверный)"
    if re.fullmatch(r"\d{8}", code):
        return "EAN-8 · OK" if is_valid_ean(code, 8) else "Code128-C · внутренний код (EAN-8 checksum неверный)"
    if re.fullmatch(r"\d{12}", code):
        return "UPC-A · OK" if is_valid_ean("0" + code, 13) else "Code128-C · внутренний код"
    if re.fullmatch(r"\d{14}", code):
        return "Code128-C · внутренний/ITF-14 код"
    if re.fullmatch(r"\d+", code) and len(code) % 2 == 0:
        return "Code128-C · внутренний код"
    return "Code128-B"


def barcode_modules_for_print(value: Any) -> tuple[str, str]:
    code = str(value or "").strip()
    if re.fullmatch(r"\d{13}", code) and is_valid_ean(code, 13):
        return ean13_modules(code), "EAN-13"
    if re.fullmatch(r"\d{8}", code) and is_valid_ean(code, 8):
        return ean8_modules(code), "EAN-8"
    if re.fullmatch(r"\d{12}", code) and is_valid_ean("0" + code, 13):
        return ean13_modules("0" + code), "UPC-A"
    if re.fullmatch(r"\d+", code) and len(code) % 2 == 0:
        return code128c_modules(code[:80] or "00"), "Code128-C"
    return code128b_modules(code[:80] or " "), "Code128-B"


__all__ = [
    "barcode_kind", "barcode_modules_for_print", "code128b_modules",
    "code128c_modules", "digits_only", "ean_checksum", "ean13_modules",
    "ean8_modules", "is_valid_ean",
]
