#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Transactional migration ledger for SQLite.

Legacy schema creation remains untouched in this first phase. The ledger is now
available so every future inventory/checkout schema change receives a named,
ordered, idempotent migration instead of inline ALTER statements.
"""
from __future__ import annotations

import datetime as dt
import sqlite3
from dataclasses import dataclass
from typing import Callable, Iterable


MigrationFn = Callable[[sqlite3.Connection], None]


@dataclass(frozen=True, slots=True)
class Migration:
    version: int
    name: str
    apply: MigrationFn


def ensure_migration_ledger(con: sqlite3.Connection) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS schema_migrations (
            version INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            applied_at TEXT NOT NULL
        )
        """
    )


def applied_versions(con: sqlite3.Connection) -> set[int]:
    ensure_migration_ledger(con)
    return {int(row[0]) for row in con.execute("SELECT version FROM schema_migrations")}


def run_migrations(con: sqlite3.Connection, migrations: Iterable[Migration]) -> list[int]:
    ensure_migration_ledger(con)
    completed = applied_versions(con)
    applied: list[int] = []
    for migration in sorted(migrations, key=lambda item: item.version):
        if migration.version in completed:
            continue
        with con:
            migration.apply(con)
            con.execute(
                "INSERT INTO schema_migrations(version, name, applied_at) VALUES (?, ?, ?)",
                (migration.version, migration.name, dt.datetime.now().astimezone().isoformat()),
            )
        applied.append(migration.version)
    return applied


def record_legacy_baseline(con: sqlite3.Connection, schema_version: int) -> None:
    """Record the pre-v2 schema as an immutable baseline, idempotently."""
    ensure_migration_ledger(con)
    con.execute(
        "INSERT OR IGNORE INTO schema_migrations(version, name, applied_at) VALUES (?, ?, ?)",
        (int(schema_version), "legacy_sai_schema_baseline", dt.datetime.now().astimezone().isoformat()),
    )
