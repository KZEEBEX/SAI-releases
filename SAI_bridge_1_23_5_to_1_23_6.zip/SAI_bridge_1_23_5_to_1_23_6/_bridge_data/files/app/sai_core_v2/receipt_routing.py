#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pure routing rules for prepared SAI receipt files.

The Qt layer may ask for files and show dialogs, but it must not decide which
receipt workflow should open.  This module owns that decision and is deliberately
free of Qt, filesystem writes, and SIGMA-specific calls.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
import re
from typing import Any, Iterable, Mapping, Sequence


class ReceiptRouteKind(str, Enum):
    AUTOMATIC = "automatic"
    SEMI_AUTO = "semi_auto"


@dataclass(frozen=True, slots=True)
class ReceiptRoutePlan:
    path: Path
    kind: ReceiptRouteKind
    item_count: int
    missing_barcode_indices: tuple[int, ...]

    @property
    def missing_count(self) -> int:
        return len(self.missing_barcode_indices)

    @property
    def stage(self) -> str:
        return self.kind.value

    @property
    def requires_barcode_completion(self) -> bool:
        return self.kind is ReceiptRouteKind.SEMI_AUTO


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def resolve_prepared_receipt_path(path: Path | str) -> Path:
    """Prefer a sibling .sai package, then legacy XML, for selected Excel files."""
    selected = Path(path)
    if selected.suffix.lower() not in {".xlsx", ".xlsm"}:
        return selected
    package = selected.with_suffix(".sai")
    if package.is_file():
        return package
    legacy_xml = selected.with_suffix(".xml")
    if legacy_xml.is_file():
        return legacy_xml
    return selected


def numeric_barcodes(row: Mapping[str, Any]) -> tuple[str, ...]:
    """Return unique numeric codes accepted by receipt routing.

    Routing checks only whether a row already has a scannable numeric identifier;
    strict EAN checksum validation remains a later review concern.
    """
    values: list[Any] = []
    raw = row.get("barcodes")
    if isinstance(raw, (list, tuple, set)):
        values.extend(raw)
    elif raw not in (None, ""):
        values.append(raw)
    for key in ("barcode_cell", "barcode", "ШК", "штрихкод"):
        value = row.get(key)
        if value not in (None, ""):
            values.append(value)

    result: list[str] = []
    for value in values:
        for chunk in re.split(r"[,;\s]+", _text(value)):
            code = chunk.strip()
            if re.fullmatch(r"\d{5,}", code) and code not in result:
                result.append(code)
    return tuple(result)


def receipt_quantity(row: Mapping[str, Any]) -> float:
    raw = row.get("qty")
    if raw in (None, ""):
        raw = row.get("quantity")
    try:
        return float(_text(raw).replace(" ", "").replace(",", "."))
    except Exception:
        return 1.0


def missing_barcode_indices(rows: Sequence[Mapping[str, Any]]) -> tuple[int, ...]:
    """Rows with positive fact quantity and no usable barcode.

    A zero quantity is a full shortage and must never force semi-automatic mode.
    """
    return tuple(
        index
        for index, row in enumerate(rows)
        if receipt_quantity(row) > 0 and not numeric_barcodes(row)
    )


def build_receipt_route_plan(path: Path | str, rows: Sequence[Mapping[str, Any]]) -> ReceiptRoutePlan:
    resolved = Path(path)
    missing = missing_barcode_indices(rows)
    kind = ReceiptRouteKind.SEMI_AUTO if missing else ReceiptRouteKind.AUTOMATIC
    return ReceiptRoutePlan(
        path=resolved,
        kind=kind,
        item_count=len(rows),
        missing_barcode_indices=missing,
    )


class DraftResumeKind(str, Enum):
    MANUAL = "manual"
    PACKAGE = "package"
    INVALID = "invalid"


@dataclass(frozen=True, slots=True)
class DraftResumePlan:
    kind: DraftResumeKind
    package_path: Path | None = None


def build_draft_resume_plan(draft: Mapping[str, Any]) -> DraftResumePlan:
    """Translate stored draft metadata into a UI-independent resume action."""
    kind = _text(draft.get("kind")).lower()
    package_raw = _text(draft.get("package_path"))
    if kind == "manual" and not package_raw:
        return DraftResumePlan(DraftResumeKind.MANUAL)
    if package_raw:
        return DraftResumePlan(DraftResumeKind.PACKAGE, Path(package_raw))
    return DraftResumePlan(DraftResumeKind.INVALID)
