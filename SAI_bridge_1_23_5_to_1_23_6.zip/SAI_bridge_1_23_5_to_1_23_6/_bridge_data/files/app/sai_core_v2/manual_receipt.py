#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Qt-independent domain model for a manually entered receipt.

The UI owns widgets and dialogs. This module owns validation, price calculation,
row identity/merging, stable signatures and conversion-ready document values.
It deliberately has no PySide, filesystem, SIGMA or draft-repository imports.
"""
from __future__ import annotations

import datetime as dt
import json
import re
from dataclasses import dataclass
from typing import Any, Iterable, Mapping, Sequence

from .pricing import sale_price_from_purchase

DEFAULT_UNIT = "штука"


def text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def money_float(value: Any) -> float:
    try:
        raw = text(value).replace("\xa0", " ").replace(" ", "").replace("₽", "").replace(",", ".")
        return float(raw) if raw else 0.0
    except Exception:
        return 0.0


def price_text(value: Any) -> str:
    number = money_float(value)
    if not number:
        return ""
    return f"{number:.2f}".rstrip("0").rstrip(".")


def round_sale_from_purchase(purchase: Any, markup_percent: Any) -> float:
    """Compatibility name for the ecosystem-wide retail pricing policy."""
    buy = money_float(purchase)
    markup = max(0.0, money_float(markup_percent))
    return sale_price_from_purchase(buy, markup)


def normalized_identity_text(value: Any) -> str:
    # Preserve the historical product-name alias vocabulary when the normalizer
    # is available, while keeping the core usable in isolated tests/tools.
    raw = value
    try:
        import sai_product_names
        raw = sai_product_names.searchable_text(value)
    except Exception:
        pass
    raw = text(raw).upper().replace("Ё", "Е")
    raw = re.sub(r"[^0-9A-ZА-Я]+", " ", raw)
    return re.sub(r"\s+", " ", raw).strip()


def normalized_barcodes(values: Iterable[Any]) -> tuple[str, ...]:
    result: list[str] = []
    for value in values:
        for chunk in re.split(r"[,;\s]+", text(value)):
            code = chunk.strip()
            if code and code not in result:
                result.append(code)
    return tuple(result)


@dataclass(frozen=True, slots=True)
class ManualReceiptRow:
    name: str
    barcodes: tuple[str, ...]
    category: str
    unit: str
    qty: float
    sale: float
    buy: float = 0.0
    product_id: str = ""

    @classmethod
    def from_values(
        cls,
        *,
        name: Any,
        barcodes: Iterable[Any],
        category: Any = "",
        unit: Any = DEFAULT_UNIT,
        qty: Any,
        sale: Any,
        buy: Any = 0.0,
        product_id: Any = "",
    ) -> "ManualReceiptRow":
        return cls(
            name=text(name).upper(),
            barcodes=normalized_barcodes(barcodes),
            category=text(category),
            unit=text(unit) or DEFAULT_UNIT,
            qty=money_float(qty),
            sale=money_float(sale),
            buy=money_float(buy),
            product_id=text(product_id),
        )

    @classmethod
    def from_mapping(cls, row: Mapping[str, Any]) -> "ManualReceiptRow":
        return cls.from_values(
            name=row.get("name"),
            barcodes=row.get("barcodes") or (),
            category=row.get("category"),
            unit=row.get("unit"),
            qty=row.get("qty"),
            sale=row.get("sale"),
            buy=row.get("buy"),
            product_id=row.get("product_id"),
        )

    def validation_errors(self) -> tuple[str, ...]:
        errors: list[str] = []
        if not self.name:
            errors.append("name")
        if self.qty <= 0:
            errors.append("qty")
        if self.sale <= 0:
            errors.append("sale")
        return tuple(errors)

    @property
    def valid(self) -> bool:
        return not self.validation_errors()

    @property
    def identity_key(self) -> tuple[Any, ...]:
        return (
            normalized_identity_text(self.name),
            tuple(sorted(self.barcodes)),
            normalized_identity_text(self.category),
            normalized_identity_text(self.unit),
            round(self.sale, 2),
            round(self.buy, 2),
            self.product_id,
        )

    def with_qty(self, qty: Any) -> "ManualReceiptRow":
        return ManualReceiptRow(
            name=self.name,
            barcodes=self.barcodes,
            category=self.category,
            unit=self.unit,
            qty=money_float(qty),
            sale=self.sale,
            buy=self.buy,
            product_id=self.product_id,
        )

    def to_mapping(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "barcodes": list(self.barcodes),
            "category": self.category,
            "unit": self.unit,
            "qty": self.qty,
            "sale": self.sale,
            "buy": self.buy,
            "product_id": self.product_id,
        }


def merge_row(rows: Sequence[Mapping[str, Any]], incoming: ManualReceiptRow) -> tuple[list[dict[str, Any]], bool]:
    """Return a new row list; never mutate caller-owned data.

    Unknown fields are retained so drafts written by newer SAI versions remain
    forward-compatible when opened by this service boundary.
    """
    result = [dict(row) for row in rows]
    for index, raw in enumerate(result):
        row = ManualReceiptRow.from_mapping(raw)
        if row.identity_key == incoming.identity_key:
            raw["qty"] = row.qty + incoming.qty
            return result, True
    result.append(incoming.to_mapping())
    return result, False


def label_copies(row: Mapping[str, Any]) -> int:
    return max(1, int(round(money_float(row.get("qty")))))


def card_has_data(card: Mapping[str, Any]) -> bool:
    return any(
        (
            text(card.get("name")),
            text(card.get("barcode_input")),
            bool(card.get("barcodes") or ()),
            text(card.get("qty")),
            text(card.get("purchase_price")),
            bool(card.get("category") or {}),
        )
    )


def stable_rows_signature(
    *,
    supplier_id: Any,
    supplier_name: Any,
    date_text: Any,
    rows: Sequence[Mapping[str, Any]],
) -> str:
    payload = {
        "supplier_id": text(supplier_id),
        "supplier_name": text(supplier_name),
        "date": text(date_text),
        "rows": [ManualReceiptRow.from_mapping(row).to_mapping() for row in rows],
    }
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def receipt_date_iso(value: Any, *, today: dt.date | None = None) -> str:
    raw = text(value)
    fallback = today or dt.date.today()
    if not raw:
        return fallback.isoformat()
    for fmt in ("%d.%m.%Y", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            pass
    return fallback.isoformat()


@dataclass(frozen=True, slots=True)
class ManualReceiptDocumentItem:
    row: int
    name: str
    quantity: float
    unit: str
    purchase_price: float
    sale_price: float
    category: str
    barcodes: tuple[str, ...]
    comment: str = "Ручная накладная"


@dataclass(frozen=True, slots=True)
class ManualReceiptDocument:
    supplier: str
    date: str
    markup_percent: float
    items: tuple[ManualReceiptDocumentItem, ...]
    source_path: str = "Ручная накладная"
    source_type: str = "FreeReceipt"
    invoice_number: str = "FREE"


def build_document(
    *,
    rows: Sequence[Mapping[str, Any]],
    supplier: Any,
    date_text: Any,
    markup_percent: Any,
    today: dt.date | None = None,
) -> ManualReceiptDocument:
    markup = money_float(markup_percent)
    items: list[ManualReceiptDocumentItem] = []
    for index, raw in enumerate(rows, start=1):
        row = ManualReceiptRow.from_mapping(raw)
        buy = row.buy or (row.sale / (1.0 + markup / 100.0) if markup > -99 else row.sale)
        items.append(
            ManualReceiptDocumentItem(
                row=index,
                name=row.name,
                quantity=row.qty,
                unit=row.unit,
                purchase_price=round(buy, 2),
                sale_price=row.sale,
                category=row.category,
                barcodes=row.barcodes,
            )
        )
    return ManualReceiptDocument(
        supplier=text(supplier) or "РУЧНАЯ НАКЛАДНАЯ",
        date=receipt_date_iso(date_text, today=today),
        markup_percent=markup,
        items=tuple(items),
    )
