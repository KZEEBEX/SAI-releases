#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""End-to-end automatic receipt tests with a non-networked SIGMA double."""
from __future__ import annotations

import os
import json
import tempfile
from pathlib import Path
from types import SimpleNamespace
import requests

RUNTIME = Path(tempfile.mkdtemp(prefix="sai_auto_receipt_readiness_"))
os.environ["SAI_USER_DATA_DIR"] = str(RUNTIME / "user_data")

import sai_api_first_apply as api_first
from sai_api_first_apply import SigmaRestClient, preflight_verify_rows, process_rows, resolve_product_for_row


ROWS = [
    {
        "excel_row": 2, "barcode": "4006381333931", "name": "ТОВАР 1",
        "quantity": 2.0, "buying_price": 100.0, "selling_price": 160.0,
    },
    {
        "excel_row": 3, "barcode": "12345678", "name": "ТОВАР 2",
        "quantity": 3.0, "buying_price": 50.0, "selling_price": 90.0,
    },
]


class FakeSigma:
    def __init__(self, missing: set[str] | None = None):
        self.missing = missing or set()
        self.writes: list[tuple] = []
        self.elements: dict[str, str] = {}

    def find_product_by_barcode(self, barcode, storehouse_id, waybill_id=None):
        if barcode in self.missing:
            return None, []
        product = {"id": f"product-{barcode}", "sellingPrice": 150 if barcode == "4006381333931" else 80}
        return product, [product]

    def get_existing_element(self, waybill_id, product_id):
        element = self.elements.get(product_id)
        return {"elementId": element, "sellingPrice": 150} if element else {}

    def add_product_to_waybill(self, waybill_id, product_id):
        element = f"element-{len(self.elements) + 1}"
        self.elements[product_id] = element
        self.writes.append(("add", waybill_id, product_id))
        return {"elementId": element}

    def set_quantity(self, waybill_id, element_id, value):
        self.writes.append(("quantity", element_id, value))

    def set_buying_price(self, waybill_id, element_id, value):
        self.writes.append(("buying", element_id, value))

    def set_selling_price(self, waybill_id, element_id, value):
        self.writes.append(("selling", element_id, value))


class DuplicateBarcodeSigma(FakeSigma):
    def find_product_by_barcode(self, barcode, storehouse_id, waybill_id=None):
        candidates = [
            {"id": "wrong", "name": "ДРУГОЙ ТОВАР"},
            {"id": "right", "name": "ТОВАР 1"},
        ]
        return candidates[0], candidates


class SavedDuplicateBarcodeSigma(FakeSigma):
    def find_product_by_barcode(self, barcode, storehouse_id, waybill_id=None):
        candidates = [
            {"id": "wrong", "name": "НЕ ТОТ ТОВАР"},
            {"id": "right", "name": "ДРУГАЯ КАРТОЧКА"},
        ]
        return candidates[0], candidates


class ConflictingPriceSigma(FakeSigma):
    """The product card is newer and higher than the draft element."""

    def find_product_by_barcode(self, barcode, storehouse_id, waybill_id=None):
        product = {"id": f"product-{barcode}", "sellingPrice": 210}
        return product, [product]

    def get_existing_element(self, waybill_id, product_id):
        return {"elementId": "element-existing", "sellingPrice": 120}


class EmptyAddedPriceSigma(FakeSigma):
    """SIGMA often returns zero before the new element price is written."""

    def find_product_by_barcode(self, barcode, storehouse_id, waybill_id=None):
        product = {"id": f"product-{barcode}", "sellingPrice": None}
        return product, [product]

    def add_product_to_waybill(self, waybill_id, product_id):
        element = f"element-{len(self.elements) + 1}"
        self.elements[product_id] = element
        self.writes.append(("add", waybill_id, product_id))
        return {"elementId": element, "sellingPrice": 0}


class FakeResponse:
    status_code = 200
    text = '{"items": []}'

    def json(self):
        return {"items": []}


class FlakyReadSession:
    def __init__(self):
        self.calls = 0

    def request(self, *_args, **_kwargs):
        self.calls += 1
        if self.calls < 3:
            raise requests.ReadTimeout("simulated SIGMA timeout")
        return FakeResponse()


def args(*, apply: bool, price_policy: str = "max"):
    return SimpleNamespace(
        waybill_id="test-waybill", apply=apply, price_policy=price_policy,
        stop_on_error=True,
    )


def main() -> int:
    retry_client = SigmaRestClient("test-token")
    retry_client.session = FlakyReadSession()
    original_sleep = api_first.time.sleep
    api_first.time.sleep = lambda _seconds: None
    try:
        assert retry_client.request("POST", "/rest/v4/products/simple?page=0", {}) == {"items": []}
        assert retry_client.session.calls == 3
    finally:
        api_first.time.sleep = original_sleep

    selected, used_barcode, candidates, _notes = resolve_product_for_row(
        args(apply=False),
        DuplicateBarcodeSigma(),
        ROWS[0],
        "store-1",
    )
    assert selected["id"] == "right" and used_barcode == "4006381333931"
    assert len(candidates) == 2

    resolutions_path = RUNTIME / "user_data" / "barcode_conflict_resolutions.json"
    resolutions_path.parent.mkdir(parents=True, exist_ok=True)
    resolutions_path.write_text(
        json.dumps({
            "4006381333931|ТОВАР 1": {"product_id": "right"},
        }),
        encoding="utf-8",
    )
    selected, used_barcode, candidates, _notes = resolve_product_for_row(
        args(apply=False),
        SavedDuplicateBarcodeSigma(),
        ROWS[0],
        "store-1",
    )
    assert selected["id"] == "right" and len(candidates) == 2

    client = FakeSigma()
    errors, preflight_log = preflight_verify_rows(args(apply=False), client, ROWS, "store-1")
    assert errors == 0 and preflight_log.is_file()
    assert not client.writes, "read-only preflight must never write"

    processed, errors, dry_log = process_rows(args(apply=False), client, ROWS, "store-1")
    assert (processed, errors) == (2, 0) and dry_log.is_file()
    assert not client.writes, "dry-run must never write"

    processed, errors, apply_log = process_rows(args(apply=True), client, ROWS, "store-1")
    assert (processed, errors) == (2, 0) and apply_log.is_file()
    assert sum(1 for item in client.writes if item[0] == "add") == 2
    assert sum(1 for item in client.writes if item[0] == "quantity") == 2
    assert sum(1 for item in client.writes if item[0] == "buying") == 2
    assert sum(1 for item in client.writes if item[0] == "selling") == 2

    conflicting = ConflictingPriceSigma()
    processed, errors, _ = process_rows(
        args(apply=True, price_policy="incoming"),
        conflicting,
        [ROWS[0]],
        "store-1",
    )
    assert (processed, errors) == (1, 0)
    assert ("selling", "element-existing", 210.0) in conflicting.writes, (
        "the receipt must use the highest of incoming, product-card and draft-element prices"
    )

    empty_price = EmptyAddedPriceSigma()
    processed, errors, _ = process_rows(
        args(apply=True),
        empty_price,
        [ROWS[0]],
        "store-1",
    )
    assert (processed, errors) == (1, 0)
    assert ("selling", "element-1", 160.0) in empty_price.writes, (
        "an empty/zero price returned for a new element must keep the incoming price"
    )

    broken = FakeSigma({"12345678"})
    errors, _ = preflight_verify_rows(args(apply=False), broken, ROWS, "store-1")
    assert errors == 1 and not broken.writes
    print("Automatic receipt readiness tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
