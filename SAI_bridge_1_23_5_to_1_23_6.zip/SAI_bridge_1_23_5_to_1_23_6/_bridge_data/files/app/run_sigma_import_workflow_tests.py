#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression tests for authenticated SIGMA import and category persistence."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))


def main() -> int:
    from openpyxl import Workbook, load_workbook
    from sai_sigma_import_state import (
        load_import_category_memory,
        read_import_xlsx_category_memory,
        remembered_categories_by_row,
        save_import_category_memory,
    )

    source = (APP_DIR / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    assert "Authorization'] = `Bearer ${token}`" in source
    assert '"Authorization"] = "Bearer " + runtime_token' in source
    assert "load_runtime_token_cache_payload(max_age_seconds=4 * 3600)" in source
    assert "self.awaiting_post_import_verification" in source
    assert "Категории сохранены; повторно назначать их не нужно." in source

    with tempfile.TemporaryDirectory(prefix="sai_sigma_import_workflow_") as temp:
        root = Path(temp)
        xlsx = root / "Import.xlsx"
        wb = Workbook()
        ws = wb.active
        ws.append(["Наименование", "Артикул", "Единица измерения", "Штрихкод", "Категория", "НДС", "Цена", "Тип"])
        ws.append(["МОЛОТОК 500 Г", "A", "штука", "7700000000019", "9", "Без НДС", 100, "Обычный товар"])
        ws.append(["ОТВЕРТКА PH2", "B", "штука", "7700000000026", "", "Без НДС", 200, "Обычный товар"])
        wb.save(xlsx)

        memory = read_import_xlsx_category_memory(xlsx)
        assert memory["barcode:7700000000019"] == "9"
        assert memory["name:МОЛОТОК 500 Г"] == "9"
        assert "barcode:7700000000026" not in memory

        memory_path = root / "category-memory.json"
        save_import_category_memory(memory, memory_path)
        loaded = load_import_category_memory(memory_path)
        assert loaded == memory
        rows = [
            {"excel_row": 2, "name": "МОЛОТОК 500 Г", "barcode": "7700000000019"},
            {"excel_row": 3, "name": "ОТВЕРТКА PH2", "barcode": "7700000000026"},
        ]
        assert remembered_categories_by_row(rows, loaded) == {2: "9"}
        check_wb = load_workbook(xlsx, read_only=True)
        try:
            assert check_wb.active.max_row == 3
        finally:
            check_wb.close()

    print("SAI SIGMA import workflow tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
