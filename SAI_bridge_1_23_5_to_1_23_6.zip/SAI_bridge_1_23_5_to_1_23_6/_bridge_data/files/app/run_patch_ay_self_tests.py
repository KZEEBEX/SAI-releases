#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Patch regression for SAI v1.22.7ay rail geometry lock."""
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"


def main() -> None:
    ui = (APP / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    notifications = (APP / "sai_notifications.py").read_text(encoding="utf-8-sig")
    version = (APP / "sai_version.py").read_text(encoding="utf-8-sig")
    ast.parse(ui)
    ast.parse(notifications)
    assert 'VERSION = "1.22.7ay"' in version
    assert 'RailTopBlock' in ui and 'RailBottomBlock' in ui
    assert 'AlignLeft | Qt.AlignmentFlag.AlignVCenter' in ui
    assert 'rail.setUpdatesEnabled(False)' in ui
    assert 'self._layout.setContentsMargins(15, 9, 15, 9)' not in notifications
    assert (APP / "run_rail_visual_tests.py").is_file()
    print("OK: SAI v1.22.7ay patch regression passed")


if __name__ == "__main__":
    main()
