#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for paginated legacy XLS supplier tables."""
from __future__ import annotations

import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import sai_converter


HEADER = [
    "№", "Код", "Товар", "Кол-во", "Ед.", "Цена",
    "Сумма без скидки", "Цена со скидкой", "Сумма", "ШК",
]


def product(number: int) -> list[object]:
    return [
        str(number), f"{number:08d}", f"Товар {number}", 2.0, "шт",
        110.0, 220.0, 100.0, 200.0, f"46000000{number:05d}",
    ]


def test_four_printed_blocks_are_complete() -> None:
    table: list[list[object]] = [HEADER, []]
    next_number = 1
    for block_size in (17, 3, 7, 2):
        if next_number > 1:
            table.extend([HEADER, []])
        table.extend(product(number) for number in range(next_number, next_number + block_size))
        next_number += block_size

    items, warnings, _meta = sai_converter.rows_from_table(table, 60.0, source_hint="synthetic.xls")
    assert len(items) == 29, f"expected 29 rows, got {len(items)}"
    assert [item.row for item in items] == list(range(1, 30))
    assert items[0].name == "ТОВАР 1"
    assert items[-1].name == "ТОВАР 29"
    assert items[0].purchase_price == 100.0, "discounted line total must define purchase price"
    assert items[0].line_total == 200.0
    assert "00000001" not in items[0].barcodes, "supplier article must not become a barcode"
    assert any("повторных шапок 3" in warning for warning in warnings)


def test_vendored_xls_reader_is_available() -> None:
    assert sai_converter.xlrd is not None
    assert callable(sai_converter.xlrd.open_workbook)


if __name__ == "__main__":
    test_four_printed_blocks_are_complete()
    test_vendored_xls_reader_is_available()
    print("Legacy XLS pagination tests: OK")
