#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7an."""
from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
app_dir = root / "app"
ui_path = app_dir / "sai_pyside_preview.py"
version_path = app_dir / "sai_version.py"
self_tests_path = app_dir / "run_self_tests.py"
wiki_dir = root / "SAI_Ecosystem_Wiki_v0.1"

for source in (ui_path, version_path, self_tests_path, Path(__file__)):
    ast.parse(source.read_text(encoding="utf-8-sig"), filename=str(source))

ui = ui_path.read_text(encoding="utf-8-sig")
version = version_path.read_text(encoding="utf-8-sig")
self_tests = self_tests_path.read_text(encoding="utf-8-sig")

assert 'VERSION = "1.22.7an"' in version
assert 'APP_VERSION == "v1.22.7an"' in self_tests
assert 'self.confirm_button.setObjectName("PageOrientationConfirmButton")' in ui
assert 'self.cancel_button.setObjectName("SoftButton")' in ui
assert 'self.confirm_button.setMinimumSize(240, 48)' in ui
assert 'self.confirm_button.setCursor(Qt.PointingHandCursor)' in ui
assert 'QPushButton#PageOrientationConfirmButton {' in ui
assert 'border-radius: 14px;' in ui
assert 'QPushButton#PageOrientationConfirmButton:hover {' in ui
assert 'QPushButton#PageOrientationConfirmButton:pressed {' in ui
assert 'QPushButton#PageOrientationConfirmButton:focus {' in ui
assert 'QPushButton#PageOrientationConfirmButton:disabled {' in ui

manifest = json.loads((wiki_dir / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.5"
assert manifest["snapshot_sai_version"] == "1.22.7an"
assert "v1.22.7an" in (wiki_dir / "README.md").read_text(encoding="utf-8")
assert (wiki_dir / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.5 / SAI 1.22.7an")
print("PATCH_AN_SELF_TEST_OK")
