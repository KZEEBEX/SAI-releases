#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import ast, json, os, sys, tempfile
from pathlib import Path

root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_ag_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as ai

assert ai.CONTRACT_VERSION=='invoice_ai_contract_v11'
assert ai.DEFAULT_MODEL=='gpt-5.6-luna'
assert ai.AUDIT_MODEL=='gpt-5.6-terra'
assert ai.FALLBACK_MODEL=='gpt-5.6-sol'
assert ai.quality_model('gpt-5.6-sol')=='gpt-5.6-luna'
assert ai.quality_model('gpt-5.6-terra')=='gpt-5.6-luna'
ai.invoice_contract_metadata()

def response(data, input_tokens=1000, output_tokens=200):
    return {
        'output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(data,ensure_ascii=False)}]}],
        'usage':{'input_tokens':input_tokens,'output_tokens':output_tokens,'total_tokens':input_tokens+output_tokens,'input_tokens_details':{'cached_tokens':0}},
    }

def base_doc(quantity=1.0, barcode='4607136256514', raw_name='ТОВАР'):
    return {
        'supplier':'ТЕСТОВЫЙ ПОСТАВЩИК','invoice_date':'2026-07-18','invoice_number':'AG-1',
        'currency':'RUB','document_total':100.0,'document_total_note':'','warnings':[],
        'items':[{'source_row':1,'source_page':1,'raw_name':raw_name,'name':raw_name,
                  'quantity':quantity,'unit':'шт','purchase_price':100.0,'line_total':100.0,
                  'article':'A1','barcodes':([barcode] if barcode else []),'confidence':0.8,'note':''}],
    }

def audit(status='verified', quantity=1.0, raw_name='ТОВАР', uncertain_fields=None, note=''):
    return {
        'supplier':'ТЕСТОВЫЙ ПОСТАВЩИК','invoice_date':'2026-07-18','invoice_number':'AG-1','document_total':100.0,
        'checked_rows':[1],
        'rows':[{'source_row':1,'source_page':1,'status':status,'raw_name':raw_name,'article':'A1',
                 'barcodes':['4607136256514'],'quantity':quantity,'unit':'шт','line_total':100.0,
                 'uncertain_fields':list(uncertain_fields or []),'note':note}],
    }

def run_case(name, replies):
    source=Path(tempfile.mkdtemp(prefix='sai_ag_case_'))/(name+'.txt')
    source.write_text('test invoice',encoding='utf-8')
    calls=[]
    queue=list(replies)
    original=ai.call_openai
    def fake(payload,*args,**kwargs):
        calls.append(payload['model'])
        if not queue:
            raise AssertionError('unexpected API call')
        return response(queue.pop(0))
    ai.call_openai=fake
    try:
        result=ai.analyze_invoice([source],'sk-test')
    finally:
        ai.call_openai=original
    assert not queue, f'unused replies in {name}'
    return result,calls,source

# Clean Luna result: no second paid request.
result,calls,source=run_case('clean',[base_doc()])
assert calls==['gpt-5.6-luna']
assert len(result.items)==1 and result.items[0].barcodes==['4607136256514']
assert len(result.validation['openai_stages'])==1
# Exact repeat comes from local cache.
original=ai.call_openai
ai.call_openai=lambda *a,**k: (_ for _ in ()).throw(AssertionError('cache miss'))
try:
    cached=ai.analyze_invoice([source],'sk-test')
finally:
    ai.call_openai=original
assert cached.validation['cache_hit'] is True

# Invalid GTIN is omitted safely; Terra is not called.
result,calls,_=run_case('bad_gtin',[base_doc(barcode='4607136256515')])
assert calls==['gpt-5.6-luna']
assert result.items[0].barcodes==[]
assert result.validation['barcode_omitted_rows']==[1]

# A material defect triggers only targeted Terra and is repaired.
result,calls,_=run_case('terra',[base_doc(quantity=0),audit(quantity=1)])
assert calls==['gpt-5.6-luna','gpt-5.6-terra']
assert result.items[0].quantity==1
assert len(result.validation['openai_stages'])==2

# Terra uncertainty in a non-barcode field triggers bounded Sol escalation.
result,calls,_=run_case('sol',[base_doc(quantity=0),audit(status='uncertain',quantity=1,raw_name='ТОВАР',uncertain_fields=['raw_name'],note='Название закрыто'),audit(status='verified',quantity=1,raw_name='ТОВАР')])
assert calls==['gpt-5.6-luna','gpt-5.6-terra','gpt-5.6-sol']
assert result.validation['arbitration_rows']==[1]
assert result.validation['unresolved_rows']==[]

ui_path=root/'app'/'sai_pyside_preview.py'
ui=ui_path.read_text(encoding='utf-8')
ast.parse(ui,filename=str(ui_path))
assert 'SAI Invoice Agent' in ui
assert 'этапы: ' in ui
wiki=json.loads((root/'SAI_Ecosystem_Wiki_v0.1'/'wiki_manifest.json').read_text(encoding='utf-8-sig'))
assert wiki['wiki_version']=='1.8'
assert wiki['snapshot_sai_version']=='1.22.7ag'
print('PATCH_AG_SELF_TEST_OK')
