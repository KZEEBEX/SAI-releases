#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic tests for SAI Ready (no network, no real Startup folder)."""
from __future__ import annotations

import json
import os
import tempfile
import time
from unittest.mock import patch
from contextlib import closing
from pathlib import Path


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="sai_ready_tests_") as td:
        root = Path(td)
        os.environ["SAI_USER_DATA_DIR"] = str(root / "user_data")

        import sai_catalog_ready as ready
        import sai_ready_autostart as autostart

        cfg = {
            "sigma_company_key": "company-test",
            "sigma_api_token": "token-test",
            "sigma_sell_point_id": "sp-test",
            "sai_ready_enabled": True,
            "sai_ready_startup_min_age_minutes": 30,
            "free_receipt_barcode_prefix": "77",
            "free_receipt_barcode_last_counter": 3_071_602_080,
        }
        ready.save_private_config_patch(cfg)
        from sai_core_v2.free_receipt import internal_barcode

        ready.sai_db.init_db()
        with closing(ready.sai_db.connect()) as connection, connection:
            existing_internal = internal_barcode("77", 912)
            connection.execute(
                "INSERT INTO products(sigma_id, company_key, sell_point_id, name, vendor_code, barcodes_json, raw_json, updated_at) "
                "VALUES(?,?,?,?,?,?,?,?)",
                ("internal-product", "company-test", "sp-test", "ВНУТРЕННИЙ", "", json.dumps([existing_internal]), "{}", "2026-07-25 10:00:00"),
            )
            connection.execute(
                "INSERT INTO barcodes(barcode, product_id, company_key, sell_point_id, updated_at) VALUES(?,?,?,?,?)",
                (existing_internal, "internal-product", "company-test", "sp-test", "2026-07-25 10:00:00"),
            )
        synced = ready.synchronize_internal_barcode_counter()
        assert synced["counter"] == 912 and synced["updated"] is True
        assert ready.load_private_config()["free_receipt_barcode_last_counter"] == 912
        assert ready.load_private_config()["free_receipt_barcode_prefix"] == "7700"

        assert ready.human_age(20) == "меньше минуты"
        assert ready.human_age(180) == "3 мин"
        assert ready.human_age(7200) == "2 ч"

        status = ready.write_status("ready", "test", ok=True, product_count=12)
        assert status["state"] == "ready"
        assert ready.read_status()["product_count"] == 12

        lock_path = root / "catalog.lock"
        first = ready.CatalogRefreshLock(lock_path, stale_seconds=60)
        second = ready.CatalogRefreshLock(lock_path, stale_seconds=60)
        assert first.acquire() is True
        assert second.acquire() is False
        first.release()
        assert second.acquire() is True
        second.release()

        assert ready._process_running(os.getpid()) is True
        lock_path.write_text(json.dumps({"pid": 12512, "started_at": "2026-09-04 15:49:10"}))
        with patch.object(ready, "_process_running", return_value=False):
            assert first.acquire(), "Dead owner must be recovered without waiting two hours"
        first.release()
        lock_path.write_text(json.dumps({"pid": os.getpid()}))
        os.utime(lock_path, (time.time() - 7200, time.time() - 7200))
        assert not first.acquire(), "A live owner's lock must not be stolen because it is old"
        with patch.object(ready, "_process_running", return_value=None):
            assert not first.acquire(), "Unknown owner liveness must fail closed"
        lock_path.unlink()
        assert first.acquire()
        replacement = {"pid": os.getpid(), "owner_token": "another-owner"}
        lock_path.write_text(json.dumps(replacement))
        first.release()
        assert json.loads(lock_path.read_text()) == replacement, "Release must not remove another owner's marker"
        lock_path.unlink()

        original_meta = ready._catalog_meta
        try:
            ready._catalog_meta = lambda company, sp: {
                "created_at": "2026-07-19 10:00:00",
                "strategy": "test",
                "product_count": 25,
                "barcode_count": 31,
                "app_version": "test",
                "age_seconds": 60.0,
            }
            result = ready.refresh_catalog(reason="test", force=False, min_age_minutes=30, cfg=cfg)
            assert result["ok"] is True
            assert result["refreshed"] is False
            assert result["product_count"] == 25
        finally:
            ready._catalog_meta = original_meta

        missing = ready.refresh_catalog(reason="test", cfg={"sai_ready_enabled": True})
        assert missing["ok"] is False
        assert missing["state"] == "missing_config"

        supplier_cache = ready._save_suppliers_cache("company-id", [
            {"id": "b", "name": "Второй"},
            {"id": "a", "name": "Первый", "inn": "123"},
            {"id": "a", "name": "Дубликат"},
        ])
        assert {item["id"] for item in supplier_cache["suppliers"]} == {"a", "b"}
        assert len(supplier_cache["suppliers"]) == 2
        assert ready._cached_supplier_count() == 2

        original_refresh_catalog = ready.refresh_catalog
        original_refresh_suppliers = ready.refresh_suppliers
        try:
            ready.save_private_config_patch({"sai_ready_startup_delay_seconds": 0})
            calls = []
            ready.refresh_catalog = lambda **_kwargs: {
                "ok": True, "product_count": 25, "barcode_count": 31,
                "internal_barcode_counter": 912,
            }
            ready.refresh_suppliers = lambda **_kwargs: calls.append("suppliers") or {
                "ok": True, "refreshed": True, "supplier_count": 2,
            }
            assert ready.run_startup_worker() == 0
            assert calls == ["suppliers"]
            assert ready.read_status()["supplier_count"] == 2
        finally:
            ready.refresh_catalog = original_refresh_catalog
            ready.refresh_suppliers = original_refresh_suppliers

        startup_dir = root / "Startup"
        installed = autostart.install_autostart(root / "SAI", startup_dir=startup_dir)
        assert installed and installed.is_file()
        raw = installed.read_bytes()
        assert raw.startswith(b"\xff\xfe")
        text = raw[2:].decode("utf-16le")
        assert "sai_catalog_ready.py" in text
        assert "--startup" in text
        assert "pythonw.exe" in text
        assert autostart.is_autostart_installed(startup_dir)
        assert autostart.remove_autostart(startup_dir)
        assert not installed.exists()

        print(json.dumps({"status": "OK", "tests": 9}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
