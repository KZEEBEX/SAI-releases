#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent deterministic tests for invoice reconciliation and validation."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_invoice_reconcile_tests_")
sys.path.insert(0, str(ROOT / "app"))

import sai_invoice_ai_reconciliation as reconciliation
import sai_openai_invoice as facade

assert facade.reconcile_luna_page is reconciliation.reconcile_luna_page
assert facade.apply_audit is reconciliation.apply_audit
assert facade._sanitize_and_evaluate_document is reconciliation._sanitize_and_evaluate_document


def item(row=1, page=1, total=20.0, name="ТОВАР", barcode="4601234567893"):
    return {
        "source_row": row,
        "source_page": page,
        "raw_name": name,
        "name": name,
        "quantity": 2.0,
        "unit": "шт",
        "purchase_price": 10.0,
        "line_total": total,
        "article": f"A{row}",
        "barcodes": [barcode] if barcode else [],
        "confidence": 0.9,
        "note": "",
    }


def doc(items, total=20.0, supplier="ООО ТЕСТ", number="1"):
    return {
        "supplier": supplier,
        "invoice_date": "2026-07-19",
        "invoice_number": number,
        "currency": "RUB",
        "document_total": total,
        "document_total_note": "",
        "items": items,
        "warnings": [],
    }

# Visually confusable Latin/Cyrillic names are equivalent and prefer real Latin spelling.
merged, problems, notes, omitted, corrections = reconciliation.reconcile_luna_page(
    doc([item(name="POTATO НОЖНИЦЫ")]),
    doc([item(name="РОТАТО НОЖНИЦЫ")]),
    1,
)
assert problems == [] and notes == [] and omitted == []
assert merged["items"][0]["raw_name"] == "POTATO НОЖНИЦЫ"

# A barcode conflict is resolved safely without a paid arbitration target.
merged, problems, notes, omitted, corrections = reconciliation.reconcile_luna_page(
    doc([item(barcode="4601234567893")]),
    doc([item(barcode="4607136256514")]),
    1,
)
assert problems == [] and notes == []
assert omitted == [1]
assert merged["items"][0]["barcodes"] == []
assert corrections == {}

# Page merge keeps page-one header, final-page total and deterministic row order.
page_one = doc([item(row=1, page=1, total=20)], total=20, supplier="ПЕРВЫЙ", number="N-1")
page_two = doc([item(row=1, page=2, total=30)], total=50, supplier="ДРУГОЙ", number="N-2")
combined = reconciliation._merge_page_documents([(2, page_two), (1, page_one)])
assert combined["supplier"] == "ПЕРВЫЙ"
assert combined["invoice_number"] == "N-1"
assert combined["document_total"] == 50
assert [row["source_row"] for row in combined["items"]] == [1, 2]
assert [row["source_page"] for row in combined["items"]] == [1, 2]

# A batch is merged completely, while an invoice/sales-document pair is not
# counted twice. Individual equal products in different documents are kept.
sale_row = item(name="ТОВАР А", barcode="")
bill_row = item(name="ТОВАР А", barcode="4601234567893")
other_row = item(name="ТОВАР Б", barcode="4607136256514")
batch = reconciliation.merge_source_documents([
    ("Реализация A.xlsx", doc([sale_row], total=20, number="A")),
    ("Счет A.xlsx", doc([bill_row], total=20, number="A")),
    ("Реализация B.xlsx", doc([other_row], total=20, number="B")),
])
assert len(batch["items"]) == 2
assert batch["document_total"] == 40
assert [row["source_row"] for row in batch["items"]] == [1, 2]
assert batch["items"][0]["barcodes"] == ["4601234567893"]
assert "Счет A.xlsx" in batch["warnings"][-1]

# Barcode-only uncertainty becomes an empty barcode and semi-automatic route.
audit = {
    "supplier": "ООО ТЕСТ",
    "invoice_date": "2026-07-19",
    "invoice_number": "1",
    "document_total": 20,
    "checked_rows": [1],
    "rows": [dict(
        item(barcode=""),
        status="uncertain",
        uncertain_fields=["barcodes"],
        note="Штрихкод не читается",
    )],
    "warnings": [],
}
updated, changed, uncertain, barcode_omitted = reconciliation.apply_audit(doc([item()]), audit)
assert uncertain == [] and barcode_omitted == [1]
assert updated["items"][0]["barcodes"] == []
assert "unreadable_barcode_omitted" in changed[1]

# Invalid GTIN is removed locally; no model is needed.
cleaned, problems, notes, barcode_omitted = reconciliation._sanitize_and_evaluate_document(
    doc([item(barcode="4601234567890")]),
    supplier_hint="ООО ТЕСТ",
    date_hint="2026-07-19",
    invoice_hint="1",
)
assert cleaned["items"][0]["barcodes"] == []
assert barcode_omitted == [1]
assert problems == [] and notes == []

# Material amount mismatch remains a blocker, but may be accepted explicitly
# by the operator after the AI pipeline has exhausted its repair attempts.
bad = doc([item(total=20)], total=25)
_cleaned, problems, notes, _omitted = reconciliation._sanitize_and_evaluate_document(
    bad,
    supplier_hint="ООО ТЕСТ",
    date_hint="2026-07-19",
    invoice_hint="1",
)
assert problems == [1]
assert reconciliation._blocking_quality_notes(notes)
assert reconciliation._reviewable_quality_notes(notes) == reconciliation._blocking_quality_notes(notes)

# A document that prints quantity and unit price does not need a separate line-total column.
derived_total = doc([item(total=0)], total=20)
_cleaned, problems, notes, _omitted = reconciliation._sanitize_and_evaluate_document(
    derived_total,
    supplier_hint="ООО ТЕСТ",
    date_hint="2026-07-19",
    invoice_hint="1",
)
assert problems == [] and notes == []
assert _cleaned["items"][0]["line_total"] == 20.0
assert _cleaned["items"][0]["line_total_derived"] is True

# A gap in the supplier's printed № column is not a missing product.
printed_gap = doc([
    item(row=1, total=20),
    item(row=2, total=20, barcode="4601234567886"),
    item(row=3, total=20, barcode="4601234567879"),
    item(row=5, total=20, barcode="4601234567862"),
], total=80)
_cleaned, problems, notes, _omitted = reconciliation._sanitize_and_evaluate_document(
    printed_gap,
    supplier_hint="ООО ТЕСТ",
    date_hint="2026-07-19",
    invoice_hint="1",
)
assert problems == [] and notes == []
assert [row["source_row"] for row in _cleaned["items"]] == [1, 2, 3, 4]
assert _cleaned["items"][3]["document_row_number"] == 5

# A derived row total still cannot hide a genuinely mismatching document total.
missing_total = doc([item(total=0)], total=25)
_cleaned, problems, notes, _omitted = reconciliation._sanitize_and_evaluate_document(
    missing_total,
    supplier_hint="ООО ТЕСТ",
    date_hint="2026-07-19",
    invoice_hint="1",
)
assert problems == [1]
blockers = reconciliation._blocking_quality_notes(notes)
reviewable = reconciliation._reviewable_quality_notes(notes)
assert blockers
assert blockers == reviewable
assert any("сумма строк" in note for note in blockers)
assert not any("нет финальной суммы строки" in note for note in blockers)

# A cropped audit must never erase valid values merely because the model could
# not read them from the fragment. This is the regression fixed in v1.22.7at.
destructive_audit = {
    "supplier": "",
    "invoice_date": "",
    "invoice_number": "",
    "document_total": 0,
    "checked_rows": [1],
    "rows": [{
        "source_row": 1,
        "source_page": 1,
        "raw_name": "",
        "article": "",
        "barcodes": [],
        "quantity": 0,
        "unit": "",
        "line_total": 0,
        "status": "uncertain",
        "uncertain_fields": ["raw_name", "quantity", "line_total"],
        "note": "Фрагмент не читается",
    }],
    "warnings": [],
}
original = doc([item()])
updated, changed, uncertain, barcode_omitted = reconciliation.apply_audit(original, destructive_audit)
row = updated["items"][0]
assert row["raw_name"] == "ТОВАР"
assert row["quantity"] == 2.0
assert row["line_total"] == 20.0
assert row["unit"] == "шт"
assert row["article"] == "A1"
assert row["barcodes"] == ["4601234567893"]
assert updated["document_total"] == 20.0
assert uncertain == [1] and barcode_omitted == []
assert "ignored_empty_raw_name" in changed[1]
cleaned, problems, notes, _ = reconciliation._sanitize_and_evaluate_document(
    updated, supplier_hint="ООО ТЕСТ", date_hint="2026-07-19", invoice_hint="1"
)
assert problems == [] and notes == []

print("INVOICE_AI_RECONCILIATION_TESTS_OK")
