#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Operator-facing readiness gate for tomorrow's receipt workflows."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
from typing import Iterable

import requests

from sai_runtime_paths import DB_PATH, PRIVATE_CONFIG_PATH, ROOT_DIR
from sai_version import APP_VERSION


SCENARIOS = {
    "automatic": (
        "run_receipt_full_cycle_rehearsal_tests.py",
        "run_automatic_receipt_readiness_tests.py",
        "run_core_v2_refactor_tests.py",
        "run_receipt_hub_refactor_tests.py",
        "run_catalog_ready_tests.py",
        "run_product_name_tests.py",
        "run_invoice_ai_tests.py",
        "run_self_tests.py",
    ),
    "semi": (
        "run_receipt_full_cycle_rehearsal_tests.py",
        "run_semi_auto_receipt_refactor_tests.py",
        "run_core_v2_refactor_tests.py",
        "run_receipt_hub_refactor_tests.py",
        "run_barcode_core_refactor_tests.py",
        "run_product_name_tests.py",
        "run_self_tests.py",
    ),
}

LABELS = {
    "automatic": "АВТОМАТИЧЕСКИЙ ПРИВОЗ",
    "semi": "ПОЛУАВТОМАТИЧЕСКИЙ ПРИВОЗ",
    "all": "ОБА СЦЕНАРИЯ ПРИВОЗА",
}


class Output:
    def __init__(self, path: Path):
        self.path = path
        self.lines: list[str] = []

    def write(self, text: str = "") -> None:
        print(text, flush=True)
        self.lines.append(text)
        self.path.write_text("\n".join(self.lines) + "\n", encoding="utf-8")


def _private_config() -> dict:
    try:
        data = json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _runtime_checks(out: Output, *, live: bool) -> list[str]:
    errors: list[str] = []
    out.write("[1/3] Проверяю готовность этого компьютера…")
    try:
        import PySide6  # noqa: F401
        out.write("  PASS  Интерфейс PySide6 доступен")
    except Exception:
        errors.append("Не найден PySide6 в выбранном Python SAI")
        out.write("  FAIL  Интерфейс PySide6 недоступен")

    cfg = _private_config()
    required = {
        "sigma_login": "логин SIGMA",
        "sigma_password": "пароль SIGMA",
        "sigma_company_key": "ключ компании SIGMA",
        "sigma_api_token": "API-токен каталога SIGMA",
    }
    missing = [label for key, label in required.items() if not str(cfg.get(key) or "").strip()]
    if missing:
        errors.append("Не заполнены: " + ", ".join(missing))
        out.write("  FAIL  Настройки SIGMA заполнены не полностью")
    else:
        out.write("  PASS  Настройки SIGMA заполнены")

    try:
        con = sqlite3.connect(str(DB_PATH), timeout=5)
        products = int(con.execute("SELECT COUNT(*) FROM products").fetchone()[0])
        barcodes = int(con.execute("SELECT COUNT(*) FROM barcodes").fetchone()[0])
        con.close()
        if products <= 0 or barcodes <= 0:
            raise RuntimeError("каталог пуст")
        out.write(f"  PASS  Локальный каталог: товаров {products}, штрихкодов {barcodes}")
    except Exception as exc:
        errors.append(f"Локальный каталог не готов: {exc}")
        out.write("  FAIL  Локальный каталог не готов")

    if live and not missing:
        try:
            company = str(cfg["sigma_company_key"]).strip()
            token = str(cfg["sigma_api_token"]).strip()
            response = requests.get(
                f"https://api.sigma.ru/v1/companies/{company}/sell-points",
                headers={"Accept": "application/json", "X-Api-Key": token, "User-Agent": f"SAI-Readiness/{APP_VERSION}"},
                timeout=20,
            )
            if response.status_code != 200:
                raise RuntimeError(f"HTTP {response.status_code}")
            out.write("  PASS  SIGMA отвечает на безопасный запрос чтения")
        except Exception as exc:
            errors.append(f"SIGMA недоступна для чтения: {exc}")
            out.write("  FAIL  Нет подтверждённой связи чтения с SIGMA")
    elif not live:
        out.write("  SKIP  Проверка сети отключена")
    return errors


def _scripts_for(scenario: str) -> tuple[str, ...]:
    if scenario in SCENARIOS:
        return SCENARIOS[scenario]
    result = []
    for key in ("automatic", "semi"):
        for script in SCENARIOS[key]:
            if script not in result:
                result.append(script)
    return tuple(result)


def _run_tests(out: Output, scenario: str) -> list[str]:
    failures = []
    scripts = _scripts_for(scenario)
    out.write("")
    out.write(f"[2/3] Прогоняю безопасный стенд: {len(scripts)} тестовых наборов…")
    with tempfile.TemporaryDirectory(prefix="sai_receipt_readiness_") as temporary:
        env = os.environ.copy()
        env["SAI_USER_DATA_DIR"] = str(Path(temporary) / "user_data")
        env["QT_QPA_PLATFORM"] = "offscreen"
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        for index, script in enumerate(scripts, 1):
            out.write(f"  [{index}/{len(scripts)}] {script}")
            process = subprocess.run(
                [sys.executable, script],
                cwd=str(Path(__file__).resolve().parent),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=420,
            )
            for line in process.stdout.splitlines():
                out.write("      " + line)
            if process.returncode:
                failures.append(f"{script}: код {process.returncode}")
                out.write("      FAIL")
            else:
                out.write("      PASS")
    return failures


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("scenario", choices=("automatic", "semi", "all"))
    parser.add_argument("--no-live", action="store_true", help="Не проверять чтение SIGMA по сети")
    args = parser.parse_args(list(argv) if argv is not None else None)
    log_path = ROOT_DIR / "SAI_RECEIPT_READINESS_LAST_LOG.txt"
    out = Output(log_path)
    out.write("=" * 78)
    out.write(f"SAI {APP_VERSION} · ПРОВЕРКА: {LABELS[args.scenario]}")
    out.write(dt.datetime.now().astimezone().isoformat())
    out.write("Настоящий приход и запись в SIGMA НЕ выполняются.")
    out.write("Полный цикл безопасно репетируется на изолированной тестовой SIGMA.")
    out.write(f"Полный лог: {log_path}")
    out.write("=" * 78)

    errors = _runtime_checks(out, live=not args.no_live)
    errors.extend(_run_tests(out, args.scenario))
    out.write("")
    out.write("[3/3] Итог")
    out.write("=" * 78)
    if errors:
        out.write("НЕ ГОТОВ: обнаружены проблемы")
        for error in errors:
            out.write("  - " + error)
        out.write("Приход не запускайте, пока эти пункты не исправлены.")
        out.write("=" * 78)
        return 1
    out.write(f"ГОТОВ К КОНТРОЛИРУЕМОМУ ПРИВОЗУ: {LABELS[args.scenario]}")
    out.write("  PASS  Полный цикл выполнен в безопасной репетиции")
    out.write("  PASS  Этот компьютер, каталог и чтение SIGMA проверены")
    out.write("  НЕ ПРОВЕРЕНО  Реальная запись в черновик SIGMA")
    out.write("  НЕ ПРОВЕРЕНО  Конкретная накладная, сканер и физическая печать")
    out.write("Первый реальный приход начинайте с небольшой накладной и обязательного dry-run.")
    out.write("=" * 78)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
