#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Best-effort direct network mode for SAI/SIGMA.

The module deliberately disables HTTP(S) proxy discovery for the SAI process
and adds Chromium flags that bypass system proxy settings.  It does not and
cannot override a full-tunnel VPN adapter that replaces the Windows default
route; that requires split-tunnelling in the VPN client.
"""
from __future__ import annotations

import os
import urllib.request
from typing import Dict, Iterable, List

_PROXY_KEYS = (
    "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
    "http_proxy", "https_proxy", "all_proxy",
)

# Capture what was configured before SAI removed it.  urllib may also include
# Windows Internet Settings proxy values.
_ORIGINAL_ENV: Dict[str, str] = {k: str(os.environ.get(k) or "") for k in _PROXY_KEYS}
try:
    _ORIGINAL_SYSTEM_PROXIES = {str(k): str(v) for k, v in urllib.request.getproxies().items()}
except Exception:
    _ORIGINAL_SYSTEM_PROXIES = {}

_CONFIGURED = False
_REQUESTS_PATCHED = False


def direct_mode_enabled() -> bool:
    value = str(os.environ.get("SAI_SIGMA_DIRECT", "1") or "1").strip().lower()
    return value not in {"0", "false", "off", "no"}


def _patch_requests() -> None:
    """Make newly created requests sessions ignore environment/system proxies."""
    global _REQUESTS_PATCHED
    if _REQUESTS_PATCHED:
        return
    try:
        import requests
        session_cls = requests.sessions.Session
        if getattr(session_cls, "_sai_direct_network_patched", False):
            _REQUESTS_PATCHED = True
            return
        original_init = session_cls.__init__

        def direct_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            self.trust_env = False
            try:
                self.proxies.clear()
            except Exception:
                self.proxies = {}

        session_cls.__init__ = direct_init
        session_cls._sai_direct_network_patched = True
        _REQUESTS_PATCHED = True
    except Exception:
        # The launcher may run before requests is installed/importable.  A later
        # module call to configure_direct_network() will try again.
        return


def configure_direct_network() -> bool:
    """Enable direct mode for the current SAI process and all child processes."""
    global _CONFIGURED
    if not direct_mode_enabled():
        os.environ["SAI_DIRECT_NETWORK_ACTIVE"] = "0"
        return False

    for key in _PROXY_KEYS:
        os.environ.pop(key, None)
    # Both spellings are used by different libraries.  '*' means bypass proxy
    # for every destination, while explicit Session.trust_env=False protects
    # requests from Windows registry proxy discovery too.
    os.environ["NO_PROXY"] = "*"
    os.environ["no_proxy"] = "*"
    os.environ["SAI_DIRECT_NETWORK_ACTIVE"] = "1"
    _patch_requests()
    _CONFIGURED = True
    return True


def direct_chromium_args(existing: Iterable[str] | None = None) -> List[str]:
    """Return Chromium arguments that force direct connections, preserving args."""
    args: List[str] = []
    for value in existing or ():
        text = str(value or "").strip()
        if text and text not in args:
            args.append(text)
    if direct_mode_enabled():
        for value in (
            "--no-proxy-server",
            "--proxy-bypass-list=*",
        ):
            if value not in args:
                args.append(value)
    return args


def original_proxy_description() -> str:
    values = []
    for key, value in _ORIGINAL_ENV.items():
        if value:
            values.append(f"{key}={value}")
    for key, value in _ORIGINAL_SYSTEM_PROXIES.items():
        pair = f"system {key}={value}"
        if value and pair not in values:
            values.append(pair)
    return "; ".join(values) if values else "proxy settings were not detected"


def direct_mode_summary() -> str:
    if not direct_mode_enabled():
        return "disabled by SAI_SIGMA_DIRECT=0"
    configure_direct_network()
    return (
        "requests: trust_env=False; proxy variables cleared; "
        "Chromium: --no-proxy-server; full-tunnel VPN adapter is not bypassed"
    )


# Importing the module is intentionally enough to protect scripts that are run
# directly instead of through sai_launcher.py.
configure_direct_network()
