#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Manager schedule and employee time tracking for the SAI staff module."""
from __future__ import annotations

import calendar
import datetime as dt

from PySide6.QtCore import Qt, QDate, QElapsedTimer, QMimeData, QRectF, QSettings, QTime, QTimer, Signal
from PySide6.QtGui import QColor, QDrag, QPainterPath, QPalette, QPen, QRegion
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QDoubleSpinBox,
    QFormLayout, QFrame, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMessageBox, QPushButton, QScrollArea, QStackedWidget, QStyledItemDelegate,
    QTabWidget, QTableWidget, QTableWidgetItem, QTimeEdit, QVBoxLayout, QWidget,
)

import sai_staff


MONTHS = ("", "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь")
WEEKDAYS = ("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")
SCALE_ROWS = {"compact": 38, "normal": 52, "large": 66}


def _money(value: float) -> str:
    return f"{value:,.0f} ₽".replace(",", " ")


def _add_months(value: dt.date, delta: int) -> dt.date:
    month_index = value.year * 12 + value.month - 1 + int(delta)
    year, month_zero = divmod(month_index, 12)
    return dt.date(year, month_zero + 1, 1)


class StaffScheduleTable(QTableWidget):
    """Schedule grid with deliberate press-and-drag employee ordering."""

    employeeMoved = Signal(str, int)
    gridActivated = Signal(int, int)
    pointerLeft = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._pressed_row = -1
        self._press_pos = None
        self._hold = QElapsedTimer()
        self._drag_started = False
        self.setAcceptDrops(True)
        self.viewport().setAcceptDrops(True)
        self.setMouseTracking(True)

    def mousePressEvent(self, event):
        index = self.indexAt(event.position().toPoint())
        if event.button() == Qt.MouseButton.LeftButton and index.isValid() and index.column() == 0:
            self._pressed_row = index.row()
            self._press_pos = event.position().toPoint()
            self._hold.start()
            self._drag_started = False
        else:
            self._pressed_row = -1
            self._press_pos = None
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._pressed_row >= 0 and self._press_pos is not None and self._hold.isValid() and self._hold.elapsed() >= 350:
            item = self.item(self._pressed_row, 0)
            payload = item.data(Qt.ItemDataRole.UserRole) if item else None
            if isinstance(payload, dict) and payload.get("kind") == "employee":
                mime = QMimeData()
                mime.setData("application/x-sai-staff-employee", str(payload.get("employee_id") or "").encode("utf-8"))
                drag = QDrag(self)
                drag.setMimeData(mime)
                self._drag_started = True
                drag.exec(Qt.DropAction.MoveAction)
                self._pressed_row = -1
                return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        index = self.indexAt(event.position().toPoint())
        should_activate = (
            event.button() == Qt.MouseButton.LeftButton
            and index.isValid()
            and not self._drag_started
        )
        super().mouseReleaseEvent(event)
        if should_activate:
            self.gridActivated.emit(index.row(), index.column())
        self._pressed_row = -1
        self._press_pos = None
        self._drag_started = False

    def dragEnterEvent(self, event):
        if event.mimeData().hasFormat("application/x-sai-staff-employee"):
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasFormat("application/x-sai-staff-employee"):
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if not event.mimeData().hasFormat("application/x-sai-staff-employee"):
            super().dropEvent(event)
            return
        employee_id = bytes(event.mimeData().data("application/x-sai-staff-employee")).decode("utf-8", "ignore")
        target = self.indexAt(event.position().toPoint()).row()
        if target < 0:
            target = max(0, self.rowCount() - 1)
        target = min(target, max(0, self.rowCount() - 1))
        self.employeeMoved.emit(employee_id, target)
        event.acceptProposedAction()

    def leaveEvent(self, event):
        self.pointerLeft.emit()
        super().leaveEvent(event)


class ScheduleGridDelegate(QStyledItemDelegate):
    """Draw one shared separator per cell without replacing its background."""

    def paint(self, painter, option, index):
        super().paint(painter, option, index)
        painter.save()
        payload = index.data(Qt.ItemDataRole.UserRole)
        if isinstance(payload, dict) and payload.get("kind") == "shift":
            if payload.get("shift_ids"):
                painter.fillRect(option.rect, QColor("#2563eb"))
            else:
                raw_date = str(payload.get("date") or "")
                if raw_date == dt.date.today().isoformat():
                    painter.fillRect(option.rect, QColor("#fff4cc"))
                else:
                    try:
                        date = dt.date.fromisoformat(raw_date)
                        if ((date.day - 1) // 7) % 2:
                            painter.fillRect(option.rect, QColor("#f7f9fc"))
                    except ValueError:
                        pass
        elif isinstance(payload, dict) and payload.get("kind") == "employee" and index.data(Qt.ItemDataRole.BackgroundRole):
            painter.fillRect(option.rect, QColor("#eaf2ff"))
            painter.setPen(option.palette.color(QPalette.ColorRole.Text))
            painter.drawText(option.rect.adjusted(10, 0, -6, 0), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, str(index.data() or ""))
        painter.setPen(QPen(option.palette.color(QPalette.ColorRole.Midlight), 1))
        painter.drawLine(option.rect.topRight(), option.rect.bottomRight())
        painter.drawLine(option.rect.bottomLeft(), option.rect.bottomRight())
        painter.restore()


class RoundedScheduleShell(QFrame):
    """Clip the native table header and viewport to the same rounded outline."""

    def resizeEvent(self, event):
        super().resizeEvent(event)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect().adjusted(0, 0, -1, -1)), 14, 14)
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))


class EmployeeDialog(QDialog):
    def __init__(self, parent=None, employee=None):
        super().__init__(parent)
        self.employee = employee or {}
        self.delete_requested = False
        self.setWindowTitle("Сотрудник")
        self.setMinimumWidth(440)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(16)
        title = QLabel("Карточка сотрудника" if self.employee else "Новый сотрудник")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        form = QFormLayout()
        form.setSpacing(12)
        self.name = QLineEdit(str(self.employee.get("name") or ""))
        self.name.setObjectName("WorkbenchInput")
        self.name.setPlaceholderText("Имя и фамилия")
        self.role = QLineEdit(str(self.employee.get("role") or ""))
        self.role.setObjectName("WorkbenchInput")
        self.role.setPlaceholderText("Продавец, управляющий, специалист…")
        self.pay_type = QComboBox()
        self.pay_type.setObjectName("WorkbenchCombo")
        self.pay_type.addItem("Фиксированно за смену", "daily")
        self.pay_type.addItem("По фактически отработанным часам", "hourly")
        self.pay_type.setCurrentIndex(max(0, self.pay_type.findData(self.employee.get("pay_type") or "daily")))
        self.rate = QDoubleSpinBox()
        self.rate.setRange(0, 1_000_000)
        self.rate.setDecimals(2)
        self.rate.setSuffix(" ₽")
        self.rate.setValue(float(self.employee.get("pay_rate") or 2000))
        self.rate.setToolTip("Для фиксированного тарифа — сумма за смену; для почасового — сумма за час")
        form.addRow("Имя", self.name)
        form.addRow("Роль", self.role)
        form.addRow("Тариф", self.pay_type)
        form.addRow("Ставка", self.rate)
        layout.addLayout(form)
        note = QLabel("Почасовой сотрудник отмечает приход и уход в SAI EMP. Руководитель видит фактические часы в этом разделе.")
        note.setObjectName("WorkbenchNote")
        note.setWordWrap(True)
        layout.addWidget(note)
        actions = QHBoxLayout()
        if self.employee.get("id"):
            remove = QPushButton("Удалить сотрудника")
            remove.setObjectName("DangerButton")
            remove.clicked.connect(self.request_delete)
            actions.addWidget(remove)
        actions.addStretch(1)
        cancel = QPushButton("Отмена")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Сохранить")
        save.setObjectName("WorkbenchPrimaryButton")
        save.clicked.connect(self.accept)
        actions.addWidget(cancel)
        actions.addWidget(save)
        layout.addLayout(actions)

    def request_delete(self) -> None:
        self.delete_requested = True
        self.accept()


class ShiftDialog(QDialog):
    """Detailed shift editor; the calendar itself uses one-click toggles."""

    def __init__(self, people, parent=None, shift=None, initial_date=None):
        super().__init__(parent)
        self.shift = shift or {}
        self.delete_requested = False
        self.setWindowTitle("Смена")
        self.setMinimumWidth(420)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(12)
        self.employee = QComboBox()
        for row in people:
            self.employee.addItem(row["name"], row["id"])
        self.employee.setCurrentIndex(max(0, self.employee.findData(self.shift.get("employee_id"))))
        self.date = QDateEdit()
        self.date.setCalendarPopup(True)
        self.date.setDisplayFormat("dd.MM.yyyy")
        raw_date = self.shift.get("work_date") or initial_date or dt.date.today().isoformat()
        self.date.setDate(QDate.fromString(raw_date, "yyyy-MM-dd"))
        self.start = QTimeEdit()
        self.start.setDisplayFormat("HH:mm")
        self.start.setTime(QTime.fromString(self.shift.get("start_time") or "09:00", "HH:mm"))
        self.end = QTimeEdit()
        self.end.setDisplayFormat("HH:mm")
        self.end.setTime(QTime.fromString(self.shift.get("end_time") or "18:00", "HH:mm"))
        self.note = QLineEdit(str(self.shift.get("note") or ""))
        self.note.setPlaceholderText("Необязательно")
        form.addRow("Сотрудник", self.employee)
        form.addRow("Дата", self.date)
        form.addRow("Начало", self.start)
        form.addRow("Конец", self.end)
        form.addRow("Комментарий", self.note)
        layout.addLayout(form)
        actions = QHBoxLayout()
        if self.shift.get("id"):
            remove = QPushButton("Удалить смену")
            remove.setObjectName("DangerButton")
            remove.clicked.connect(self.remove_shift)
            actions.addWidget(remove)
        actions.addStretch(1)
        cancel = QPushButton("Отмена")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Сохранить смену")
        save.setObjectName("WorkbenchPrimaryButton")
        save.clicked.connect(self.accept)
        actions.addWidget(cancel)
        actions.addWidget(save)
        layout.addLayout(actions)

    def remove_shift(self) -> None:
        self.delete_requested = True
        self.accept()


class StaffPage(QWidget):
    """Manager workspace. The schedule is deliberately the primary view."""

    def __init__(self, parent_page=None):
        super().__init__()
        self.parent_page = parent_page
        self.anchor_date = dt.date.today().replace(day=1)
        self.view_mode = "month"
        self._schedule_tables: list[QTableWidget] = []
        self._build()
        self.refresh()

    def device_id(self) -> str:
        try:
            import sai_organization_sync
            from sai_pyside_preview import load_private_config
            return sai_organization_sync.SyncSettings.from_config(load_private_config()).device_id
        except Exception:
            return ""

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 12, 28, 18)
        root.setSpacing(0)
        root.addWidget(self._schedule_tab(), 0)
        root.addStretch(1)

    @staticmethod
    def _table(headers):
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.setShowGrid(False)
        table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        return table

    def _schedule_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        tools = QHBoxLayout()
        prev = QPushButton("‹")
        prev.setObjectName("SoftButton")
        prev.setFixedWidth(40)
        prev.setToolTip("Предыдущий период")
        prev.clicked.connect(lambda: self.move_period(-1))
        self.period_button = QPushButton()
        self.period_button.setObjectName("StaffMonthButton")
        self.period_button.setToolTip("Вернуться к текущему месяцу")
        self.period_button.clicked.connect(self.current_period)
        nxt = QPushButton("›")
        nxt.setObjectName("SoftButton")
        nxt.setFixedWidth(40)
        nxt.setToolTip("Следующий период")
        nxt.clicked.connect(lambda: self.move_period(1))
        tools.addSpacing(145)
        tools.addStretch(1)
        tools.addWidget(prev)
        tools.addWidget(self.period_button)
        tools.addWidget(nxt)
        tools.addStretch(1)
        layout.addLayout(tools)
        self.schedule_stack = QStackedWidget()
        empty = QFrame()
        empty.setObjectName("StaffEmptyState")
        empty_layout = QVBoxLayout(empty)
        empty_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_title = QLabel("Добавьте первого сотрудника")
        empty_title.setObjectName("EmptyStateTitle")
        empty_note = QLabel("После этого здесь появится календарь. Нажатие на ячейку назначает смену.")
        empty_note.setObjectName("PageSubtitle")
        empty_note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        empty_add = QPushButton("+ Добавить сотрудника")
        empty_add.setObjectName("WorkbenchPrimaryButton")
        empty_add.clicked.connect(self.add_employee)
        empty_layout.addWidget(empty_title, 0, Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(empty_note, 0, Qt.AlignmentFlag.AlignCenter)
        empty_layout.addWidget(empty_add, 0, Qt.AlignmentFlag.AlignCenter)
        self.schedule_stack.addWidget(empty)
        self.schedule_table = StaffScheduleTable()
        self.schedule_table.setColumnCount(1)
        self.schedule_table.setHorizontalHeaderLabels(["Сотрудник"])
        self.schedule_table.verticalHeader().setVisible(False)
        self.schedule_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.schedule_table.setObjectName("StaffScheduleGrid")
        self.schedule_table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.schedule_table.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.schedule_table.setAlternatingRowColors(False)
        self.schedule_table.setShowGrid(False)
        self.schedule_table.setItemDelegate(ScheduleGridDelegate(self.schedule_table))
        self.schedule_table.horizontalHeader().setFixedHeight(48)
        self.schedule_table.gridActivated.connect(self.toggle_schedule_cell)
        self.schedule_table.employeeMoved.connect(self.reorder_employee)
        self.schedule_table.cellEntered.connect(self.hover_schedule_cell)
        self.schedule_table.pointerLeft.connect(self.clear_employee_hover)
        self._hovered_employee_row = -1
        self.schedule_stack.addWidget(self.schedule_table)
        self.schedule_shell = RoundedScheduleShell()
        self.schedule_shell.setObjectName("StaffScheduleShell")
        shell_layout = QVBoxLayout(self.schedule_shell)
        shell_layout.setContentsMargins(1, 1, 1, 1)
        shell_layout.setSpacing(0)
        shell_layout.addWidget(self.schedule_stack)
        layout.addWidget(self.schedule_shell, 0)
        self.inline_add_employee = QPushButton("＋ Новый сотрудник")
        self.inline_add_employee.setObjectName("StaffAddEmployeeButton")
        self.inline_add_employee.setCursor(Qt.CursorShape.PointingHandCursor)
        self.inline_add_employee.clicked.connect(self.add_employee)
        layout.addWidget(self.inline_add_employee, 0, Qt.AlignmentFlag.AlignLeft)
        return page

    def _time_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        layout.setSpacing(10)
        timer_card = QFrame()
        timer_card.setObjectName("WorkbenchCard")
        row = QHBoxLayout(timer_card)
        row.setContentsMargins(16, 12, 16, 12)
        self.person = QComboBox()
        self.person.setMinimumWidth(220)
        self.person.currentIndexChanged.connect(self.current_person_changed)
        self.timer_status = QLabel("Таймер не запущен")
        self.timer_status.setObjectName("InlineStatus")
        self.timer = QPushButton("Отметить приход")
        self.timer.setObjectName("WorkbenchPrimaryButton")
        self.timer.clicked.connect(self.toggle_timer)
        row.addWidget(QLabel("Сотрудник"))
        row.addWidget(self.person)
        row.addWidget(self.timer_status, 1)
        row.addWidget(self.timer)
        layout.addWidget(timer_card)
        note = QLabel("Это те же отметки, которые почасовой сотрудник делает в SAI EMP. Оплата считается по фактическому времени между приходом и уходом.")
        note.setObjectName("WorkbenchNote")
        note.setWordWrap(True)
        layout.addWidget(note)
        self.time_table = self._table(["Сотрудник", "Приход", "Уход", "Часов"])
        self.time_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.time_table, 1)
        return page

    def _expense_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        tools = QHBoxLayout()
        self.expense_name = QLineEdit()
        self.expense_name.setPlaceholderText("Что куплено")
        self.expense_qty = QDoubleSpinBox()
        self.expense_qty.setRange(.01, 100000)
        self.expense_qty.setValue(1)
        self.expense_qty.setPrefix("× ")
        self.expense_price = QDoubleSpinBox()
        self.expense_price.setRange(0, 10_000_000)
        self.expense_price.setSuffix(" ₽")
        add = QPushButton("Добавить покупку")
        add.setObjectName("WorkbenchPrimaryButton")
        add.clicked.connect(self.add_expense)
        tools.addWidget(self.expense_name, 1)
        tools.addWidget(self.expense_qty)
        tools.addWidget(self.expense_price)
        tools.addWidget(add)
        layout.addLayout(tools)
        self.expense_table = self._table(["Дата", "Сотрудник", "Покупка", "Количество", "Цена", "Сумма", "Статус"])
        self.expense_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.expense_table.cellDoubleClicked.connect(self.toggle_reimbursed)
        layout.addWidget(self.expense_table, 1)
        hint = QLabel("Двойной щелчок по покупке отмечает её как возвращённую или снова ожидающую возврата.")
        hint.setObjectName("WorkbenchNote")
        layout.addWidget(hint)
        return page

    def _payroll_tab(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 12, 0, 0)
        tools = QHBoxLayout()
        self.pay_start = QDateEdit(QDate.currentDate().addDays(1 - QDate.currentDate().day()))
        self.pay_start.setCalendarPopup(True)
        self.pay_end = QDateEdit(QDate.currentDate())
        self.pay_end.setCalendarPopup(True)
        refresh = QPushButton("Рассчитать")
        refresh.setObjectName("WorkbenchPrimaryButton")
        refresh.clicked.connect(self.refresh_payroll)
        tools.addWidget(QLabel("Период:"))
        tools.addWidget(self.pay_start)
        tools.addWidget(QLabel("—"))
        tools.addWidget(self.pay_end)
        tools.addWidget(refresh)
        tools.addStretch(1)
        layout.addLayout(tools)
        self.pay_table = self._table(["Сотрудник", "Тариф", "Смен", "Часов", "Зарплата", "Вернуть за покупки", "Итого"])
        self.pay_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.pay_table)
        return page

    def refresh(self):
        sai_staff.init_staff_schema()
        self.refresh_schedule()

    def notify(self, text, kind="success"):
        if self.parent_page and hasattr(self.parent_page, "notify"):
            self.parent_page.notify("Сотрудники", text, kind)

    def add_employee(self):
        dialog = EmployeeDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            sai_staff.save_employee(dialog.name.text(), dialog.role.text(), dialog.pay_type.currentData(), dialog.rate.value(), device_id=self.device_id())
            self.refresh()
            self.notify("Сотрудник добавлен.")
        except Exception as exc:
            QMessageBox.warning(self, "Сотрудники", str(exc))

    def edit_employee(self, employee_id):
        employee = next((row for row in sai_staff.employees(include_inactive=True) if row["id"] == employee_id), None)
        if not employee:
            return
        dialog = EmployeeDialog(self, employee)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            if dialog.delete_requested:
                sai_staff.delete_record("employees", employee_id, device_id=self.device_id())
                self.refresh()
                self.notify("Сотрудник удалён.")
                return
            sai_staff.save_employee(dialog.name.text(), dialog.role.text(), dialog.pay_type.currentData(), dialog.rate.value(), employee_id=employee_id, device_id=self.device_id())
            self.refresh()
            self.notify("Карточка сотрудника сохранена.")
        except Exception as exc:
            QMessageBox.warning(self, "Сотрудники", str(exc))

    def add_shift(self, initial_date=None, shift=None):
        people = sai_staff.employees()
        if not people:
            self.add_employee()
            people = sai_staff.employees()
        if not people:
            return
        dialog = ShiftDialog(people, self, shift=shift, initial_date=initial_date)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        if dialog.delete_requested:
            sai_staff.delete_record("shifts", str((shift or {}).get("id") or ""), device_id=self.device_id())
            self.refresh()
            self.notify("Смена удалена.")
            return
        sai_staff.save_shift(dialog.employee.currentData(), dialog.date.date().toString("yyyy-MM-dd"), dialog.start.time().toString("HH:mm"), dialog.end.time().toString("HH:mm"), dialog.note.text(), shift_id=str((shift or {}).get("id") or ""), device_id=self.device_id())
        self.refresh()
        self.notify("График сохранён.")

    def move_period(self, delta: int) -> None:
        self.anchor_date = _add_months(self.anchor_date, int(delta))
        self.refresh_schedule(reset_scroll=True)

    def current_period(self) -> None:
        today = dt.date.today()
        self.anchor_date = today.replace(day=1)
        self.refresh_schedule(reset_scroll=True)

    def _render_schedule_grid(self, dates, people, shifts) -> None:
        table = self.schedule_table
        table.clear()
        table.setColumnCount(len(dates) + 1)
        table.setRowCount(len(people))
        table.setHorizontalHeaderLabels(["Сотрудник"] + [f"{WEEKDAYS[date.weekday()]}\n{date.day:02d}" for date in dates])
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
        table.horizontalHeader().setMinimumSectionSize(18)
        for column in range(1, len(dates) + 1):
            table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeMode.Fixed)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        table.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        cell_size, name_width = self._schedule_dimensions(len(dates))
        table.setColumnWidth(0, name_width)
        self.inline_add_employee.setFixedWidth(name_width)
        for column in range(1, len(dates) + 1):
            table.setColumnWidth(column, cell_size)
        shift_map = {}
        for shift in shifts:
            shift_map.setdefault((shift["employee_id"], shift["work_date"]), []).append(shift)
        today = dt.date.today()
        for row_index, person in enumerate(people):
            name_item = QTableWidgetItem(person["name"])
            name_item.setData(Qt.ItemDataRole.UserRole, {"employee_id": person["id"], "kind": "employee"})
            name_item.setToolTip("Нажмите, чтобы изменить карточку сотрудника")
            table.setItem(row_index, 0, name_item)
            table.setRowHeight(row_index, cell_size)
            for day_index, date in enumerate(dates):
                matches = shift_map.get((person["id"], date.isoformat()), [])
                text = ""
                cell = QTableWidgetItem(text)
                cell.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                cell.setData(Qt.ItemDataRole.UserRole, {"employee_id": person["id"], "date": date.isoformat(), "shift_ids": [item["id"] for item in matches], "kind": "shift"})
                if matches:
                    cell.setBackground(QColor("#2563eb"))
                    cell.setForeground(QColor("#ffffff"))
                    font = cell.font()
                    font.setBold(True)
                    cell.setFont(font)
                    intervals = ", ".join(f"{item['start_time']}–{item['end_time']}" for item in matches)
                    cell.setToolTip(f"{date:%d.%m.%Y}: {intervals}. Нажмите, чтобы снять смену.")
                elif date == today:
                    cell.setBackground(QColor("#fff4cc"))
                    cell.setToolTip("Сегодня. Нажмите, чтобы назначить смену.")
                else:
                    week_index = (date - dates[0]).days // 7
                    if week_index % 2:
                        cell.setBackground(QColor("#f7f9fc"))
                    cell.setToolTip("Нажмите, чтобы назначить смену.")
                table.setItem(row_index, day_index + 1, cell)
        self._schedule_tables = [table]
        table.setFixedHeight(48 + len(people) * cell_size + 2)
        self.schedule_stack.setFixedHeight(table.height())
        self.schedule_shell.setFixedHeight(table.height() + 2)

    def _schedule_dimensions(self, day_count: int) -> tuple[int, int]:
        viewport_width = self.schedule_table.viewport().width()
        if viewport_width < 600:
            viewport_width = max(620, self.width() - 58)
        minimum_name_width = 125
        cell_size = max(24, (viewport_width - minimum_name_width) // max(1, day_count))
        name_width = viewport_width - cell_size * day_count
        return cell_size, max(minimum_name_width, name_width)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, "schedule_table", None) and self.schedule_table.columnCount() > 1:
            QTimer.singleShot(0, self.refresh_schedule)

    def toggle_schedule_cell(self, row: int, column: int) -> None:
        table = self.schedule_table
        item = table.item(row, column)
        payload = item.data(Qt.ItemDataRole.UserRole) if item else None
        if not isinstance(payload, dict):
            return
        employee_id = str(payload.get("employee_id") or "")
        if payload.get("kind") == "employee" or column == 0:
            self.edit_employee(employee_id)
            return
        try:
            shift_ids = [str(value) for value in payload.get("shift_ids") or [] if str(value)]
            if shift_ids:
                for shift_id in shift_ids:
                    sai_staff.delete_record("shifts", shift_id, device_id=self.device_id())
            else:
                sai_staff.save_shift(employee_id, str(payload.get("date") or ""), "09:00", "18:00", device_id=self.device_id())
            self.refresh_schedule()
        except Exception as exc:
            QMessageBox.warning(self, "График", str(exc))

    def hover_schedule_cell(self, row: int, column: int) -> None:
        self.clear_employee_hover()
        if column != 0:
            return
        item = self.schedule_table.item(row, 0)
        payload = item.data(Qt.ItemDataRole.UserRole) if item else None
        if isinstance(payload, dict) and payload.get("kind") == "employee":
            item.setBackground(QColor("#eaf2ff"))
            self._hovered_employee_row = row

    def clear_employee_hover(self) -> None:
        if self._hovered_employee_row < 0:
            return
        item = self.schedule_table.item(self._hovered_employee_row, 0)
        if item:
            item.setData(Qt.ItemDataRole.BackgroundRole, None)
        self._hovered_employee_row = -1

    def reorder_employee(self, employee_id: str, target_row: int) -> None:
        try:
            sai_staff.reorder_employee(employee_id, target_row, device_id=self.device_id())
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "Сотрудники", str(exc))

    def refresh_schedule(self, reset_scroll: bool = False):
        del reset_scroll
        people = sai_staff.employees()
        self.schedule_stack.setCurrentIndex(1 if people else 0)
        if not people:
            self._schedule_tables = []
            self.period_button.setText(f"{MONTHS[self.anchor_date.month]} {self.anchor_date.year}")
            return
        first = self.anchor_date.replace(day=1)
        last = dt.date(first.year, first.month, calendar.monthrange(first.year, first.month)[1])
        dates = [first + dt.timedelta(days=index) for index in range((last - first).days + 1)]
        self.period_button.setText(f"{MONTHS[first.month]} {first.year}")
        range_start, range_end = dates[0], dates[-1]
        shifts = sai_staff.shifts_between(range_start.isoformat(), range_end.isoformat())
        self._render_schedule_grid(dates, people, shifts)

    def toggle_timer(self):
        employee_id = self.person.currentData()
        if not employee_id:
            QMessageBox.warning(self, "Рабочие часы", "Сначала добавьте и выберите сотрудника.")
            return
        try:
            if sai_staff.running_entry(employee_id):
                hours = sai_staff.stop_timer(employee_id, device_id=self.device_id())
                self.notify(f"Уход зарегистрирован: {hours:.2f} ч.")
            else:
                sai_staff.start_timer(employee_id, device_id=self.device_id())
                self.notify("Приход зарегистрирован.")
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "Рабочие часы", str(exc))

    def current_person_changed(self):
        QSettings("SAI", "SAI").setValue("staff/current_employee_id", str(self.person.currentData() or ""))
        self.refresh_timer()

    def refresh_timer(self):
        entry = sai_staff.running_entry(str(self.person.currentData() or "")) if self.person.count() else None
        if not entry:
            self.timer.setText("Отметить приход")
            self.timer_status.setText("Сейчас не на работе")
            return
        elapsed = dt.datetime.now().astimezone() - dt.datetime.fromisoformat(entry["started_at"])
        seconds = max(0, int(elapsed.total_seconds()))
        self.timer.setText("Отметить уход")
        self.timer_status.setText(f"На работе · {seconds // 3600:02d}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}")

    def period(self):
        return (dt.date.today() - dt.timedelta(days=30)).isoformat(), dt.date.today().isoformat()

    def refresh_time(self):
        rows = sai_staff.time_entries_between(*self.period())
        self.time_table.setRowCount(len(rows))
        now = dt.datetime.now().astimezone()
        for row_index, row in enumerate(rows):
            start = dt.datetime.fromisoformat(row["started_at"])
            end = dt.datetime.fromisoformat(row["ended_at"]) if row.get("ended_at") else now
            values = (row["employee_name"], start.strftime("%d.%m.%Y %H:%M"), end.strftime("%d.%m.%Y %H:%M") if row.get("ended_at") else "Сейчас", f"{max(0, (end - start).total_seconds() / 3600):.2f}")
            for column, value in enumerate(values):
                self.time_table.setItem(row_index, column, QTableWidgetItem(str(value)))

    def add_expense(self):
        try:
            sai_staff.add_expense(str(self.person.currentData() or ""), self.expense_name.text(), self.expense_qty.value(), self.expense_price.value(), device_id=self.device_id())
            self.expense_name.clear()
            self.expense_price.setValue(0)
            self.refresh()
            self.notify("Покупка добавлена к возврату.")
        except Exception as exc:
            QMessageBox.warning(self, "Покупки", str(exc))

    def refresh_expenses(self):
        rows = sai_staff.expenses_between(*self.period())
        self._expense_rows = rows
        self.expense_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            values = (str(row["purchased_at"])[0:10], row["employee_name"], row["name"], f"{float(row['quantity']):g}", _money(float(row["unit_price"])), _money(float(row["quantity"]) * float(row["unit_price"])), "Возвращено" if row["reimbursed"] else "К возврату")
            for column, value in enumerate(values):
                self.expense_table.setItem(row_index, column, QTableWidgetItem(str(value)))

    def toggle_reimbursed(self, row, _column):
        if row >= len(getattr(self, "_expense_rows", [])):
            return
        item = self._expense_rows[row]
        sai_staff.set_expense_reimbursed(item["id"], not bool(item["reimbursed"]), device_id=self.device_id())
        self.refresh_expenses()
        self.refresh_payroll()

    def refresh_payroll(self):
        rows = sai_staff.payroll(self.pay_start.date().toString("yyyy-MM-dd"), self.pay_end.date().toString("yyyy-MM-dd"))
        self.pay_table.setRowCount(len(rows))
        for row_index, row in enumerate(rows):
            method = f"{_money(row.rate)}/час" if row.pay_type == "hourly" else f"{_money(row.rate)}/смена"
            values = (row.name, method, str(row.days), f"{row.hours:.2f}", _money(row.salary), _money(row.expenses), _money(row.total))
            for column, value in enumerate(values):
                self.pay_table.setItem(row_index, column, QTableWidgetItem(str(value)))


class EmployeeClockPage(QWidget):
    """Reusable SAI EMP home screen bound to one authenticated employee."""

    def __init__(self, employee_id: str, parent_page=None):
        super().__init__()
        self.employee_id = str(employee_id or "")
        self.parent_page = parent_page
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 32, 32, 32)
        layout.setSpacing(16)
        person = next((row for row in sai_staff.employees(include_inactive=True) if row["id"] == self.employee_id), {})
        title = QLabel(str(person.get("name") or "Рабочие часы"))
        title.setObjectName("PageTitle")
        layout.addWidget(title)
        self.status = QLabel()
        self.status.setObjectName("InlineStatus")
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.action = QPushButton()
        self.action.setObjectName("WorkbenchPrimaryButton")
        self.action.setMinimumHeight(72)
        self.action.clicked.connect(self.toggle)
        layout.addStretch(1)
        layout.addWidget(self.status)
        layout.addWidget(self.action)
        layout.addStretch(1)
        self.clock = QTimer(self)
        self.clock.setInterval(1000)
        self.clock.timeout.connect(self.refresh)
        self.clock.start()
        self.refresh()

    def refresh(self):
        entry = sai_staff.running_entry(self.employee_id)
        if not entry:
            self.status.setText("Сейчас вы не на работе")
            self.action.setText("Я пришёл на работу")
            return
        elapsed = dt.datetime.now().astimezone() - dt.datetime.fromisoformat(entry["started_at"])
        seconds = max(0, int(elapsed.total_seconds()))
        self.status.setText(f"На работе · {seconds // 3600:02d}:{seconds % 3600 // 60:02d}:{seconds % 60:02d}")
        self.action.setText("Я ухожу с работы")

    def toggle(self):
        try:
            if sai_staff.running_entry(self.employee_id):
                sai_staff.stop_timer(self.employee_id)
            else:
                sai_staff.start_timer(self.employee_id)
            self.refresh()
        except Exception as exc:
            QMessageBox.warning(self, "Рабочие часы", str(exc))


__all__ = ["EmployeeClockPage", "EmployeeDialog", "ShiftDialog", "StaffPage"]
