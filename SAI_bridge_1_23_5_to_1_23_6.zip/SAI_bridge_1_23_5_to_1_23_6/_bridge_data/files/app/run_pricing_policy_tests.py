#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent boundary tests for the shared SAI retail pricing policy."""
from __future__ import annotations

from sai_converter import calc_sale_price
from sai_core_v2.free_receipt import price_forecast
from sai_core_v2.manual_receipt import round_sale_from_purchase
from sai_core_v2.pricing import (
    LOW_PURCHASE_THRESHOLD,
    LOW_RETAIL_THRESHOLD,
    RETAIL_PRICE_STEP,
    sale_price_from_purchase,
)


assert str(LOW_RETAIL_THRESHOLD) == "25"
assert LOW_PURCHASE_THRESHOLD == LOW_RETAIL_THRESHOLD
assert str(RETAIL_PRICE_STEP) == "5"

cases = (
    # Calculated retail below 25 ₽: only remove kopecks upward.
    ("1,01", "0", 2.0),
    ("5", "60", 8.0),
    ("10", "60", 16.0),
    ("15", "60", 24.0),
    ("15.01", "60", 25.0),
    ("24.01", "0", 25.0),
    ("24.99", "0", 25.0),
    # Calculated retail from 25 ₽: nearest price ending in 0 or 5.
    ("25", "0", 25.0),
    ("25.01", "0", 25.0),
    ("27.49", "0", 25.0),
    ("27.50", "0", 30.0),
    ("27.51", "0", 30.0),
    ("32.10", "0", 30.0),
    ("32.50", "0", 35.0),
    ("50", "0", 50.0),
    ("50.01", "0", 50.0),
    ("52.49", "0", 50.0),
    ("52.50", "0", 55.0),
    ("52.51", "0", 55.0),
    ("50", "60", 80.0),
    ("51", "60", 80.0),
    ("100", "60", 160.0),
    ("101", "60", 160.0),
)

for purchase, markup, expected in cases:
    core = sale_price_from_purchase(purchase, markup)
    manual = round_sale_from_purchase(purchase, markup)
    converter = calc_sale_price(float(str(purchase).replace(",", ".")), float(markup))
    free = price_forecast(purchase, markup).sale
    assert core == expected, (purchase, markup, core, expected)
    assert manual == expected, (purchase, markup, manual, expected)
    assert converter == expected, (purchase, markup, converter, expected)
    assert free == expected, (purchase, markup, free, expected)

# A negative markup is clamped to zero.
assert sale_price_from_purchase("49.01", "-50") == 50.0
assert sale_price_from_purchase("51", "-50") == 50.0
assert sale_price_from_purchase("0", "60") == 0.0
assert sale_price_from_purchase("bad", "60") == 0.0

for purchase in ("0.01", "7.37", "15.01"):
    buy = float(purchase)
    result = sale_price_from_purchase(purchase, "60")
    raw = buy * 1.6
    assert result + 1e-9 >= raw, (purchase, raw, result)
    assert result.is_integer()

for purchase in ("25", "32.10", "51.11", "101.01", "999.99"):
    result = sale_price_from_purchase(purchase, "60")
    assert int(result) % 5 == 0

print("SAI pricing policy tests: OK")
