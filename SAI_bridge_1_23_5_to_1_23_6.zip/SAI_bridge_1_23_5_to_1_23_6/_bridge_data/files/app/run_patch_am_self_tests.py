#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7am."""
from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
app_dir = root / "app"
ui_path = app_dir / "sai_pyside_preview.py"
version_path = app_dir / "sai_version.py"
self_tests_path = app_dir / "run_self_tests.py"
wiki_dir = root / "SAI_Ecosystem_Wiki_v0.1"

for source in (ui_path, version_path, self_tests_path, Path(__file__)):
    ast.parse(source.read_text(encoding="utf-8-sig"), filename=str(source))

ui = ui_path.read_text(encoding="utf-8-sig")
version = version_path.read_text(encoding="utf-8-sig")
self_tests = self_tests_path.read_text(encoding="utf-8-sig")

assert 'VERSION = "1.22.7am"' in version
assert 'APP_VERSION == "v1.22.7am"' in self_tests

# The plus is no longer a font glyph: its two strokes use the exact circle center.
assert 'class DropPlusIndicator(QWidget):' in ui
assert 'center = circle.center()' in ui
assert 'painter.drawLine(QPointF(center.x() - half, center.y())' in ui
assert 'painter.drawLine(QPointF(center.x(), center.y() - half)' in ui
assert 'plus = DropPlusIndicator()' in ui
assert 'plus = QLabel("+")' not in ui
assert 'QLabel#InvoiceDropPlus' not in ui

# Only the outer table contour is rounded. Header sections remain rectangular,
# so they fill the clipped corner instead of punching transparent wedges into it.
assert 'class RoundedTableWidget(QTableWidget):' in ui
assert 'self.setMask(QRegion(path.toFillPolygon().toPolygon()))' in ui
assert 'QTableWidget QHeaderView::section:first' not in ui
assert 'QTableWidget QHeaderView::section:last' not in ui
assert 'border-top-left-radius: 15px;' not in ui
assert 'border-top-right-radius: 15px;' not in ui

manifest = json.loads((wiki_dir / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.4"
assert manifest["snapshot_sai_version"] == "1.22.7am"
assert "v1.22.7am" in (wiki_dir / "README.md").read_text(encoding="utf-8")
assert (wiki_dir / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.4 / SAI 1.22.7am")

print("PATCH_AM_SELF_TEST_OK")
