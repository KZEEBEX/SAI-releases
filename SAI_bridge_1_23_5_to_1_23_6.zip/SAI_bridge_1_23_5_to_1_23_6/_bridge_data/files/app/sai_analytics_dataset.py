#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Compact, privacy-conscious analytical dataset for SAI AI features."""
from __future__ import annotations

import datetime as dt
import json
import sqlite3
from pathlib import Path
from typing import Any

from sai_core_v2.sigma_warehouse import analytic_quantity_condition, analytics_archive_stats
from sai_runtime_paths import CACHE_DIR
from sai_sigma_session import atomic_json

DATASET_PATH = CACHE_DIR / "sai_analytics_ai_dataset.json"


def _number(value: Any) -> float:
    try:
        return round(float(value or 0), 2)
    except Exception:
        return 0.0


def build_ai_dataset(
    con: sqlite3.Connection, *, location_id: str, begin_date: str = "2026-01-01",
    product_limit: int = 750,
) -> dict[str, Any]:
    daily_rows = con.execute(
        """SELECT metric_date, net_revenue, receipt_count, average_check,
                  units_sold, returns_total, discount_total, cash_total, card_total
           FROM sigma_daily_metrics
           WHERE location_id=? AND metric_date>=? ORDER BY metric_date""",
        (location_id, begin_date),
    ).fetchall()
    quantity_filter = analytic_quantity_condition()
    if not daily_rows:
        daily_rows = con.execute(
            f"""SELECT substr(operation_time, 1, 10),
                       COALESCE(SUM(
                           CASE WHEN direction='return' THEN -1 ELSE 1 END *
                           COALESCE(CAST(line_total AS REAL),
                                    CAST(unit_price AS REAL) * CAST(quantity AS REAL), 0)
                       ), 0),
                       COUNT(DISTINCT CASE WHEN direction='sale' THEN operation_id END),
                       0,
                       COALESCE(SUM(CASE WHEN direction='sale' AND {quantity_filter}
                                         THEN CAST(quantity AS REAL) ELSE 0 END), 0),
                       0, 0, 0, 0
                FROM sigma_sale_lines
                WHERE operation_time>=?
                GROUP BY substr(operation_time, 1, 10)
                ORDER BY substr(operation_time, 1, 10)""",
            (begin_date,),
        ).fetchall()
    clean_units = {
        str(row[0]): _number(row[1])
        for row in con.execute(
            f"""SELECT substr(operation_time, 1, 10),
                       COALESCE(SUM(CASE WHEN direction='sale' AND {quantity_filter}
                                         THEN CAST(quantity AS REAL) ELSE 0 END), 0)
                FROM sigma_sale_lines WHERE operation_time>=?
                GROUP BY substr(operation_time, 1, 10)""",
            (begin_date,),
        )
    }
    daily = [
        {
            "date": str(row[0]), "revenue": _number(row[1]),
            "checks": int(row[2] or 0), "average_check": _number(row[3]),
            "units": clean_units.get(str(row[0]), 0.0), "returns": _number(row[5]),
            "discounts": _number(row[6]), "cash": _number(row[7]),
            "card": _number(row[8]),
        }
        for row in daily_rows
    ]
    for item in daily:
        if item["checks"] and not item["average_check"]:
            item["average_check"] = round(item["revenue"] / item["checks"], 2)
    monthly: dict[str, dict[str, Any]] = {}
    for item in daily:
        key = item["date"][:7]
        bucket = monthly.setdefault(key, {
            "month": key, "revenue": 0.0, "checks": 0, "units": 0.0,
            "returns": 0.0, "discounts": 0.0,
        })
        for field in ("revenue", "units", "returns", "discounts"):
            bucket[field] = round(float(bucket[field]) + float(item[field]), 2)
        bucket["checks"] += int(item["checks"])
    for bucket in monthly.values():
        bucket["average_check"] = round(
            float(bucket["revenue"]) / int(bucket["checks"]), 2
        ) if bucket["checks"] else 0.0

    product_rows = con.execute(
        f"""SELECT
               COALESCE(NULLIF(l.sai_product_id, ''), 'unlinked:' || l.product_name) AS product_key,
               COALESCE((SELECT p.name FROM product_identities i
                         JOIN products p ON p.sigma_id=i.external_id AND p.company_key=i.company_key
                         WHERE i.sai_product_id=l.sai_product_id LIMIT 1), l.product_name) AS product_name,
               SUM(CASE WHEN l.direction='return' THEN -CAST(l.quantity AS REAL)
                        ELSE CAST(l.quantity AS REAL) END) AS units,
               SUM(CASE WHEN l.direction='return' THEN -CAST(COALESCE(l.line_total, '0') AS REAL)
                        ELSE CAST(COALESCE(l.line_total, '0') AS REAL) END) AS revenue,
               MIN(l.operation_time), MAX(l.operation_time), COUNT(DISTINCT l.operation_id),
               COALESCE((SELECT CAST(s.quantity AS REAL) FROM sigma_stock_current s
                         WHERE s.sai_product_id=l.sai_product_id AND s.location_id=?), 0),
               COALESCE((SELECT CAST(s.buying_price AS REAL) FROM sigma_stock_current s
                         WHERE s.sai_product_id=l.sai_product_id AND s.location_id=?), 0),
               COALESCE((SELECT CAST(s.selling_price AS REAL) FROM sigma_stock_current s
                         WHERE s.sai_product_id=l.sai_product_id AND s.location_id=?), 0)
           FROM sigma_sale_lines l
           WHERE l.operation_time>=? AND {analytic_quantity_condition('l')}
           GROUP BY product_key, product_name
           ORDER BY revenue DESC, units DESC LIMIT ?""",
        (location_id, location_id, location_id, begin_date, max(1, int(product_limit))),
    ).fetchall()
    products = [
        {
            "product_id": str(row[0]), "name": str(row[1]),
            "units_sold": _number(row[2]), "revenue": _number(row[3]),
            "first_sale": str(row[4] or ""), "last_sale": str(row[5] or ""),
            "checks": int(row[6] or 0), "current_stock": _number(row[7]),
            "buying_price": _number(row[8]), "selling_price": _number(row[9]),
        }
        for row in product_rows
    ]
    excluded_row = con.execute(
        f"""SELECT COUNT(*),
                   COALESCE(SUM(CASE WHEN direction='return' THEN -1 ELSE 1 END *
                       COALESCE(CAST(line_total AS REAL),
                                CAST(unit_price AS REAL) * CAST(quantity AS REAL), 0)), 0),
                   COALESCE(SUM(CAST(quantity AS REAL)), 0)
            FROM sigma_sale_lines
            WHERE operation_time>=? AND NOT ({quantity_filter})""",
        (begin_date,),
    ).fetchone()
    totals = {
        "revenue": round(sum(float(item["revenue"]) for item in daily), 2),
        "checks": sum(int(item["checks"]) for item in daily),
        "units": round(sum(float(item["units"]) for item in daily), 2),
        "returns": round(sum(float(item["returns"]) for item in daily), 2),
        "active_days": len(daily),
    }
    totals["average_check"] = round(
        float(totals["revenue"]) / int(totals["checks"]), 2
    ) if totals["checks"] else 0.0
    archive = analytics_archive_stats(con)
    return {
        "schema": "sai.analytics.ai.v1",
        "generated_at": dt.datetime.now().astimezone().isoformat(),
        "period": {
            "from": begin_date,
            "to": daily[-1]["date"] if daily else dt.date.today().isoformat(),
        },
        "purpose": (
            "Готовая аналитическая витрина. Сырые чеки остаются локально; "
            "ИИ сначала получает агрегаты и запрашивает детализацию только при необходимости."
        ),
        "coverage": archive,
        "totals": totals,
        "monthly": list(monthly.values()),
        "daily": daily,
        "products": products,
        "data_quality": {
            "unlinked_product_lines": archive["unlinked_lines"],
            "unpriced_lines": archive["unpriced_lines"],
            "excluded_from_product_demand": {
                "lines": int(excluded_row[0] or 0),
                "revenue_still_in_financial_totals": _number(excluded_row[1]),
                "raw_quantity_not_treated_as_pieces": _number(excluded_row[2]),
                "reason": "Обобщённые отделы, несвязанные товары и продажи крепежа по весу.",
            },
            "historical_stock_note": (
                "SIGMA API отдаёт текущий остаток. История снимков накапливается SAI с момента подключения."
            ),
        },
    }


def write_ai_dataset(
    con: sqlite3.Connection, *, location_id: str, begin_date: str = "2026-01-01",
    path: Path | None = None,
) -> Path:
    target = Path(path or DATASET_PATH)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = build_ai_dataset(con, location_id=location_id, begin_date=begin_date)
    atomic_json(target, payload)
    return target
