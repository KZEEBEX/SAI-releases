#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import io
import json
import tempfile
from pathlib import Path

import sai_github_updates as updates


class Response(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.close()


package = b"verified installer bytes"
digest = hashlib.sha256(package).hexdigest()
manifest = {
    "schema_version": 1,
    "channel": "production",
    "version": "1.24.0",
    "package": "SAI-Setup-1.24.0.exe",
    "size": len(package),
    "sha256": digest,
}
release = {
    "tag_name": "v1.24.0",
    "draft": False,
    "prerelease": False,
    "html_url": "https://github.com/KZEEBEX/SAI-releases/releases/tag/v1.24.0",
    "assets": [
        {
            "name": updates.MANIFEST_NAME,
            "size": 100,
            "browser_download_url": "https://github.com/KZEEBEX/SAI-releases/releases/download/v1.24.0/sai-update.json",
        },
        {
            "name": manifest["package"],
            "size": len(package),
            "browser_download_url": "https://github.com/KZEEBEX/SAI-releases/releases/download/v1.24.0/SAI-Setup-1.24.0.exe",
        },
    ],
}


def opener(request, timeout=0):
    url = request.full_url
    if url.endswith("/releases/latest"):
        return Response(json.dumps(release).encode())
    if url.endswith("/sai-update.json"):
        return Response(json.dumps(manifest).encode())
    if url.endswith(".exe"):
        return Response(package)
    raise AssertionError(url)


found = updates.check_for_update("v1.23.4-dev.1", opener=opener)
assert found is not None and found.version == "1.24.0"
assert updates.check_for_update("v1.24.0", opener=opener) is None
assert updates.version_key("1.24.0") > updates.version_key("1.24.0-dev.99")

dev_manifest = {
    **manifest,
    "channel": "development",
    "version": "1.24.1-dev.3",
    "package": "SAI-Setup-1.24.1-dev.3.zip",
}
dev_release = {
    **release,
    "tag_name": "v1.24.1-dev.3",
    "prerelease": True,
    "assets": [
        {
            "name": updates.MANIFEST_NAME,
            "size": 100,
            "browser_download_url": "https://github.com/KZEEBEX/SAI-releases/releases/download/v1.24.1-dev.3/sai-update.json",
        },
        {
            "name": dev_manifest["package"],
            "size": len(package),
            "browser_download_url": "https://github.com/KZEEBEX/SAI-releases/releases/download/v1.24.1-dev.3/SAI-Setup-1.24.1-dev.3.zip",
        },
    ],
}


def channel_opener(request, timeout=0):
    url = request.full_url
    if "/releases?per_page=" in url:
        return Response(json.dumps([dev_release, release]).encode())
    if "/v1.24.1-dev.3/sai-update.json" in url:
        return Response(json.dumps(dev_manifest).encode())
    if url.endswith("/sai-update.json"):
        return Response(json.dumps(manifest).encode())
    raise AssertionError(url)


dev_found = updates.check_for_update("v1.24.0", channel="development", opener=channel_opener)
assert dev_found is not None and dev_found.version == "1.24.1-dev.3"
assert dev_found.channel == "development"
assert updates.check_for_update("v1.24.1-dev.3", channel="development", opener=channel_opener) is None

with tempfile.TemporaryDirectory() as folder:
    saved = updates.download_update(found, destination=Path(folder), opener=opener)
    assert saved.read_bytes() == package

bad_release = dict(release)
bad_release["assets"] = list(release["assets"])
bad_manifest = dict(manifest, package="../escape.exe")


def unsafe_opener(request, timeout=0):
    if request.full_url.endswith("/releases/latest"):
        return Response(json.dumps(bad_release).encode())
    return Response(json.dumps(bad_manifest).encode())


try:
    updates.check_for_update("1.0.0", opener=unsafe_opener)
except updates.UpdateCheckError:
    pass
else:
    raise AssertionError("Unsafe package path must be rejected")

bad_update = updates.ReleaseUpdate(**{**found.__dict__, "sha256": "0" * 64})
with tempfile.TemporaryDirectory() as folder:
    try:
        updates.download_update(bad_update, destination=Path(folder), opener=opener)
    except updates.UpdateCheckError:
        assert not list(Path(folder).iterdir())
    else:
        raise AssertionError("Checksum mismatch must be rejected")

print("github update tests: OK")
