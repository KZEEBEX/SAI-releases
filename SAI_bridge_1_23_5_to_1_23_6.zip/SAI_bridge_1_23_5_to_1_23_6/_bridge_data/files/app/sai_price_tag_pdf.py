"""Qt rendering boundary for A4 price-tag PDFs and on-screen previews."""
from __future__ import annotations

import datetime as dt
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

from PySide6.QtCore import QMarginsF, QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontDatabase, QPageLayout, QPageSize, QPainter, QPdfWriter, QPen, QPixmap
try:
    from PySide6.QtPrintSupport import QPrinter, QPrinterInfo
except Exception:  # pragma: no cover - depends on the local Qt installation
    QPrinter = None
    QPrinterInfo = None

from sai_core_v2.barcodes import barcode_modules_for_print
from sai_print_routing import require_a4_printer_name
from sai_price_tags import price_tag_name, price_text, read_sai_price_items, safe_text, unit_text


PRICE_TAG_W_MM = 35.3
PRICE_TAG_H_MM = 39.0
PRICE_TAG_ACCENT_H_MM = 10.0
PRICE_TAG_DPI = 300
_PRICE_TAG_FONTS_LOADED = False


def ensure_price_tag_fonts_loaded() -> None:
    """Load Windows fonts explicitly so PDF Cyrillic never becomes squares."""
    global _PRICE_TAG_FONTS_LOADED
    if _PRICE_TAG_FONTS_LOADED:
        return
    _PRICE_TAG_FONTS_LOADED = True
    fonts_dir = Path(os.environ.get("WINDIR") or r"C:\Windows") / "Fonts"
    for filename in (
        "arial.ttf", "arialbd.ttf", "ariblk.ttf",
        "consola.ttf", "consolab.ttf",
        "segoeui.ttf", "segoeuib.ttf",
    ):
        path = fonts_dir / filename
        if path.exists():
            QFontDatabase.addApplicationFont(str(path))


def price_tag_date_text(today: dt.date | None = None) -> str:
    return (today or dt.date.today()).strftime("%d.%m.%Y")


def default_price_tag_path(prefix: str = "Ценники", suffix: str = ".pdf") -> Path:
    desktop = Path.home() / "Desktop"
    directory = desktop if desktop.exists() else Path.home()
    base = directory / f"{prefix}_{dt.datetime.now().strftime('%d%m%y')}{suffix}"
    if not base.exists():
        return base
    return directory / f"{prefix}_{dt.datetime.now().strftime('%d%m%y_%H%M%S')}{suffix}"


def fit_font(
    painter: QPainter,
    family: str,
    text: str,
    rect: QRect,
    max_pt: int,
    min_pt: int,
    bold: bool = False,
    flags: int = 0,
) -> QFont:
    font = QFont(family, max_pt)
    font.setBold(bold)
    for point_size in range(max_pt, min_pt - 1, -1):
        font.setPointSize(point_size)
        painter.setFont(font)
        bounds = painter.boundingRect(rect, flags, text)
        if bounds.width() <= rect.width() + 2 and bounds.height() <= rect.height() + 2:
            return font
    font.setPointSize(min_pt)
    return font


def _scaled_module_edges(module_count: int, start: int, width: int) -> list[tuple[int, int]]:
    """Distribute modules across the full width without cumulative truncation."""
    count = max(1, int(module_count))
    usable = max(count, int(width))
    return [
        (
            start + round(index * usable / count),
            start + round((index + 1) * usable / count),
        )
        for index in range(count)
    ]


def draw_price_tag_barcode(painter: QPainter, code: str, rect: QRect) -> None:
    code = safe_text(code)
    if not code:
        painter.setPen(QColor("#9ca3af"))
        painter.setFont(QFont("Segoe UI", 6))
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "без штрихкода")
        return
    try:
        modules, symbology = barcode_modules_for_print(code)
        margin = max(1, int(rect.width() * (0.025 if symbology.startswith("EAN") or symbology == "UPC-A" else 0.09)))
        bar_height = int(rect.height() * 0.64)
        x_start = rect.x() + margin
        usable_width = max(len(modules), rect.width() - margin * 2)
        edges = _scaled_module_edges(len(modules), x_start, usable_width)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#050505"))
        for index, bit in enumerate(modules):
            if bit == "1":
                left, right = edges[index]
                painter.drawRect(left, rect.y(), max(1, right - left), bar_height)
        painter.setPen(QColor("#050505"))
        font = QFont("Consolas", 6)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(
            QRect(rect.x(), rect.y() + bar_height, rect.width(), rect.height() - bar_height),
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
            code,
        )
    except Exception:
        painter.setPen(QColor("#111827"))
        painter.setFont(QFont("Consolas", 7))
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, code)


def draw_price_tag(
    painter: QPainter,
    item: Mapping[str, Any],
    x: int,
    y: int,
    width: int,
    height: int,
    *,
    date_text: str | None = None,
    dpi: int = PRICE_TAG_DPI,
) -> None:
    millimeter = max(1, int(dpi)) / 25.4

    def px(value: float) -> int:
        return int(round(value * millimeter))

    accent_text = safe_text(item.get("accent_text") or item.get("price_tag_accent"))
    accent_height = px(PRICE_TAG_ACCENT_H_MM) if accent_text else 0
    body_y = y + accent_height

    painter.fillRect(QRect(x, y, width, height), QColor("#ffffff"))
    if accent_text:
        painter.fillRect(QRect(x, y, width, accent_height), QColor("#050505"))
        accent_rect = QRect(x + px(1.4), y + px(0.8), width - px(2.8), accent_height - px(1.6))
        accent_flags = int(Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap)
        display_accent = accent_text.upper()
        painter.setFont(fit_font(painter, "Arial", display_accent, accent_rect, 17, 9, True, accent_flags))
        painter.setPen(QColor("#ffffff"))
        painter.drawText(accent_rect, accent_flags, display_accent)
    painter.setPen(QPen(QColor("#4b5563"), max(1, px(0.10))))
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawRect(QRect(x, y, width - 1, height - 1))
    if accent_text:
        # Preserve the original 35.3 × 39 mm price tag as an exact, separately
        # bordered block. The black 10 mm header is only attached above it.
        painter.drawRect(QRect(x, body_y, width - 1, px(PRICE_TAG_H_MM) - 1))

    name = price_tag_name(item.get("name"))
    barcode = safe_text(item.get("barcode"))
    display_unit = unit_text(item.get("unit"))
    display_price = price_text(item.get("price"))

    title_rect = QRect(x + px(2.6), body_y + px(2.5), width - px(5.2), px(10.7))
    title_flags = int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop | Qt.TextFlag.TextWordWrap)
    painter.setFont(fit_font(painter, "Segoe UI", name, title_rect, 10, 6, True, title_flags))
    painter.setPen(QColor("#000000"))
    painter.drawText(title_rect, title_flags, name)

    price_rect = QRect(x + px(3.8), body_y + px(15.2), px(23.8), px(9.8))
    price_flags = int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    painter.setFont(fit_font(painter, "Arial Black", display_price, price_rect, 36, 22, False, price_flags))
    painter.drawText(price_rect, price_flags, display_price)

    rub_rect = QRect(x + px(28.1), body_y + px(16.0), width - px(28.1) - px(2.3), px(9.2))
    rub_font = QFont("Arial", 8)
    rub_font.setBold(True)
    painter.setFont(rub_font)
    painter.drawText(QRect(rub_rect.x(), rub_rect.y(), rub_rect.width(), px(4.4)), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignBottom, "руб.")
    painter.drawText(QRect(rub_rect.x(), rub_rect.y() + px(4.5), rub_rect.width(), px(4.5)), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop, f"1 {display_unit}")

    draw_price_tag_barcode(painter, barcode, QRect(x + px(2.5), body_y + px(27.3), width - px(5.0), px(7.1)))
    date_font = QFont("Arial", 7)
    date_font.setBold(True)
    painter.setFont(date_font)
    painter.drawText(
        QRect(x + px(2.6), body_y + px(35.4), px(18), px(2.8)),
        Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
        date_text or price_tag_date_text(),
    )


def _paint_price_tag_pages(
    items: Sequence[Mapping[str, Any]],
    device: Any,
    *,
    new_page: Any,
    dpi: int,
) -> None:
    painter = QPainter(device)
    if not painter.isActive():
        raise RuntimeError("Принтер не принял начало задания.")
    try:
        page_width, page_height = int(device.width()), int(device.height())
        tag_width = int(round(PRICE_TAG_W_MM * dpi / 25.4))
        # Different physical heights cannot share a clean cutting grid. Keep the
        # ordinary 39 mm tags and the 49 mm accented tags on separate pages.
        groups = [
            [item for item in items if not safe_text(item.get("accent_text") or item.get("price_tag_accent"))],
            [item for item in items if safe_text(item.get("accent_text") or item.get("price_tag_accent"))],
        ]
        page_started = False
        for accented, group in enumerate(groups):
            if not group:
                continue
            tag_height_mm = PRICE_TAG_H_MM + (PRICE_TAG_ACCENT_H_MM if accented else 0.0)
            tag_height = int(round(tag_height_mm * dpi / 25.4))
            columns = max(1, page_width // tag_width)
            rows = max(1, page_height // tag_height)
            per_page = max(1, columns * rows)
            x_start = max(0, (page_width - columns * tag_width) // 2)
            y_start = max(0, (page_height - rows * tag_height) // 2)
            for index, item in enumerate(group):
                if page_started and index % per_page == 0:
                    if not new_page():
                        raise RuntimeError("Принтер не принял следующую страницу задания.")
                page_started = True
                local = index % per_page
                draw_price_tag(
                    painter,
                    item,
                    x_start + local % columns * tag_width,
                    y_start + local // columns * tag_height,
                    tag_width,
                    tag_height,
                    dpi=dpi,
                )
    finally:
        painter.end()


def create_price_tags_pdf(items: Sequence[Mapping[str, Any]], out_path: str | Path | None = None) -> Path:
    if not items:
        raise ValueError("Нет товаров для ценников.")
    ensure_price_tag_fonts_loaded()
    output = Path(out_path) if out_path else default_price_tag_path()
    output.parent.mkdir(parents=True, exist_ok=True)
    writer = QPdfWriter(str(output))
    writer.setResolution(PRICE_TAG_DPI)
    try:
        writer.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        writer.setPageOrientation(QPageLayout.Orientation.Landscape)
        writer.setPageMargins(QMarginsF(0, 0, 0, 0), QPageLayout.Unit.Millimeter)
    except Exception:
        pass
    _paint_price_tag_pages(
        items,
        writer,
        new_page=writer.newPage,
        dpi=PRICE_TAG_DPI,
    )
    return output


def print_price_tags_a4(
    items: Sequence[Mapping[str, Any]],
    printer_name: str = "",
) -> str:
    """Render the standard A4 sheet directly to a Windows/Qt printer."""
    if not items:
        raise ValueError("Нет товаров для ценников.")
    if QPrinter is None or QPrinterInfo is None:
        raise RuntimeError("В этой установке SAI недоступен системный модуль печати Qt.")

    installed = list(QPrinterInfo.availablePrinterNames())
    requested = safe_text(printer_name)
    if requested:
        selected = next((name for name in installed if name.casefold() == requested.casefold()), "")
        if not selected:
            raise RuntimeError(f"Выбранный принтер «{requested}» не найден в Windows.")
    else:
        selected = safe_text(QPrinterInfo.defaultPrinter().printerName())
        if not selected:
            raise RuntimeError("В Windows не выбран принтер по умолчанию.")

    selected = require_a4_printer_name(selected)
    info = QPrinterInfo.printerInfo(selected)
    printer = QPrinter(info, QPrinter.PrinterMode.HighResolution)
    printer.setDocName("Ценники SAI")
    printer.setCopyCount(1)
    printer.setResolution(PRICE_TAG_DPI)
    page_size = QPageSize(QPageSize.PageSizeId.A4)
    # Ordinary office printers normally have a non-printable hardware margin.
    # Requiring an A4 *borderless* layout made otherwise healthy Windows
    # drivers (notably Pantum) reject the job before QPainter could start.
    # Use the driver's real printable area instead; _paint_price_tag_pages()
    # centres the fixed-size 35.3 x 39 mm tags inside that area and therefore
    # does not scale or distort the price-tag template.
    printer.setFullPage(False)
    printer.setPageSize(page_size)
    printer.setPageOrientation(QPageLayout.Orientation.Landscape)

    ensure_price_tag_fonts_loaded()
    dpi = max(1, int(printer.resolution()))
    _paint_price_tag_pages(
        items,
        printer,
        new_page=printer.newPage,
        dpi=dpi,
    )
    if printer.printerState() == QPrinter.PrinterState.Error:
        raise RuntimeError(f"Windows сообщила об ошибке принтера «{selected}».")
    return selected


def create_price_tags_pdf_from_sai_file(path: str | Path, out_path: str | Path | None = None) -> tuple[Path, int]:
    items = read_sai_price_items(path)
    return create_price_tags_pdf(items, out_path), len(items)


def make_price_tag_preview_pixmap(item: Mapping[str, Any], max_w: int = 420, max_h: int = 465) -> QPixmap:
    ensure_price_tag_fonts_loaded()
    tag_width = int(round(PRICE_TAG_W_MM * PRICE_TAG_DPI / 25.4))
    accent = safe_text(item.get("accent_text") or item.get("price_tag_accent"))
    tag_height_mm = PRICE_TAG_H_MM + (PRICE_TAG_ACCENT_H_MM if accent else 0.0)
    tag_height = int(round(tag_height_mm * PRICE_TAG_DPI / 25.4))
    pixmap = QPixmap(tag_width, tag_height)
    pixmap.fill(QColor("#ffffff"))
    painter = QPainter(pixmap)
    try:
        draw_price_tag(painter, item, 0, 0, tag_width, tag_height)
    finally:
        painter.end()
    return pixmap.scaled(max_w, max_h, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)


__all__ = [
    "PRICE_TAG_ACCENT_H_MM", "PRICE_TAG_DPI", "PRICE_TAG_H_MM", "PRICE_TAG_W_MM", "create_price_tags_pdf",
    "create_price_tags_pdf_from_sai_file", "default_price_tag_path", "draw_price_tag",
    "draw_price_tag_barcode", "fit_font", "make_price_tag_preview_pixmap",
    "price_tag_date_text", "ensure_price_tag_fonts_loaded", "print_price_tags_a4",
]
