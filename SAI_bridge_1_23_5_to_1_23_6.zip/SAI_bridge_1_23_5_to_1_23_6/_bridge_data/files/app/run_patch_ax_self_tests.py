#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Patch regression for SAI v1.22.7ax visual polish."""
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"


def main() -> None:
    ui = (APP / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    notifications = (APP / "sai_notifications.py").read_text(encoding="utf-8-sig")
    version = (APP / "sai_version.py").read_text(encoding="utf-8-sig")
    ast.parse(ui)
    ast.parse(notifications)
    assert 'VERSION = "1.22.7ax"' in version
    assert "class RailIconButton(QPushButton):" in ui
    assert "fixed icon lane" in ui
    assert "QFrame#CatalogStatusBadge[compactBadge=\"true\"]" in ui
    assert "shadow.setBlurRadius(44)" in notifications
    assert (APP / "run_rail_visual_tests.py").is_file()
    print("OK: SAI v1.22.7ax patch regression passed")


if __name__ == "__main__":
    main()
