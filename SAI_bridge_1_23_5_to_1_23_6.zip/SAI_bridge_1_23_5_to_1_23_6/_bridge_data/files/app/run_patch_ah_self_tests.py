#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import ast, json, os, sys, tempfile
from pathlib import Path

root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_ah_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as ai

assert ai.CONTRACT_VERSION=='invoice_ai_contract_v12'
assert ai.PROMPT_VERSION=='invoice_prompt_v10'
assert ai.DEFAULT_MODEL=='gpt-5.6-luna'
ai.invoice_contract_metadata()

def response(data, input_tokens=1000, output_tokens=200):
    return {
        'output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(data,ensure_ascii=False)}]}],
        'usage':{'input_tokens':input_tokens,'output_tokens':output_tokens,'total_tokens':input_tokens+output_tokens,'input_tokens_details':{'cached_tokens':0}},
    }

def item(row,page,total,name='ТОВАР',barcode='4607136256514'):
    return {'source_row':row,'source_page':page,'raw_name':name,'name':name,'quantity':1.0,'unit':'шт',
            'purchase_price':total,'line_total':total,'article':f'A{row}',
            'barcodes':([barcode] if barcode else []),'confidence':0.9,'note':''}

def doc(items,total=0.0,supplier='ТЕСТОВЫЙ ПОСТАВЩИК'):
    return {'supplier':supplier,'invoice_date':'2026-07-18','invoice_number':'AH-1','currency':'RUB',
            'document_total':total,'document_total_note':'','items':items,'warnings':[]}

# Pure merge keeps global printed numbering and last positive document total.
merged=ai._merge_page_documents([(1,doc([item(1,1,100.0)],0.0)),(2,doc([item(2,2,200.0)],300.0))])
assert [x['source_row'] for x in merged['items']]==[1,2]
assert [x['source_page'] for x in merged['items']]==[1,2]
assert merged['document_total']==300.0

# Pagewise agent: Luna may fail one page, Terra retries only that page.
work=Path(tempfile.mkdtemp(prefix='sai_ah_case_'))
p1=work/'page1.png'; p2=work/'page2.png'
p1.write_bytes(b'fake1'); p2.write_bytes(b'fake2')
plan={str(p1.resolve()):[0],str(p2.resolve()):[0]}
assert ai._confirmed_visual_page_numbers([p1,p2],plan)==[1,2]

calls=[]
original_build=ai.build_request_payload
original_call=ai.call_openai

def fake_build(paths,model='',supplier_hint='',date_hint='',invoice_hint='',stage='extract',draft=None,target_rows=None,audit_notes=None,orientation_plan=None,target_global_pages=None):
    selected={'extract_terra':ai.AUDIT_MODEL,'extract_sol':ai.FALLBACK_MODEL}.get(stage,ai.DEFAULT_MODEL)
    return {'model':selected,'_stage':stage,'_page':int((target_global_pages or [0])[0]),
            '_sai_precision_views_used':True,'_sai_precision_views_count':5}

def fake_call(payload,*args,**kwargs):
    calls.append((payload['_stage'],payload['_page'],payload['model']))
    page=payload['_page']; stage=payload['_stage']
    if page==1 and stage=='extract_luna':
        return response(doc([],0.0))
    if page==1 and stage=='extract_terra':
        return response(doc([item(1,1,100.0)],0.0))
    if page==2 and stage=='extract_luna':
        return response(doc([item(2,2,200.0,barcode='')],300.0))
    raise AssertionError(f'unexpected call: {payload}')

ai.build_request_payload=fake_build
ai.call_openai=fake_call
try:
    result=ai.analyze_invoice([p1,p2],'sk-test',orientation_plan=plan)
finally:
    ai.build_request_payload=original_build
    ai.call_openai=original_call
assert calls==[
    ('extract_luna',1,'gpt-5.6-luna'),
    ('extract_terra',1,'gpt-5.6-terra'),
    ('extract_luna',2,'gpt-5.6-luna'),
]
assert len(result.items)==2
assert result.validation['pagewise_primary'] is True
assert result.validation['pagewise_pages']==2
assert result.validation['fallback_model']==''
assert result.validation['audit_model']=='gpt-5.6-terra'

ui_path=root/'app'/'sai_pyside_preview.py'
ui=ui_path.read_text(encoding='utf-8')
ast.parse(ui,filename=str(ui_path))
assert 'каждую подтверждённую страницу отдельно' in ui
print('PATCH_AH_SELF_TEST_OK')
