#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused installation checks for SAI v1.22.7as final invoice AI refactor."""
from __future__ import annotations

import ast
import json
import subprocess
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
app = root / "app"

assert 'VERSION = "1.22.7as"' in (app / "sai_version.py").read_text(encoding="utf-8")
assert 'APP_VERSION == "v1.22.7as"' in (app / "run_self_tests.py").read_text(encoding="utf-8")

paths = {
    "facade": app / "sai_openai_invoice.py",
    "models": app / "sai_invoice_ai_models.py",
    "client": app / "sai_invoice_ai_client.py",
    "reconciliation": app / "sai_invoice_ai_reconciliation.py",
    "aggregate_tests": app / "run_invoice_ai_tests.py",
    "client_tests": app / "run_invoice_ai_client_tests.py",
    "reconciliation_tests": app / "run_invoice_ai_reconciliation_tests.py",
}
for path in paths.values():
    assert path.is_file(), path
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

facade_text = paths["facade"].read_text(encoding="utf-8")
facade_tree = ast.parse(facade_text)
assert len(facade_text.splitlines()) <= 900, "AI-фасад снова слишком велик"
assert "import ssl" not in facade_text
assert "import urllib" not in facade_text
assert "import sai_invoice_ai_client as _invoice_client" in facade_text
assert "import sai_invoice_ai_models as _invoice_models" in facade_text
assert "import sai_invoice_ai_reconciliation as _invoice_reconciliation" in facade_text
for extracted in (
    "call_openai",
    "reconcile_luna_page",
    "apply_audit",
    "_sanitize_and_evaluate_document",
):
    assert not any(
        isinstance(node, ast.FunctionDef) and node.name == extracted
        for node in facade_tree.body
    ), extracted
analyze = next(
    node for node in facade_tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "analyze_invoice"
)
assert analyze.end_lineno - analyze.lineno + 1 <= 140

models_text = paths["models"].read_text(encoding="utf-8")
for token in (
    'DEFAULT_MODEL = "gpt-5.6-luna"',
    'AUDIT_MODEL = "gpt-5.6-terra"',
    'FALLBACK_MODEL = "gpt-5.6-sol"',
    "def quality_model",
):
    assert token in models_text
client_text = paths["client"].read_text(encoding="utf-8")
for token in (
    "def call_openai",
    "def parse_response_document",
    "def parse_audit_response",
    'if not str(key_name).startswith("_sai_")',
):
    assert token in client_text
reconciliation_text = paths["reconciliation"].read_text(encoding="utf-8")
for token in (
    "def reconcile_luna_page",
    "def apply_audit",
    "def _sanitize_and_evaluate_document",
    "def _blocking_quality_notes",
):
    assert token in reconciliation_text

subprocess.run(
    [sys.executable, str(paths["aggregate_tests"]), str(root)],
    cwd=app,
    check=True,
)

wiki = root / "SAI_Ecosystem_Wiki_v0.1"
manifest = json.loads((wiki / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "3.0"
assert manifest["snapshot_sai_version"] == "1.22.7as"
assert (wiki / "decisions" / "ADR-027-INVOICE-AI-CLIENT-RECONCILIATION-BOUNDARIES.md").is_file()
assert (wiki / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v3.0 / SAI 1.22.7as")

print("PATCH_AS_SELF_TEST_OK")
