#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Create the manifest uploaded beside a verified SAI release package."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", required=True)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--channel", choices=("production", "development"), default="production")
    parser.add_argument("--output", type=Path, default=Path("sai-update.json"))
    args = parser.parse_args()

    package = args.package.resolve()
    if not package.is_file():
        raise SystemExit(f"Package not found: {package}")
    if package.suffix.casefold() not in {".exe", ".msi", ".cmd", ".bat", ".zip"}:
        raise SystemExit("Unsupported package type; use .exe, .msi, .cmd, .bat or .zip")
    version = str(args.version).strip().lstrip("v")
    if not version:
        raise SystemExit("Version is empty")
    manifest = {
        "schema_version": 1,
        "channel": args.channel,
        "version": version,
        "package": package.name,
        "size": package.stat().st_size,
        "sha256": sha256(package),
    }
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
