#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Single source of truth for the SAI application version."""

# VERSION is the next production candidate.  During daily work the visible
# APP_VERSION carries a DEV revision so nobody can confuse it with a verified
# release.  Production promotion removes the DEV suffix only after acceptance.
PRODUCTION_VERSION = "1.23.6"
VERSION = "1.23.6"
DEVELOPMENT_REVISION = 0
RELEASE_CHANNEL = "production"
APP_VERSION = (
    f"v{VERSION}-dev.{DEVELOPMENT_REVISION}"
    if RELEASE_CHANNEL == "development"
    else f"v{VERSION}"
)
BUILD_ID = "SAI-1.23.6"
BUILD_LABEL = "Production: reliable receiving, draft sync and update channels"
