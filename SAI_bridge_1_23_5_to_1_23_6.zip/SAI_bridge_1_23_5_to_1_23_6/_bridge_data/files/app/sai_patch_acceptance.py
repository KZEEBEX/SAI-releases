#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent patch acceptance gate for SAI.

Every release installer calls this module after applying a patch to a shadow
copy and again after applying it to the working tree.  A patch is accepted only
when the changed feature, its adjacent workflows, public imports, version
invariants, application import and user-data isolation all pass.
"""
from __future__ import annotations

import ast
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from dataclasses import asdict, dataclass, field
from typing import Iterable, Sequence


DEFAULT_GROUPS: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "UPDATED_FEATURE",
        (
            "run_optimization_tests.py",
            "run_barcode_core_refactor_tests.py",
            "run_pricing_policy_tests.py",
            "run_price_tag_data_refactor_tests.py",
            "run_price_tag_pdf_refactor_tests.py",
            "run_price_tags_workflow_tests.py",
            "run_sigma_price_tag_batch_tests.py",
            "run_print_routing_tests.py",
            "run_thermal_printing_refactor_tests.py",
            "run_stock_core_tests.py",
            "run_sigma_product_editor_tests.py",
            "run_manual_sigma_login_tests.py",
            "run_sigma_import_workflow_tests.py",
            "run_automatic_receipt_readiness_tests.py",
            "run_receipt_full_cycle_rehearsal_tests.py",
            "run_receipt_launcher_tests.py",
            "run_account_and_stock_ui_tests.py",
            "run_free_receipt_refactor_tests.py",
            "run_semi_auto_price_choice_tests.py",
            "run_organization_sync_tests.py",
            "run_staff_tests.py",
            "run_marking_verification_tests.py",
        ),
    ),
    (
        "DIRECT_NEIGHBOURS",
        (
            "run_manual_receipt_refactor_tests.py",
            "run_semi_auto_receipt_refactor_tests.py",
            "run_receipt_hub_refactor_tests.py",
            "run_catalog_ready_tests.py",
            "run_product_name_tests.py",
        ),
    ),
    (
        "APPLICATION_SHELL",
        (
            "run_core_v2_refactor_tests.py",
            "run_startup_handoff_tests.py",
            "run_notification_system_tests.py",
            "run_ui_polish_tests.py",
            "run_design_system_tests.py",
            "run_ui_normalization_tests.py",
            "run_theme_settings_tests.py",
            "run_frameless_window_tests.py",
            "run_draft_delete_tests.py",
            "run_draft_badge_tests.py",
            "run_intro_system_tests.py",
        ),
    ),
    ("INTEGRATIONS", ("run_invoice_ai_tests.py",)),
    ("FULL_SELF_TEST", ("run_self_tests.py",)),
)


@dataclass(slots=True)
class CheckResult:
    name: str
    status: str
    details: str = ""
    duration_seconds: float = 0.0


@dataclass(slots=True)
class AcceptanceReport:
    status: str
    root: str
    python: str
    started_at: str
    completed_at: str = ""
    checks: list[CheckResult] = field(default_factory=list)
    tests: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)

    def add(self, name: str, status: str, details: str = "", duration: float = 0.0) -> None:
        self.checks.append(CheckResult(name, status, details, duration))

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "root": self.root,
            "python": self.python,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "checks": [asdict(item) for item in self.checks],
            "tests": list(self.tests),
            "skipped": list(self.skipped),
        }


def _now() -> str:
    return dt.datetime.now().astimezone().isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def tree_fingerprint(root: Path) -> dict[str, tuple[int, str]]:
    if not root.exists():
        return {}
    result: dict[str, tuple[int, str]] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if (
            rel.startswith("logs/")
            or rel.startswith("Profile/")
            or rel.startswith("browser_profile/")
            or rel.endswith(".lock")
            or rel.endswith("-wal")
            or rel.endswith("-shm")
        ):
            continue
        try:
            result[rel] = (path.stat().st_size, _sha256(path))
        except FileNotFoundError:
            continue
        except PermissionError:
            # Chromium/Qt may keep cache files exclusively locked while SAI is
            # open on Windows. Preserve integrity coverage without requiring
            # the operator to close the app: size + mtime still detects a
            # mutation between the before/after snapshots.
            try:
                stat = path.stat()
                result[rel] = (stat.st_size, f"locked:{stat.st_mtime_ns}")
            except (FileNotFoundError, PermissionError):
                continue
    return result


def runtime_python(root: Path, explicit: Path | None = None) -> Path:
    if explicit is not None and explicit.is_file():
        return explicit
    for path in (
        root / "app" / ".venv" / "Scripts" / "python.exe",
        root / ".venv" / "Scripts" / "python.exe",
        root / "app" / ".venv" / "bin" / "python",
    ):
        if path.is_file():
            return path
    return Path(sys.executable)


def module_available(python: Path, module: str, *, cwd: Path) -> bool:
    process = subprocess.run(
        [str(python), "-c", f"import {module}"], cwd=str(cwd),
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30,
    )
    return process.returncode == 0


def validate_python_sources(app_dir: Path) -> int:
    count = 0
    for path in app_dir.rglob("*.py"):
        if ".venv" in path.parts or "__pycache__" in path.parts:
            continue
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        count += 1
    return count


def _run(
    python: Path,
    app_dir: Path,
    script: str,
    env: dict[str, str],
    *,
    timeout: int = 360,
) -> tuple[int, str, float]:
    started = dt.datetime.now().timestamp()
    process = subprocess.run(
        [str(python), script], cwd=str(app_dir), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", timeout=timeout,
    )
    duration = dt.datetime.now().timestamp() - started
    return process.returncode, process.stdout.strip(), duration


def _import_smoke(python: Path, root: Path, env: dict[str, str], *, include_ui: bool) -> str:
    modules = [
        "sai_core_v2.barcodes",
        "sai_core_v2.pricing",
        "sai_price_tags",
        "sai_price_tag_pdf",
        "sai_thermal_printing",
        "sai_core_v2.stock",
        "sai_stock",
        "sai_sigma_product_editor",
        "sai_core_v2.accounts",
        "sai_accounts",
        "sai_stock_ui",
        "sai_admin",
        "sai_secret_store",
        "sai_core_v2.free_receipt",
        "sai_free_receipt",
        "sai_core_v2.manual_receipt",
        "sai_manual_receipt",
        "sai_core_v2.semi_auto_receipt_refactor",
        "sai_semi_auto_receipt",
    ]
    if include_ui:
        modules.extend(["sai_receipt_hub", "sai_pyside_preview"])
    code = (
        "import importlib, sys; sys.path.insert(0, 'app'); "
        f"mods={modules!r}; "
        "[importlib.import_module(name) for name in mods]; "
        "from sai_version import VERSION, APP_VERSION, RELEASE_CHANNEL, DEVELOPMENT_REVISION; "
        "assert RELEASE_CHANNEL in ('development', 'production'); "
        "expected = f'v{VERSION}-dev.{DEVELOPMENT_REVISION}' if RELEASE_CHANNEL == 'development' else f'v{VERSION}'; "
        "assert APP_VERSION == expected; "
        "print('IMPORT_SMOKE_OK ' + APP_VERSION)"
    )
    process = subprocess.run(
        [str(python), "-c", code], cwd=str(root), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", timeout=90,
    )
    if process.returncode:
        raise RuntimeError(process.stdout.strip() or "import smoke failed")
    return process.stdout.strip()


def run_acceptance(
    root: Path,
    *,
    python: Path | None = None,
    report_path: Path | None = None,
    groups: Sequence[tuple[str, Sequence[str]]] = DEFAULT_GROUPS,
    log=print,
    keep_going: bool = False,
) -> AcceptanceReport:
    root = root.resolve()
    app_dir = root / "app"
    runtime = runtime_python(root, python)
    report = AcceptanceReport("RUNNING", str(root), str(runtime), _now())
    if not (app_dir / "sai_version.py").is_file():
        raise RuntimeError(f"Not an SAI root: {root}")

    real_user_data = root / "user_data"
    before_user_data = tree_fingerprint(real_user_data)
    with tempfile.TemporaryDirectory(prefix="sai_patch_acceptance_") as temporary:
        isolated_data = Path(temporary) / "user_data"
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        env["SAI_USER_DATA_DIR"] = str(isolated_data)
        env.setdefault("QT_QPA_PLATFORM", "offscreen")

        try:
            count = validate_python_sources(app_dir)
            report.add("PYTHON_SYNTAX", "PASS", f"{count} files")
            log(f"  PYTHON_SYNTAX: PASS ({count} файлов)")

            has_qt = module_available(runtime, "PySide6", cwd=app_dir)
            details = _import_smoke(runtime, root, env, include_ui=has_qt)
            report.add("PUBLIC_API_AND_APP_IMPORT", "PASS", details)
            log("  PUBLIC_API_AND_APP_IMPORT: PASS")

            failures = []
            for group_name, scripts in groups:
                group_completed = 0
                group_failures = 0
                for script in scripts:
                    script_path = app_dir / script
                    if not script_path.is_file():
                        report.skipped.append(script)
                        log(f"  {group_name}: SKIP {script} (файл отсутствует)")
                        continue
                    ui_test = script in {
                        "run_receipt_hub_refactor_tests.py", "run_notification_system_tests.py",
                        "run_price_tag_pdf_refactor_tests.py", "run_ui_polish_tests.py",
                        "run_thermal_printing_refactor_tests.py",
                        "run_account_and_stock_ui_tests.py",
                        "run_intro_system_tests.py",
                    }
                    if ui_test and not has_qt:
                        report.skipped.append(script)
                        log(f"  {group_name}: SKIP {script} (PySide6 отсутствует)")
                        continue
                    code, output, duration = _run(runtime, app_dir, script, env)
                    if output:
                        for line in output.splitlines():
                            log("    " + line)
                    if code != 0:
                        report.add(group_name, "FAIL", f"{script}: exit {code}", duration)
                        failures.append(script)
                        group_failures += 1
                        if not keep_going:
                            raise RuntimeError(f"{script} failed with exit code {code}")
                        continue
                    report.tests.append(script)
                    group_completed += 1
                report.add(group_name, "FAIL" if group_failures else "PASS", f"{group_completed} passed, {group_failures} failed")
                log(f"  {group_name}: {group_completed} PASS, {group_failures} FAIL")

            after_user_data = tree_fingerprint(real_user_data)
            if before_user_data != after_user_data:
                before_keys = set(before_user_data)
                after_keys = set(after_user_data)
                changed = sorted(
                    (before_keys ^ after_keys)
                    | {key for key in before_keys & after_keys if before_user_data[key] != after_user_data[key]}
                )
                report.add("USER_DATA_INTEGRITY", "FAIL", ", ".join(changed[:20]))
                raise RuntimeError("Tests changed real user_data: " + ", ".join(changed[:20]))
            report.add("USER_DATA_INTEGRITY", "PASS", "real user_data unchanged")
            log("  USER_DATA_INTEGRITY: PASS")

            if failures:
                raise RuntimeError("Failed tests: " + ", ".join(failures))

            report.status = "ACCEPTED"
            report.completed_at = _now()
        except Exception as exc:
            report.status = "REJECTED"
            report.completed_at = _now()
            if not any(item.status == "FAIL" for item in report.checks):
                report.add("ACCEPTANCE_GATE", "FAIL", str(exc))
            if report_path is not None:
                report_path.parent.mkdir(parents=True, exist_ok=True)
                report_path.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            raise

    if report_path is not None:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


__all__ = [
    "AcceptanceReport", "CheckResult", "DEFAULT_GROUPS", "run_acceptance",
    "runtime_python", "tree_fingerprint", "validate_python_sources",
]
