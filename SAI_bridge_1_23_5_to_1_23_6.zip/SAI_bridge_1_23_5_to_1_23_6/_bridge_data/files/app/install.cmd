@echo off
setlocal
cd /d "%~dp0"

echo ========================================
echo       SAI Hub setup and verification

echo ========================================
echo.

where py >nul 2>nul
if errorlevel 1 goto no_python

set "PY_CMD=py -3.12"
%PY_CMD% --version >nul 2>nul
if errorlevel 1 set "PY_CMD=py -3"
%PY_CMD% --version
if errorlevel 1 goto no_python

if exist ".venv\Scripts\python.exe" goto have_venv
echo Creating virtual environment...
%PY_CMD% -m venv .venv
if errorlevel 1 goto error_venv

:have_venv
echo Installing dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto error_pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto error_pip

echo Installing Chromium for Playwright...
".venv\Scripts\python.exe" -m playwright install chromium
if errorlevel 1 goto error_browser

if not exist "..\user_data" mkdir "..\user_data"
if not exist "..\user_data\backups" mkdir "..\user_data\backups"
if not exist "..\user_data\sai_private_config.json" copy /Y "sai_private_config.example.json" "..\user_data\sai_private_config.json" >nul
if not exist "..\user_data\sai_config.json" copy /Y "sai_config.example.json" "..\user_data\sai_config.json" >nul

echo Running safe self-tests...
".venv\Scripts\python.exe" run_self_tests.py
if errorlevel 1 goto error_tests

echo Checking SAI launcher...
".venv\Scripts\python.exe" sai_launcher.py --check --console
if errorlevel 1 goto error_tests

echo.
echo SAI SETUP COMPLETED SUCCESSFULLY.
echo Start SAI using the Hub shortcut in the root SAI folder.
pause
exit /b 0

:no_python
echo ERROR: Python Launcher was not found.
echo Install Python 3.12 x64 and enable Add python.exe to PATH.
goto failed
:error_venv
echo ERROR: Could not create .venv.
goto failed
:error_pip
echo ERROR: Could not install Python dependencies.
goto failed
:error_browser
echo ERROR: Could not install Chromium for Playwright.
goto failed
:error_tests
echo ERROR: SAI verification failed.
goto failed
:failed
echo Review the error above. This window will stay open.
pause
exit /b 1
