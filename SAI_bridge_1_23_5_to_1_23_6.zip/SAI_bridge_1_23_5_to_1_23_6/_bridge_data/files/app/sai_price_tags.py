"""Price-tag data service, independent of the Qt interface."""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Iterable

import sai_converter
import sai_package
import sai_product_names
from sai_core_v2.free_receipt import normalize_unit

try:
    from openpyxl import load_workbook
except Exception:  # pragma: no cover - reported when XLSX is requested
    load_workbook = None


def safe_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def price_tag_name(value: Any) -> str:
    """Return seller-facing text without supplier packing/list markings."""
    source = safe_text(value)
    if not source:
        return ""
    return sai_product_names.normalize_product_name(source).normalized or source


def normalized_key(value: Any) -> str:
    text = sai_product_names.searchable_text(value).upper().replace("Ё", "Е")
    return re.sub(r"\s+", " ", re.sub(r"[^0-9A-ZА-Я]+", " ", text)).strip()


def price_number(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    text = str(value).strip().replace("\xa0", "").replace(" ", "").replace(",", ".")
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    try:
        return float(match.group(0)) if match else 0.0
    except (TypeError, ValueError):
        return 0.0


def price_text(value: Any) -> str:
    price = price_number(value)
    if abs(price - round(price)) < 0.001:
        return f"{int(round(price)):,}".replace(",", " ")
    return f"{price:,.2f}".replace(",", " ").replace(".", ",")


def unit_text(value: Any) -> str:
    unit = normalize_unit(value or "штука")
    low = unit.lower().replace(".", "").strip()
    if low in {"штука", "шт", "pcs", "pc"}:
        return "шт."
    if low in {"килограмм", "килограмма", "килограммов"}:
        return "кг"
    if low in {"грамм", "грамма", "граммов"}:
        return "г"
    if low in {"пара", "пары", "пар", "pair", "pairs"}:
        return "пара"
    return unit


def _unique(items: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[tuple[str, str, float, str, str]] = set()
    for raw in items:
        name = safe_text(raw.get("name"))
        if not name:
            continue
        barcode = safe_text(raw.get("barcode"))
        price = price_number(raw.get("price"))
        unit = safe_text(raw.get("unit") or "штука")
        accent_text = safe_text(raw.get("accent_text") or raw.get("price_tag_accent"))
        key = (normalized_key(name), barcode, round(price, 2), normalized_key(unit), normalized_key(accent_text))
        if key in seen:
            continue
        seen.add(key)
        result_item = {"name": name, "barcode": barcode, "price": price, "unit": unit}
        if accent_text:
            result_item["accent_text"] = accent_text
        result.append(result_item)
    return result


def read_sai_xml_price_items(path: str | Path) -> list[dict[str, Any]]:
    root = ET.parse(str(Path(path))).getroot()
    raw_items: list[dict[str, Any]] = []
    for item in root.findall(".//item"):
        barcodes: list[str] = []
        container = item.find("barcodes")
        if container is not None:
            for element in container.findall("barcode"):
                barcode = safe_text(element.text)
                if barcode and barcode not in barcodes:
                    barcodes.append(barcode)
        direct = safe_text(item.findtext("barcode") or item.findtext("bar_code") or item.findtext("ШК"))
        if direct and direct not in barcodes:
            barcodes.append(direct)
        raw_items.append({
            "name": item.findtext("name"),
            "barcode": barcodes[0] if barcodes else "",
            "price": item.findtext("sale_price") or item.findtext("price") or item.findtext("retail_price") or 0,
            "unit": item.findtext("unit") or "штука",
            "accent_text": item.findtext("price_tag_accent") or "",
        })
    return _unique(raw_items)


def read_sai_xlsx_price_items(path: str | Path) -> list[dict[str, Any]]:
    if load_workbook is None:
        raise RuntimeError("openpyxl недоступен, XLSX прочитать нельзя.")
    workbook = load_workbook(str(Path(path)), data_only=True, read_only=True)
    sheet = workbook["Для робота SIGMA"] if "Для робота SIGMA" in workbook.sheetnames else workbook[workbook.sheetnames[0]]
    table = [list(row) for row in sheet.iter_rows(values_only=True)]
    if not table:
        workbook.close()
        return []
    try:
        header_row, columns, _warning = sai_converter.detect_columns(table)
    except Exception:
        header_row, columns = 0, {}
    raw_items: list[dict[str, Any]] = []
    accent_column = None
    for index, value in enumerate(table[header_row]):
        if normalized_key(value) in {"ВАЖНОЕ ОТЛИЧИЕ", "АКЦЕНТ ЦЕННИКА", "PRICE TAG ACCENT"}:
            accent_column = index
            break
    for row in table[header_row + 1:]:
        def cell(field: str) -> Any:
            index = columns.get(field)
            return row[index] if index is not None and index < len(row) else ""
        barcode_cell = cell("barcode")
        try:
            barcodes = sai_converter.split_barcodes(barcode_cell)
        except Exception:
            barcodes = []
        raw_items.append({
            "name": cell("name"),
            "barcode": barcodes[0] if barcodes else barcode_cell,
            "price": cell("sale") or cell("price") or cell("buy"),
            "unit": cell("unit") or "штука",
            "accent_text": row[accent_column] if accent_column is not None and accent_column < len(row) else "",
        })
    result = _unique(raw_items)
    workbook.close()
    return result


def read_sai_package_price_items(path: str | Path) -> list[dict[str, Any]]:
    _sheet, rows, _meta = sai_package.load_rows(path)
    raw_items = []
    for row in rows:
        barcodes = row.get("barcodes") or []
        raw_items.append({
            "name": row.get("name"),
            "barcode": barcodes[0] if barcodes else row.get("barcode_cell"),
            "price": row.get("sale"),
            "unit": row.get("unit") or "штука",
            "accent_text": row.get("price_tag_accent") or row.get("accent_text") or "",
        })
    return _unique(raw_items)


def read_sai_price_items(path: str | Path) -> list[dict[str, Any]]:
    source = Path(path)
    if source.suffix.lower() == ".sai":
        return read_sai_package_price_items(source)
    if source.suffix.lower() in {".xlsx", ".xlsm"}:
        return read_sai_xlsx_price_items(source)
    return read_sai_xml_price_items(source)


__all__ = [
    "normalized_key", "price_number", "price_tag_name", "price_text", "read_sai_package_price_items",
    "read_sai_price_items", "read_sai_xlsx_price_items", "read_sai_xml_price_items",
    "safe_text", "unit_text",
]
