"""Durable at-most-once automatic dispatch; never claims physical printing.

A crash after spool submission cannot be distinguished from a failed print.
Such jobs require an explicit operator reprint instead of automatic replay.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
import time
from typing import Callable

from sai_runtime_paths import CACHE_DIR
from sai_sigma_session import ProcessLock, SessionUnavailable, atomic_json, read_json


def dispatch_once(key: str, submit: Callable[[], object], *, reprint: bool = False,
                  directory: Path | None = None) -> dict:
    if not key.strip():
        raise ValueError("Print job identity is required")
    root = Path(directory or CACHE_DIR / "print_jobs")
    path = root / (hashlib.sha256(key.encode()).hexdigest() + ".json")
    lock = ProcessLock(path.with_suffix(".lock"), timeout=0)
    try:
        lock.__enter__()
    except SessionUnavailable:
        return {"state": "busy", "submitted": False}
    try:
        previous = read_json(path)
        if previous and not reprint:
            return {"state": "already_submitted" if previous.get("state") == "submitted" else "uncertain",
                    "submitted": False}
        attempt = int(previous.get("attempt") or 0) + 1
        record = {"state": "uncertain", "attempt": attempt, "started_at": time.time()}
        # Must be durable before touching the printer, not after it.
        atomic_json(path, record)
        try:
            result = submit()
        except Exception:
            # Preserve uncertainty, and never persist errors containing private data.
            raise
        if result is False:
            return {"state": "uncertain", "submitted": False}
        atomic_json(path, {**record, "state": "submitted", "submitted_at": time.time()})
        return {"state": "submitted", "submitted": True}
    finally:
        lock.__exit__(None, None, None)
