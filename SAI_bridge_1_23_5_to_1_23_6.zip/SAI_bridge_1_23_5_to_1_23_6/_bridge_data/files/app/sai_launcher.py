#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Reliable SAI Hub launcher with crash logging and daily database backups."""
from __future__ import annotations

import argparse
import datetime as dt
import os
import sqlite3
import sys
import traceback
from pathlib import Path

from sai_direct_network import configure_direct_network

configure_direct_network()

APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
for _browser_dir in (
    ROOT_DIR / "_runtime" / "ms-playwright",
    ROOT_DIR / "_offline" / "ms-playwright",
):
    if _browser_dir.is_dir():
        os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(_browser_dir))
        break
USER_DATA_DIR = Path(os.environ.get("SAI_USER_DATA_DIR") or (ROOT_DIR / "user_data")).resolve()
LOGS_DIR = USER_DATA_DIR / "logs"
BACKUPS_DIR = USER_DATA_DIR / "backups"
DB_PATH = USER_DATA_DIR / "sai.db"


def _show_error(title: str, message: str, console: bool = False) -> None:
    if console:
        print(f"{title}: {message}", file=sys.stderr)
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, message, title, 0x10)
    except Exception:
        print(f"{title}: {message}", file=sys.stderr)


def _write_crash_log(exc_type, exc_value, exc_tb) -> Path:
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    path = LOGS_DIR / f"sai_crash_{stamp}.txt"
    text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    path.write_text(text, encoding="utf-8")
    return path


def _backup_database_once_per_day(keep: int = 10) -> None:
    if not DB_PATH.exists() or DB_PATH.stat().st_size == 0:
        return
    BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
    today = dt.date.today().strftime("%Y%m%d")
    target = BACKUPS_DIR / f"sai_{today}.db"
    if not target.exists():
        temp = target.with_suffix(".db.tmp")
        if temp.exists():
            temp.unlink()
        source = sqlite3.connect(f"file:{DB_PATH.as_posix()}?mode=ro", uri=True, timeout=10)
        destination = sqlite3.connect(temp)
        try:
            source.backup(destination)
        finally:
            destination.close()
            source.close()
        temp.replace(target)
    backups = sorted(BACKUPS_DIR.glob("sai_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[max(1, keep):]:
        try:
            old.unlink()
        except OSError:
            pass


def _install_exception_hook(console: bool) -> None:
    def hook(exc_type, exc_value, exc_tb):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        log_path = _write_crash_log(exc_type, exc_value, exc_tb)
        message = (
            "SAI завершился с ошибкой.\n\n"
            f"Отчёт сохранён:\n{log_path}\n\n"
            "Запустите «SAI Doctor» и приложите этот файл к сообщению об ошибке."
        )
        _show_error("Ошибка запуска SAI", message, console=console)
    sys.excepthook = hook


def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--console", action="store_true")
    args, _ = parser.parse_known_args()
    os.chdir(APP_DIR)
    USER_DATA_DIR.mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)
    _install_exception_hook(args.console)

    try:
        from sai_version import APP_VERSION
        import PySide6  # noqa: F401
        if args.check:
            import sai_pyside_preview  # noqa: F401
            print(f"OK: SAI {APP_VERSION} launcher check passed")
            return 0
        _backup_database_once_per_day()
        from sai_pyside_preview import main as hub_main
        return int(hub_main() or 0)
    except SystemExit as exc:
        return exc.code if isinstance(exc.code, int) else 0
    except BaseException:
        exc_type, exc_value, exc_tb = sys.exc_info()
        log_path = _write_crash_log(exc_type, exc_value, exc_tb)
        message = (
            "SAI не удалось запустить.\n\n"
            f"Причина: {exc_value}\n\n"
            f"Отчёт сохранён:\n{log_path}\n\n"
            "Проверьте установку через app\\install.cmd или запустите SAI Doctor."
        )
        _show_error("Ошибка запуска SAI", message, console=args.console)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
