#!/usr/bin/env python
"""Runtime and boundary tests for the extracted price-tag PDF renderer."""
from __future__ import annotations

import ast
import os
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from sai_price_tag_pdf import (
    PRICE_TAG_DPI,
    PRICE_TAG_H_MM,
    PRICE_TAG_W_MM,
    _scaled_module_edges,
    create_price_tags_pdf,
    make_price_tag_preview_pixmap,
    price_tag_date_text,
)


HERE = Path(__file__).resolve().parent


def main() -> None:
    app = QApplication.instance() or QApplication([])
    assert PRICE_TAG_W_MM == 35.3
    assert PRICE_TAG_H_MM == 39.0
    assert PRICE_TAG_DPI == 300
    assert price_tag_date_text().count(".") == 2
    edges = _scaled_module_edges(95, 10, 341)
    assert edges[0][0] == 10 and edges[-1][1] == 351
    assert max(right - left for left, right in edges) - min(right - left for left, right in edges) <= 1

    items = [
        {"name": "Тестовый товар", "barcode": "4601234567893", "price": 125.5, "unit": "шт"},
        {"name": "Внутренний код", "barcode": "10000542", "price": 200, "unit": "кг"},
    ]
    preview = make_price_tag_preview_pixmap(items[0], 420, 465)
    assert not preview.isNull()
    accented = dict(items[0], accent_text="650 МЛ")
    accent_preview = make_price_tag_preview_pixmap(accented, 420, 600)
    assert not accent_preview.isNull()
    assert accent_preview.height() > preview.height()
    assert preview.width() <= 420 and preview.height() <= 465

    with tempfile.TemporaryDirectory(prefix="sai_price_pdf_test_") as temporary:
        output = Path(temporary) / "price-tags.pdf"
        result = create_price_tags_pdf(items, output)
        assert result == output
        assert output.is_file()
        content = output.read_bytes()
        assert content.startswith(b"%PDF-")
        assert len(content) > 1_000

    ui_text = (HERE / "sai_pyside_preview.py").read_text(encoding="utf-8")
    tree = ast.parse(ui_text)
    forbidden = {
        "create_price_tags_pdf", "create_price_tags_pdf_from_sai_file",
        "make_price_tag_preview_pixmap", "_draw_price_tag_barcode",
        "_draw_one_price_tag",
    }
    remaining = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    assert not forbidden & remaining, f"PDF rendering leaked into UI: {sorted(forbidden & remaining)}"
    assert "from sai_price_tag_pdf import" in ui_text
    renderer = (HERE / "sai_price_tag_pdf.py").read_text(encoding="utf-8")
    assert "QPageSize.PageSizeId.A4" in renderer
    assert "QPageLayout.Orientation.Landscape" in renderer
    assert "def print_price_tags_a4(" in renderer
    assert "printer.setFullPage(False)" in renderer
    assert "не принял формат A4" not in renderer
    assert "QPrinter.PrinterMode.HighResolution" in renderer
    assert "_paint_price_tag_pages(" in renderer
    assert "ensure_price_tag_fonts_loaded()" in renderer
    assert 'fit_font(painter, "Segoe UI"' in renderer
    print("SAI price-tag PDF refactor tests: OK")
    app.processEvents()


if __name__ == "__main__":
    main()
