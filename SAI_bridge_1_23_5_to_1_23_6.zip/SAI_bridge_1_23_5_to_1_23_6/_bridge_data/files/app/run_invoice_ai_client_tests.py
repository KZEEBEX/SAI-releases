#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent offline tests for the invoice AI transport boundary."""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_invoice_client_tests_")
sys.path.insert(0, str(ROOT / "app"))

import sai_invoice_ai_client as client
from sai_invoice_ai_errors import OpenAIInvoiceError
import sai_openai_invoice as facade

assert facade.call_openai is client.call_openai
assert facade._extract_output_text is client.extract_output_text
assert facade._parse_response_document is client.parse_response_document
assert facade._parse_audit_response is client.parse_audit_response


def response(data):
    return {
        "output": [
            {
                "type": "message",
                "content": [{"type": "output_text", "text": json.dumps(data, ensure_ascii=False)}],
            }
        ]
    }


document = {"items": [{"source_row": 1}]}
assert client.parse_response_document(response(document)) == document
assert client.parse_response_document_allow_empty(response({"items": []})) == {"items": []}
try:
    client.parse_response_document(response({"items": []}), "Luna")
except OpenAIInvoiceError as exc:
    assert "не нашёл ни одной товарной строки" in str(exc)
else:
    raise AssertionError("Пустой товарный ответ должен быть отклонён")

try:
    client.extract_output_text({"output": [{"type": "message", "content": [{"type": "refusal", "refusal": "нет"}]}]})
except OpenAIInvoiceError as exc:
    assert "Модель отказалась" in str(exc)
else:
    raise AssertionError("Refusal должен стать операторской ошибкой")

audit = client.parse_audit_response(response({
    "checked_rows": [2, 1, 2],
    "rows": [{
        "source_row": 1,
        "source_page": 0,
        "barcodes": ["4601234567893", ""],
        "status": "unexpected",
    }],
}))
assert audit["checked_rows"] == [1, 2]
assert audit["rows"][0]["source_page"] == 1
assert audit["rows"][0]["status"] == "verified"

header = client.parse_header_response(response({
    "supplier": " ООО ТЕСТ ",
    "invoice_date": "2026-07-19",
    "invoice_number": 77,
    "document_total": "120,50",
    "note": None,
}))
assert header["supplier"] == "ООО ТЕСТ"
assert header["invoice_number"] == "77"
assert abs(header["document_total"] - 120.5) < 0.0001

captured = {}


class FakeResponse:
    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def read(self):
        return json.dumps({"output": []}).encode("utf-8")


class FakeOpener:
    def open(self, request, timeout=0):
        captured["url"] = request.full_url
        captured["timeout"] = timeout
        captured["headers"] = dict(request.header_items())
        captured["payload"] = json.loads(request.data.decode("utf-8"))
        return FakeResponse()


original_make_opener = client.make_opener
client.make_opener = lambda _proxy="": FakeOpener()
try:
    result = client.call_openai(
        {"model": "gpt-test", "store": False, "_sai_private": "never-send"},
        "sk-test",
        api_base="https://example.invalid/v1/",
        timeout=17,
    )
finally:
    client.make_opener = original_make_opener
assert result == {"output": []}
assert captured["url"] == "https://example.invalid/v1/responses"
assert captured["timeout"] == 17
assert captured["payload"] == {"model": "gpt-test", "store": False}
assert "never-send" not in json.dumps(captured, ensure_ascii=False)

class FlakyOpener:
    attempts = 0

    def open(self, request, timeout=0):
        FlakyOpener.attempts += 1
        if FlakyOpener.attempts < 3:
            raise ConnectionResetError("remote disconnected")
        return FakeResponse()


original_sleep = client.time.sleep
client.make_opener = lambda _proxy="": FlakyOpener()
client.time.sleep = lambda _seconds: None
try:
    result = client.call_openai({"model": "gpt-test"}, "sk-test")
finally:
    client.make_opener = original_make_opener
    client.time.sleep = original_sleep
assert result == {"output": []}
assert FlakyOpener.attempts == 3

try:
    client.call_openai({}, "")
except OpenAIInvoiceError as exc:
    assert "API key" in str(exc)
else:
    raise AssertionError("Пустой API key должен быть отклонён до сети")

print("INVOICE_AI_CLIENT_TESTS_OK")
