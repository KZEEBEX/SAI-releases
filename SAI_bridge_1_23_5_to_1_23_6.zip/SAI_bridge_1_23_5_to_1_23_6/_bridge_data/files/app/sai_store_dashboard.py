#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Store dashboard UI and its small local data boundary."""
from __future__ import annotations

import json
import datetime as dt
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path

import requests
from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSizePolicy,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from sai_runtime_paths import PRIVATE_CONFIG_PATH, USER_DATA_DIR
import sai_receipt_drafts


@dataclass(frozen=True)
class PeriodSnapshot:
    current: float = 0.0
    previous: float = 0.0
    labels: tuple[str, ...] = ()
    values: tuple[float, ...] = ()
    average_check: float = 0.0
    receipt_count: int = 0
    details_loaded: bool = False

    @property
    def change_percent(self) -> float | None:
        if self.previous == 0:
            return 0.0 if self.current == 0 else None
        return (self.current - self.previous) / self.previous * 100.0


@dataclass(frozen=True)
class StoreSnapshot:
    revenue: float = 0.0
    average_check: float = 0.0
    receipt_count: int = 0
    periods: dict[str, PeriodSnapshot] | None = None
    connected: bool = False


class StoreDashboardService:
    """Reads the cashier-owned snapshot without coupling the dashboard to POS."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path or (USER_DATA_DIR / "store_dashboard.json"))

    @staticmethod
    def _number(value) -> float:
        try:
            return float(str(value).replace(" ", "").replace(",", "."))
        except (TypeError, ValueError):
            return 0.0

    def load(self) -> StoreSnapshot:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            raw = {}
        today = raw.get("today") if isinstance(raw.get("today"), dict) else {}
        source_periods = raw.get("periods") if isinstance(raw.get("periods"), dict) else {}
        periods: dict[str, PeriodSnapshot] = {}
        for key in ("day", "week", "month"):
            item = source_periods.get(key) if isinstance(source_periods.get(key), dict) else {}
            points = item.get("points") if isinstance(item.get("points"), list) else []
            labels: list[str] = []
            values: list[float] = []
            for point in points:
                if not isinstance(point, dict):
                    continue
                labels.append(str(point.get("label") or ""))
                values.append(self._number(point.get("value")))
            periods[key] = PeriodSnapshot(
                current=self._number(item.get("current")),
                previous=self._number(item.get("previous")),
                labels=tuple(labels),
                values=tuple(values),
                average_check=self._number(
                    item.get("average_check", today.get("average_check") if key == "day" else 0)
                ),
                receipt_count=max(0, int(self._number(
                    item.get("receipt_count", today.get("receipt_count") if key == "day" else 0)
                ))),
                details_loaded=(
                    "average_check" in item
                    and "receipt_count" in item
                ) or key == "day" and bool(today),
            )
        return StoreSnapshot(
            revenue=self._number(today.get("revenue")),
            average_check=self._number(today.get("average_check")),
            receipt_count=max(0, int(self._number(today.get("receipt_count")))),
            periods=periods,
            connected=bool(raw),
        )

    @staticmethod
    def _private_config() -> dict:
        try:
            data = json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8-sig"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError, TypeError):
            return {}

    @staticmethod
    def _iso_utc(value: dt.datetime) -> str:
        utc = value.astimezone(dt.timezone.utc).replace(tzinfo=None)
        return utc.isoformat(timespec="milliseconds") + "Z"

    @staticmethod
    def _period_bounds(now: dt.datetime, key: str) -> tuple[dt.datetime, dt.datetime]:
        end = now.replace(hour=23, minute=59, second=59, microsecond=999000)
        if key == "day":
            begin = now.replace(hour=0, minute=0, second=0, microsecond=0)
        elif key == "week":
            begin = (now - dt.timedelta(days=6)).replace(
                hour=0, minute=0, second=0, microsecond=0,
            )
        else:
            begin = (now - dt.timedelta(days=29)).replace(
                hour=0, minute=0, second=0, microsecond=0,
            )
        return begin, end

    @staticmethod
    def _label(point_time: str, key: str, timezone: dt.tzinfo) -> str:
        try:
            parsed = dt.datetime.fromisoformat(str(point_time).replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=dt.timezone.utc)
            local = parsed.astimezone(timezone)
            return local.strftime("%H:%M" if key == "day" else "%d.%m")
        except (TypeError, ValueError):
            return ""

    def fetch_remote(self) -> StoreSnapshot:
        cfg = self._private_config()
        company = str(cfg.get("sigma_company_key") or "").strip()
        sell_point = str(cfg.get("sigma_sell_point_id") or "").strip()
        if not company or not sell_point:
            raise RuntimeError("В настройках SAI не определены компания или торговая точка")
        now = dt.datetime.now().astimezone()
        offset = now.utcoffset() or dt.timedelta()
        timezone_hours = int(offset.total_seconds() // 3600)
        url = f"https://chs.sigma.ru/companies/{company}/dashboard/sales"
        def fetch_period(key: str) -> tuple[str, PeriodSnapshot, dict]:
            begin, end = self._period_bounds(now, key)
            response = requests.get(
                url,
                params={
                    "begin": self._iso_utc(begin),
                    "end": self._iso_utc(end),
                    "sellPointId": sell_point,
                    "timeZone": timezone_hours,
                },
                headers={
                    "Accept": "application/json",
                    "Origin": "https://cloud.sigma.ru",
                    "Referer": "https://cloud.sigma.ru/",
                    "User-Agent": "SAI/StoreDashboard",
                },
                timeout=12,
            )
            response.raise_for_status()
            payload = response.json()
            current = payload.get("currPeriod") if isinstance(payload.get("currPeriod"), dict) else {}
            previous = payload.get("prevPeriod") if isinstance(payload.get("prevPeriod"), dict) else {}
            elements = payload.get("elements") if isinstance(payload.get("elements"), list) else []
            labels = tuple(self._label(item.get("time"), key, now.tzinfo) for item in elements if isinstance(item, dict))
            values = tuple(self._number(item.get("totalSum")) for item in elements if isinstance(item, dict))
            period_snapshot = PeriodSnapshot(
                current=self._number(current.get("totalSum")),
                previous=self._number(previous.get("totalSum")),
                labels=labels,
                values=values,
                average_check=self._number(current.get("avgBill")),
                receipt_count=max(0, int(self._number(current.get("saleCount")))),
                details_loaded=True,
            )
            return key, period_snapshot, current

        periods: dict[str, PeriodSnapshot] = {}
        day_data: dict = {}
        with ThreadPoolExecutor(max_workers=3, thread_name_prefix="sai-dashboard") as pool:
            for key, snapshot, current in pool.map(fetch_period, ("day", "week", "month")):
                periods[key] = snapshot
                if key == "day":
                    day_data = current
        snapshot = StoreSnapshot(
            revenue=self._number(day_data.get("totalSum")),
            average_check=self._number(day_data.get("avgBill")),
            receipt_count=max(0, int(self._number(day_data.get("saleCount")))),
            periods=periods,
            connected=True,
        )
        self._save(snapshot)
        return snapshot

    def _save(self, snapshot: StoreSnapshot) -> None:
        payload = {
            "today": {
                "revenue": snapshot.revenue,
                "average_check": snapshot.average_check,
                "receipt_count": snapshot.receipt_count,
            },
            "periods": {
                key: {
                    "current": value.current,
                    "previous": value.previous,
                    "average_check": value.average_check,
                    "receipt_count": value.receipt_count,
                    "details_loaded": value.details_loaded,
                    "points": [
                        {"label": label, "value": amount}
                        for label, amount in zip(value.labels, value.values)
                    ],
                }
                for key, value in (snapshot.periods or {}).items()
            },
            "updated_at": dt.datetime.now().astimezone().isoformat(),
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        temporary.replace(self.path)


def _money(value: float) -> str:
    return f"{value:,.0f} ₽".replace(",", " ")


class MetricCard(QFrame):
    def __init__(self, title: str, accent: str, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("StoreMetricCard")
        self.setProperty("accent", accent)
        self.setMinimumHeight(132)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 15)
        layout.setSpacing(5)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("StoreMetricTitle")
        self.value_label = QLabel("0")
        self.value_label.setObjectName("StoreMetricValue")
        self.hint_label = QLabel("Сегодня")
        self.hint_label.setObjectName("StoreMetricHint")
        layout.addWidget(self.title_label)
        layout.addStretch(1)
        layout.addWidget(self.value_label)
        layout.addWidget(self.hint_label)


class RecommendedActionCard(QFrame):
    """Reserved dashboard slot for future data-driven SAI recommendations."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("StoreRecommendedAction")
        self.setMinimumHeight(132)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 15)
        layout.setSpacing(6)
        title = QLabel("Рекомендованное действие")
        title.setObjectName("StoreRecommendedTitle")
        message = QLabel("Здесь появится следующая полезная подсказка для магазина")
        message.setObjectName("StoreRecommendedText")
        message.setWordWrap(True)
        hint = QLabel("Раздел готовится")
        hint.setObjectName("StoreRecommendedHint")
        layout.addWidget(title)
        layout.addStretch(1)
        layout.addWidget(message)
        layout.addWidget(hint)


class DashboardPanel(QFrame):
    def __init__(self, title: str, tone: str = "plain", parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("StoreDashboardPanel")
        self.setProperty("tone", tone)
        self.layout_box = QVBoxLayout(self)
        self.layout_box.setContentsMargins(18, 16, 18, 16)
        self.layout_box.setSpacing(10)
        title_label = QLabel(title)
        title_label.setObjectName("StorePanelTitle")
        self.layout_box.addWidget(title_label)


def _clear_layout(layout: QVBoxLayout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        if widget is not None:
            widget.deleteLater()


class SalesChart(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.labels: tuple[str, ...] = ()
        self.values: tuple[float, ...] = ()
        self._points: list[QPointF] = []
        self._plot_rect = QRectF()
        self.setMinimumHeight(150)
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.MinimumExpanding)

    def set_series(self, labels: tuple[str, ...], values: tuple[float, ...]) -> None:
        self.labels = labels
        self.values = values
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        dark = bool(self.window().property("saiNightTheme"))
        text = QColor("#aab6ca" if dark else "#7a879c")
        grid = QColor("#344158" if dark else "#e5eaf2")
        blue = QColor("#2f6df6")
        rect = QRectF(self.rect()).adjusted(58, 14, -16, -30)
        self._plot_rect = rect
        painter.setFont(QFont("Segoe UI", 8))
        values = self.values
        maximum = max(values, default=0.0)
        scale_max = max(1.0, maximum * 1.12)
        for step in range(5):
            y = rect.bottom() - rect.height() * step / 4
            painter.setPen(QPen(grid, 1))
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            painter.setPen(text)
            amount = scale_max * step / 4
            painter.drawText(
                QRectF(0, y - 9, rect.left() - 8, 18),
                Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                self._axis_money(amount),
            )
        if not values or maximum <= 0:
            self._points = []
            painter.setPen(text)
            painter.setFont(QFont("Segoe UI", 11, QFont.Weight.DemiBold))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "Продаж пока нет")
            painter.end()
            return
        count = max(2, len(values))
        points: list[QPointF] = []
        for index, value in enumerate(values):
            x = rect.left() + rect.width() * index / (count - 1)
            y = rect.bottom() - rect.height() * value / scale_max
            points.append(QPointF(x, y))
        self._points = points
        fill = QPainterPath(points[0])
        line = QPainterPath(points[0])
        for point in points[1:]:
            line.lineTo(point)
            fill.lineTo(point)
        fill.lineTo(QPointF(points[-1].x(), rect.bottom()))
        fill.lineTo(QPointF(points[0].x(), rect.bottom()))
        fill.closeSubpath()
        translucent = QColor(blue)
        translucent.setAlpha(34)
        painter.save()
        painter.setClipRect(rect)
        painter.fillPath(fill, translucent)
        painter.setPen(QPen(blue, 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        painter.drawPath(line)
        painter.setBrush(blue)
        painter.setPen(QPen(QColor("#ffffff"), 1.5))
        if len(points) <= 10:
            for point in points:
                painter.drawEllipse(point, 3.5, 3.5)
        painter.restore()
        painter.setPen(text)
        painter.setFont(QFont("Segoe UI", 8))
        indices = self._label_indices(len(self.labels))
        for index in indices:
            if index >= len(points):
                continue
            label = self.labels[index]
            x = points[index].x()
            painter.drawText(QRectF(x - 34, rect.bottom() + 6, 68, 18), Qt.AlignmentFlag.AlignCenter, label)
        painter.end()

    @staticmethod
    def _axis_money(value: float) -> str:
        if value >= 1_000_000:
            return f"{value / 1_000_000:.1f}м".replace(".0", "").replace(".", ",")
        if value >= 1_000:
            return f"{value / 1_000:.0f}к"
        return f"{value:.0f}"

    @staticmethod
    def _label_indices(count: int) -> tuple[int, ...]:
        if count <= 1:
            return (0,) if count else ()
        wanted = min(6, count)
        return tuple(sorted({round(index * (count - 1) / (wanted - 1)) for index in range(wanted)}))

    def mouseMoveEvent(self, event) -> None:  # noqa: N802 - Qt override
        if not self._points or not self._plot_rect.contains(event.position()):
            QToolTip.hideText()
            return super().mouseMoveEvent(event)
        index = min(range(len(self._points)), key=lambda item: abs(self._points[item].x() - event.position().x()))
        label = self.labels[index] if index < len(self.labels) else ""
        value = self.values[index] if index < len(self.values) else 0.0
        QToolTip.showText(event.globalPosition().toPoint(), f"{label}\n{_money(value)}", self)
        super().mouseMoveEvent(event)


class StoreDashboardPage(QWidget):
    snapshot_loaded = Signal(object, str)
    PERIODS = {
        "day": ("День", "к предыдущему дню"),
        "week": ("Неделя", "к предыдущей неделе"),
        "month": ("Месяц", "к предыдущему месяцу"),
    }

    def __init__(self, parent=None, service: StoreDashboardService | None = None) -> None:
        super().__init__(parent)
        self.controller = parent
        self.setObjectName("StoreDashboardPage")
        self.service = service or StoreDashboardService()
        self.snapshot = StoreSnapshot()
        self.period = "day"
        self._refresh_running = False
        self.snapshot_loaded.connect(self._remote_loaded)
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 26, 28, 28)
        outer.setSpacing(18)

        metrics = QGridLayout()
        metrics.setHorizontalSpacing(14)
        metrics.setVerticalSpacing(14)
        self.revenue_card = MetricCard("Продажи сегодня", "blue")
        self.average_card = MetricCard("Средний чек", "green")
        self.receipts_card = MetricCard("Пробито чеков", "amber")
        self.recommended_action = RecommendedActionCard()
        for index, card in enumerate((
            self.revenue_card, self.average_card, self.receipts_card, self.recommended_action,
        )):
            metrics.addWidget(card, 0, index)
            metrics.setColumnStretch(index, 1)
        outer.addLayout(metrics)

        chart_card = QFrame()
        chart_card.setObjectName("StoreChartCard")
        chart_layout = QVBoxLayout(chart_card)
        chart_layout.setContentsMargins(20, 18, 20, 18)
        chart_layout.setSpacing(12)
        chart_header = QHBoxLayout()
        chart_title_box = QVBoxLayout()
        chart_title = QLabel("Продажи")
        chart_title.setObjectName("StoreChartTitle")
        self.period_total = QLabel("0 ₽")
        self.period_total.setObjectName("StoreChartTotal")
        self.period_change = QLabel("Нет предыдущих данных")
        self.period_change.setObjectName("StoreChartChange")
        total_row = QHBoxLayout()
        total_row.addWidget(self.period_total)
        total_row.addWidget(self.period_change)
        total_row.addStretch(1)
        chart_title_box.addWidget(chart_title)
        chart_title_box.addLayout(total_row)
        chart_header.addLayout(chart_title_box)
        chart_header.addStretch(1)
        period_group = QButtonGroup(self)
        period_group.setExclusive(True)
        for key, (label, _) in self.PERIODS.items():
            button = QPushButton(label)
            button.setObjectName("StorePeriodButton")
            button.setCheckable(True)
            button.setChecked(key == self.period)
            button.clicked.connect(lambda checked=False, value=key: self.set_period(value))
            period_group.addButton(button)
            chart_header.addWidget(button)
        chart_layout.addLayout(chart_header)
        self.chart = SalesChart()
        chart_layout.addWidget(self.chart, 1)
        middle = QGridLayout()
        middle.setHorizontalSpacing(14)
        middle.setVerticalSpacing(14)
        middle.addWidget(chart_card, 0, 0)
        middle.setColumnStretch(0, 64)

        receipts = DashboardPanel("Приёмка", "coral")
        receipts_header = QHBoxLayout()
        self.receipts_count = QLabel("0 активных")
        self.receipts_count.setObjectName("StorePanelMeta")
        new_receipt = QPushButton("Новый привоз  +")
        new_receipt.setObjectName("StorePanelAction")
        new_receipt.clicked.connect(self._open_receipts)
        receipts_header.addWidget(self.receipts_count)
        receipts_header.addStretch(1)
        receipts_header.addWidget(new_receipt)
        receipts.layout_box.addLayout(receipts_header)
        self.receipts_rows = QVBoxLayout()
        self.receipts_rows.setSpacing(5)
        receipts.layout_box.addLayout(self.receipts_rows)
        receipts.layout_box.addStretch(1)
        middle.addWidget(receipts, 0, 1)
        middle.setColumnStretch(1, 36)

        stock = DashboardPanel("Склад")
        self.stock_meta = QLabel("Остатки и товары с низким запасом")
        self.stock_meta.setObjectName("StorePanelMeta")
        self.stock_empty = QLabel("Данные об остатках появятся после синхронизации склада")
        self.stock_empty.setObjectName("StoreEmptyState")
        self.stock_empty.setWordWrap(True)
        stock.layout_box.addWidget(self.stock_meta)
        stock.layout_box.addWidget(self.stock_empty)
        stock.layout_box.addStretch(1)
        middle.addWidget(stock, 1, 0)

        day = DashboardPanel("День в движении", "mint")
        self.day_rows = QVBoxLayout()
        self.day_rows.setSpacing(8)
        day.layout_box.addLayout(self.day_rows)
        day.layout_box.addStretch(1)
        self._add_day_row("○", "План дня ещё не настроен", "—")
        middle.addWidget(day, 1, 1)
        middle.setRowStretch(0, 64)
        middle.setRowStretch(1, 36)
        outer.addLayout(middle, 1)

    def _open_receipts(self) -> None:
        handler = getattr(self.controller, "show_receipt_hub", None)
        if callable(handler):
            handler()

    def _add_day_row(self, marker: str, text: str, time_text: str) -> None:
        row = QHBoxLayout()
        dot = QLabel(marker)
        dot.setObjectName("StoreDayMarker")
        label = QLabel(text)
        label.setObjectName("StoreDayText")
        when = QLabel(time_text)
        when.setObjectName("StorePanelMeta")
        row.addWidget(dot)
        row.addWidget(label, 1)
        row.addWidget(when)
        self.day_rows.addLayout(row)

    def _refresh_receipts(self) -> None:
        _clear_layout(self.receipts_rows)
        try:
            drafts = list(sai_receipt_drafts.list_active())
        except Exception:
            drafts = []
        self.receipts_count.setText(f"{len(drafts)} активных")
        if not drafts:
            empty = QLabel("Активных приёмок пока нет")
            empty.setObjectName("StoreEmptyState")
            self.receipts_rows.addWidget(empty)
            return
        for draft in drafts[:4]:
            row = QFrame()
            row.setObjectName("StoreReceiptRow")
            layout = QHBoxLayout(row)
            layout.setContentsMargins(10, 8, 10, 8)
            layout.setSpacing(9)
            mark = QLabel("↓")
            mark.setObjectName("StoreReceiptMark")
            supplier = QLabel(str(draft.get("supplier") or draft.get("supplier_name") or "Новый привоз"))
            supplier.setObjectName("StoreReceiptSupplier")
            supplier.setWordWrap(True)
            count = draft.get("item_count") or draft.get("rows_count") or ""
            detail = QLabel(f"{count} поз." if count else str(draft.get("stage") or "в работе"))
            detail.setObjectName("StorePanelMeta")
            layout.addWidget(mark)
            layout.addWidget(supplier, 1)
            layout.addWidget(detail)
            self.receipts_rows.addWidget(row)

    def set_period(self, period: str) -> None:
        if period not in self.PERIODS:
            return
        self.period = period
        self._render_period()

    def refresh(self) -> None:
        self.snapshot = self.service.load()
        self._render_snapshot()
        if not self._refresh_running:
            self._refresh_running = True
            threading.Thread(target=self._fetch_remote, daemon=True).start()

    def _render_snapshot(self) -> None:
        self.revenue_card.value_label.setText(_money(self.snapshot.revenue))
        self.average_card.value_label.setText(_money(self.snapshot.average_check))
        self.receipts_card.value_label.setText(str(self.snapshot.receipt_count))
        self._refresh_receipts()
        self._render_period()

    def _fetch_remote(self) -> None:
        try:
            snapshot = self.service.fetch_remote()
            self.snapshot_loaded.emit(snapshot, "")
        except Exception as exc:
            self.snapshot_loaded.emit(None, str(exc))

    def _remote_loaded(self, snapshot, error: str) -> None:
        self._refresh_running = False
        if isinstance(snapshot, StoreSnapshot):
            self.snapshot = snapshot
            self.setToolTip("")
            self._render_snapshot()
            return
        self.setToolTip(error)

    def _render_period(self) -> None:
        periods = self.snapshot.periods or {}
        period = periods.get(self.period, PeriodSnapshot())
        period_hint = {
            "day": "Сегодня",
            "week": "Последние 7 дней",
            "month": "Последние 30 дней",
        }[self.period]
        self.revenue_card.title_label.setText({
            "day": "Продажи сегодня",
            "week": "Продажи за 7 дней",
            "month": "Продажи за 30 дней",
        }[self.period])
        self.revenue_card.value_label.setText(_money(period.current))
        self.average_card.value_label.setText(_money(period.average_check) if period.details_loaded else "…")
        self.receipts_card.value_label.setText(str(period.receipt_count) if period.details_loaded else "…")
        for card in (
            self.revenue_card, self.average_card, self.receipts_card,
        ):
            card.hint_label.setText(period_hint)
        self.period_total.setText(_money(period.current))
        change = period.change_percent
        if change is None:
            change_text = "Первый период с данными"
            positive = True
        else:
            sign = "+" if change > 0 else ""
            change_text = f"{sign}{change:.1f}% {self.PERIODS[self.period][1]}"
            positive = change >= 0
        self.period_change.setText(change_text.replace(".", ","))
        self.period_change.setProperty("positive", positive)
        self.period_change.style().unpolish(self.period_change)
        self.period_change.style().polish(self.period_change)
        labels, values = period.labels, period.values
        if self.period == "day":
            labels, values = self._working_day_series(labels, values)
        self.chart.set_series(labels, values)

    @staticmethod
    def _working_day_series(
        labels: tuple[str, ...], values: tuple[float, ...],
    ) -> tuple[tuple[str, ...], tuple[float, ...]]:
        """Use the chart width for trading hours instead of an empty night."""
        active = [index for index, value in enumerate(values) if value > 0]
        if not active:
            return labels, values
        first = max(0, active[0] - 1)
        last = min(len(values) - 1, active[-1] + 1)
        return labels[first:last + 1], values[first:last + 1]


__all__ = [
    "PeriodSnapshot", "SalesChart", "StoreDashboardPage",
    "StoreDashboardService", "StoreSnapshot",
]
