#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Runtime checks for the manager calendar and SAI EMP clock surface."""
from __future__ import annotations

import os
import tempfile

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_staff_ui_")

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication

import sai_staff
from sai_staff_ui import EmployeeClockPage, StaffPage


def main() -> int:
    app = QApplication.instance() or QApplication([])
    page = StaffPage()
    assert page.schedule_stack.currentIndex() == 0

    person_id = sai_staff.save_employee("Анна", "Продавец", "daily", 2000)
    hourly_id = sai_staff.save_employee("Михаил", "Специалист", "hourly", 500)
    page.refresh()
    page.resize(1280, 720)
    page.show()
    app.processEvents()
    assert page.schedule_stack.currentIndex() == 1
    assert page.view_mode == "month"
    assert len(page._schedule_tables) == 1
    table = page._schedule_tables[0]
    assert table.rowCount() == 2
    assert 29 <= table.columnCount() - 1 <= 31
    assert table.item(0, 0).text() in {"Анна", "Михаил"}
    assert page.inline_add_employee.text() == "＋ Новый сотрудник"
    assert table.horizontalScrollBar().maximum() == 0
    assert table.columnWidth(1) == table.rowHeight(0)

    payload = table.item(0, 1).data(256)
    assert payload["employee_id"] in {person_id, hourly_id}
    QTest.mouseClick(table.viewport(), Qt.MouseButton.LeftButton, pos=table.visualItemRect(table.item(0, 1)).center())
    app.processEvents()
    assert len(sai_staff.shifts_between(payload["date"], payload["date"])) == 1
    painted = table.viewport().grab().toImage().pixelColor(table.visualItemRect(table.item(0, 1)).center())
    assert painted.blue() > 180 and painted.red() < 100, painted.name()
    QTest.mouseClick(table.viewport(), Qt.MouseButton.LeftButton, pos=table.visualItemRect(table.item(0, 1)).center())
    app.processEvents()
    assert sai_staff.shifts_between(payload["date"], payload["date"]) == []

    page.reorder_employee(hourly_id, 0)
    assert sai_staff.employees()[0]["id"] == hourly_id

    employee_page = EmployeeClockPage(hourly_id)
    assert employee_page.action.text() == "Я пришёл на работу"
    employee_page.toggle()
    assert sai_staff.running_entry(hourly_id)
    employee_page.toggle()
    assert not sai_staff.running_entry(hourly_id)
    employee_page.close()
    page.close()
    print("SAI staff UI tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
