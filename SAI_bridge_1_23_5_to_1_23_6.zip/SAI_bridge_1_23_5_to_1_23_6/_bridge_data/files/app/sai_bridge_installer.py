#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fast, rollback-capable bridge from SAI 1.23.1 to the current build.

The bridge directory is placed directly inside the existing SAI directory.
It replaces program files only.  ``user_data`` and ``app/.venv`` are never
part of the payload and are never overwritten.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any


class BridgeError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_relative(value: Any) -> Path:
    path = Path(str(value or ""))
    if not path.parts or path.is_absolute() or ".." in path.parts:
        raise BridgeError("Manifest contains an unsafe file path.")
    return path


def detected_version(target: Path) -> str:
    version_file = target / "app" / "sai_version.py"
    if not version_file.is_file():
        raise BridgeError("The selected folder is not an SAI installation.")
    text = version_file.read_text(encoding="utf-8-sig", errors="replace")
    match = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
    if not match:
        raise BridgeError("Cannot determine the installed SAI version.")
    return match.group(1).strip().lstrip("v")


def runtime_python(target: Path) -> Path:
    for path in (
        target / "app" / ".venv" / "Scripts" / "python.exe",
        target / "_runtime" / "python" / "python.exe",
        target / "_offline" / "python" / "python.exe",
    ):
        if path.is_file():
            return path
    raise BridgeError("The existing SAI Python runtime was not found.")


def discover_target(package: Path) -> Path:
    """Find the SAI root when a release was unpacked below user_data/updates."""
    package = package.resolve()
    for candidate in (package, *package.parents):
        if (candidate / "app" / "sai_version.py").is_file():
            return candidate
        if candidate.name.casefold() == "user_data":
            root = candidate.parent
            if (root / "app" / "sai_version.py").is_file():
                return root
    raise BridgeError("Cannot locate the existing SAI installation automatically.")


def restart_sai(target: Path) -> None:
    for name in ("Start SAI Hub.vbs", "Запустить SAI Hub.vbs", "START_SAI.cmd"):
        launcher = target / name
        if launcher.is_file():
            os.startfile(str(launcher))  # type: ignore[attr-defined]
            return
    raise BridgeError("SAI was updated, but its launcher was not found for automatic restart.")


def validate_payload(package: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    manifest_path = package / "_bridge_data" / "manifest.json"
    if not manifest_path.is_file():
        raise BridgeError("Bridge manifest is missing.")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise BridgeError("Bridge manifest is damaged.") from exc
    if int(manifest.get("schema_version") or 0) != 1:
        raise BridgeError("Unsupported bridge format.")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise BridgeError("Bridge payload is empty.")
    payload_root = package / "_bridge_data" / "files"
    for item in files:
        if not isinstance(item, dict):
            raise BridgeError("Bridge file record is invalid.")
        relative = safe_relative(item.get("path"))
        source = payload_root / relative
        if not source.is_file():
            raise BridgeError(f"Bridge file is missing: {relative}")
        if int(item.get("size") or -1) != source.stat().st_size or sha256(source) != str(item.get("sha256") or ""):
            raise BridgeError(f"Bridge integrity check failed: {relative}")
    return manifest, files


def run_postcheck(target: Path, python: Path, expected_version: str) -> None:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["SAI_USER_DATA_DIR"] = str(target / "user_data")
    code = (
        "import sys; sys.path.insert(0, 'app'); "
        "from sai_version import APP_VERSION; "
        f"assert APP_VERSION == {expected_version!r}, APP_VERSION; "
        "import sai_runtime_paths, sai_github_updates; "
        "print(APP_VERSION)"
    )
    result = subprocess.run(
        [str(python), "-c", code], cwd=str(target), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", timeout=60,
    )
    if result.returncode:
        raise BridgeError("Updated SAI did not pass the startup check:\n" + result.stdout[-2000:])


def restore(target: Path, backup_files: Path, applied: list[tuple[Path, bool]]) -> None:
    for relative, existed in reversed(applied):
        destination = target / relative
        backup = backup_files / relative
        try:
            if existed and backup.is_file():
                destination.parent.mkdir(parents=True, exist_ok=True)
                temporary = destination.with_suffix(destination.suffix + ".rollback.tmp")
                shutil.copy2(backup, temporary)
                os.replace(temporary, destination)
            elif not existed and destination.exists():
                destination.unlink()
        except Exception:
            pass


def install(package: Path, target: Path, *, force: bool = False, log=print) -> Path:
    package = package.resolve()
    target = target.resolve()
    manifest, files = validate_payload(package)
    source_version = detected_version(target)
    supported = {str(value).strip().lstrip("v") for value in manifest.get("supported_versions") or []}
    expected_version = str(manifest.get("target_app_version") or "").strip()
    if not expected_version:
        raise BridgeError("Target version is missing from the manifest.")
    if source_version not in supported and source_version != expected_version.lstrip("v") and not force:
        raise BridgeError(
            f"This bridge supports {', '.join(sorted(supported))}; installed version is {source_version}."
        )

    python = runtime_python(target)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_root = target / "user_data" / "backups" / f"bridge_{source_version}_to_{expected_version.lstrip('v')}_{stamp}"
    backup_files = backup_root / "files"
    backup_files.mkdir(parents=True, exist_ok=False)
    applied: list[tuple[Path, bool]] = []
    payload_root = package / "_bridge_data" / "files"
    report = {
        "source_version": source_version,
        "target_version": expected_version,
        "started_at": dt.datetime.now().astimezone().isoformat(),
        "status": "RUNNING",
        "backup": str(backup_root),
        "repository": str(manifest.get("update_repository") or ""),
    }
    (backup_root / "BRIDGE_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    log(f"Installed SAI: {source_version}")
    log(f"Target SAI: {expected_version}")
    log(f"Backup: {backup_root}")
    try:
        for index, item in enumerate(files, start=1):
            relative = safe_relative(item.get("path"))
            # These locations are immutable bridge invariants, even if a bad
            # manifest somehow passes through a future builder.
            if relative.parts[0] in {"user_data", ".git"} or ".venv" in relative.parts:
                raise BridgeError(f"Bridge attempted to touch protected data: {relative}")
            source = payload_root / relative
            destination = target / relative
            existed = destination.is_file()
            if existed:
                backup = backup_files / relative
                backup.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(destination, backup)
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_suffix(destination.suffix + f".{os.getpid()}.bridge.tmp")
            shutil.copy2(source, temporary)
            os.replace(temporary, destination)
            applied.append((relative, existed))
            if index % 100 == 0:
                log(f"Updated {index}/{len(files)} files...")

        run_postcheck(target, python, expected_version)
        report["status"] = "INSTALLED"
        report["completed_at"] = dt.datetime.now().astimezone().isoformat()
        (backup_root / "BRIDGE_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        installed = target / "user_data" / "installed_build.json"
        installed.parent.mkdir(parents=True, exist_ok=True)
        installed.write_text(json.dumps({
            "version": expected_version,
            "build_id": str(manifest.get("build_id") or ""),
            "installation": "bridge-update",
            "source_version": source_version,
            "update_repository": str(manifest.get("update_repository") or ""),
            "installed_at": report["completed_at"],
            "backup": str(backup_root),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        log("Bridge update completed successfully.")
        return backup_root
    except Exception:
        log("Update failed. Restoring the previous program files...")
        restore(target, backup_files, applied)
        report["status"] = "ROLLED_BACK"
        report["completed_at"] = dt.datetime.now().astimezone().isoformat()
        report["error"] = traceback.format_exc()
        (backup_root / "BRIDGE_REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=Path)
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--restart", action="store_true")
    parser.add_argument("--wait-seconds", type=float, default=0.0)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    target = args.target.resolve() if args.target else discover_target(package)
    log_path = package / "SAI_BRIDGE_LAST_LOG.txt"
    log_path.write_text("SAI Bridge update\n", encoding="utf-8")

    def write_log(value: object = "") -> None:
        text = str(value)
        print(text, flush=True)
        with log_path.open("a", encoding="utf-8") as stream:
            stream.write(text + "\n")

    try:
        if args.wait_seconds > 0:
            time.sleep(min(args.wait_seconds, 15.0))
        install(package, target, force=args.force, log=write_log)
        if args.restart:
            write_log("Restarting SAI...")
            restart_sai(target)
        return 0
    except Exception as exc:
        write_log("ERROR: " + str(exc))
        write_log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
