"""Compatibility styles. New shared rules belong in sai_design_tokens and sai_ui_style."""

STYLESHEET = """
QWidget {
    background: #f5f7fb;
    color: #0f172a;
    font-family: 'Segoe UI';
    font-size: 13px;
}
QWidget#FramelessWindowShell {
    background: #f5f7fb;
}
QFrame#FramelessTitleBar {
    background: #f5f7fb;
    border: none;
}
QLabel#FramelessTitleBrand {
    color: #64748b;
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1px;
}
QPushButton#WindowControlButton {
    background: transparent;
    border: none;
    border-radius: 0;
    padding: 0;
}
QPushButton#WindowControlButton:hover {
    background: #e6ebf3;
}
QPushButton#WindowControlButton[kind="close"]:hover {
    background: #e5484d;
}

QWidget#SplashPage {
    background: #ffffff;
}
QLabel#SplashTitle {
    background: transparent;
    color: #172033;
}
QLabel#SplashVersion {
    background: transparent;
    color: #64748b;
}
QLabel#SplashDots {
    background: transparent;
    color: #2563eb;
}
QWidget#StartupGate {
    background: #ffffff;
}
QFrame#StartupFastCanvas {
    background: #ffffff;
}
QFrame#StartupUpdateGate {
    background: #f5f8fd;
}
QFrame#StartupUpdatePanel {
    background: #ffffff;
    border: 1px solid #dce6f3;
    border-radius: 24px;
}
QLabel#StartupUpdateBadge {
    background: transparent;
    color: #2563eb;
    font-size: 11px;
    font-weight: 900;
    letter-spacing: 1px;
}
QLabel#StartupUpdateTitle {
    background: transparent;
    color: #0b1930;
    font-size: 28px;
    font-weight: 900;
}
QLabel#StartupUpdateSubtitle {
    background: transparent;
    color: #64748b;
    font-size: 14px;
}
QLabel#StartupUpdateNotes {
    background: #f1f6ff;
    color: #334155;
    border: 1px solid #dbeafe;
    border-radius: 13px;
    padding: 12px 14px;
}
QProgressBar#StartupUpdateProgress {
    background: #dbeafe;
    border: none;
    border-radius: 2px;
}
QProgressBar#StartupUpdateProgress::chunk {
    background: #2563eb;
    border-radius: 2px;
}
QPushButton#StartupUpdateButton {
    background: #2563eb;
    color: #ffffff;
    border: none;
    border-radius: 12px;
    padding: 12px 24px;
    font-size: 14px;
    font-weight: 900;
}
QPushButton#StartupUpdateButton:hover { background: #1d4ed8; }
QPushButton#StartupUpdateButton:pressed { background: #1e40af; }
QPushButton#StartupUpdateButton:disabled { background: #93b4ef; }
QPushButton#StartupUpdateSecondary {
    background: transparent;
    color: #64748b;
    border: none;
    padding: 8px 12px;
    font-weight: 700;
}
QPushButton#StartupUpdateSecondary:hover { color: #2563eb; }
QStackedWidget#MainWindowStack {
    background: #ffffff;
}
QFrame#StartupPanel, QFrame#StartupFirstRunCanvas {
    background: #ffffff;
}
QFrame#StartupFirstRunPanel {
    background: #ffffff;
    border: 1px solid #e5edf8;
    border-radius: 24px;
}
QLabel#StartupTitle {
    color: #081830;
    font-size: 34px;
    font-weight: 800;
}
QLabel#StartupSubtitle {
    color: #64748b;
    font-size: 14px;
}
QLabel#StartupStatus {
    color: #64748b;
    background: transparent;
    border: none;
    padding: 4px 0px;
}
QFrame#StartupForm {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    padding: 14px;
}
QLineEdit#StartupInput {
    background: #ffffff;
    border: 1px solid #dbe3ef;
    border-radius: 12px;
    padding: 9px 12px;
    color: #0f172a;
}
QLineEdit#StartupInput:focus {
    border: 1px solid #2563eb;
}
QTextEdit#StartupLog {
    background: #0f172a;
    color: #dbeafe;
    border: none;
    border-radius: 16px;
    padding: 12px;
    font-family: Consolas;
    font-size: 12px;
}
QPushButton#StartupPrimary {
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 12px;
    padding: 11px 18px;
    font-weight: 800;
}
QPushButton#StartupPrimary:disabled {
    background: #bfdbfe;
    color: #eff6ff;
}
QPushButton#StartupSecondary {
    background: #f1f5f9;
    color: #334155;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 11px 18px;
    font-weight: 700;
}
QLabel {
    background: transparent;
}
QCheckBox {
    background: transparent;
}
QTabWidget {
    background: transparent;
}
QTabBar {
    background: transparent;
}
QFrame#Rail {
    background: #0f172a;
    border: none;
}
QFrame#RailTopBlock,
QFrame#RailBottomBlock {
    background: transparent;
    border: none;
}
QLabel#RailBrand {
    background: transparent;
    color: white;
    font-size: 34px;
    font-weight: 900;
    letter-spacing: 1px;
}
QLabel#RailSub {
    background: transparent;
    color: #94a3b8;
    font-size: 13px;
}
QLabel#RailSection {
    background: transparent;
    color: #64748b;
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
    padding-top: 8px;
}
QLabel#RailVersion {
    background: transparent;
    color: #94a3b8;
    font-size: 9px;
    padding: 0;
}
QCheckBox#RailCheck {
    background: transparent;
    color: #e2e8f0;
    spacing: 8px;
}
QCheckBox#RailCheck::indicator {
    width: 16px;
    height: 16px;
}
QPushButton {
    outline: none;
}
QPushButton#PrimaryRailButton {
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 13px;
    padding: 11px 14px;
    font-weight: 700;
    text-align: left;
}
QPushButton#PrimaryRailButton:hover { background: #1d4ed8; }
QPushButton#SecondaryRailButton {
    background: rgba(148, 163, 184, 0.22);
    color: #e2e8f0;
    border: 1px solid rgba(226, 232, 240, 0.16);
    border-radius: 12px;
    padding: 10px 13px;
    font-weight: 800;
    text-align: left;
}
QPushButton#SecondaryRailButton:hover { background: rgba(148, 163, 184, 0.34); }
QPushButton#SecondaryRailButton:checked {
    background: rgba(148, 163, 184, 0.42);
    color: white;
}
QPushButton#RailButton {
    background: rgba(255, 255, 255, 0.08);
    color: #e2e8f0;
    border: 1px solid rgba(255, 255, 255, 0.09);
    border-radius: 12px;
    padding: 10px 13px;
    text-align: left;
}
QPushButton#RailButton:hover { background: rgba(255, 255, 255, 0.14); }
QPushButton#RailButton:checked {
    background: rgba(255, 255, 255, 0.18);
    color: white;
    border: 1px solid rgba(255, 255, 255, 0.20);
    font-weight: 800;
}

QFrame#PageHeader {
    background: transparent;
    border: none;
}
QLabel#PageHeaderTitle {
    background: transparent;
    color: #0f172a;
    font-size: 30px;
    font-weight: 900;
}
QLabel#PageHeaderSubtitle {
    background: transparent;
    color: #64748b;
    font-size: 14px;
}

QFrame#MainArea {
    background: #f5f7fb;
}
QStackedWidget#ContentStack {
    background: #f5f7fb;
}
QScrollArea {
    background: #f5f7fb;
    border: none;
}
QScrollArea QWidget#qt_scrollarea_viewport {
    background: #f5f7fb;
}
QScrollArea#WorkbenchScroll {
    background: #f5f7fb;
    border: none;
}
QWidget#WorkbenchBody {
    background: #f5f7fb;
}
QWidget#StatsPage {
    background: #f5f7fb;
}
QFrame#StatsHeader {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QLabel#StatsTitle {
    background: transparent;
    font-size: 25px;
    font-weight: 800;
    color: #0f172a;
}
QLabel#StatsSubtitle {
    background: transparent;
    color: #64748b;
    font-size: 13px;
}
QPushButton#StatsRefreshButton {
    background: white;
    color: #111827;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    padding: 9px 18px;
    font-weight: 700;
}
QPushButton#StatsRefreshButton:hover { background: #f8fafc; }

QFrame#Hero {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ffffff, stop:1 #eff6ff);
    border: 1px solid #e2e8f0;
    border-radius: 22px;
}
QLabel#HeroTitle {
    background: transparent;
    font-size: 28px;
    font-weight: 800;
    color: #0f172a;
}
QLabel#HeroSubtitle {
    background: transparent;
    color: #64748b;
    font-size: 14px;
}
QLabel#StatusPill {
    background: #dcfce7;
    color: #166534;
    border-radius: 11px;
    padding: 6px 11px;
    font-weight: 700;
}
QPushButton#HeroButton {
    background: #111827;
    color: white;
    border: none;
    border-radius: 14px;
    padding: 12px 22px;
    font-weight: 800;
}
QPushButton#HeroButton:hover { background: #020617; }
QPushButton#HeroButton:pressed { background: #1e293b; }
QPushButton#HeroSecondaryButton {
    background: white;
    color: #111827;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    padding: 9px 18px;
    font-weight: 600;
}
QFrame#StepPill {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
}
QLabel#StepNumber {
    background: #eff6ff;
    color: #1d4ed8;
    border-radius: 10px;
    padding: 4px 8px;
    font-weight: 800;
}
QLabel#StepText {
    background: transparent;
    color: #334155;
    font-weight: 600;
}
QFrame#MetricCard {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QLabel#CardTitle {
    background: transparent;
    color: #64748b;
    font-weight: 700;
}
QLabel#CardValue {
    background: transparent;
    color: #0f172a;
    font-size: 21px;
    font-weight: 800;
}
QLabel#CardHint {
    background: transparent;
    color: #64748b;
    font-size: 12px;
}
QLabel#Dot_green { color: #22c55e; }
QLabel#Dot_blue { color: #3b82f6; }
QLabel#Dot_amber { color: #f59e0b; }
QLabel#Dot_purple { color: #8b5cf6; }
QTabWidget::pane {
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    background: white;
    top: -1px;
}
QTabBar::tab {
    background: #e2e8f0;
    color: #334155;
    padding: 9px 16px;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    margin-right: 4px;
    font-weight: 700;
}
QTabBar::tab:selected {
    background: white;
    color: #0f172a;
    border: 1px solid #e2e8f0;
    border-bottom: 1px solid white;
}
QTableWidget {
    background: white;
    alternate-background-color: #f8fafc;
    border: none;
    gridline-color: transparent;
    selection-background-color: #dbeafe;
    selection-color: #0f172a;
}
QTableWidget::item {
    padding: 7px;
    border-bottom: 1px solid #f1f5f9;
}
QHeaderView::section {
    background: #f8fafc;
    color: #475569;
    padding: 8px;
    border: none;
    border-bottom: 1px solid #e2e8f0;
    font-weight: 800;
}

QLabel#WorkbenchTitle {
    background: transparent;
    font-size: 30px;
    font-weight: 900;
    color: #0f172a;
}
QLabel#WorkbenchSubtitle {
    background: transparent;
    color: #64748b;
    font-size: 14px;
}
QFrame#WorkbenchCard {
    background: white;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
}
QFrame#WorkbenchCard[dropTarget="true"] {
    border: 1px dashed #93c5fd;
}
QFrame#WorkbenchCard[dropTarget="true"][dragActive="true"] {
    background: #eff6ff;
    border: 2px solid #2563eb;
}
QLabel#WorkbenchSection {
    background: transparent;
    color: #0f172a;
    font-size: 16px;
    font-weight: 900;
}
QLabel#WorkbenchFile {
    background: #f8fafc;
    border-radius: 12px;
    padding: 10px 12px;
    color: #334155;
}
QLabel#WorkbenchFieldLabel {
    background: transparent;
    color: #475569;
    font-weight: 700;
}
QFrame#InvoiceDropOverlay {
    background: rgba(219, 234, 254, 0.94);
    border: 3px solid #2563eb;
}
QLabel#InvoiceDropTitle {
    background: transparent;
    color: #0f172a;
    font-size: 24px;
    font-weight: 900;
    padding: 8px 20px;
}
QLineEdit#WorkbenchInput, QComboBox#WorkbenchCombo {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 11px;
    padding: 9px 11px;
    min-height: 22px;
}
QComboBox#WorkbenchCombo::drop-down {
    border: none;
    width: 30px;
}
QComboBox#WorkbenchCombo::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #334155;
    margin-right: 10px;
}
QLineEdit#WorkbenchInput:focus, QComboBox#WorkbenchCombo:focus {
    border: 1px solid #2563eb;
}
QTableWidget#ReceiptTable {
    background: white;
    alternate-background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
    gridline-color: transparent;
    selection-background-color: #dbeafe;
    selection-color: #0f172a;
}
QTableCornerButton::section {
    background: #f8fafc;
    border: none;
    border-bottom: 1px solid #e2e8f0;

}
QFrame#SuggestionPopup {
    background: rgba(255,255,255,0.98);
    border: 1px solid #dbeafe;
    border-radius: 16px;
}
QFrame#SuggestionRow {
    background: transparent;
    border-radius: 12px;
}
QFrame#SuggestionRow:hover {
    background: #eff6ff;
}
QLabel#SuggestionTitle {
    background: transparent;
    color: #0f172a;
    font-size: 13px;
    font-weight: 500;
}
QLabel#SuggestionMeta {
    background: transparent;
    color: #94a3b8;
    font-size: 11px;
}
QScrollArea#SuggestionScroll, QWidget#SuggestionContent {
    background: transparent;
    border: none;
}
QWidget#CategoryBox, QWidget#QuickCategoryBox {
    background: transparent;
    border: none;
}
QFrame#FreeReceiptCardShell {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QFrame#FreeReceiptInnerCard {
    background: transparent;
    border: none;
}
QWidget#FreePriceTools {
    background: transparent;
    border: none;
}
QLabel#PriceForecastLabel {
    background: transparent;
    color: #94a3b8;
    font-size: 12px;
    font-weight: 800;
}
QComboBox#FreeMarkupCombo {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 11px;
    padding: 8px 8px;
    min-height: 24px;
    max-width: 72px;
    font-weight: 800;
}
QComboBox#FreeMarkupCombo::drop-down {
    border: none;
    width: 18px;
}
QFrame#CategoryInputShell {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 11px;
}
QLineEdit#CategoryInlineEdit {
    background: transparent;
    border: none;
    padding: 4px 2px;
    color: #0f172a;
    min-height: 28px;
}
QFrame#CategoryInlineChip {
    background: #e0f2fe;
    border: none;
    border-radius: 11px;
}
QLabel#CategoryInlineChipLabel {
    background: transparent;
    color: #0369a1;
    font-size: 12px;
    font-weight: 900;
}
QPushButton#CategoryInlineChipClose {
    background: rgba(255,255,255,0.55);
    color: #0369a1;
    border: none;
    border-radius: 9px;
    font-size: 13px;
    font-weight: 900;
    padding: 0px;
}
QPushButton#CategoryInlineChipClose:hover {
    background: rgba(255,255,255,0.85);
    color: #0c4a6e;
}
QWidget#BarcodeTools, QWidget#BarcodeList, QWidget#BarcodeRow {
    background: transparent;
    border: none;
}
QLineEdit#BarcodeEdit {
    background: #ffffff;
    color: #0f172a;
    border: 1px solid #dbe4f0;
    border-radius: 10px;
    padding: 7px 10px;
    font-family: Consolas, 'Courier New';
    font-weight: 800;
}
QLineEdit#BarcodeEdit:hover {
    background: #f8fafc;
    border-color: #bfdbfe;
}
QLineEdit#BarcodeEdit:focus {
    background: #ffffff;
    border-color: #2563eb;
}

QLabel#WorkbenchNote {
    background: transparent;
    color: #64748b;
}

QComboBox#FactStatusCombo {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 7px;
    padding: 5px 8px;
    min-height: 26px;
}
QComboBox#FactStatusCombo::drop-down {
    border: none;
    width: 22px;
}
QFrame#SemiFileSummary {
    background: #f8fbff;
    border: 1px solid #dbeafe;
    border-radius: 14px;
}
QLabel#SemiFileStatusIdle, QLabel#SemiFileStatusOk {
    background: transparent;
    font-size: 15px;
    font-weight: 900;
}
QLabel#SemiFileStatusIdle { color: #64748b; }
QLabel#SemiFileStatusOk { color: #15803d; }
QLabel#SemiFileMetaLabel {
    background: transparent;
    color: #94a3b8;
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
}
QLabel#SemiFileMetaValue {
    background: transparent;
    color: #0f172a;
    font-size: 15px;
    font-weight: 850;
}
QLabel#SemiFileNameValue {
    background: transparent;
    color: #475569;
    font-size: 12px;
}
QFrame#SemiPhonePanel {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
}
QFrame#SemiCurrentPanel {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
}
QLabel#SemiCurrentCaption {
    background: transparent;
    color: #64748b;
    border: none;
    font-size: 11px;
    font-weight: 850;
    letter-spacing: 0.7px;
}
QLabel#SemiCurrentName {
    background: transparent;
    color: #0f172a;
    border: none;
    font-size: 23px;
    font-weight: 900;
}
QLabel#SemiCurrentMeta {
    background: transparent;
    color: #64748b;
    border: none;
    font-size: 13px;
}
QFrame#SemiThermalPanel {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
}
QFrame#SemiFieldPanel {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
}
QFrame#RoundedTableShell {
    background: #ffffff;
    border: 1px solid #dbe4f0;
    border-radius: 16px;
}
QTableWidget#ReceiptTable[saiRoundedByShell="true"] {
    border: none;
    border-radius: 15px;
}
QHeaderView#SemiProductsHeader,
QHeaderView#RoundedTableHeader {
    background: transparent;
    border: none;
}
QHeaderView#SemiProductsHeader::section:first,
QHeaderView#RoundedTableHeader::section:first {
    border-top-left-radius: 13px;
}
QHeaderView#SemiProductsHeader::section:last,
QHeaderView#RoundedTableHeader::section:last {
    border-top-right-radius: 13px;
}
QLabel#SemiThermalTitle {
    background: transparent;
    color: #0f172a;
    border: none;
    font-size: 13px;
    font-weight: 850;
}
QCheckBox#SaiToggleSwitch {
    background: transparent;
    border: none;
    padding: 0;
}
QFrame#SemiEditGroup {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 13px;
}
QFrame#SemiPrintModule {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 13px;
}
QLabel#SemiEditGroupTitle {
    background: transparent;
    color: #0f172a;
    border: none;
    font-size: 14px;
    font-weight: 900;
}
QLabel#SemiPhoneQr {
    background: #ffffff;
    color: #64748b;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 800;
}

QProgressBar#SemiProgressBar {
    background: #f1f5f9;
    color: #0f172a;
    border: 1px solid #dbe4f0;
    border-radius: 11px;
    padding: 2px;
    min-height: 24px;
    font-weight: 900;
    text-align: center;
}
QProgressBar#SemiProgressBar::chunk {
    background: #60a5fa;
    border-radius: 8px;
}
QLabel#SemiStateIdle, QLabel#SemiStateReady, QLabel#SemiStateOk, QLabel#SemiStateWarn, QLabel#SemiStateError, QLabel#SemiStateDone {
    border-radius: 14px;
    padding: 10px 14px;
    font-size: 17px;
    font-weight: 950;
    letter-spacing: 0.8px;
}
QLabel#SemiStateIdle {
    background: #f8fafc;
    color: #475569;
    border: 1px solid #e2e8f0;
}
QLabel#SemiStateReady {
    background: #e0f2fe;
    color: #075985;
    border: 1px solid #7dd3fc;
}
QLabel#SemiStateOk, QLabel#SemiStateDone {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #86efac;
}
QLabel#SemiStateWarn {
    background: #fef3c7;
    color: #92400e;
    border: 1px solid #fcd34d;
}
QLabel#SemiStateError {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fca5a5;
}

QLabel#InlineStatus {
    background: #eff6ff;
    color: #1e3a8a;
    border: 1px solid #bfdbfe;
    border-radius: 12px;
    padding: 10px 12px;
    font-weight: 700;
}
QPushButton#FreeClearSideButton {
    background: #fee2e2;
    color: #991b1b;
    border: none;
    border-top-left-radius: 17px;
    border-bottom-left-radius: 17px;
    padding: 0px;
    font-size: 18px;
    font-weight: 900;
}
QPushButton#FreeClearSideButton:hover {
    background: #fecaca;
    color: #7f1d1d;
}
QPushButton#FreeClearSideButton:pressed {
    background: #ef4444;
    color: #ffffff;
}
QPushButton#FreeAddSideButton {
    background: #60a5fa;
    color: white;
    border: none;
    border-top-right-radius: 17px;
    border-bottom-right-radius: 17px;
    padding: 0px;
    font-size: 24px;
    font-weight: 900;
}
QPushButton#FreeAddSideButton:hover { background: #3b82f6; }
QPushButton#FreeAddSideButton:pressed { background: #2563eb; }

QWidget#FreePrintTools {
    background: transparent;
    border: none;
}
QCheckBox#FreePrintLabelCheck {
    background: transparent;
    color: #0f172a;
    border: none;
    padding: 8px 2px;
    spacing: 8px;
    font-weight: 800;
}
QCheckBox#FreePrintLabelCheck::indicator {
    width: 16px;
    height: 16px;
}
QCheckBox#FreePrintLabelCheck:checked {
    background: transparent;
}
QPushButton#FreeRepeatPrintButton {
    background: #ffffff;
    color: #334155;
    border: 1px solid #cbd5e1;
    border-radius: 11px;
    padding: 8px 14px;
    font-weight: 800;
}
QPushButton#FreeRepeatPrintButton:hover {
    border-color: #93c5fd;
    background: #f8fafc;
}
QPushButton#ManualRowDeleteButton {
    background: transparent;
    border: none;
    border-radius: 9px;
    padding: 0;
    margin: 3px;
    font-size: 18px;
    font-weight: 900;
}
QPushButton#ManualRowDeleteButton {
    color: #dc2626;
}
QPushButton#ManualRowDeleteButton:hover {
    background: #fee2e2;
}
QPushButton#ManualReceiptNewButton {
    background: #ffffff;
    color: #2563eb;
    border: 1px solid #bfdbfe;
    border-radius: 10px;
    padding: 4px 10px;
    font-size: 11px;
    font-weight: 900;
}
QPushButton#ManualReceiptNewButton:hover {
    background: #eff6ff;
    border-color: #60a5fa;
}

QWidget#HistoryDeleteCell,
QPushButton#HistoryDeleteButton {
    background: transparent;
    border: none;
    padding: 0;
    margin: 0;
}
QPushButton#WorkbenchPrimaryButton {
    background: #111827;
    color: white;
    border: none;
    border-radius: 15px;
    padding: 13px 24px;
    font-size: 15px;
    font-weight: 900;
}
QPushButton#WorkbenchPrimaryButton:hover { background: #020617; }
QPushButton#PageOrientationConfirmButton {
    background: #2563eb;
    color: #ffffff;
    border: 1px solid #1d4ed8;
    border-radius: 14px;
    padding: 12px 26px;
    font-size: 14px;
    font-weight: 900;
}
QPushButton#PageOrientationConfirmButton:hover {
    background: #1d4ed8;
    border-color: #1e40af;
}
QPushButton#PageOrientationConfirmButton:pressed {
    background: #1e40af;
    border-color: #1e3a8a;
    padding-top: 13px;
    padding-bottom: 11px;
}
QPushButton#PageOrientationConfirmButton:focus {
    border: 2px solid #93c5fd;
}
QPushButton#PageOrientationConfirmButton:disabled {
    background: #cbd5e1;
    color: #64748b;
    border-color: #cbd5e1;
}
QPushButton#SoftButton, QPushButton#GhostButton {
    background: white;
    color: #111827;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    padding: 10px 16px;
    font-weight: 700;
}
QPushButton#SoftButton:hover, QPushButton#GhostButton:hover { background: #f8fafc; }
QPushButton#CategoryPill {
    background: #60a5fa;
    color: white;
    border: none;
    border-radius: 12px;
    padding: 3px 9px;
    font-size: 11px;
    font-weight: 800;
}
QPushButton#CategoryPill:hover { background: #3b82f6; }
QPushButton#CategoryPill:checked { background: #2563eb; color: white; }
QPushButton#SoftPrimaryButton {
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 12px;
    padding: 9px 16px;
    font-weight: 800;
}
QPushButton#SoftPrimaryButton:hover { background: #1d4ed8; }
QPushButton#SoftPrimaryButton:pressed { background: #1e40af; }
QPushButton#BarcodeChip {
    background: #f8fafc;
    color: #0f172a;
    border: 1px solid #cbd5e1;
    border-radius: 10px;
    padding: 7px 10px;
    text-align: left;
    font-family: Consolas, 'Courier New';
    font-weight: 800;
}
QPushButton#BarcodeChip:checked { background: #dbeafe; border-color: #2563eb; color: #1e3a8a; }
QPushButton#DangerHoldButton {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
    border-radius: 12px;
    padding: 8px 14px;
    font-weight: 800;
}
QPushButton#DangerHoldButton:hover {
    background: #fecaca;
    color: #7f1d1d;
    border-color: #fca5a5;
}
QPushButton#DangerHoldButton:pressed {
    background: #ef4444;
    color: #ffffff;
    border-color: #dc2626;
}
QPushButton#TinyDangerButton {
    background: #fff1f2;
    color: #991b1b;
    border: 1px solid #fecdd3;
    border-radius: 10px;
    padding: 7px 0;
    font-weight: 900;
}
QLabel#BarcodePreview {
    background: white;
    border: 1px dashed #cbd5e1;
    border-radius: 14px;
    padding: 8px;
    color: #64748b;
}
QTextEdit#WorkbenchLog {
    background: #0f172a;
    color: #d1fae5;
    border: none;
    border-radius: 16px;
    padding: 12px;
    font-family: Consolas, 'Courier New';
    font-size: 12px;
}


/* Unified notification system ------------------------------------------------ */
QFrame#NotificationToast {
    background: #ffffff;
    border: 1px solid #cbd7e8;
    border-radius: 14px;
}
QWidget#NotificationContent { background: transparent; }
QLabel#NotificationTitle {
    background: transparent;
    color: #0f172a;
    font-weight: 800;
    font-size: 12px;
}
QLabel#NotificationMessage {
    background: transparent;
    color: #526079;
    font-size: 12px;
}
QPushButton#NotificationClose, QPushButton#SAIMessageClose {
    background: transparent;
    color: #94a3b8;
    border: none;
    border-radius: 8px;
    padding: 0;
    font-size: 20px;
    font-weight: 500;
}
QPushButton#NotificationClose:hover, QPushButton#SAIMessageClose:hover {
    background: #eef2f7;
    color: #334155;
}
QFrame#CatalogStatusBadge {
    background: rgba(255,255,255,0.07);
    border: 1px solid rgba(191,219,254,0.20);
    border-radius: 13px;
}
QFrame#CatalogStatusBadge[compactBadge="true"] {
    background: transparent;
    border-color: transparent;
}
QLabel#CatalogStatusTitle {
    background: transparent;
    color: #dbeafe;
    font-size: 10px;
    font-weight: 800;
}
QLabel#CatalogStatusDetail {
    background: transparent;
    color: #93a9ca;
    font-size: 9px;
    font-weight: 600;
}
QDialog#SAIMessageDialog { background: transparent; }
QFrame#SAIMessagePanel {
    background: #ffffff;
    border: 1px solid #dbe3ef;
    border-radius: 20px;
}
QLabel#SAIMessageTitle {
    background: transparent;
    color: #0f172a;
    font-size: 15px;
    font-weight: 800;
}
QLabel#SAIMessageText {
    background: transparent;
    color: #1e293b;
    font-size: 14px;
    font-weight: 600;
}
QLabel#SAIMessageInfo {
    background: transparent;
    color: #64748b;
    font-size: 12px;
}
QPushButton#SAIMessageButton {
    min-width: 92px;
    min-height: 38px;
    padding: 0 16px;
    border-radius: 11px;
    font-weight: 750;
}
QPushButton#SAIMessageButton[kind="primary"] {
    background: #2563eb;
    color: #ffffff;
    border: 1px solid #2563eb;
}
QPushButton#SAIMessageButton[kind="primary"]:hover { background: #1d4ed8; border-color: #1d4ed8; }
QPushButton#SAIMessageButton[kind="primary"]:pressed { background: #1e40af; border-color: #1e40af; }
QPushButton#SAIMessageButton[kind="secondary"] {
    background: #f8fafc;
    color: #334155;
    border: 1px solid #dbe3ef;
}
QPushButton#SAIMessageButton[kind="secondary"]:hover { background: #eef2f7; border-color: #cbd5e1; }
QPushButton#SAIMessageButton[kind="danger"] {
    background: #dc2626;
    color: #ffffff;
    border: 1px solid #dc2626;
}
QPushButton#SAIMessageButton[kind="danger"]:hover { background: #b91c1c; border-color: #b91c1c; }
QDialogButtonBox QPushButton {
    min-height: 38px;
    padding: 0 16px;
    border-radius: 11px;
    font-weight: 700;
}
QLabel#DialogTitle {
    background: transparent;
    font-size: 24px;
    font-weight: 900;
    color: #0f172a;
}
QLabel#DialogSubtitle {
    background: transparent;
    color: #64748b;
    font-size: 13px;
}
QCheckBox#SettingsCheck {
    background: transparent;
    color: #0f172a;
    spacing: 8px;
    font-weight: 600;
}
QCheckBox#SettingsCheck::indicator {
    width: 16px;
    height: 16px;
}
QLabel#ThemeSettingLabel {
    background: transparent;
    color: #172033;
    font-size: 13px;
    font-weight: 750;
}
QFrame#ThemeModeSelector {
    background: #eef2f7;
    border: 1px solid #d8e0eb;
    border-radius: 14px;
}
QPushButton#ThemeModeButton {
    background: transparent;
    border: 1px solid transparent;
    border-radius: 10px;
    padding: 0;
}
QPushButton#ThemeModeButton:hover {
    background: #e3eaf4;
}
QPushButton#ThemeModeButton:focus {
    border-color: #93c5fd;
}
QPushButton#ThemeModeButton:checked {
    background: #2563eb;
    border-color: #2563eb;
}
QPushButton#ThemeModeButton:checked:hover {
    background: #1d4ed8;
    border-color: #1d4ed8;
}
QTimeEdit#ThemeTimeEdit {
    min-height: 48px;
    padding: 0 13px;
    background: #ffffff;
    color: #172033;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
    font-size: 15px;
    font-weight: 800;
}
QTimeEdit#ThemeTimeEdit:focus {
    border: 2px solid #60a5fa;
    padding: 0 12px;
}
QTimeEdit#ThemeTimeEdit:disabled {
    background: #f1f4f8;
    color: #a0acba;
    border-color: #e0e6ee;
}
QLabel#ThemeModeDescription {
    background: transparent;
    color: #64748b;
    font-size: 12px;
}

QWidget#UxPage {
    background: #f5f7fb;
}
QScrollArea#UxScroll {
    border: none;
    background: #f5f7fb;
}
QScrollArea#UxScroll > QWidget > QWidget {
    background: #f5f7fb;
}
QFrame#UxHeaderCard,
QFrame#UxCard {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 20px;
}
QFrame#UxHeaderCard {
    border-radius: 22px;
}
QLabel#UxOverline {
    color: #64748b;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 0.8px;
    text-transform: uppercase;
}
QLabel#UxHeroTitle {
    color: #0f4fbf;
    font-size: 30px;
    font-weight: 950;
}
QLabel#UxHeroProgressText {
    color: #0f172a;
    font-size: 21px;
    font-weight: 900;
}
QProgressBar#UxProgress {
    height: 12px;
    border: none;
    border-radius: 6px;
    background: #e5e7eb;
}
QProgressBar#UxProgress::chunk {
    border-radius: 6px;
    background: #2563eb;
}
QFrame#UxMetric_green,
QFrame#UxMetric_amber,
QFrame#UxMetric_red {
    border-radius: 16px;
    min-width: 150px;
}
QFrame#UxMetric_green { background: #f0fdf4; border: 1px solid #bbf7d0; }
QFrame#UxMetric_amber { background: #fffbeb; border: 1px solid #fde68a; }
QFrame#UxMetric_red { background: #fff1f2; border: 1px solid #fecdd3; }
QLabel#UxMetricDot_green { color: #16a34a; font-size: 18px; }
QLabel#UxMetricDot_amber { color: #d97706; font-size: 18px; }
QLabel#UxMetricDot_red { color: #dc2626; font-size: 18px; }
QLabel#UxMetricTitle { color: #475569; font-size: 12px; font-weight: 800; }
QLabel#UxMetricValue { color: #0f172a; font-size: 23px; font-weight: 950; }
QLabel#UxCardTitle {
    color: #0f172a;
    font-size: 16px;
    font-weight: 950;
}
QFrame#UxActionBox {
    background: #f8fbff;
    border: 1px solid #bfdbfe;
    border-radius: 14px;
}
QLabel#UxMuted {
    color: #64748b;
    font-size: 12px;
    font-weight: 650;
}
QLabel#UxActionText {
    color: #0f172a;
    font-size: 14px;
    font-weight: 950;
}
QFrame#UxAddRowCard {
    background: #ffffff;
    border: 1px dashed #93c5fd;
    border-radius: 18px;
}
QLabel#UxAddRowTitle {
    color: #2563eb;
    font-size: 16px;
    font-weight: 950;
}
QLabel#UxFieldLabel {
    color: #64748b;
    font-size: 12px;
    font-weight: 800;
}
QLabel#UxFieldValue,
QLabel#UxProductName,
QLabel#UxBlueValue {
    color: #0f172a;
    font-size: 17px;
    font-weight: 900;
}
QLabel#UxProductName { font-size: 18px; }
QLabel#UxBlueValue { color: #2563eb; font-size: 20px; }
QLabel#UxInputLook {
    background: #ffffff;
    border: 2px solid #3b82f6;
    border-radius: 12px;
    color: #0f172a;
    font-size: 17px;
    font-weight: 850;
    padding: 10px 12px;
}
QFrame#UxQtyBox {
    background: #ffffff;
    border: 1px solid #dbe4ef;
    border-radius: 12px;
}
QLabel#UxQtyPart {
    color: #0f172a;
    font-size: 17px;
    font-weight: 900;
    padding: 10px 12px;
    border-right: 1px solid #e2e8f0;
}
QPushButton#UxButton,
QPushButton#UxButtonPrimary {
    background: #ffffff;
    color: #2563eb;
    border: 1px solid #93c5fd;
    border-radius: 12px;
    padding: 9px 13px;
    text-align: left;
    font-weight: 900;
}
QPushButton#UxButton:hover { background: #eff6ff; border-color: #60a5fa; }
QPushButton#UxButtonPrimary {
    background: #2563eb;
    color: #ffffff;
    border-color: #2563eb;
}
QPushButton#UxButtonPrimary:hover { background: #1d4ed8; }
QLabel#UxLockHint {
    color: #64748b;
    font-size: 13px;
    font-weight: 800;
}
QTableWidget#UxTable {
    background: #ffffff;
    alternate-background-color: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 14px;
    gridline-color: #e2e8f0;
    color: #0f172a;
    selection-background-color: #dbeafe;
    selection-color: #0f172a;
    font-size: 12px;
}
QTableWidget#UxTable::item {
    padding: 6px;
    border: none;
}
QHeaderView::section {
    background: #f8fafc;
    color: #334155;
    font-weight: 900;
    border: none;
    border-bottom: 1px solid #e2e8f0;
    padding: 9px 8px;
}
QLabel#UxStatus_green,
QLabel#UxStatus_peach,
QLabel#UxStatus_gray,
QLabel#UxStatus_amber {
    border-radius: 9px;
    padding: 5px 8px;
    font-size: 11px;
    font-weight: 900;
    min-width: 82px;
}
QLabel#UxStatus_green { background: #dcfce7; color: #15803d; }
QLabel#UxStatus_peach { background: #ffedd5; color: #ea580c; }
QLabel#UxStatus_gray { background: #e2e8f0; color: #475569; }
QLabel#UxStatus_amber { background: #fef3c7; color: #a16207; }
QLabel#UxFooterNote {
    color: #64748b;
    font-size: 12px;
    font-weight: 650;
    padding: 0 4px;
}

/* v1.21.80 UX preview polish: calmer, denser, closer to a production receiving cockpit. */
QFrame#UxNextActionCard,
QFrame#UxProductCard,
QFrame#UxTableCard,
QFrame#UxSideCard {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QFrame#UxHeaderCard {
    background: #ffffff;
    border: 1px solid #dbeafe;
    border-radius: 22px;
}
QLabel#UxHeroTitle {
    color: #0f4fbf;
    font-size: 28px;
    font-weight: 950;
}
QFrame#UxMetric_blue,
QFrame#UxMetric_green,
QFrame#UxMetric_amber,
QFrame#UxMetric_gray,
QFrame#UxMetric_red {
    border-radius: 15px;
    min-width: 108px;
}
QFrame#UxMetric_blue { background: #eff6ff; border: 1px solid #bfdbfe; }
QFrame#UxMetric_green { background: #f0fdf4; border: 1px solid #bbf7d0; }
QFrame#UxMetric_amber { background: #fffbeb; border: 1px solid #fde68a; }
QFrame#UxMetric_gray { background: #f8fafc; border: 1px solid #e2e8f0; }
QFrame#UxMetric_red { background: #fff1f2; border: 1px solid #fecdd3; }
QLabel#UxMetricTitle { color: #64748b; font-size: 11px; font-weight: 850; }
QLabel#UxMetricValue { color: #0f172a; font-size: 20px; font-weight: 950; }
QFrame#UxStep_done,
QFrame#UxStep_active,
QFrame#UxStep_wait {
    border-radius: 14px;
}
QFrame#UxStep_done { background: #f0fdf4; border: 1px solid #bbf7d0; }
QFrame#UxStep_active { background: #eff6ff; border: 1px solid #93c5fd; }
QFrame#UxStep_wait { background: #f8fafc; border: 1px solid #e2e8f0; }
QLabel#UxStepDot_done { color: #16a34a; font-size: 14px; }
QLabel#UxStepDot_active { color: #2563eb; font-size: 14px; }
QLabel#UxStepDot_wait { color: #94a3b8; font-size: 14px; }
QLabel#UxStepTitle { color: #0f172a; font-size: 12px; font-weight: 950; }
QLabel#UxStepSubtitle { color: #64748b; font-size: 10px; font-weight: 700; }
QLabel#UxActionIcon {
    background: #eff6ff;
    color: #2563eb;
    border: 1px solid #bfdbfe;
    border-radius: 18px;
    min-width: 36px;
    max-width: 36px;
    min-height: 36px;
    max-height: 36px;
    font-size: 22px;
    font-weight: 950;
}
QLabel#UxActionText {
    color: #0f172a;
    font-size: 14px;
    font-weight: 850;
}
QLabel#UxChip_blue,
QLabel#UxChip_green,
QLabel#UxChip_amber,
QLabel#UxChip_gray,
QLabel#UxChip_peach {
    border-radius: 12px;
    padding: 6px 10px;
    font-size: 11px;
    font-weight: 900;
}
QLabel#UxChip_blue { background: #dbeafe; color: #1d4ed8; }
QLabel#UxChip_green { background: #dcfce7; color: #15803d; }
QLabel#UxChip_amber { background: #fef3c7; color: #a16207; }
QLabel#UxChip_gray { background: #e2e8f0; color: #475569; }
QLabel#UxChip_peach { background: #ffedd5; color: #ea580c; }
QPushButton#UxButtonCompact,
QPushButton#UxButtonCompactPrimary {
    background: #ffffff;
    color: #2563eb;
    border: 1px solid #bfdbfe;
    border-radius: 11px;
    padding: 7px 11px;
    text-align: left;
    font-size: 12px;
    font-weight: 900;
}
QPushButton#UxButtonCompact:hover { background: #eff6ff; border-color: #60a5fa; }
QPushButton#UxButtonCompactPrimary {
    background: #2563eb;
    color: #ffffff;
    border-color: #2563eb;
}
QPushButton#UxButtonCompactPrimary:hover { background: #1d4ed8; }
QFrame#UxAddRowCard {
    background: #ffffff;
    border: 1px dashed #93c5fd;
    border-radius: 16px;
}
QTableWidget#UxTable {
    font-size: 11px;
}
QTableWidget#UxTable::item {
    padding: 4px;
}
QHeaderView::section {
    padding: 7px 6px;
}

/* v1.21.81 UX preview: less text, compact icon rail, visible phone QR. */
QFrame#Rail {
    background: #0f172a;
    border: none;
}
QLabel#RailSection {
    color: #475569;
    font-size: 14px;
    padding: 2px 0;
}
QLabel#RailVersion {
    color: #94a3b8;
    font-size: 9px;
    padding: 0;
}
QPushButton#PrimaryRailButton,
QPushButton#SecondaryRailButton,
QPushButton#RailButton {
    text-align: center;
    padding: 0;
    font-size: 20px;
    font-weight: 950;
    min-width: 46px;
    max-width: 52px;
}
QPushButton#PrimaryRailButton {
    background: #2563eb;
    border-radius: 14px;
}
QPushButton#SecondaryRailButton,
QPushButton#RailButton {
    border-radius: 14px;
}
QPushButton#SecondaryRailButton:checked,
QPushButton#RailButton:checked {
    background: #1e293b;
    border: 1px solid #3b82f6;
    color: #ffffff;
}
QLabel#UxCompactTitle {
    color: #0f172a;
    font-size: 24px;
    font-weight: 950;
}
QFrame#UxHeaderCard {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QProgressBar#UxProgress {
    height: 8px;
}
QLabel#UxPhoneQr {
    background: #ffffff;
    border: 1px solid #dbeafe;
    border-radius: 14px;
    padding: 8px;
    min-width: 112px;
    min-height: 112px;
}
QLabel#UxTinyMono {
    color: #64748b;
    font-family: Consolas, 'Courier New';
    font-size: 11px;
    font-weight: 800;
}
QLabel#UxActionText {
    color: #0f172a;
    font-size: 18px;
    font-weight: 950;
}
QLabel#UxMetricValue { font-size: 18px; }
QLabel#UxMetricTitle { font-size: 10px; }


/* v1.22.0 release receipt hub: SAI-file-first receiving flow. */
QFrame#UxSaiFileCard {
    background: #ffffff;
    border: 1px solid #dbeafe;
    border-radius: 18px;
}
QLabel#UxSourceTitle {
    color: #0f172a;
    font-size: 20px;
    font-weight: 950;
}
QLabel#UxSourceSub {
    color: #475569;
    font-size: 12px;
    font-weight: 750;
}
QFrame#UxSourceTile,
QFrame#UxSourceTilePrimary {
    min-width: 190px;
    border-radius: 14px;
}
QFrame#UxSourceTile {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
}
QFrame#UxSourceTilePrimary {
    background: #eff6ff;
    border: 1px solid #93c5fd;
}
QLabel#UxSourceTileTitle {
    color: #0f172a;
    font-size: 13px;
    font-weight: 950;
}
QLabel#UxSourceTileSub {
    color: #64748b;
    font-size: 10px;
    font-weight: 750;
}
QPushButton#UxSourceAction,
QPushButton#UxSourceActionPrimary {
    min-width: 180px;
    min-height: 64px;
    border-radius: 18px;
    padding: 10px 14px;
    text-align: left;
    font-size: 12px;
    font-weight: 850;
}
QPushButton#UxSourceAction {
    background: #ffffff;
    color: #334155;
    border: 1px solid #e2e8f0;
}
QPushButton#UxSourceAction:hover {
    background: #f8fbff;
    color: #1d4ed8;
    border-color: #93c5fd;
}
QPushButton#UxSourceActionPrimary {
    background: #eff6ff;
    color: #1d4ed8;
    border: 1px solid #60a5fa;
}
QPushButton#UxSourceActionPrimary:hover {
    background: #dbeafe;
    border-color: #2563eb;
}
QPushButton#UxNewReceiptButton {
    background: #2563eb;
    color: #ffffff;
    border: 1px solid #2563eb;
    border-radius: 18px;
    padding: 18px 22px;
    text-align: left;
    font-size: 18px;
    font-weight: 950;
}
QPushButton#UxNewReceiptButton:hover {
    background: #1d4ed8;
    border-color: #1d4ed8;
}
QPushButton#UxNewReceiptButton:pressed {
    background: #1e40af;
}
QPushButton#UxNewReceiptButton:disabled {
    background: #cbd5e1;
    color: #f8fafc;
    border-color: #cbd5e1;
}
QLabel#UxRouteOr {
    color: #94a3b8;
    font-size: 11px;
    font-weight: 850;
}
QLabel#UxLaunchHint {
    color: #64748b;
    font-size: 11px;
    font-weight: 700;
}
QFrame#UxFlowStep_done,
QFrame#UxFlowStep_active,
QFrame#UxFlowStep_wait {
    border-radius: 13px;
    min-width: 136px;
}
QFrame#UxFlowStep_done { background: #f0fdf4; border: 1px solid #bbf7d0; }
QFrame#UxFlowStep_active { background: #eff6ff; border: 1px solid #93c5fd; }
QFrame#UxFlowStep_wait { background: #f8fafc; border: 1px solid #e2e8f0; }
QLabel#UxFlowTitle {
    color: #0f172a;
    font-size: 12px;
    font-weight: 950;
}
QLabel#UxFlowSub {
    color: #64748b;
    font-size: 10px;
    font-weight: 750;
}
QLabel#UxFlowArrow {
    color: #94a3b8;
    font-size: 18px;
    font-weight: 950;
    min-width: 18px;
}

/* Release receipt layout balance: calmer proportions, stronger hierarchy. */
QLabel#UxCompactTitle {
    font-size: 23px;
    font-weight: 950;
    padding-right: 2px;
}
QFrame#UxHeaderCard {
    border-radius: 17px;
    min-height: 66px;
    max-height: 82px;
}
QProgressBar#UxProgressInline {
    height: 8px;
    min-width: 180px;
    border: none;
    border-radius: 4px;
    background: #e2e8f0;
}
QProgressBar#UxProgressInline::chunk {
    border-radius: 4px;
    background: #2563eb;
}
QFrame#UxMetric_blue,
QFrame#UxMetric_green,
QFrame#UxMetric_amber,
QFrame#UxMetric_gray,
QFrame#UxMetric_red {
    min-width: 82px;
    max-width: 104px;
    border-radius: 13px;
}
QLabel#UxMetricTitle {
    font-size: 10px;
    font-weight: 850;
}
QLabel#UxMetricValue {
    font-size: 17px;
    font-weight: 950;
}
QFrame#UxNextActionCard {
    border-radius: 16px;
}
QLabel#UxActionIcon {
    min-width: 32px;
    max-width: 32px;
    min-height: 32px;
    max-height: 32px;
    border-radius: 16px;
    font-size: 18px;
}
QLabel#UxActionText {
    font-size: 17px;
    font-weight: 950;
}
QFrame#UxProductCard {
    border-radius: 16px;
}
QLabel#UxProductName {
    font-size: 22px;
    font-weight: 950;
    color: #0f172a;
    padding: 8px 10px;
    background: #f8fafc;
    border-radius: 12px;
}
QLabel#UxInputLookMuted {
    background: #ffffff;
    border: 2px solid #3b82f6;
    border-radius: 12px;
    padding: 10px 12px;
    min-height: 24px;
    color: #94a3b8;
    font-size: 15px;
    font-weight: 850;
}
QFrame#UxQtyBox {
    background: #ffffff;
    border: 1px solid #bfdbfe;
    border-radius: 12px;
}
QLabel#UxQtyPartBtn,
QLabel#UxQtyPartValue {
    color: #0f172a;
    font-size: 18px;
    font-weight: 950;
    border-right: 1px solid #dbeafe;
}
QLabel#UxQtyPartValue {
    color: #2563eb;
    font-size: 16px;
}
QFrame#UxSideCard {
    min-width: 154px;
    max-width: 184px;
    border-radius: 16px;
}
QLabel#UxPhoneQr {
    min-width: 90px;
    max-width: 96px;
    min-height: 90px;
    max-height: 96px;
    padding: 6px;
}
QPushButton#UxButtonCompact,
QPushButton#UxButtonCompactPrimary {
    min-height: 32px;
    border-radius: 10px;
    padding: 6px 10px;
    font-size: 11px;
}
QFrame#UxAddRowCard {
    border-radius: 14px;
}
QLabel#UxNextLine {
    color: #475569;
    font-size: 11px;
    font-weight: 800;
    padding: 2px 0;
}
QTableWidget#UxTable {
    font-size: 11px;
}
QTableWidget#UxTable::item {
    padding: 5px;
}
QHeaderView::section {
    padding: 7px 6px;
}
QLabel#UxLockHint {
    font-size: 12px;
    font-weight: 800;
}


/* Release receipt hub: collapsible SAI-file process explanation. */
QLabel#UxSourceTitleCompact {
    color: #0f172a;
    font-size: 16px;
    font-weight: 950;
}
QLabel#UxSourceSubCompact {
    color: #64748b;
    font-size: 12px;
    font-weight: 800;
}
QPushButton#UxStateButton,
QPushButton#UxStateButtonActive {
    min-height: 30px;
    border-radius: 10px;
    padding: 5px 10px;
    font-size: 11px;
    font-weight: 900;
}
QPushButton#UxStateButton {
    background: #ffffff;
    color: #475569;
    border: 1px solid #e2e8f0;
}
QPushButton#UxStateButton:hover {
    background: #eff6ff;
    border-color: #bfdbfe;
    color: #1d4ed8;
}
QPushButton#UxStateButtonActive {
    background: #2563eb;
    color: #ffffff;
    border: 1px solid #2563eb;
}
QFrame#UxStartActions {
    background: transparent;
    border: none;
}
QFrame#UxStartCard,
QFrame#UxFinalCard {
    background: #ffffff;
    border: 1px solid #dbeafe;
    border-radius: 18px;
}
QLabel#UxStartTitle {
    color: #0f172a;
    font-size: 24px;
    font-weight: 950;
}
QLabel#UxStartSub {
    color: #475569;
    font-size: 13px;
    font-weight: 750;
}

/* v1.22.6: stable SVG rail icons and real title/subtitle hierarchy. */
QPushButton#StableRailButton,
QPushButton#StableRailButtonPrimary {
    color: #cbd5e1;
    border: 1px solid transparent;
    border-radius: 13px;
    padding: 0;
    background: transparent;
}
QPushButton#StableRailButton:hover {
    background: #182337;
    border-color: #334155;
    color: #ffffff;
}
QPushButton#StableRailButton:checked {
    background: #1e293b;
    border-color: #3b82f6;
    color: #ffffff;
}
QPushButton#StableRailButtonPrimary {
    background: #2563eb;
    border-color: #2563eb;
    color: #ffffff;
}
QPushButton#StableRailButtonPrimary:hover {
    background: #1d4ed8;
    border-color: #1d4ed8;
}
QPushButton#StableRailButtonPrimary:checked {
    background: #1e40af;
    border-color: #60a5fa;
}
QLabel#StableRailIcon,
QLabel#StableRailLabel {
    background: transparent;
    border: none;
    padding: 0;
}
QLabel#UxActionTitle,
QLabel#UxActionTitlePrimary,
QLabel#UxActionTitlePrimaryLarge,
QLabel#UxActionSubtitle,
QLabel#UxActionSubtitlePrimary,
QLabel#UxActionSubtitlePrimaryLarge {
    background: transparent;
    border: none;
    padding: 0;
}
QLabel#UxActionTitle {
    color: #0f172a;
    font-size: 14px;
    font-weight: 950;
}
QLabel#UxActionSubtitle {
    color: #64748b;
    font-size: 10px;
    font-weight: 650;
}
QLabel#UxActionTitlePrimary {
    color: #1d4ed8;
    font-size: 14px;
    font-weight: 950;
}
QLabel#UxActionSubtitlePrimary {
    color: #64748b;
    font-size: 10px;
    font-weight: 650;
}
QLabel#UxActionTitlePrimaryLarge {
    color: #ffffff;
    font-size: 20px;
    font-weight: 950;
}
QLabel#UxActionSubtitlePrimaryLarge {
    color: #dbeafe;
    font-size: 11px;
    font-weight: 600;
}

QPushButton#NewReceiptHeroButton {
    background: transparent;
    border: none;
    padding: 0;
}
QLabel#NewReceiptHeroEyebrow {
    background: transparent;
    color: rgba(255,255,255,0.78);
    font-size: 10px;
    font-weight: 900;
    letter-spacing: 1px;
}
QLabel#NewReceiptHeroTitle {
    background: transparent;
    color: #ffffff;
    font-size: 27px;
    font-weight: 950;
}
QLabel#NewReceiptHeroSubtitle {
    background: transparent;
    color: #e0f2fe;
    font-size: 13px;
    font-weight: 700;
}
QDialog#ReceiptDraftsDialog {
    background: #f8fafc;
}
QTableWidget#ReceiptDraftsTable {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 16px;
}
QMenuBar {
    background: #f8fafc;
    color: #0f172a;
}
QMenuBar::item:selected { background: #e2e8f0; }
QMenu { background: white; border: 1px solid #e2e8f0; }
QMenu::item { padding: 7px 24px; }
QMenu::item:selected { background: #eff6ff; }
"""


STYLESHEET += r"""
/* v1.22.7be: calm integrated rail and premium hero composition. */
QFrame#Rail {
    background: #edf2f8;
    border: none;
    border-right: 1px solid #d7e0eb;
}
QLabel#RailVersion { color: #8a99ae; }
QPushButton#StableRailButton,
QPushButton#StableRailButtonPrimary {
    border: 1px solid transparent;
}
QPushButton#StableRailButton:hover {
    background: rgba(255,255,255,0.70);
    border-color: #d7e0eb;
}
QPushButton#StableRailButton:checked {
    background: #ffffff;
    border-color: #cbd7e5;
}
QPushButton#StableRailButtonPrimary {
    background: #2563eb;
    border-color: #3b82f6;
}
QFrame#CatalogStatusBadge {
    background: rgba(255,255,255,0.54);
    border-color: #d4deea;
}
QLabel#CatalogStatusTitle { color: #334155; }
QLabel#CatalogStatusDetail { color: #718096; }
"""

DARK_STYLESHEET = """
QWidget {
    background: #0f172a;
    color: #e5e7eb;
}
QWidget#SplashPage,
QWidget#StartupGate,
QFrame#StartupFastCanvas,
QFrame#StartupUpdateGate,
QStackedWidget#MainWindowStack,
QFrame#StartupPanel,
QFrame#StartupFirstRunCanvas,
QFrame#MainArea,
QStackedWidget#ContentStack,
QScrollArea,
QScrollArea QWidget#qt_scrollarea_viewport,
QScrollArea#WorkbenchScroll,
QWidget#WorkbenchBody,
QWidget#StatsPage,
QWidget#UxPage,
QScrollArea#UxScroll {
    background: #0f172a;
}
QScrollArea#UxScroll > QWidget > QWidget {
    background: #0f172a;
}
QLabel#SplashTitle,
QLabel#StartupTitle {
    color: #f8fafc;
}
QLabel#SplashVersion,
QLabel#StartupSubtitle,
QLabel#StartupStatus {
    color: #94a3b8;
}
QLabel#SplashDots {
    color: #60a5fa;
}
QFrame#StartupUpdatePanel {
    background: #111c30;
    border: 1px solid #293853;
}
QLabel#StartupUpdateBadge { color: #60a5fa; }
QLabel#StartupUpdateTitle { color: #f8fafc; }
QLabel#StartupUpdateSubtitle { color: #94a3b8; }
QLabel#StartupUpdateNotes {
    background: #17233a;
    color: #cbd5e1;
    border-color: #293853;
}
QProgressBar#StartupUpdateProgress { background: #24324b; }
QProgressBar#StartupUpdateProgress::chunk { background: #3b82f6; }
QPushButton#StartupUpdateSecondary { color: #94a3b8; }
QPushButton#StartupUpdateSecondary:hover { color: #60a5fa; }
QPushButton#StartupPrimary {
    background: #1d4ed8;
    color: #ffffff;
    border-color: #3b82f6;
}
QPushButton#StartupPrimary:disabled {
    background: #172554;
    color: #64748b;
    border-color: #1e3a8a;
}
QPushButton#StartupSecondary {
    background: #1e293b;
    color: #e5e7eb;
    border-color: #475569;
}
QPushButton#StartupSecondary:hover {
    background: #273449;
    color: #ffffff;
    border-color: #60a5fa;
}
QFrame#Rail {
    background: #020617;
}
QFrame#RailTopBlock,
QFrame#RailBottomBlock {
    background: transparent;
    border: none;
}
QDialog#ReceiptDraftsDialog {
    background: #0f172a;
}
QTableWidget#ReceiptDraftsTable {
    background: #111827;
    alternate-background-color: #172033;
    border-color: #334155;
}
QFrame#PageHeader {
    background: transparent;
    border: none;
}
QLabel#PageHeaderTitle,
QLabel#WorkbenchTitle,
QLabel#StatsTitle,
QLabel#HeroTitle,
QLabel#UxHeroTitle,
QLabel#UxStartTitle,
QLabel#UxProductName,
QLabel#UxHeroProgressText,
QLabel#SemiFileMetaValue,
QLabel#DialogTitle {
    color: #f8fafc;
}
QLabel#PageHeaderSubtitle,
QLabel#WorkbenchSubtitle,
QLabel#StatsSubtitle,
QLabel#HeroSubtitle,
QLabel#WorkbenchNote,
QLabel#CardTitle,
QLabel#CardHint,
QLabel#SuggestionMeta,
QLabel#UxMuted,
QLabel#UxFooterNote,
QLabel#UxStartSub,
QLabel#UxOverline,
QLabel#SemiFileMetaLabel,
QLabel#SemiFileNameValue,
QLabel#DialogSubtitle {
    color: #94a3b8;
}
QFrame#StartupFirstRunPanel,
QFrame#StartupForm,
QFrame#StatsHeader,
QFrame#Hero,
QFrame#MetricCard,
QFrame#WorkbenchCard,
QFrame#FreeReceiptCardShell,
QFrame#SemiPhonePanel,
QFrame#SuggestionPopup,
QFrame#UxCard,
QFrame#UxHeaderCard,
QFrame#UxSideCard,
QFrame#UxTableCard,
QFrame#UxProductCard,
QFrame#UxStartCard,
QFrame#UxFinalCard,
QFrame#UxSaiFileCard,
QFrame#UxNextActionCard,
QFrame#UxAddRowCard,
QFrame#UxActionBox,
QFrame#UxSourceTile,
QFrame#UxSourceTilePrimary {
    background: #111827;
    border-color: #334155;
}
QFrame#WorkbenchCard[dropTarget="true"] {
    background: #111827;
    border: 1px dashed #475569;
}
QFrame#WorkbenchCard[dropTarget="true"][dragActive="true"] {
    background: #172554;
    border: 2px solid #60a5fa;
}
QLabel#WorkbenchFieldLabel {
    background: transparent;
    color: #cbd5e1;
}
QFrame#InvoiceDropOverlay {
    background: rgba(15, 23, 42, 0.94);
    border: 3px solid #60a5fa;
}
QLabel#InvoiceDropTitle {
    background: transparent;
    color: #f8fafc;
}
QFrame#FreeReceiptInnerCard,
QWidget#FreePriceTools,
QWidget#BarcodeTools,
QWidget#BarcodeList,
QWidget#CategoryBox,
QWidget#QuickCategoryBox,
QWidget#SuggestionContent,
QScrollArea#SuggestionScroll {
    background: transparent;
}
QCheckBox#SettingsCheck {
    color: #e5e7eb;
}
QLabel#ThemeSettingLabel {
    color: #e8eef8;
}
QFrame#ThemeModeSelector {
    background: #111c2f;
    border-color: #2d3c55;
}
QPushButton#ThemeModeButton {
    background: transparent;
    border-color: transparent;
}
QPushButton#ThemeModeButton:hover {
    background: #1c2a41;
}
QPushButton#ThemeModeButton:focus {
    border-color: #4f79b5;
}
QPushButton#ThemeModeButton:checked {
    background: #2563eb;
    border-color: #3b82f6;
}
QPushButton#ThemeModeButton:checked:hover {
    background: #1d4ed8;
    border-color: #60a5fa;
}
QTimeEdit#ThemeTimeEdit {
    background: #0b1220;
    color: #f1f5f9;
    border-color: #475569;
    selection-background-color: #2563eb;
    selection-color: #ffffff;
}
QTimeEdit#ThemeTimeEdit:focus {
    border-color: #60a5fa;
}
QTimeEdit#ThemeTimeEdit:disabled {
    background: #111827;
    color: #5f6f86;
    border-color: #28364b;
}
QLabel#ThemeModeDescription {
    color: #94a3b8;
}
QProgressBar#SemiProgressBar {
    background: #1e293b;
    color: #e5e7eb;
    border-color: #475569;
}
QLabel#SemiStateIdle {
    background: #172033;
    color: #cbd5e1;
    border-color: #334155;
}
QFrame#SemiFileSummary,
QFrame#SemiPhonePanel {
    background: #111827;
    border-color: #334155;
}
QLabel#SemiPhoneQr {
    background: #e2e8f0;
    color: #475569;
    border: 1px solid #475569;
}
QLabel#SemiFileStatusOk {
    color: #86efac;
}
QLabel#SemiStateReady {
    background: #172554;
    color: #bfdbfe;
    border: 1px solid #3b82f6;
}
QLabel#SemiStateOk,
QLabel#SemiStateDone {
    background: #052e16;
    color: #bbf7d0;
    border: 1px solid #22c55e;
}
QLabel#SemiStateWarn {
    background: #3f2d0d;
    color: #fde68a;
    border: 1px solid #f59e0b;
}
QLabel#SemiStateError {
    background: #3f1d1d;
    color: #fecaca;
    border: 1px solid #ef4444;
}
QProgressBar#SemiProgressBar::chunk,
QProgressBar#UxProgressInline::chunk {
    background: #3b82f6;
}
QPushButton#WorkbenchPrimaryButton {
    background: #1d4ed8;
    color: #ffffff;
    border-color: #3b82f6;
}
QPushButton#WorkbenchPrimaryButton:hover {
    background: #1e40af;
    border-color: #60a5fa;
}
QPushButton#PageOrientationConfirmButton {
    background: #2563eb;
    color: #ffffff;
    border: 1px solid #60a5fa;
}
QPushButton#PageOrientationConfirmButton:hover {
    background: #1d4ed8;
    border-color: #93c5fd;
}
QPushButton#PageOrientationConfirmButton:pressed {
    background: #1e3a8a;
    border-color: #60a5fa;
}
QPushButton#PageOrientationConfirmButton:focus {
    border: 2px solid #bfdbfe;
}
QPushButton#PageOrientationConfirmButton:disabled {
    background: #172554;
    color: #64748b;
    border-color: #1e3a8a;
}
QPushButton#UxNewReceiptButton,
QPushButton#UxSourceActionPrimary,
QPushButton#StableRailButtonPrimary,
QPushButton#UxStateButtonActive {
    background: #1d4ed8;
    color: #ffffff;
    border-color: #3b82f6;
}
QPushButton#UxNewReceiptButton:hover,
QPushButton#UxSourceActionPrimary:hover,
QPushButton#StableRailButtonPrimary:hover,
QPushButton#UxStateButtonActive:hover {
    background: #1e40af;
    border-color: #60a5fa;
}
QPushButton#UxNewReceiptButton:pressed,
QPushButton#UxSourceActionPrimary:pressed,
QPushButton#StableRailButtonPrimary:pressed,
QPushButton#UxStateButtonActive:pressed {
    background: #1e3a8a;
    border-color: #60a5fa;
}
QPushButton#UxSourceAction,
QPushButton#UxNewReceiptButton:disabled,
QPushButton#UxSourceAction:disabled,
QPushButton#UxSourceActionPrimary:disabled {
    background: #1f2937;
    color: #cbd5e1;
    border-color: #334155;
}
QLineEdit,
QComboBox,
QTextEdit,
QLineEdit#WorkbenchInput,
QComboBox#WorkbenchCombo,
QLineEdit#StartupInput,
QLabel#WorkbenchFile,
QLabel#UxInputLook,
QLabel#UxInputLookMuted,
QFrame#CategoryInputShell {
    background: #0b1220;
    color: #e5e7eb;
    border-color: #475569;
}
QLineEdit:focus,
QComboBox:focus,
QTextEdit:focus,
QLineEdit#WorkbenchInput:focus,
QComboBox#WorkbenchCombo:focus {
    border-color: #60a5fa;
}
QComboBox QAbstractItemView {
    background: #111827;
    color: #e5e7eb;
    selection-background-color: #1d4ed8;
    selection-color: #ffffff;
}
QTableWidget,
QTableWidget#ReceiptTable,
QTableWidget#UxTable {
    background: #111827;
    alternate-background-color: #172033;
    color: #e5e7eb;
    border-color: #334155;
    gridline-color: transparent;
    selection-background-color: #1e3a8a;
    selection-color: #ffffff;
}
QTableWidget::item,
QTableWidget#UxTable::item {
    border-bottom-color: #253247;
}
QHeaderView::section {
    background: #172033;
    color: #cbd5e1;
    border-bottom-color: #334155;
}
QTableCornerButton::section {
    background: #172033;
    border-bottom-color: #334155;
}
QTabWidget::pane {
    background: #111827;
    border-color: #334155;
}
QTabBar::tab {
    background: #1e293b;
    color: #cbd5e1;
}
QTabBar::tab:selected {
    background: #111827;
    color: #ffffff;
    border-color: #334155;
    border-bottom-color: #111827;
}
QPushButton#SoftButton,
QPushButton#GhostButton,
QPushButton#HeroSecondaryButton,
QPushButton#StatsRefreshButton,
QPushButton#UxButton,
QPushButton#UxButtonCompact,
QPushButton#UxStateButton {
    background: #1e293b;
    color: #e5e7eb;
    border-color: #475569;
}
QPushButton#SoftButton:hover,
QPushButton#GhostButton:hover,
QPushButton#UxButton:hover,
QPushButton#UxButtonCompact:hover,
QPushButton#UxStateButton:hover {
    background: #273449;
    color: #ffffff;
    border-color: #60a5fa;
}
QPushButton:disabled {
    color: #64748b;
    background: #172033;
    border-color: #334155;
}
QLabel#InlineStatus,
QLabel#StatusPill,
QLabel#SemiFileSummary,
QLabel#SemiFileStatusIdle {
    background: #172033;
    color: #cbd5e1;
    border-color: #334155;
}
QWidget#HistoryDeleteCell,
QPushButton#HistoryDeleteButton {
    background: transparent;
    border: none;
}
QLabel#SuggestionTitle,
QLabel#WorkbenchSection,
QLabel#CardValue,
QLabel#UxCardTitle,
QLabel#UxSourceTitle,
QLabel#UxSourceTitleCompact,
QLabel#UxActionTitle,
QLabel#UxStepTitle,
QLabel#UxFlowTitle,
QLabel#UxMetricValue,
QLabel#UxCompactTitle,
QLabel#UxAddRowTitle,
QLabel#UxNextLine,
QLabel#UxFieldValue {
    color: #f1f5f9;
}
QLabel#UxActionSubtitle,
QLabel#UxActionSubtitlePrimary,
QLabel#UxSourceSub,
QLabel#UxSourceSubCompact,
QLabel#UxStepSubtitle,
QLabel#UxFlowSub,
QLabel#UxMetricTitle,
QLabel#UxFieldLabel,
QLabel#PriceForecastLabel {
    color: #94a3b8;
}
QLabel#UxActionTitlePrimary,
QLabel#UxActionTitlePrimaryLarge {
    color: #ffffff;
}
QLabel#UxActionSubtitlePrimary,
QLabel#UxActionSubtitlePrimaryLarge {
    color: #dbeafe;
}
QFrame#SuggestionRow:hover {
    background: #1e293b;
}
QProgressBar {
    background: #1e293b;
    color: #e5e7eb;
    border-color: #334155;
}
QMenuBar,
QMenu {
    background: #111827;
    color: #e5e7eb;
    border-color: #334155;
}
QMenuBar::item:selected,
QMenu::item:selected {
    background: #1e3a8a;
}
QToolTip {
    background: #020617;
    color: #f8fafc;
    border: 1px solid #475569;
}
QScrollBar:vertical {
    background: transparent;
    border: none;
    width: 7px;
    margin: 3px 1px;
}
QScrollBar:horizontal {
    background: transparent;
    border: none;
    height: 7px;
    margin: 1px 3px;
}
QScrollBar::groove:vertical,
QScrollBar::groove:horizontal {
    background: transparent;
    border: none;
}
QScrollBar::handle:vertical,
QScrollBar::handle:horizontal {
    background: #475569;
    border: none;
    border-radius: 3px;
    min-height: 42px;
    min-width: 42px;
}
QScrollBar::handle:vertical:hover,
QScrollBar::handle:horizontal:hover {
    background: #64748b;
}
QScrollBar::handle:vertical:pressed,
QScrollBar::handle:horizontal:pressed {
    background: #748399;
}
QScrollBar::add-page:vertical,
QScrollBar::sub-page:vertical,
QScrollBar::add-page:horizontal,
QScrollBar::sub-page:horizontal,
QScrollBar::add-line:vertical,
QScrollBar::sub-line:vertical,
QScrollBar::add-line:horizontal,
QScrollBar::sub-line:horizontal,
QScrollBar::up-arrow:vertical,
QScrollBar::down-arrow:vertical,
QScrollBar::left-arrow:horizontal,
QScrollBar::right-arrow:horizontal {
    background: transparent;
    border: none;
    width: 0;
    height: 0;
}

QWidget#FramelessWindowShell,
QFrame#FramelessTitleBar {
    background: #0f172a;
}
QLabel#FramelessTitleBrand {
    color: #7183a1;
}
QPushButton#WindowControlButton:hover {
    background: #1e293b;
}
QPushButton#WindowControlButton[kind="close"]:hover {
    background: #e5484d;
}

/* Unified notification system — night theme */
QFrame#NotificationToast {
    background: #18243a;
    border: 1px solid #455a78;
}
QLabel#NotificationTitle { color: #f8fafc; }
QLabel#NotificationMessage { color: #b8c4d8; }
QPushButton#NotificationClose, QPushButton#SAIMessageClose { color: #7183a1; }
QPushButton#NotificationClose:hover, QPushButton#SAIMessageClose:hover {
    background: #1d2a41;
    color: #dbeafe;
}
QFrame#CatalogStatusBadge {
    background: rgba(15,23,42,0.34);
    border-color: rgba(147,197,253,0.18);
}
QFrame#CatalogStatusBadge[compactBadge="true"] {
    background: transparent;
    border-color: transparent;
}
QLabel#CatalogStatusTitle { color: #e0ecff; }
QLabel#CatalogStatusDetail { color: #8ea3c4; }
QFrame#SAIMessagePanel {
    background: #111b2e;
    border: 1px solid #2a3b59;
}
QLabel#SAIMessageTitle { color: #f8fafc; }
QLabel#SAIMessageText { color: #e6edf8; }
QLabel#SAIMessageInfo { color: #9fb0ca; }
QPushButton#SAIMessageButton[kind="secondary"] {
    background: #17243a;
    color: #dbeafe;
    border-color: #344662;
}
QPushButton#SAIMessageButton[kind="secondary"]:hover {
    background: #20314d;
    border-color: #49607f;
}

/* v1.22.7be: the rail belongs to the shell instead of forming a blue slab. */
QFrame#Rail {
    background: #141d2b;
    border: none;
    border-right: 1px solid #293548;
}
QLabel#RailVersion { color: #718096; }
QPushButton#StableRailButton:hover {
    background: #1b2738;
    border-color: #33445c;
}
QPushButton#StableRailButton:checked {
    background: #202d40;
    border-color: #456184;
}
QFrame#CatalogStatusBadge {
    background: rgba(22,32,48,0.72);
    border-color: #324158;
}
QLabel#CatalogStatusTitle { color: #dbe7f7; }
QLabel#CatalogStatusDetail { color: #8fa2bc; }

"""
