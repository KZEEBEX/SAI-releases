#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Application-facing facade for the semi-automatic receipt workflow.

The Qt page keeps widget orchestration, dialogs, sound and printing. This facade
exposes one stable API for desktop and mobile clients while delegating all rules
to the Qt-independent SAI Core v2 module.
"""
from __future__ import annotations

from typing import Any, Iterable, Mapping, Sequence

from sai_core_v2.semi_auto_receipt import (
    BarcodeParseResult,
    existing_barcodes,
    find_barcode_owner,
    formatted_number,
    is_valid_ean,
    is_zero_quantity,
    label_copies,
    label_quantity_is_manual,
    merge_barcodes,
    missing_indices,
    next_internal_barcode,
    next_missing_index,
    number_float,
    parse_scan_barcodes,
    progress,
    receipt_quantity_int,
    row_barcodes,
    valid_standard_barcodes,
    with_label_quantity,
    with_quantity,
)


class SemiAutoReceiptService:
    """Stateless boundary used by the semi-auto desktop/mobile adapters."""

    def valid_barcodes(self, value: Any) -> list[str]:
        return list(valid_standard_barcodes(value))

    def parse_scan(self, value: Any, *, force: bool = False) -> BarcodeParseResult:
        return parse_scan_barcodes(value, force=force, checksum_validator=is_valid_ean)

    def row_barcodes(self, row: Mapping[str, Any]) -> list[str]:
        return list(row_barcodes(row))

    def quantity_value(self, row: Mapping[str, Any] | None) -> float:
        return number_float((row or {}).get("qty"))

    def is_zero_quantity(self, row: Mapping[str, Any] | None) -> bool:
        return is_zero_quantity(row)

    def missing_indices(self, rows: Sequence[Mapping[str, Any]]) -> list[int]:
        return list(missing_indices(rows))

    def find_owner(
        self,
        rows: Sequence[Mapping[str, Any]],
        barcode: Any,
        *,
        current_index: int = -1,
        exclude_current: bool = True,
    ) -> int | None:
        return find_barcode_owner(
            rows,
            barcode,
            current_index=current_index,
            exclude_current=exclude_current,
        )

    def next_missing(
        self,
        rows: Sequence[Mapping[str, Any]],
        *,
        start: int = -1,
        wrap: bool = False,
    ) -> int | None:
        return next_missing_index(rows, start=start, wrap=wrap)

    def merge_barcodes(
        self,
        row: Mapping[str, Any],
        codes: Iterable[Any],
        *,
        warnings: Iterable[Any] = (),
    ) -> dict[str, Any]:
        return merge_barcodes(row, codes, warnings=warnings)

    def formatted_number(self, value: Any) -> int | float:
        return formatted_number(value)

    def receipt_quantity_int(self, row: Mapping[str, Any] | None) -> int:
        return receipt_quantity_int(row)

    def label_quantity_is_manual(self, row: Mapping[str, Any] | None) -> bool:
        return label_quantity_is_manual(row)

    def label_copies(self, row: Mapping[str, Any] | None) -> int:
        return label_copies(row)

    def with_quantity(self, row: Mapping[str, Any], value: Any) -> dict[str, Any]:
        return with_quantity(row, value)

    def with_label_quantity(self, row: Mapping[str, Any], value: Any) -> dict[str, Any]:
        return with_label_quantity(row, value)

    def progress(self, rows: Sequence[Mapping[str, Any]]):
        return progress(rows)

    def existing_barcodes(self, rows: Sequence[Mapping[str, Any]]) -> set[str]:
        return existing_barcodes(rows)

    def next_internal_barcode(
        self,
        existing: Iterable[Any],
        *,
        prefix: Any = "77",
        start_counter: Any = 1,
    ) -> tuple[str, int] | None:
        return next_internal_barcode(existing, prefix=prefix, start_counter=start_counter)
