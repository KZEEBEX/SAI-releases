#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression tests for the Windows receipt-readiness launchers."""
from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
LAUNCHERS = {
    "ПРОВЕРИТЬ АВТОМАТИЧЕСКИЙ ПРИВОЗ.cmd": "automatic",
    "ПРОВЕРИТЬ ПОЛУАВТОМАТИЧЕСКИЙ ПРИВОЗ.cmd": "semi",
    "ПРОВЕРИТЬ ВСЕ ПРИВОЗЫ.cmd": "all",
}


def main() -> int:
    for filename, scenario in LAUNCHERS.items():
        raw = (ROOT / filename).read_bytes()
        assert raw, f"{filename}: empty launcher"
        assert all(byte < 128 for byte in raw), f"{filename}: must be ASCII"
        assert b"\r\n" in raw, f"{filename}: Windows CRLF is required"
        without_crlf = raw.replace(b"\r\n", b"")
        assert b"\n" not in without_crlf, f"{filename}: bare LF found"
        assert b"\r" not in without_crlf, f"{filename}: bare CR found"

        text = raw.decode("ascii")
        assert "app\\.venv\\Scripts\\python.exe" in text
        assert "app\\run_receipt_readiness.py" in text
        assert f" {scenario}\r\n" in text
        assert "pause\r\n" in text

    print("SAI receipt launcher tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
