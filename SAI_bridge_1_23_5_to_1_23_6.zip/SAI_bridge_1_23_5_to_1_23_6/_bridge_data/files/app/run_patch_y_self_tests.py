#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, sys, tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_y_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as m
assert m.CONTRACT_VERSION=='invoice_ai_contract_v4'
assert m.DEFAULT_MODEL=='gpt-5.6-sol' and m.AUDIT_MODEL=='gpt-5.6-terra'
assert m.build_invoice_schema()['title']=='SAI Invoice Extraction v4'
assert m.build_audit_schema()['title']=='SAI Invoice Audit v1'
sample=Path(tempfile.mkdtemp(prefix='sai_patch_y_src_'))/'sample.txt'
sample.write_text('test',encoding='utf-8')
payload=m.build_request_payload([sample],stage='extract')
assert payload['_sai_precision_views_used'] is False
doc={'supplier':'A','invoice_date':'2026-07-18','invoice_number':'1','currency':'RUB','document_total':20.0,'document_total_note':'','items':[{'source_row':1,'raw_name':'ТОВАР','name':'ТОВАР','quantity':2.0,'unit':'шт','purchase_price':10.0,'line_total':20.0,'article':'A1','barcodes':['4006381333931'],'confidence':0.9,'note':''}],'warnings':[]}
audit={'checked_rows':[1],'corrections':[{'source_row':1,'status':'corrected','raw_name':'ТОВАР 1','name':'ТОВАР 1','quantity':2.0,'unit':'шт','purchase_price':10.0,'line_total':20.0,'article':'A2','barcodes':['4006381333931'],'confidence':0.99,'note':''}],'warnings':[]}
merged,changed,uncertain=m.apply_audit(doc,audit)
assert merged['items'][0]['article']=='A2' and 1 in changed and not uncertain
problems,notes=m.detect_problem_rows(merged,[1],[1],[])
assert problems==[]
try:
 m._parse_response_document({'output':[{'type':'message','content':[{'type':'output_text','text':'{"items": []}'}]}]},'test')
except m.OpenAIInvoiceError:
 pass
else:
 raise AssertionError('empty result accepted')
print('PATCH_Y_SELF_TEST_OK')
