#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import importlib
import os
import sys
import tempfile
from pathlib import Path


root = Path(tempfile.mkdtemp(prefix="sai_staff_test_"))
os.environ["SAI_USER_DATA_DIR"] = str(root / "a")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sai_runtime_paths
import sai_db
import sai_staff
importlib.reload(sai_runtime_paths); importlib.reload(sai_db); importlib.reload(sai_staff)

seller = sai_staff.save_employee("Анна", "Продавец", "daily", 2000, device_id="pc-a")
hourly = sai_staff.save_employee("Михаил", "Специалист", "hourly", 500, device_id="pc-a")
today = "2026-08-15"
sai_staff.save_shift(seller, today, "09:00", "18:00", device_id="pc-a")
entry = sai_staff.start_timer(hourly, device_id="pc-a")
with sai_db.connect() as con:
    con.execute("UPDATE staff_time_entries SET started_at='2026-08-15T08:00:00+03:00',ended_at='2026-08-15T10:30:00+03:00' WHERE id=?", (entry,)); con.commit()
expense = sai_staff.add_expense(hourly, "Лампочка", 2, 150, device_id="pc-a")
with sai_db.connect() as con:
    con.execute(
        "UPDATE staff_expenses SET purchased_at='2026-08-15T12:00:00+03:00' WHERE id=?",
        (expense,),
    )
    con.commit()
lines = {row.name: row for row in sai_staff.payroll(today, today)}
assert lines["Анна"].salary == 2000
assert lines["Михаил"].hours == 2.5 and lines["Михаил"].salary == 1250
assert lines["Михаил"].expenses == 300 and lines["Михаил"].total == 1550

shared = root / "shared"
published, imported = sai_staff.sync_shared(shared, "pc-a")
assert published >= 5 and imported == 0

os.environ["SAI_USER_DATA_DIR"] = str(root / "b")
importlib.reload(sai_runtime_paths); importlib.reload(sai_db); importlib.reload(sai_staff)
published, imported = sai_staff.sync_shared(shared, "pc-b")
assert imported >= 5
assert {row["name"] for row in sai_staff.employees()} == {"Анна", "Михаил"}
assert {row.name: row.total for row in sai_staff.payroll(today, today)}["Михаил"] == 1550
print("SAI staff tests: OK")
