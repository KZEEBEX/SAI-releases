#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Online pre-sale verification of Data Matrix marking codes."""
from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any


CDN_DIRECTORY_URL = "https://cdn.crpt.ru/api/v4/true-api/cdn/info"
API_PREFIX = "/api/v4/true-api"


class MarkingCheckError(RuntimeError):
    pass


@dataclass(frozen=True)
class MarkingCheckResult:
    scanned_code: str
    code: dict[str, Any]
    request_id: str
    request_timestamp: int | None
    host: str
    elapsed_ms: int
    raw: dict[str, Any]


def normalize_scanned_code(value: str) -> str:
    text = str(value or "").strip("\r\n\t ")
    if text.startswith("]d2"):
        text = text[3:]
    text = text.replace("<GS>", "\x1d").replace("{GS}", "\x1d")
    # Keyboard-wedge scanners obey the active Windows keyboard layout. A Data
    # Matrix contains Latin serial/crypto characters, so under RU layout the
    # very same physical keys arrive as Cyrillic and Honest Sign cannot find
    # the code. Restore the physical US-QWERTY characters automatically.
    ru = "йцукенгшщзхъфывапролджэячсмитьбю"
    en = "qwertyuiop[]asdfghjkl;'zxcvbnm,."
    table = str.maketrans(ru + ru.upper(), en + en.upper())
    text = text.translate(table)
    # A number of 2D scanners drop the non-printable FNC1/GS key in keyboard
    # mode. Restore the two common Russian marking layouts only when their tail
    # is unambiguous. AI 91 carries a four-character verification key; AI 92 is
    # the following crypto block. AI 93 is a final four-character block.
    ai_91_92 = re.match(r"^(01\d{14}21.+?)(?:\x1d)?91(.{4})(?:\x1d)?92(.+)$", text)
    if ai_91_92:
        text = f"{ai_91_92.group(1)}\x1d91{ai_91_92.group(2)}\x1d92{ai_91_92.group(3)}"
    elif "\x1d" not in text and text.startswith("01") and re.search(r"93.{4}$", text):
        text = re.sub(r"93(.{4})$", "\x1d93\\1", text, count=1)
    return text


def validate_scanned_code(value: str) -> str:
    code = normalize_scanned_code(value)
    if not code:
        raise MarkingCheckError("Просканируйте Data Matrix товара.")
    if len(code) < 18:
        raise MarkingCheckError("Получен слишком короткий код. Нужен полный Data Matrix, а не обычный EAN-штрихкод.")
    return code


def _json_request(url: str, token: str, *, payload: dict[str, Any] | None = None, timeout: float = 5.0) -> dict[str, Any]:
    data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(url, data=data, method="POST" if data is not None else "GET", headers={
        "Accept": "application/json", "Content-Type": "application/json; charset=utf-8",
        "X-API-KEY": token, "User-Agent": "SAI-Marking-Check/1.0",
    })
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8-sig", errors="replace")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")[:500]
        if exc.code in (401, 403):
            raise MarkingCheckError("Токен ККТ не принят «Честным знаком». Проверьте или обновите его в SAI Admin.") from exc
        raise MarkingCheckError(f"«Честный знак» вернул HTTP {exc.code}: {body or exc.reason}") from exc
    except urllib.error.URLError as exc:
        raise MarkingCheckError(f"Нет связи с сервисом проверки маркировки: {getattr(exc, 'reason', exc)}") from exc
    except TimeoutError as exc:
        raise MarkingCheckError("Сервис проверки маркировки не ответил вовремя.") from exc
    try:
        result = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise MarkingCheckError("Сервис проверки маркировки вернул непонятный ответ.") from exc
    if not isinstance(result, dict):
        raise MarkingCheckError("Сервис проверки маркировки вернул ответ неизвестного формата.")
    if int(result.get("code") or 0) != 0:
        raise MarkingCheckError(str(result.get("description") or "Проверка отклонена сервисом маркировки."))
    return result


class MarkingVerificationService:
    def __init__(self, token: str, *, timeout: float = 5.0) -> None:
        self.token = str(token or "").strip(); self.timeout = max(2.0, float(timeout))
        self._host = ""; self._host_selected_at = 0.0

    def _require_token(self) -> None:
        if len(self.token) < 20:
            raise MarkingCheckError("Токен ККТ не задан. Добавьте его в SAI Admin.")

    def _discover_host(self) -> str:
        self._require_token(); now = time.monotonic()
        if self._host and now - self._host_selected_at < 600:
            return self._host
        info = _json_request(CDN_DIRECTORY_URL, self.token, timeout=self.timeout)
        hosts = [str(item.get("host") or "").rstrip("/") for item in (info.get("hosts") or [])
                 if isinstance(item, dict) and str(item.get("host") or "").startswith("https://")]
        if not hosts:
            raise MarkingCheckError("«Честный знак» не предоставил ни одной CDN-площадки.")
        ranked: list[tuple[int, str]] = []
        for host in hosts[:3]:
            started = time.perf_counter()
            try:
                health = _json_request(host + API_PREFIX + "/cdn/health/check", self.token, timeout=2.5)
                ranked.append((int(health.get("avgTimeMs") or ((time.perf_counter() - started) * 1000)), host))
            except Exception:
                continue
        self._host = min(ranked)[1] if ranked else hosts[0]; self._host_selected_at = now
        return self._host

    def check(self, scanned_code: str) -> MarkingCheckResult:
        code = validate_scanned_code(scanned_code); started = time.perf_counter(); host = self._discover_host()
        try:
            response = _json_request(host + API_PREFIX + "/codes/check", self.token, payload={"codes": [code]}, timeout=self.timeout)
        except MarkingCheckError:
            self._host = ""; host = self._discover_host()
            response = _json_request(host + API_PREFIX + "/codes/check", self.token, payload={"codes": [code]}, timeout=self.timeout)
        rows = response.get("codes") or []
        if not rows or not isinstance(rows[0], dict):
            raise MarkingCheckError("В ответе «Честного знака» нет результата по отсканированному коду.")
        return MarkingCheckResult(code, dict(rows[0]), str(response.get("reqId") or ""),
                                  int(response["reqTimestamp"]) if response.get("reqTimestamp") is not None else None,
                                  host, int((time.perf_counter() - started) * 1000), response)


FIELD_LABELS = {
    "cis": "Код маркировки", "printView": "Печатное представление", "gtin": "GTIN",
    "groupIds": "Товарные группы", "valid": "Структура кода корректна",
    "verified": "Криптографическая проверка", "found": "Код найден",
    "realizable": "Продажа разрешена", "utilised": "Введён в оборот",
    "isBlocked": "Заблокирован", "isOwner": "Принадлежит организации", "sold": "Ранее продан",
    "expireDate": "Срок годности", "productionDate": "Дата производства",
    "producerInn": "ИНН производителя", "packageType": "Тип упаковки",
    "isTracking": "Прослеживаемый товар", "grayZone": "Серая зона",
    "errorCode": "Код результата", "message": "Сообщение системы", "prVetDocument": "Ветеринарный документ",
}


def display_value(value: Any) -> str:
    if value is True: return "Да"
    if value is False: return "Нет"
    if value is None or value == "": return "—"
    if isinstance(value, (list, dict)): return json.dumps(value, ensure_ascii=False)
    return str(value)


def result_rows(result: MarkingCheckResult) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []; seen: set[str] = set()
    for key in list(FIELD_LABELS) + sorted(result.code):
        if key in seen or key not in result.code: continue
        seen.add(key); rows.append((FIELD_LABELS.get(key, key), display_value(result.code.get(key))))
    rows.extend([("Длина отсканированного кода", str(len(result.scanned_code))),
                 ("Идентификатор проверки", result.request_id or "—"),
                 ("Время ответа", f"{result.elapsed_ms} мс"), ("CDN-площадка", result.host)])
    return rows
