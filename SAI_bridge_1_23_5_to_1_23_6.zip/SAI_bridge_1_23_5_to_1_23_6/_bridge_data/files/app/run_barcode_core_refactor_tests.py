#!/usr/bin/env python
"""Regression tests for the Qt-independent barcode core."""
from __future__ import annotations

import ast
from pathlib import Path

from sai_core_v2.barcodes import (
    barcode_kind,
    barcode_modules_for_print,
    code128b_modules,
    code128c_modules,
    ean_checksum,
    ean13_modules,
    ean8_modules,
    is_valid_ean,
)


HERE = Path(__file__).resolve().parent


def main() -> None:
    ean13 = "460123456789" + str(ean_checksum("460123456789"))
    ean8 = "1234567" + str(ean_checksum("1234567"))
    assert is_valid_ean(ean13, 13)
    assert is_valid_ean(ean8, 8)
    assert not is_valid_ean(ean13[:-1] + str((int(ean13[-1]) + 1) % 10), 13)
    assert len(ean13_modules(ean13)) == 95
    assert len(ean8_modules(ean8)) == 67

    modules13, kind13 = barcode_modules_for_print(ean13)
    modules8, kind8 = barcode_modules_for_print(ean8)
    assert (modules13, kind13) == (ean13_modules(ean13), "EAN-13")
    assert (modules8, kind8) == (ean8_modules(ean8), "EAN-8")

    internal = "10000542"
    assert not is_valid_ean(internal, 8)
    internal_modules, internal_kind = barcode_modules_for_print(internal)
    assert internal_kind == "Code128-C"
    assert internal_modules == code128c_modules(internal)
    assert barcode_kind(internal).startswith("Code128-C")

    assert barcode_modules_for_print("ABC-123")[1] == "Code128-B"
    assert code128b_modules("ABC") == code128b_modules("ABC")
    assert set(code128c_modules("1234")) <= {"0", "1"}

    ui_path = HERE / "sai_pyside_preview.py"
    ui_text = ui_path.read_text(encoding="utf-8")
    ui_tree = ast.parse(ui_text)
    forbidden = {
        "ean_checksum", "is_valid_ean", "ean13_modules", "ean8_modules",
        "code128b_modules", "code128c_modules", "barcode_kind",
        "barcode_modules_for_print",
    }
    remaining = {node.name for node in ast.walk(ui_tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    assert not forbidden & remaining, f"barcode logic leaked into UI: {sorted(forbidden & remaining)}"
    assert "from sai_core_v2.barcodes import" in ui_text
    print("SAI barcode core refactor tests: OK")


if __name__ == "__main__":
    main()
