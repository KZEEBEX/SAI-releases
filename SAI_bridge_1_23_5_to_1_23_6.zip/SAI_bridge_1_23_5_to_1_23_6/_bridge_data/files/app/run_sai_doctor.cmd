@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo Python environment not found. Run install.cmd first.
    pause
    exit /b 1
)

echo Starting SAI Doctor...
".venv\Scripts\python.exe" sai_doctor.py --deep
set ERR=%ERRORLEVEL%
echo.
echo SAI Doctor finished with code %ERR%.
echo Reports are saved in ..\user_data\logs\sai_doctor_*.txt
pause
exit /b %ERR%
