#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Safe all-or-rollback SIGMA updates for the price-tag workbench."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

from sai_sigma_product_editor import (
    ProductCardChanges,
    ProductCardEditResult,
    SigmaProductEditError,
    editor_from_current_session,
)


@dataclass(frozen=True)
class PriceTagCatalogChange:
    product_id: str
    name: str
    price: Decimal
    vendor_code: str
    barcodes: tuple[str, ...]


@dataclass(frozen=True)
class PriceTagBatchResult:
    requested: int
    changed: int
    verified: int
    results: tuple[ProductCardEditResult, ...]


def _product_changes(change: PriceTagCatalogChange) -> ProductCardChanges:
    return ProductCardChanges(
        name=change.name.strip(),
        vendor_code=change.vendor_code.strip(),
        price=Decimal(change.price),
        barcodes=tuple(str(value).strip() for value in change.barcodes if str(value).strip()),
        unit_short_name="",
    )


def _rollback_changes(original: dict) -> ProductCardChanges:
    variation = (original.get("variations") or [{}])[0]
    return ProductCardChanges(
        name=str(original.get("name") or variation.get("catalogProductName") or "").strip(),
        vendor_code=str(original.get("vendorCode") or variation.get("catalogVendorCode") or "").strip(),
        price=Decimal(str((variation.get("price") or {}).get("value") or 0)),
        barcodes=tuple(str(value).strip() for value in variation.get("barcodes") or () if str(value).strip()),
        unit_short_name="",
    )


def _name_price_changes(
    change: PriceTagCatalogChange,
    original: dict,
) -> ProductCardChanges:
    """Change only name and price; preserve live SIGMA metadata byte-for-byte."""
    variation = (original.get("variations") or [{}])[0]
    live_barcodes = tuple(
        str(value).strip()
        for value in variation.get("barcodes") or ()
        if str(value).strip()
    )
    return ProductCardChanges(
        name=change.name.strip(),
        vendor_code=str(
            original.get("vendorCode")
            or variation.get("catalogVendorCode")
            or change.vendor_code
        ).strip(),
        price=Decimal(change.price),
        barcodes=live_barcodes or change.barcodes,
        unit_short_name="",
    )


def normalize_price_tag_changes(
    changes: Iterable[PriceTagCatalogChange],
) -> tuple[PriceTagCatalogChange, ...]:
    """Validate the complete list before SIGMA receives any writes."""
    result: list[PriceTagCatalogChange] = []
    by_product: dict[str, PriceTagCatalogChange] = {}
    for index, raw in enumerate(changes, start=1):
        product_id = str(raw.product_id).strip()
        name = str(raw.name).strip()
        price = Decimal(raw.price)
        barcodes = tuple(dict.fromkeys(str(value).strip() for value in raw.barcodes if str(value).strip()))
        if not product_id:
            raise SigmaProductEditError(f"Строка {index} не связана с карточкой SIGMA.")
        if not name:
            raise SigmaProductEditError(f"В строке {index} отсутствует название.")
        if price <= 0:
            raise SigmaProductEditError(f"В строке {index} цена должна быть больше нуля.")
        if not barcodes:
            raise SigmaProductEditError(f"В строке {index} отсутствует штрихкод карточки SIGMA.")
        change = PriceTagCatalogChange(
            product_id=product_id,
            name=name,
            price=price,
            vendor_code=str(raw.vendor_code).strip(),
            barcodes=barcodes,
        )
        previous = by_product.get(product_id)
        if previous is not None:
            if previous != change:
                raise SigmaProductEditError(
                    f"Товар «{name}» добавлен несколько раз с разными данными."
                )
            continue
        by_product[product_id] = change
        result.append(change)
    if not result:
        raise SigmaProductEditError("Список изменений пуст.")
    return tuple(result)


def apply_price_tag_batch(
    changes: Iterable[PriceTagCatalogChange],
    *,
    editor=None,
) -> PriceTagBatchResult:
    """Preflight every card, apply sequentially, and roll back on any failure."""
    prepared_changes = normalize_price_tag_changes(changes)
    active_editor = editor or editor_from_current_session()
    snapshots: list[tuple] = []

    # Full preflight first. A malformed or ambiguous card must stop the entire batch.
    for change in prepared_changes:
        if hasattr(active_editor, "prepare_edit") and hasattr(active_editor, "apply_prepared"):
            current = active_editor.prepare_edit(
                change.product_id,
                _product_changes(change),
            )
            desired = _name_price_changes(change, current.original)
            prepared = active_editor.prepare_edit(
                change.product_id,
                desired,
                current=current,
            )
            snapshots.append((
                change,
                desired,
                _rollback_changes(current.original),
                prepared,
            ))
        else:
            # Compatibility for external/test editors implementing the old API.
            original, _payload, _catalog_payload, _fields = active_editor.prepare(
                change.product_id,
                _product_changes(change),
            )
            desired = _name_price_changes(change, original)
            snapshots.append((
                change,
                desired,
                _rollback_changes(original),
                None,
            ))

    applied: list[tuple[PriceTagCatalogChange, ProductCardChanges]] = []
    results: list[ProductCardEditResult] = []
    try:
        for change, desired, rollback, prepared in snapshots:
            result = (
                active_editor.apply_prepared(prepared)
                if prepared is not None
                else active_editor.apply(change.product_id, desired)
            )
            results.append(result)
            if result.applied:
                applied.append((change, rollback))
    except Exception as exc:
        rollback_errors: list[str] = []
        for change, rollback in reversed(applied):
            try:
                active_editor.apply(change.product_id, rollback)
            except Exception as rollback_exc:
                rollback_errors.append(f"{change.name}: {rollback_exc}")
        detail = ""
        if rollback_errors:
            detail = "\nНе удалось подтвердить откат: " + "; ".join(rollback_errors)
        if applied:
            rollback_summary = (
                f"Ранее подтверждённых карточек: {len(applied)}; "
                "для них выполнен обратный откат."
            )
        else:
            rollback_summary = "Ранее подтверждённых карточек не было."
        raise SigmaProductEditError(
            f"Пакетное изменение остановлено: {exc}. "
            f"{rollback_summary}{detail}"
        ) from exc

    return PriceTagBatchResult(
        requested=len(prepared_changes),
        changed=sum(1 for result in results if result.applied),
        verified=sum(1 for result in results if result.verified or not result.changed_fields),
        results=tuple(results),
    )


__all__ = [
    "PriceTagBatchResult",
    "PriceTagCatalogChange",
    "apply_price_tag_batch",
    "normalize_price_tag_changes",
]
