#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Qt workflow boundary for verified SIGMA updates from the price-tag list."""
from __future__ import annotations

from decimal import Decimal
import json
import threading
from typing import Any

from PySide6.QtCore import QTimer

import sai_db
from sai_notifications import QMessageBox
from sai_sigma_price_tag_batch import PriceTagCatalogChange, apply_price_tag_batch


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _price(value: Any) -> float:
    try:
        return float(str(value).strip().replace(" ", "").replace(",", "."))
    except (TypeError, ValueError):
        return 0.0


class PriceTagSigmaBatchMixin:
    """Coordinates preflight, background writes, verification and local refresh."""

    def print_price_tags_now(self) -> None:
        if not self.items:
            QMessageBox.information(self, "Ценники", "Сначала добавь хотя бы один товар.")
            return
        if self._sigma_batch_job:
            return
        invalid = [
            index + 1 for index, item in enumerate(self.items)
            if not _text(item.get("name"))
            or not _text(item.get("barcode"))
            or _price(item.get("price")) <= 0
        ]
        if invalid:
            QMessageBox.information(
                self,
                "Ценники",
                "Нельзя продолжить: проверь название, ШК и цену в строках "
                + ", ".join(str(value) for value in invalid[:20]),
            )
            return
        unresolved = self.resolve_price_tag_catalog_links()
        if unresolved:
            QMessageBox.warning(
                self,
                "Ценники",
                "Не удалось однозначно связать с каталогом SIGMA строки: "
                + ", ".join(str(value) for value in unresolved[:20])
                + ".\n\nНайди эти товары через верхний поиск и добавь их в список заново.",
            )
            return
        print_mode = getattr(self, "price_tag_print_mode", lambda: "a4")()
        copies = int(getattr(self, "price_tags_print_copies", lambda: 1)())
        print_description = {
            "off": "После успешной проверки печать не запускается.",
            "thermal": f"После успешной проверки SAI отправит термоэтикетки: по {copies} шт. на товар.",
            "a4": f"После успешной проверки SAI отправит обычные ценники: по {copies} шт. на товар.",
        }.get(print_mode, "После успешной проверки печать не запускается.")
        summary = (
            f"SAI изменит и проверит в SIGMA карточек: {len(self.items)}.\n"
            "Будут записаны названия и продажные цены из таблицы.\n"
            f"{print_description}\n\n"
            "Продолжить?"
        )
        dialog_title = "Обновить SIGMA" if print_mode == "off" else "Обновить SIGMA и напечатать"
        if QMessageBox.question(self, dialog_title, summary) != QMessageBox.Yes:
            return
        changes = tuple(
            PriceTagCatalogChange(
                product_id=_text(item.get("sigma_product_id")),
                name=_text(item.get("name")),
                price=Decimal(str(_price(item.get("price")))),
                vendor_code=_text(item.get("vendor_code")),
                barcodes=tuple(
                    _text(value)
                    for value in (item.get("catalog_barcodes") or (item.get("barcode"),))
                    if _text(value)
                ),
            )
            for item in self.items
        )
        job: dict[str, Any] = {
            "done": False,
            "result": None,
            "error": None,
            "changes": changes,
        }
        self._sigma_batch_job = job
        self.print_all_btn.setEnabled(False)
        for button in getattr(self, "price_tags_print_mode_buttons", {}).values():
            button.setEnabled(False)
        if getattr(self, "price_tags_copy_wrap", None) is not None:
            self.price_tags_copy_wrap.setEnabled(False)
        self.print_all_btn.setText("Проверяю и обновляю SIGMA…")
        self.status_label.setText(f"Проверяю весь список перед записью: {len(changes)} карточек…")

        def work() -> None:
            try:
                job["result"] = apply_price_tag_batch(changes)
            except Exception as exc:
                job["error"] = str(exc)
            finally:
                job["done"] = True

        threading.Thread(target=work, name="sai-price-tag-sigma-batch", daemon=True).start()
        QTimer.singleShot(100, self._poll_price_tag_sigma_batch)

    def resolve_price_tag_catalog_links(self) -> list[int]:
        """Resolve old SAI-file rows by an exact barcode without guessing."""
        unresolved: list[int] = []
        for index, item in enumerate(self.items, start=1):
            if _text(item.get("sigma_product_id")):
                continue
            matches = self.catalog_service.find_exact_barcode(
                item.get("barcode"),
                non_blocking=False,
            )
            unique = {
                _text(row.get("id")): row for row in matches if _text(row.get("id"))
            }
            if len(unique) != 1:
                unresolved.append(index)
                continue
            product = next(iter(unique.values()))
            item["sigma_product_id"] = _text(product.get("id"))
            item["vendor_code"] = _text(product.get("vendor_code"))
            item["catalog_barcodes"] = [
                _text(value) for value in (product.get("barcodes") or ())
                if _text(value)
            ]
        return unresolved

    def _poll_price_tag_sigma_batch(self) -> None:
        job = self._sigma_batch_job
        if not job:
            return
        if not job["done"]:
            QTimer.singleShot(100, self._poll_price_tag_sigma_batch)
            return
        self._sigma_batch_job = None
        for button in getattr(self, "price_tags_print_mode_buttons", {}).values():
            button.setEnabled(True)
        if getattr(self, "price_tags_copy_wrap", None) is not None:
            self.price_tags_copy_wrap.setEnabled(True)
        mode = getattr(self, "price_tag_print_mode", lambda: "a4")()
        self.print_all_btn.setText("Обновить SIGMA" if mode == "off" else "Обновить SIGMA и напечатать")
        self.print_all_btn.setEnabled(bool(self.items))
        if job["error"]:
            self.status_label.setText("Изменения SIGMA не применены. Печать не запускалась.")
            QMessageBox.critical(
                self,
                "Ценники",
                "Не удалось безопасно обновить весь список.\n\n"
                + job["error"]
                + "\n\nПечать не запускалась.",
            )
            return
        result = job["result"]
        requested = int(getattr(result, "requested", 0) or 0)
        verified = int(getattr(result, "verified", 0) or 0)
        if requested <= 0 or verified != requested:
            self.status_label.setText("SIGMA не подтвердила весь список. Печать не запускалась.")
            QMessageBox.critical(
                self,
                "Ценники",
                "Печать остановлена: SIGMA подтвердила изменения не для всех товаров.\n\n"
                f"Подтверждено: {verified} из {requested}.\n"
                "Ценники не отправлялись на принтер.",
            )
            return
        self._store_verified_price_tag_changes(job["changes"])
        mode = getattr(self, "price_tag_print_mode", lambda: "a4")()
        target = {"off": "Печать отключена.", "thermal": "Отправляю термоэтикетки…", "a4": "Отправляю обычные ценники…"}.get(mode, "Печать отключена.")
        self.status_label.setText(f"SIGMA подтвердила: {verified} из {requested}. {target}")
        self._print_verified_price_tags()

    def _store_verified_price_tag_changes(
        self,
        changes: tuple[PriceTagCatalogChange, ...],
    ) -> None:
        """Keep local search results consistent with the verified SIGMA cards."""
        try:
            with sai_db.connect() as con:
                for change in changes:
                    row = con.execute(
                        "SELECT raw_json FROM products WHERE sigma_id=? LIMIT 1",
                        (change.product_id,),
                    ).fetchone()
                    raw = json.loads(row[0] or "{}") if row else {}
                    if not isinstance(raw, dict):
                        raw = {}
                    raw["name"] = change.name
                    raw["sellingPrice"] = float(change.price)
                    con.execute(
                        """UPDATE products SET name=?, raw_json=?, updated_at=datetime('now')
                           WHERE sigma_id=?""",
                        (
                            change.name,
                            json.dumps(raw, ensure_ascii=False),
                            change.product_id,
                        ),
                    )
                con.commit()
            self.catalog_service.warm_catalog_cache(background=True, force=True)
        except Exception:
            pass


__all__ = ["PriceTagSigmaBatchMixin"]
