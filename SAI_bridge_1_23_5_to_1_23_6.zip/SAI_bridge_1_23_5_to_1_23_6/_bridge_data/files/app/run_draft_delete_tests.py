#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression tests for permanent receipt-draft deletion."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

if not os.environ.get("SAI_USER_DATA_DIR"):
    _TEMP = tempfile.TemporaryDirectory(prefix="sai_draft_delete_")
    os.environ["SAI_USER_DATA_DIR"] = str(Path(_TEMP.name) / "user_data")

import sai_converter
import sai_receipt_drafts as drafts


def manual_payload() -> dict:
    return {
        "supplier_name": "ООО ТЕСТ",
        "date": "21.07.2026",
        "rows": [{"name": "ТРУБА 110 ММ", "qty": 2, "buy": 100}],
        "current_card": {},
    }


def ai_result() -> sai_converter.ConvertResult:
    return sai_converter.ConvertResult(
        source_path="invoice.pdf",
        source_type="AI",
        supplier="ООО ТЕСТ",
        date="2026-07-21",
        items=[sai_converter.ConvertItem(
            row=1,
            name="ТРУБА 110 ММ",
            quantity=2,
            purchase_price=100,
            sale_price=160,
            article="A-1",
            barcodes=["4600000000000"],
        )],
    )


def main() -> None:
    drafts.ensure_dir()

    drafts.restore("manual_current")
    created = drafts.register_manual_autosave(manual_payload())
    assert created.get("id") == "manual_current"
    assert len(drafts.list_active()) == 1

    drafts.remove("manual_current")
    assert drafts.is_deleted("manual_current")
    assert not drafts.MANUAL_AUTOSAVE.exists()
    assert drafts.list_active() == []

    # A delayed timer from a hidden page must not resurrect the deleted draft.
    stale = drafts.register_manual_autosave(manual_payload())
    assert stale.get("deleted") is True
    assert drafts.list_active() == []
    assert not drafts.MANUAL_AUTOSAVE.exists()

    # An explicit new-manual-receipt action may reuse the stable id.
    drafts.restore("manual_current")
    recreated = drafts.register_manual_autosave(manual_payload())
    assert recreated.get("id") == "manual_current"
    assert len(drafts.list_active()) == 1
    drafts.remove("manual_current")

    meta = drafts.save_result(ai_result(), (), stage="ai_review")
    draft_id = str(meta["id"])
    assert Path(meta["package_path"]).is_file()
    drafts.remove(draft_id)
    assert drafts.is_deleted(draft_id)
    stale_ai = drafts.save_result(ai_result(), (), draft_id=draft_id, stage="ai_review")
    assert stale_ai.get("deleted") is True
    assert all(str(row.get("id")) != draft_id for row in drafts.list_active())

    print("Draft deletion tests passed.")


if __name__ == "__main__":
    main()
