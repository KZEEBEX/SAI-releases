"""Plain-text thermal label rendering with automatic centred type fitting."""
from __future__ import annotations

from typing import Any, Mapping

from PySide6.QtCore import QRect, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QImage, QPainter

from sai_thermal_printing import (
    THERMAL_LABEL_PROFILES,
    _ensure_thermal_fonts_loaded,
    mm_to_dots,
    normalize_thermal_config,
)


def normalize_thermal_text(value: Any) -> str:
    """Keep intentional line breaks while removing accidental edge whitespace."""
    lines = [
        " ".join(str(line).replace("\t", " ").split())
        for line in str(value or "").replace("\r", "").split("\n")
    ]
    while lines and not lines[0]:
        lines.pop(0)
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


def fit_thermal_text_font(painter: QPainter, text: str, rect: QRect) -> QFont:
    """Return the largest bold font whose wrapped text fits the label body."""
    del painter
    flags = int(Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap)
    low = 3
    high = max(low, min(rect.height(), round(rect.width() * 0.72)))
    best = low
    while low <= high:
        size = (low + high) // 2
        font = QFont("Arial", -1)
        font.setPixelSize(size)
        font.setBold(True)
        bounds = QFontMetrics(font).boundingRect(rect, flags, text)
        if bounds.width() <= rect.width() and bounds.height() <= rect.height():
            best = size
            low = size + 1
        else:
            high = size - 1
    result = QFont("Arial", -1)
    result.setPixelSize(best)
    result.setBold(True)
    return result


def render_thermal_text_label(
    text: Any,
    size_key: str = "58x40",
    config: Mapping[str, Any] | None = None,
) -> QImage:
    """Render plain text at the maximum readable size, centred on the label."""
    _ensure_thermal_fonts_loaded()
    cfg = normalize_thermal_config(config)
    size = size_key if size_key in THERMAL_LABEL_PROFILES else cfg["size"]
    profile = THERMAL_LABEL_PROFILES.get(size) or THERMAL_LABEL_PROFILES["58x40"]
    width = mm_to_dots(profile["w_mm"])
    height = mm_to_dots(profile["h_mm"])
    image = QImage(width, height, QImage.Format.Format_RGB32)
    image.fill(QColor("#ffffff"))
    value = normalize_thermal_text(text)
    if not value:
        return image

    margin = mm_to_dots(1.15 if size == "58x40" else 0.8)
    offset_x = mm_to_dots(cfg["offset_x_tenth_mm"] / 10)
    offset_y = mm_to_dots(cfg["offset_y_tenth_mm"] / 10)
    rect = QRect(
        margin + offset_x,
        margin + offset_y,
        max(1, width - margin * 2),
        max(1, height - margin * 2),
    )
    painter = QPainter(image)
    try:
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        painter.setPen(QColor("#000000"))
        painter.setFont(fit_thermal_text_font(painter, value, rect))
        flags = int(Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap)
        painter.drawText(rect, flags, value)
    finally:
        painter.end()
    return image


__all__ = ["fit_thermal_text_font", "normalize_thermal_text", "render_thermal_text_label"]
