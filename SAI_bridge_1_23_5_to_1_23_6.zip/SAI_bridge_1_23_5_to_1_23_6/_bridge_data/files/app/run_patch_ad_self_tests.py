#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import inspect
import json
import os
import sys
import tempfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_patch_ad_")
sys.path.insert(0, str(root / "app"))

import sai_openai_invoice as ai
import sai_page_orientation as orientation

assert ai.CONTRACT_VERSION == "invoice_ai_contract_v9"
assert ai.AI_CACHE_DIR.name == "openai_invoice_v9"
assert orientation.normalize_angle(270) == -90
assert orientation.normalize_angle(-90) == -90
assert orientation.normalize_angle(450) == 90
assert orientation.angle_label(0) == "без поворота"
assert orientation.angle_label(-90).startswith("90° против")

sample_paths = [root / "one.pdf", root / "two.jpg"]
plan_a = {str(sample_paths[0].resolve()): [0, -90], str(sample_paths[1].resolve()): [180]}
plan_b = {str(sample_paths[0].resolve()): [0, 90], str(sample_paths[1].resolve()): [180]}
assert orientation.normalize_plan(sample_paths, plan_a)[str(sample_paths[0].resolve())] == [0, -90]
assert orientation.angle_for_page(sample_paths[0], 1, plan_a) == -90
assert orientation.angle_for_page(sample_paths[0], 9, plan_a) == 0
assert orientation.plan_fingerprint(sample_paths, plan_a) != orientation.plan_fingerprint(sample_paths, plan_b)

source = (root / "app" / "sai_openai_invoice.py").read_text(encoding="utf-8")
ui_source = (root / "app" / "sai_pyside_preview.py").read_text(encoding="utf-8")
assert "operator-confirmed" in inspect.getsource(ai._render_prepared_visual_views)
assert "orientation_plan" in inspect.signature(ai.analyze_invoice).parameters
assert "orientation_plan" in inspect.signature(ai.build_request_payload).parameters
assert "QTransform().rotate(-90) if image.height()>=image.width()" not in source
assert "prepared_visuals=stage in {'extract','audit'}" in source
assert "PageOrientationDialog" in ui_source
assert "Проверить страницы" in ui_source
assert "Ориентация страниц не подтверждена. Платный запрос не запущен." in ui_source
assert "orientation_plan" in ui_source

invoice_schema = ai.build_invoice_schema()
audit_schema = ai.build_audit_schema()
assert invoice_schema["type"] == "object"
assert audit_schema["type"] == "object"
assert "uniqueItems" not in json.dumps(audit_schema)

wiki_manifest = json.loads((root / "SAI_Ecosystem_Wiki_v0.1" / "wiki_manifest.json").read_text(encoding="utf-8-sig"))
assert wiki_manifest["wiki_version"] == "1.5"
assert wiki_manifest["snapshot_sai_version"] == "1.22.7ad"
assert (root / "SAI_Ecosystem_Wiki_v0.1" / "decisions" / "ADR-019-OPERATOR-CONFIRMED-PAGE-ORIENTATION.md").is_file()
print("PATCH_AD_SELF_TEST_OK")
