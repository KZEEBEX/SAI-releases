@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto not_installed
".venv\Scripts\python.exe" sai_launcher.py --console
set "SAI_RC=%ERRORLEVEL%"
if "%SAI_RC%"=="0" exit /b 0
echo.
echo SAI stopped with an error. See user_data\logs.
pause
exit /b %SAI_RC%
:not_installed
echo SAI is not installed. Run app\install.cmd.
pause
exit /b 1
