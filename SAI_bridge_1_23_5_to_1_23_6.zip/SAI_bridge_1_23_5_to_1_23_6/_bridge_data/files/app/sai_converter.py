#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""SAI Converter v0.1.

Read supplier documents and produce a clean SAI Package (.sai).

This first version is intentionally conservative: it is local/offline, read-only
for source files, and does not talk to SIGMA. It focuses on Excel/CSV and simple
UPD XML/ZIP documents; AI/PDF/photo recognition is implemented in a separate
module. New outputs use the versioned SAI Package format; XML remains import-only
compatibility.
"""
from __future__ import annotations

import csv
import datetime as dt
import math
import re
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import xml.etree.ElementTree as ET

from sai_core_v2.pricing import sale_price_from_purchase

try:
    from openpyxl import load_workbook
except Exception:  # pragma: no cover
    load_workbook = None

try:
    from _vendor import xlrd
except Exception:  # pragma: no cover
    xlrd = None


BARCODE_RE = re.compile(r"(?<!\d)(\d{6,14})(?!\d)")
MAX_DIADOC_ZIP_MEMBERS = 500
MAX_DIADOC_ZIP_UNCOMPRESSED_BYTES = 100 * 1024 * 1024
MAX_DIADOC_XML_BYTES = 10 * 1024 * 1024


@dataclass
class ConvertIssue:
    level: str
    message: str


@dataclass
class ConvertItem:
    row: int
    raw_name: str = ""
    name: str = ""
    quantity: float = 0.0
    unit: str = "штука"
    purchase_price: float = 0.0
    sale_price: float = 0.0
    article: str = ""
    category: str = ""
    barcodes: List[str] = field(default_factory=list)
    comment: str = ""
    issues: List[str] = field(default_factory=list)
    line_total: float = 0.0
    purchase_price_source: str = ""
    confidence: float = 0.0
    name_manually_edited: bool = False
    name_normalization_changes: List[str] = field(default_factory=list)
    name_search_aliases: List[str] = field(default_factory=list)
    name_normalizer_version: int = 0
    price_operator_approved: bool = False
    price_approval_source: str = ""
    catalog_price_snapshot: float = 0.0
    price_approval_barcode: str = ""


@dataclass
class ConvertResult:
    source_path: str
    source_type: str
    supplier: str = ""
    date: str = ""
    invoice_number: str = ""
    markup_percent: float = 60.0
    items: List[ConvertItem] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    validation: Dict[str, Any] = field(default_factory=dict)
    critical_issues: List[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return bool(self.items) and not self.errors


def safe_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def norm_text(value: Any) -> str:
    text = safe_str(value).lower().replace("ё", "е")
    text = re.sub(r"[^0-9a-zа-я]+", "", text)
    return text


def parse_float(value: Any, default: float = 0.0) -> float:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            if math.isnan(float(value)):
                return default
        except Exception:
            pass
        return float(value)
    text = safe_str(value)
    if not text:
        return default
    text = text.replace("\xa0", " ")
    text = re.sub(r"[^0-9,\.\-]+", "", text)
    if not text or text in {"-", ".", ","}:
        return default
    if "," in text and "." in text:
        # Treat the last separator as decimal separator.
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    else:
        text = text.replace(",", ".")
    try:
        return float(text)
    except Exception:
        return default


def parse_date(value: Any, reference_date: Optional[dt.date] = None) -> str:
    text = safe_str(value)
    if not text:
        return ""
    # Excel date can arrive as datetime/date from openpyxl.
    if isinstance(value, dt.datetime):
        return value.date().isoformat()
    if isinstance(value, dt.date):
        return value.isoformat()
    # ISO must be checked before day-first formats. Otherwise 2026-07-18 can
    # be incorrectly matched as 26-07-18 and turned into 2018-07-26.
    m = re.search(r"(?<!\d)(20\d{2})[\.\-/](\d{1,2})[\.\-/](\d{1,2})(?!\d)", text)
    if m:
        y, mo, d = m.groups()
        try:
            parsed = dt.date(int(y), int(mo), int(d))
            reference = reference_date or dt.date.today()
            # Some OCR responses transpose compact DDMMYY into ISO as YY-MM-DD:
            # 130826 becomes 2013-08-26 instead of 2026-08-13. Repair only the
            # unmistakable business-document case where the ISO day is the
            # current/adjacent year suffix and the old year suffix is a valid day.
            corrected_year = 2000 + parsed.day
            corrected_day = parsed.year % 100
            if (
                parsed.year <= reference.year - 5
                and 1 <= corrected_day <= 31
                and abs(corrected_year - reference.year) <= 1
            ):
                return dt.date(corrected_year, parsed.month, corrected_day).isoformat()
            return parsed.isoformat()
        except Exception:
            return ""
    m = re.search(r"(?<!\d)(\d{1,2})[\.\-/](\d{1,2})[\.\-/](\d{2,4})(?!\d)", text)
    if m:
        d, mo, y = m.groups()
        y = ("20" + y) if len(y) == 2 else y
        try:
            return dt.date(int(y), int(mo), int(d)).isoformat()
        except Exception:
            return ""
    # Supplier documents often print compact dates as DDMMYY.  Never interpret
    # this six-digit form as YYMMDD: 120826 means 12.08.2026, not 26.08.2012.
    m = re.search(r"(?<!\d)(\d{2})(\d{2})(\d{2})(?!\d)", text)
    if m:
        d, mo, y = m.groups()
        try:
            return dt.date(2000 + int(y), int(mo), int(d)).isoformat()
        except Exception:
            return ""
    return ""


def normalize_unit(value: Any) -> str:
    text = safe_str(value).lower().replace(".", " ").replace(",", " ").strip()
    compact = re.sub(r"[^0-9a-zа-я]+", "", text)
    if compact in {"м", "m", "метр", "метра", "метров", "погм", "пм", "мп", "мпог", "погонныйметр"}:
        return "м"
    if "метр" in compact and compact not in {"миллиметр", "сантиметр"}:
        return "м"
    return "штука"


def split_barcodes(*values: Any) -> List[str]:
    out: List[str] = []
    seen = set()
    for value in values:
        text = safe_str(value)
        if not text:
            continue
        for match in BARCODE_RE.findall(text):
            if match not in seen:
                seen.add(match)
                out.append(match)
    return out


def clean_name(value: Any) -> str:
    text = safe_str(value)
    text = text.replace("\xa0", " ")
    text = re.sub(r"[\r\n\t]+", " ", text)
    # Supplier package marks: (16/100), (12х24), [1/20] etc.
    text = re.sub(r"\s*[\(\[]\s*\d+\s*(?:[/xх\*]\s*\d+){1,3}\s*[\)\]]", " ", text, flags=re.I)
    text = re.sub(r"\s+", " ", text).strip(" -–—;,")
    return text.upper()


def calc_sale_price(buy: float, markup_percent: float) -> float:
    return sale_price_from_purchase(buy, markup_percent)


def supplier_from_filename(path: Path) -> str:
    stem = path.stem
    stem = re.sub(r"^(SAI|УПД|UPD|СЧЕТ|СЧЁТ|НАКЛАДНАЯ|ТОРГ)[_\-\s]+", "", stem, flags=re.I)
    stem = re.sub(r"[_\-]+", " ", stem)
    stem = re.sub(r"\d{2,4}[\.\-_]?\d{2}[\.\-_]?\d{2,4}", "", stem)
    return re.sub(r"\s+", " ", stem).strip().upper()


def filename_component(text: str, fallback: str = "ПОСТАВЩИК") -> str:
    text = safe_str(text).upper() or fallback
    text = re.sub(r"[^0-9A-ZА-ЯЁ]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text[:64] or fallback


def norm_header_row(values: Sequence[Any]) -> List[str]:
    return [norm_text(v) for v in values]


HEADER_SYNONYMS: Dict[str, Tuple[str, ...]] = {
    "barcode": ("шк", "штрихкод", "штрихкодтовара", "штрихкоддлясканирования", "ean", "barcode", "баркод"),
    "name": ("наименование", "наименованиетовара", "товар", "название", "номенклатура", "описание", "description"),
    "qty": ("колво", "количество", "количествотовара", "кол", "qty", "quantity"),
    "unit": ("ед", "едизм", "единица", "единицаизмерения", "okei", "unit"),
    "buy": ("цена", "ценатовара", "ценасндс", "ценабезндс", "закуп", "закупочнаяцена", "цена закупки", "price"),
    "sale": ("продажнаяцена", "ценапродажи", "розничнаяцена", "розница"),
    "total": ("сумма", "суммасндс", "стоимость", "итого", "сттовучнал", "amount"),
    "article": ("артикул", "код", "кодтовара", "кодпоставщика", "sku", "article"),
    "category": ("категория", "группа", "раздел", "category"),
}


def header_matches(norm_header: str, field: str) -> bool:
    if not norm_header:
        return False
    for synonym in HEADER_SYNONYMS.get(field, ()): 
        s = norm_text(synonym)
        if norm_header == s or (len(s) >= 5 and s in norm_header):
            if field == "buy" and any(bad in norm_header for bad in ("сумма", "стоимость", "итого")):
                return False
            if field == "article" and "штрих" in norm_header:
                return False
            return True
    return False


def _header_candidate_score(norm_header: str, field: str) -> int:
    """Rank duplicate columns so final payable values beat list-price values."""
    if not header_matches(norm_header, field):
        return -1
    score = 10
    if field == "buy":
        if "скидк" in norm_header and "безскидк" not in norm_header:
            score += 20
        elif "безскидк" in norm_header:
            score -= 10
    elif field == "total":
        if norm_header in {"сумма", "итого", "amount"}:
            score += 20
        if "скидк" in norm_header and "безскидк" not in norm_header:
            score += 15
        elif "безскидк" in norm_header:
            score -= 10
    return score


def columns_from_header_row(row: Sequence[Any]) -> Tuple[Dict[str, int], int]:
    """Return the best field mapping for one (possibly merged) header row."""
    normalized = norm_header_row(row)
    cols: Dict[str, int] = {}
    scores: Dict[str, int] = {}
    for c_idx, header in enumerate(normalized):
        for field in HEADER_SYNONYMS:
            candidate = _header_candidate_score(header, field)
            if candidate < 0:
                continue
            previous = scores.get(field, -1)
            # Price/amount tables commonly contain both list and discounted
            # columns. Prefer the rightmost column when their labels are equal.
            if candidate > previous or (candidate == previous and field in {"buy", "total"}):
                cols[field] = c_idx
                scores[field] = candidate
    score = sum(2 if field in {"name", "qty", "buy"} else 1 for field in cols)
    return cols, score


def detect_columns(table: List[List[Any]], max_scan_rows: int = 20) -> Tuple[int, Dict[str, int], List[str]]:
    best_row = 0
    best_score = -1
    best_cols: Dict[str, int] = {}
    warnings: List[str] = []

    for r_idx, row in enumerate(table[:max_scan_rows]):
        cols, score = columns_from_header_row(row)
        if score > best_score:
            best_score = score
            best_row = r_idx
            best_cols = cols

    if best_score < 4 or "name" not in best_cols:
        warnings.append("Не удалось уверенно определить строку заголовков; применяю грубую эвристику.")
        best_row = 0
        best_cols = infer_columns_without_headers(table)
    return best_row, best_cols, warnings


def infer_columns_without_headers(table: List[List[Any]]) -> Dict[str, int]:
    # Very cautious fallback for simple supplier sheets without headers.
    cols: Dict[str, int] = {}
    sample = table[:30]
    max_cols = max((len(r) for r in sample), default=0)
    text_scores = []
    barcode_scores = []
    numeric_scores = []
    for c in range(max_cols):
        texts = [safe_str(r[c]) for r in sample if c < len(r)]
        text_scores.append(sum(1 for t in texts if len(t) > 5 and not parse_float(t)))
        barcode_scores.append(sum(1 for t in texts if split_barcodes(t)))
        numeric_scores.append(sum(1 for t in texts if parse_float(t) != 0))
    if text_scores:
        cols["name"] = max(range(len(text_scores)), key=lambda i: text_scores[i])
    if barcode_scores and max(barcode_scores) > 0:
        cols["barcode"] = max(range(len(barcode_scores)), key=lambda i: barcode_scores[i])
    numeric_order = sorted(range(len(numeric_scores)), key=lambda i: numeric_scores[i], reverse=True)
    if numeric_order:
        cols["qty"] = numeric_order[0]
    if len(numeric_order) > 1:
        cols["buy"] = numeric_order[1]
    return cols


def rows_from_table(table: List[List[Any]], markup_percent: float, source_hint: str = "") -> Tuple[List[ConvertItem], List[str], Dict[str, str]]:
    warnings: List[str] = []
    meta: Dict[str, str] = {}
    if not table:
        return [], ["Файл пустой."], meta

    # Try to catch document number/date/supplier in the top text area.
    top_text = "\n".join(" ".join(safe_str(c) for c in row if safe_str(c)) for row in table[:12])
    date = parse_date(top_text)
    if date:
        meta["date"] = date
    inv = re.search(r"(?:счет|сч[её]т|накладная|упд|№|номер)\s*(?:№)?\s*([A-Za-zА-Яа-я0-9_\-/]+)", top_text, flags=re.I)
    if inv:
        meta["invoice_number"] = inv.group(1)

    header_row, cols, detect_warnings = detect_columns(table)
    warnings.extend(detect_warnings)
    missing_core = [f for f in ("name", "qty", "buy") if f not in cols]
    if missing_core:
        warnings.append("Не уверенно найдены колонки: " + ", ".join(missing_core) + ". Проверь предпросмотр.")

    items: List[ConvertItem] = []
    repeated_headers = 0
    for row_number, row in enumerate(table[header_row + 1 :], start=header_row + 2):
        row_cols, row_header_score = columns_from_header_row(row)
        if row_header_score >= 4 and "name" in row_cols and ({"qty", "buy", "total"} & set(row_cols)):
            # Supplier printouts often repeat the whole header on every page.
            # It starts a new table band; it never means that the goods ended.
            cols = row_cols
            repeated_headers += 1
            continue

        def cell(field: str) -> Any:
            idx = cols.get(field)
            return row[idx] if idx is not None and idx < len(row) else ""

        raw_name = cell("name")
        name = clean_name(raw_name)
        qty = parse_float(cell("qty"), 0.0)
        unit = normalize_unit(cell("unit")) if "unit" in cols else "штука"
        buy = parse_float(cell("buy"), 0.0)
        total = parse_float(cell("total"), 0.0)
        if total and qty:
            buy = round(total / qty, 4)
        sale = parse_float(cell("sale"), 0.0)
        if not sale:
            sale = calc_sale_price(buy, markup_percent)
        article = safe_str(cell("article"))
        category = safe_str(cell("category"))

        # An explicit barcode column is authoritative. Never reinterpret a
        # numeric supplier article or price elsewhere in the row as a barcode.
        # Whole-row fallback remains only for headerless documents where SAI
        # could not identify a dedicated barcode column.
        barcodes = (
            split_barcodes(cell("barcode"))
            if "barcode" in cols
            else split_barcodes(*row)
        )

        # Skip obvious service/summary rows.
        row_text = " ".join(safe_str(c) for c in row if safe_str(c)).strip()
        if not row_text:
            continue
        lower_name = name.lower()
        if lower_name in {"итого", "всего", "сумма"} or lower_name.startswith("итого") or lower_name.startswith("всего"):
            continue
        if not name and not qty and not buy and not barcodes:
            continue

        item = ConvertItem(
            row=len(items) + 1,
            raw_name=safe_str(raw_name),
            name=name,
            quantity=qty,
            unit=unit,
            purchase_price=buy,
            sale_price=sale,
            article=article,
            category=category,
            barcodes=barcodes,
            comment=f"source row {row_number}" if source_hint else "",
            line_total=round(total if total else buy * qty, 4),
            purchase_price_source="сумма строки / количество" if total and qty else "колонка цены",
            confidence=1.0,
        )
        validate_item(item)
        items.append(item)

    if repeated_headers:
        warnings.append(
            f"Объединены все печатные блоки таблицы: повторных шапок {repeated_headers}."
        )

    return items, warnings, meta


def validate_item(item: ConvertItem) -> None:
    item.issues.clear()
    if not item.name:
        item.issues.append("нет названия")
    if not item.quantity:
        item.issues.append("нет количества")
    if not item.purchase_price:
        item.issues.append("нет закупочной цены")
    if not item.sale_price:
        item.issues.append("нет продажной цены")
    if not item.barcodes:
        item.issues.append("нет ШК")
    if item.unit not in {"штука", "м"}:
        item.unit = normalize_unit(item.unit)


def read_xlsx_table(path: Path) -> List[List[Any]]:
    if load_workbook is None:
        raise RuntimeError("openpyxl не установлен")
    wb = load_workbook(str(path), data_only=True, read_only=True)
    # Prefer a sheet that looks like goods table.
    best_ws = wb.active
    best_score = -1
    for ws in wb.worksheets:
        table = []
        for row in ws.iter_rows(max_row=30, values_only=True):
            table.append(list(row))
        _, cols, _ = detect_columns(table)
        score = len(cols)
        if score > best_score:
            best_score = score
            best_ws = ws
    table: List[List[Any]] = []
    for row in best_ws.iter_rows(values_only=True):
        vals = list(row)
        # Trim empty tail but keep column positions before the last value.
        while vals and safe_str(vals[-1]) == "":
            vals.pop()
        table.append(vals)
    return table


def read_xls_tables(path: Path) -> List[Tuple[str, List[List[Any]]]]:
    """Read every worksheet from legacy BIFF .xls without requiring Excel."""
    if xlrd is None:
        raise RuntimeError("встроенный модуль чтения XLS недоступен")
    workbook = xlrd.open_workbook(str(path), on_demand=True)
    result: List[Tuple[str, List[List[Any]]]] = []
    try:
        for sheet in workbook.sheets():
            table: List[List[Any]] = []
            for row_number in range(sheet.nrows):
                values = [sheet.cell_value(row_number, column) for column in range(sheet.ncols)]
                while values and safe_str(values[-1]) == "":
                    values.pop()
                table.append(values)
            result.append((safe_str(sheet.name) or "Лист", table))
    finally:
        workbook.release_resources()
    return result


def read_csv_table(path: Path) -> List[List[Any]]:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1251", "utf-8"):
        try:
            text = raw.decode(enc)
            break
        except Exception:
            text = ""
    if not text:
        text = raw.decode("utf-8", errors="replace")
    sample = text[:4096]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t,")
    except Exception:
        dialect = csv.excel
        dialect.delimiter = ";"
    return [row for row in csv.reader(text.splitlines(), dialect)]


def local_name(tag: str) -> str:
    return tag.split("}", 1)[-1] if "}" in tag else tag


def attr_any(el: ET.Element, names: Iterable[str]) -> str:
    wanted = {norm_text(n) for n in names}
    for k, v in el.attrib.items():
        if norm_text(local_name(k)) in wanted:
            return safe_str(v)
    return ""


def descendant_attr_any(el: ET.Element, names: Iterable[str]) -> str:
    """Read an attribute from an element or one of its children."""
    for child in el.iter():
        value = attr_any(child, names)
        if value:
            return value
    return ""


def _party_name(container: ET.Element) -> str:
    for party in container.iter():
        tag = local_name(party.tag)
        if tag in {"СвЮЛУч", "СвЮЛ", "Орг"}:
            value = attr_any(party, ["НаимОрг", "НаимОргСокр", "Наим", "Наименование"])
            if value:
                return value
        if tag in {"СвИП", "ИП"}:
            organization = attr_any(party, ["НаимОрг", "Наим", "Наименование"])
            if organization:
                return organization
            for person in party.iter():
                if local_name(person.tag) != "ФИО":
                    continue
                parts = [attr_any(person, [key]) for key in ("Фамилия", "Имя", "Отчество")]
                full_name = " ".join(part for part in parts if part)
                if full_name:
                    return "ИП " + full_name
    return ""


def parse_upd_xml_bytes(data: bytes, source_path: str, markup_percent: float) -> ConvertResult:
    try:
        root = ET.fromstring(data)
    except Exception as exc:
        return ConvertResult(source_path=source_path, source_type="XML", errors=[f"XML не читается: {exc}"])

    result = ConvertResult(source_path=source_path, source_type="XML", markup_percent=markup_percent)
    # Document meta.
    for el in root.iter():
        name = local_name(el.tag)
        if name == "СвПрод":
            supplier = _party_name(el) or attr_any(el, ["НаимОрг", "НаимОргСокр", "Наим", "Наименование"])
            if supplier and not result.supplier:
                result.supplier = supplier.upper()
        if name in {"СвСчФакт", "Документ", "Файл"}:
            if not result.invoice_number:
                result.invoice_number = attr_any(el, ["НомерДок", "НомерСчФ", "НомСчФ", "Номер"])
            if not result.date:
                result.date = parse_date(attr_any(el, ["ДатаДок", "ДатаСчФ", "Дата"] ))

    items: List[ConvertItem] = []
    for el in root.iter():
        name = attr_any(el, ["НаимТов", "НаименованиеТовара", "Наименование", "Наим"])
        if not name:
            continue
        tag = local_name(el.tag).lower()
        # In UPD goods usually live in СведТов / СвТов. Avoid organization names.
        if tag not in {"сведтов", "свтов", "тов", "товар", "item"} and not attr_any(el, ["КолТов", "Количество"]):
            continue
        qty = parse_float(attr_any(el, ["КолТов", "Количество", "Кол", "quantity"]), 0.0)
        printed_buy = parse_float(attr_any(el, ["ЦенаТов", "Цена", "price"]), 0.0)
        # The store pays the VAT-inclusive line amount. In UПД, ЦенаТов is
        # commonly VAT-exclusive, so always prefer СтТовУчНал / КолТов.
        total = parse_float(attr_any(el, ["СтТовУчНал", "Сумма", "Стоимость"]), 0.0)
        buy = round(total / qty, 4) if qty and total else printed_buy
        sale = calc_sale_price(buy, markup_percent)
        unit = normalize_unit(attr_any(el, ["НаимЕдИзм", "ОКЕИ_Тов", "ЕдИзм", "Ед"] ))
        article = descendant_attr_any(el, ["АртикулТов", "Артикул", "КодПоставщика"])
        barcode_values: List[str] = []
        for child in el.iter():
            barcode_values.extend(
                attr_any(child, [field])
                for field in ("КодТов", "НомСредИдентТов", "Штрихкод", "ШК", "EAN")
            )
        barcodes = split_barcodes(*barcode_values)
        item = ConvertItem(
            row=int(parse_float(attr_any(el, ["НомСтр", "НомерСтроки"]), len(items) + 1)),
            raw_name=safe_str(name),
            name=clean_name(name),
            quantity=qty,
            unit=unit,
            purchase_price=buy,
            sale_price=sale,
            article=article,
            barcodes=barcodes,
            line_total=total,
            purchase_price_source="сумма строки с НДС / количество" if qty and total else "цена товара",
            confidence=1.0,
        )
        validate_item(item)
        items.append(item)

    result.items = items
    if not items:
        result.errors.append("В XML не нашёл товарные строки. Для этого формата нужен отдельный шаблон конвертера.")
    if not result.supplier:
        result.supplier = supplier_from_filename(Path(source_path))
    result.validation = {
        "structured_source": "diadoc_upd_xml",
        "local_import": True,
        "manual_review_required": False,
        "document_total": round(sum(item.line_total for item in items), 2),
        "price_from_line_total": sum(1 for item in items if item.line_total > 0 and item.quantity > 0),
        "price_from_printed": sum(1 for item in items if not item.line_total and item.purchase_price > 0),
    }
    return result


def convert_document(path: str | Path, supplier: str = "", invoice_date: str = "", invoice_number: str = "", markup_percent: float = 60.0) -> ConvertResult:
    p = Path(path)
    if not p.exists():
        return ConvertResult(source_path=str(p), source_type="UNKNOWN", errors=["Файл не найден."])
    suffix = p.suffix.lower()
    result: ConvertResult
    try:
        if suffix == ".xls":
            all_items: List[ConvertItem] = []
            warnings: List[str] = []
            meta: Dict[str, str] = {}
            xls_sheets = read_xls_tables(p)
            for sheet_name, table in xls_sheets:
                sheet_items, sheet_warnings, sheet_meta = rows_from_table(
                    table, markup_percent, source_hint=f"xls:{sheet_name}"
                )
                if sheet_items:
                    for item in sheet_items:
                        item.row = len(all_items) + 1
                        all_items.append(item)
                    warnings.extend(f"{sheet_name}: {message}" for message in sheet_warnings)
                    for key, value in sheet_meta.items():
                        meta.setdefault(key, value)
            result = ConvertResult(str(p), "Excel XLS", items=all_items, warnings=warnings, markup_percent=markup_percent)
            result.date = meta.get("date", "")
            result.invoice_number = meta.get("invoice_number", "")
            result.validation = {
                "local_xls_row_count": len(all_items),
                "local_xls_sheet_count": len(xls_sheets),
                "complete_local_read": True,
            }
        elif suffix in {".xlsx", ".xlsm"}:
            table = read_xlsx_table(p)
            items, warnings, meta = rows_from_table(table, markup_percent, source_hint="xlsx")
            result = ConvertResult(str(p), "Excel", items=items, warnings=warnings, markup_percent=markup_percent)
            result.date = meta.get("date", "")
            result.invoice_number = meta.get("invoice_number", "")
        elif suffix in {".csv", ".txt"}:
            table = read_csv_table(p)
            items, warnings, meta = rows_from_table(table, markup_percent, source_hint="csv")
            result = ConvertResult(str(p), "CSV", items=items, warnings=warnings, markup_percent=markup_percent)
            result.date = meta.get("date", "")
            result.invoice_number = meta.get("invoice_number", "")
        elif suffix == ".xml":
            result = parse_upd_xml_bytes(p.read_bytes(), str(p), markup_percent)
        elif suffix == ".zip":
            result = convert_zip(p, markup_percent)
        else:
            result = ConvertResult(str(p), suffix.upper().lstrip(".") or "UNKNOWN", errors=["Пока поддерживаются XLSX/XLSM/CSV/XML/ZIP. PDF и фото добавим отдельным AI/OCR-слоем."])
    except Exception as exc:
        result = ConvertResult(str(p), suffix.upper().lstrip(".") or "UNKNOWN", errors=[f"Ошибка конвертации: {exc}"])

    if not result.supplier:
        result.supplier = supplier_from_filename(p)
    if supplier:
        result.supplier = supplier.strip().upper()
    if invoice_date:
        result.date = parse_date(invoice_date) or invoice_date.strip()
    if invoice_number:
        result.invoice_number = invoice_number.strip()
    result.markup_percent = float(markup_percent or 60.0)
    if not result.date:
        result.date = dt.date.today().isoformat()
    if not result.items and not result.errors:
        result.errors.append("Товарные строки не найдены.")
    return result


def convert_zip(path: Path, markup_percent: float) -> ConvertResult:
    try:
        with zipfile.ZipFile(str(path), "r") as zf:
            members = zf.infolist()
            if len(members) > MAX_DIADOC_ZIP_MEMBERS:
                return ConvertResult(str(path), "ZIP", errors=["В ZIP слишком много файлов. Архив остановлен для безопасности."])
            if sum(max(0, info.file_size) for info in members) > MAX_DIADOC_ZIP_UNCOMPRESSED_BYTES:
                return ConvertResult(str(path), "ZIP", errors=["Распакованный ZIP больше 100 МБ. Архив остановлен для безопасности."])
            xml_members = [
                info for info in members
                if not info.is_dir() and info.filename.lower().endswith(".xml")
                and info.file_size <= MAX_DIADOC_XML_BYTES
            ]
            # Diadoc service XML files (DP_*) contain statuses and signatures.
            # Prefer the actual universal transfer document (ON_NSCHFDOPPR_*).
            primary = [
                info for info in xml_members
                if Path(info.filename.replace("\\", "/")).name.upper().startswith("ON_NSCHFDOPPR_")
            ]
            xml_members = primary or xml_members
            if not xml_members:
                return ConvertResult(str(path), "ZIP", errors=["В ZIP не нашёл XML-файлы."])
            best: Optional[ConvertResult] = None
            best_xml_name = ""
            for info in xml_members:
                if info.flag_bits & 0x1:
                    continue
                data = zf.read(info)
                res = parse_upd_xml_bytes(data, f"{path.name}/{info.filename}", markup_percent)
                if res.items and (best is None or len(res.items) > len(best.items)):
                    best = res
                    best_xml_name = info.filename
            if best is None:
                return ConvertResult(str(path), "ZIP", errors=["В ZIP XML есть, но товарные строки не распознаны."])
            best.source_path = str(path)
            best.source_type = "DIADOC/UPD"
            best.validation = dict(best.validation or {})
            best.validation["archive_members"] = len(members)
            best.validation["source_xml"] = best_xml_name
            if not best.supplier:
                best.supplier = supplier_from_filename(path)
            return best
    except Exception as exc:
        return ConvertResult(str(path), "ZIP", errors=[f"ZIP не читается: {exc}"])


def write_sai_xml(result: ConvertResult, out_path: str | Path) -> str:
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    root = ET.Element("sai_receipt", {"version": "1.0"})
    meta = ET.SubElement(root, "meta")
    for tag, value in [
        ("supplier", result.supplier),
        ("date", result.date),
        ("invoice_number", result.invoice_number),
        ("markup_percent", str(int(result.markup_percent) if float(result.markup_percent).is_integer() else result.markup_percent)),
        ("currency", "RUB"),
        ("source", "SAI Converter"),
        ("source_file", Path(result.source_path).name),
    ]:
        el = ET.SubElement(meta, tag)
        el.text = safe_str(value)

    items_el = ET.SubElement(root, "items")
    for idx, item in enumerate(result.items, start=1):
        item_el = ET.SubElement(items_el, "item", {"row": str(idx)})
        fields = [
            ("name", item.name),
            ("quantity", format_number(item.quantity)),
            ("unit", item.unit),
            ("purchase_price", format_number(item.purchase_price)),
            ("sale_price", format_number(item.sale_price)),
            ("article", item.article),
            ("category", item.category),
        ]
        for tag, value in fields:
            el = ET.SubElement(item_el, tag)
            el.text = safe_str(value)
        bcs = ET.SubElement(item_el, "barcodes")
        for bc in item.barcodes:
            bc_el = ET.SubElement(bcs, "barcode")
            bc_el.text = bc
        comment = ET.SubElement(item_el, "comment")
        extra = item.comment
        if item.issues:
            extra = (extra + "; " if extra else "") + "Проверить: " + ", ".join(item.issues)
        comment.text = extra

    indent_xml(root)
    tree = ET.ElementTree(root)
    tree.write(str(out), encoding="utf-8", xml_declaration=True)
    # Preserve the exact original invoice path for the permanent receipt archive.
    # The XML itself keeps only a portable filename; the sidecar stays local.
    try:
        from sai_receipt_archive import write_source_sidecar
        source = Path(result.source_path)
        if source.is_file():
            write_source_sidecar(out, [source])
    except Exception:
        pass
    return str(out)



def write_sai_package(
    result: ConvertResult,
    out_path: str | Path,
    source_paths: Sequence[str | Path] | None = None,
) -> str:
    """Write the current open SAI Package format (.sai)."""
    from sai_package import write_package
    try:
        from sai_version import APP_VERSION
    except Exception:
        APP_VERSION = ""
    return write_package(
        result,
        out_path,
        source_paths=source_paths,
        created_by_version=APP_VERSION,
    )


def write_sai_file(
    result: ConvertResult,
    out_path: str | Path,
    source_paths: Sequence[str | Path] | None = None,
) -> str:
    """Canonical SAI writer. XML is retained only through write_sai_xml()."""
    return write_sai_package(result, out_path, source_paths=source_paths)

def format_number(value: Any) -> str:
    try:
        f = float(value)
        if f.is_integer():
            return str(int(f))
        return ("%.4f" % f).rstrip("0").rstrip(".")
    except Exception:
        return "0"


def indent_xml(elem: ET.Element, level: int = 0) -> None:
    i = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        for child in elem:
            indent_xml(child, level + 1)
        if not child.tail or not child.tail.strip():
            child.tail = i
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = i


def default_output_path(result: ConvertResult, directory: str | Path | None = None) -> Path:
    base_dir = Path(directory) if directory else Path(result.source_path).parent
    supplier = filename_component(result.supplier)
    date_part = re.sub(r"\D+", "", result.date or dt.date.today().isoformat())[-6:]
    if len(date_part) != 6:
        date_part = dt.date.today().strftime("%d%m%y")
    return base_dir / f"SAI_{supplier}_{date_part}.sai"


if __name__ == "__main__":  # small CLI for local testing
    import argparse
    parser = argparse.ArgumentParser(description="Convert supplier document to SAI Package")
    parser.add_argument("file")
    parser.add_argument("--supplier", default="")
    parser.add_argument("--date", default="")
    parser.add_argument("--invoice", default="")
    parser.add_argument("--markup", type=float, default=60.0)
    parser.add_argument("--out", default="")
    args = parser.parse_args()
    res = convert_document(args.file, args.supplier, args.date, args.invoice, args.markup)
    print(f"items={len(res.items)} warnings={len(res.warnings)} errors={len(res.errors)}")
    for w in res.warnings:
        print("WARN", w)
    for e in res.errors:
        print("ERROR", e)
    if res.items:
        out = Path(args.out) if args.out else default_output_path(res)
        print(write_sai_package(res, out))
