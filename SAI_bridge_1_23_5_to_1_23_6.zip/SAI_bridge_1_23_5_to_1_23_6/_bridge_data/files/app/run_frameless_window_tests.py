#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Runtime checks for the frameless SAI shell and screen-safe geometry."""
from __future__ import annotations

import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import sai_pyside_preview as ui


def main() -> None:
    app = ui.QApplication.instance() or ui.QApplication([])
    window = ui.MainWindow()
    assert window.windowFlags() & ui.Qt.WindowType.FramelessWindowHint
    assert isinstance(window.title_bar, ui.FramelessTitleBar)
    assert window.title_bar.height() == 36
    assert window.title_bar.maximize_btn.kind == "maximize"

    window.fit_to_available_screen(force=True)
    window.show()
    app.processEvents()
    screen = window.screen() or app.primaryScreen()
    assert screen is not None
    available = screen.availableGeometry()
    frame = window.frameGeometry()
    assert available.contains(frame.topLeft()), (available, frame)
    assert available.contains(frame.bottomRight()), (available, frame)
    assert window.height() <= available.height()
    assert window.width() <= available.width()

    top_left = window.mapToGlobal(ui.QPoint(1, 1))
    edges = window._frameless_resize._edges_at(top_left)
    assert edges & ui.Qt.Edge.LeftEdge
    assert edges & ui.Qt.Edge.TopEdge

    window.close()
    app.processEvents()
    print("Frameless window tests passed.")


if __name__ == "__main__":
    main()
