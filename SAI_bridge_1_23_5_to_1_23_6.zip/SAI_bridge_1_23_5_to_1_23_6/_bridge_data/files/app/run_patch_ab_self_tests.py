#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import os,sys,tempfile,json
from pathlib import Path
root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_ab_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as m
assert m.CONTRACT_VERSION=='invoice_ai_contract_v7'
assert m.SCHEMA_VERSION=='invoice_schema_v6'
assert m.AUDIT_SCHEMA_VERSION=='invoice_audit_schema_v4'
assert m.AUDIT_MODEL=='gpt-5.6-sol'
invoice=m.build_invoice_schema(); audit=m.build_audit_schema()
assert 'source_page' in invoice['properties']['items']['items']['required']
assert {'supplier','checked_rows','rows'} <= set(audit['required'])
assert 'uniqueItems' not in json.dumps(audit)
# Verified audit replaces the imperfect first read, including supplier and exact GTIN.
doc={'supplier':'ИП Симонов Игорь Алексеевич','invoice_date':'2026-07-16','invoice_number':'G-1','document_total':556.0,'items':[{'source_row':1,'source_page':1,'raw_name':'Удлинитель катушка 3 роз.','name':'Удлинитель катушка 3 роз.','article':'860445','barcodes':['4630115290922'],'quantity':4,'unit':'шт','line_total':556,'confidence':0.8,'note':'нечетко'}]}
verified={'supplier':'ИП Смирнов Игорь Алексеевич','invoice_date':'2026-07-16','invoice_number':'G-1','document_total':556.0,'checked_rows':[1],'rows':[{'source_row':1,'source_page':1,'status':'verified','raw_name':'1-2-SALE сет. удлинитель ПВС 2x1 2роз. 2м 10А','article':'860454','barcodes':['4630115290292'],'quantity':4,'unit':'шт','line_total':556,'note':''}]}
merged,changed,uncertain=m.apply_audit(doc,verified)
assert merged['supplier']=='ИП Смирнов Игорь Алексеевич'
row=merged['items'][0]
assert row['article']=='860454' and row['barcodes']==['4630115290292']
assert 'катушка' not in row['raw_name'].lower() and row['note']=='' and not uncertain
assert 1 in changed
# Uncertain fields stay explicit and cannot masquerade as verified.
verified['rows'][0]['status']='uncertain'; verified['rows'][0]['note']='ШК: одна цифра не читается'; verified['rows'][0]['barcodes']=[]
merged2,changed2,uncertain2=m.apply_audit(doc,verified)
assert uncertain2==[1] and merged2['items'][0]['barcodes']==[] and 'цифра' in merged2['items'][0]['note']
# Audit parser rejects duplicate rows.
resp={'output':[{'type':'message','content':[{'type':'output_text','text':json.dumps({'supplier':'x','invoice_date':'','invoice_number':'','document_total':1,'checked_rows':[1],'rows':[verified['rows'][0],verified['rows'][0]]},ensure_ascii=False)}]}]}
try: m._parse_audit_response(resp)
except m.OpenAIInvoiceError: pass
else: raise AssertionError('duplicate audit row accepted')
print('PATCH_AB_SELF_TEST_OK')
