#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Serverless organization sync over a shared folder.

SQLite databases are deliberately never copied.  Every completed receipt is
published as an immutable, self-contained bundle and imported into each
computer's own local database. Active receipt drafts use per-device snapshots
with last-write-wins conflict resolution. The transport may be a Windows
network share or a folder synchronized by Yandex Disk.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import shutil
import socket
import uuid
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Optional

import sai_db
import sai_receipt_drafts
import sai_staff
from sai_runtime_paths import USER_DATA_DIR


SCHEMA_VERSION = 1
ORGANIZATION_FILE = "organization.json"
STATE_FILE = USER_DATA_DIR / "organization_sync_state.json"
IMPORTED_ARCHIVE_ROOT = USER_DATA_DIR / "История приходов" / "Общие"


def _now() -> str:
    return dt.datetime.now().astimezone().replace(microsecond=0).isoformat()


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def _safe(value: Any, fallback: str = "item", limit: int = 100) -> str:
    text = _text(value) or fallback
    text = re.sub(r'[^0-9A-Za-zА-Яа-яЁё._ -]+', "_", text)
    return text.strip(" ._")[:limit] or fallback


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def _atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    os.replace(temporary, path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _copy_if_changed(source: Path, target: Path, expected_sha256: str = "") -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        try:
            if expected_sha256 and _sha256(target) == expected_sha256:
                return
            if not expected_sha256 and target.stat().st_size == source.stat().st_size:
                return
        except Exception:
            pass
    temporary = target.with_suffix(target.suffix + f".{os.getpid()}.tmp")
    shutil.copy2(source, temporary)
    os.replace(temporary, target)


def _safe_relative(value: Any) -> Path:
    path = Path(_text(value))
    if not path.parts or path.is_absolute() or ".." in path.parts:
        raise RuntimeError("Общий пакет содержит небезопасный путь к файлу.")
    return path


def new_device_id() -> str:
    return uuid.uuid4().hex[:16]


def default_device_name() -> str:
    return socket.gethostname() or "Компьютер SAI"


@dataclass
class SyncSettings:
    enabled: bool
    root: Path
    organization_name: str
    device_id: str
    device_name: str

    @classmethod
    def from_config(cls, config: Mapping[str, Any]) -> "SyncSettings":
        return cls(
            enabled=bool(config.get("organization_sync_enabled", False)),
            root=Path(_text(config.get("organization_sync_root"))).expanduser(),
            organization_name=_text(config.get("organization_name")) or "Моя организация",
            device_id=_text(config.get("organization_device_id")) or new_device_id(),
            device_name=_text(config.get("organization_device_name")) or default_device_name(),
        )

    @property
    def valid(self) -> bool:
        return bool(self.enabled and self.root.parts)


@dataclass
class SyncReport:
    ok: bool = True
    exported_receipts: int = 0
    imported_receipts: int = 0
    published_drafts: int = 0
    imported_drafts: int = 0
    published_staff_records: int = 0
    imported_staff_records: int = 0
    available_version: str = ""
    message: str = ""
    completed_at: str = ""


def initialize_organization(settings: SyncSettings) -> Path:
    if not settings.root.parts:
        raise ValueError("Не выбрана общая папка организации.")
    settings.root.mkdir(parents=True, exist_ok=True)
    for name in ("history", "updates", "devices", "staff", "drafts"):
        (settings.root / name).mkdir(parents=True, exist_ok=True)
    org_path = settings.root / ORGANIZATION_FILE
    current = _read_json(org_path, {}) or {}
    if not current:
        _atomic_json(org_path, {
            "schema_version": SCHEMA_VERSION,
            "organization_id": uuid.uuid4().hex,
            "name": settings.organization_name,
            "created_at": _now(),
        })
    _atomic_json(settings.root / "devices" / f"{_safe(settings.device_id)}.json", {
        "device_id": settings.device_id,
        "device_name": settings.device_name,
        "last_seen_at": _now(),
    })
    return settings.root


def _ensure_sync_schema() -> None:
    sai_db.init_db()
    with closing(sai_db.connect()) as con:
        columns = {str(row[1]) for row in con.execute("PRAGMA table_info(apply_runs)").fetchall()}
        if "organization_sync_id" not in columns:
            con.execute("ALTER TABLE apply_runs ADD COLUMN organization_sync_id TEXT")
        if "source_device_name" not in columns:
            con.execute("ALTER TABLE apply_runs ADD COLUMN source_device_name TEXT")
        con.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_apply_runs_org_sync_id "
            "ON apply_runs(organization_sync_id) WHERE organization_sync_id IS NOT NULL"
        )
        con.commit()


def _local_receipts() -> list[Dict[str, Any]]:
    _ensure_sync_schema()
    with closing(sai_db.connect()) as con:
        rows = con.execute(
            """
            SELECT * FROM apply_runs
            WHERE status='ok' AND COALESCE(error_count, 0)=0
              AND COALESCE(ok_count, 0)>0
              AND COALESCE(organization_sync_id, '')=''
            ORDER BY id
            """
        ).fetchall()
    return [dict(row) for row in rows]


def _bundle_signature(run: Mapping[str, Any], items: Iterable[Mapping[str, Any]], files: Iterable[Mapping[str, Any]]) -> str:
    payload = {
        "run": {key: run.get(key) for key in (
            "supplier_name", "invoice_date", "waybill_id", "status", "ok_count", "error_count",
            "total_quantity", "buying_total", "selling_total", "app_version", "created_at",
        )},
        "items": list(items),
        "files": [
            {"kind": row.get("kind"), "stored_name": row.get("stored_name"), "size": row.get("file_size")}
            for row in files
        ],
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _publish_receipt(settings: SyncSettings, run: Mapping[str, Any], state: Dict[str, Any]) -> bool:
    run_id = int(run.get("id") or 0)
    sync_id = f"{_safe(settings.device_id)}-{run_id:08d}"
    items = sai_db.get_apply_items(run_id)
    files = sai_db.receipt_files(run_id)
    signature = _bundle_signature(run, items, files)
    exports = state.setdefault("exports", {})
    target = settings.root / "history" / sync_id
    if exports.get(sync_id) == signature and (target / "manifest.json").is_file():
        return False

    copied_files = []
    for index, row in enumerate(files, start=1):
        source = Path(_text(row.get("archived_path")))
        if not source.is_file():
            continue
        stored = _safe(row.get("stored_name") or row.get("original_name") or source.name, f"file-{index}")
        relative = Path("files") / f"{index:03d}_{_safe(row.get('kind'), 'file')}" / stored
        checksum = _sha256(source)
        _copy_if_changed(source, target / relative, checksum)
        copied_files.append({
            "kind": _text(row.get("kind")),
            "original_name": _text(row.get("original_name")) or source.name,
            "stored_name": stored,
            "relative_path": relative.as_posix(),
            "file_size": source.stat().st_size,
            "sha256": checksum,
        })

    manifest = {
        "schema_version": SCHEMA_VERSION,
        "sync_id": sync_id,
        "source_device_id": settings.device_id,
        "source_device_name": settings.device_name,
        "published_at": _now(),
        "signature": signature,
        "run": {key: run.get(key) for key in (
            "sai_file_name", "supplier_name", "invoice_date", "waybill_id", "status", "ok_count",
            "error_count", "total_quantity", "buying_total", "selling_total", "app_version", "created_at",
        )},
        "items": items,
        "files": copied_files,
    }
    _atomic_json(target / "manifest.json", manifest)  # manifest last: bundle is now complete
    exports[sync_id] = signature
    return True


def _import_receipt(settings: SyncSettings, manifest_path: Path) -> bool:
    manifest = _read_json(manifest_path, {}) or {}
    sync_id = _text(manifest.get("sync_id"))
    if not sync_id or _text(manifest.get("source_device_id")) == settings.device_id:
        return False
    run = manifest.get("run") if isinstance(manifest.get("run"), dict) else {}
    items = manifest.get("items") if isinstance(manifest.get("items"), list) else []
    files = manifest.get("files") if isinstance(manifest.get("files"), list) else []
    _ensure_sync_schema()
    local_archive = IMPORTED_ARCHIVE_ROOT / _safe(sync_id)
    local_archive.mkdir(parents=True, exist_ok=True)

    with closing(sai_db.connect()) as con:
        existing = con.execute("SELECT id FROM apply_runs WHERE organization_sync_id=?", (sync_id,)).fetchone()
        if existing:
            return False
        cur = con.execute(
            """
            INSERT INTO apply_runs(
                sai_path, sai_file_name, supplier_name, invoice_date, waybill_id, status,
                ok_count, error_count, total_quantity, buying_total, selling_total,
                log_path, audit_path, archive_dir, app_version, created_at,
                organization_sync_id, source_device_name
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                "", _text(run.get("sai_file_name")), _text(run.get("supplier_name")),
                _text(run.get("invoice_date")), _text(run.get("waybill_id")), "ok",
                int(run.get("ok_count") or len(items)), 0, float(run.get("total_quantity") or 0),
                float(run.get("buying_total") or 0), float(run.get("selling_total") or 0),
                "", "", str(local_archive), _text(run.get("app_version")),
                _text(run.get("created_at")) or _now(), sync_id, _text(manifest.get("source_device_name")),
            ),
        )
        apply_id = int(cur.lastrowid)
        for item in items:
            if not isinstance(item, dict):
                continue
            con.execute(
                """
                INSERT INTO price_history(
                    apply_run_id, product_id, barcode, used_barcode, name, supplier_name, invoice_date,
                    waybill_id, quantity, buying_price, incoming_selling_price,
                    sigma_existing_selling_price, final_selling_price, price_source, status,
                    source_log_path, created_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    apply_id, _text(item.get("product_id")), _text(item.get("barcode")),
                    _text(item.get("used_barcode")), _text(item.get("name")), _text(run.get("supplier_name")),
                    _text(run.get("invoice_date")), _text(run.get("waybill_id")),
                    float(item.get("quantity") or 0), float(item.get("buying_price") or 0),
                    float(item.get("incoming_selling_price") or 0),
                    item.get("sigma_existing_selling_price"), float(item.get("final_selling_price") or 0),
                    _text(item.get("price_source")), "OK", "", _text(run.get("created_at")) or _now(),
                ),
            )
        for index, file_row in enumerate(files, start=1):
            if not isinstance(file_row, dict):
                continue
            relative = _safe_relative(file_row.get("relative_path"))
            source = manifest_path.parent / relative
            if not source.is_file():
                continue
            target = local_archive / relative
            checksum = _text(file_row.get("sha256"))
            if checksum and _sha256(source) != checksum:
                raise RuntimeError(f"Повреждён файл общей истории: {source.name}")
            _copy_if_changed(source, target, checksum)
            con.execute(
                """
                INSERT INTO receipt_files(apply_run_id, kind, original_name, stored_name, archived_path, file_size, created_at)
                VALUES(?,?,?,?,?,?,?)
                """,
                (
                    apply_id, _text(file_row.get("kind")), _text(file_row.get("original_name")),
                    _text(file_row.get("stored_name")) or target.name, str(target), target.stat().st_size, _now(),
                ),
            )
            if not _text(run.get("sai_file_name")) and _text(file_row.get("kind")) == "sai":
                con.execute("UPDATE apply_runs SET sai_path=?, sai_file_name=? WHERE id=?", (str(target), target.name, apply_id))
        con.commit()
    _atomic_json(local_archive / "sync_manifest.json", manifest)
    return True


def _draft_id(value: Any) -> str:
    return re.sub(r"[^a-zA-Z0-9_-]+", "", _text(value))[:80]


def _draft_tombstones() -> Dict[str, str]:
    payload = _read_json(sai_receipt_drafts.DRAFTS_DIR / "_deleted.json", {}) or {}
    rows = payload.get("drafts") if isinstance(payload, dict) else {}
    return {
        _draft_id(key): _text(value)
        for key, value in (rows or {}).items()
        if _draft_id(key) and _text(value)
    }


def _draft_public_metadata(row: Mapping[str, Any]) -> Dict[str, Any]:
    """Strip computer-specific paths while retaining workflow/UI metadata."""
    return {
        str(key): value
        for key, value in row.items()
        if str(key) not in {
            "package_path", "manual_payload_path", "_sync_source_device_id",
            "_sync_revision", "_sync_signature",
        }
    }


def _draft_signature(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _publish_drafts(settings: SyncSettings) -> int:
    """Publish this computer's changed draft revisions and deletion markers."""
    published = 0
    device_root = settings.root / "drafts" / _safe(settings.device_id)
    rows = {str(row.get("id") or ""): row for row in sai_receipt_drafts.list_all() if row.get("id")}
    tombstones = _draft_tombstones()
    for draft_id in sorted(set(rows) | set(tombstones)):
        safe_id = _draft_id(draft_id)
        if not safe_id:
            continue
        row = rows.get(draft_id)
        deleted_at = _text(tombstones.get(safe_id))
        if deleted_at:
            payload: Dict[str, Any] = {
                "schema_version": SCHEMA_VERSION,
                "draft_id": safe_id,
                "source_device_id": settings.device_id,
                "source_device_name": settings.device_name,
                "updated_at": deleted_at,
                "deleted": True,
                "metadata": {},
                "file": None,
            }
        elif row is not None:
            updated_at = _text(row.get("updated_at")) or _now()
            # An unchanged imported revision already has an authoritative
            # source snapshot. Republish only after a local edit.
            if (
                _text(row.get("_sync_source_device_id"))
                and _text(row.get("_sync_source_device_id")) != settings.device_id
                and _text(row.get("_sync_revision")) == updated_at
            ):
                continue
            source: Optional[Path] = None
            stored_name = ""
            kind = _text(row.get("kind"))
            if kind == "manual" and sai_receipt_drafts.MANUAL_AUTOSAVE.is_file():
                source = sai_receipt_drafts.MANUAL_AUTOSAVE
                stored_name = "manual.json"
            else:
                candidate = Path(_text(row.get("package_path"))) if row.get("package_path") else None
                if candidate and candidate.is_file():
                    source = candidate
                    stored_name = "receipt.sai"
            file_info = None
            if source is not None:
                checksum = _sha256(source)
                file_info = {"name": stored_name, "size": source.stat().st_size, "sha256": checksum}
            payload = {
                "schema_version": SCHEMA_VERSION,
                "draft_id": safe_id,
                "source_device_id": settings.device_id,
                "source_device_name": settings.device_name,
                "updated_at": updated_at,
                "deleted": False,
                "metadata": _draft_public_metadata(row),
                "file": file_info,
            }
        else:
            continue

        payload["signature"] = _draft_signature(payload)
        target = device_root / safe_id
        existing = _read_json(target / "manifest.json", {}) or {}
        if _text(existing.get("signature")) == payload["signature"]:
            continue
        file_info = payload.get("file")
        if isinstance(file_info, dict) and row is not None:
            kind = _text(row.get("kind"))
            source = (
                sai_receipt_drafts.MANUAL_AUTOSAVE
                if kind == "manual"
                else Path(_text(row.get("package_path")))
            )
            _copy_if_changed(source, target / _text(file_info.get("name")), _text(file_info.get("sha256")))
        payload["published_at"] = _now()
        _atomic_json(target / "manifest.json", payload)  # manifest last
        published += 1
    return published


def _revision_key(
    updated_at: Any,
    source_device_id: Any,
    signature: Any,
    *,
    deleted: bool = False,
) -> tuple[str, int, str, str]:
    # Draft timestamps are ISO-like and use the same sortable year-first form.
    # Source/signature make simultaneous whole-second edits deterministic.
    return (_text(updated_at).replace(" ", "T"), 1 if deleted else 0, _text(source_device_id), _text(signature))


def _local_draft_revision(draft_id: str, settings: SyncSettings) -> tuple[str, int, str, str]:
    tombstone = _draft_tombstones().get(draft_id)
    if tombstone:
        return _revision_key(tombstone, settings.device_id, "deleted", deleted=True)
    row = sai_receipt_drafts.get(draft_id) or {}
    return _revision_key(
        row.get("updated_at"),
        row.get("_sync_source_device_id") or settings.device_id,
        row.get("_sync_signature"),
    )


def _write_draft_tombstone(draft_id: str, updated_at: str) -> None:
    tombstone_path = sai_receipt_drafts.DRAFTS_DIR / "_deleted.json"
    payload = _read_json(tombstone_path, {}) or {}
    rows = payload.get("drafts") if isinstance(payload, dict) else {}
    rows = dict(rows or {})
    rows[draft_id] = updated_at
    _atomic_json(tombstone_path, {"drafts": dict(sorted(rows.items()))})


def _clear_draft_tombstone(draft_id: str) -> None:
    tombstone_path = sai_receipt_drafts.DRAFTS_DIR / "_deleted.json"
    payload = _read_json(tombstone_path, {}) or {}
    rows = dict(payload.get("drafts") or {}) if isinstance(payload, dict) else {}
    if draft_id in rows:
        rows.pop(draft_id, None)
        _atomic_json(tombstone_path, {"drafts": dict(sorted(rows.items()))})


def _import_draft(settings: SyncSettings, manifest_path: Path, manifest: Mapping[str, Any]) -> bool:
    draft_id = _draft_id(manifest.get("draft_id"))
    if not draft_id:
        return False
    updated_at = _text(manifest.get("updated_at"))
    remote_key = _revision_key(
        updated_at,
        manifest.get("source_device_id"),
        manifest.get("signature"),
        deleted=bool(manifest.get("deleted")),
    )
    if remote_key <= _local_draft_revision(draft_id, settings):
        return False

    folder = sai_receipt_drafts.DRAFTS_DIR / draft_id
    if bool(manifest.get("deleted")):
        if folder.exists():
            shutil.rmtree(folder, ignore_errors=True)
        if draft_id == "manual_current":
            sai_receipt_drafts.MANUAL_AUTOSAVE.unlink(missing_ok=True)
        _write_draft_tombstone(draft_id, updated_at or _now())
        return True

    metadata = manifest.get("metadata") if isinstance(manifest.get("metadata"), dict) else {}
    metadata = dict(metadata)
    metadata["id"] = draft_id
    metadata["updated_at"] = updated_at or _now()
    metadata["_sync_source_device_id"] = _text(manifest.get("source_device_id"))
    metadata["_sync_revision"] = metadata["updated_at"]
    metadata["_sync_signature"] = _text(manifest.get("signature"))
    file_info = manifest.get("file") if isinstance(manifest.get("file"), dict) else None
    if file_info:
        name = _text(file_info.get("name"))
        if name not in {"receipt.sai", "manual.json"}:
            raise RuntimeError("Черновик содержит неизвестный тип файла.")
        source = manifest_path.parent / name
        checksum = _text(file_info.get("sha256"))
        if not source.is_file() or (checksum and _sha256(source) != checksum):
            raise RuntimeError(f"Файл общего черновика повреждён: {draft_id}")
        if name == "manual.json":
            target = sai_receipt_drafts.MANUAL_AUTOSAVE
            metadata["manual_payload_path"] = str(target)
        else:
            target = folder / "receipt.sai"
            metadata["package_path"] = str(target)
        _copy_if_changed(source, target, checksum)
    elif _text(metadata.get("status")) == "active":
        # Never expose an active draft that cannot actually be opened.
        return False
    folder.mkdir(parents=True, exist_ok=True)
    _clear_draft_tombstone(draft_id)
    _atomic_json(folder / "draft.json", metadata)
    return True


def _import_drafts(settings: SyncSettings) -> int:
    """Import the newest foreign revision for every logical draft."""
    newest: Dict[str, tuple[tuple[str, int, str, str], Path, Dict[str, Any]]] = {}
    for manifest_path in (settings.root / "drafts").glob("*/*/manifest.json"):
        manifest = _read_json(manifest_path, {}) or {}
        if not isinstance(manifest, dict) or _text(manifest.get("source_device_id")) == settings.device_id:
            continue
        draft_id = _draft_id(manifest.get("draft_id"))
        if not draft_id:
            continue
        key = _revision_key(
            manifest.get("updated_at"),
            manifest.get("source_device_id"),
            manifest.get("signature"),
            deleted=bool(manifest.get("deleted")),
        )
        if draft_id not in newest or key > newest[draft_id][0]:
            newest[draft_id] = (key, manifest_path, manifest)
    imported = 0
    for _, manifest_path, manifest in newest.values():
        if _import_draft(settings, manifest_path, manifest):
            imported += 1
    return imported


def _available_update(settings: SyncSettings, current_version: str) -> str:
    latest = _read_json(settings.root / "updates" / "latest.json", {}) or {}
    version = _text(latest.get("version"))
    package = settings.root / "updates" / _text(latest.get("package")) if latest.get("package") else None
    if version and _version_key(version) > _version_key(current_version) and package and package.exists():
        return version
    return ""


def _version_key(value: Any) -> tuple[tuple[int, ...], int, int, int]:
    """Order stable, legacy-letter and development SAI versions."""
    text = _text(value).lower().lstrip("v")
    match = re.fullmatch(r"(\d+(?:\.\d+)*)([a-z]*)(?:[-._]?dev(?:[-._]?(\d+))?)?", text)
    if not match:
        return ((0,), 0, 0, 0)
    numbers = tuple(int(part) for part in match.group(1).split("."))
    suffix_value = 0
    for char in match.group(2):
        suffix_value = suffix_value * 26 + (ord(char) - ord("a") + 1)
    is_development = "dev" in text
    development_revision = int(match.group(3) or 0)
    # For the same candidate number a verified stable release is newer than
    # every development revision and can therefore replace it via sync.
    return numbers, suffix_value, 0 if is_development else 1, development_revision


def update_manifest(settings: SyncSettings) -> Dict[str, Any]:
    value = _read_json(settings.root / "updates" / "latest.json", {}) or {}
    return value if isinstance(value, dict) else {}


def update_package(settings: SyncSettings) -> Optional[Path]:
    manifest = update_manifest(settings)
    raw = _text(manifest.get("package"))
    if not raw:
        return None
    relative = _safe_relative(raw)
    path = settings.root / "updates" / relative
    if not path.is_file():
        return None
    expected = _text(manifest.get("sha256"))
    if expected and _sha256(path) != expected:
        raise RuntimeError("Контрольная сумма обновления SAI не совпадает.")
    return path


def sync_once(settings: SyncSettings, current_version: str = "") -> SyncReport:
    report = SyncReport(completed_at=_now())
    if not settings.valid:
        report.ok = False
        report.message = "Синхронизация организации не подключена."
        return report
    try:
        initialize_organization(settings)
        state = _read_json(STATE_FILE, {}) or {}
        for run in _local_receipts():
            if _publish_receipt(settings, run, state):
                report.exported_receipts += 1
        _atomic_json(STATE_FILE, state)
        report.published_drafts = _publish_drafts(settings)
        for manifest in sorted((settings.root / "history").glob("*/manifest.json")):
            if _import_receipt(settings, manifest):
                report.imported_receipts += 1
        report.imported_drafts = _import_drafts(settings)
        report.published_staff_records, report.imported_staff_records = sai_staff.sync_shared(
            settings.root, settings.device_id,
        )
        report.available_version = _available_update(settings, current_version)
        report.message = (
            f"Синхронизировано: отправлено {report.exported_receipts}, "
            f"получено {report.imported_receipts}; черновики: "
            f"отправлено {report.published_drafts}, получено {report.imported_drafts}; "
            f"данные сотрудников: "
            f"отправлено {report.published_staff_records}, получено {report.imported_staff_records}."
        )
    except Exception as exc:
        report.ok = False
        report.message = str(exc)
    report.completed_at = _now()
    return report
