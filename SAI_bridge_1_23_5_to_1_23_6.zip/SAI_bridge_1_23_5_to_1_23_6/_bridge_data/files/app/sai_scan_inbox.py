#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Discover the newest contiguous batch of scanner-created invoice files."""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path


SCAN_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".webp", ".gif"}
DEFAULT_MAX_GAP_SECONDS = 10 * 60
DEFAULT_MAX_AGE_SECONDS = 24 * 60 * 60
DEFAULT_STABLE_SECONDS = 2.0


@dataclass(frozen=True)
class ScanCandidate:
    path: Path
    timestamp_ns: int
    size: int


def _candidate(path: Path) -> ScanCandidate | None:
    try:
        stat = path.stat()
    except OSError:
        return None
    if not path.is_file() or path.suffix.casefold() not in SCAN_EXTENSIONS or stat.st_size <= 0:
        return None
    # On Windows st_ctime is the time the file appeared in this folder.  mtime
    # additionally protects against selecting a PDF which the scanner is still
    # writing.
    timestamp_ns = max(int(stat.st_ctime_ns), int(stat.st_mtime_ns))
    return ScanCandidate(path.resolve(), timestamp_ns, int(stat.st_size))


def latest_scan_batch(
    folder: Path,
    *,
    newer_than_ns: int = 0,
    max_gap_seconds: float = DEFAULT_MAX_GAP_SECONDS,
    max_age_seconds: float = DEFAULT_MAX_AGE_SECONDS,
    stable_seconds: float = DEFAULT_STABLE_SECONDS,
    now_ns: int | None = None,
) -> list[ScanCandidate]:
    """Return the newest chronological batch whose adjacent gaps are <= limit."""
    root = Path(folder).expanduser()
    if not root.is_dir():
        return []
    current_ns = int(now_ns if now_ns is not None else time.time_ns())
    stable_ns = max(0, int(float(stable_seconds) * 1_000_000_000))
    age_ns = max(0, int(float(max_age_seconds) * 1_000_000_000))
    candidates: list[ScanCandidate] = []
    try:
        children = list(root.iterdir())
    except OSError:
        return []
    for path in children:
        item = _candidate(path)
        if item is None or item.timestamp_ns <= int(newer_than_ns):
            continue
        age = current_ns - item.timestamp_ns
        if age < stable_ns or age > age_ns:
            continue
        candidates.append(item)
    if not candidates:
        return []
    return newest_contiguous_batch(candidates, max_gap_seconds=max_gap_seconds)


def newest_contiguous_batch(
    candidates: list[ScanCandidate],
    *,
    max_gap_seconds: float = DEFAULT_MAX_GAP_SECONDS,
) -> list[ScanCandidate]:
    """Group already discovered candidates, keeping only the newest series."""
    if not candidates:
        return []
    ordered = sorted(
        candidates,
        key=lambda item: (item.timestamp_ns, item.path.name.casefold()),
        reverse=True,
    )
    newest_group = [ordered[0]]
    max_gap_ns = max(0, int(float(max_gap_seconds) * 1_000_000_000))
    for item in ordered[1:]:
        previous = newest_group[-1]
        if previous.timestamp_ns - item.timestamp_ns > max_gap_ns:
            break
        newest_group.append(item)
    newest_group.reverse()
    return newest_group


def batch_marker(batch: list[ScanCandidate]) -> int:
    return max((item.timestamp_ns for item in batch), default=0)


__all__ = [
    "ScanCandidate", "SCAN_EXTENSIONS", "DEFAULT_MAX_GAP_SECONDS",
    "latest_scan_batch", "newest_contiguous_batch", "batch_marker",
]
