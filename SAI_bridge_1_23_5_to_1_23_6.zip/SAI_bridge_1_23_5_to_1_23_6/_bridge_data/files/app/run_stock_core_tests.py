#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import sqlite3
import tempfile
from decimal import Decimal
from pathlib import Path

from sai_core_v2.migrations import run_migrations
from sai_core_v2.stock import STOCK_MIGRATIONS, StockMovement, stable_product_id
from sai_stock import StockService


def main() -> None:
    con = sqlite3.connect(":memory:")
    con.execute("PRAGMA foreign_keys=ON")
    con.executescript("""
        CREATE TABLE products(
            sigma_id TEXT PRIMARY KEY, company_key TEXT NOT NULL,
            sell_point_id TEXT NOT NULL, name TEXT
        );
    """)
    con.executemany(
        "INSERT INTO products VALUES (?, ?, ?, ?)",
        [("p-1", "shop", "point", "Milk"), ("p-2", "shop", "point", "Bread")],
    )
    assert run_migrations(con, STOCK_MIGRATIONS) == [4]
    assert run_migrations(con, STOCK_MIGRATIONS) == []
    assert con.execute("SELECT COUNT(*) FROM product_identities").fetchone()[0] == 2
    service = StockService(con)
    assert con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='product_events'"
    ).fetchone()
    assert con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='sigma_stock_current'"
    ).fetchone()
    assert service.prepare_sigma_catalog("shop") == 2
    assert service.prepare_sigma_catalog("shop") == 2
    product_id = service.sigma_product_id("shop", "p-1")
    assert product_id == stable_product_id("sigma", "shop", "p-1")
    assert con.execute("SELECT COUNT(*) FROM product_identities").fetchone()[0] == 2
    service.ensure_location("main", "Main shop")

    receipt = StockMovement("receipt:42:p-1", product_id, "main", "receipt", Decimal("10"), "sai", "42")
    first_id, created = service.post(receipt)
    assert created
    repeated_id, created = service.post(receipt)
    assert not created and repeated_id == first_id
    service.post(StockMovement("sale:77:p-1", product_id, "main", "sale", Decimal("-2.5"), "pos", "77"))
    assert service.balance(product_id, "main") == Decimal("7.5")

    try:
        service.post(StockMovement("bad", product_id, "main", "receipt", Decimal("0"), "test"))
    except ValueError:
        pass
    else:
        raise AssertionError("zero movement must be rejected")

    try:
        con.execute("UPDATE stock_movements SET note='rewritten'")
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("recorded movement must be immutable")
    try:
        con.execute("DELETE FROM stock_movements WHERE movement_id=?", (first_id,))
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError("recorded movement must not be deleted")

    # Exercise the real application initializer, not only the isolated domain
    # migration. This catches ordering errors between the legacy baseline and
    # the versioned migration ledger.
    import sai_db
    with tempfile.TemporaryDirectory(prefix="sai_stock_db_") as temporary:
        sai_db.DB_PATH = Path(temporary) / "sai.db"
        sai_db.init_db()
        application_db = sai_db.connect()
        try:
            versions = dict(application_db.execute("SELECT version, name FROM schema_migrations"))
            assert versions[3] == "legacy_sai_schema_baseline"
            assert versions[4] == "catalog_identity_and_stock_ledger"
            tables = {row[0] for row in application_db.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )}
            assert {"product_identities", "stock_locations", "stock_movements"} <= tables
        finally:
            application_db.close()
    print("SAI stock core tests: OK")


if __name__ == "__main__":
    main()
