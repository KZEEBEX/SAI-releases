#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for product-name workflow v1.22.7au."""
from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
APP = ROOT / "app"
sys.path.insert(0, str(APP))

import sai_openai_invoice as ai
import sai_product_names as names
from sai_version import VERSION

assert VERSION == "1.22.7au", VERSION

document = {
        "supplier": "TEST",
        "invoice_date": "2026-07-19",
        "invoice_number": "1",
        "document_total": 100.0,
        "items": [{
            "source_row": 1,
            "source_page": 1,
            "raw_name": "1-2.SALE роз. ОУ 2мест. 16А земля бел. E1M SZ1",
            "name": "1-2.SALE роз. ОУ 2мест. 16А земля бел. E1M SZ1",
            "quantity": 1,
            "unit": "шт",
            "purchase_price": 100,
            "line_total": 100,
            "article": "SZ1",
            "barcodes": [],
            "note": "",
        }],
    "warnings": [],
}
response = {
    "output": [{
        "type": "message",
        "content": [{"type": "output_text", "text": json.dumps(document, ensure_ascii=False)}],
    }],
    "usage": {"input_tokens": 100, "output_tokens": 50, "total_tokens": 150},
}
result = ai.response_to_convert_result(response, [APP / "dummy.pdf"], markup_percent=60)
assert len(result.items) == 1
item = result.items[0]
assert item.raw_name.startswith("1-2.SALE")
assert item.name == "РОЗЕТКА ОУ 2 ГН 16 А С/З БЕЛАЯ E1M SZ1", item.name
assert item.name_normalizer_version == names.RULES_VERSION
assert any("ОТКРЫТОЙ УСТАНОВКИ" in alias for alias in item.name_search_aliases)

ui_path = APP / "sai_pyside_preview.py"
ui_text = ui_path.read_text(encoding="utf-8-sig")
ui_tree = ast.parse(ui_text, filename=str(ui_path))
classes = {node.name: node for node in ui_tree.body if isinstance(node, ast.ClassDef)}
assert "ProductNameReviewDialog" in classes
converter = classes.get("ConverterPage")
assert converter is not None
methods = {node.name for node in converter.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
assert {"review_product_names", "product_name_item_changed", "populate_preview"} <= methods
assert 'QPushButton("Проверить названия")' in ui_text
assert '"Дословно в документе"' in ui_text
assert 'sai_product_names.normalize_items(self.result.items)' in ui_text
assert 'self.table.itemChanged.connect(self.product_name_item_changed)' in ui_text

package_text = (APP / "sai_package.py").read_text(encoding="utf-8-sig")
for token in ("name_source", "name_normalization_changes", "name_search_aliases", "name_normalizer_version"):
    assert token in package_text

print("SAI patch v1.22.7au tests: OK")
