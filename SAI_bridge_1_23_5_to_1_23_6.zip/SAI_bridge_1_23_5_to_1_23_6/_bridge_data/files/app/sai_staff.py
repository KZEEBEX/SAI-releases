#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Employees, schedules, time tracking and reimbursable shop expenses.

Records use stable UUIDs and last-write-wins timestamps, so the same small data
model can be synchronized through an ordinary shared folder without copying a
live SQLite database between computers.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import uuid
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

import sai_db


RECORD_TABLES = {
    "employees": "staff_employees",
    "shifts": "staff_shifts",
    "time_entries": "staff_time_entries",
    "expenses": "staff_expenses",
}


def now_text() -> str:
    return dt.datetime.now().astimezone().replace(microsecond=0).isoformat()


def _id() -> str:
    return uuid.uuid4().hex


def _text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def init_staff_schema() -> None:
    sai_db.init_db()
    with closing(sai_db.connect()) as con, con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS staff_employees (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT '',
                pay_type TEXT NOT NULL DEFAULT 'daily',
                pay_rate REAL NOT NULL DEFAULT 2000,
                sort_order INTEGER NOT NULL DEFAULT 0,
                active INTEGER NOT NULL DEFAULT 1,
                deleted INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                source_device_id TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS staff_shifts (
                id TEXT PRIMARY KEY,
                employee_id TEXT NOT NULL,
                work_date TEXT NOT NULL,
                start_time TEXT NOT NULL DEFAULT '09:00',
                end_time TEXT NOT NULL DEFAULT '18:00',
                note TEXT NOT NULL DEFAULT '',
                deleted INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                source_device_id TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(employee_id) REFERENCES staff_employees(id)
            );
            CREATE INDEX IF NOT EXISTS idx_staff_shifts_date ON staff_shifts(work_date, employee_id);
            CREATE TABLE IF NOT EXISTS staff_time_entries (
                id TEXT PRIMARY KEY,
                employee_id TEXT NOT NULL,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                note TEXT NOT NULL DEFAULT '',
                deleted INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                source_device_id TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(employee_id) REFERENCES staff_employees(id)
            );
            CREATE INDEX IF NOT EXISTS idx_staff_time_employee ON staff_time_entries(employee_id, started_at);
            CREATE TABLE IF NOT EXISTS staff_expenses (
                id TEXT PRIMARY KEY,
                employee_id TEXT NOT NULL,
                purchased_at TEXT NOT NULL,
                name TEXT NOT NULL,
                quantity REAL NOT NULL DEFAULT 1,
                unit_price REAL NOT NULL DEFAULT 0,
                note TEXT NOT NULL DEFAULT '',
                reimbursed INTEGER NOT NULL DEFAULT 0,
                deleted INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL,
                source_device_id TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(employee_id) REFERENCES staff_employees(id)
            );
            CREATE INDEX IF NOT EXISTS idx_staff_expenses_employee ON staff_expenses(employee_id, purchased_at);
            """
        )
        columns = {str(row[1]) for row in con.execute("PRAGMA table_info(staff_employees)").fetchall()}
        if "sort_order" not in columns:
            con.execute("ALTER TABLE staff_employees ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0")


def _rows(query: str, params: Iterable[Any] = ()) -> list[dict[str, Any]]:
    init_staff_schema()
    with closing(sai_db.connect()) as con:
        return [dict(row) for row in con.execute(query, tuple(params)).fetchall()]


def employees(*, include_inactive: bool = False) -> list[dict[str, Any]]:
    where = "deleted=0" if include_inactive else "deleted=0 AND active=1"
    return _rows(f"SELECT * FROM staff_employees WHERE {where} ORDER BY active DESC, sort_order, name COLLATE NOCASE")


def save_employee(name: str, role: str, pay_type: str, pay_rate: float, *, employee_id: str = "", active: bool = True, device_id: str = "", sort_order: int | None = None) -> str:
    name = _text(name)
    if not name:
        raise ValueError("Укажите имя сотрудника.")
    pay_type = "hourly" if pay_type == "hourly" else "daily"
    init_staff_schema()
    with closing(sai_db.connect()) as con, con:
        if sort_order is None:
            current = con.execute("SELECT sort_order FROM staff_employees WHERE id=?", (employee_id,)).fetchone() if employee_id else None
            sort_order = int(current[0]) if current else int(con.execute("SELECT COALESCE(MAX(sort_order),-1)+1 FROM staff_employees WHERE deleted=0").fetchone()[0])
        employee_id = employee_id or _id()
        con.execute(
            """INSERT INTO staff_employees(id,name,role,pay_type,pay_rate,sort_order,active,deleted,updated_at,source_device_id)
               VALUES(?,?,?,?,?,?,?,0,?,?)
               ON CONFLICT(id) DO UPDATE SET name=excluded.name,role=excluded.role,pay_type=excluded.pay_type,
               pay_rate=excluded.pay_rate,active=excluded.active,deleted=0,updated_at=excluded.updated_at,
               source_device_id=excluded.source_device_id""",
            (employee_id, name, _text(role), pay_type, max(0.0, float(pay_rate)), int(sort_order), int(active), now_text(), device_id),
        )
    return employee_id


def reorder_employee(employee_id: str, new_index: int, *, device_id: str = "") -> None:
    """Move an employee in the shared schedule order."""
    people = employees()
    ids = [str(row["id"]) for row in people]
    if employee_id not in ids:
        return
    ids.remove(employee_id)
    ids.insert(max(0, min(int(new_index), len(ids))), employee_id)
    timestamp = now_text()
    with closing(sai_db.connect()) as con, con:
        for index, current_id in enumerate(ids):
            con.execute(
                "UPDATE staff_employees SET sort_order=?,updated_at=?,source_device_id=? WHERE id=?",
                (index, timestamp, device_id, current_id),
            )


def save_shift(employee_id: str, work_date: str, start_time: str, end_time: str, note: str = "", *, shift_id: str = "", device_id: str = "") -> str:
    if not employee_id or not work_date:
        raise ValueError("Выберите сотрудника и дату смены.")
    shift_id = shift_id or _id()
    init_staff_schema()
    with closing(sai_db.connect()) as con, con:
        con.execute(
            """INSERT INTO staff_shifts(id,employee_id,work_date,start_time,end_time,note,deleted,updated_at,source_device_id)
               VALUES(?,?,?,?,?,?,0,?,?)
               ON CONFLICT(id) DO UPDATE SET employee_id=excluded.employee_id,work_date=excluded.work_date,
               start_time=excluded.start_time,end_time=excluded.end_time,note=excluded.note,deleted=0,
               updated_at=excluded.updated_at,source_device_id=excluded.source_device_id""",
            (shift_id, employee_id, work_date, start_time, end_time, _text(note), now_text(), device_id),
        )
    return shift_id


def delete_record(kind: str, record_id: str, *, device_id: str = "") -> None:
    table = RECORD_TABLES[kind]
    init_staff_schema()
    with closing(sai_db.connect()) as con, con:
        con.execute(f"UPDATE {table} SET deleted=1,updated_at=?,source_device_id=? WHERE id=?", (now_text(), device_id, record_id))


def shifts_between(start_date: str, end_date: str) -> list[dict[str, Any]]:
    return _rows(
        """SELECT s.*,e.name employee_name,e.pay_type,e.pay_rate FROM staff_shifts s
           JOIN staff_employees e ON e.id=s.employee_id
           WHERE s.deleted=0 AND e.deleted=0 AND s.work_date BETWEEN ? AND ?
           ORDER BY e.name COLLATE NOCASE,s.work_date,s.start_time""",
        (start_date, end_date),
    )


def running_entry(employee_id: str = "") -> dict[str, Any] | None:
    query = "SELECT * FROM staff_time_entries WHERE deleted=0 AND ended_at IS NULL"
    params: tuple[Any, ...] = ()
    if employee_id:
        query += " AND employee_id=?"
        params = (employee_id,)
    query += " ORDER BY started_at DESC LIMIT 1"
    rows = _rows(query, params)
    return rows[0] if rows else None


def start_timer(employee_id: str, *, device_id: str = "") -> str:
    if running_entry(employee_id):
        raise ValueError("У этого сотрудника таймер уже запущен.")
    entry_id = _id(); timestamp = now_text(); init_staff_schema()
    with closing(sai_db.connect()) as con, con:
        con.execute(
            "INSERT INTO staff_time_entries(id,employee_id,started_at,ended_at,note,deleted,updated_at,source_device_id) VALUES(?,?,?,NULL,'',0,?,?)",
            (entry_id, employee_id, timestamp, timestamp, device_id),
        )
    return entry_id


def stop_timer(employee_id: str, *, device_id: str = "") -> float:
    entry = running_entry(employee_id)
    if not entry:
        raise ValueError("Таймер не запущен.")
    ended = dt.datetime.now().astimezone().replace(microsecond=0)
    started = dt.datetime.fromisoformat(entry["started_at"])
    hours = max(0.0, (ended - started).total_seconds() / 3600)
    with closing(sai_db.connect()) as con, con:
        con.execute("UPDATE staff_time_entries SET ended_at=?,updated_at=?,source_device_id=? WHERE id=?", (ended.isoformat(), ended.isoformat(), device_id, entry["id"]))
    return hours


def add_expense(employee_id: str, name: str, quantity: float, unit_price: float, note: str = "", *, device_id: str = "") -> str:
    if not employee_id or not _text(name):
        raise ValueError("Выберите сотрудника и укажите покупку.")
    expense_id = _id(); timestamp = now_text(); init_staff_schema()
    with closing(sai_db.connect()) as con, con:
        con.execute(
            """INSERT INTO staff_expenses(id,employee_id,purchased_at,name,quantity,unit_price,note,reimbursed,deleted,updated_at,source_device_id)
               VALUES(?,?,?,?,?,?,?,0,0,?,?)""",
            (expense_id, employee_id, timestamp, _text(name), max(0.0, float(quantity)), max(0.0, float(unit_price)), _text(note), timestamp, device_id),
        )
    return expense_id


def set_expense_reimbursed(expense_id: str, reimbursed: bool, *, device_id: str = "") -> None:
    init_staff_schema()
    with closing(sai_db.connect()) as con, con:
        con.execute("UPDATE staff_expenses SET reimbursed=?,updated_at=?,source_device_id=? WHERE id=?", (int(reimbursed), now_text(), device_id, expense_id))


def time_entries_between(start_date: str, end_date: str) -> list[dict[str, Any]]:
    return _rows(
        """SELECT t.*,e.name employee_name,e.pay_type,e.pay_rate FROM staff_time_entries t
           JOIN staff_employees e ON e.id=t.employee_id
           WHERE t.deleted=0 AND e.deleted=0 AND substr(t.started_at,1,10) BETWEEN ? AND ?
           ORDER BY t.started_at DESC""", (start_date, end_date),
    )


def expenses_between(start_date: str, end_date: str) -> list[dict[str, Any]]:
    return _rows(
        """SELECT x.*,e.name employee_name FROM staff_expenses x JOIN staff_employees e ON e.id=x.employee_id
           WHERE x.deleted=0 AND e.deleted=0 AND substr(x.purchased_at,1,10) BETWEEN ? AND ?
           ORDER BY x.purchased_at DESC""", (start_date, end_date),
    )


@dataclass(frozen=True)
class PayrollLine:
    employee_id: str
    name: str
    pay_type: str
    rate: float
    days: int
    hours: float
    salary: float
    expenses: float
    total: float


def payroll(start_date: str, end_date: str) -> list[PayrollLine]:
    people = employees(include_inactive=True)
    shifts = shifts_between(start_date, end_date)
    entries = time_entries_between(start_date, end_date)
    expenses = expenses_between(start_date, end_date)
    now = dt.datetime.now().astimezone()
    result = []
    for person in people:
        person_shifts = [row for row in shifts if row["employee_id"] == person["id"]]
        person_entries = [row for row in entries if row["employee_id"] == person["id"]]
        hours = 0.0
        for row in person_entries:
            start = dt.datetime.fromisoformat(row["started_at"])
            end = dt.datetime.fromisoformat(row["ended_at"]) if row.get("ended_at") else now
            hours += max(0.0, (end - start).total_seconds() / 3600)
        days = len({row["work_date"] for row in person_shifts})
        rate = float(person["pay_rate"] or 0)
        salary = rate * hours if person["pay_type"] == "hourly" else rate * days
        refund = sum(float(row["quantity"] or 0) * float(row["unit_price"] or 0) for row in expenses if row["employee_id"] == person["id"] and not row["reimbursed"])
        result.append(PayrollLine(person["id"], person["name"], person["pay_type"], rate, days, hours, salary, refund, salary + refund))
    return result


def _atomic_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(dict(value), ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def sync_shared(root: Path, device_id: str) -> tuple[int, int]:
    """Publish local records and import newer records from every other PC."""
    if not root.parts:
        return 0, 0
    base = root / "staff" / "records"
    init_staff_schema(); published = imported = 0
    with closing(sai_db.connect()) as con, con:
        for kind, table in RECORD_TABLES.items():
            folder = base / kind; folder.mkdir(parents=True, exist_ok=True)
            for row in con.execute(f"SELECT * FROM {table}").fetchall():
                payload = dict(row)
                target = folder / f"{payload['id']}.json"
                current = {}
                try: current = json.loads(target.read_text(encoding="utf-8-sig"))
                except Exception: pass
                if _text(payload.get("updated_at")) > _text(current.get("updated_at")):
                    _atomic_json(target, payload); published += 1
            columns = [str(row[1]) for row in con.execute(f"PRAGMA table_info({table})").fetchall()]
            for path in folder.glob("*.json"):
                try: payload = json.loads(path.read_text(encoding="utf-8-sig"))
                except Exception: continue
                if not isinstance(payload, dict) or not payload.get("id"):
                    continue
                local = con.execute(f"SELECT updated_at FROM {table} WHERE id=?", (payload["id"],)).fetchone()
                if local and _text(local[0]) >= _text(payload.get("updated_at")):
                    continue
                values = [0 if column == "sort_order" and payload.get(column) is None else payload.get(column) for column in columns]
                placeholders = ",".join("?" for _ in columns)
                updates = ",".join(f"{column}=excluded.{column}" for column in columns if column != "id")
                con.execute(f"INSERT INTO {table}({','.join(columns)}) VALUES({placeholders}) ON CONFLICT(id) DO UPDATE SET {updates}", values)
                imported += 1
    return published, imported
