#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression tests for the free-receipt catalog/barcode refactor."""
from __future__ import annotations

import ast
import json
import sqlite3
import tempfile
import time
from pathlib import Path

from sai_core_v2.free_receipt import (
    barcode_digits,
    category_id_from_raw,
    category_name_from_raw,
    ean_checksum,
    highest_internal_counter,
    internal_barcode,
    internal_barcode_counter,
    is_barcode_like_query,
    merge_barcodes,
    next_internal_barcode,
    normalize_markup,
    normalize_unit,
    price_forecast,
    product_search_score,
)
from sai_free_receipt import FreeReceiptCatalogService


APP_DIR = Path(__file__).resolve().parent


def assert_true(value, message: str) -> None:
    if not value:
        raise AssertionError(message)


def build_catalog_db(path: Path) -> None:
    connection = sqlite3.connect(str(path))
    connection.executescript(
        """
        CREATE TABLE products (
            sigma_id TEXT PRIMARY KEY,
            name TEXT,
            vendor_code TEXT,
            barcodes_json TEXT,
            raw_json TEXT
        );
        CREATE TABLE barcodes (product_id TEXT, barcode TEXT);
        CREATE TABLE price_history (
            product_id TEXT,
            final_selling_price REAL,
            sigma_existing_selling_price REAL,
            incoming_selling_price REAL,
            created_at TEXT
        );
        CREATE TABLE receipt_items (category TEXT);
        """
    )
    connection.execute(
        "INSERT INTO products VALUES (?,?,?,?,?)",
        (
            "p-1",
            "УГОЛОК МЕБЕЛЬНЫЙ 40 ММ",
            "ART-40",
            json.dumps(["4600000000001"], ensure_ascii=False),
            json.dumps({"unitName": "шт.", "category": {"id": "cat-1", "name": "Крепёж"}, "sellingPrice": 125.5}, ensure_ascii=False),
        ),
    )
    connection.execute(
        "INSERT INTO products VALUES (?,?,?,?,?)",
        (
            "p-2",
            "ШЛАНГ ПОЛИВОЧНЫЙ 20 М",
            "HOSE-20",
            "[]",
            json.dumps({"unitName": "м", "categoryId": "cat-2"}, ensure_ascii=False),
        ),
    )
    connection.execute("INSERT INTO barcodes VALUES (?,?)", ("p-2", "4690000000002"))
    existing_internal = internal_barcode("77", 75)
    connection.execute(
        "INSERT INTO products VALUES (?,?,?,?,?)",
        (
            "p-internal",
            "ТОВАР С ВНУТРЕННИМ ШК",
            "INTERNAL-75",
            json.dumps([existing_internal]),
            json.dumps({"unitName": "шт.", "sellingPrice": 10}),
        ),
    )
    connection.execute("INSERT INTO barcodes VALUES (?,?)", ("p-internal", existing_internal))
    connection.execute(
        "INSERT INTO price_history VALUES (?,?,?,?,?)",
        ("p-2", 0, 350, 0, "2026-07-22 12:00:00"),
    )
    connection.execute("INSERT INTO receipt_items VALUES (?)", ("Крепёж",))
    connection.execute("INSERT INTO receipt_items VALUES (?)", ("Крепёж",))
    connection.commit()
    connection.close()


def test_pure_rules() -> None:
    assert_true(is_barcode_like_query("4600000000001"), "EAN query not recognized")
    assert_true(not is_barcode_like_query("уголок"), "name recognized as barcode")
    assert_true(barcode_digits("46 00-01") == "460001", "barcode normalization")

    merged = merge_barcodes(["1", "2"], ["2, 3;4", "5"])
    assert_true(merged.barcodes == ("1", "2", "3", "4", "5"), "barcode merge order")
    limited = merge_barcodes([str(i) for i in range(8)], ["9"])
    assert_true(limited.limit_reached and limited.rejected == ("9",), "barcode limit")

    code, counter = next_internal_barcode("77", 1, {"7700000000019"})
    assert_true(counter >= 1 and len(code) == 13 and code.startswith("77"), "internal barcode shape")
    assert_true(int(code[-1]) == ean_checksum(code[:-1]), "internal barcode checksum")
    assert_true(internal_barcode_counter(internal_barcode("77", 75), "77") == 75, "counter extraction")
    valid_internal = internal_barcode("77", 75)
    invalid_internal = valid_internal[:-1] + str((int(valid_internal[-1]) + 1) % 10)
    assert_true(internal_barcode_counter(invalid_internal, "77") is None, "invalid checksum accepted")
    assert_true(
        internal_barcode_counter("7730716020803", "77") is None,
        "commercial EAN-13 was mistaken for an internal SAI barcode",
    )
    assert_true(highest_internal_counter([internal_barcode("77", 4), internal_barcode("77", 75)], "77") == 75, "highest counter")

    forecast = price_forecast("100", "60", 90)
    assert_true(forecast.uses_purchase and forecast.sale == 160.0, "price forecast")
    old = price_forecast("", "60", "125.50")
    assert_true(not old.uses_purchase and old.sale == 125.5, "old price fallback")
    assert_true(normalize_markup("-5", 60) == 0.0, "negative markup clamp")

    raw = {"product": {"category": {"id": "cat-1", "name": "Крепёж"}}}
    assert_true(category_name_from_raw(raw) == "Крепёж", "category name")
    assert_true(category_id_from_raw(raw) == "cat-1", "category id")
    assert_true(normalize_unit("кг.") == "кг", "unit normalization")

    score, exact = product_search_score(
        name="УГОЛОК МЕБЕЛЬНЫЙ 40 ММ", barcodes=["4600000000001"], query="угол меб", barcode_mode=False,
    )
    assert_true(score > 0 and not exact, "name search score")
    score, exact = product_search_score(
        name="УГОЛОК", barcodes=["4600000000001"], query="4600000000001", barcode_mode=True,
    )
    assert_true(score >= 220 and exact, "exact barcode score")


def test_service() -> None:
    with tempfile.TemporaryDirectory(prefix="sai_free_receipt_test_") as temp:
        root = Path(temp)
        db_path = root / "sai.db"
        generated_path = root / "generated.json"
        build_catalog_db(db_path)
        config = {
            "free_receipt_barcode_prefix": "77",
            "free_receipt_barcode_last_counter": 3_071_602_080,
        }

        def load_config():
            return dict(config)

        def save_config(patch):
            config.update(dict(patch or {}))
            return dict(config)

        service = FreeReceiptCatalogService(
            db_path=db_path,
            generated_path=generated_path,
            config_loader=load_config,
            config_saver=save_config,
        )
        categories = [{"id": "cat-1", "name": "Крепёж"}, {"id": "cat-2", "name": "Сад"}]

        immediate = service.find_exact_barcode("4690000000002", categories, non_blocking=True)
        assert_true(
            len(immediate) == 1 and immediate[0]["id"] == "p-2",
            "non-blocking exact lookup while full cache warms",
        )
        deadline = time.monotonic() + 5.0
        while service.catalog_loading and time.monotonic() < deadline:
            time.sleep(0.01)
        exact = service.find_exact_barcode("4690000000002", categories)
        assert_true(len(exact) == 1 and exact[0]["id"] == "p-2", "exact catalog lookup")
        assert_true(exact[0]["price"] == 350.0, "price-history fallback")
        assert_true(exact[0]["category"] == "Сад", "category id resolution")

        rows = service.search(
            name_query="угол меб", barcode_query="", barcode_mode=False,
            categories=categories, selected_category="Крепёж", limit=10,
        )
        assert_true(rows and rows[0]["id"] == "p-1", "name catalog lookup")
        assert_true(rows[0]["price"] == 125.5 and rows[0]["unit"] == "штука", "catalog mapping")

        barcode_rows = service.search(
            name_query="", barcode_query="4690000000002", barcode_mode=True,
            categories=categories, selected_category="", limit=10,
        )
        assert_true(len(barcode_rows) == 1 and barcode_rows[0]["exact_barcode_match"], "barcode catalog search")

        usage = service.category_usage_counts([{"category": "Крепёж"}])
        assert_true(usage.get("Крепёж") == 52, "category usage aggregation")

        first = service.generate_internal_barcode([], [])
        second = service.generate_internal_barcode([first.code], [])
        assert_true(first.counter == 76, "generator restarted below catalog maximum")
        assert_true(second.counter == 77, "generator did not advance monotonically")
        assert_true(config["free_receipt_barcode_prefix"] == "7700", "legacy prefix was not narrowed")
        assert_true(first.code != second.code, "generated barcode uniqueness")
        assert_true(config["free_receipt_barcode_last_counter"] == second.counter, "counter persistence")
        assert_true(first.code in service.load_generated_barcodes(), "generated history persistence")


def test_large_catalog_search_latency() -> None:
    with tempfile.TemporaryDirectory(prefix="sai_free_receipt_speed_") as temp:
        root = Path(temp)
        db_path = root / "sai.db"
        build_catalog_db(db_path)
        connection = sqlite3.connect(str(db_path))
        rows = [
            (
                f"speed-{index}",
                f"БЫСТРЫЙ ТОВАР {index:05d}",
                f"FAST-{index:05d}",
                json.dumps([f"460900000{index:04d}"]),
                json.dumps({"unitName": "шт.", "sellingPrice": index + 0.5}),
            )
            for index in range(6000)
        ]
        connection.executemany("INSERT INTO products VALUES (?,?,?,?,?)", rows)
        connection.commit()
        connection.close()

        service = FreeReceiptCatalogService(db_path=db_path, generated_path=root / "generated.json")
        service.warm_catalog_cache(background=False)
        assert_true(service.catalog_ready, "catalog cache did not become ready")

        started = time.perf_counter()
        by_name = service.search(
            name_query="быстр 5999", barcode_query="", barcode_mode=False, limit=10,
        )
        name_elapsed = time.perf_counter() - started
        assert_true(by_name and by_name[0]["id"] == "speed-5999", "cached name/article search")
        assert_true(name_elapsed < 0.35, f"cached name search too slow: {name_elapsed:.3f}s")

        started = time.perf_counter()
        by_barcode = service.search(
            name_query="", barcode_query="4609000005999", barcode_mode=True, limit=10,
        )
        barcode_elapsed = time.perf_counter() - started
        assert_true(by_barcode and by_barcode[0]["id"] == "speed-5999", "cached barcode search")
        assert_true(barcode_elapsed < 0.35, f"cached barcode search too slow: {barcode_elapsed:.3f}s")


def test_ui_boundary() -> None:
    path = APP_DIR / "sai_pyside_preview.py"
    source = path.read_text(encoding="utf-8-sig")
    tree = ast.parse(source)
    page = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "FreeReceiptPage")
    methods = {node.name: ast.get_source_segment(source, node) or "" for node in page.body if isinstance(node, ast.FunctionDef)}
    required = {
        "is_barcode_like_query": "free_is_barcode_like_query",
        "find_product_by_exact_barcode": "free_catalog_service.find_exact_barcode",
        "run_product_search": "free_catalog_service.search",
        "generate_barcode": "free_catalog_service.generate_internal_barcode",
        "category_usage_counts": "free_catalog_service.category_usage_counts",
        "resolve_price_equation": "_free_round_sale_from_purchase",
    }
    for method, marker in required.items():
        assert_true(marker in methods.get(method, ""), f"UI delegation missing: {method}")

    forbidden = ("SELECT sigma_id", "SELECT product_id FROM barcodes", "price_history WHERE product_id", "free_receipt_barcode_last_counter")
    guarded = "\n".join(methods.get(name, "") for name in (
        "find_product_by_exact_barcode", "run_product_search", "extract_product_price",
        "generate_barcode", "category_usage_counts",
    ))
    for marker in forbidden:
        assert_true(marker not in guarded, f"UI still owns catalog/barcode persistence: {marker}")
    assert_true("from sai_free_receipt import FreeReceiptCatalogService" in source, "service import missing")
    assert_true("self.free_catalog_service = shared_free_catalog_service()" in methods.get("__init__", ""), "shared service init missing")
    assert_true("warm_catalog_cache(background=True)" in methods.get("__init__", ""), "background cache warmup missing")
    assert_true("non_blocking=True" in methods.get("run_product_search", ""), "typing search may block UI")
    assert_true("non_blocking=True" in methods.get("find_product_by_exact_barcode", ""), "barcode lookup may block UI")
    assert_true("textChanged.connect(self.update_price_forecast)" not in source, "instant price forecast is still connected")
    assert_true("self.retail_price_edit" in source, "manual sale price field missing")


def main() -> int:
    test_pure_rules()
    test_service()
    test_large_catalog_search_latency()
    test_ui_boundary()
    print("Free receipt refactor tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
