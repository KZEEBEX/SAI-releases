#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Safe end-to-end rehearsal of both receipt routes.

The rehearsal uses production package, routing, semi-automatic and SIGMA apply
services. Only the external SIGMA endpoint is replaced with an in-memory double,
so no real draft or product can be changed.
"""
from __future__ import annotations

import os
from pathlib import Path
from types import SimpleNamespace
import tempfile

RUNTIME = Path(tempfile.mkdtemp(prefix="sai_receipt_full_cycle_"))
os.environ["SAI_USER_DATA_DIR"] = str(RUNTIME / "user_data")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import sai_package
from sai_api_first_apply import (
    catalog_selling_price,
    highest_known_price,
    preflight_verify_rows,
    process_rows,
)
from sai_app import load_sai_rows
from sai_core_v2.receipt_routing import ReceiptRouteKind, build_receipt_route_plan
from sai_core_v2.semi_auto_receipt_refactor import (
    collection_progress,
    find_barcode_owner,
    merge_barcodes,
    next_internal_barcode,
    parse_scan_barcodes,
)
from sai_semi_auto_receipt import SemiAutoReceiptService
from sai_waybill_creator import create_waybill


INITIAL_ROWS = [
    {
        "source_row": 1, "name": "ТОВАР С ИЗВЕСТНЫМ ШК", "qty": 2,
        "unit": "штука", "buy": 100, "sale": 160, "article": "A-1",
        "barcodes": ["4006381333931"], "comment": "",
    },
    {
        "source_row": 2, "name": "ТОВАР ДЛЯ СКАНИРОВАНИЯ", "qty": 3,
        "unit": "штука", "buy": 50, "sale": 90, "article": "A-2",
        "barcodes": [], "comment": "",
    },
    {
        "source_row": 3, "name": "ПОЛНЫЙ НЕДОВОЗ", "qty": 0,
        "unit": "штука", "buy": 25, "sale": 45, "article": "A-3",
        "barcodes": [], "comment": "",
    },
    {
        "source_row": 4, "name": "ТОВАР С НЕСКОЛЬКИМИ ШК", "qty": 1,
        "unit": "м", "buy": 30, "sale": 70, "article": "A-4",
        "barcodes": ["12345678", "87654321"], "comment": "",
    },
]


class FakeWaybillSigma:
    def __init__(self) -> None:
        self.created_payload = None

    def request(self, method, endpoint, payload=None):
        if method == "GET" and endpoint.endswith("/storehouses/waybill?storehouseType=DESTINATION"):
            return [{"id": "store-1", "name": "Основной склад", "isDefault": True}]
        if method == "GET" and endpoint == "/rest/1.1/account":
            return {"user": {"id": "user-1", "name": "Тест"}}
        if method == "POST" and endpoint.startswith("/waybills/generate-waybill-number"):
            return "TEST-001"
        if method == "POST" and endpoint == "/waybills":
            self.created_payload = dict(payload or {})
            return {"id": "waybill-1"}
        raise AssertionError((method, endpoint, payload))


class FakeApplySigma:
    def __init__(self, *, missing: set[str] | None = None, fail_once_on: str = "") -> None:
        self.missing = set(missing or ())
        self.fail_once_on = fail_once_on
        self.failed = False
        self.elements = {"product-4006381333931": "element-existing"}
        self.product_prices = {
            "product-4006381333931": 175,
            "product-5901234123457": 80,
            "product-12345678": 80,
        }
        self.values: dict[str, dict[str, float]] = {}
        self.writes: list[tuple] = []

    def find_product_by_barcode(self, barcode, storehouse_id, waybill_id=None):
        if barcode in self.missing:
            return None, []
        price = self.product_prices[f"product-{barcode}"]
        product = {"id": f"product-{barcode}", "sellingPrice": price}
        return product, [product]

    def get_existing_element(self, waybill_id, product_id):
        element = self.elements.get(product_id)
        return {
            "elementId": element,
            "sellingPrice": self.product_prices[product_id],
        } if element else {}

    def add_product_to_waybill(self, waybill_id, product_id):
        element = self.elements.setdefault(product_id, f"element-{len(self.elements) + 1}")
        self.writes.append(("add", product_id, element))
        return {"elementId": element}

    def _set(self, kind, element_id, value):
        if self.fail_once_on == kind and not self.failed:
            self.failed = True
            raise RuntimeError("simulated transient SIGMA failure")
        self.values.setdefault(element_id, {})[kind] = float(value)
        self.writes.append((kind, element_id, float(value)))

    def set_quantity(self, waybill_id, element_id, value):
        self._set("quantity", element_id, value)

    def set_buying_price(self, waybill_id, element_id, value):
        self._set("buying", element_id, value)

    def set_selling_price(self, waybill_id, element_id, value):
        self._set("selling", element_id, value)


def apply_args(*, apply: bool = False):
    return SimpleNamespace(
        waybill_id="waybill-1",
        apply=apply,
        price_policy="max",
        stop_on_error=True,
    )


def to_apply_rows(rows):
    result = []
    for row in rows:
        if float(row.get("qty") or 0) <= 0:
            continue
        result.append({
            "excel_row": int(row.get("excel_row") or len(result) + 2),
            "barcode": ", ".join(row.get("barcodes") or []),
            "name": row.get("name") or "",
            "quantity": float(row.get("qty") or 0),
            "buying_price": float(row.get("buy") or 0),
            "selling_price": float(row.get("sale") or 0),
        })
    return result


def rehearse_package_and_semi_auto(root: Path):
    service = SemiAutoReceiptService()
    package = service.save_rows(
        [dict(row) for row in INITIAL_ROWS],
        source_path=None,
        output_path=root / "tomorrow-rehearsal.sai",
    )
    _sheet, rows, _meta = sai_package.load_rows(package)
    plan = build_receipt_route_plan(package, rows)
    assert plan.kind is ReceiptRouteKind.SEMI_AUTO
    assert plan.missing_barcode_indices == (1,)

    assert parse_scan_barcodes("1234567").wait_more
    assert parse_scan_barcodes("12A34", force=True).error
    assert parse_scan_barcodes("4006381333930").warnings
    scan = parse_scan_barcodes("5901234123457")
    assert scan.accepted and scan.codes == ("5901234123457",)
    assert find_barcode_owner(rows, "4006381333931", current_index=1) == 0

    rows[1] = merge_barcodes(rows[1], scan.codes)
    progress = collection_progress(rows)
    assert progress.missing == 0 and progress.zero_quantity == 1
    internal = next_internal_barcode("77", 0, {"4006381333931", "5901234123457"})
    assert internal and len(internal[0]) == 13

    saved = service.save_rows(rows, source_path=package, output_path=package)
    receipt = sai_package.read_receipt(saved)
    assert receipt["items"][1]["barcodes"] == ["5901234123457"]
    assert receipt["items"][2]["quantity"] == 0
    assert "недовоз" in receipt["items"][2]["comment"].lower()

    _sheet, reopened_rows = load_sai_rows(str(saved))
    ready = build_receipt_route_plan(saved, reopened_rows)
    assert ready.kind is ReceiptRouteKind.AUTOMATIC
    return saved, reopened_rows


def rehearse_waybill_creation() -> None:
    sigma = FakeWaybillSigma()
    created = create_waybill(
        sigma,
        "company-1",
        {"id": "supplier-1", "name": "Тестовый поставщик"},
        "24.07.2026",
    )
    assert created["id"] == "waybill-1"
    assert created["storehouseDestination"]["id"] == "store-1"
    assert sigma.created_payload["status"] == "DRAFT"
    assert sigma.created_payload["type"] == "INCOME"
    assert sigma.created_payload["supplier"]["id"] == "supplier-1"


def rehearse_qt_operator_entry(package: Path) -> None:
    from PySide6.QtWidgets import QApplication
    from sai_pyside_preview import WorkbenchPage

    class Parent:
        free_receipt_page = None

        def show_receipt_hub(self):
            return None

    app = QApplication.instance() or QApplication([])
    page = WorkbenchPage(Parent())
    page.load_suppliers_async = lambda: None
    page.fill_suppliers([{
        "id": "supplier-1",
        "name": "ПОЛУАВТОМАТИЧЕСКИЙ ПРИВОЗ",
        "inn": "0000000000",
    }])
    page.set_sai_file(package)
    assert len(page.source_rows) == 4
    assert page.rows_without_barcodes() == []
    assert page.selected_supplier_id() == "supplier-1"
    assert bool(page.create_btn.property("logical_enabled"))
    assert "Создать черновик" in page.create_btn.text()

    active_package = page.processing_sai_file()
    _sheet, active_rows = load_sai_rows(str(active_package))
    assert len(active_rows) == 3
    assert all(float(row.get("qty") or 0) > 0 for row in active_rows)
    page.close()
    app.processEvents()


def rehearse_qt_semi_auto_completion(root: Path) -> None:
    """The final scan must be durable and must expose the next workflow action."""
    from PySide6.QtWidgets import QApplication
    from sai_pyside_preview import SemiAutoReceiptPage
    from sai_semi_auto_receipt import SemiAutoReceiptService as PersistenceService

    class Parent:
        opened = None

        def open_sai_file_in_workbench(self, path):
            self.opened = Path(path)

    class BrokenPersistence:
        def save_rows(self, *_args, **_kwargs):
            raise RuntimeError("simulated persistence failure")

    source_rows = [dict(INITIAL_ROWS[1])]
    package = PersistenceService().save_rows(
        source_rows,
        source_path=None,
        output_path=root / "qt-final-scan.sai",
    )
    _sheet, rows = load_sai_rows(str(package))
    app = QApplication.instance() or QApplication([])
    parent = Parent()
    page = SemiAutoReceiptPage(parent)
    page.sai_path = package
    page.output_path = package
    page.sheet_name = "SAI Package"
    page.rows = rows
    page.current_index = 0
    page.beep_error = lambda: None
    page.beep_success = lambda: None
    page.print_thermal_check.setChecked(False)
    page.refresh_table()
    page.set_current_index(0)
    assert page.table.columnCount() == 9
    assert page.table.cellWidget(0, 8) is not None

    # The operator can correct the retail price before scanning. The value must
    # reach the SAI package immediately and become the price used by labels.
    page.current_sale_edit.setText("199")
    page.apply_current_sale_from_edit()
    assert page.rows[0]["sale"] == 199
    assert sai_package.read_receipt(package)["items"][0]["sale_price"] == 199

    # A failed disk write must stop immediately on the accepted row and expose
    # recovery. It must never advance through another 45 unsaved rows.
    page.semi_auto_service = BrokenPersistence()
    page.add_barcodes_to_current(["5901234123457"], suppress_print=True)
    assert page.current_index == 0
    assert page.rows[0]["barcodes"] == ["5901234123457"]
    assert page.retry_save_btn.isVisible() or not page.retry_save_btn.isHidden()

    # Retrying with the correct persistence boundary saves the exact in-memory
    # state, reaches 100%, and always exposes the continuation button.
    page.semi_auto_service = PersistenceService()
    page.retry_save_current_state()
    assert page.current_index == -1
    assert not page.enter_sigma_btn.isHidden()
    assert page.enter_sigma_btn.isEnabled()
    assert sai_package.read_receipt(package)["items"][0]["barcodes"] == ["5901234123457"]
    page.open_in_auto_receipt()
    assert parent.opened == package
    page.close()
    app.processEvents()


def rehearse_automatic_apply(rows) -> None:
    # A zero returned by the fast SIGMA endpoints is "price unavailable".
    # The official catalog cache remains the safety source for the max policy.
    price_db = RUNTIME / "catalog-price-test.db"
    import json
    import sqlite3
    con = sqlite3.connect(price_db)
    con.execute("CREATE TABLE products (sigma_id TEXT PRIMARY KEY, raw_json TEXT)")
    con.execute(
        "INSERT INTO products(sigma_id, raw_json) VALUES (?, ?)",
        ("product-price", json.dumps({"items": [{"price": 310.0}]})),
    )
    con.commit(); con.close()
    assert highest_known_price(0, None) is None
    assert catalog_selling_price("product-price", price_db) == 310.0
    assert highest_known_price(300, 0, catalog_selling_price("product-price", price_db)) == 310.0

    active = to_apply_rows(rows)
    assert len(active) == 3, "zero-quantity shortage must not reach SIGMA"

    sigma = FakeApplySigma()
    errors, preflight_log = preflight_verify_rows(apply_args(), sigma, active, "store-1")
    assert errors == 0 and preflight_log.is_file() and not sigma.writes

    processed, errors, dry_log = process_rows(apply_args(), sigma, active, "store-1")
    assert (processed, errors) == (3, 0) and dry_log.is_file() and not sigma.writes

    processed, errors, apply_log = process_rows(apply_args(apply=True), sigma, active, "store-1")
    assert (processed, errors) == (3, 0) and apply_log.is_file()
    added_before_retry = sum(1 for item in sigma.writes if item[0] == "add")
    assert added_before_retry == 2, "existing waybill product must not be added again"
    assert sigma.values["element-existing"]["selling"] == 175, "max price policy must preserve higher SIGMA price"

    processed, errors, _ = process_rows(apply_args(apply=True), sigma, active, "store-1")
    assert (processed, errors) == (3, 0)
    assert sum(1 for item in sigma.writes if item[0] == "add") == added_before_retry
    assert sigma.values["element-2"]["selling"] == 90
    assert sigma.values["element-3"]["selling"] == 80

    missing = FakeApplySigma(missing={"5901234123457"})
    errors, _ = preflight_verify_rows(apply_args(), missing, active, "store-1")
    assert errors == 1 and not missing.writes

    transient = FakeApplySigma(fail_once_on="buying")
    processed, errors, _ = process_rows(apply_args(apply=True), transient, active, "store-1")
    assert errors == 1 and processed == 0
    processed, errors, _ = process_rows(apply_args(apply=True), transient, active, "store-1")
    assert (processed, errors) == (3, 0), "repeat run must recover after a transient partial write"
    assert sum(1 for item in transient.writes if item[0] == "add") == 2


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="sai_receipt_rehearsal_files_") as td:
        package, rows = rehearse_package_and_semi_auto(Path(td))
        rehearse_qt_semi_auto_completion(Path(td))
        rehearse_qt_operator_entry(package)
        rehearse_waybill_creation()
        rehearse_automatic_apply(rows)
    print("SAI receipt full-cycle rehearsal: OK")
    print("  package -> semi-auto -> save/reopen -> automatic route: PASS")
    print("  final scan -> failed save stop -> retry -> visible continuation: PASS")
    print("  real Qt workbench load -> supplier -> zero-shortage exclusion: PASS")
    print("  draft creation contract -> preflight -> dry-run -> apply: PASS")
    print("  shortage, duplicate, invalid scan, missing product, retry: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
