#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Small pure helpers shared by SAI scripts."""

import re
from typing import Any, List, Optional

BARCODE_RE = re.compile(r"\d{6,16}")
VALID_PRICE_POLICIES = {"max", "incoming", "sigma", "keep_sigma"}


def safe_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def normalize_barcode_text(value: Any) -> str:
    s = safe_str(value)
    if not s:
        return ""
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return s.strip()


def extract_barcode_candidates(value: Any) -> List[str]:
    """Extract unique barcode-like digit runs without rejecting old internal codes."""
    s = normalize_barcode_text(value)
    if not s:
        return []
    found = BARCODE_RE.findall(s)
    if found:
        result, seen = [], set()
        for code in found:
            if code not in seen:
                seen.add(code)
                result.append(code)
        return result
    digits = re.sub(r"\D+", "", s)
    return [digits] if digits else []


def gtin_check_digit_ok(code: str) -> bool:
    """Validate GTIN-8/12/13/14 check digit."""
    s = re.sub(r"\D+", "", safe_str(code))
    if len(s) not in {8, 12, 13, 14}:
        return False
    body, check = s[:-1], int(s[-1])
    total = 0
    weight = 3
    for ch in reversed(body):
        total += int(ch) * weight
        weight = 1 if weight == 3 else 3
    calc = (10 - (total % 10)) % 10
    return calc == check


def classify_barcode(code: Any) -> str:
    """Return a compact status used in reports/logs."""
    s = re.sub(r"\D+", "", safe_str(code))
    if not s:
        return "EMPTY"
    if len(s) in {8, 12, 13, 14}:
        return "GTIN_OK" if gtin_check_digit_ok(s) else "GTIN_BAD_CHECKSUM"
    if 6 <= len(s) <= 7:
        return "INTERNAL_SHORT"
    if 9 <= len(s) <= 16:
        return "NON_STANDARD_LENGTH"
    return "SUSPICIOUS"


def choose_selling_price(excel_selling_price: float, existing_price: Optional[float], policy: str = "max") -> float:
    """Pick final selling price.

    max         — safest default: never lower SIGMA price.
    incoming    — always use incoming Excel/SAI price.
    sigma       — keep SIGMA price when present, otherwise incoming.
    keep_sigma  — alias for sigma.
    """
    incoming = float(excel_selling_price or 0)
    policy = (policy or "max").strip().lower()
    if policy not in VALID_PRICE_POLICIES:
        policy = "max"
    if existing_price is None:
        return incoming
    sigma = float(existing_price)
    if policy == "incoming":
        return incoming
    if policy in {"sigma", "keep_sigma"}:
        return sigma
    return max(incoming, sigma)


def price_source_label(excel_selling_price: float, existing_price: Optional[float], final_selling_price: float, policy: str = "max") -> str:
    policy = (policy or "max").strip().lower()
    incoming = float(excel_selling_price or 0)
    final = float(final_selling_price or 0)
    if existing_price is None:
        return f"{policy.upper()}_INCOMING_NO_SIGMA_PRICE"
    sigma = float(existing_price)
    if abs(incoming - sigma) < 0.000001:
        return f"{policy.upper()}_SAME"
    if abs(final - incoming) < 0.000001:
        return f"{policy.upper()}_INCOMING"
    if abs(final - sigma) < 0.000001:
        return f"{policy.upper()}_SIGMA"
    return f"{policy.upper()}_CUSTOM"
