#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused offline regression tests for the marking verification module."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from sai_marking import MarkingVerificationService, normalize_scanned_code, result_rows


class _Response:
    def __init__(self, payload: dict) -> None:
        self.payload = json.dumps(payload).encode("utf-8")
    def __enter__(self): return self
    def __exit__(self, *_args): return None
    def read(self) -> bytes: return self.payload


def _urlopen(request, timeout=0):
    assert request.headers.get("X-api-key") == "test-token-value-1234567890"
    if request.full_url.endswith("/cdn/info"):
        return _Response({"code": 0, "description": "ok", "hosts": [{"host": "https://cdn01.crpt.ru"}]})
    if request.full_url.endswith("/cdn/health/check"):
        return _Response({"code": 0, "description": "ok", "avgTimeMs": 2})
    if request.full_url.endswith("/codes/check"):
        sent = json.loads(request.data.decode("utf-8"))
        assert sent["codes"] == ["010460123456789021ABC\x1d93XYZ"]
        return _Response({
            "code": 0, "description": "ok", "reqId": "req-1", "reqTimestamp": 1,
            "codes": [{"gtin": "04601234567890", "found": True, "realizable": True,
                       "sold": False, "packageType": "UNIT"}],
        })
    raise AssertionError(request.full_url)


def main() -> None:
    assert normalize_scanned_code("]d2010460123456789021ABC<GS>93XYZ") == "010460123456789021ABC\x1d93XYZ"
    assert normalize_scanned_code("010460123456789021ФИС") == "010460123456789021ABC"
    assert normalize_scanned_code("0104600905000592215T8G8e93szZd") == "0104600905000592215T8G8e\x1d93szZd"
    assert normalize_scanned_code("0104600528351347215Ap/GI91EE1192jdNagwjWm2JnvWCl7f1of3ajFioaxbxNllTHlSSzGho=") == (
        "0104600528351347215Ap/GI\x1d91EE11\x1d92jdNagwjWm2JnvWCl7f1of3ajFioaxbxNllTHlSSzGho="
    )
    with patch("urllib.request.urlopen", _urlopen):
        result = MarkingVerificationService("test-token-value-1234567890").check("010460123456789021ABC\x1d93XYZ")
    assert result.code["realizable"] is True
    assert ("Продажа разрешена", "Да") in result_rows(result)
    source = (Path(__file__).parent / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    assert '"Маркировка", self.show_marking' in source
    assert "MarkingCheckPage(self)" in source
    admin = (Path(__file__).parent / "sai_admin.py").read_text(encoding="utf-8-sig")
    assert "save_marking_token" in admin and "Вставьте токен ККТ" in admin
    print("SAI marking verification tests: OK")


if __name__ == "__main__":
    main()
