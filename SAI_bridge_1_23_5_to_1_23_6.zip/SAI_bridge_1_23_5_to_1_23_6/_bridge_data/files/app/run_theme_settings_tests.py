#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic checks for SAI v1.22.7bb fixed light/dark themes."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import sai_pyside_preview as ui


def logic_tests() -> None:
    assert ui.normalize_theme_mode(None) == "day"
    assert ui.normalize_theme_mode("DAY") == "day"
    assert ui.normalize_theme_mode("night") == "night"
    assert ui.normalize_theme_mode("system") == "day"
    assert ui.normalize_theme_mode("schedule") == "day"
    assert ui.resolve_theme_is_dark("day") is False
    assert ui.resolve_theme_is_dark("night") is True


class DummyPage:
    _background_catalog_running = False

    def __getattr__(self, _name):
        return lambda *args, **kwargs: None


def runtime_tests() -> None:
    app = ui.QApplication.instance() or ui.QApplication([])
    with tempfile.TemporaryDirectory(prefix="sai_theme_settings_") as td:
        private_path = Path(td) / "sai_private_config.json"
        private_path.write_text(json.dumps({"theme_mode": "day"}), encoding="utf-8")
        original_path = ui.PRIVATE_CONFIG_PATH
        ui.PRIVATE_CONFIG_PATH = private_path
        try:
            selector = ui.ThemeModeSelector()
            assert set(selector.buttons) == {"day", "night"}
            selector.set_mode("night")
            assert selector.mode() == "night"
            selector.set_mode("day")
            assert selector.mode() == "day"

            page = ui.SettingsPage(DummyPage())
            assert page.theme_selector.mode() == "day"
            assert not hasattr(page, "theme_time_edit")

            page.theme_selector.set_mode("night", emit=True)
            saved = json.loads(private_path.read_text(encoding="utf-8"))
            assert saved["theme_mode"] == "night"
            assert "пока ты сам" in page.theme_mode_description.text()

            page.theme_selector.set_mode("day", emit=True)
            saved = json.loads(private_path.read_text(encoding="utf-8"))
            assert saved["theme_mode"] == "day"
        finally:
            ui.PRIVATE_CONFIG_PATH = original_path

    app.processEvents()


def main() -> None:
    logic_tests()
    runtime_tests()
    print("Theme settings tests passed.")


if __name__ == "__main__":
    main()
