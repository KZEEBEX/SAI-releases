#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""SQLite storage for SAI.

v1.17 introduces SQLite as a safe internal cache/history layer.
The old JSON catalog cache still exists as fallback, so a DB problem must never
block receiving goods in the shop.
"""

from __future__ import annotations

import csv
import datetime as dt
import json
import sqlite3
from contextlib import closing
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from sai_runtime_paths import DB_PATH, ensure_runtime_dirs
from sai_core_v2.migrations import record_legacy_baseline, run_migrations
from sai_core_v2.stock import STOCK_MIGRATIONS
from sai_core_v2.product_events import PRODUCT_EVENT_MIGRATIONS, sync_receipt_events
from sai_core_v2.sigma_warehouse import SIGMA_WAREHOUSE_MIGRATIONS
from sai_core_v2.accounts import ACCOUNT_ADMIN_MIGRATIONS, ACCOUNT_MIGRATIONS

SCHEMA_VERSION = 10


def utcnow_text() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)


def json_loads(value: Any, default: Any = None) -> Any:
    if value is None or value == "":
        return default
    try:
        return json.loads(value)
    except Exception:
        return default


def connect() -> sqlite3.Connection:
    ensure_runtime_dirs()
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=30)
    con.row_factory = sqlite3.Row
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA synchronous=NORMAL")
        con.execute("PRAGMA foreign_keys=ON")
    except Exception:
        pass
    return con


def init_db() -> None:
    with closing(connect()) as con, con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS catalog_sync (
                company_key TEXT NOT NULL,
                sell_point_id TEXT NOT NULL,
                created_at TEXT NOT NULL,
                strategy TEXT,
                product_count INTEGER NOT NULL DEFAULT 0,
                barcode_count INTEGER NOT NULL DEFAULT 0,
                app_version TEXT,
                PRIMARY KEY (company_key, sell_point_id)
            );

            CREATE TABLE IF NOT EXISTS products (
                sigma_id TEXT PRIMARY KEY,
                company_key TEXT NOT NULL,
                sell_point_id TEXT NOT NULL,
                name TEXT,
                vendor_code TEXT,
                barcodes_json TEXT,
                raw_json TEXT,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_products_company_sp ON products(company_key, sell_point_id);
            CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
            CREATE INDEX IF NOT EXISTS idx_products_vendor_code ON products(vendor_code);

            CREATE TABLE IF NOT EXISTS barcodes (
                barcode TEXT NOT NULL,
                product_id TEXT NOT NULL,
                company_key TEXT NOT NULL,
                sell_point_id TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (barcode, product_id, company_key, sell_point_id)
            );
            CREATE INDEX IF NOT EXISTS idx_barcodes_lookup ON barcodes(company_key, sell_point_id, barcode);

            CREATE TABLE IF NOT EXISTS receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sai_path TEXT,
                sai_file_name TEXT,
                sai_file_size INTEGER,
                sai_file_mtime REAL,
                supplier_name TEXT,
                invoice_date TEXT,
                status TEXT,
                total INTEGER DEFAULT 0,
                ok_full INTEGER DEFAULT 0,
                missing_count INTEGER DEFAULT 0,
                no_barcode_count INTEGER DEFAULT 0,
                barcode_add_needed_count INTEGER DEFAULT 0,
                conflicts_count INTEGER DEFAULT 0,
                import_path TEXT,
                barcode_update_path TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_receipts_file ON receipts(sai_path, sai_file_mtime);
            CREATE INDEX IF NOT EXISTS idx_receipts_created_at ON receipts(created_at);

            CREATE TABLE IF NOT EXISTS receipt_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                receipt_id INTEGER NOT NULL,
                excel_row INTEGER,
                name TEXT,
                barcodes_raw TEXT,
                qty REAL,
                buy REAL,
                sale REAL,
                article TEXT,
                category TEXT,
                status TEXT,
                sigma_product_id TEXT,
                matched_codes TEXT,
                message TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(receipt_id) REFERENCES receipts(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_receipt_items_receipt ON receipt_items(receipt_id);
            CREATE INDEX IF NOT EXISTS idx_receipt_items_status ON receipt_items(status);

            CREATE TABLE IF NOT EXISTS apply_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sai_path TEXT,
                sai_file_name TEXT,
                supplier_name TEXT,
                invoice_date TEXT,
                waybill_id TEXT,
                status TEXT,
                ok_count INTEGER DEFAULT 0,
                error_count INTEGER DEFAULT 0,
                buying_total REAL DEFAULT 0,
                selling_total REAL DEFAULT 0,
                log_path TEXT,
                audit_path TEXT,
                app_version TEXT,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_apply_runs_created_at ON apply_runs(created_at);
            CREATE INDEX IF NOT EXISTS idx_apply_runs_supplier ON apply_runs(supplier_name, invoice_date);

            CREATE TABLE IF NOT EXISTS price_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                apply_run_id INTEGER,
                product_id TEXT,
                barcode TEXT,
                used_barcode TEXT,
                name TEXT,
                supplier_name TEXT,
                invoice_date TEXT,
                waybill_id TEXT,
                quantity REAL,
                buying_price REAL,
                incoming_selling_price REAL,
                sigma_existing_selling_price REAL,
                final_selling_price REAL,
                price_source TEXT,
                status TEXT,
                source_log_path TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(apply_run_id) REFERENCES apply_runs(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_price_history_barcode ON price_history(barcode);
            CREATE INDEX IF NOT EXISTS idx_price_history_used_barcode ON price_history(used_barcode);
            CREATE INDEX IF NOT EXISTS idx_price_history_name ON price_history(name);
            CREATE INDEX IF NOT EXISTS idx_price_history_product ON price_history(product_id);
            CREATE INDEX IF NOT EXISTS idx_price_history_apply_run ON price_history(apply_run_id);
            CREATE INDEX IF NOT EXISTS idx_price_history_created_at ON price_history(created_at);

            CREATE TABLE IF NOT EXISTS receipt_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                apply_run_id INTEGER NOT NULL,
                kind TEXT NOT NULL,
                original_name TEXT,
                stored_name TEXT,
                archived_path TEXT NOT NULL,
                file_size INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                FOREIGN KEY(apply_run_id) REFERENCES apply_runs(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_receipt_files_apply ON receipt_files(apply_run_id);
            CREATE INDEX IF NOT EXISTS idx_receipt_files_kind ON receipt_files(kind);
            """
        )
        # Incremental migrations for existing shop databases.
        existing_apply_columns = {row[1] for row in con.execute("PRAGMA table_info(apply_runs)").fetchall()}
        if "total_quantity" not in existing_apply_columns:
            con.execute("ALTER TABLE apply_runs ADD COLUMN total_quantity REAL DEFAULT 0")
        if "archive_dir" not in existing_apply_columns:
            con.execute("ALTER TABLE apply_runs ADD COLUMN archive_dir TEXT")
        con.execute(
            """
            UPDATE apply_runs
            SET total_quantity = COALESCE((
                SELECT SUM(quantity) FROM price_history WHERE price_history.apply_run_id = apply_runs.id
            ), 0)
            WHERE total_quantity IS NULL OR ABS(total_quantity) < 0.000001
            """
        )
        con.execute(
            "INSERT OR REPLACE INTO meta(key, value) VALUES('schema_version', ?)",
            (str(SCHEMA_VERSION),),
        )
        # Version 3 is the last legacy schema. Version 4 is applied below by
        # the ordered migration ledger and must not be pre-marked as complete.
        record_legacy_baseline(con, 3)
        run_migrations(con, STOCK_MIGRATIONS)
        run_migrations(con, ACCOUNT_MIGRATIONS)
        run_migrations(con, ACCOUNT_ADMIN_MIGRATIONS)
        run_migrations(con, PRODUCT_EVENT_MIGRATIONS)
        run_migrations(con, SIGMA_WAREHOUSE_MIGRATIONS)
        con.commit()


def is_available() -> bool:
    try:
        init_db()
        return True
    except Exception:
        return False


def _normalize_catalog_product(summary: Dict[str, Any]) -> Dict[str, Any]:
    pid = safe_str(summary.get("id"))
    return {
        "id": pid,
        "name": safe_str(summary.get("name")),
        "vendor_code": safe_str(summary.get("vendor_code")),
        "barcodes": [safe_str(x) for x in (summary.get("barcodes") or []) if safe_str(x)],
        "raw": summary.get("raw"),
    }


def save_catalog(catalog: Dict[str, Any], company_key: str, sell_point_id: str, app_version: str = "", *, complete: bool = True, allow_empty: bool = False) -> Dict[str, int]:
    """Merge a verified snapshot, retaining unchanged rows and their timestamps.

    Partial updates never delete unseen products or advance full-snapshot age.
    Empty full snapshots require explicit confirmation.
    """
    init_db()
    company_key, sell_point_id = safe_str(company_key), safe_str(sell_point_id)
    prepared = {}
    for pid, summary in (catalog.get("products_by_id") or {}).items():
        item = _normalize_catalog_product(summary or {})
        item["id"] = item["id"] or safe_str(pid)
        if item["id"]:
            prepared[item["id"]] = item
    for code, by_pid in (catalog.get("code_to_products") or {}).items():
        code = safe_str(code)
        if not code or not isinstance(by_pid, dict):
            continue
        for pid, summary in by_pid.items():
            pid = safe_str(pid)
            if not pid:
                continue
            item = prepared.setdefault(pid, {**_normalize_catalog_product(summary or {}), "id": pid})
            if code not in item["barcodes"]:
                item["barcodes"].append(code)
    if complete and not prepared and not allow_empty:
        raise ValueError("Пустой каталог не заменяет сохранённые данные без подтверждения")
    now = utcnow_text()
    product_revision = dt.datetime.now().isoformat(sep=" ", timespec="microseconds")
    changed = removed = 0
    with closing(connect()) as con, con:
        con.execute("BEGIN IMMEDIATE")
        existing = {
            str(row["sigma_id"]): row for row in con.execute(
                "SELECT * FROM products WHERE company_key=? AND sell_point_id=?",
                (company_key, sell_point_id),
            )
        }
        for pid, item in prepared.items():
            barcodes = sorted(set(item["barcodes"]))
            values = (
                item["name"], item["vendor_code"], json_dumps(barcodes),
                json.dumps(item.get("raw"), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str),
            )
            previous = existing.get(pid)
            if previous and (
                previous["name"], previous["vendor_code"], previous["barcodes_json"],
                json.dumps(json_loads(previous["raw_json"]), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str),
            ) == values:
                continue
            result = con.execute(
                """INSERT INTO products(sigma_id, company_key, sell_point_id, name, vendor_code, barcodes_json, raw_json, updated_at)
                   VALUES(?,?,?,?,?,?,?,?)
                   ON CONFLICT(sigma_id) DO UPDATE SET
                     name=excluded.name, vendor_code=excluded.vendor_code,
                     barcodes_json=excluded.barcodes_json, raw_json=excluded.raw_json, updated_at=excluded.updated_at
                   WHERE products.company_key=excluded.company_key AND products.sell_point_id=excluded.sell_point_id""",
                (pid, company_key, sell_point_id, *values, product_revision),
            )
            if result.rowcount != 1:
                raise ValueError("Карточка каталога принадлежит другой организации или точке")
            con.execute("DELETE FROM barcodes WHERE product_id=? AND company_key=? AND sell_point_id=?", (pid, company_key, sell_point_id))
            con.executemany(
                "INSERT INTO barcodes(barcode, product_id, company_key, sell_point_id, updated_at) VALUES(?,?,?,?,?)",
                [(code, pid, company_key, sell_point_id, now) for code in barcodes],
            )
            changed += 1
        if complete:
            obsolete = [(pid, company_key, sell_point_id) for pid in existing.keys() - prepared.keys()]
            con.executemany("DELETE FROM barcodes WHERE product_id=? AND company_key=? AND sell_point_id=?", obsolete)
            con.executemany("DELETE FROM products WHERE sigma_id=? AND company_key=? AND sell_point_id=?", obsolete)
            removed = len(obsolete)
        product_count = con.execute("SELECT COUNT(*) FROM products WHERE company_key=? AND sell_point_id=?", (company_key, sell_point_id)).fetchone()[0]
        barcode_count = con.execute("SELECT COUNT(*) FROM barcodes WHERE company_key=? AND sell_point_id=?", (company_key, sell_point_id)).fetchone()[0]
        if complete:
            con.execute(
                """INSERT OR REPLACE INTO catalog_sync(company_key, sell_point_id, created_at, strategy, product_count, barcode_count, app_version)
                   VALUES(?,?,?,?,?,?,?)""",
                (company_key, sell_point_id, now, safe_str(catalog.get("strategy")), product_count, barcode_count, safe_str(app_version)),
            )
    return {"product_count": int(product_count), "barcode_count": int(barcode_count), "changed": changed, "removed": removed}


def load_catalog(company_key: str, sell_point_id: str) -> Optional[Dict[str, Any]]:
    init_db()
    company_key = safe_str(company_key)
    sell_point_id = safe_str(sell_point_id)
    with closing(connect()) as con, con:
        meta = con.execute(
            "SELECT * FROM catalog_sync WHERE company_key=? AND sell_point_id=?",
            (company_key, sell_point_id),
        ).fetchone()
        if not meta:
            return None
        rows = con.execute(
            "SELECT * FROM products WHERE company_key=? AND sell_point_id=?",
            (company_key, sell_point_id),
        ).fetchall()
        if not rows:
            return None
        products_by_id: Dict[str, Dict[str, Any]] = {}
        for r in rows:
            pid = safe_str(r["sigma_id"])
            if not pid:
                continue
            products_by_id[pid] = {
                "id": pid,
                "name": safe_str(r["name"]),
                "vendor_code": safe_str(r["vendor_code"]),
                "barcodes": json_loads(r["barcodes_json"], []) or [],
                "raw": json_loads(r["raw_json"], None),
            }

        code_to_products: Dict[str, Dict[str, Dict[str, Any]]] = {}
        codes = set()
        bc_rows = con.execute(
            "SELECT barcode, product_id FROM barcodes WHERE company_key=? AND sell_point_id=?",
            (company_key, sell_point_id),
        ).fetchall()
        for r in bc_rows:
            code = safe_str(r["barcode"])
            pid = safe_str(r["product_id"])
            product = products_by_id.get(pid)
            if not code or not product:
                continue
            codes.add(code)
            code_to_products.setdefault(code, {})[pid] = product
        if not codes:
            return None
        return {
            "codes": codes,
            "product_count": int(meta["product_count"] or len(products_by_id)),
            "strategy": "sqlite_" + safe_str(meta["strategy"] or "unknown"),
            "code_to_products": code_to_products,
            "products_by_id": products_by_id,
            "cache_created_at": safe_str(meta["created_at"]),
            "cache_source": "sqlite",
        }


def catalog_age_seconds(company_key: str, sell_point_id: str) -> Optional[float]:
    try:
        init_db()
        with closing(connect()) as con, con:
            row = con.execute(
                "SELECT created_at FROM catalog_sync WHERE company_key=? AND sell_point_id=?",
                (safe_str(company_key), safe_str(sell_point_id)),
            ).fetchone()
        if not row:
            return None
        created_at = safe_str(row["created_at"])
        if not created_at:
            return None
        created = dt.datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
        return max(0.0, (dt.datetime.now() - created).total_seconds())
    except Exception:
        return None


def _file_info(path: Any) -> Dict[str, Any]:
    p = Path(safe_str(path))
    try:
        st = p.stat()
        return {
            "path": str(p),
            "name": p.name,
            "size": int(st.st_size),
            "mtime": float(st.st_mtime),
        }
    except Exception:
        return {"path": str(p), "name": p.name, "size": 0, "mtime": 0.0}


def _row_key(row: Dict[str, Any]) -> int:
    try:
        return int(row.get("excel_row") or 0)
    except Exception:
        return 0


def save_receipt_check(
    sai_path: Any,
    supplier_name: str,
    invoice_date: str,
    source_rows: Iterable[Dict[str, Any]],
    result: Dict[str, Any],
) -> int:
    """Store the latest product-check result for history/recovery.

    The GUI does not depend on this function. If DB storage fails, callers should log
    the error and continue normal receiving.
    """
    init_db()
    info = _file_info(sai_path)
    now = utcnow_text()
    status = "ready"
    if int(result.get("no_barcode") or 0) > 0:
        status = "blocked_no_barcode"
    elif int(result.get("conflicts") or 0) > 0:
        status = "blocked_conflicts"
    elif int(result.get("barcode_add_needed") or 0) > 0:
        status = "blocked_manual_barcodes"
    elif int(result.get("missing") or 0) > 0:
        status = "import_required"

    rows_by_excel = {_row_key(r): dict(r) for r in (source_rows or [])}
    item_status: Dict[int, Dict[str, Any]] = {}

    for r in result.get("missing_rows") or []:
        item_status[_row_key(r)] = {"status": "missing_import", "message": "Нужно импортировать в SIGMA"}
    for r in result.get("no_barcode_rows") or []:
        item_status[_row_key(r)] = {"status": "no_barcode", "message": "Нет штрихкода"}
    for item in result.get("barcode_add_rows") or []:
        row = item.get("row") or {}
        product = item.get("product") or {}
        item_status[_row_key(row)] = {
            "status": "barcode_add_needed",
            "sigma_product_id": safe_str(product.get("id")),
            "matched_codes": ", ".join(item.get("matched_codes") or []),
            "message": "Нужно добавить ШК к существующему товару",
        }
    for item in result.get("conflict_rows") or []:
        row = item.get("row") or {}
        item_status[_row_key(row)] = {
            "status": "conflict",
            "matched_codes": ", ".join(item.get("codes") or []),
            "message": "Разные ШК строки ведут к разным товарам SIGMA",
        }

    with closing(connect()) as con, con:
        cur = con.execute(
            """
            INSERT INTO receipts(
                sai_path, sai_file_name, sai_file_size, sai_file_mtime,
                supplier_name, invoice_date, status, total, ok_full,
                missing_count, no_barcode_count, barcode_add_needed_count, conflicts_count,
                import_path, barcode_update_path, created_at, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                info["path"], info["name"], info["size"], info["mtime"],
                safe_str(supplier_name), safe_str(invoice_date), status,
                int(result.get("total") or 0), int(result.get("ok_full") or 0),
                int(result.get("missing") or 0), int(result.get("no_barcode") or 0),
                int(result.get("barcode_add_needed") or 0), int(result.get("conflicts") or 0),
                safe_str(result.get("import_path")), safe_str(result.get("barcode_update_path")),
                now, now,
            ),
        )
        receipt_id = int(cur.lastrowid)
        for excel_row, row in sorted(rows_by_excel.items()):
            st = item_status.get(excel_row, {"status": "found", "message": "Найдено"})
            con.execute(
                """
                INSERT INTO receipt_items(
                    receipt_id, excel_row, name, barcodes_raw, qty, buy, sale,
                    article, category, status, sigma_product_id, matched_codes, message, created_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    receipt_id, excel_row, safe_str(row.get("name")),
                    ", ".join(row.get("barcodes") or []), row.get("qty"), row.get("buy"), row.get("sale"),
                    safe_str(row.get("article")), safe_str(row.get("category")),
                    safe_str(st.get("status")), safe_str(st.get("sigma_product_id")),
                    safe_str(st.get("matched_codes")), safe_str(st.get("message")), now,
                ),
            )
        con.commit()
    return receipt_id


def latest_receipt_summary(limit: int = 5) -> List[Dict[str, Any]]:
    init_db()
    with closing(connect()) as con, con:
        rows = con.execute(
            """
            SELECT id, sai_file_name, supplier_name, invoice_date, status, total,
                   ok_full, missing_count, no_barcode_count, barcode_add_needed_count,
                   conflicts_count, created_at
            FROM receipts
            ORDER BY id DESC
            LIMIT ?
            """,
            (int(limit or 5),),
        ).fetchall()
    return [dict(r) for r in rows]


def _to_float(value: Any) -> float:
    s = safe_str(value).replace("\xa0", "").replace(" ", "").replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0


def _pct_change(old: float, new: float) -> Optional[float]:
    try:
        old = float(old)
        new = float(new)
        if abs(old) < 0.000001:
            return None
        return ((new - old) / old) * 100.0
    except Exception:
        return None


def _first_barcode_from_raw(value: Any) -> str:
    raw = safe_str(value)
    if not raw:
        return ""
    parts = [p.strip() for p in raw.replace(";", ",").replace("\n", ",").split(",")]
    return next((p for p in parts if p), raw)


def record_apply_log(
    log_path: Any,
    sai_path: Any = "",
    supplier_name: str = "",
    invoice_date: str = "",
    waybill_id: str = "",
    audit_path: Any = "",
    app_version: str = "",
) -> Dict[str, Any]:
    """Store a successful API-first APPLY CSV into SQLite price history.

    This is a memory layer for SAI. It never affects the SIGMA write itself.
    """
    init_db()
    log_path = Path(safe_str(log_path))
    if not log_path.exists():
        raise FileNotFoundError(str(log_path))
    now = utcnow_text()
    info = _file_info(sai_path)
    rows: List[Dict[str, Any]] = []
    with open(log_path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f, delimiter=";")
        for r in reader:
            rows.append(dict(r))

    ok_rows = [r for r in rows if safe_str(r.get("status")).upper() == "OK"]
    error_rows = [r for r in rows if safe_str(r.get("status")).upper() == "ERROR"]
    buying_total = sum(_to_float(r.get("quantity")) * _to_float(r.get("buying_price")) for r in ok_rows)
    selling_total = sum(_to_float(r.get("quantity")) * _to_float(r.get("final_selling_price") or r.get("incoming_selling_price")) for r in ok_rows)
    status = "ok" if not error_rows else "errors"

    with closing(connect()) as con, con:
        cur = con.execute(
            """
            INSERT INTO apply_runs(
                sai_path, sai_file_name, supplier_name, invoice_date, waybill_id, status,
                ok_count, error_count, total_quantity, buying_total, selling_total,
                log_path, audit_path, app_version, created_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                info["path"], info["name"], safe_str(supplier_name), safe_str(invoice_date), safe_str(waybill_id), status,
                len(ok_rows), len(error_rows), float(sum(_to_float(r.get("quantity")) for r in ok_rows)),
                float(buying_total), float(selling_total), str(log_path), safe_str(audit_path), safe_str(app_version), now,
            ),
        )
        apply_run_id = int(cur.lastrowid)
        for r in ok_rows:
            final_sale = _to_float(r.get("final_selling_price") or r.get("incoming_selling_price"))
            con.execute(
                """
                INSERT INTO price_history(
                    apply_run_id, product_id, barcode, used_barcode, name, supplier_name, invoice_date, waybill_id,
                    quantity, buying_price, incoming_selling_price, sigma_existing_selling_price, final_selling_price,
                    price_source, status, source_log_path, created_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    apply_run_id, safe_str(r.get("product_id")), safe_str(r.get("barcode")), safe_str(r.get("used_barcode")),
                    safe_str(r.get("name")), safe_str(supplier_name), safe_str(invoice_date), safe_str(waybill_id),
                    _to_float(r.get("quantity")), _to_float(r.get("buying_price")), _to_float(r.get("incoming_selling_price")),
                    None if safe_str(r.get("sigma_existing_selling_price")) == "" else _to_float(r.get("sigma_existing_selling_price")),
                    final_sale, safe_str(r.get("price_source")), safe_str(r.get("status")), str(log_path), now,
                ),
            )
        # A successful receipt becomes visible in the product timeline in the
        # same transaction. Rows that cannot yet be linked safely remain in
        # price_history and are picked up after a later catalog refresh.
        sync_receipt_events(con, apply_run_id)
        con.commit()

    return {
        "apply_run_id": apply_run_id,
        "ok_count": len(ok_rows),
        "error_count": len(error_rows),
        "total_quantity": float(sum(_to_float(r.get("quantity")) for r in ok_rows)),
        "buying_total": float(buying_total),
        "selling_total": float(selling_total),
        "log_path": str(log_path),
    }


def latest_apply_summary(limit: int = 8) -> List[Dict[str, Any]]:
    init_db()
    with closing(connect()) as con, con:
        rows = con.execute(
            """
            SELECT id, supplier_name, invoice_date, waybill_id, status, ok_count, error_count,
                   total_quantity, buying_total, selling_total, log_path, audit_path, archive_dir, app_version, created_at
            FROM apply_runs
            ORDER BY id DESC
            LIMIT ?
            """,
            (int(limit),),
        ).fetchall()
    return [dict(r) for r in rows]



def successful_apply_runs(search: str = "", limit: int = 500) -> List[Dict[str, Any]]:
    """Return only receipts that completed without row errors."""
    init_db()
    search = safe_str(search)
    params: List[Any] = []
    where = "WHERE status='ok' AND COALESCE(error_count, 0)=0 AND COALESCE(ok_count, 0)>0"
    if search:
        where += " AND (supplier_name LIKE ? OR invoice_date LIKE ? OR waybill_id LIKE ? OR sai_file_name LIKE ?)"
        token = f"%{search}%"
        params.extend([token, token, token, token])
    params.append(max(1, int(limit or 500)))
    with closing(connect()) as con, con:
        rows = con.execute(
            f"""
            SELECT id, sai_path, sai_file_name, supplier_name, invoice_date, waybill_id,
                   status, ok_count, error_count, COALESCE(total_quantity, 0) AS total_quantity,
                   buying_total, selling_total, log_path, audit_path, archive_dir,
                   app_version, created_at
            FROM apply_runs
            {where}
            ORDER BY id DESC
            LIMIT ?
            """,
            tuple(params),
        ).fetchall()
    return [dict(r) for r in rows]


def search_successful_apply_runs(query: str, limit: int = 1000) -> List[Dict[str, Any]]:
    """Find completed receipts by supplier, product name, barcode or product id.

    Words may be entered in any order. Every entered word must occur in one
    product row (or in the receipt metadata), which prevents short common words
    from pulling unrelated receipts into the result.
    """
    query = safe_str(query).strip()
    rows = successful_apply_runs(search="", limit=limit)
    if not query or not rows:
        return rows

    def normalized(value: Any) -> str:
        text = safe_str(value).casefold().replace("ё", "е")
        return " ".join("".join(ch if ch.isalnum() else " " for ch in text).split())

    tokens = [token for token in normalized(query).split() if token]
    if not tokens:
        return rows

    run_by_id = {int(row.get("id") or 0): row for row in rows}
    matches: Dict[int, List[str]] = {run_id: [] for run_id in run_by_id}
    with closing(connect()) as con, con:
        item_rows = con.execute(
            """
            SELECT apply_run_id, name, barcode, used_barcode, product_id
            FROM price_history
            WHERE apply_run_id IN (
                SELECT id FROM apply_runs
                WHERE status='ok' AND COALESCE(error_count, 0)=0 AND COALESCE(ok_count, 0)>0
                ORDER BY id DESC LIMIT ?
            ) AND UPPER(COALESCE(status, ''))='OK'
            ORDER BY id DESC
            """,
            (max(1, int(limit or 1000)),),
        ).fetchall()

    def token_matches(token: str, haystack: str) -> bool:
        if token in haystack:
            return True
        # A long unfinished word is useful while the operator is still typing.
        if len(token) >= 4:
            return any(word.startswith(token) for word in haystack.split())
        return False

    for item in item_rows:
        run_id = int(item["apply_run_id"] or 0)
        if run_id not in run_by_id:
            continue
        searchable = normalized(" ".join([
            safe_str(item["name"]), safe_str(item["barcode"]),
            safe_str(item["used_barcode"]), safe_str(item["product_id"]),
        ]))
        if all(token_matches(token, searchable) for token in tokens):
            label = safe_str(item["name"]) or safe_str(item["used_barcode"]) or safe_str(item["barcode"])
            if label and label not in matches[run_id]:
                matches[run_id].append(label)

    found: List[Dict[str, Any]] = []
    for row in rows:
        run_id = int(row.get("id") or 0)
        metadata = normalized(" ".join([
            safe_str(row.get("supplier_name")), safe_str(row.get("invoice_date")),
            safe_str(row.get("waybill_id")), safe_str(row.get("sai_file_name")),
        ]))
        metadata_match = all(token_matches(token, metadata) for token in tokens)
        product_matches = matches.get(run_id, [])
        if metadata_match or product_matches:
            result = dict(row)
            result["history_matches"] = product_matches
            found.append(result)
    return found


def get_apply_run(apply_run_id: int) -> Optional[Dict[str, Any]]:
    init_db()
    with closing(connect()) as con, con:
        row = con.execute("SELECT * FROM apply_runs WHERE id=?", (int(apply_run_id),)).fetchone()
    return dict(row) if row else None


def get_apply_items(apply_run_id: int) -> List[Dict[str, Any]]:
    init_db()
    with closing(connect()) as con, con:
        rows = con.execute(
            """
            SELECT id, product_id, barcode, used_barcode, name, quantity, buying_price,
                   final_selling_price, incoming_selling_price, price_source, status
            FROM price_history
            WHERE apply_run_id=? AND UPPER(COALESCE(status, ''))='OK'
            ORDER BY id
            """,
            (int(apply_run_id),),
        ).fetchall()
    return [dict(r) for r in rows]


def update_apply_archive_dir(apply_run_id: int, archive_dir: str) -> None:
    init_db()
    with closing(connect()) as con, con:
        con.execute("UPDATE apply_runs SET archive_dir=? WHERE id=?", (safe_str(archive_dir), int(apply_run_id)))
        con.commit()


def register_receipt_file(
    apply_run_id: int,
    kind: str,
    original_name: str,
    stored_name: str,
    archived_path: str,
    file_size: int = 0,
) -> int:
    init_db()
    now = utcnow_text()
    archived_path = safe_str(archived_path)
    with closing(connect()) as con, con:
        # Re-generating NDP/labels should replace the entry for the same stored file,
        # while multiple source invoices remain independent records.
        existing = con.execute(
            "SELECT id FROM receipt_files WHERE apply_run_id=? AND archived_path=?",
            (int(apply_run_id), archived_path),
        ).fetchone()
        if existing:
            con.execute(
                """
                UPDATE receipt_files
                SET kind=?, original_name=?, stored_name=?, file_size=?, created_at=?
                WHERE id=?
                """,
                (safe_str(kind), safe_str(original_name), safe_str(stored_name), int(file_size or 0), now, int(existing["id"])),
            )
            file_id = int(existing["id"])
        else:
            cur = con.execute(
                """
                INSERT INTO receipt_files(apply_run_id, kind, original_name, stored_name, archived_path, file_size, created_at)
                VALUES(?,?,?,?,?,?,?)
                """,
                (int(apply_run_id), safe_str(kind), safe_str(original_name), safe_str(stored_name), archived_path, int(file_size or 0), now),
            )
            file_id = int(cur.lastrowid)
        con.commit()
    return file_id


def receipt_files(apply_run_id: int) -> List[Dict[str, Any]]:
    init_db()
    with closing(connect()) as con, con:
        rows = con.execute(
            """
            SELECT id, apply_run_id, kind, original_name, stored_name, archived_path, file_size, created_at
            FROM receipt_files
            WHERE apply_run_id=?
            ORDER BY
                CASE kind
                    WHEN 'sai' THEN 1
                    WHEN 'source' THEN 2
                    WHEN 'approval_preview' THEN 3
                    WHEN 'approval_final' THEN 4
                    WHEN 'ndp' THEN 5
                    WHEN 'price_tags' THEN 6
                    ELSE 9
                END,
                id
            """,
            (int(apply_run_id),),
        ).fetchall()
    return [dict(r) for r in rows]


def delete_apply_run(apply_run_id: int) -> None:
    init_db()
    with closing(connect()) as con, con:
        con.execute("DELETE FROM apply_runs WHERE id=?", (int(apply_run_id),))
        con.commit()


def price_history_stats() -> Dict[str, int]:
    init_db()
    with closing(connect()) as con, con:
        apply_runs = con.execute("SELECT COUNT(*) FROM apply_runs").fetchone()[0]
        price_rows = con.execute("SELECT COUNT(*) FROM price_history").fetchone()[0]
    return {"apply_runs": int(apply_runs), "price_rows": int(price_rows)}


def latest_price_for_item(barcode: str = "", used_barcode: str = "", name: str = "") -> Optional[Dict[str, Any]]:
    init_db()
    barcode = safe_str(barcode)
    used_barcode = safe_str(used_barcode)
    name = safe_str(name)
    with closing(connect()) as con, con:
        row = None
        for code in [used_barcode, barcode, _first_barcode_from_raw(barcode)]:
            code = safe_str(code)
            if not code:
                continue
            row = con.execute(
                """
                SELECT * FROM price_history
                WHERE used_barcode=? OR barcode=?
                ORDER BY id DESC
                LIMIT 1
                """,
                (code, code),
            ).fetchone()
            if row:
                break
        if not row and name:
            row = con.execute(
                """
                SELECT * FROM price_history
                WHERE name=?
                ORDER BY id DESC
                LIMIT 1
                """,
                (name,),
            ).fetchone()
    return dict(row) if row else None


def price_warnings_for_rows(
    rows: Iterable[Dict[str, Any]],
    buy_threshold_pct: float = 15.0,
    sale_threshold_pct: float = 10.0,
    limit: int = 20,
) -> List[Dict[str, Any]]:
    """Return notable changes vs last APPLY for each SAI row.

    Rows are expected in the shape produced by load_sai_rows/create_import_file.
    """
    warnings: List[Dict[str, Any]] = []
    seen = set()
    for row in rows or []:
        name = safe_str(row.get("name"))
        barcodes = row.get("barcodes") or []
        raw_barcode = ", ".join([safe_str(x) for x in barcodes if safe_str(x)])
        key = (raw_barcode, name)
        if key in seen:
            continue
        seen.add(key)
        previous = latest_price_for_item(barcode=raw_barcode, name=name)
        if not previous:
            continue
        new_buy = _to_float(row.get("buy"))
        new_sale = _to_float(row.get("sale"))
        old_buy = _to_float(previous.get("buying_price"))
        old_sale = _to_float(previous.get("final_selling_price"))
        buy_pct = _pct_change(old_buy, new_buy)
        sale_pct = _pct_change(old_sale, new_sale)
        hit_buy = buy_pct is not None and abs(buy_pct) >= float(buy_threshold_pct)
        hit_sale = sale_pct is not None and abs(sale_pct) >= float(sale_threshold_pct)
        if not (hit_buy or hit_sale):
            continue
        warnings.append({
            "name": name,
            "barcode": raw_barcode,
            "old_buying": old_buy,
            "new_buying": new_buy,
            "buy_change_pct": buy_pct if hit_buy else None,
            "old_selling": old_sale,
            "new_selling": new_sale,
            "sale_change_pct": sale_pct if hit_sale else None,
            "previous_date": previous.get("created_at"),
            "previous_supplier": previous.get("supplier_name"),
        })
        if len(warnings) >= int(limit):
            break
    return warnings
