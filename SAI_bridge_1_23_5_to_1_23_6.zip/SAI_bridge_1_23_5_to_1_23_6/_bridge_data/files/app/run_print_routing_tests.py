"""Regression checks for strict A4/thermal printer separation."""
from __future__ import annotations

from pathlib import Path

from sai_print_routing import (
    is_thermal_printer_name,
    require_a4_printer_name,
    resolve_a4_printer_name,
)


def main() -> None:
    thermal = "4BARCODE 4B-2083B (Copy 1)"
    ordinary = "Pantum BM2300W Series 0001"
    installed = [thermal, ordinary]

    assert is_thermal_printer_name(thermal)
    assert not is_thermal_printer_name(ordinary)
    assert resolve_a4_printer_name(thermal, installed, thermal) == ordinary
    assert resolve_a4_printer_name(ordinary, installed, thermal) == ordinary
    assert require_a4_printer_name(ordinary) == ordinary

    try:
        require_a4_printer_name(thermal)
    except RuntimeError as exc:
        assert "запрещена" in str(exc)
    else:
        raise AssertionError("A4 printing to 4BARCODE must be rejected")

    app_dir = Path(__file__).resolve().parent
    pyside_source = (app_dir / "sai_pyside_preview.py").read_text(encoding="utf-8")
    legacy_source = (app_dir / "sai_app.py").read_text(encoding="utf-8")
    assert "configured_a4_printer_name()" in pyside_source
    assert 'os.startfile(path, "print")' not in legacy_source
    assert "require_a4_printer_name(" in legacy_source

    print("SAI print routing tests: OK")


if __name__ == "__main__":
    main()
