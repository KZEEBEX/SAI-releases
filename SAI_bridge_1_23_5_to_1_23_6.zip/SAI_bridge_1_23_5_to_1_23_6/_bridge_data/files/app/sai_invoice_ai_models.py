#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Model and cost-guard configuration for SAI invoice AI."""
from __future__ import annotations

DEFAULT_MODEL = "gpt-5.6-luna"
AUDIT_MODEL = "gpt-5.6-terra"
FALLBACK_MODEL = "gpt-5.6-sol"
DEFAULT_API_BASE = "https://api.openai.com/v1"

MAX_OUTPUT_TOKENS = 18_000
MAX_AUDIT_OUTPUT_TOKENS = 8_000
MAX_HEADER_OUTPUT_TOKENS = 1_200
MAX_SOL_REPAIR_ROWS = 6
MAX_SOL_REPAIR_PAGES = 2

LEGACY_PRIMARY_MODELS = {
    "gpt-5-mini",
    "gpt-5-nano",
    "gpt-5.4-mini",
    "gpt-5.4-nano",
    "gpt-5.6",
    "gpt-5.6-sol",
    "gpt-5.6-terra",
    "gpt-5.6-luna",
}


def quality_model(configured_model: str = "") -> str:
    """Return the primary model used by the adaptive invoice agent.

    Known model choices from earlier SAI builds are deliberately migrated to
    Luna. Unknown custom model identifiers are preserved.
    """
    value = str(configured_model or "").strip()
    if not value or value.lower() in LEGACY_PRIMARY_MODELS:
        return DEFAULT_MODEL
    return value


def economical_model(configured_model: str = "") -> str:
    """Backward-compatible alias used by older SAI UI code."""
    return quality_model(configured_model)
