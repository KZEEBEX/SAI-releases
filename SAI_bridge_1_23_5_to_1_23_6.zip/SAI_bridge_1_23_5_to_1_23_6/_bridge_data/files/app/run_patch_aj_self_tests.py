#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused regression checks for SAI v1.22.7aj."""
from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
app_dir = root / "app"
ui_path = app_dir / "sai_pyside_preview.py"
version_path = app_dir / "sai_version.py"
self_tests_path = app_dir / "run_self_tests.py"
wiki_dir = root / "SAI_Ecosystem_Wiki_v0.1"

for source in (ui_path, version_path, self_tests_path):
    text = source.read_text(encoding="utf-8-sig")
    ast.parse(text, filename=str(source))

ui = ui_path.read_text(encoding="utf-8-sig")
version = version_path.read_text(encoding="utf-8-sig")
self_tests = self_tests_path.read_text(encoding="utf-8-sig")

assert 'VERSION = "1.22.7aj"' in version

# Night theme: first-run form and both startup splash implementations.
assert 'QLabel#StartupTitle' in ui
assert 'QLabel#StartupSubtitle' in ui
assert 'QLabel#StartupStatus' in ui
assert 'QPushButton#StartupPrimary:disabled' in ui
assert 'QPushButton#StartupSecondary' in ui
assert 'dark = bool(app and app.property("saiNightTheme"))' in ui
assert 'QColor("#f8fafc" if dark else "#081830")' in ui
assert 'QWidget#SplashPage,' in ui

# Price tags: scanner-oriented barcode rendering is removed from this page.
assert 'Предпросмотр для сканера' not in ui
price_start = ui.index('class PriceTagsPage(QWidget):')
price_end = ui.index('\nclass ', price_start + 10)
price_page = ui[price_start:price_end]
assert 'self.barcode_preview = QLabel()' not in price_page
assert 'self.barcode_kind_label.setText' in price_page

# AI invoice drag-and-drop uses the same source-selection workflow.
assert 'class InvoiceDropFrame(QFrame):' in ui
assert 'files_dropped = Signal(object)' in ui
assert 'card.files_dropped.connect(self.set_source_paths)' in ui
assert 'self.setAcceptDrops(True)' in ui[ui.index('class ConverterPage(QWidget):'):ui.index('class PriceTagsPage(QWidget):')]
assert 'def set_source_paths(self, raw_paths: object)' in ui
assert 'sai_openai_invoice.SUPPORTED_EXTENSIONS' in ui
assert 'QFrame#WorkbenchCard[dropTarget="true"][dragActive="true"]' in ui

# The general release gate must reflect the current invoice-agent contract.
assert '"gpt-5.6-luna", "Legacy Sol/default model migration"' in self_tests
assert 'APP_VERSION == "v1.22.7aj"' in self_tests

manifest = json.loads((wiki_dir / "wiki_manifest.json").read_text(encoding="utf-8"))
assert manifest["wiki_version"] == "2.1"
assert manifest["snapshot_sai_version"] == "1.22.7aj"
assert (wiki_dir / "README.md").read_text(encoding="utf-8").find("v1.22.7aj") >= 0
assert (wiki_dir / "CHANGELOG.md").read_text(encoding="utf-8").startswith("## v2.1 / SAI 1.22.7aj")

print("PATCH_AJ_SELF_TEST_OK")
