#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Runtime checks for the active-draft counter on the receipt hub."""
from __future__ import annotations

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import sai_pyside_preview as ui


def main() -> None:
    app = ui.QApplication.instance() or ui.QApplication([])
    original = ui.sai_receipt_drafts.list_active
    try:
        ui.sai_receipt_drafts.list_active = lambda: [{"id": "a"}, {"id": "b"}, {"id": "c"}]
        hub = ui.ReceiptUxPreviewPage(None)
        hub.refresh_draft_badges()
        assert hub._draft_buttons, "Draft action button was not created"
        button = hub._draft_buttons[0]
        assert button._draft_count == 3
        assert button.badge_label.text() == "3"
        assert not button.badge_label.isHidden()
        texts = [label.text() for label in hub.findChildren(ui.QLabel)]
        assert "Составить накладную вручную" in texts

        ui.sai_receipt_drafts.list_active = lambda: []
        hub.refresh_draft_badges()
        assert button._draft_count == 0
        assert button.badge_label.isHidden()
        hub.deleteLater()
    finally:
        ui.sai_receipt_drafts.list_active = original
    app.processEvents()
    print("Draft badge tests passed.")


if __name__ == "__main__":
    main()
