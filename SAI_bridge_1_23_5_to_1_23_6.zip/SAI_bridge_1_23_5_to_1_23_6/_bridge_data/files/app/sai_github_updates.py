#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Read and download verified SAI releases from the public GitHub channel.

The source repository is deliberately not used here.  Clients only read the
public ``KZEEBEX/SAI-releases`` repository and accept a package described by
the ``sai-update.json`` asset attached to a GitHub Release.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping, Optional
from urllib.parse import urlparse

from sai_runtime_paths import USER_DATA_DIR


REPOSITORY = "KZEEBEX/SAI-releases"
API_ROOT = f"https://api.github.com/repos/{REPOSITORY}"
MANIFEST_NAME = "sai-update.json"
DOWNLOAD_DIR = USER_DATA_DIR / "updates"
MAX_MANIFEST_BYTES = 256 * 1024
MAX_RELEASE_LIST_BYTES = 2 * 1024 * 1024
MAX_PACKAGE_BYTES = 2 * 1024 * 1024 * 1024
USER_AGENT = "SAI-Updater/1.0"


class UpdateCheckError(RuntimeError):
    """The release channel returned an incomplete or unsafe response."""


@dataclass(frozen=True)
class ReleaseUpdate:
    version: str
    tag: str
    channel: str
    package_name: str
    package_url: str
    sha256: str
    size: int
    release_url: str = ""
    published_at: str = ""
    notes: str = ""


def version_key(value: Any) -> tuple[tuple[int, ...], int, int, int]:
    text = str(value or "").strip().lower().lstrip("v")
    match = re.fullmatch(r"(\d+(?:\.\d+)*)([a-z]*)(?:[-._]?dev(?:[-._]?(\d+))?)?", text)
    if not match:
        return ((0,), 0, 0, 0)
    numbers = tuple(int(part) for part in match.group(1).split("."))
    suffix_value = 0
    for char in match.group(2):
        suffix_value = suffix_value * 26 + (ord(char) - ord("a") + 1)
    is_development = "dev" in text
    return numbers, suffix_value, 0 if is_development else 1, int(match.group(3) or 0)


def _request(url: str) -> urllib.request.Request:
    return urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "User-Agent": USER_AGENT,
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )


def _read_bytes(response: Any, limit: int) -> bytes:
    data = response.read(limit + 1)
    if len(data) > limit:
        raise UpdateCheckError("Файл канала обновлений превышает допустимый размер.")
    return data


def _read_json_value(url: str, opener: Callable[..., Any], limit: int = MAX_MANIFEST_BYTES) -> Any:
    try:
        with opener(_request(url), timeout=20) as response:
            raw = _read_bytes(response, limit)
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {}
        raise UpdateCheckError(f"GitHub вернул HTTP {exc.code}.") from exc
    except (OSError, urllib.error.URLError) as exc:
        raise UpdateCheckError(f"Не удалось связаться с GitHub: {exc}") from exc
    try:
        value = json.loads(raw.decode("utf-8-sig"))
    except Exception as exc:
        raise UpdateCheckError("GitHub вернул повреждённое описание обновления.") from exc
    return value


def _read_json(url: str, opener: Callable[..., Any], limit: int = MAX_MANIFEST_BYTES) -> Mapping[str, Any]:
    value = _read_json_value(url, opener, limit)
    if not isinstance(value, dict):
        raise UpdateCheckError("Описание обновления имеет неверный формат.")
    return value


def _safe_download_url(value: Any) -> str:
    url = str(value or "").strip()
    parsed = urlparse(url)
    if parsed.scheme != "https" or parsed.hostname not in {"github.com", "api.github.com"}:
        raise UpdateCheckError("В релизе указан небезопасный адрес загрузки.")
    expected_prefix = f"/{REPOSITORY}/"
    if parsed.hostname == "github.com" and not parsed.path.startswith(expected_prefix):
        raise UpdateCheckError("Пакет обновления находится вне официального репозитория SAI.")
    return url


def _safe_package_name(value: Any) -> str:
    name = str(value or "").strip()
    if not name or Path(name).name != name or name in {".", ".."}:
        raise UpdateCheckError("В манифесте указано небезопасное имя пакета.")
    if Path(name).suffix.casefold() not in {".exe", ".msi", ".cmd", ".bat", ".zip"}:
        raise UpdateCheckError("Формат пакета обновления не поддерживается.")
    return name


def check_for_update(
    current_version: str,
    *,
    channel: str = "production",
    opener: Callable[..., Any] = urllib.request.urlopen,
) -> Optional[ReleaseUpdate]:
    """Return a newer verified release description, or ``None``.

    Normal clients query GitHub's ``latest`` endpoint, which excludes
    pre-releases.  The development channel is explicit and never selected by
    a production installation accidentally.
    """
    normalized_channel = str(channel or "production").strip().casefold()
    if normalized_channel not in {"production", "development"}:
        raise ValueError("Неизвестный канал обновлений.")
    endpoint = f"{API_ROOT}/releases/latest" if normalized_channel == "production" else f"{API_ROOT}/releases?per_page=30"
    raw_payload = _read_json_value(
        endpoint,
        opener,
        MAX_RELEASE_LIST_BYTES if normalized_channel == "development" else MAX_MANIFEST_BYTES,
    )
    if normalized_channel == "production":
        if not isinstance(raw_payload, dict):
            raise UpdateCheckError("GitHub вернул неверный список production-релизов.")
        releases = [raw_payload]
    else:
        if not isinstance(raw_payload, list):
            raise UpdateCheckError("GitHub вернул неверный список тестовых релизов.")
        releases = [row for row in raw_payload if isinstance(row, dict)]

    candidates: list[ReleaseUpdate] = []
    first_error: Optional[Exception] = None
    for payload in releases:
        if not payload or bool(payload.get("draft")):
            continue
        tag = str(payload.get("tag_name") or "").strip()
        if tag and version_key(tag) <= version_key(current_version):
            continue
        is_prerelease = bool(payload.get("prerelease"))
        if normalized_channel == "production" and is_prerelease:
            continue
        expected_channel = "development" if is_prerelease else "production"
        try:
            candidate = _update_from_release(payload, current_version, expected_channel, opener)
        except UpdateCheckError as exc:
            if first_error is None:
                first_error = exc
            continue
        if candidate is not None:
            candidates.append(candidate)
    if candidates:
        return max(candidates, key=lambda item: version_key(item.version))
    if first_error is not None:
        raise first_error
    return None


def _update_from_release(
    payload: Mapping[str, Any],
    current_version: str,
    expected_channel: str,
    opener: Callable[..., Any],
) -> Optional[ReleaseUpdate]:
    """Validate one GitHub release and return it when it is newer."""

    tag = str(payload.get("tag_name") or "").strip()
    assets = payload.get("assets") if isinstance(payload.get("assets"), list) else []
    asset_by_name = {
        str(asset.get("name") or "").strip(): asset
        for asset in assets if isinstance(asset, dict)
    }
    manifest_asset = asset_by_name.get(MANIFEST_NAME)
    if not isinstance(manifest_asset, dict):
        raise UpdateCheckError(f"В релизе {tag or 'без тега'} нет файла {MANIFEST_NAME}.")
    manifest_url = _safe_download_url(manifest_asset.get("browser_download_url"))
    manifest = _read_json(manifest_url, opener)

    if int(manifest.get("schema_version") or 0) != 1:
        raise UpdateCheckError("Версия формата манифеста обновления не поддерживается.")
    manifest_channel = str(manifest.get("channel") or "").strip().casefold()
    if manifest_channel != expected_channel:
        raise UpdateCheckError(f"Релиз содержит манифест канала {manifest_channel or 'не указан'}, ожидался {expected_channel}.")
    version = str(manifest.get("version") or "").strip().lstrip("v")
    if not version or version_key(version) == version_key(""):
        raise UpdateCheckError("В манифесте отсутствует корректный номер версии.")
    if tag and version_key(tag) != version_key(version):
        raise UpdateCheckError("Версия манифеста не совпадает с тегом GitHub Release.")
    if version_key(version) <= version_key(current_version):
        return None

    package_name = _safe_package_name(manifest.get("package"))
    package_asset = asset_by_name.get(package_name)
    if not isinstance(package_asset, dict):
        raise UpdateCheckError(f"В GitHub Release отсутствует пакет {package_name}.")
    sha256 = str(manifest.get("sha256") or "").strip().casefold()
    if not re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise UpdateCheckError("В манифесте отсутствует корректная SHA-256.")
    declared_size = int(manifest.get("size") or 0)
    asset_size = int(package_asset.get("size") or 0)
    if declared_size <= 0 or declared_size != asset_size or declared_size > MAX_PACKAGE_BYTES:
        raise UpdateCheckError("Размер пакета не совпадает с манифестом или превышает лимит.")

    return ReleaseUpdate(
        version=version,
        tag=tag or f"v{version}",
        channel=manifest_channel,
        package_name=package_name,
        package_url=_safe_download_url(package_asset.get("browser_download_url")),
        sha256=sha256,
        size=declared_size,
        release_url=str(payload.get("html_url") or "").strip(),
        published_at=str(payload.get("published_at") or "").strip(),
        notes=str(payload.get("body") or "").strip(),
    )


def download_update(
    update: ReleaseUpdate,
    *,
    destination: Path = DOWNLOAD_DIR,
    opener: Callable[..., Any] = urllib.request.urlopen,
) -> Path:
    """Download atomically and return the package only after SHA-256 passes."""
    name = _safe_package_name(update.package_name)
    url = _safe_download_url(update.package_url)
    destination.mkdir(parents=True, exist_ok=True)
    target = destination / name
    temporary = destination / f".{name}.{os.getpid()}.download"
    digest = hashlib.sha256()
    written = 0
    try:
        with opener(_request(url), timeout=120) as response, temporary.open("wb") as stream:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                written += len(block)
                if written > MAX_PACKAGE_BYTES or written > update.size:
                    raise UpdateCheckError("Загружаемый пакет имеет неожиданный размер.")
                digest.update(block)
                stream.write(block)
        if written != update.size:
            raise UpdateCheckError("Пакет обновления загрузился не полностью.")
        if digest.hexdigest().casefold() != update.sha256.casefold():
            raise UpdateCheckError("Контрольная сумма обновления SAI не совпадает.")
        os.replace(temporary, target)
        return target
    finally:
        try:
            if temporary.exists():
                temporary.unlink()
        except OSError:
            pass
