#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""CLI for the permanent SAI patch acceptance gate."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

from sai_patch_acceptance import run_acceptance


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the SAI patch acceptance gate")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--python", type=Path, default=None)
    parser.add_argument("--report", type=Path, default=None)
    parser.add_argument("--keep-going", action="store_true", help="Collect all failures instead of stopping at the first")
    args = parser.parse_args(argv)
    try:
        report = run_acceptance(args.root, python=args.python, report_path=args.report, keep_going=args.keep_going)
    except Exception as exc:
        print("", flush=True)
        print("PATCH REJECTED", flush=True)
        print(str(exc), flush=True)
        return 1
    print("", flush=True)
    print("=" * 78, flush=True)
    print("UPDATED FEATURE: PASS", flush=True)
    print("ADJACENT SCENARIOS: PASS", flush=True)
    print("PUBLIC API: PASS", flush=True)
    print("USER DATA INTEGRITY: PASS", flush=True)
    print("APPLICATION IMPORT: PASS", flush=True)
    print(f"TESTS COMPLETED: {len(report.tests)}", flush=True)
    print("PATCH ACCEPTED", flush=True)
    print("=" * 78, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
