#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Invoice source validation and visual preparation for the SAI AI pipeline.

This module owns file limits, MIME encoding, operator-confirmed page rendering,
and targeted row crops. It performs no network calls and has no knowledge of
model routing or invoice reconciliation.
"""
from __future__ import annotations

import base64
import mimetypes
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

import sai_page_orientation
from sai_invoice_ai_errors import OpenAIInvoiceError

MAX_FILE_BYTES = 50 * 1024 * 1024
MAX_TOTAL_BYTES = 50 * 1024 * 1024
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
FILE_EXTENSIONS = {
    ".pdf", ".txt", ".md", ".json", ".html", ".htm", ".xml", ".rtf",
    ".doc", ".docx", ".odt", ".ppt", ".pptx", ".csv", ".tsv", ".iif",
    ".xls", ".xlsx", ".xlsm", ".xlt", ".xltx", ".ods", ".zip",
}
SUPPORTED_EXTENSIONS = IMAGE_EXTENSIONS | FILE_EXTENSIONS


def mime_for(path: Path) -> str:
    explicit = {
        ".pdf": "application/pdf",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
        ".xls": "application/vnd.ms-excel",
        ".csv": "text/csv",
        ".tsv": "text/tab-separated-values",
        ".xml": "application/xml",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".doc": "application/msword",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".ppt": "application/vnd.ms-powerpoint",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".webp": "image/webp",
        ".gif": "image/gif",
        ".zip": "application/zip",
    }
    return explicit.get(path.suffix.lower()) or mimetypes.guess_type(path.name)[0] or "application/octet-stream"


def validate_source_paths(paths: Sequence[str | Path]) -> List[Path]:
    result: List[Path] = []
    total = 0
    for raw in paths:
        path = Path(raw).expanduser().resolve()
        if not path.is_file():
            raise OpenAIInvoiceError(f"Файл не найден: {path}")
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise OpenAIInvoiceError(
                f"Формат {path.suffix or '(без расширения)'} пока не поддерживается: {path.name}"
            )
        size = path.stat().st_size
        if size > MAX_FILE_BYTES:
            raise OpenAIInvoiceError(f"Файл больше 50 МБ: {path.name}")
        total += size
        if total > MAX_TOTAL_BYTES:
            raise OpenAIInvoiceError("Общий размер выбранных файлов превышает 50 МБ.")
        result.append(path)
    if not result:
        raise OpenAIInvoiceError("Не выбраны файлы накладной.")
    return result


def image_data_url(data: bytes, mime: str = "image/jpeg") -> str:
    return f"data:{mime};base64," + base64.b64encode(data).decode("ascii")


def odt_text(path: Path) -> str:
    """Extract readable ODT paragraphs locally; the OpenAI file API does not accept ODT."""
    try:
        with zipfile.ZipFile(path) as archive:
            content = archive.read("content.xml")
        root = ET.fromstring(content)
        paragraphs: List[str] = []
        for element in root.iter():
            if element.tag.endswith("}p") or element.tag.endswith("}h"):
                value = re.sub(r"\s+", " ", "".join(element.itertext())).strip()
                if value:
                    paragraphs.append(value)
        result = "\n".join(paragraphs).strip()
    except Exception as exc:
        raise OpenAIInvoiceError(f"Не удалось прочитать ODT {path.name}: {exc}") from exc
    if not result:
        raise OpenAIInvoiceError(f"В ODT нет читаемого текста: {path.name}")
    return result


def quantity_name_key(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").upper().replace("Ё", "Е")).strip()


def ambiguous_quantity_hints(paths: Sequence[str | Path]) -> Dict[str, str]:
    """Return XLSX quantity strings such as 2/15 that must stay operator-visible."""
    hints: Dict[str, str] = {}
    try:
        from openpyxl import load_workbook
    except Exception:
        return hints
    for raw_path in paths:
        path = Path(raw_path)
        if path.suffix.lower() not in {".xlsx", ".xlsm", ".xltx"}:
            continue
        try:
            workbook = load_workbook(str(path), data_only=False, read_only=True)
            try:
                for sheet in workbook.worksheets:
                    header_row = name_column = quantity_column = 0
                    for row_number in range(1, min(sheet.max_row, 25) + 1):
                        for cell in sheet[row_number]:
                            header = re.sub(r"\s+", " ", str(cell.value or "").casefold()).strip()
                            if "наимен" in header:
                                name_column = int(cell.column)
                            if "колич" in header or header in {"кол-во", "кол."}:
                                quantity_column = int(cell.column)
                        if name_column and quantity_column:
                            header_row = row_number
                            break
                    if not header_row:
                        continue
                    for row_number in range(header_row + 1, sheet.max_row + 1):
                        name = quantity_name_key(sheet.cell(row_number, name_column).value)
                        value = str(sheet.cell(row_number, quantity_column).value or "").strip()
                        if name and re.fullmatch(r"\d+(?:[.,]\d+)?\s*/\s*\d+(?:[.,]\d+)?", value):
                            hints[name] = value
            finally:
                workbook.close()
        except Exception:
            continue
    return hints


def qimage_jpeg_bytes(image: Any, quality: int = 88) -> bytes:
    from PySide6.QtCore import QByteArray, QBuffer, QIODevice

    data_array = QByteArray()
    buffer = QBuffer(data_array)
    buffer.open(QIODevice.WriteOnly)
    image.save(buffer, "JPG", int(quality))
    buffer.close()
    return bytes(data_array)


def overlapping_horizontal_bands(image: Any, count: int = 4, overlap_ratio: float = 0.12) -> List[Any]:
    """Split a page into readable full-width row bands while retaining boundary rows."""
    from PySide6.QtCore import QRect

    count = max(1, int(count))
    height = max(1, int(image.height()))
    width = max(1, int(image.width()))
    base = height / float(count)
    overlap = max(8, int(base * float(overlap_ratio)))
    result = []
    for index in range(count):
        top = max(0, int(index * base) - overlap)
        bottom = min(height, int((index + 1) * base) + overlap)
        if bottom > top:
            result.append(image.copy(QRect(0, top, width, bottom - top)))
    return result


def row_groups_for_targets(
    draft: Mapping[str, Any] | None,
    target_rows: Sequence[int] | None,
) -> Dict[int, List[Dict[str, Any]]]:
    """Build compact row ranges for cropped Terra/Sol verification views."""
    wanted = {int(x) for x in (target_rows or []) if int(x) > 0}
    if not wanted or not isinstance(draft, Mapping):
        return {}
    by_page: Dict[int, List[int]] = {}
    for pos, row in enumerate(draft.get("items") or [], start=1):
        try:
            number = int(row.get("source_row") or pos)
        except Exception:
            number = pos
        try:
            page = max(1, int(row.get("source_page") or 1))
        except Exception:
            page = 1
        by_page.setdefault(page, []).append(number)
    result: Dict[int, List[Dict[str, Any]]] = {}
    for page, numbers in by_page.items():
        ordered = sorted(dict.fromkeys(numbers))
        selected = [index for index, number in enumerate(ordered) if number in wanted]
        if not selected:
            continue
        clusters: List[tuple[int, int]] = []
        start = previous = selected[0]
        for index in selected[1:]:
            if index <= previous + 1:
                previous = index
                continue
            clusters.append((start, previous))
            start = previous = index
        clusters.append((start, previous))
        groups = []
        for start_index, end_index in clusters:
            groups.append({
                "start_index": start_index,
                "end_index": end_index,
                "total_rows": max(1, len(ordered)),
                "source_rows": ordered[start_index:end_index + 1],
            })
        result[page] = groups
    return result


def row_crop_rect(image: Any, page_number: int, group: Mapping[str, Any]) -> Any:
    """Return a generous full-width crop around one or more estimated table rows."""
    from PySide6.QtCore import QRect

    height = max(1, int(image.height()))
    width = max(1, int(image.width()))
    total = max(1, int(group.get("total_rows") or 1))
    start = max(0, int(group.get("start_index") or 0))
    end = max(start, int(group.get("end_index") or start))
    table_top = 0.19 if int(page_number) == 1 else 0.08
    table_bottom = 0.92
    usable = max(1.0, (table_bottom - table_top) * height)
    row_height = usable / float(total)
    y0 = int(table_top * height + (start - 1.15) * row_height)
    y1 = int(table_top * height + (end + 2.15) * row_height)
    minimum = max(260, int(height * 0.13))
    if y1 - y0 < minimum:
        center = (y0 + y1) // 2
        y0 = center - minimum // 2
        y1 = y0 + minimum
    y0 = max(0, y0)
    y1 = min(height, max(y0 + 1, y1))
    return image.copy(QRect(0, y0, width, y1 - y0))


def visual_rotation_label(angle: int) -> str:
    return sai_page_orientation.angle_label(angle)


def render_prepared_visual_views(
    paths: Sequence[Path],
    orientation_plan: Mapping[str, Sequence[Any]] | None = None,
    include_bands: bool = False,
    target_global_pages: Sequence[int] | None = None,
    target_row_groups: Mapping[int, Sequence[Mapping[str, Any]]] | None = None,
    max_pages: int = 40,
    max_bytes: int = 36 * 1024 * 1024,
) -> tuple[List[tuple[Path, str, bytes]], set[Path]]:
    """Render operator-confirmed pages, optionally only global page numbers.

    Global page numbers follow the same order in which visual files/pages were
    selected by the operator: first page is 1, next is 2, and so on.
    """
    views: List[tuple[Path, str, bytes]] = []
    complete_paths: set[Path] = set()
    used_bytes = 0
    rendered_pages = 0
    visual_page_number = 0
    target_pages = {int(x) for x in (target_global_pages or []) if int(x) > 0}
    row_groups = {int(page): list(groups) for page, groups in dict(target_row_groups or {}).items()}
    try:
        from PySide6.QtCore import QSize
        from PySide6.QtGui import QImage
        from PySide6.QtPdf import QPdfDocument
    except Exception:
        return views, complete_paths

    for path in paths:
        suffix = path.suffix.lower()
        resolved = path.resolve()
        path_views: List[tuple[Path, str, bytes]] = []
        path_bytes = 0
        path_ok = True
        selected_for_path = 0
        if suffix == ".pdf":
            try:
                doc = QPdfDocument()
                doc.load(str(path))
                expected = max(0, int(doc.pageCount()))
                if expected <= 0:
                    path_ok = False
                for page in range(expected):
                    visual_page_number += 1
                    if target_pages and visual_page_number not in target_pages:
                        continue
                    selected_for_path += 1
                    if rendered_pages >= max_pages:
                        path_ok = False
                        break
                    points = doc.pagePointSize(page)
                    if points.width() <= 0 or points.height() <= 0:
                        path_ok = False
                        break
                    scale = 3600.0 / max(points.width(), points.height())
                    image = doc.render(
                        page,
                        QSize(max(1, int(points.width() * scale)), max(1, int(points.height() * scale))),
                    )
                    if image.isNull():
                        path_ok = False
                        break
                    angle = sai_page_orientation.angle_for_page(path, page, orientation_plan)
                    prepared = sai_page_orientation.apply_rotation(image, angle)
                    operator_crop = sai_page_orientation.crop_for_page(path, page, orientation_plan)
                    prepared = sai_page_orientation.apply_crop(prepared, operator_crop)
                    page_scope = "область, выбранная оператором" if operator_crop else "полный лист"
                    groups = row_groups.get(visual_page_number) or []
                    if groups:
                        page_parts = []
                        for group in groups:
                            crop = row_crop_rect(prepared, visual_page_number, group)
                            rows = ", ".join(str(int(x)) for x in (group.get("source_rows") or []))
                            page_parts.append((
                                path,
                                f"{path.name}, страница SAI {visual_page_number}, PDF-страница {page + 1}, {visual_rotation_label(angle)}, увеличенный фрагмент source_row {rows}",
                                qimage_jpeg_bytes(crop, 94),
                            ))
                    else:
                        page_parts = [(
                            path,
                            f"{path.name}, страница SAI {visual_page_number}, PDF-страница {page + 1}, {visual_rotation_label(angle)}, {page_scope}",
                            qimage_jpeg_bytes(prepared, 88),
                        )]
                        if include_bands:
                            bands = overlapping_horizontal_bands(prepared, 4, 0.14)
                            for band_index, band in enumerate(bands, start=1):
                                page_parts.append((
                                    path,
                                    f"{path.name}, страница SAI {visual_page_number}, PDF-страница {page + 1}, {visual_rotation_label(angle)}, увеличенная полоса {band_index}/{len(bands)}",
                                    qimage_jpeg_bytes(band, 92),
                                ))
                    page_size = sum(len(item[2]) for item in page_parts)
                    if used_bytes + path_bytes + page_size > max_bytes:
                        path_ok = False
                        break
                    path_views.extend(page_parts)
                    path_bytes += page_size
                    rendered_pages += 1
                try:
                    doc.close()
                except Exception:
                    pass
            except Exception:
                path_ok = False
        elif suffix in IMAGE_EXTENSIONS:
            visual_page_number += 1
            if not target_pages or visual_page_number in target_pages:
                selected_for_path = 1
                try:
                    if rendered_pages >= max_pages:
                        path_ok = False
                    else:
                        image = QImage(str(path))
                        if image.isNull():
                            path_ok = False
                        else:
                            angle = sai_page_orientation.angle_for_page(path, 0, orientation_plan)
                            prepared = sai_page_orientation.apply_rotation(image, angle)
                            operator_crop = sai_page_orientation.crop_for_page(path, 0, orientation_plan)
                            prepared = sai_page_orientation.apply_crop(prepared, operator_crop)
                            page_scope = "область, выбранная оператором" if operator_crop else "полный лист"
                            groups = row_groups.get(visual_page_number) or []
                            if groups:
                                page_parts = []
                                for group in groups:
                                    crop = row_crop_rect(prepared, visual_page_number, group)
                                    rows = ", ".join(str(int(x)) for x in (group.get("source_rows") or []))
                                    page_parts.append((
                                        path,
                                        f"{path.name}, страница SAI {visual_page_number}, изображение, {visual_rotation_label(angle)}, увеличенный фрагмент source_row {rows}",
                                        qimage_jpeg_bytes(crop, 94),
                                    ))
                            else:
                                page_parts = [(
                                    path,
                                    f"{path.name}, страница SAI {visual_page_number}, изображение, {visual_rotation_label(angle)}, {page_scope}",
                                    qimage_jpeg_bytes(prepared, 90),
                                )]
                                if include_bands:
                                    bands = overlapping_horizontal_bands(prepared, 4, 0.14)
                                    for band_index, band in enumerate(bands, start=1):
                                        page_parts.append((
                                            path,
                                            f"{path.name}, страница SAI {visual_page_number}, изображение, {visual_rotation_label(angle)}, увеличенная полоса {band_index}/{len(bands)}",
                                            qimage_jpeg_bytes(band, 92),
                                        ))
                            path_bytes = sum(len(item[2]) for item in page_parts)
                            if used_bytes + path_bytes > max_bytes:
                                path_ok = False
                            else:
                                path_views.extend(page_parts)
                                rendered_pages += 1
                except Exception:
                    path_ok = False
        else:
            continue
        if path_ok and path_views:
            views.extend(path_views)
            used_bytes += path_bytes
            complete_paths.add(resolved)
        elif selected_for_path and not path_ok:
            # A selected visual page failed; caller must stop before a paid request.
            continue
    return views, complete_paths


def append_sources(
    content: List[Dict[str, Any]],
    paths: Sequence[Path],
    prepared_visuals: bool = False,
    precision_views: bool = False,
    orientation_plan: Mapping[str, Sequence[Any]] | None = None,
    target_global_pages: Sequence[int] | None = None,
    target_row_groups: Mapping[int, Sequence[Mapping[str, Any]]] | None = None,
) -> tuple[bool, int]:
    rendered_paths: set[Path] = set()
    view_count = 0
    if prepared_visuals:
        views, rendered_paths = render_prepared_visual_views(
            paths,
            orientation_plan,
            include_bands=precision_views,
            target_global_pages=target_global_pages,
            target_row_groups=target_row_groups,
        )
        required_visual = {
            path.resolve() for path in paths if path.suffix.lower() in ({".pdf"} | IMAGE_EXTENSIONS)
        }
        if target_global_pages:
            expected_targets = len({int(x) for x in target_global_pages if int(x) > 0})
            if target_row_groups:
                covered = sum(1 for page in target_row_groups if target_row_groups.get(page))
                if required_visual and (not views or covered != expected_targets):
                    raise OpenAIInvoiceError("Не удалось подготовить увеличенные фрагменты проблемных строк.")
            else:
                full_views = sum(
                    1 for _source, label, _data in views
                    if "полный лист" in label or "область, выбранная оператором" in label
                )
                if required_visual and (not views or full_views != expected_targets):
                    raise OpenAIInvoiceError(
                        "Не удалось полностью подготовить целевые страницы для точечной проверки AI."
                    )
        else:
            missing = sorted(
                path.name for path in paths if path.resolve() in (required_visual - rendered_paths)
            )
            if missing:
                raise OpenAIInvoiceError(
                    "Не удалось полностью подготовить визуальные страницы до запроса: "
                    + ", ".join(missing)
                    + ". Проверь файлы или уменьши размер комплекта."
                )
        for _source_path, label, data in views:
            view_count += 1
            content.append({
                "type": "input_text",
                "text": "SAI подготовил изображение документа: "
                + label
                + ". Это источник истины; не дублируй товары из перекрывающихся фрагментов.",
            })
            content.append({"type": "input_image", "image_url": image_data_url(data), "detail": "high"})
    for path in paths:
        if path.suffix.lower() in ({".pdf"} | IMAGE_EXTENSIONS) and (
            path.resolve() in rendered_paths or target_global_pages
        ):
            continue
        if path.suffix.lower() == ".odt":
            content.append({
                "type": "input_text",
                "text": (
                    f"Текст документа {path.name}, извлечённый SAI из ODT. "
                    "Это источник истины; сохрани порядок товарных строк:\n"
                    + odt_text(path)
                ),
            })
            continue
        encoded = base64.b64encode(path.read_bytes()).decode("ascii")
        data_url = f"data:{mime_for(path)};base64,{encoded}"
        if path.suffix.lower() in IMAGE_EXTENSIONS:
            content.append({"type": "input_image", "image_url": data_url, "detail": "high"})
        else:
            content.append({"type": "input_file", "filename": path.name, "file_data": data_url})
    return bool(rendered_paths), view_count
