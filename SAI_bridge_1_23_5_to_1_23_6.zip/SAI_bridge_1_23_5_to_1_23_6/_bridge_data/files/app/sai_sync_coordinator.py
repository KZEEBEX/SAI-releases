"""Cross-process source freshness and duplicate suppression.

Execute on a worker, never the Qt thread. A source failure does not erase its
last successful result. There is intentionally no automatic replay of writes.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import time
from typing import Callable
from sai_runtime_paths import CACHE_DIR
from sai_sigma_session import ProcessLock, SessionUnavailable, atomic_json, read_json

FRESHNESS_SECONDS = {"suppliers": 86400, "categories": 86400, "catalog": 14400, "stock": 600, "sales": 180, "warehouse": 180}


class SyncCoordinator:
    def __init__(self, directory: Path | None = None):
        self.directory = Path(directory or CACHE_DIR / "sync_status")

    def path(self, source: str, scope: str) -> Path:
        key = hashlib.sha256((source + "\0" + scope).encode()).hexdigest()[:24]
        return self.directory / (key + ".json")

    def snapshot(self, source: str, scope: str) -> dict:
        return read_json(self.path(source, scope))

    def run(self, source: str, scope: str, loader: Callable[[], dict], *, force: bool = False) -> dict:
        path = self.path(source, scope)
        lock = ProcessLock(path.with_suffix(".lock"), timeout=0)
        try:
            lock.__enter__()
        except SessionUnavailable:
            return {"ok": True, "refreshed": False, "_sync_state": "busy", "message": "Этот источник уже обновляется другим процессом SAI"}
        try:
            previous = read_json(path)
            try:
                age = time.time() - float(previous.get("success_at") or 0)
            except (ValueError, TypeError):
                age = float("inf")
            if not force and previous.get("state") == "ready" and isinstance(previous.get("result"), dict) and 0 <= age < FRESHNESS_SECONDS.get(source, 300):
                return {**previous.get("result", {}), "refreshed": False, "_sync_state": "fresh"}
            started = time.time()
            atomic_json(path, {**previous, "source": source, "state": "running", "started_at": started})
            try:
                result = loader()
                if result.get("ok") is False or result.get("refreshed") is False or result.get("source_errors"):
                    atomic_json(path, {**previous, "source": source, "state": "error", "finished_at": time.time()})
                    return {**result, "_sync_state": "error"}
                atomic_json(path, {
                    "source": source, "state": "ready", "success_at": time.time(),
                    "duration": time.time() - started, "result": result,
                })
                return {**result, "_sync_state": "ready"}
            except Exception:
                atomic_json(path, {**previous, "source": source, "state": "error", "finished_at": time.time()})
                raise
        finally:
            lock.__exit__(None, None, None)
