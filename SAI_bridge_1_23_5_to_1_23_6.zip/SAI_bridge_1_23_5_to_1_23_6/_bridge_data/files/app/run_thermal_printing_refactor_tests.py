#!/usr/bin/env python
"""Regression tests for extracted thermal label rendering and TSPL transport."""
from __future__ import annotations

import ast
import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from sai_thermal_printing import (
    THERMAL_LABEL_PROFILES,
    build_tspl_payload,
    mm_to_dots,
    normalize_thermal_config,
    page_size_matches_label,
    qimage_to_tspl_bitmap_bytes,
    render_thermal_label,
    resolve_windows_printer_name,
)
from sai_datamatrix import encode_ecc200
from sai_thermal_text import normalize_thermal_text, render_thermal_text_label

HERE = Path(__file__).resolve().parent


def main() -> None:
    app = QApplication.instance() or QApplication([])
    cfg = normalize_thermal_config({"thermal_label_size": "58×40", "thermal_label_scale_percent": 999})
    assert cfg["size"] == "58x40" and cfg["scale_percent"] == 160
    item = {"name": "ТЕСТОВЫЙ ТОВАР", "barcode": "10000542", "price": 123, "unit": "шт"}
    image = render_thermal_label(item, "58x40", cfg)
    profile = THERMAL_LABEL_PROFILES["58x40"]
    assert image.width() == mm_to_dots(profile["w_mm"])
    assert image.height() == mm_to_dots(profile["h_mm"])
    row_bytes, height, bitmap = qimage_to_tspl_bitmap_bytes(image)
    assert row_bytes == (image.width() + 7) // 8 and height == image.height()
    assert len(bitmap) == row_bytes * height
    payload = build_tspl_payload(image, "58x40", 2)
    assert payload.startswith(b"SIZE 58.0 mm,40.0 mm\r\n")
    assert b"BITMAP 0,0," in payload and payload.endswith(b"PRINT 1,2\r\n")

    compact_cfg = normalize_thermal_config({"thermal_label_size": "43×25"})
    compact_cfg.update({
        "printer": "4BARCODE 4B-2083B (Copy 1)",
        "method": "raw",
        "invert_tspl": True,
        "offset_y_tenth_mm": -7,
    })
    normalized_twice = normalize_thermal_config(compact_cfg)
    assert normalized_twice["size"] == "43x25"
    assert normalized_twice["method"] == "raw"
    assert normalized_twice["printer"] == "4BARCODE 4B-2083B (Copy 1)"
    assert normalized_twice["invert_tspl"] is True
    assert normalized_twice["offset_y_tenth_mm"] == -7
    compact_image = render_thermal_label(item, "43x25", compact_cfg)
    compact_profile = THERMAL_LABEL_PROFILES["43x25"]
    assert compact_image.width() == mm_to_dots(compact_profile["w_mm"])
    assert compact_image.height() == mm_to_dots(compact_profile["h_mm"])
    compact_payload = build_tspl_payload(compact_image, "43x25", 1)
    assert compact_payload.startswith(b"SIZE 43.0 mm,25.0 mm\r\n")
    assert compact_payload.endswith(b"PRINT 1,1\r\n")

    tiny_cfg = normalize_thermal_config({"thermal_label_size": "30×20"})
    assert tiny_cfg["size"] == "30x20"
    tiny_image = render_thermal_label(item, "30x20", tiny_cfg)
    tiny_profile = THERMAL_LABEL_PROFILES["30x20"]
    assert tiny_image.width() == mm_to_dots(tiny_profile["w_mm"])
    assert tiny_image.height() == mm_to_dots(tiny_profile["h_mm"])
    # The tiny template intentionally ignores the title: only price and code
    # may affect its pixels.
    renamed = dict(item, name="СОВСЕМ ДРУГОЕ ДЛИННОЕ НАЗВАНИЕ")
    assert render_thermal_label(renamed, "30x20", tiny_cfg) == tiny_image
    tiny_payload = build_tspl_payload(tiny_image, "30x20", 3)
    assert tiny_payload.startswith(b"SIZE 30.0 mm,20.0 mm\r\n")
    assert tiny_payload.endswith(b"PRINT 1,3\r\n")

    matrix = encode_ecc200("4601234567893")
    assert len(matrix) == 14 and all(len(row) == 14 for row in matrix)
    assert all(matrix[-1]) and all(row[0] for row in matrix)
    assert matrix != encode_ecc200("4601234567894")
    dm_cfg = normalize_thermal_config({"thermal_label_size": "30x20", "thermal_label_code_mode": "datamatrix"})
    assert dm_cfg["code_mode"] == "datamatrix" and not dm_cfg["datamatrix_split"]
    dm_image = render_thermal_label(item, "30x20", dm_cfg)
    assert dm_image != tiny_image
    split_cfg = normalize_thermal_config({
        "thermal_label_size": "30x20",
        "thermal_label_code_mode": "datamatrix",
        "thermal_label_datamatrix_split": True,
    })
    assert split_cfg["datamatrix_split"] is True
    split_image = render_thermal_label(item, "30x20", split_cfg)
    assert split_image != dm_image

    assert normalize_thermal_text("  СКИДКА   20% \n  только сегодня  ") == "СКИДКА 20%\nтолько сегодня"
    for text_size in ("58x40", "43x25", "30x20"):
        text_image = render_thermal_text_label("СКИДКА\n20%", text_size, {"thermal_label_size": text_size})
        text_profile = THERMAL_LABEL_PROFILES[text_size]
        assert text_image.width() == mm_to_dots(text_profile["w_mm"])
        assert text_image.height() == mm_to_dots(text_profile["h_mm"])
        assert text_image != render_thermal_text_label("", text_size, {"thermal_label_size": text_size})
        ink = [
            (x, y)
            for y in range(text_image.height())
            for x in range(text_image.width())
            if text_image.pixelColor(x, y).value() < 220
        ]
        assert ink
        ink_center_x = (min(x for x, _ in ink) + max(x for x, _ in ink)) / 2
        ink_center_y = (min(y for _, y in ink) + max(y for _, y in ink)) / 2
        assert abs(ink_center_x - text_image.width() / 2) <= text_image.width() * 0.04
        assert abs(ink_center_y - text_image.height() / 2) <= text_image.height() * 0.04

    assert page_size_matches_label(43.0, 25.0, "43x25")
    assert page_size_matches_label(30.0, 20.0, "30x20")
    assert not page_size_matches_label(20.0, 30.0, "30x20")
    assert not page_size_matches_label(25.0, 43.0, "43x25")
    assert page_size_matches_label(43.8, 24.2, "43x25")
    assert not page_size_matches_label(58.0, 40.0, "43x25")
    assert not page_size_matches_label(210.0, 297.0, "43x25")

    installed = [
        "Pantum-P2200-Series",
        "4BARCODE 4B-2083B (Copy 1)",
        "4BARCODE 4B-2083B",
    ]
    assert resolve_windows_printer_name("4barcode 4b-2083b (copy 1)", installed) == "4BARCODE 4B-2083B (Copy 1)"
    assert resolve_windows_printer_name("Xprinter V1 BT", installed, "4BARCODE 4B-2083B (Copy 1)") == "4BARCODE 4B-2083B (Copy 1)"
    assert resolve_windows_printer_name("missing", installed, "Pantum-P2200-Series") == "4BARCODE 4B-2083B (Copy 1)"
    assert resolve_windows_printer_name("Pantum-P2200-Series", installed) == "Pantum-P2200-Series"
    assert resolve_windows_printer_name("Xprinter V1 BT", ["Pantum-P2200-Series"]) == ""

    ui = (HERE / "sai_pyside_preview.py").read_text(encoding="utf-8")
    tree = ast.parse(ui)
    forbidden = {"_build_tspl_payload", "_qimage_to_tspl_bitmap_bytes", "_send_raw_to_windows_printer", "_send_image_to_windows_printer", "_list_windows_printers", "_get_default_windows_printer"}
    remaining = {node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)}
    assert not forbidden & remaining, f"thermal internals leaked into UI: {sorted(forbidden & remaining)}"
    assert "from sai_thermal_printing import" in ui
    assert "ThermalTextPrintPage" in ui and '"Термо печать"' in ui
    assert 'self.quick_thermal_size_combo.addItem("30×20 мм", "30x20")' in ui
    assert 'split_label = QLabel("2 на этикетке")' in ui
    thermal_source = (HERE / "sai_thermal_printing.py").read_text(encoding="utf-8")
    assert "painter.drawImage(painter.viewport()" not in thermal_source
    assert "page_size_matches_label(actual_width, actual_height, size_key)" in thermal_source
    print("SAI thermal printing refactor tests: OK")
    app.processEvents()


if __name__ == "__main__":
    main()
