#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent aggregate test entry point for the complete invoice AI boundary."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
APP = ROOT / "app"
for script in (
    "run_legacy_xls_pagination_tests.py",
    "run_invoice_ai_source_tests.py",
    "run_invoice_ai_client_tests.py",
    "run_invoice_ai_reconciliation_tests.py",
    "run_invoice_ai_pipeline_tests.py",
    "run_invoice_manual_review_tests.py",
):
    subprocess.run([sys.executable, str(APP / script), str(ROOT)], cwd=APP, check=True)
print("INVOICE_AI_TEST_SUITE_OK")
