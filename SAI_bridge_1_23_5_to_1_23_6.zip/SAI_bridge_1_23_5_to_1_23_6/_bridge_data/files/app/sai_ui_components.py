"""Reusable Qt components; visual values come from sai_design_tokens."""
from pathlib import Path

from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QPushButton, QLineEdit, QDialog, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QVBoxLayout, QWidget,
)
from sai_design_tokens import METRICS

def button(text, role="secondary", parent=None):
    if role not in ("hero", "secondary", "danger"):
        raise ValueError("Unknown SAI button role")
    widget = QPushButton(text, parent)
    widget.setProperty("saiRole", role)
    widget.setCursor(Qt.PointingHandCursor)
    return widget

def field(text="", parent=None):
    widget = QLineEdit(text, parent)
    widget.setObjectName("WorkbenchInput")
    widget.setProperty("saiRole", "field")
    return widget

def set_state(widget, state=""):
    widget.setProperty("saiState", state)
    widget.style().unpolish(widget)
    widget.style().polish(widget)
    widget.update()

def dialog(title, parent=None):
    widget = QDialog(parent)
    widget.setWindowTitle(title)
    widget.setProperty("saiRole", "dialog")
    return widget

class TableEditButton(QPushButton):
    """One stable SAI-blue pencil for every editable table row."""

    def __init__(self, parent=None, tooltip: str = "Редактировать") -> None:
        super().__init__(parent)
        self.setObjectName("TableEditButton")
        self.setToolTip(tooltip)
        self.setAccessibleName(tooltip)
        self.setFixedSize(METRICS["icon_size"], METRICS["icon_size"])
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFlat(True)
        self.setText("")
        icon_path = Path(__file__).resolve().parent / "assets" / "icons" / "mdi" / "pencil-outline.svg"
        self.setIcon(QIcon(str(icon_path)))
        self.setIconSize(QSize(20, 20))


class ReceiptWorkflowStep(QFrame):
    """One compact, stateful receipt milestone."""

    def __init__(self, number: int, title: str, actor: str, parent=None) -> None:
        super().__init__(parent)
        self.number = int(number)
        self.setObjectName("ReceiptWorkflowStep")
        self.setProperty("workflowState", "pending")
        self.setMinimumHeight(54)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(9, 7, 9, 7)
        layout.setSpacing(8)
        self.badge = QLabel(str(self.number))
        self.badge.setObjectName("ReceiptWorkflowBadge")
        self.badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.badge.setFixedSize(26, 26)
        text = QVBoxLayout()
        text.setContentsMargins(0, 0, 0, 0)
        text.setSpacing(0)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("ReceiptWorkflowTitle")
        self.actor_label = QLabel(actor)
        self.actor_label.setObjectName("ReceiptWorkflowActor")
        text.addWidget(self.title_label)
        text.addWidget(self.actor_label)
        layout.addWidget(self.badge)
        layout.addLayout(text, 1)

    def set_workflow_state(self, state: str) -> None:
        state = state if state in {"pending", "current", "done", "skipped", "error"} else "pending"
        self.setProperty("workflowState", state)
        self.badge.setText({"done": "✓", "skipped": "—", "error": "!"}.get(state, str(self.number)))
        for widget in (self, self.badge, self.title_label, self.actor_label):
            widget.setProperty("workflowState", state)
            widget.style().unpolish(widget)
            widget.style().polish(widget)
            widget.update()


class ReceiptWorkflowTracker(QWidget):
    """Always-visible map of automatic and operator receipt stages."""

    STAGES = (
        ("setup", "Параметры", "Оператор"),
        ("draft", "Черновик SIGMA", "SAI"),
        ("catalog", "Проверка товаров", "SAI"),
        ("products", "Новые товары / ШК", "SAI + оператор"),
        ("fact", "Факт приёмки", "Оператор"),
        ("prices", "Проверка цен", "SAI + оператор"),
        ("apply", "Ввод прихода", "SAI"),
        ("documents", "НДП и ценники", "SAI / оператор"),
    )

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("ReceiptWorkflowTracker")
        self.steps = {}
        self.current_stage = "setup"
        layout = QGridLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setHorizontalSpacing(7)
        layout.setVerticalSpacing(7)
        for index, (stage_id, title, actor) in enumerate(self.STAGES):
            step = ReceiptWorkflowStep(index + 1, title, actor, self)
            self.steps[stage_id] = step
            layout.addWidget(step, index // 4, index % 4)
            layout.setColumnStretch(index % 4, 1)
        self.set_current("setup")

    def set_current(
        self,
        stage_id: str,
        *,
        skipped: set[str] | None = None,
        error: bool = False,
        complete: bool = False,
    ) -> None:
        if stage_id not in self.steps:
            return
        skipped = set(skipped or set())
        current_index = next(i for i, stage in enumerate(self.STAGES) if stage[0] == stage_id)
        self.current_stage = stage_id
        for index, (candidate, _title, _actor) in enumerate(self.STAGES):
            if candidate in skipped:
                state = "skipped"
            elif index < current_index or (complete and index == current_index):
                state = "done"
            elif index == current_index:
                state = "error" if error else "current"
            else:
                state = "pending"
            self.steps[candidate].set_workflow_state(state)

    def state(self, stage_id: str) -> str:
        step = self.steps.get(stage_id)
        return str(step.property("workflowState") or "") if step is not None else ""
