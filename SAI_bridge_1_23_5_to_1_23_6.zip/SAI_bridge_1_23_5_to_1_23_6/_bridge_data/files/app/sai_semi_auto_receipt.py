#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Application service for saving semi-automatic receipt edits.

The Qt page owns widgets and notifications.  This module owns format-specific
persistence for SAI Package, legacy XML and legacy Excel files.
"""
from __future__ import annotations

import datetime as dt
import os
from pathlib import Path
from typing import Any, Mapping, MutableMapping, Sequence
import xml.etree.ElementTree as ET

from openpyxl import load_workbook

import sai_converter
import sai_package
from sai_app import find_headers, normalize_unit, pick_col
from sai_core_v2.semi_auto_receipt_refactor import is_zero_quantity, row_barcodes, text


def _number(value: Any, default: float = 0.0) -> float:
    raw = text(value).replace(" ", "").replace(",", ".")
    if not raw:
        return default
    try:
        return float(raw)
    except Exception:
        return default


def _package_barcodes(row: Mapping[str, Any]) -> list[str]:
    """Match the historical SAI Package contract: store digits only."""
    result: list[str] = []
    for value in row_barcodes(row):
        digits = "".join(character for character in text(value) if character.isdigit())
        if digits and digits not in result:
            result.append(digits)
    return result


def package_item_from_row(row: Mapping[str, Any], index: int) -> dict[str, Any]:
    qty = row.get("qty") if row.get("qty") not in (None, "") else row.get("quantity")
    buy = row.get("buy") if row.get("buy") not in (None, "") else row.get("purchase_price")
    sale = row.get("sale") if row.get("sale") not in (None, "") else row.get("price")
    comment = text(row.get("comment"))
    if is_zero_quantity(row) and "недовоз" not in comment.lower():
        comment = (comment + " Недовоз: фактическое количество 0.").strip()
    return {
        "row": int(_number(row.get("source_row"), index + 1)),
        "name": text(row.get("name")),
        "quantity": _number(qty, 0.0),
        "unit": normalize_unit(row.get("unit") or "штука"),
        "purchase_price": _number(buy, 0.0),
        "sale_price": _number(sale, 0.0),
        "article": text(row.get("article") or row.get("vendor_code") or row.get("code")),
        "category": text(row.get("category")),
        "barcodes": _package_barcodes(row),
        "comment": comment,
        "issues": [text(value) for value in (row.get("issues") or []) if text(value)],
        "price_operator_approved": bool(row.get("price_operator_approved")),
        "price_approval_source": text(row.get("price_approval_source")),
        "catalog_price_snapshot": _number(row.get("catalog_price_snapshot"), 0.0),
        "price_approval_barcode": text(row.get("price_approval_barcode")),
    }


def write_row_to_xml_item(item_el: ET.Element, row: Mapping[str, Any], index: int) -> None:
    def set_xml_text(tag: str, value: Any) -> None:
        element = item_el.find(tag)
        if element is None:
            element = ET.SubElement(item_el, tag)
        element.text = text(value)

    item = package_item_from_row(row, index)
    set_xml_text("name", item["name"])
    set_xml_text("quantity", item["quantity"])
    set_xml_text("unit", item["unit"])
    set_xml_text("purchase_price", item["purchase_price"])
    set_xml_text("sale_price", item["sale_price"])
    set_xml_text("article", item["article"])
    set_xml_text("category", item["category"])
    set_xml_text("comment", item["comment"])
    set_xml_text("price_operator_approved", "true" if item["price_operator_approved"] else "false")
    set_xml_text("price_approval_source", item["price_approval_source"])
    set_xml_text("catalog_price_snapshot", item["catalog_price_snapshot"])
    set_xml_text("price_approval_barcode", item["price_approval_barcode"])
    barcodes_el = item_el.find("barcodes")
    if barcodes_el is None:
        barcodes_el = ET.SubElement(item_el, "barcodes")
    for child in list(barcodes_el):
        barcodes_el.remove(child)
    for barcode in row_barcodes(row):
        element = ET.SubElement(barcodes_el, "barcode")
        element.text = barcode


class SemiAutoReceiptService:
    def save_rows(
        self,
        rows: Sequence[MutableMapping[str, Any]],
        *,
        source_path: Path | None,
        output_path: Path,
        sheet_name: str = "",
        default_markup_percent: float = 60.0,
    ) -> Path:
        if not rows:
            raise ValueError("Нельзя сохранить пустой полуавтоматический привоз")
        source = Path(source_path) if source_path else None
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)

        if source is None or source.suffix.lower() == ".sai":
            if source is None:
                items = [
                    sai_converter.ConvertItem(**package_item_from_row(row, index))
                    for index, row in enumerate(rows)
                ]
                result = sai_converter.ConvertResult(
                    source_path="Полуавтоматический привоз",
                    source_type="SemiAuto",
                    supplier="ПОЛУАВТОМАТИЧЕСКИЙ ПРИВОЗ",
                    date=dt.date.today().isoformat(),
                    invoice_number="MANUAL",
                    markup_percent=float(default_markup_percent),
                    items=items,
                )
                return Path(sai_converter.write_sai_package(result, output))
            receipt = sai_package.read_receipt(source)
            receipt["items"] = [package_item_from_row(row, index) for index, row in enumerate(rows)]
            return Path(sai_package.rewrite_receipt(source, receipt, out_path=output))

        temp = output.with_name(f".{output.stem}.sai_tmp{output.suffix}")
        try:
            temp.unlink(missing_ok=True)
            if source.suffix.lower() == ".xml":
                tree = ET.parse(str(source))
                root = tree.getroot()
                items_el = root.find("items")
                if items_el is None:
                    items_el = ET.SubElement(root, "items")
                xml_items = list(items_el.findall("item"))
                for index, row in enumerate(rows):
                    item_el = xml_items[index] if index < len(xml_items) else ET.SubElement(
                        items_el, "item", {"row": str(index + 1)}
                    )
                    write_row_to_xml_item(item_el, row, index)
                try:
                    ET.indent(tree, space="  ")
                except Exception:
                    pass
                tree.write(str(temp), encoding="utf-8", xml_declaration=True)
            else:
                workbook = load_workbook(source)
                worksheet = workbook[sheet_name] if sheet_name in workbook.sheetnames else workbook[workbook.sheetnames[0]]
                header_row, headers = find_headers(worksheet)
                col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
                if not col_barcode:
                    col_barcode = pick_col(headers, ["BARCODE"], contains_any=["ШК"])
                if not col_barcode:
                    raise RuntimeError("В SAI-файле не найдена колонка ШК.")
                col_name = pick_col(headers, ["НАИМЕНОВАНИЕ", "ТОВАР", "НАЗВАНИЕ"], contains_any=["НАИМЕНОВАН"]) or pick_col(headers, ["ТОВАР"], contains_any=["ТОВАР"])
                col_qty = pick_col(headers, ["КОЛ-ВО", "КОЛИЧЕСТВО", "КОЛ-ВО ЕД."], contains_any=["КОЛ"])
                col_unit = pick_col(headers, ["ЕД.", "ЕД", "ЕДИНИЦА", "ЕДИНИЦА ИЗМЕРЕНИЯ"], contains_any=["ЕД"])
                col_sale = pick_col(headers, ["ПРОДАЖНАЯ ЦЕНА", "ЦЕНА ПРОДАЖИ", "РОЗНИЧНАЯ ЦЕНА"], contains_any=["ПРОДАЖ"]) or pick_col(headers, ["ЦЕНА"])
                col_article = pick_col(headers, ["АРТИКУЛ", "КОД", "КОД ТОВАРА", "КОД ПОСТАВЩИКА"])
                col_buy = pick_col(headers, ["ЗАКУПОЧНАЯ ЦЕНА", "ЗАКУП ЦЕНА", "ЦЕНА ЗАКУПКИ"], contains_any=["ЗАКУП"])
                col_price_approved = pick_col(headers, ["ЦЕНА УТВЕРЖДЕНА ОПЕРАТОРОМ"])
                col_price_source = pick_col(headers, ["ИСТОЧНИК УТВЕРЖДЕННОЙ ЦЕНЫ"])
                if any(bool(row.get("price_operator_approved")) for row in rows):
                    if not col_price_approved:
                        col_price_approved = worksheet.max_column + 1
                        worksheet.cell(header_row, col_price_approved).value = "Цена утверждена оператором"
                    if not col_price_source:
                        col_price_source = worksheet.max_column + 1
                        worksheet.cell(header_row, col_price_source).value = "Источник утвержденной цены"
                append_row = max(worksheet.max_row + 1, (header_row or 1) + 1)
                for row in rows:
                    excel_row = int(_number(row.get("excel_row"), 0.0))
                    if excel_row <= 0:
                        excel_row = append_row
                        row["excel_row"] = excel_row
                        append_row += 1
                    worksheet.cell(excel_row, col_barcode).value = ", ".join(row_barcodes(row))
                    worksheet.cell(excel_row, col_barcode).number_format = "@"
                    if col_name:
                        worksheet.cell(excel_row, col_name).value = text(row.get("name"))
                    if col_qty:
                        worksheet.cell(excel_row, col_qty).value = row.get("qty") if row.get("qty") not in (None, "") else 0
                    if col_unit:
                        worksheet.cell(excel_row, col_unit).value = text(row.get("unit") or "штука")
                    if col_sale:
                        worksheet.cell(excel_row, col_sale).value = row.get("sale") or row.get("price") or 0
                    if col_buy:
                        worksheet.cell(excel_row, col_buy).value = row.get("buy") or row.get("purchase_price") or 0
                    if col_article:
                        worksheet.cell(excel_row, col_article).value = text(row.get("article") or row.get("vendor_code") or row.get("code"))
                    if col_price_approved:
                        worksheet.cell(excel_row, col_price_approved).value = "ДА" if row.get("price_operator_approved") else ""
                    if col_price_source:
                        worksheet.cell(excel_row, col_price_source).value = text(row.get("price_approval_source"))
                workbook.save(temp)
                try:
                    workbook.close()
                except Exception:
                    pass
            os.replace(str(temp), str(output))
            return output
        except Exception:
            temp.unlink(missing_ok=True)
            raise
