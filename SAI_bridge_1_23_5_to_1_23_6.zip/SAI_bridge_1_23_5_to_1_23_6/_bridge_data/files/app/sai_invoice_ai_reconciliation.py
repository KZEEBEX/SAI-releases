#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Deterministic reconciliation and validation for SAI invoice AI."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

import sai_converter
import sai_page_orientation
from sai_core import gtin_check_digit_ok
from sai_invoice_ai_sources import IMAGE_EXTENSIONS

_VISUAL_CONFUSABLES = str.maketrans({
    "а": "a", "в": "b", "е": "e", "к": "k", "м": "m", "н": "h",
    "о": "o", "р": "p", "с": "c", "т": "t", "у": "y", "х": "x",
    "ё": "e", "і": "i", "ј": "j", "ѕ": "s",
})


def _confirmed_visual_page_numbers(
    paths:Sequence[str|Path],
    orientation_plan:Mapping[str,Sequence[Any]]|None,
)->List[int]:
    """Return global visual page numbers confirmed by the preview window."""
    normalized=sai_page_orientation.normalize_plan(paths,orientation_plan)
    count=0
    for raw in paths:
        path=Path(raw).expanduser().resolve()
        if path.suffix.lower() not in ({'.pdf'}|IMAGE_EXTENSIONS):
            continue
        count+=len(normalized.get(str(path)) or [])
    return list(range(1,count+1))


def _row_signature(row:Mapping[str,Any])->tuple[Any,...]:
    return (
        _norm_literal(row.get('raw_name') or row.get('name')),
        round(sai_converter.parse_float(row.get('quantity')),4),
        round(sai_converter.parse_float(row.get('line_total')),4),
        _norm_literal(row.get('article')),
        tuple(sai_converter.safe_str(x) for x in (row.get('barcodes') or [])),
    )


def _useful_page_warning(value:Any)->bool:
    text=sai_converter.safe_str(value).strip()
    if not text:
        return False
    lowered=text.casefold()
    ignored=(
        'supplier неразборчив','supplier отсутств','invoice_date','invoice_number',
        'document_total отсутств','итог строк на предоставленной странице',
        'итог относится ко всему документу','страниц','лист',
    )
    if any(token in lowered for token in ignored):
        return False
    return bool(re.search(r'(source_row|строк[аеу]?\s+\d+)',lowered))


def _merge_page_documents(page_documents:Sequence[tuple[int,Dict[str,Any]]])->Dict[str,Any]:
    """Merge page results while anchoring document headers to the first page.

    Later pages are allowed to omit or repeat supplier/date/number. They never
    overwrite page-one metadata and never create expensive row repairs merely
    because a continuation page has no document header.
    """
    merged={
        'supplier':'','invoice_date':'','invoice_number':'','currency':'RUB',
        'document_total':0.0,'document_total_note':'','items':[],'warnings':[],
    }
    rows=[]
    seen_exact=set()
    ordered_pages=sorted(page_documents,key=lambda pair:int(pair[0]))
    if ordered_pages:
        first_doc=ordered_pages[0][1]
        for field in ('supplier','invoice_date','invoice_number','currency'):
            value=sai_converter.safe_str(first_doc.get(field))
            if value:
                merged[field]=value
    for page_number,doc in ordered_pages:
        total=sai_converter.parse_float(doc.get('document_total'))
        if total>0:
            # In multi-page invoices the final page normally contains the
            # document total, while earlier pages may contain page subtotals.
            merged['document_total']=total
            merged['document_total_note']=sai_converter.safe_str(doc.get('document_total_note'))
        for warning in doc.get('warnings') or []:
            text=sai_converter.safe_str(warning)
            if _useful_page_warning(text) and text not in merged['warnings']:
                merged['warnings'].append(text)
        for local_pos,raw in enumerate(doc.get('items') or [],start=1):
            row=json.loads(json.dumps(raw,ensure_ascii=False))
            row['source_page']=int(page_number)
            try: local_row=max(1,int(row.get('source_row') or local_pos))
            except Exception: local_row=local_pos
            row['source_row']=local_row
            signature=(int(page_number),_row_signature(row))
            if signature in seen_exact:
                continue
            seen_exact.add(signature)
            rows.append((int(page_number),local_row,row))
    printed=[local for _page,local,_row in rows]
    preserve=bool(printed) and len(set(printed))==len(printed) and sorted(printed)==list(range(1,max(printed)+1))
    rows.sort(key=(lambda item:(item[1],item[0])) if preserve else (lambda item:(item[0],item[1])))
    if not preserve and rows:
        merged['warnings'].append('SAI восстановил внутреннюю нумерацию строк после независимого чтения страниц.')
    for index,(_page,_local,row) in enumerate(rows,start=1):
        row['source_row']=int(row.get('source_row') or index) if preserve else index
        merged['items'].append(row)
    return merged


def _source_document_row_identity(row:Mapping[str,Any])->tuple[Any,...]:
    """Identity used to recognise a bill and its matching sales document."""
    return (
        _norm_literal(row.get('article')),
        _norm_literal(row.get('raw_name') or row.get('name')),
        round(sai_converter.parse_float(row.get('quantity')),4),
        round(sai_converter.parse_float(row.get('line_total')),2),
    )


def merge_source_documents(
    source_documents:Sequence[tuple[str,Dict[str,Any]]],
) -> Dict[str,Any]:
    """Merge independently read files and remove only whole-document duplicates.

    A supplier may send both an invoice and a sales document containing the
    same rows.  We collapse such a pair as one source document, but never
    remove an individual repeated product from different documents.
    """
    unique_documents:List[tuple[str,Dict[str,Any]]]=[]
    by_identity:Dict[tuple[Any,...],int]={}
    duplicate_names:List[str]=[]
    for source_name,raw_doc in source_documents:
        doc=json.loads(json.dumps(raw_doc,ensure_ascii=False))
        items=list(doc.get('items') or [])
        identity=tuple(_source_document_row_identity(row) for row in items)
        if not identity:
            continue
        existing_index=by_identity.get(identity)
        if existing_index is None:
            by_identity[identity]=len(unique_documents)
            unique_documents.append((source_name,doc))
            continue
        duplicate_names.append(source_name)
        existing=unique_documents[existing_index][1]
        for old_row,new_row in zip(existing.get('items') or [],items):
            merged_barcodes=[]
            for value in list(old_row.get('barcodes') or [])+list(new_row.get('barcodes') or []):
                text=sai_converter.safe_str(value)
                if text and text not in merged_barcodes:
                    merged_barcodes.append(text)
            old_row['barcodes']=merged_barcodes

    merged={
        'supplier':'','invoice_date':'','invoice_number':'','currency':'RUB',
        'document_total':0.0,'document_total_note':'','items':[],'warnings':[],
    }
    if not unique_documents:
        return merged
    first=unique_documents[0][1]
    for field in ('supplier','invoice_date','invoice_number','currency'):
        merged[field]=sai_converter.safe_str(first.get(field))
    total=0.0
    for document_index,(source_name,doc) in enumerate(unique_documents,start=1):
        doc_total=sai_converter.parse_float(doc.get('document_total'))
        if doc_total<=0:
            doc_total=sum(sai_converter.parse_float(row.get('line_total')) for row in (doc.get('items') or []))
        total+=doc_total
        for warning in doc.get('warnings') or []:
            text=sai_converter.safe_str(warning)
            if text and text not in merged['warnings']:
                merged['warnings'].append(text)
        for row in doc.get('items') or []:
            copied=json.loads(json.dumps(row,ensure_ascii=False))
            copied['source_document']=source_name
            copied['source_page']=document_index
            copied['source_row']=len(merged['items'])+1
            merged['items'].append(copied)
    merged['document_total']=round(total,4)
    merged['document_total_note']=(
        f"Объединено исходных документов: {len(unique_documents)}; "
        f"повторяющихся пар пропущено: {len(duplicate_names)}."
    )
    if duplicate_names:
        merged['warnings'].append(
            'SAI не удвоил товары из повторяющих документов: '+', '.join(duplicate_names)+'.'
        )
    return merged


def _valid_barcodes(value:Any)->List[str]:
    result=[]
    for raw in value or []:
        for code in re.findall(r'(?<!\d)(\d{8}|\d{12}|\d{13}|\d{14})(?!\d)',sai_converter.safe_str(raw)):
            if gtin_check_digit_ok(code) and code not in result:
                result.append(code)
    return result


def _prefer_equivalent_text(first:Any,second:Any)->str:
    a=sai_converter.safe_str(first); b=sai_converter.safe_str(second)
    if not a: return b
    if not b: return a
    # For visually equivalent Latin/Cyrillic brand spellings prefer the version
    # that preserves more actual Latin letters (POTATO instead of РОТАТО).
    latin_a=len(re.findall(r'[A-Za-z]',a)); latin_b=len(re.findall(r'[A-Za-z]',b))
    if latin_b>latin_a:
        return b
    if latin_a>latin_b:
        return a
    return b if len(b)>len(a) else a


def reconcile_luna_page(primary:Dict[str,Any],verification:Dict[str,Any],page_number:int)->tuple[Dict[str,Any],List[int],List[str],List[int],Dict[int,List[str]]]:
    """Reconcile two independent Luna readings and return only material conflicts."""
    merged=json.loads(json.dumps(primary,ensure_ascii=False))
    problems:set[int]=set(); notes:List[str]=[]; omitted:set[int]=set(); corrections:Dict[int,List[str]]={}
    # Header fields are accepted when one pass read them. A genuine conflict is
    # left empty so the inexpensive header-only stage can resolve it.
    for field in ('supplier','invoice_date','invoice_number'):
        a=sai_converter.safe_str(primary.get(field)); b=sai_converter.safe_str(verification.get(field))
        if a and b and not _equivalent_text(a,b):
            merged[field]=''
        else:
            merged[field]=_prefer_equivalent_text(a,b)
    merged['currency']=sai_converter.safe_str(primary.get('currency') or verification.get('currency') or 'RUB')
    ta=sai_converter.parse_float(primary.get('document_total')); tb=sai_converter.parse_float(verification.get('document_total'))
    merged['document_total']=ta if ta>0 else tb
    if ta>0 and tb>0 and abs(ta-tb)>0.01:
        # Page subtotals are common; the final deterministic document check will
        # decide which total is meaningful without escalating all rows.
        merged['document_total']=max(ta,tb)
    merged['document_total_note']=sai_converter.safe_str(primary.get('document_total_note') or verification.get('document_total_note'))
    pmap=_row_map(primary); vmap=_row_map(verification)
    all_numbers=sorted(set(pmap)|set(vmap))
    output=[]
    for number in all_numbers:
        a=pmap.get(number); b=vmap.get(number)
        if a is None and b is not None:
            row=json.loads(json.dumps(b,ensure_ascii=False)); problems.add(number)
            notes.append(f'строка {number}: найдена только вторым чтением Luna')
            corrections[number]=['row_from_second_luna']; output.append(row); continue
        if b is None and a is not None:
            row=json.loads(json.dumps(a,ensure_ascii=False)); problems.add(number)
            notes.append(f'строка {number}: второе чтение Luna не вернуло позицию')
            output.append(row); continue
        assert a is not None and b is not None
        row=json.loads(json.dumps(a,ensure_ascii=False)); changed=[]
        # Text identity fields: punctuation, register and visually confusable
        # Latin/Cyrillic glyphs are cosmetic; real wording changes go to Terra.
        for field in ('raw_name','name'):
            av=sai_converter.safe_str(a.get(field)); bv=sai_converter.safe_str(b.get(field))
            if not av and bv:
                row[field]=bv; changed.append(field)
            elif av and bv and _equivalent_text(av,bv):
                preferred=_prefer_equivalent_text(av,bv)
                if preferred!=av: changed.append(field)
                row[field]=preferred
            elif av and bv:
                problems.add(number); notes.append(f'строка {number}: Luna расходится по {field}')
        aa=sai_converter.safe_str(a.get('article')); ab=sai_converter.safe_str(b.get('article'))
        if not aa and ab:
            row['article']=ab; changed.append('article')
        elif aa and ab and _equivalent_text(aa,ab):
            row['article']=_prefer_equivalent_text(aa,ab)
        elif aa and ab:
            problems.add(number); notes.append(f'строка {number}: Luna расходится по article')
        for field in ('quantity','line_total'):
            av=sai_converter.parse_float(a.get(field)); bv=sai_converter.parse_float(b.get(field))
            if av<=0<bv:
                row[field]=bv; changed.append(field)
            elif av>0 and bv>0 and abs(av-bv)>0.0001:
                problems.add(number); notes.append(f'строка {number}: Luna расходится по {field}')
        ua=sai_converter.safe_str(a.get('unit')); ub=sai_converter.safe_str(b.get('unit'))
        if not ua and ub:
            row['unit']=ub; changed.append('unit')
        elif ua and ub and not _equivalent_unit(ua,ub):
            problems.add(number); notes.append(f'строка {number}: Luna расходится по unit')
        codes_a=_valid_barcodes(a.get('barcodes')); codes_b=_valid_barcodes(b.get('barcodes'))
        if codes_a==codes_b:
            row['barcodes']=codes_a
        else:
            # A barcode is never arbitrated at extra cost. Any disagreement is
            # resolved safely by leaving it empty and routing semi-automatically.
            row['barcodes']=[]; row['note']=''; omitted.add(number); changed.append('barcode_consensus_omitted')
        row['source_page']=int(page_number)
        row['source_row']=int(number)
        if number not in problems:
            row['note']=''; row['confidence']=0.97
        reportable=[reason for reason in changed if reason!='barcode_consensus_omitted']
        if reportable:
            corrections[number]=sorted(set(reportable))
        output.append(row)
    output.sort(key=lambda row:int(row.get('source_row') or 999999))
    merged['items']=output
    merged['warnings']=[]
    return merged,sorted(problems),list(dict.fromkeys(notes)),sorted(omitted),corrections


def _norm_literal(value:Any)->str:
    return re.sub(r'[^0-9a-zа-яё]+','',sai_converter.safe_str(value).casefold())


def _norm_compare(value:Any)->str:
    text=sai_converter.safe_str(value).casefold().translate(_VISUAL_CONFUSABLES)
    text=text.replace('×','x').replace('х','x')
    return re.sub(r'[^0-9a-z]+','',text)


def _equivalent_text(first:Any,second:Any)->bool:
    a=_norm_compare(first); b=_norm_compare(second)
    return bool(a and b and a==b)


def _equivalent_unit(first:Any,second:Any)->bool:
    def canon(value:Any)->str:
        text=re.sub(r'[^0-9a-zа-яё]+','',sai_converter.safe_str(value).casefold())
        aliases={
            'шт':'piece','штука':'piece','штук':'piece','pcs':'piece','pc':'piece',
            'м':'meter','метр':'meter','метров':'meter','m':'meter',
            'кг':'kg','килограмм':'kg','kg':'kg',
            'уп':'pack','упак':'pack','упаковка':'pack','pack':'pack',
        }
        return aliases.get(text,text)
    a=canon(first); b=canon(second)
    return bool(a and b and a==b)


def _row_map(doc:Dict[str,Any])->Dict[int,Dict[str,Any]]:
    result={}
    for pos,row in enumerate(doc.get('items') or [],start=1):
        try: number=int(row.get('source_row') or pos)
        except Exception: number=pos
        result[number]=row
    return result


def apply_audit(doc:Dict[str,Any],audit:Dict[str,Any])->tuple[Dict[str,Any],Dict[int,List[str]],List[int],List[int]]:
    """Merge a row audit without allowing an incomplete answer to erase good data.

    Terra/Sol inspect only cropped fragments. A model can legitimately fail to
    read one of the requested fields and return an empty string or zero. Those
    values are evidence of uncertainty, not corrections. Existing non-empty
    values from the dual-Luna consensus are therefore preserved unless the
    audit supplies a meaningful replacement. Barcode-only uncertainty remains
    the one deliberate destructive action and routes the row to the guarded
    semi-automatic barcode workflow.
    """
    merged=json.loads(json.dumps(doc,ensure_ascii=False)); rows=_row_map(merged); changed:Dict[int,List[str]]={}; uncertain=[]; barcode_omitted=[]
    for header in ('supplier','invoice_date','invoice_number','document_total'):
        value=audit.get(header)
        if header=='document_total':
            parsed=sai_converter.parse_float(value)
            if parsed>0 and abs(sai_converter.parse_float(merged.get(header))-parsed)>0.0001:
                merged[header]=parsed
        elif sai_converter.safe_str(value) and _norm_literal(merged.get(header))!=_norm_literal(value):
            merged[header]=sai_converter.safe_str(value)
    allowed=('source_page','raw_name','article','barcodes','quantity','unit','line_total')
    verified_map={int(row.get('source_row') or 0):row for row in (audit.get('rows') or [])}
    for number,before in rows.items():
        verified=verified_map.get(number)
        if not verified: continue
        reasons=[]
        status=sai_converter.safe_str(verified.get('status')).casefold()
        uncertain_fields={sai_converter.safe_str(x).casefold() for x in (verified.get('uncertain_fields') or []) if sai_converter.safe_str(x)}
        note_text=sai_converter.safe_str(verified.get('note'))
        note_norm=note_text.casefold()
        barcode_only=(status=='uncertain' and uncertain_fields and uncertain_fields.issubset({'barcodes'}))
        if status=='uncertain' and not uncertain_fields:
            barcode_only=(not before.get('barcodes') and any(token in note_norm for token in ('штрихкод','штрих-код','шк','barcode','gtin')))

        for field in allowed:
            if field=='barcodes':
                continue
            raw_new=verified.get(field)
            if field in {'quantity','line_total'}:
                new=sai_converter.parse_float(raw_new)
                old=sai_converter.parse_float(before.get(field))
                if new<=0:
                    if old>0: reasons.append(f'ignored_empty_{field}')
                    continue
                differs=abs(old-new)>0.0001
            elif field=='source_page':
                try: new=max(1,int(raw_new or 0))
                except Exception: new=0
                if new<=0: continue
                differs=int(before.get(field) or 1)!=new
            else:
                new=sai_converter.safe_str(raw_new)
                if not new:
                    if sai_converter.safe_str(before.get(field)): reasons.append(f'ignored_empty_{field}')
                    continue
                differs=_norm_literal(before.get(field))!=_norm_literal(new)
            before[field]=new
            if differs: reasons.append(field)

        old_codes=[sai_converter.safe_str(x) for x in (before.get('barcodes') or []) if sai_converter.safe_str(x)]
        new_codes=[sai_converter.safe_str(x) for x in (verified.get('barcodes') or []) if sai_converter.safe_str(x)]
        if barcode_only:
            before['barcodes']=[]
            before['note']=''
            before['confidence']=0.96
            barcode_omitted.append(number)
            reasons.append('unreadable_barcode_omitted')
        elif new_codes:
            if old_codes!=new_codes: reasons.append('barcodes')
            before['barcodes']=new_codes
        elif old_codes:
            reasons.append('ignored_empty_barcodes')

        before['name']=sai_converter.safe_str(before.get('raw_name'))
        if barcode_only:
            pass
        elif status=='uncertain':
            uncertain.append(number)
            before['note']=note_text or 'Построчная проверка не смогла уверенно прочитать критическое поле.'
            before['confidence']=0.50
            reasons.append('uncertain')
        else:
            before['note']=''; before['confidence']=0.98
        if reasons: changed[number]=sorted(set(reasons))
    merged['items']=sorted(rows.values(),key=lambda r:int(r.get('source_row') or 999999))
    return merged,changed,sorted(set(uncertain)),sorted(set(barcode_omitted))

def _sanitize_and_evaluate_document(
    doc:Dict[str,Any],
    supplier_hint:str='',
    date_hint:str='',
    invoice_hint:str='',
)->tuple[Dict[str,Any],List[int],List[str],List[int]]:
    """Apply deterministic safety checks without spending another API call.

    Invalid or unreadable barcodes are deliberately removed instead of being
    escalated: the guarded receipt router will send those rows to the
    semi-automatic barcode workflow. Other material problems become repair
    targets for Terra/Sol.
    """
    cleaned=json.loads(json.dumps(doc,ensure_ascii=False))
    items=list(cleaned.get('items') or [])
    problems:set[int]=set()
    notes:List[str]=[]
    omitted:set[int]=set()
    seen_rows:Dict[int,int]={}
    seen_codes:Dict[str,int]={}
    normalized=[]
    for pos,row in enumerate(items,start=1):
        try: number=int(row.get('source_row') or pos)
        except Exception: number=pos
        if number<=0: number=pos
        if number in seen_rows:
            problems.update({number,seen_rows[number]})
            notes.append(f'дубликат source_row {number}')
        seen_rows[number]=number
        row['source_row']=number
        try: row['source_page']=max(1,int(row.get('source_page') or 1))
        except Exception: row['source_page']=1
        raw_name=sai_converter.safe_str(row.get('raw_name') or row.get('name'))
        row['raw_name']=raw_name
        row['name']=sai_converter.safe_str(row.get('name') or raw_name)
        row['quantity']=sai_converter.parse_float(row.get('quantity'))
        row['line_total']=sai_converter.parse_float(row.get('line_total'))
        row['purchase_price']=sai_converter.parse_float(row.get('purchase_price'))
        if row['line_total']<=0 and row['quantity']>0 and row['purchase_price']>0:
            row['line_total']=round(row['quantity']*row['purchase_price'],4)
            row['line_total_derived']=True
        row['unit']=sai_converter.safe_str(row.get('unit'))
        row['article']=sai_converter.safe_str(row.get('article'))
        raw_codes=[sai_converter.safe_str(x) for x in (row.get('barcodes') or []) if sai_converter.safe_str(x)]
        valid_codes=[]
        saw_unusable=False
        for raw_code in raw_codes:
            matches=re.findall(r'(?<!\d)(\d{8}|\d{12}|\d{13}|\d{14})(?!\d)',raw_code)
            if not matches:
                saw_unusable=True
            for code in matches:
                if gtin_check_digit_ok(code):
                    if code not in valid_codes: valid_codes.append(code)
                else:
                    saw_unusable=True
        if saw_unusable:
            omitted.add(number)
        row['barcodes']=valid_codes
        if not raw_name:
            problems.add(number); notes.append(f'строка {number}: нет наименования')
        if row['quantity']<=0:
            problems.add(number); notes.append(f'строка {number}: нет положительного количества')
        if row['line_total']<=0:
            problems.add(number); notes.append(f'строка {number}: нет финальной суммы строки')
        note=sai_converter.safe_str(row.get('note'))
        note_norm=note.casefold()
        if not valid_codes and any(token in note_norm for token in ('штрихкод','штрих-код','шк','barcode','gtin')):
            row['note']=''; omitted.add(number)
        for code in valid_codes:
            previous=seen_codes.get(code)
            if previous is not None and previous!=number:
                problems.update({previous,number})
                notes.append(f'ШК {code} повторяется в строках {previous} и {number}')
            else:
                seen_codes[code]=number
        normalized.append(row)
    normalized.sort(key=lambda row:int(row.get('source_row') or 999999))
    cleaned['items']=normalized
    row_numbers=[int(row.get('source_row') or 0) for row in normalized]
    if row_numbers:
        expected=list(range(1,max(row_numbers)+1))
        if row_numbers!=expected:
            if len(set(row_numbers))==len(row_numbers):
                # Supplier sheets may contain a typo/gap in their printed «№»
                # column. Keep it for audit, but use stable sequential source_row
                # identifiers inside SAI so a missing printed number is not treated
                # as a missing product.
                for position,row in enumerate(normalized,start=1):
                    row['document_row_number']=int(row.get('source_row') or position)
                    row['source_row']=position
                row_numbers=list(range(1,len(normalized)+1))
            else:
                problems.update(row_numbers)
                notes.append('номера товарных строк содержат дубликаты')
    first_row=row_numbers[0] if row_numbers else 1
    if not sai_converter.safe_str(supplier_hint or cleaned.get('supplier')):
        problems.add(first_row); notes.append('не прочитан поставщик')
    if not sai_converter.safe_str(date_hint or cleaned.get('invoice_date')):
        problems.add(first_row); notes.append('не прочитана дата документа')
    if not sai_converter.safe_str(invoice_hint or cleaned.get('invoice_number')):
        problems.add(first_row); notes.append('не прочитан номер документа')
    total=sai_converter.parse_float(cleaned.get('document_total'))
    lines=sum(sai_converter.parse_float(row.get('line_total')) for row in normalized)
    tolerance=_document_rounding_tolerance(len(normalized))
    if total<=0:
        problems.add(first_row); notes.append('не прочитан итог документа')
    elif abs(total-lines)>tolerance:
        problems.update(row_numbers)
        notes.append(f'сумма строк {lines:.2f} не сходится с итогом документа {total:.2f}')
    return cleaned,sorted(problems),list(dict.fromkeys(notes)),sorted(omitted)


def _target_pages_for_rows(doc:Dict[str,Any],rows:Sequence[int])->List[int]:
    mapping=_row_map(doc)
    pages={max(1,int((mapping.get(int(row)) or {}).get('source_page') or 1)) for row in rows if int(row)>0}
    return sorted(pages or {1})


def _check_audit_coverage(audit:Dict[str,Any],target_rows:Sequence[int])->tuple[List[int],List[int]]:
    expected={int(x) for x in target_rows if int(x)>0}
    checked={int(x) for x in (audit.get('checked_rows') or []) if int(x)>0}
    returned={int(row.get('source_row') or 0) for row in (audit.get('rows') or []) if int(row.get('source_row') or 0)>0}
    missing=sorted(expected-(checked & returned))
    extras=sorted(returned-expected)
    return missing,extras


def _blocking_quality_notes(notes:Sequence[str])->List[str]:
    blockers=[]
    markers=('сумма строк','нет положительного количества','нет финальной суммы строки','нет наименования','дубликат source_row','не образуют непрерывную')
    for note in notes:
        if any(marker in note for marker in markers): blockers.append(note)
    return blockers


def _reviewable_quality_notes(notes:Sequence[str])->List[str]:
    """Return blockers that an operator may explicitly accept.

    A damaged document can make its printed grand total unreadable while all
    item rows remain usable. Only that exact mismatch is reviewable; missing
    row quantities, names or line totals must still stop the pipeline.
    """
    return [
        note for note in _blocking_quality_notes(notes)
        if note.casefold().startswith('сумма строк ') and ' не сходится с итогом документа ' in note.casefold()
    ]


def _document_rounding_tolerance(item_count:int)->float:return max(0.10,max(1,item_count)*0.02)


def _unique_append(values:List[str],message:str)->None:
    text=sai_converter.safe_str(message)
    if text and text not in values: values.append(text)
