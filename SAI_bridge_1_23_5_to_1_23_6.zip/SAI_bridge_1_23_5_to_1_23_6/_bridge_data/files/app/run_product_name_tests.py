#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent regression tests for SAI product-name normalization."""
from __future__ import annotations

import json
import tempfile
import zipfile
from pathlib import Path

import sai_converter
import sai_package
import sai_product_names as names


def check(value: bool, message: str) -> None:
    if not value:
        raise AssertionError(message)


def norm(value: str) -> str:
    return names.normalize_product_name(value, custom_rules=names.DEFAULT_CUSTOM_RULES).normalized


# Approved electrical language.
value = norm("1-2.SALE выкл. ОУ 1кл. 10А бел. (корп. ABS, пласт. осн.) E1M sz901382")
check(value == "ВЫКЛЮЧАТЕЛЬ ОУ 1КЛ 10 А БЕЛЫЙ (КОРПУС ABS, ПЛАСТИКОВОЕ ОСНОВАНИЕ) E1M SZ901382", value)
check("1-2.SALE" not in value and "E1M" in value and "SZ901382" in value, "Prefix removed, model preserved")

value = norm("Колодка ОУ двойная 2гн. с загл. каучук 2Р+РЕ 1x16А 220-240V IP44 черн.")
check(value.startswith("КОЛОДКА ОУ 2 ГН"), value)
check("1×16 А" in value and "220–240 В" in value and "ЧЁРНАЯ" in value, value)

value = norm("Роз. СУ 2мест. 16А земля бел.")
check(value == "РОЗЕТКА СУ 2 ГН 16 А С/З БЕЛАЯ", value)

value = norm("Выкл. скрытой установки двухклавишный 10A беж.")
check(value == "ВЫКЛЮЧАТЕЛЬ СУ 2КЛ 10 А БЕЖЕВЫЙ", value)

# D/ is attached, but meaningful 'без' remains full.
check(norm("Средство для мытья пола 1л") == "СРЕДСТВО Д/МЫТЬЯ ПОЛА 1 Л", "D/ policy")
check(norm("Лопата штыковая без черенка 120см") == "ЛОПАТА ШТЫКОВАЯ БЕЗ ЧЕРЕНКА 120 СМ", "Meaningful absence stays full")

# Product types do not collapse into each other.
check(norm("Колодка 3 гн с/з 16А") .startswith("КОЛОДКА 3 ГН С/З"), "Kolodka preserved")
check(norm("Удлинитель 3роз. 5м 16А земля").startswith("УДЛИНИТЕЛЬ 3 ГН 5 М 16 А С/З"), "Extension preserved")
check(norm("Сетевой фильтр 5роз. 3м").startswith("СЕТЕВОЙ ФИЛЬТР 5 ГН 3 М"), "Network filter preserved")

# Units and model safety.
value = norm("Ecola св-к св/д 24W 6500K 6K 175x40 мат. бел. DPRD24ELC (40!)")
check("СВЕТИЛЬНИК СВ/Д 24 ВТ 6500 К" in value, value)
check("6 К" not in value and "DPRD24ELC" in value, value)
check(norm("Прожектор 30W LPR-023-0-65K-030") == "ПРОЖЕКТОР 30 ВТ LPR-023-0-65K-030", "Model must not be split as Kelvin")
check(norm("Удлинитель ПВС 3x1 1.5м 16A") == "УДЛИНИТЕЛЬ ПВС 3×1 1,5 М 16 А", "Decimal/unit format")

# Supplier package/price notes are removed, product pack count remains.
value = norm("EKF набор термоус. трубка 7 цветов по 3шт. 100mm (цена за 1уп.) TUT-N-2")
check(value == "EKF НАБОР ТЕРМОУСАДОЧНЫХ ТРУБОК 7 ЦВЕТОВ ПО 3 ШТ 100 ММ TUT-N-2", value)
check("3 ШТ" in value and "ЦЕНА" not in value, value)

# Plain supplier list markers and decorative punctuation are not seller-facing text.
value = norm("Клей универсальный Момент 125 мл (200) !!!")
check(value == "КЛЕЙ УНИВЕРСАЛЬНЫЙ МОМЕНТ 125 МЛ", value)
check(norm("Круг отрезной 200мм") == "КРУГ ОТРЕЗНОЙ 200 ММ", "Meaningful dimensions must remain")
check("XQ-200" in norm("Дрель XQ-200 (комплект)"), "Model number must remain")

# Wholesale carton ratios and decorative brand quotes never reach sellers.
value = norm('Кисть плоская №2 /50 мм (12/720) натур.щетина "КЕДР" 006-4020')
check(value == "КИСТЬ ПЛОСКАЯ №2 /50 ММ НАТУР.ЩЕТИНА КЕДР 006-4020", value)
value = norm('Краска интерьерная "ALFAVIT" 3 кг (1) серия Альфа')
check(value == "КРАСКА ИНТЕРЬЕРНАЯ ALFAVIT 3 КГ СЕРИЯ АЛЬФА", value)
check("(ВСПЕНЕННАЯ)" in norm("Лента двусторонняя (вспененная) 24 мм"), "Product characteristic in brackets must remain")

# Supplier article belongs to its own field and must not be duplicated in the name.
article_name = names.normalize_product_name(
    '10102-150 Шпатель фасадный "ИНТЕК" 150мм',
    article="10102-150",
    custom_rules=names.DEFAULT_CUSTOM_RULES,
)
check(article_name.normalized.startswith("ШПАТЕЛЬ ФАСАДНЫЙ"), article_name.normalized)
check("10102-150" not in article_name.normalized, article_name.normalized)
check("УДАЛЁН АРТИКУЛ ИЗ НАЧАЛА НАЗВАНИЯ" in article_name.changes, str(article_name.changes))
check(
    names.normalize_product_name("Краска 10102-150 белая", article="10102-150", custom_rules=names.DEFAULT_CUSTOM_RULES).normalized
    == "КРАСКА 10102-150 БЕЛАЯ",
    "Article inside a meaningful name must remain",
)

# Unknown supplier vocabulary is preserved instead of guessed away.
value = norm("BRAND XQZ-77 муфта суперфлекс 20мм")
check("BRAND" in value and "XQZ-77" in value and "СУПЕРФЛЕКС" in value, value)
check("ЗЕМЛЯ" in norm("Земля для рассады 5л"), "Non-electrical earth must not become grounding")

# Search aliases allow both compact and full query vocabulary.
search = names.searchable_text("РОЗЕТКА ОУ 2 ГН С/З")
check("ОТКРЫТОЙ УСТАНОВКИ" in search and "С ЗАЗЕМЛЕНИЕМ" in search and "ГНЕЗД" in search, search)

# Manual edits are protected from automatic reruns.
item = sai_converter.ConvertItem(row=1, raw_name="Роз. ОУ 1мест. 16А бел.", name="")
check(names.normalize_items([item], custom_rules=names.DEFAULT_CUSTOM_RULES) == 1, "Initial normalization")
check(item.name == "РОЗЕТКА ОУ 1 ГН 16 А БЕЛАЯ", item.name)
names.apply_manual_name(item, "РОЗЕТКА ОУ 1 ГН 16 А БЕЛАЯ МАГАЗИН")
check(names.normalize_items([item], custom_rules=names.DEFAULT_CUSTOM_RULES) == 0, "Manual name must survive")
check(item.name.endswith("МАГАЗИН") and item.name_manually_edited, "Manual state")
names.restore_normalized_name(item, custom_rules=names.DEFAULT_CUSTOM_RULES)
check(item.name == "РОЗЕТКА ОУ 1 ГН 16 А БЕЛАЯ" and not item.name_manually_edited, "Restore suggestion")

# Custom dictionary is additive and local.
custom = dict(names.DEFAULT_CUSTOM_RULES)
custom["literal_replacements"] = {"СУПЕРФЛЕКС": "SUPERFLEX"}
check(names.normalize_product_name("Муфта суперфлекс 20мм", custom_rules=custom).normalized == "МУФТА SUPERFLEX 20 ММ", "Custom dictionary")

# The SAI package keeps both source literal and final name plus provenance.
result = sai_converter.ConvertResult(source_path="", source_type="test", supplier="TEST", items=[item])
item.name = "РОЗЕТКА ОУ 1 ГН 16 А БЕЛАЯ МАГАЗИН"
item.name_manually_edited = True
item.name_normalization_changes = ["РУЧНАЯ ПРАВКА"]
item.name_search_aliases = ["РОЗЕТКА ОТКРЫТОЙ УСТАНОВКИ 1 ГНЕЗДО 16 А БЕЛАЯ"]
item.name_normalizer_version = names.RULES_VERSION
with tempfile.TemporaryDirectory(prefix="sai_name_test_") as td:
    out = Path(td) / "test.sai"
    sai_package.write_package(result, out, created_by_version="test")
    with zipfile.ZipFile(out, "r") as archive:
        receipt = json.loads(archive.read("data/receipt.json"))
    row = receipt["items"][0]
    check(row["raw_name"] == "Роз. ОУ 1мест. 16А бел.", "Literal must survive package")
    check(row["name"].endswith("МАГАЗИН") and row["name_source"] == "manual", "Final/manual provenance")
    check(row["name_normalizer_version"] == names.RULES_VERSION, "Normalizer version")

print("SAI product name tests: OK")
