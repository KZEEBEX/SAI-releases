#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Application boundary for free-receipt catalog lookup and barcode issuance."""
from __future__ import annotations

import json
import sqlite3
import threading
from difflib import SequenceMatcher
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import sai_db
from sai_catalog_ready import load_private_config, save_private_config_patch
from sai_core_v2.free_receipt import (
    BARCODE_LIMIT,
    barcode_digits,
    category_id_from_raw,
    category_name_from_raw,
    highest_internal_counter,
    json_pick,
    merge_barcodes,
    next_internal_barcode,
    normalize_search_text,
    normalized_internal_prefix,
    normalize_unit,
    recursive_price,
    search_tokens,
    text,
)
from sai_core_v2.manual_receipt import money_float
from sai_runtime_paths import USER_DATA_DIR, ensure_runtime_dirs


@dataclass(frozen=True, slots=True)
class GeneratedBarcode:
    code: str
    counter: int


class FreeReceiptCatalogService:
    """Own SQLite/catalog access and generated-barcode persistence.

    The service intentionally has no PySide dependency.  A caller may provide a
    custom DB path and config functions in tests or future clients.
    """

    def __init__(
        self,
        *,
        db_path: Path | None = None,
        generated_path: Path | None = None,
        config_loader=load_private_config,
        config_saver=save_private_config_patch,
    ) -> None:
        self.db_path = Path(db_path) if db_path is not None else Path(sai_db.DB_PATH)
        self.generated_path = Path(generated_path) if generated_path is not None else USER_DATA_DIR / "free_receipt_generated_barcodes.json"
        self.config_loader = config_loader
        self.config_saver = config_saver
        self._catalog_cache: tuple[dict[str, Any], ...] = ()
        self._barcode_index: dict[str, tuple[dict[str, Any], ...]] = {}
        self._catalog_stamp: tuple[int, ...] | None = None
        self._cache_ready = False
        self._cache_loading = False
        self._cache_lock = threading.RLock()

    @staticmethod
    def resolve_category(raw: Any, categories: Sequence[Mapping[str, Any]], fallback: Any = "") -> str:
        name = category_name_from_raw(raw) or text(fallback)
        if name:
            return name
        category_id = category_id_from_raw(raw)
        if category_id:
            for category in categories:
                if text(category.get("id")) == category_id:
                    return text(category.get("name"))
        return ""

    @staticmethod
    def _barcodes(raw_json: Any, extra: Iterable[Any]) -> list[str]:
        try:
            values = json.loads(raw_json or "[]") if isinstance(raw_json, str) else list(raw_json or [])
        except Exception:
            values = []
        return list(merge_barcodes(values, extra, limit=1000).barcodes)

    @staticmethod
    def _price(connection: sqlite3.Connection, product_id: Any, raw: Any) -> float:
        price = recursive_price(raw)
        if price:
            return price
        price = money_float(json_pick(raw, (
            "sellingPrice", "sellingCost", "sellingCostPerUnit", "productPrice",
            "retailPrice", "salePrice", "price",
        ), 0))
        if price:
            return price
        try:
            row = connection.execute(
                "SELECT final_selling_price, sigma_existing_selling_price, incoming_selling_price "
                "FROM price_history WHERE product_id=? ORDER BY created_at DESC LIMIT 1",
                (text(product_id),),
            ).fetchone()
            if row:
                return money_float(row[0] or row[1] or row[2])
        except Exception:
            pass
        return 0.0

    def extract_product_price(self, connection: sqlite3.Connection, product_id: Any, raw: Any) -> float:
        return self._price(connection, product_id, raw)

    def _catalog_rows(self, connection: sqlite3.Connection) -> tuple[list[sqlite3.Row], dict[str, list[str]]]:
        products = connection.execute(
            "SELECT sigma_id, name, vendor_code, barcodes_json, raw_json FROM products LIMIT 9000"
        ).fetchall()
        extra: dict[str, list[str]] = {}
        try:
            for row in connection.execute("SELECT product_id, barcode FROM barcodes").fetchall():
                product_id = text(row[0]); barcode = text(row[1])
                if product_id and barcode:
                    extra.setdefault(product_id, []).append(barcode)
        except Exception:
            pass
        return products, extra

    def _db_stamp(self) -> tuple[int, ...] | None:
        try:
            stat = self.db_path.stat()
            wal_path = Path(str(self.db_path) + "-wal")
            try:
                wal_stat = wal_path.stat()
                wal_values = (int(wal_stat.st_mtime_ns), int(wal_stat.st_size))
            except OSError:
                wal_values = (0, 0)
            return int(stat.st_mtime_ns), int(stat.st_size), *wal_values
        except OSError:
            return None

    @property
    def catalog_ready(self) -> bool:
        with self._cache_lock:
            return self._cache_ready

    @property
    def catalog_loading(self) -> bool:
        with self._cache_lock:
            return self._cache_loading

    @staticmethod
    def _price_history(connection: sqlite3.Connection) -> dict[str, float]:
        prices: dict[str, float] = {}
        try:
            rows = connection.execute(
                "SELECT product_id, final_selling_price, sigma_existing_selling_price, "
                "incoming_selling_price FROM price_history ORDER BY created_at DESC"
            ).fetchall()
            for row in rows:
                product_id = text(row[0])
                if product_id and product_id not in prices:
                    prices[product_id] = money_float(row[1] or row[2] or row[3])
        except Exception:
            pass
        return prices

    def _build_catalog_cache(self) -> tuple[tuple[dict[str, Any], ...], dict[str, tuple[dict[str, Any], ...]]]:
        if not self.db_path.exists():
            return (), {}
        connection = sqlite3.connect(str(self.db_path))
        connection.row_factory = sqlite3.Row
        try:
            products, extra = self._catalog_rows(connection)
            history_prices = self._price_history(connection)
            cached: list[dict[str, Any]] = []
            barcode_lists: dict[str, list[dict[str, Any]]] = {}
            for row in products:
                product_id = text(row["sigma_id"])
                raw = row["raw_json"] or "{}"
                barcodes = self._barcodes(row["barcodes_json"], extra.get(product_id, ()))
                name = text(row["name"])
                vendor_code = text(row["vendor_code"])
                price = recursive_price(raw)
                if not price:
                    price = money_float(json_pick(raw, (
                        "sellingPrice", "sellingCost", "sellingCostPerUnit", "productPrice",
                        "retailPrice", "salePrice", "price",
                    ), 0))
                if not price:
                    price = history_prices.get(product_id, 0.0)
                name_search = normalize_search_text(name)
                vendor_search = normalize_search_text(vendor_code)
                barcode_search = " ".join(text(value).upper() for value in barcodes)
                item = {
                    "id": product_id,
                    "name": name,
                    "vendor_code": vendor_code,
                    "barcodes": barcodes,
                    "price": price,
                    "unit": normalize_unit(json_pick(raw, ("unitName", "unit", "measureName", "unitType"), "штука")),
                    "raw": raw,
                    "_name_search": name_search,
                    "_name_tokens": tuple(search_tokens(name)),
                    "_vendor_search": vendor_search,
                    "_barcode_search": barcode_search,
                    "_all_search": f"{name_search} {vendor_search} {barcode_search}",
                }
                cached.append(item)
                for barcode in barcodes:
                    digits = barcode_digits(barcode)
                    if digits:
                        barcode_lists.setdefault(digits, []).append(item)
            return tuple(cached), {key: tuple(value) for key, value in barcode_lists.items()}
        finally:
            connection.close()

    def _refresh_catalog_cache(self) -> None:
        try:
            rows, barcode_index = self._build_catalog_cache()
            stamp = self._db_stamp()
            with self._cache_lock:
                self._catalog_cache = rows
                self._barcode_index = barcode_index
                self._catalog_stamp = stamp
                self._cache_ready = True
        except Exception:
            with self._cache_lock:
                if not self._cache_ready:
                    self._catalog_cache = ()
                    self._barcode_index = {}
                    self._catalog_stamp = self._db_stamp()
                    self._cache_ready = True
        finally:
            with self._cache_lock:
                self._cache_loading = False

    def warm_catalog_cache(self, *, background: bool = True, force: bool = False) -> None:
        stamp = self._db_stamp()
        with self._cache_lock:
            current = self._catalog_stamp
            if not force and self._cache_ready and current == stamp:
                return
            if self._cache_loading:
                return
            self._cache_loading = True
        if background:
            threading.Thread(
                target=self._refresh_catalog_cache,
                name="SAI-manual-receipt-catalog",
                daemon=True,
            ).start()
        else:
            self._refresh_catalog_cache()

    def _cached_rows(self, *, non_blocking: bool) -> tuple[dict[str, Any], ...]:
        self.warm_catalog_cache(background=non_blocking)
        with self._cache_lock:
            return self._catalog_cache

    def _result_row(
        self,
        row: Mapping[str, Any],
        categories: Sequence[Mapping[str, Any]],
        *,
        score: int,
        exact: bool,
    ) -> dict[str, Any]:
        result = {key: value for key, value in row.items() if not key.startswith("_")}
        result["score"] = score
        result["exact_barcode_match"] = exact
        result["category"] = self.resolve_category(
            row.get("raw"), categories,
            json_pick(row.get("raw"), ("categoryName", "productCategoryName", "category", "groupName"), ""),
        )
        return result

    def category_usage_counts(self, rows: Sequence[Mapping[str, Any]]) -> dict[str, int]:
        counts: dict[str, int] = {}
        for row in rows:
            name = text(row.get("category"))
            if name:
                counts[name] = counts.get(name, 0) + 50
        if self.db_path.exists():
            try:
                connection = sqlite3.connect(str(self.db_path))
                for name, count in connection.execute(
                    "SELECT category, COUNT(*) FROM receipt_items "
                    "WHERE category IS NOT NULL AND TRIM(category)<>'' GROUP BY category"
                ).fetchall():
                    normalized = text(name)
                    if normalized:
                        counts[normalized] = counts.get(normalized, 0) + int(count or 0)
                connection.close()
            except Exception:
                pass
        return counts

    def find_exact_barcode(
        self,
        code: Any,
        categories: Sequence[Mapping[str, Any]] = (),
        *,
        non_blocking: bool = False,
    ) -> list[dict[str, Any]]:
        digits = barcode_digits(code)
        if not digits:
            return []
        self._cached_rows(non_blocking=non_blocking)
        with self._cache_lock:
            matches = self._barcode_index.get(digits, ())
        if non_blocking and not matches:
            return self._direct_exact_barcode(digits, categories)
        return [self._result_row(row, categories, score=250, exact=True) for row in matches]

    @staticmethod
    def _row_barcodes(row: Mapping[str, Any]) -> tuple[str, ...]:
        raw_values: list[Any] = []
        for key in ("barcodes", "barcode", "barcode_cell", "used_barcode"):
            value = row.get(key)
            if isinstance(value, (list, tuple, set)):
                raw_values.extend(value)
            elif value not in (None, ""):
                raw_values.append(value)
        return merge_barcodes((), raw_values, limit=1000).barcodes

    def sale_price_for_receipt_row(self, row: Mapping[str, Any]) -> float:
        """Return an unambiguous current catalog price for an NDP row.

        Barcode identity has priority.  Name fallback is intentionally exact:
        a fuzzy guess must never silently put another product's price on a
        seller-facing preliminary invoice.
        """
        cached_rows = self._cached_rows(non_blocking=False)

        for barcode in self._row_barcodes(row):
            digits = barcode_digits(barcode)
            if not digits:
                continue
            with self._cache_lock:
                matches = tuple(self._barcode_index.get(digits, ()))
            if len(matches) == 1:
                price = money_float(matches[0].get("price"))
                if price > 0:
                    return price

        wanted_name = normalize_search_text(row.get("name"))
        if not wanted_name:
            return 0.0
        matches = tuple(item for item in cached_rows if text(item.get("_name_search")) == wanted_name)
        if len(matches) != 1:
            return 0.0
        price = money_float(matches[0].get("price"))
        return price if price > 0 else 0.0

    def _direct_exact_barcode(
        self,
        digits: str,
        categories: Sequence[Mapping[str, Any]] = (),
    ) -> list[dict[str, Any]]:
        """Fast one-barcode fallback while the full search cache is warming."""
        if not digits or not self.db_path.exists():
            return []
        connection = sqlite3.connect(str(self.db_path), timeout=0.35)
        connection.row_factory = sqlite3.Row
        try:
            rows: list[sqlite3.Row] = []
            try:
                rows.extend(connection.execute(
                    "SELECT p.sigma_id, p.name, p.vendor_code, p.barcodes_json, p.raw_json "
                    "FROM barcodes b JOIN products p ON p.sigma_id=b.product_id "
                    "WHERE b.barcode=? LIMIT 12",
                    (digits,),
                ).fetchall())
            except Exception:
                pass
            if not rows:
                try:
                    candidates = connection.execute(
                        "SELECT sigma_id, name, vendor_code, barcodes_json, raw_json "
                        "FROM products WHERE barcodes_json LIKE ? LIMIT 24",
                        (f"%{digits}%",),
                    ).fetchall()
                    rows.extend(
                        row for row in candidates
                        if digits in self._barcodes(row["barcodes_json"], ())
                    )
                except Exception:
                    pass
            results: list[dict[str, Any]] = []
            seen: set[str] = set()
            for row in rows:
                product_id = text(row["sigma_id"])
                if not product_id or product_id in seen:
                    continue
                seen.add(product_id)
                raw = row["raw_json"] or "{}"
                item = {
                    "id": product_id,
                    "name": text(row["name"]),
                    "vendor_code": text(row["vendor_code"]),
                    "barcodes": self._barcodes(row["barcodes_json"], (digits,)),
                    "price": self._price(connection, product_id, raw),
                    "unit": normalize_unit(
                        json_pick(raw, ("unitName", "unit", "measureName", "unitType"), "штука")
                    ),
                    "raw": raw,
                }
                results.append(self._result_row(item, categories, score=250, exact=True))
            return results
        finally:
            connection.close()

    def search(
        self,
        *,
        name_query: Any,
        barcode_query: Any,
        barcode_mode: bool,
        categories: Sequence[Mapping[str, Any]] = (),
        selected_category: Any = "",
        limit: int = 10,
        non_blocking: bool = False,
    ) -> list[dict[str, Any]]:
        query = text(name_query) or text(barcode_query)
        if barcode_mode:
            query = text(name_query) if text(name_query) else text(barcode_query)
            if len(barcode_digits(query)) < 2:
                return []
        elif len(normalize_search_text(name_query)) < 2:
            return []
        cached_rows = self._cached_rows(non_blocking=non_blocking)
        if non_blocking and not self.catalog_ready:
            return []

        result: list[dict[str, Any]] = []
        normalized_query = normalize_search_text(query)
        tokens = search_tokens(query)
        digit_query = barcode_digits(query)
        if barcode_mode and digit_query:
            with self._cache_lock:
                exact_rows = self._barcode_index.get(digit_query, ())
            if exact_rows:
                exact_result = [
                    self._result_row(row, categories, score=220, exact=True)
                    for row in exact_rows
                ]
                if text(selected_category):
                    for item in exact_result:
                        if text(item.get("category")) == text(selected_category):
                            item["score"] = int(item.get("score") or 0) + 8
                return exact_result[: max(1, int(limit))]
        for row in cached_rows:
            if barcode_mode:
                barcode_values = tuple(text(value).upper() for value in (row.get("barcodes") or ()))
                exact = any(barcode_digits(value) == digit_query for value in barcode_values)
                if exact:
                    score = 220
                elif any(barcode_digits(value).startswith(digit_query) for value in barcode_values):
                    score = 150 + min(40, len(digit_query) * 2)
                elif any(digit_query in barcode_digits(value) for value in barcode_values):
                    score = 95 + min(30, len(digit_query))
                else:
                    score = 0
            else:
                all_search = text(row.get("_all_search"))
                if not tokens or not all(
                    token in all_search or (len(token) >= 5 and token[:-1] in all_search)
                    for token in tokens
                ):
                    continue
                name_search = text(row.get("_name_search"))
                vendor_search = text(row.get("_vendor_search"))
                barcode_search = text(row.get("_barcode_search"))
                exact = False
                score = 0
                if normalized_query == vendor_search or normalized_query in barcode_search.split():
                    score += 2000
                if normalized_query == name_search:
                    score += 1600
                if name_search.startswith(normalized_query):
                    score += 900
                for token in tokens:
                    if name_search.startswith(token) or f" {token}" in f" {name_search}":
                        score += 180
                    elif token in name_search:
                        score += 110
                    if vendor_search.startswith(token):
                        score += 150
                    if any(value.startswith(token) for value in barcode_search.split()):
                        score += 170
            if score <= 0:
                continue
            mapped = self._result_row(row, categories, score=score, exact=exact)
            category = text(mapped.get("category"))
            if text(selected_category) and text(selected_category) == category:
                mapped["score"] = score + 8
            result.append(mapped)
        result.sort(key=lambda row: int(row.get("score") or 0), reverse=True)
        return result[: max(1, int(limit))]

    def similar_name_search(
        self,
        name_query: Any,
        *,
        categories: Sequence[Mapping[str, Any]] = (),
        limit: int = 18,
        non_blocking: bool = True,
    ) -> list[dict[str, Any]]:
        """Return broad, human-reviewable name matches from the warm local cache.

        This search deliberately allows different numeric characteristics.  It
        never assigns a barcode automatically: the operator sees the complete
        name, price and barcodes and chooses the intended product explicitly.
        """
        query = normalize_search_text(name_query)
        noise = {
            "ДЛЯ", "ШТ", "ШТУКА", "ШТУК", "УП", "УПАК", "УПАКОВКА",
            "КОМПЛ", "КОМПЛЕКТ", "ММ", "СМ", "МЛ", "КГ", "ВТ", "КВТ",
        }
        query_tokens = tuple(
            token for token in search_tokens(query)
            if len(token) >= 3 and token not in noise and any(char.isalpha() for char in token)
        )
        if len(query) < 2 or not query_tokens:
            return []
        cached_rows = self._cached_rows(non_blocking=non_blocking)
        if non_blocking and not self.catalog_ready:
            return []

        query_set = set(query_tokens)
        ranked: list[tuple[int, dict[str, Any]]] = []
        for row in cached_rows:
            if not row.get("barcodes"):
                continue
            candidate = text(row.get("_name_search"))
            candidate_tokens = tuple(
                token for token in (row.get("_name_tokens") or search_tokens(candidate))
                if len(token) >= 3 and token not in noise and any(char.isalpha() for char in token)
            )
            candidate_set = set(candidate_tokens)
            shared = query_set & candidate_set
            prefix_hits = sum(
                1 for left in query_tokens
                if len(left) >= 4 and any(
                    right.startswith(left) or left.startswith(right)
                    for right in candidate_tokens if len(right) >= 4
                )
            )
            if not shared and not prefix_hits and query not in candidate and candidate not in query:
                continue

            if candidate == query:
                score = 100
            else:
                recall = len(shared) / max(1, len(query_set))
                precision = len(shared) / max(1, len(candidate_set))
                sequence = SequenceMatcher(None, query, candidate).ratio()
                containment = 1.0 if query in candidate or candidate in query else 0.0
                score = int(round(
                    48 * recall + 18 * precision + 24 * sequence
                    + 7 * containment + min(3, prefix_hits) * 3
                ))
                score = max(1, min(99, score))
            ranked.append((score, row))

        ranked.sort(key=lambda pair: (pair[0], text(pair[1].get("name"))), reverse=True)
        return [
            self._result_row(row, categories, score=score, exact=(score == 100))
            for score, row in ranked[: max(1, int(limit))]
        ]

    def load_generated_barcodes(self) -> list[str]:
        try:
            data = json.loads(self.generated_path.read_text(encoding="utf-8"))
            values = data.get("barcodes", ()) if isinstance(data, Mapping) else data
            return list(merge_barcodes((), values or (), limit=5000).barcodes)
        except Exception:
            return []

    def save_generated_barcodes(self, values: Iterable[Any]) -> None:
        ensure_runtime_dirs()
        self.generated_path.parent.mkdir(parents=True, exist_ok=True)
        barcodes = list(merge_barcodes((), values, limit=5000).barcodes)[-5000:]
        temporary = self.generated_path.with_suffix(self.generated_path.suffix + ".tmp")
        temporary.write_text(json.dumps({"barcodes": barcodes}, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self.generated_path)

    def existing_internal_barcodes(self, current: Iterable[Any], rows: Sequence[Mapping[str, Any]]) -> set[str]:
        existing = {text(value) for value in current if text(value)}
        for row in rows:
            existing.update(text(value) for value in (row.get("barcodes") or ()) if text(value))
        existing.update(self.load_generated_barcodes())
        for product in self._cached_rows(non_blocking=False):
            existing.update(text(value) for value in (product.get("barcodes") or ()) if text(value))
        if self.db_path.exists():
            try:
                connection = sqlite3.connect(str(self.db_path))
                existing.update(text(row[0]) for row in connection.execute("SELECT barcode FROM barcodes WHERE barcode LIKE '77%'").fetchall() if text(row[0]))
                connection.close()
            except Exception:
                pass
        return existing

    def generate_internal_barcode(self, current: Iterable[Any], rows: Sequence[Mapping[str, Any]]) -> GeneratedBarcode:
        config = dict(self.config_loader() or {})
        prefix = normalized_internal_prefix(config.get("free_receipt_barcode_prefix") or "7700")
        existing = self.existing_internal_barcodes(current, rows)
        max_counter = (10 ** max(1, 12 - len(prefix))) - 1
        remembered_raw = int(money_float(config.get("free_receipt_barcode_last_counter")))
        remembered = remembered_raw if 0 <= remembered_raw <= max_counter else 0
        observed = highest_internal_counter(existing, prefix)
        start = max(remembered, observed) + 1
        code, counter = next_internal_barcode(prefix, start, existing)
        history = self.load_generated_barcodes()
        history.append(code)
        self.save_generated_barcodes(history)
        self.config_saver({
            "free_receipt_barcode_prefix": prefix,
            "free_receipt_barcode_last_counter": counter,
        })
        return GeneratedBarcode(code, counter)


__all__ = ["FreeReceiptCatalogService", "GeneratedBarcode", "BARCODE_LIMIT"]
