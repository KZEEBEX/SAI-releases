#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Adaptive SAI Invoice Agent: dual-Luna consensus with cropped escalation."""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

import sai_converter
import sai_page_orientation
import sai_product_names
from sai_core import gtin_check_digit_ok
from sai_runtime_paths import USER_DATA_DIR
from sai_invoice_ai_errors import OpenAIInvoiceError
import sai_invoice_ai_client as _invoice_client
import sai_invoice_ai_contract as _invoice_contract
import sai_invoice_ai_models as _invoice_models
import sai_invoice_ai_reconciliation as _invoice_reconciliation
from sai_invoice_ai_contract import (
    AI_CONFIG_DIR,
    ARBITRATE_PROMPT_PATH,
    ARBITRATE_PROMPT_VERSION,
    AUDIT_PROMPT_PATH,
    AUDIT_PROMPT_VERSION,
    AUDIT_SCHEMA_PATH,
    AUDIT_SCHEMA_VERSION,
    CONTRACT_VERSION,
    HEADER_PROMPT_PATH,
    HEADER_PROMPT_VERSION,
    HEADER_SCHEMA_PATH,
    HEADER_SCHEMA_VERSION,
    OPERATOR_HINTS_TOKEN,
    PROMPT_PATH,
    PROMPT_VERSION,
    SCHEMA_PATH,
    SCHEMA_VERSION,
)
import sai_invoice_ai_sources as _invoice_sources
from sai_invoice_ai_sources import (
    FILE_EXTENSIONS,
    IMAGE_EXTENSIONS,
    MAX_FILE_BYTES,
    MAX_TOTAL_BYTES,
    SUPPORTED_EXTENSIONS,
)
from sai_invoice_ai_pipeline import (
    InvoicePipelineState,
    build_quality_metadata,
    merge_problem_notes,
    restore_document_total,
)
from sai_invoice_ai_telemetry import (
    AI_ECONOMY_TELEMETRY_PATH,
    MODEL_PRICES_USD_PER_MILLION,
    SHADOW_ECONOMY_VERSION,
    aggregate_stages as _aggregate_stages,
    append_economy_telemetry as _append_economy_telemetry,
    empty_shadow_summary,
    estimate_response_cost_usd,
    response_usage,
    shadow_actual_impact as _shadow_actual_impact,
    shadow_page_risk as _shadow_page_risk,
    source_telemetry_summary as _source_telemetry_summary,
    stage_record as _stage_record,
    summarize_shadow_pages as _summarize_shadow_pages,
)

DEFAULT_MODEL = _invoice_models.DEFAULT_MODEL
AUDIT_MODEL = _invoice_models.AUDIT_MODEL
FALLBACK_MODEL = _invoice_models.FALLBACK_MODEL
DEFAULT_API_BASE = _invoice_models.DEFAULT_API_BASE
MAX_OUTPUT_TOKENS = _invoice_models.MAX_OUTPUT_TOKENS
MAX_AUDIT_OUTPUT_TOKENS = _invoice_models.MAX_AUDIT_OUTPUT_TOKENS
MAX_HEADER_OUTPUT_TOKENS = _invoice_models.MAX_HEADER_OUTPUT_TOKENS
MAX_SOL_REPAIR_ROWS = _invoice_models.MAX_SOL_REPAIR_ROWS
MAX_SOL_REPAIR_PAGES = _invoice_models.MAX_SOL_REPAIR_PAGES
LEGACY_PRIMARY_MODELS = _invoice_models.LEGACY_PRIMARY_MODELS
quality_model = _invoice_models.quality_model
economical_model = _invoice_models.economical_model

AI_CACHE_DIR = USER_DATA_DIR / "cache" / "openai_invoice_v14"
FINAL_LINE_TOTAL_POLICY = "final_line_total_including_vat_and_discounts"
VALID_BARCODE_LENGTHS = {8, 12, 13, 14}



# Compatibility facade for the versioned invoice AI contract.
def _sha256_file(path: Path) -> str:
    return _invoice_contract.sha256_file(path)


def _read_required_text(path: Path, label: str) -> str:
    return _invoice_contract.read_required_text(path, label)


def _assert_openai_schema_compatible(schema: Any, label: str) -> None:
    _invoice_contract.assert_openai_schema_compatible(schema, label)


def load_invoice_schema() -> Dict[str, Any]:
    return _invoice_contract.load_invoice_schema()


def load_audit_schema() -> Dict[str, Any]:
    return _invoice_contract.load_audit_schema()


def load_header_schema() -> Dict[str, Any]:
    return _invoice_contract.load_header_schema()


def _load_prompt(path: Path, marker: str) -> str:
    return _invoice_contract.load_prompt(path, marker)


def invoice_contract_metadata() -> Dict[str, str]:
    return _invoice_contract.invoice_contract_metadata()


def build_invoice_schema() -> Dict[str, Any]:
    return load_invoice_schema()


def build_audit_schema() -> Dict[str, Any]:
    return load_audit_schema()


def build_header_schema() -> Dict[str, Any]:
    return load_header_schema()


def _operator_hints(supplier_hint: str, date_hint: str, invoice_hint: str) -> str:
    return _invoice_contract.operator_hints(supplier_hint, date_hint, invoice_hint)


def _instruction_text(stage: str, supplier_hint: str, date_hint: str, invoice_hint: str) -> str:
    return _invoice_contract.instruction_text(stage, supplier_hint, date_hint, invoice_hint)


# Compatibility facade: historical callers keep importing source helpers from
# sai_openai_invoice while their implementation lives in sai_invoice_ai_sources.
def _mime_for(path: Path) -> str:
    return _invoice_sources.mime_for(path)


def validate_source_paths(paths: Sequence[str | Path]) -> List[Path]:
    return _invoice_sources.validate_source_paths(paths)


def _image_data_url(data: bytes, mime: str = "image/jpeg") -> str:
    return _invoice_sources.image_data_url(data, mime)


def _qimage_jpeg_bytes(image: Any, quality: int = 88) -> bytes:
    return _invoice_sources.qimage_jpeg_bytes(image, quality)


def _overlapping_horizontal_bands(image: Any, count: int = 4, overlap_ratio: float = 0.12) -> List[Any]:
    return _invoice_sources.overlapping_horizontal_bands(image, count, overlap_ratio)


def _row_groups_for_targets(
    draft: Mapping[str, Any] | None,
    target_rows: Sequence[int] | None,
) -> Dict[int, List[Dict[str, Any]]]:
    return _invoice_sources.row_groups_for_targets(draft, target_rows)


def _row_crop_rect(image: Any, page_number: int, group: Mapping[str, Any]) -> Any:
    return _invoice_sources.row_crop_rect(image, page_number, group)


def _visual_rotation_label(angle: int) -> str:
    return _invoice_sources.visual_rotation_label(angle)


def _render_prepared_visual_views(
    paths: Sequence[Path],
    orientation_plan: Mapping[str, Sequence[Any]] | None = None,
    include_bands: bool = False,
    target_global_pages: Sequence[int] | None = None,
    target_row_groups: Mapping[int, Sequence[Mapping[str, Any]]] | None = None,
    max_pages: int = 40,
    max_bytes: int = 36 * 1024 * 1024,
) -> tuple[List[tuple[Path, str, bytes]], set[Path]]:
    """Compatibility wrapper for operator-confirmed source rendering."""
    return _invoice_sources.render_prepared_visual_views(
        paths, orientation_plan, include_bands, target_global_pages,
        target_row_groups, max_pages, max_bytes,
    )


def _append_sources(
    content: List[Dict[str, Any]],
    paths: Sequence[Path],
    prepared_visuals: bool = False,
    precision_views: bool = False,
    orientation_plan: Mapping[str, Sequence[Any]] | None = None,
    target_global_pages: Sequence[int] | None = None,
    target_row_groups: Mapping[int, Sequence[Mapping[str, Any]]] | None = None,
) -> tuple[bool, int]:
    return _invoice_sources.append_sources(
        content, paths, prepared_visuals, precision_views, orientation_plan,
        target_global_pages, target_row_groups,
    )
























def _compact_audit_draft(doc:Dict[str,Any],target_rows:Sequence[int]|None=None)->Dict[str,Any]:
    compact={
      'supplier':sai_converter.safe_str(doc.get('supplier')),
      'invoice_date':sai_converter.safe_str(doc.get('invoice_date')),
      'invoice_number':sai_converter.safe_str(doc.get('invoice_number')),
      'document_total':sai_converter.parse_float(doc.get('document_total')),
      'items':[]
    }
    wanted={int(x) for x in (target_rows or []) if int(x)>0}
    for pos,row in enumerate(doc.get('items') or [],start=1):
        number=int(row.get('source_row') or pos)
        if wanted and number not in wanted:
            continue
        compact['items'].append({
          'source_row':number,
          'source_page':int(row.get('source_page') or 1),
          'raw_name':sai_converter.safe_str(row.get('raw_name') or row.get('name')),
          'article':sai_converter.safe_str(row.get('article')),
          'barcodes':[sai_converter.safe_str(x) for x in (row.get('barcodes') or [])],
          'quantity':sai_converter.parse_float(row.get('quantity')),
          'unit':sai_converter.safe_str(row.get('unit')),
          'line_total':sai_converter.parse_float(row.get('line_total')),
        })
    return compact

def build_request_payload(
    paths:Sequence[str|Path],
    model:str=DEFAULT_MODEL,
    supplier_hint:str='',
    date_hint:str='',
    invoice_hint:str='',
    stage:str='extract',
    draft:Dict[str,Any]|None=None,
    target_rows:Sequence[int]|None=None,
    audit_notes:Sequence[str]|None=None,
    orientation_plan:Mapping[str,Sequence[Any]]|None=None,
    target_global_pages:Sequence[int]|None=None,
)->Dict[str,Any]:
    checked=validate_source_paths(paths)
    if stage in {'extract','extract_batch','extract_luna','extract_luna_verify'}:
        selected=quality_model(model)
        prompt_stage='extract'
        schema=build_invoice_schema()
        format_name='sai_invoice_agent_extraction_v9'
        max_tokens=MAX_OUTPUT_TOKENS
        effort='low'
    elif stage=='extract_terra':
        selected=AUDIT_MODEL
        prompt_stage='extract'
        schema=build_invoice_schema()
        format_name='sai_invoice_agent_extraction_terra_v9'
        max_tokens=MAX_OUTPUT_TOKENS
        effort='low'
    elif stage=='extract_sol':
        selected=FALLBACK_MODEL
        prompt_stage='extract'
        schema=build_invoice_schema()
        format_name='sai_invoice_agent_extraction_sol_v9'
        max_tokens=MAX_OUTPUT_TOKENS
        effort='medium'
    elif stage in {'header_luna','header_terra'}:
        selected=quality_model(model) if stage=='header_luna' else AUDIT_MODEL
        prompt_stage='header'
        schema=build_header_schema()
        format_name='sai_invoice_header_v1'
        max_tokens=MAX_HEADER_OUTPUT_TOKENS
        effort='low'
    elif stage in {'audit','repair'}:
        selected=AUDIT_MODEL
        prompt_stage='repair'
        schema=build_audit_schema()
        format_name='sai_invoice_agent_repair_v7'
        max_tokens=MAX_AUDIT_OUTPUT_TOKENS
        effort='low'
    elif stage in {'escalate','arbitrate'}:
        selected=FALLBACK_MODEL
        prompt_stage='escalate'
        schema=build_audit_schema()
        format_name='sai_invoice_agent_escalation_v7'
        max_tokens=MAX_AUDIT_OUTPUT_TOKENS
        effort='medium'
    else:
        raise OpenAIInvoiceError(f'Неизвестный этап AI-агента: {stage}')
    content=[{'type':'input_text','text':_instruction_text(prompt_stage,supplier_hint,date_hint,invoice_hint)}]
    if stage=='extract_luna_verify':
        content.append({'type':'input_text','text':'Это независимое второе чтение той же страницы. Не копируй и не угадывай данные из первого прохода: заново прочитай изображение посимвольно.'})
    if stage=='extract_batch':
        content.append({'type':'input_text','text':
            'Тебе одновременно передан ВЕСЬ КОМПЛЕКТ страниц и файлов. Сначала сопоставь все страницы между собой. '
            'Если одна и та же страница случайно приложена повторно (в том же или другом файле), извлеки её товарные строки ТОЛЬКО ОДИН РАЗ и используй source_page первого экземпляра. '
            'Повтор определяй по содержимому всего листа: реквизитам, номерам строк, товарам, количествам и суммам. '
            'Не удаляй законные одинаковые товары из разных строк или из действительно разных документов. '
            'Верни единый результат по всему комплекту без повторных листов и повторных позиций.'})
    if target_global_pages and prompt_stage=='extract':
        pages=', '.join(str(int(x)) for x in sorted({int(x) for x in target_global_pages if int(x)>0}))
        content.append({'type':'input_text','text':
            'SAI ПЕРЕДАЛ ТОЛЬКО СТРАНИЦУ/СТРАНИЦЫ '+pages+'. '
            'Верни товары только с этих изображений. source_page должен равняться номеру страницы SAI. '
            'Не считай отсутствие товаров на других страницах ошибкой.'})
    if draft is not None:
        content.append({'type':'input_text','text':'КОМПАКТНЫЙ ЧЕРНОВИК SAI (не источник истины):\n'+json.dumps(_compact_audit_draft(draft,target_rows),ensure_ascii=False,separators=(',',':'))})
    if target_rows:
        content.append({'type':'input_text','text':'ПРОВЕРЬ И ВЕРНИ ТОЛЬКО source_row: '+', '.join(str(int(x)) for x in target_rows)})
    if audit_notes:
        content.append({'type':'input_text','text':'ЛОКАЛЬНЫЕ ПРОВЕРКИ SAI ОБНАРУЖИЛИ:\n'+'\n'.join('- '+sai_converter.safe_str(x) for x in audit_notes if sai_converter.safe_str(x))})
    target_row_groups=_row_groups_for_targets(draft,target_rows) if prompt_stage in {'repair','escalate'} else {}
    rendered,prepared_view_count=_append_sources(
        content,checked,prepared_visuals=True,
        precision_views=(prompt_stage=='extract' and stage!='extract_batch'),
        orientation_plan=orientation_plan,target_global_pages=target_global_pages,
        target_row_groups=target_row_groups,
    )
    return {
        'model':selected,'store':False,'reasoning':{'effort':effort},'max_output_tokens':max_tokens,
        'input':[{'role':'user','content':content}],
        'text':{'verbosity':'low','format':{'type':'json_schema','name':format_name,'strict':True,'schema':schema}},
        '_sai_precision_views_used':rendered,
        '_sai_precision_views_count':prepared_view_count,
        '_sai_orientation_plan':sai_page_orientation.normalize_plan(checked,orientation_plan),
        '_sai_target_pages':sorted({int(x) for x in (target_global_pages or []) if int(x)>0}),
    }


# Compatibility facade for transport and response parsing.
_make_opener = _invoice_client.make_opener
_extract_output_text = _invoice_client.extract_output_text
_parse_response_document = _invoice_client.parse_response_document
_parse_response_document_allow_empty = _invoice_client.parse_response_document_allow_empty
_parse_audit_response = _invoice_client.parse_audit_response
_parse_header_response = _invoice_client.parse_header_response
_response_from_document = _invoice_client.response_from_document
call_openai = _invoice_client.call_openai

# Compatibility facade for deterministic reconciliation and validation.
_confirmed_visual_page_numbers = _invoice_reconciliation._confirmed_visual_page_numbers
_row_signature = _invoice_reconciliation._row_signature
_useful_page_warning = _invoice_reconciliation._useful_page_warning
_valid_barcodes = _invoice_reconciliation._valid_barcodes
_prefer_equivalent_text = _invoice_reconciliation._prefer_equivalent_text
_norm_literal = _invoice_reconciliation._norm_literal
_norm_compare = _invoice_reconciliation._norm_compare
_equivalent_text = _invoice_reconciliation._equivalent_text
_equivalent_unit = _invoice_reconciliation._equivalent_unit
_row_map = _invoice_reconciliation._row_map
_merge_page_documents = _invoice_reconciliation._merge_page_documents
merge_source_documents = _invoice_reconciliation.merge_source_documents
reconcile_luna_page = _invoice_reconciliation.reconcile_luna_page
apply_audit = _invoice_reconciliation.apply_audit
_sanitize_and_evaluate_document = _invoice_reconciliation._sanitize_and_evaluate_document
_target_pages_for_rows = _invoice_reconciliation._target_pages_for_rows
_check_audit_coverage = _invoice_reconciliation._check_audit_coverage
_blocking_quality_notes = _invoice_reconciliation._blocking_quality_notes
_reviewable_quality_notes = _invoice_reconciliation._reviewable_quality_notes
_document_rounding_tolerance = _invoice_reconciliation._document_rounding_tolerance
_unique_append = _invoice_reconciliation._unique_append

























def _cache_key(paths:Sequence[str|Path],model:str,supplier_hint:str,date_hint:str,invoice_hint:str,orientation_plan:Mapping[str,Sequence[Any]]|None=None)->str:
    contract=invoice_contract_metadata(); digest=hashlib.sha256(); digest.update(CONTRACT_VERSION.encode()); digest.update(quality_model(model).encode())
    digest.update(b'\0MULTI_FILE_SPLIT_AND_MERGE_V1\0')
    for key in sorted(contract): digest.update(key.encode()); digest.update(contract[key].encode())
    for value in (supplier_hint,date_hint,invoice_hint): digest.update(b'\0'); digest.update(str(value or '').strip().encode())
    digest.update(b'\0ORIENTATION\0'); digest.update(sai_page_orientation.plan_fingerprint(paths,orientation_plan).encode())
    for path in validate_source_paths(paths): digest.update(b'\0FILE\0'); digest.update(path.name.encode(errors='replace')); digest.update(str(path.stat().st_size).encode()); digest.update(_sha256_file(path).encode())
    return digest.hexdigest()

def _cache_path(key:str)->Path: return AI_CACHE_DIR/f'{key}.json'

def _read_cached_bundle(key:str)->Dict[str,Any]|None:
    path=_cache_path(key)
    if not path.is_file(): return None
    try:
        value=json.loads(path.read_text(encoding='utf-8-sig'))
        if value.get('cache_version')!=14: raise ValueError('old cache')
        _parse_response_document(value['final_response'],'кэш')
        if not isinstance(value.get('stages'),list): raise ValueError('stages')
        return value
    except Exception:
        try: path.unlink()
        except Exception: pass
        return None

def _write_cached_bundle(key:str,bundle:Dict[str,Any])->None:
    AI_CACHE_DIR.mkdir(parents=True,exist_ok=True); path=_cache_path(key); temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(bundle,ensure_ascii=False),encoding='utf-8'); temp.replace(path)

















def response_to_convert_result(response:Dict[str,Any],source_paths:Sequence[str|Path],markup_percent:float=60.0,supplier_hint:str='',date_hint:str='',invoice_hint:str='',contract_metadata:Dict[str,str]|None=None,model:str=DEFAULT_MODEL,cache_hit:bool=False,stages:Sequence[Dict[str,Any]]|None=None,quality_metadata:Dict[str,Any]|None=None)->sai_converter.ConvertResult:
    doc=_parse_response_document(response,'финальный результат')
    supplier=sai_converter.safe_str(supplier_hint or doc.get('supplier')); date=sai_converter.parse_date(date_hint or doc.get('invoice_date')); invoice_number=sai_converter.safe_str(invoice_hint or doc.get('invoice_number'))
    result=sai_converter.ConvertResult(source_path=' | '.join(str(Path(p)) for p in source_paths),source_type='openai',supplier=supplier,date=date,invoice_number=invoice_number,markup_percent=float(markup_percent or 0),warnings=[]); result.validation={}; result.critical_issues=[]
    document_total=max(0.0,sai_converter.parse_float(doc.get('document_total'),0.0)); document_total_note=sai_converter.safe_str(doc.get('document_total_note'))
    line_total_sum=0.0; price_from_line_total=0; price_from_printed=0; missing_price_basis=0; printed_price_mismatch=0; invalid_barcode_count=0
    qmeta=dict(quality_metadata or {}); row_disagreements={int(k):v for k,v in (qmeta.get('row_corrections') or {}).items()}; unresolved_rows=set(int(x) for x in (qmeta.get('unresolved_rows') or [])); reconciled=not bool(unresolved_rows)
    ambiguous_quantities=_invoice_sources.ambiguous_quantity_hints(source_paths)
    rows=sorted(list(doc.get('items') or []),key=lambda r:int(r.get('source_row') or 999999))
    for index,raw in enumerate(rows,start=1):
        source_row=int(raw.get('source_row') or index); raw_name=sai_converter.safe_str(raw.get('raw_name') or raw.get('name')); name=sai_converter.clean_name(raw.get('name') or raw_name)
        qty=max(0.0,sai_converter.parse_float(raw.get('quantity'),0.0)); printed_buy=max(0.0,sai_converter.parse_float(raw.get('purchase_price'),0.0)); line_total=max(0.0,sai_converter.parse_float(raw.get('line_total'),0.0)); issues=[]
        confidence=0.97 if source_row not in row_disagreements else 0.92
        if source_row in unresolved_rows: confidence=min(confidence,0.55)
        if qty>0 and line_total>0:
            buy=line_total/qty; price_source='сумма строки / количество'; price_from_line_total+=1; line_total_sum+=line_total
            if printed_buy>0 and abs(printed_buy*qty-line_total)>max(0.05,abs(qty)*0.005+0.01): printed_price_mismatch+=1
        elif printed_buy>0:
            buy=printed_buy; price_source='колонка цены — нет суммы строки'; price_from_printed+=1; issues.append('нет финальной суммы строки — проверь закупочную цену'); line_total_sum+=printed_buy*qty if qty>0 else 0
        else: buy=0.0; price_source='не определена'; missing_price_basis+=1
        barcodes=[]
        for candidate in raw.get('barcodes') or []:
            for code in re.findall(r'(?<!\d)(\d{8}|\d{12}|\d{13}|\d{14})(?!\d)',sai_converter.safe_str(candidate)):
                if code in barcodes: continue
                if gtin_check_digit_ok(code): barcodes.append(code)
                else: invalid_barcode_count+=1; issues.append(f'ШК {code} не прошёл контрольную цифру — отсканируй товар'); confidence=min(confidence,0.45)
        if source_row in unresolved_rows: issues.append('AI не смог уверенно подтвердить критическое поле — сверь строку с документом')
        original_quantity=ambiguous_quantities.get(_invoice_sources.quantity_name_key(raw_name))
        if original_quantity:
            issues.append(f'проверь количество: в исходном XLSX указано {original_quantity}')
            confidence=min(confidence,0.55)
        if not name: issues.append('нет наименования')
        if qty<=0: issues.append('проверь количество')
        if buy<=0: issues.append('проверь закупочную цену')
        note=sai_converter.safe_str(raw.get('note'))
        if note: issues.append(note)
        if not name and qty<=0 and buy<=0: continue
        item=sai_converter.ConvertItem(row=source_row,name=name,quantity=qty,unit=sai_converter.normalize_unit(raw.get('unit')),purchase_price=round(buy,4),sale_price=sai_converter.calc_sale_price(buy,markup_percent),article=sai_converter.safe_str(raw.get('article')),barcodes=barcodes,comment=note,issues=issues)
        item.raw_name=raw_name
        normalized_name=sai_product_names.normalize_product_name(item.name or raw_name,article=item.article)
        if normalized_name.normalized:
            item.name=normalized_name.normalized
        item.name_normalization_changes=list(normalized_name.changes)
        item.name_search_aliases=list(normalized_name.search_aliases)
        item.name_normalizer_version=sai_product_names.RULES_VERSION
        item.line_total=round(line_total if line_total>0 else buy*qty,4)
        item.purchase_price_source=price_source
        item.confidence=confidence
        result.items.append(item)
    item_count=len(result.items); total_difference=abs(line_total_sum-document_total) if document_total>0 else 0.0; total_tolerance=_document_rounding_tolerance(item_count)
    if document_total_note:_unique_append(result.warnings,document_total_note)
    if document_total>0 and total_difference>total_tolerance:
        message=f'Сумма товарных строк {line_total_sum:.2f} не сходится с итогом документа {document_total:.2f}; разница {total_difference:.2f}.'; _unique_append(result.critical_issues,message); _unique_append(result.warnings,message)
    if price_from_printed:_unique_append(result.warnings,f'У {price_from_printed} позиций нет финальной суммы строки: цена взята из колонки и требует проверки.')
    if missing_price_basis:_unique_append(result.critical_issues,f'У {missing_price_basis} позиций не определена ни финальная сумма строки, ни закупочная цена.')
    if invalid_barcode_count:_unique_append(result.warnings,f'Отклонено ШК с неверной контрольной цифрой: {invalid_barcode_count}. Эти позиции пойдут в полуавтоматический режим.')
    stage_list=list(stages or [])
    if not stage_list:
        stage_list=[_stage_record('Одиночный тестовый ответ',str(model or DEFAULT_MODEL),response)]
    usage,total_cost=_aggregate_stages(stage_list)
    result.validation={'ai_contract':dict(contract_metadata or invoice_contract_metadata()),'purchase_price_policy':FINAL_LINE_TOTAL_POLICY,'document_total':round(document_total,4),'items_total':round(line_total_sum,4),'total_difference':round(total_difference,4),'total_tolerance':round(total_tolerance,4),'price_from_line_total':price_from_line_total,'price_from_printed':price_from_printed,'missing_price_basis':missing_price_basis,'printed_price_mismatch_info':printed_price_mismatch,'invalid_barcode_count':invalid_barcode_count,'document_total_note':document_total_note,'openai_model':quality_model(model),'openai_usage':usage,'openai_stages':stage_list,'cache_hit':bool(cache_hit),'estimated_cost_usd':0.0 if cache_hit and total_cost is not None else total_cost,'original_estimated_cost_usd':total_cost,'quality_passes':len(stage_list),'reconciled':reconciled,'disagreement_count':int(qmeta.get('correction_count') or 0),'corrected_rows':sorted(row_disagreements),'unresolved_rows':sorted(unresolved_rows),'barcode_omitted_rows':sorted(int(x) for x in (qmeta.get('barcode_omitted_rows') or [])),'model_warnings':[sai_converter.safe_str(x) for x in (doc.get('warnings') or []) if sai_converter.safe_str(x)],'precision_views_used':bool(qmeta.get('precision_views_used')),'precision_views_count':int(qmeta.get('precision_views_count') or 0),'audit_model':qmeta.get('audit_model') or AUDIT_MODEL,'fallback_model':qmeta.get('fallback_model') or '','agent_mode':qmeta.get('agent_mode') or 'dual_luna_consensus_cropped_terra_sol','pagewise_primary':bool(qmeta.get('pagewise_primary')),'pagewise_pages':int(qmeta.get('pagewise_pages') or 0),'arbitration_rows':list(qmeta.get('arbitration_rows') or []),'local_quality_notes':list(qmeta.get('local_quality_notes') or []),'manual_header_fields':list(qmeta.get('manual_header_fields') or []),'manual_review_required':bool(qmeta.get('manual_review_required')),'manual_review_reasons':list(qmeta.get('manual_review_reasons') or []),'manual_review_accepted':bool(qmeta.get('manual_review_accepted')),'page_orientation_plan':qmeta.get('page_orientation_plan') or {},'economy_shadow':qmeta.get('economy_shadow') or {}}
    if not result.items: result.errors.append('OpenAI не нашёл товарных строк в документе.')
    return result

def _record_pipeline_stage(
    state:InvoicePipelineState,
    name:str,
    model:str,
    response:Dict[str,Any],
    payload:Mapping[str,Any]|None=None,
)->Dict[str,Any]:
    stage=_stage_record(name,model,response)
    state.stages.append(stage)
    if payload is not None:
        state.record_payload(payload)
    return stage


def _recover_visual_header(
    paths:Sequence[str|Path],
    first_doc:Dict[str,Any],
    visual_pages:Sequence[int],
    selected:str,
    supplier_hint:str,
    date_hint:str,
    invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],
    api_key:str,
    api_base:str,
    proxy_url:str,
    timeout:int,
    state:InvoicePipelineState,
)->Dict[str,Any]:
    if supplier_hint:first_doc['supplier']=supplier_hint
    if date_hint:first_doc['invoice_date']=date_hint
    if invoice_hint:first_doc['invoice_number']=invoice_hint
    missing_header=[field for field in ('supplier','invoice_date','invoice_number') if not sai_converter.safe_str(first_doc.get(field))]
    if not missing_header:
        return first_doc

    header_payload=build_request_payload(
        paths,selected,supplier_hint,date_hint,invoice_hint,'header_luna',
        orientation_plan=normalized_orientation,target_global_pages=[visual_pages[0]],
    )
    header_response=call_openai(header_payload,api_key,api_base,proxy_url,timeout)
    _record_pipeline_stage(state,'Luna: реквизиты первой страницы',selected,header_response,header_payload)
    header=_parse_header_response(header_response,'Luna: реквизиты')
    for field in ('supplier','invoice_date','invoice_number'):
        if not sai_converter.safe_str(first_doc.get(field)) and sai_converter.safe_str(header.get(field)):
            first_doc[field]=header[field]
    if sai_converter.parse_float(first_doc.get('document_total'))<=0 and header.get('document_total'):
        first_doc['document_total']=header['document_total']
    missing_header=[field for field in ('supplier','invoice_date','invoice_number') if not sai_converter.safe_str(first_doc.get(field))]
    if not missing_header:
        return first_doc

    header_payload=build_request_payload(
        paths,AUDIT_MODEL,supplier_hint,date_hint,invoice_hint,'header_terra',
        orientation_plan=normalized_orientation,target_global_pages=[visual_pages[0]],
    )
    header_response=call_openai(header_payload,api_key,api_base,proxy_url,timeout)
    _record_pipeline_stage(state,'Terra: реквизиты первой страницы',AUDIT_MODEL,header_response,header_payload)
    header=_parse_header_response(header_response,'Terra: реквизиты')
    for field in ('supplier','invoice_date','invoice_number'):
        if not sai_converter.safe_str(first_doc.get(field)) and sai_converter.safe_str(header.get(field)):
            first_doc[field]=header[field]
    missing_header=[field for field in ('supplier','invoice_date','invoice_number') if not sai_converter.safe_str(first_doc.get(field))]
    if missing_header:
        # The paid recognition has already produced usable item rows. Missing
        # document headers are safe for an operator to enter locally and must
        # not discard the result or force another paid request.
        state.manual_header_fields=list(missing_header)
    return first_doc


def _read_visual_document(
    paths:Sequence[str|Path],
    visual_pages:Sequence[int],
    selected:str,
    supplier_hint:str,
    date_hint:str,
    invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],
    api_key:str,
    api_base:str,
    proxy_url:str,
    timeout:int,
    state:InvoicePipelineState,
)->Dict[str,Any]:
    page_documents=[]
    for page_number in visual_pages:
        primary=None
        attempts=(
            ('extract_luna',selected,f'Luna: чтение страницы {page_number}'),
            ('extract_terra',AUDIT_MODEL,f'Terra: резервное чтение страницы {page_number}'),
            ('extract_sol',FALLBACK_MODEL,f'Sol: аварийное чтение страницы {page_number}'),
        )
        for attempt_stage,attempt_model,stage_label in attempts:
            payload=build_request_payload(
                paths,attempt_model,supplier_hint,date_hint,invoice_hint,attempt_stage,
                orientation_plan=normalized_orientation,target_global_pages=[page_number],
            )
            response=call_openai(payload,api_key,api_base,proxy_url,timeout)
            _record_pipeline_stage(state,stage_label,attempt_model,response,payload)
            candidate=_parse_response_document_allow_empty(response,stage_label)
            if candidate.get('items'):
                primary=candidate
                break
        if primary is None:
            _usage,cost=_aggregate_stages(state.stages)
            spent=f' Потрачено ориентировочно ${cost:.4f}.' if cost is not None else ''
            raise OpenAIInvoiceError(
                f'Страница {page_number} не дала ни одной товарной строки даже после Luna, Terra и Sol.'+
                spent+' Результат не сохранён.'
            )

        shadow_prediction=_shadow_page_risk(primary,page_number)
        verify_payload=build_request_payload(
            paths,selected,supplier_hint,date_hint,invoice_hint,'extract_luna_verify',
            orientation_plan=normalized_orientation,target_global_pages=[page_number],
        )
        verify_response=call_openai(verify_payload,api_key,api_base,proxy_url,timeout)
        verify_stage=_record_pipeline_stage(
            state,f'Luna: независимая проверка страницы {page_number}',selected,verify_response,verify_payload,
        )
        verification_route_cost=float(verify_stage.get('estimated_cost_usd') or 0)
        verification=_parse_response_document_allow_empty(verify_response,f'Luna: проверка страницы {page_number}')
        if not verification.get('items'):
            fallback_payload=build_request_payload(
                paths,AUDIT_MODEL,supplier_hint,date_hint,invoice_hint,'extract_terra',
                orientation_plan=normalized_orientation,target_global_pages=[page_number],
            )
            fallback_response=call_openai(fallback_payload,api_key,api_base,proxy_url,timeout)
            fallback_stage=_record_pipeline_stage(
                state,f'Terra: резервная проверка страницы {page_number}',AUDIT_MODEL,fallback_response,fallback_payload,
            )
            verification_route_cost+=float(fallback_stage.get('estimated_cost_usd') or 0)
            verification=_parse_response_document(fallback_response,f'Terra: проверка страницы {page_number}')

        reconciled,page_problem_rows,page_notes,page_omitted,page_changes=reconcile_luna_page(primary,verification,page_number)
        shadow_prediction['second_luna_cost_usd']=verify_stage.get('estimated_cost_usd')
        shadow_prediction['verification_route_cost_usd']=round(verification_route_cost,8)
        shadow_prediction['actual']=_shadow_actual_impact(page_problem_rows,page_omitted,page_changes)
        state.shadow_pages.append(shadow_prediction)
        state.consensus_problems.update(page_problem_rows)
        state.consensus_notes.extend(page_notes)
        state.barcode_omitted.update(page_omitted)
        state.add_corrections(page_changes)
        page_documents.append((page_number,reconciled))

    first_doc=_merge_page_documents(page_documents)
    return _recover_visual_header(
        paths,first_doc,visual_pages,selected,supplier_hint,date_hint,invoice_hint,
        normalized_orientation,api_key,api_base,proxy_url,timeout,state,
    )


def _read_visual_batch_document(
    paths:Sequence[str|Path],
    visual_pages:Sequence[int],
    selected:str,
    supplier_hint:str,
    date_hint:str,
    invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],
    api_key:str,
    api_base:str,
    proxy_url:str,
    timeout:int,
    state:InvoicePipelineState,
)->Dict[str,Any]:
    """Read the complete visual batch once so the AI can see duplicate pages."""
    payload=build_request_payload(
        paths,selected,supplier_hint,date_hint,invoice_hint,'extract_batch',
        orientation_plan=normalized_orientation,
    )
    response=call_openai(payload,api_key,api_base,proxy_url,timeout)
    _record_pipeline_stage(state,'Luna: единое чтение всей пачки',selected,response,payload)
    first_doc=_parse_response_document(response,'Luna: чтение всей пачки')
    return _recover_visual_header(
        paths,first_doc,visual_pages,selected,supplier_hint,date_hint,invoice_hint,
        normalized_orientation,api_key,api_base,proxy_url,timeout,state,
    )


def _document_total_gap(document:Mapping[str,Any])->float:
    total=max(0.0,sai_converter.parse_float(document.get('document_total'),0.0))
    if total<=0:
        return 0.0
    lines=sum(
        max(0.0,sai_converter.parse_float(row.get('line_total'),0.0))
        for row in (document.get('items') or [])
        if isinstance(row,Mapping)
    )
    return abs(lines-total)


def _merge_recovered_pages_by_source(
    paths:Sequence[str|Path],normalized_orientation:Mapping[str,Sequence[Any]],
    page_documents:Sequence[tuple[int,Dict[str,Any]]],
)->Dict[str,Any]:
    """Merge continuation pages per PDF, then combine the distinct documents."""
    by_page={int(page):doc for page,doc in page_documents}
    source_documents=[]
    global_page=1
    for raw_path in paths:
        path=Path(raw_path).expanduser().resolve()
        page_count=len(normalized_orientation.get(str(path)) or [])
        local=[]
        for _local_page in range(page_count):
            document=by_page.get(global_page)
            if document and document.get('items'):
                local.append((global_page,document))
            global_page+=1
        if local:
            source_documents.append((path.name,_merge_page_documents(local)))
    if not source_documents:
        return {}
    return merge_source_documents(source_documents)


def _recover_missing_visual_rows_if_needed(
    paths:Sequence[str|Path],document:Dict[str,Any],visual_pages:Sequence[int],selected:str,
    supplier_hint:str,date_hint:str,invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],api_key:str,api_base:str,
    proxy_url:str,timeout:int,state:InvoicePipelineState,
)->Dict[str,Any]:
    """Re-read pages when totals or explicit page coverage show an omission.

    The normal fast route remains one request for the complete PDF batch.  A
    page-wise recovery is paid for when the total disagrees, multiple source
    files need reconciliation, or any confirmed page is absent from source_page.
    The last condition prevents a four-page PDF from silently succeeding after
    the batch model read only the first two pages.
    """
    batch_items=list(document.get('items') or [])
    batch_gap=_document_total_gap(document)
    expected_pages={int(page) for page in visual_pages if int(page)>0}
    observed_pages={
        int(sai_converter.parse_float(row.get('source_page'),0))
        for row in batch_items if isinstance(row,Mapping)
    }
    missing_pages=sorted(expected_pages-observed_pages)
    visual_source_count=sum(
        1 for raw_path in paths
        if Path(raw_path).suffix.lower() in ({'.pdf'}|IMAGE_EXTENSIONS)
    )
    if not visual_pages or (
        not missing_pages and
        visual_source_count<=1
        and batch_gap<=_document_rounding_tolerance(len(batch_items))
    ):
        return document

    page_documents=[]
    for page_number in visual_pages:
        candidate=None
        attempts=(
            ('extract_luna',selected,'Luna'),
            ('extract_terra',AUDIT_MODEL,'Terra'),
            ('extract_sol',FALLBACK_MODEL,'Sol'),
        )
        for attempt_stage,attempt_model,actor in attempts:
            payload=build_request_payload(
                paths,attempt_model,supplier_hint,date_hint,invoice_hint,attempt_stage,
                orientation_plan=normalized_orientation,target_global_pages=[page_number],
            )
            response=call_openai(payload,api_key,api_base,proxy_url,timeout)
            _record_pipeline_stage(
                state,f'{actor}: контроль страницы {page_number}',attempt_model,response,payload,
            )
            candidate=_parse_response_document_allow_empty(
                response,f'{actor}: восстановление страницы {page_number}',
            )
            if candidate.get('items'):
                break
        if not candidate or not candidate.get('items'):
            raise OpenAIInvoiceError(
                f'Страница {page_number} подтверждена оператором, но не дала товарных строк '
                'после проверки Luna, Terra и Sol. SAI остановил неполный результат.'
            )
        page_documents.append((page_number,candidate))

    if not page_documents:
        return document
    recovered=_merge_recovered_pages_by_source(paths,normalized_orientation,page_documents)
    for field in ('supplier','invoice_date','invoice_number','currency'):
        if document.get(field) not in (None,'',0,0.0):
            recovered[field]=document.get(field)
    recovered_items=list(recovered.get('items') or [])
    recovered_gap=_document_total_gap(recovered)
    recovered_complete=(
        recovered_gap<=_document_rounding_tolerance(len(recovered_items))
        and sai_converter.parse_float(recovered.get('document_total'),0.0)>0
    )
    coverage_recovered=bool(missing_pages and recovered_items)
    gap_recovered=(
        len(recovered_items)>len(batch_items)
        and (recovered_gap+0.01<batch_gap or recovered_complete)
    )
    if coverage_recovered or gap_recovered:
        warnings=list(recovered.get('warnings') or [])
        warnings.append(
            f'SAI восстановил пропущенные товарные строки постраничной проверкой: '
            f'{len(batch_items)} -> {len(recovered_items)}.'
        )
        recovered['warnings']=warnings
        return recovered
    return document


def _read_unified_document(
    paths:Sequence[str|Path],
    selected:str,
    supplier_hint:str,
    date_hint:str,
    invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],
    api_key:str,
    api_base:str,
    proxy_url:str,
    timeout:int,
    state:InvoicePipelineState,
)->Dict[str,Any]:
    payload=build_request_payload(
        paths,selected,supplier_hint,date_hint,invoice_hint,'extract',
        orientation_plan=normalized_orientation,
    )
    response=call_openai(payload,api_key,api_base,proxy_url,timeout)
    _record_pipeline_stage(state,'Luna: единое чтение документа',selected,response,payload)
    return _parse_response_document(response,'Luna: основное чтение')


def _read_unified_source_documents(
    paths:Sequence[str|Path],
    selected:str,
    supplier_hint:str,
    date_hint:str,
    invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],
    api_key:str,
    api_base:str,
    proxy_url:str,
    timeout:int,
    state:InvoicePipelineState,
)->Dict[str,Any]:
    """Read every non-visual file independently before creating one receipt."""
    documents=[]
    total=len(paths)
    for index,raw_path in enumerate(paths,start=1):
        path=Path(raw_path).expanduser().resolve()
        payload=build_request_payload(
            [path],selected,supplier_hint,date_hint,invoice_hint,'extract',
            orientation_plan=normalized_orientation,
        )
        response=call_openai(payload,api_key,api_base,proxy_url,timeout)
        _record_pipeline_stage(
            state,f'Luna: файл {index}/{total} — {path.name}',selected,response,payload,
        )
        document=_parse_response_document(response,f'Luna: чтение файла {path.name}')
        if not document.get('items'):
            raise OpenAIInvoiceError(
                f'Файл {path.name} не дал ни одной товарной строки. Общий результат не сохранён.'
            )
        documents.append((path.name,document))
    return merge_source_documents(documents)


def _review_problem_rows(
    paths:Sequence[str|Path],
    current:Dict[str,Any],
    problem_rows:Sequence[int],
    problem_notes:Sequence[str],
    supplier_hint:str,
    date_hint:str,
    invoice_hint:str,
    normalized_orientation:Mapping[str,Sequence[Any]],
    api_key:str,
    api_base:str,
    proxy_url:str,
    timeout:int,
    state:InvoicePipelineState,
    *,
    model:str,
    payload_stage:str,
    stage_label:str,
    parse_label:str,
    actor_name:str,
)->tuple[Dict[str,Any],List[int],List[str]]:
    target_pages=_target_pages_for_rows(current,problem_rows)
    payload=build_request_payload(
        paths,model,supplier_hint,date_hint,invoice_hint,payload_stage,
        draft=current,target_rows=problem_rows,audit_notes=problem_notes,
        orientation_plan=normalized_orientation,target_global_pages=target_pages,
    )
    response=call_openai(payload,api_key,api_base,proxy_url,timeout)
    audit=_parse_audit_response(response,parse_label)
    _record_pipeline_stage(state,stage_label,model,response,payload)
    missing,extras=_check_audit_coverage(audit,problem_rows)
    if extras:
        raise OpenAIInvoiceError(actor_name+' вернула лишние строки: '+', '.join(map(str,extras))+'. Результат не сохранён.')
    merged,changed,uncertain,omitted=apply_audit(current,audit)
    state.add_corrections(changed)
    state.barcode_omitted.update(omitted)
    current,local_problems,local_notes,omitted_after=_sanitize_and_evaluate_document(
        merged,supplier_hint,date_hint,invoice_hint,
    )
    state.barcode_omitted.update(omitted_after)
    next_rows=sorted(set(local_problems)|set(uncertain)|set(missing))
    missing_note=[f'{actor_name} не вернула строки: {", ".join(map(str,missing))}'] if missing else []
    return current,next_rows,merge_problem_notes(local_notes,missing_note)


def _local_structured_result(paths:Sequence[str|Path],markup_percent:float,supplier_hint:str,date_hint:str,invoice_hint:str)->sai_converter.ConvertResult|None:
    checked=validate_source_paths(paths)
    if len(checked)!=1 or checked[0].suffix.lower() not in {'.zip','.xls'}: return None
    result=sai_converter.convert_document(
        checked[0],supplier=supplier_hint,invoice_date=date_hint,
        invoice_number=invoice_hint,markup_percent=markup_percent,
    )
    if result.errors or not result.items:
        source_label='ZIP Диадока' if checked[0].suffix.lower()=='.zip' else 'старый XLS'
        raise OpenAIInvoiceError(f'Не удалось прочитать {source_label}: '+'; '.join(result.errors or ['нет товарных строк']))
    result.validation=dict(result.validation or {})
    result.validation.update({
        'agent_mode':'local_diadoc_upd' if checked[0].suffix.lower()=='.zip' else 'local_legacy_xls',
        'openai_stages':[],'openai_usage':{},
        'estimated_cost_usd':0.0,'cache_hit':False,
    })
    return result


def analyze_invoice(paths:Sequence[str|Path],api_key:str,model:str=DEFAULT_MODEL,proxy_url:str='',api_base:str=DEFAULT_API_BASE,markup_percent:float=60.0,supplier_hint:str='',date_hint:str='',invoice_hint:str='',timeout:int=420,orientation_plan:Mapping[str,Sequence[Any]]|None=None)->sai_converter.ConvertResult:
    """Run the unchanged dual-Luna route through explicit pipeline stages."""
    started_at=time.monotonic()
    local_result=_local_structured_result(paths,markup_percent,supplier_hint,date_hint,invoice_hint)
    if local_result is not None: return local_result
    selected=quality_model(model)
    contract=invoice_contract_metadata()
    normalized_orientation=sai_page_orientation.normalize_plan(paths,orientation_plan)
    key=_cache_key(paths,selected,supplier_hint,date_hint,invoice_hint,normalized_orientation)
    cached=_read_cached_bundle(key)
    if cached is not None:
        cached_quality=cached.get('quality_metadata') or {}
        cached_result=response_to_convert_result(
            cached['final_response'],paths,markup_percent,supplier_hint,date_hint,invoice_hint,
            contract,selected,True,cached.get('stages') or [],cached_quality,
        )
        _append_economy_telemetry({
            'event':'invoice_analysis','status':'cache_hit','document_key':key[:20],
            'contract_version':CONTRACT_VERSION,'model':selected,'cache_hit':True,
            'duration_ms':round((time.monotonic()-started_at)*1000),
            'source':_source_telemetry_summary(paths),
            'economy_shadow':cached_quality.get('economy_shadow') or {},
            'estimated_cost_usd':0.0,
            'original_estimated_cost_usd':cached_result.validation.get('original_estimated_cost_usd'),
        })
        return cached_result

    state=InvoicePipelineState()
    visual_pages=_confirmed_visual_page_numbers(paths,normalized_orientation)
    if visual_pages:
        first_doc=_read_visual_batch_document(
            paths,visual_pages,selected,supplier_hint,date_hint,invoice_hint,
            normalized_orientation,api_key,api_base,proxy_url,timeout,state,
        )
    elif len(paths)>1:
        first_doc=_read_unified_source_documents(
            paths,selected,supplier_hint,date_hint,invoice_hint,
            normalized_orientation,api_key,api_base,proxy_url,timeout,state,
        )
    else:
        first_doc=_read_unified_document(
            paths,selected,supplier_hint,date_hint,invoice_hint,
            normalized_orientation,api_key,api_base,proxy_url,timeout,state,
        )

    restore_document_total(first_doc)
    first_doc=_recover_missing_visual_rows_if_needed(
        paths,first_doc,visual_pages,selected,supplier_hint,date_hint,invoice_hint,
        normalized_orientation,api_key,api_base,proxy_url,timeout,state,
    )
    restore_document_total(first_doc)
    manual_supplier_hint=supplier_hint or ('manual' if 'supplier' in state.manual_header_fields else '')
    manual_date_hint=date_hint or ('manual' if 'invoice_date' in state.manual_header_fields else '')
    manual_invoice_hint=invoice_hint or ('manual' if 'invoice_number' in state.manual_header_fields else '')
    current,local_problem_rows,local_notes,omitted=_sanitize_and_evaluate_document(
        first_doc,manual_supplier_hint,manual_date_hint,manual_invoice_hint,
    )
    state.barcode_omitted.update(omitted)
    problem_rows=sorted(set(local_problem_rows)|state.consensus_problems)
    problem_notes=merge_problem_notes(local_notes,state.consensus_notes)

    if problem_rows:
        current,problem_rows,problem_notes=_review_problem_rows(
            paths,current,problem_rows,problem_notes,manual_supplier_hint,manual_date_hint,manual_invoice_hint,
            normalized_orientation,api_key,api_base,proxy_url,timeout,state,
            model=AUDIT_MODEL,payload_stage='repair',
            stage_label='Terra: увеличенные фрагменты спорных строк',
            parse_label='Terra: точечная проверка',actor_name='Terra',
        )

    if problem_rows:
        target_pages=_target_pages_for_rows(current,problem_rows)
        if len(problem_rows)<=MAX_SOL_REPAIR_ROWS and len(target_pages)<=MAX_SOL_REPAIR_PAGES:
            state.arbitration_rows=list(problem_rows)
            current,problem_rows,problem_notes=_review_problem_rows(
                paths,current,problem_rows,problem_notes,manual_supplier_hint,manual_date_hint,manual_invoice_hint,
                normalized_orientation,api_key,api_base,proxy_url,timeout,state,
                model=FALLBACK_MODEL,payload_stage='escalate',
                stage_label='Sol: финальные фрагменты отдельных строк',
                parse_label='Sol: финальная проверка',actor_name='Sol',
            )
        else:
            state.unresolved.update(problem_rows)

    state.unresolved.update(problem_rows)
    blockers=_blocking_quality_notes(problem_notes)
    reviewable_blockers=_reviewable_quality_notes(blockers)
    hard_blockers=[note for note in blockers if note not in reviewable_blockers]
    if hard_blockers:
        _usage,cost=_aggregate_stages(state.stages)
        spent=f' Потрачено ориентировочно ${cost:.4f}.' if cost is not None else ''
        raise OpenAIInvoiceError(
            'SAI Invoice Agent остановил небезопасный результат: '+
            '; '.join(hard_blockers[:6])+'.'+spent+
            ' Файл не сохранён; повторный запрос автоматически не запускается.'
        )

    final_response=_response_from_document(current)
    economy_shadow=_summarize_shadow_pages(state.shadow_pages) if state.shadow_pages else empty_shadow_summary()
    quality=build_quality_metadata(
        state,visual_pages=visual_pages,normalized_orientation=normalized_orientation,
        problem_notes=problem_notes,economy_shadow=economy_shadow,
        audit_model=AUDIT_MODEL,fallback_model=FALLBACK_MODEL,
    )
    if visual_pages:
        quality['agent_mode']='single_batch_luna_targeted_terra_sol'
    quality['manual_review_required']=bool(reviewable_blockers)
    quality['manual_review_reasons']=list(reviewable_blockers)
    quality['manual_review_accepted']=False
    result=response_to_convert_result(
        final_response,paths,markup_percent,supplier_hint,date_hint,invoice_hint,
        contract,selected,False,state.stages,quality,
    )
    if result.errors or not result.items:
        raise OpenAIInvoiceError('AI-агент не прошёл проверку качества: '+'; '.join(result.errors or ['нет товарных строк']))
    bundle={
        'cache_version':14,'contract_version':CONTRACT_VERSION,'model':selected,
        'final_response':final_response,'stages':state.stages,'quality_metadata':quality,
    }
    _write_cached_bundle(key,bundle)
    _append_economy_telemetry({
        'event':'invoice_analysis','status':'ok','document_key':key[:20],
        'contract_version':CONTRACT_VERSION,'model':selected,'cache_hit':False,
        'duration_ms':round((time.monotonic()-started_at)*1000),
        'source':_source_telemetry_summary(paths),
        'usage':result.validation.get('openai_usage') or {},
        'stages':result.validation.get('openai_stages') or [],
        'estimated_cost_usd':result.validation.get('estimated_cost_usd'),
        'economy_shadow':economy_shadow,
        'result':{
            'item_count':len(result.items),
            'critical_issue_count':len(result.critical_issues or []),
            'warning_count':len(result.warnings or []),
            'unresolved_row_count':len(result.validation.get('unresolved_rows') or []),
            'barcode_omitted_count':len(result.validation.get('barcode_omitted_rows') or []),
        },
    })
    return result
