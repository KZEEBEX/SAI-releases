import argparse
import datetime as dt
import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

from sai_runtime_paths import APP_DIR, ROOT_DIR, LOGS_DIR, PRIVATE_CONFIG_PATH, ensure_runtime_dirs

from sai_direct_network import configure_direct_network, direct_chromium_args

configure_direct_network()

SENSITIVE_HEADERS = {
    "authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-csrf-token",
    "x-xsrf-token",
}

RELEVANT_RE = re.compile(
    r"(waybill|waybills|document|documents|income|supplier|suppliers|provider|providers|"
    r"contractor|contractors|counterpart|counterparty|counterparties|contragent|"
    r"partner|partners|legal|entity|entities|organization|organizations|customer|customers|"
    r"storehouse|storehouses)",
    re.I,
)

DANGEROUS_AUTH_RE = re.compile(r"(oauth/token|openid-connect|auth/realms|login-actions|credential)", re.I)


def safe_str(value):
    return "" if value is None else str(value)


def load_private_config():
    try:
        return json.loads(PRIVATE_CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def redact_text(text, limit=8000):
    text = safe_str(text)
    if not text:
        return ""
    text = re.sub(r'("access_token"\s*:\s*")[^"]+', r'\1***REDACTED***', text, flags=re.I)
    text = re.sub(r'("refresh_token"\s*:\s*")[^"]+', r'\1***REDACTED***', text, flags=re.I)
    text = re.sub(r'("password"\s*:\s*")[^"]+', r'\1***REDACTED***', text, flags=re.I)
    text = re.sub(r'("token"\s*:\s*")[^"]+', r'\1***REDACTED***', text, flags=re.I)
    text = re.sub(r'(Bearer\s+)[A-Za-z0-9._\-]+', r'\1***REDACTED***', text, flags=re.I)
    if len(text) > limit:
        return text[:limit] + "...<TRUNCATED>"
    return text


def clean_headers(headers):
    out = {}
    for k, v in (headers or {}).items():
        lk = str(k).lower()
        if lk in SENSITIVE_HEADERS or "token" in lk or "cookie" in lk:
            out[k] = "***REDACTED***"
        else:
            out[k] = safe_str(v)[:1000]
    return out


def is_relevant_url(url, method="GET"):
    url = safe_str(url)
    method = safe_str(method).upper()
    if DANGEROUS_AUTH_RE.search(url):
        return False
    if method in {"POST", "PUT", "PATCH", "DELETE"}:
        return True
    return bool(RELEVANT_RE.search(url))


def compact_body_for_url(url, body):
    if not body:
        return ""
    if DANGEROUS_AUTH_RE.search(url):
        return "***AUTH BODY REDACTED***"
    return redact_text(body, limit=12000)


def try_json_or_text_preview(resp, url):
    if DANGEROUS_AUTH_RE.search(url):
        return "***AUTH RESPONSE REDACTED***"
    try:
        ct = safe_str(resp.headers.get("content-type", ""))
        if not any(x in ct.lower() for x in ["json", "text", "javascript"]):
            return f"***SKIPPED content-type={ct[:80]}***"
        txt = resp.text()
        return redact_text(txt, limit=12000)
    except Exception as e:
        return f"***READ_ERROR: {str(e)[:300]}***"


def official_api_probe():
    import requests

    cfg = load_private_config()
    company_key = safe_str(cfg.get("sigma_company_key")).strip()
    api_token = safe_str(cfg.get("sigma_api_token")).strip()
    sell_point_id = safe_str(cfg.get("sigma_sell_point_id")).strip()

    if not company_key or not api_token:
        return {
            "enabled": False,
            "reason": "sigma_company_key или sigma_api_token не заполнены",
            "results": [],
        }

    base = f"https://api.sigma.ru/v1/companies/{company_key}"
    headers = {"X-Api-Key": api_token, "Accept": "application/json"}

    endpoints = [
        "suppliers",
        "providers",
        "contractors",
        "counterparties",
        "contragents",
        "partners",
        "customers",
        "organizations",
        "legal-entities",
        "waybills",
        "income-waybills",
        "documents",
    ]

    results = []
    for endpoint in endpoints:
        for params in ({}, {"sellPointId": sell_point_id} if sell_point_id else {}):
            if params == {} and results and False:
                pass
            try:
                r = requests.get(
                    f"{base}/{endpoint}",
                    headers=headers,
                    params=params,
                    timeout=15,
                )
                preview = redact_text(r.text, limit=3500)
                results.append({
                    "endpoint": endpoint,
                    "params": params,
                    "status": r.status_code,
                    "content_type": r.headers.get("content-type", ""),
                    "preview": preview,
                })
                print(f"OFFICIAL API probe: GET /{endpoint} params={params or '{}'} -> HTTP {r.status_code}", flush=True)
            except Exception as e:
                results.append({
                    "endpoint": endpoint,
                    "params": params,
                    "status": "ERROR",
                    "error": str(e)[:500],
                })
                print(f"OFFICIAL API probe: GET /{endpoint} ERROR {str(e)[:160]}", flush=True)

    return {
        "enabled": True,
        "base": "https://api.sigma.ru/v1/companies/***",
        "results": results,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-data-dir", required=True)
    parser.add_argument("--duration", type=int, default=240)
    parser.add_argument("--url", default="https://cloud.sigma.ru/documents")
    args = parser.parse_args()

    ensure_runtime_dirs()
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = LOGS_DIR / f"supplier_waybill_probe_{stamp}.json"

    print("=" * 72, flush=True)
    print("SAI supplier/waybill creation probe", flush=True)
    print("Задача: поймать запросы SIGMA при создании черновика прихода.", flush=True)
    print("=" * 72, flush=True)

    report = {
        "created_at": dt.datetime.now().isoformat(timespec="seconds"),
        "duration_seconds": args.duration,
        "official_api_probe": {},
        "browser_events": [],
        "suspects": [],
        "notes": [
            "Секретные заголовки и токены вырезаны.",
            "Если пользователь логинился во время диагностики, auth-тела и auth-ответы не сохранялись.",
            "Нужны запросы, связанные с supplier/contractor/counterparty и POST/PUT/PATCH waybill/document.",
        ],
    }

    print("Проверяю возможные official API endpoints для поставщиков/черновиков...", flush=True)
    try:
        report["official_api_probe"] = official_api_probe()
    except Exception as e:
        report["official_api_probe"] = {"enabled": False, "error": str(e)[:500]}
        print(f"OFFICIAL API probe failed: {str(e)[:200]}", flush=True)

    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        report["playwright_error"] = str(e)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"ОШИБКА: Playwright не доступен: {e}", flush=True)
        print(f"SAI_SUPPLIER_PROBE_REPORT:{report_path}", flush=True)
        return 2

    start_ts = time.time()
    seen = set()

    def add_event(event):
        key = (event.get("kind"), event.get("method"), event.get("url"), event.get("status"), event.get("post_data"))
        if key in seen:
            return
        seen.add(key)
        report["browser_events"].append(event)

        url = event.get("url", "")
        method = event.get("method", "")
        if method in {"POST", "PUT", "PATCH", "DELETE"} or RELEVANT_RE.search(url):
            report["suspects"].append(event)

    print("", flush=True)
    print("Откроется SIGMA.", flush=True)
    print("Действия в браузере:", flush=True)
    print("1) Создайте один тестовый черновик прихода вручную.", flush=True)
    print("2) Выберите поставщика.", flush=True)
    print("3) Когда черновик откроется — ничего больше добавлять не нужно.", flush=True)
    print(f"4) Подождите завершения диагностики ({args.duration} секунд максимум).", flush=True)
    print("", flush=True)

    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=args.user_data_dir,
            headless=False,
            accept_downloads=True,
            viewport={"width": 1440, "height": 900},
            args=direct_chromium_args(["--disable-blink-features=AutomationControlled"]),
        )

        def on_request(req):
            try:
                url = req.url
                method = req.method.upper()
                if not is_relevant_url(url, method):
                    return
                post_data = ""
                try:
                    post_data = req.post_data or ""
                except Exception:
                    post_data = ""
                event = {
                    "kind": "request",
                    "t": round(time.time() - start_ts, 3),
                    "method": method,
                    "url": url,
                    "resource_type": req.resource_type,
                    "headers": clean_headers(req.headers),
                    "post_data": compact_body_for_url(url, post_data),
                }
                add_event(event)
                if method in {"POST", "PUT", "PATCH", "DELETE"}:
                    print(f"CAPTURE request: {method} {url}", flush=True)
            except Exception as e:
                print(f"request capture error: {str(e)[:160]}", flush=True)

        def on_response(resp):
            try:
                req = resp.request
                url = resp.url
                method = req.method.upper()
                if not is_relevant_url(url, method):
                    return
                event = {
                    "kind": "response",
                    "t": round(time.time() - start_ts, 3),
                    "method": method,
                    "url": url,
                    "status": resp.status,
                    "headers": clean_headers(resp.headers),
                    "body_preview": try_json_or_text_preview(resp, url),
                }
                add_event(event)
                if method in {"POST", "PUT", "PATCH", "DELETE"}:
                    print(f"CAPTURE response: HTTP {resp.status} {method} {url}", flush=True)
            except Exception as e:
                print(f"response capture error: {str(e)[:160]}", flush=True)

        context.on("request", on_request)
        context.on("response", on_response)

        page = context.pages[0] if context.pages else context.new_page()
        page.goto(args.url, wait_until="domcontentloaded", timeout=60000)

        deadline = time.time() + max(30, args.duration)
        last_ping = 0
        while time.time() < deadline:
            try:
                if not context.pages:
                    break
            except Exception:
                break

            now = time.time()
            if now - last_ping >= 10:
                left = int(deadline - now)
                print(
                    f"Диагностика идёт... осталось примерно {max(0, left)} сек. "
                    f"Событий: {len(report['browser_events'])}, подозрительных: {len(report['suspects'])}",
                    flush=True,
                )
                last_ping = now
            time.sleep(0.5)

        try:
            context.close()
        except Exception:
            pass

    report["finished_at"] = dt.datetime.now().isoformat(timespec="seconds")
    report["browser_events_count"] = len(report["browser_events"])
    report["suspects_count"] = len(report["suspects"])

    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("", flush=True)
    print(f"Диагностика завершена. Событий: {len(report['browser_events'])}, подозрительных: {len(report['suspects'])}", flush=True)
    print(f"Отчёт: {report_path}", flush=True)
    print(f"SAI_SUPPLIER_PROBE_REPORT:{report_path}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
