#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Patch regression for SAI v1.22.7aw unified notifications."""
from __future__ import annotations

import ast
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
APP = ROOT / "app"


def main() -> None:
    version = (APP / "sai_version.py").read_text(encoding="utf-8-sig")
    ui = (APP / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    notifications = (APP / "sai_notifications.py").read_text(encoding="utf-8-sig")
    ast.parse(ui)
    ast.parse(notifications)
    assert 'VERSION = "1.22.7aw"' in version
    assert "NotificationCenter(self)" in ui
    assert "CatalogStatusBadge(rail)" in ui
    assert "class Toast(QFrame):" not in ui
    assert 'self.notify("SAI готов"' not in ui
    assert "class SAIMessageBox(QDialog):" in notifications
    assert "QMessageBox = SAIMessageBox" in notifications
    assert "class NotificationCenter(QObject):" in notifications
    assert "class CatalogStatusBadge(QFrame):" in notifications
    assert (APP / "run_notification_system_tests.py").is_file()
    print("OK: SAI v1.22.7aw patch regression passed")


if __name__ == "__main__":
    main()
