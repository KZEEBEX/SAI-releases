#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Static regression checks for SAI v1.22.7av."""
from __future__ import annotations

import re
import sys
from pathlib import Path


def require(text: str, fragment: str, label: str) -> None:
    if fragment not in text:
        raise AssertionError(f"{label}: missing {fragment!r}")


def main() -> int:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    app = root / "app"
    version = (app / "sai_version.py").read_text(encoding="utf-8-sig")
    require(version, 'VERSION = "1.22.7av"', "version")

    ready = (app / "sai_catalog_ready.py").read_text(encoding="utf-8-sig")
    require(ready, "class CatalogRefreshLock", "cross-process lock")
    require(ready, "def refresh_catalog", "refresh facade")
    require(ready, "ready_stale", "safe stale fallback")
    require(ready, "--startup", "startup CLI")

    ui = (app / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    require(ui, "Подготавливать каталог при входе в Windows", "settings switch")
    require(ui, "Fast path: the local mirror is the startup source of truth", "instant startup")
    require(ui, "apply_v1227av_ready_defaults()", "migration")
    if "Ждать обновления каталога SIGMA при запуске" in ui:
        raise AssertionError("obsolete blocking-startup setting is still visible")

    default_cfg = (app / "sai_app.py").read_text(encoding="utf-8-sig")
    require(default_cfg, '"sai_ready_enabled": True', "default ready mode")
    require(default_cfg, '"catalog_force_refresh_on_startup": False', "non-blocking default")

    tests = app / "run_catalog_ready_tests.py"
    if not tests.is_file():
        raise AssertionError("run_catalog_ready_tests.py is missing")

    print("OK: SAI v1.22.7av static regression")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
