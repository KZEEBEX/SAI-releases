#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent regression tests for the unified SAI notification system."""
from __future__ import annotations

import ast
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "app"
UI_PATH = APP / "sai_pyside_preview.py"
NOTIFICATIONS_PATH = APP / "sai_notifications.py"


def static_tests() -> None:
    ui = UI_PATH.read_text(encoding="utf-8-sig")
    notifications = NOTIFICATIONS_PATH.read_text(encoding="utf-8-sig")
    ast.parse(ui, filename=str(UI_PATH))
    ast.parse(notifications, filename=str(NOTIFICATIONS_PATH))

    assert "from sai_notifications import CatalogStatusBadge, NotificationCenter, QMessageBox" in ui
    assert "class Toast(QFrame):" not in ui, "Legacy toast implementation must be removed"
    assert "NotificationCenter(self)" in ui
    assert "CatalogStatusBadge(bottom_block)" in ui
    assert "def update_catalog_status" in ui
    assert 'self.notify("SAI готов"' not in ui, "Routine startup readiness must not produce a popup"
    styles = (APP / "sai_legacy_styles.py").read_text(encoding="utf-8-sig")
    assert "QFrame#NotificationToast" in styles
    assert "QDialog#SAIMessageDialog" in styles
    assert "QPushButton#SAIMessageButton" in styles
    assert "class SAIMessageBox(QDialog):" in notifications
    assert "class NotificationCenter(QObject):" in notifications
    assert "class CatalogStatusBadge(QFrame):" in notifications
    assert "shadow.setBlurRadius(44)" in notifications
    assert "shadow.setOffset(0, 11)" in notifications
    assert "accent.setFixedWidth(4)" in notifications
    assert "accent.setMinimumHeight(48)" in notifications
    assert "QSizePolicy.Policy.Expanding" in notifications
    assert "body_layout.setContentsMargins(6, 2, 2, 2)" in notifications
    assert "compactBadge" in notifications
    assert "_split_dialog_text" in notifications
    assert "_dialog_title" in notifications


def runtime_tests() -> None:
    # The repository test environment may not have PySide6. The installed SAI
    # .venv does, and the patch installer runs this same test there.
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    try:
        from PySide6.QtWidgets import QApplication, QWidget
    except Exception as exc:
        print(f"SKIP: PySide6 runtime notification tests ({exc})")
        return

    sys.path.insert(0, str(APP))
    from sai_notifications import CatalogStatusBadge, NotificationCenter, SAIMessageBox

    app = QApplication.instance() or QApplication([])
    app.setProperty("saiNightTheme", False)
    host = QWidget()
    host.resize(960, 640)
    host.show()
    center = NotificationCenter(host)
    center.notify("Каталог", "Обновление запущено", "info", 30000)
    assert len(center.toasts) == 1
    # Exact duplicates within two seconds must not create notification spam.
    center.notify("Каталог", "Обновление запущено", "info", 30000)
    assert len(center.toasts) == 1
    center.notify("Печать", "Файл отправлен", "success", 30000)
    assert len(center.toasts) == 2
    app.processEvents()
    toast = center.toasts[0]
    accent = toast.findChild(QWidget, "NotificationAccent")
    assert accent is not None
    assert accent.width() == 4 and accent.height() >= 48
    assert accent.geometry().left() >= 6
    assert accent.geometry().top() > 1
    assert accent.geometry().bottom() < toast.height() - 1

    badge = CatalogStatusBadge(host)
    badge.set_status("КАТАЛОГ ГОТОВ", "5 480 ТОВАРОВ · 1 Ч", "success")
    assert badge.title_label.text() == "КАТАЛОГ ГОТОВ"
    assert badge.property("tone") == "success"
    badge.set_compact(True)
    assert badge.title_label.isHidden()

    box = SAIMessageBox(host)
    box.setIcon(SAIMessageBox.Icon.Warning)
    box.setWindowTitle("Проверка")
    box.setText("Основное сообщение")
    box.setInformativeText("Подробности")
    proceed = box.addButton("Продолжить", SAIMessageBox.ButtonRole.AcceptRole)
    cancel = box.addButton("Отмена", SAIMessageBox.ButtonRole.RejectRole)
    box.setDefaultButton(proceed)
    assert proceed.property("kind") == "primary"
    assert cancel.property("kind") == "secondary"
    assert box.title_label.text() == "ПРОВЕРКА"
    # isVisible() is false while the parent dialog itself is not shown.
    # isHidden() checks the label's own explicit visibility state instead.
    assert not box.info_label.isHidden()
    assert box.info_label.text() == "Подробности"

    center.clear()
    box.deleteLater()
    badge.deleteLater()
    host.deleteLater()
    app.processEvents()


def main() -> None:
    static_tests()
    runtime_tests()
    print("OK: unified notification system tests passed")


if __name__ == "__main__":
    main()
