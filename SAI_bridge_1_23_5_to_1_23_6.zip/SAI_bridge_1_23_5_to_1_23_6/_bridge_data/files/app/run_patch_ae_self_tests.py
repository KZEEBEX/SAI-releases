#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import ast, json, os, sys, tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve()
os.environ["SAI_USER_DATA_DIR"]=tempfile.mkdtemp(prefix="sai_patch_ae_")
sys.path.insert(0,str(root/"app"))
import sai_openai_invoice as ai
import sai_page_orientation as orientation
assert ai.CONTRACT_VERSION=="invoice_ai_contract_v9"
assert orientation.normalize_angle(270)==-90
ui_path=root/"app"/"sai_pyside_preview.py"
ui=ui_path.read_text(encoding="utf-8")
ast.parse(ui,filename=str(ui_path))
assert "class PageOrientationDialog(QDialog):" in ui
assert "self.preview.setMinimumSize(320, 200)" in ui
assert "self._fit_to_available_screen(force=True)" in ui
assert "screen.availableGeometry()" in ui
assert "self.confirm_button.setText(\"Подтвердить страницы\")" in ui
assert "self.confirm_button.setDefault(True)" in ui
assert "Ctrl+Enter — подтвердить" in ui
assert "self.preview.setMinimumSize(760, 520)" not in ui
assert "self.resize(1120, 820)" not in ui
wiki=json.loads((root/"SAI_Ecosystem_Wiki_v0.1"/"wiki_manifest.json").read_text(encoding="utf-8-sig"))
assert wiki["wiki_version"]=="1.6"
assert wiki["snapshot_sai_version"]=="1.22.7ae"
print("PATCH_AE_SELF_TEST_OK")
