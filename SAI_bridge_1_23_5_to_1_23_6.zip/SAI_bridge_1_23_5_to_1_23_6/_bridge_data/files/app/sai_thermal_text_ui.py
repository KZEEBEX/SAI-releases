"""Desktop page for printing arbitrary centred text on thermal labels."""
from __future__ import annotations

from typing import Any, Callable, Mapping

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (
    QComboBox, QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpinBox, QTextEdit, QVBoxLayout, QWidget,
)

from sai_notifications import QMessageBox
from sai_thermal_printing import normalize_thermal_config, print_thermal_image
from sai_thermal_text import normalize_thermal_text, render_thermal_text_label


class ThermalTextPreview(QLabel):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._image = QImage()
        self.setObjectName("ThermalTextCanvas")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setMinimumSize(360, 260)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def set_image(self, image: QImage) -> None:
        self._image = image
        self._sync_pixmap()

    def _sync_pixmap(self) -> None:
        if self._image.isNull():
            self.clear()
            return
        available = self.size()
        available.setWidth(max(1, available.width() - 48))
        available.setHeight(max(1, available.height() - 48))
        self.setPixmap(QPixmap.fromImage(self._image).scaled(
            available,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        ))

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._sync_pixmap()


class ThermalTextPrintPage(QWidget):
    SIZE_LABELS = (("58×40 мм", "58x40"), ("43×25 мм", "43x25"), ("30×20 мм", "30x20"))

    def __init__(
        self,
        parent_page: QWidget,
        *,
        load_config: Callable[[], Mapping[str, Any]],
        save_config: Callable[[dict[str, Any]], None],
    ) -> None:
        super().__init__()
        self.parent_page = parent_page
        self._load_config = load_config
        self._save_config = save_config
        self._image = QImage()
        self.setObjectName("ThermalTextPage")
        self._build_ui()
        self.refresh_config()
        self.update_preview()

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 26, 28, 28)
        root.setSpacing(18)

        title = QLabel("Термо печать")
        title.setObjectName("ThermalTextPageTitle")
        subtitle = QLabel("Напечатайте любой текст — SAI сам увеличит его до доступного размера и разместит по центру.")
        subtitle.setObjectName("ThermalTextPageSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(title)
        root.addWidget(subtitle)

        body = QHBoxLayout()
        body.setSpacing(16)
        editor_card = QFrame()
        editor_card.setObjectName("ThermalTextCard")
        editor_layout = QVBoxLayout(editor_card)
        editor_layout.setContentsMargins(20, 18, 20, 20)
        editor_layout.setSpacing(12)
        editor_title = QLabel("Текст на этикетке")
        editor_title.setObjectName("ThermalTextSectionTitle")
        editor_layout.addWidget(editor_title)
        self.text_edit = QTextEdit()
        self.text_edit.setObjectName("ThermalTextEditor")
        self.text_edit.setAcceptRichText(False)
        self.text_edit.setPlaceholderText("Например:\nСКИДКА 20%")
        self.text_edit.setTabChangesFocus(True)
        self.text_edit.textChanged.connect(self.update_preview)
        editor_layout.addWidget(self.text_edit, 1)

        controls = QHBoxLayout()
        controls.setSpacing(10)
        size_caption = QLabel("Размер")
        size_caption.setObjectName("ThermalTextFieldLabel")
        self.size_combo = QComboBox()
        self.size_combo.setObjectName("ThermalTextCombo")
        for label, value in self.SIZE_LABELS:
            self.size_combo.addItem(label, value)
        self.size_combo.currentIndexChanged.connect(self.size_changed)
        copies_caption = QLabel("Копий")
        copies_caption.setObjectName("ThermalTextFieldLabel")
        self.copies_spin = QSpinBox()
        self.copies_spin.setObjectName("ThermalTextCopies")
        self.copies_spin.setRange(1, 999)
        self.copies_spin.setValue(1)
        controls.addWidget(size_caption)
        controls.addWidget(self.size_combo, 1)
        controls.addSpacing(8)
        controls.addWidget(copies_caption)
        controls.addWidget(self.copies_spin)
        editor_layout.addLayout(controls)

        self.printer_label = QLabel("")
        self.printer_label.setObjectName("ThermalTextPrinterState")
        self.printer_label.setWordWrap(True)
        editor_layout.addWidget(self.printer_label)
        actions = QHBoxLayout()
        actions.setSpacing(10)
        self.settings_btn = QPushButton("Настройки принтера")
        self.settings_btn.setObjectName("ThermalTextSoftButton")
        self.settings_btn.clicked.connect(self.parent_page.show_settings)
        self.print_btn = QPushButton("Печатать")
        self.print_btn.setObjectName("ThermalTextPrimaryButton")
        self.print_btn.clicked.connect(self.print_text)
        actions.addWidget(self.settings_btn)
        actions.addWidget(self.print_btn, 1)
        editor_layout.addLayout(actions)
        self.status_label = QLabel("")
        self.status_label.setObjectName("ThermalTextStatus")
        self.status_label.setWordWrap(True)
        self.status_label.hide()
        editor_layout.addWidget(self.status_label)

        preview_card = QFrame()
        preview_card.setObjectName("ThermalTextCard")
        preview_layout = QVBoxLayout(preview_card)
        preview_layout.setContentsMargins(20, 18, 20, 20)
        preview_layout.setSpacing(12)
        preview_header = QHBoxLayout()
        preview_title = QLabel("Предпросмотр")
        preview_title.setObjectName("ThermalTextSectionTitle")
        self.preview_size = QLabel("")
        self.preview_size.setObjectName("ThermalTextPreviewSize")
        preview_header.addWidget(preview_title)
        preview_header.addStretch(1)
        preview_header.addWidget(self.preview_size)
        preview_layout.addLayout(preview_header)
        self.preview = ThermalTextPreview()
        preview_layout.addWidget(self.preview, 1)
        body.addWidget(editor_card, 5)
        body.addWidget(preview_card, 6)
        root.addLayout(body, 1)

    def current_config(self) -> dict[str, Any]:
        raw = dict(self._load_config() or {})
        raw["thermal_label_size"] = str(self.size_combo.currentData() or "58x40")
        return normalize_thermal_config(raw)

    def refresh_config(self) -> None:
        cfg = normalize_thermal_config(self._load_config())
        index = self.size_combo.findData(cfg["size"])
        self.size_combo.blockSignals(True)
        self.size_combo.setCurrentIndex(index if index >= 0 else 0)
        self.size_combo.blockSignals(False)
        printer = str(cfg.get("printer") or "").strip()
        self.printer_label.setText(
            f"Термопринтер: {printer}" if printer else "Термопринтер не выбран. Откройте настройки принтера."
        )
        self.printer_label.setProperty("configured", bool(printer))
        self.printer_label.style().unpolish(self.printer_label)
        self.printer_label.style().polish(self.printer_label)

    def size_changed(self) -> None:
        self._save_config({"thermal_label_size": str(self.size_combo.currentData() or "58x40")})
        self.update_preview()

    def update_preview(self) -> None:
        size = str(self.size_combo.currentData() or "58x40")
        text = normalize_thermal_text(self.text_edit.toPlainText())
        self._image = render_thermal_text_label(text, size, self.current_config())
        self.preview.set_image(self._image)
        self.preview_size.setText(size.replace("x", " × ") + " мм")
        self.print_btn.setEnabled(bool(text))
        if not text:
            self.status_label.hide()

    def print_text(self) -> None:
        text = normalize_thermal_text(self.text_edit.toPlainText())
        if not text:
            QMessageBox.information(self, "Термо печать", "Введите текст для этикетки.")
            return
        copies = int(self.copies_spin.value())
        self.print_btn.setEnabled(False)
        self.print_btn.setText("Печатаем…")
        try:
            config = self.current_config()
            print_thermal_image(render_thermal_text_label(text, config["size"], config), config, copies=copies)
            self.status_label.setText(f"Отправлено на печать: {copies} шт.")
            self.status_label.setProperty("tone", "success")
            self.status_label.show()
            self.parent_page.notify("Термо печать", f"Напечатано этикеток: {copies}", "success")
        except Exception as exc:
            self.status_label.setText(str(exc))
            self.status_label.setProperty("tone", "error")
            self.status_label.show()
            QMessageBox.critical(self, "Термо печать", f"Не удалось напечатать этикетку:\n\n{exc}")
        finally:
            self.status_label.style().unpolish(self.status_label)
            self.status_label.style().polish(self.status_label)
            self.print_btn.setText("Печатать")
            self.print_btn.setEnabled(bool(text))

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        self.refresh_config()
        self.update_preview()
