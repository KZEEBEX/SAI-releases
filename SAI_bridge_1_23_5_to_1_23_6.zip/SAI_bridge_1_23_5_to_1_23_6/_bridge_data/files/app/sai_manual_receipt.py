#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Application service for manual receipts.

This is the boundary between the Qt screen and persistence/converter adapters.
The screen no longer builds SAI packages or owns autosave file semantics.
"""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import sai_converter
import sai_receipt_drafts
from sai_core_v2.manual_receipt import (
    ManualReceiptDocument,
    build_document,
    stable_rows_signature,
    text,
)
from sai_runtime_paths import USER_DATA_DIR


class ManualReceiptService:
    DRAFT_ID = "manual_current"

    def __init__(self, autosave_path: Path | None = None) -> None:
        self.autosave_path = Path(autosave_path or (USER_DATA_DIR / "free_receipt_autosave.json"))

    def is_deleted(self) -> bool:
        return sai_receipt_drafts.is_deleted(self.DRAFT_ID)

    def restore(self) -> None:
        sai_receipt_drafts.restore(self.DRAFT_ID)

    def save_autosave(self, payload: Mapping[str, Any]) -> None:
        self.autosave_path.parent.mkdir(parents=True, exist_ok=True)
        data = dict(payload)
        data.setdefault("saved_at", dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.autosave_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        sai_receipt_drafts.register_manual_autosave(data, draft_id=self.DRAFT_ID)

    def load_autosave(self) -> dict[str, Any]:
        if self.is_deleted() or not self.autosave_path.is_file():
            return {}
        try:
            payload = json.loads(self.autosave_path.read_text(encoding="utf-8"))
            return dict(payload) if isinstance(payload, dict) else {}
        except Exception:
            return {}

    def clear_autosave(self) -> None:
        self.autosave_path.unlink(missing_ok=True)
        sai_receipt_drafts.remove(self.DRAFT_ID)

    def signature(
        self,
        *,
        supplier_id: Any,
        supplier_name: Any,
        date_text: Any,
        rows: Sequence[Mapping[str, Any]],
    ) -> str:
        return stable_rows_signature(
            supplier_id=supplier_id,
            supplier_name=supplier_name,
            date_text=date_text,
            rows=rows,
        )

    def build_document(
        self,
        *,
        rows: Sequence[Mapping[str, Any]],
        supplier: Any,
        date_text: Any,
        markup_percent: Any,
    ) -> ManualReceiptDocument:
        return build_document(
            rows=rows,
            supplier=supplier,
            date_text=date_text,
            markup_percent=markup_percent,
        )

    @staticmethod
    def to_convert_result(document: ManualReceiptDocument) -> sai_converter.ConvertResult:
        return sai_converter.ConvertResult(
            source_path=document.source_path,
            source_type=document.source_type,
            supplier=document.supplier,
            date=document.date,
            invoice_number=document.invoice_number,
            markup_percent=document.markup_percent,
            items=[
                sai_converter.ConvertItem(
                    row=item.row,
                    name=item.name,
                    quantity=item.quantity,
                    unit=item.unit,
                    purchase_price=item.purchase_price,
                    sale_price=item.sale_price,
                    category=item.category,
                    barcodes=list(item.barcodes),
                    comment=item.comment,
                )
                for item in document.items
            ],
        )

    def build_convert_result(
        self,
        *,
        rows: Sequence[Mapping[str, Any]],
        supplier: Any,
        date_text: Any,
        markup_percent: Any,
    ) -> sai_converter.ConvertResult:
        return self.to_convert_result(
            self.build_document(
                rows=rows,
                supplier=supplier,
                date_text=date_text,
                markup_percent=markup_percent,
            )
        )

    def save_prepared_receipt(self, result: sai_converter.ConvertResult) -> dict[str, Any]:
        missing = any(
            float(item.quantity or 0) > 0 and not list(item.barcodes or [])
            for item in (result.items or [])
        )
        return sai_receipt_drafts.save_result(
            result,
            (),
            draft_id=None,
            stage="semi_auto" if missing else "automatic",
            kind="manual",
        )


def supplier_fields(combo_data: Any, combo_text: Any = "") -> tuple[str, str]:
    if isinstance(combo_data, Mapping):
        return text(combo_data.get("id")), text(combo_data.get("name"))
    return "", text(combo_text)
