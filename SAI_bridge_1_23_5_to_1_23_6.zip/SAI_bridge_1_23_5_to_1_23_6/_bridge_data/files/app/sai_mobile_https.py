#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Local HTTPS material for the SAI mobile barcode scanner.

The private CA key stays in the current Windows user's certificate store.
Only a public CA certificate and the short-lived LAN server key are exported
into user_data, which is excluded from Git.
"""
from __future__ import annotations

import json
import plistlib
import subprocess
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass(frozen=True)
class MobileHttpsMaterial:
    ca_certificate: Path
    server_certificate: Path
    server_private_key: Path


def build_apple_ca_profile(ca_certificate: Path) -> bytes:
    """Return an iOS configuration profile containing only the public SAI CA."""
    namespace = uuid.UUID("4ba48c45-54ed-47cd-9a27-80ea5cb191aa")
    root_uuid = str(uuid.uuid5(namespace, "sai-mobile-root-profile")).upper()
    payload_uuid = str(uuid.uuid5(namespace, "sai-mobile-root-certificate")).upper()
    payload = {
        "PayloadContent": ca_certificate.read_bytes(),
        "PayloadCertificateFileName": "SAI-Local-CA.cer",
        "PayloadDescription": "Доверие локальному HTTPS-серверу мобильного сканера SAI.",
        "PayloadDisplayName": "SAI Local Mobile Scanner CA",
        "PayloadIdentifier": "ru.sai.mobile-scanner.ca",
        "PayloadType": "com.apple.security.root",
        "PayloadUUID": payload_uuid,
        "PayloadVersion": 1,
    }
    profile = {
        "PayloadContent": [payload],
        "PayloadDescription": "Локальный сертификат живой камеры SAI.",
        "PayloadDisplayName": "SAI — локальная камера",
        "PayloadIdentifier": "ru.sai.mobile-scanner",
        "PayloadOrganization": "SAI",
        "PayloadRemovalDisallowed": False,
        "PayloadType": "Configuration",
        "PayloadUUID": root_uuid,
        "PayloadVersion": 1,
    }
    return plistlib.dumps(profile, fmt=plistlib.FMT_XML, sort_keys=False)


def _state_is_current(state_path: Path, ip_address: str) -> bool:
    try:
        state = json.loads(state_path.read_text(encoding="utf-8-sig"))
        expires = datetime.fromisoformat(str(state["server_not_after"]).replace("Z", "+00:00"))
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return (
            str(state.get("ip") or "") == ip_address
            and expires > datetime.now(timezone.utc).replace(microsecond=0)
        )
    except Exception:
        return False


def ensure_mobile_https_material(
    *,
    app_dir: Path,
    user_data_dir: Path,
    ip_address: str,
) -> MobileHttpsMaterial:
    output_dir = user_data_dir / "mobile_https"
    ca_path = output_dir / "sai-local-ca.cer"
    cert_path = output_dir / "sai-mobile-server.pem"
    key_path = output_dir / "sai-mobile-server-key.pem"
    state_path = output_dir / "state.json"
    files_exist = all(path.is_file() and path.stat().st_size > 0 for path in (ca_path, cert_path, key_path))
    if not files_exist or not _state_is_current(state_path, ip_address):
        script_path = app_dir / "sai_mobile_https.ps1"
        if not script_path.is_file():
            raise RuntimeError("Не найден генератор локального сертификата SAI.")
        output_dir.mkdir(parents=True, exist_ok=True)
        completed = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
                "-OutputDir",
                str(output_dir),
                "-IpAddress",
                ip_address,
            ],
            capture_output=True,
            text=True,
            timeout=45,
            creationflags=int(getattr(subprocess, "CREATE_NO_WINDOW", 0)),
        )
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout or "").strip()
            raise RuntimeError(f"Не удалось создать локальный HTTPS-сертификат: {detail}")
    if not all(path.is_file() and path.stat().st_size > 0 for path in (ca_path, cert_path, key_path)):
        raise RuntimeError("Локальный HTTPS-сертификат SAI создан не полностью.")
    return MobileHttpsMaterial(ca_path, cert_path, key_path)
