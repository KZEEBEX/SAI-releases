#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Runtime paths for SAI.

Code/templates live in app/. User secrets, browser profile, cache and logs live in
../user_data/ by default. This keeps release archives clean and avoids leaking
SIGMA tokens or browser sessions.
"""

import os
import shutil
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
USER_DATA_DIR = Path(os.environ.get("SAI_USER_DATA_DIR") or (ROOT_DIR / "user_data")).resolve()
PROFILE_DIR = Path(os.environ.get("SAI_PROFILE_DIR") or (USER_DATA_DIR / "Profile")).resolve()
TEMPLATES_DIR = APP_DIR / "templates"
CACHE_DIR = USER_DATA_DIR / "cache"
LOGS_DIR = USER_DATA_DIR / "logs"
CONFIG_PATH = USER_DATA_DIR / "sai_config.json"
PRIVATE_CONFIG_PATH = USER_DATA_DIR / "sai_private_config.json"
PRIVATE_CONFIG_EXAMPLE_PATH = APP_DIR / "sai_private_config.example.json"
DB_PATH = USER_DATA_DIR / "sai.db"

# Legacy locations used before v1.16.0. They are never included in clean releases,
# but migration keeps an upgraded existing folder usable.
LEGACY_PROFILE_DIR = ROOT_DIR / "Profile"
LEGACY_CACHE_DIR = APP_DIR / "cache"
LEGACY_LOGS_DIR = APP_DIR / "logs"
LEGACY_CONFIG_PATH = APP_DIR / "sai_config.json"
LEGACY_PRIVATE_CONFIG_PATH = APP_DIR / "sai_private_config.json"


def ensure_runtime_dirs() -> None:
    USER_DATA_DIR.mkdir(parents=True, exist_ok=True)
    PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    LOGS_DIR.mkdir(parents=True, exist_ok=True)


def migrate_legacy_user_files() -> None:
    """Copy old local config/cache/profile into user_data on first run.

    Copy, do not move: this avoids destroying a working install. The clean-release
    builder excludes both old and new local-data locations.
    """
    ensure_runtime_dirs()
    for old, new in (
        (LEGACY_CONFIG_PATH, CONFIG_PATH),
        (LEGACY_PRIVATE_CONFIG_PATH, PRIVATE_CONFIG_PATH),
    ):
        try:
            if old.exists() and not new.exists():
                shutil.copy2(old, new)
        except Exception:
            pass

    # Copy only if the new dirs are empty; browser/cache folders can be large.
    for old_dir, new_dir in (
        (LEGACY_PROFILE_DIR, PROFILE_DIR),
        (LEGACY_CACHE_DIR, CACHE_DIR),
        (LEGACY_LOGS_DIR, LOGS_DIR),
    ):
        try:
            if old_dir.exists() and old_dir.is_dir() and not any(new_dir.iterdir()):
                shutil.copytree(old_dir, new_dir, dirs_exist_ok=True)
        except Exception:
            pass
