#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression checks for the splash-free startup handoff."""
from __future__ import annotations

import ast
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
SOURCE = APP_DIR / "sai_pyside_preview.py"


def function_source(class_name: str, function_name: str) -> str:
    text = SOURCE.read_text(encoding="utf-8-sig")
    tree = ast.parse(text, filename=str(SOURCE))
    lines = text.splitlines()
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for child in node.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child.name == function_name:
                    end = getattr(child, "end_lineno", child.lineno)
                    return "\n".join(lines[child.lineno - 1:end])
    raise AssertionError(f"Не найден {class_name}.{function_name}")


def main() -> int:
    gate = function_source("StartupGateWidget", "start_finish_transition")
    handoff = function_source("MainWindow", "finish_startup")

    assert "self.startup_done.emit" in gate
    assert "AnimatedStartupSplash" not in gate
    assert "shell.grab()" not in handoff
    assert "StartupHandoffOverlay" not in handoff
    assert "self.main_stack.setCurrentWidget(self.main_page)" in handoff
    assert handoff.index("MainPage()") < handoff.index("setCurrentWidget(self.main_page)"), "Нельзя показывать недостроенный интерфейс"
    assert "QTimer.singleShot(0" in handoff and "start_background_services" in handoff
    assert "QPropertyAnimation" not in handoff

    print("OK: запуск без заставки защищён regression-тестом")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
