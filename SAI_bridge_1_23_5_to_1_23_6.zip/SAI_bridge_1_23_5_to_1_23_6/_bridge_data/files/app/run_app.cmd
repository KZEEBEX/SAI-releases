@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv not found. Run install.cmd first.
  pause
  exit /b 1
)

if not exist "..\user_data" mkdir "..\user_data"
".venv\Scripts\python.exe" sai_app.py
