#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import ast, json, os, sys, tempfile
from pathlib import Path

root=Path(sys.argv[1]).resolve()
os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_ai_')
sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as ai

assert ai.CONTRACT_VERSION=='invoice_ai_contract_v13'
assert ai.PROMPT_VERSION=='invoice_prompt_v11'
assert ai.AUDIT_PROMPT_VERSION=='invoice_audit_prompt_v7'
assert ai.HEADER_PROMPT_VERSION=='invoice_header_prompt_v1'
assert ai.DEFAULT_MODEL=='gpt-5.6-luna'
ai.invoice_contract_metadata()
assert ai._equivalent_text('POTATO P0042S','РОТАТО P0042S')
assert not ai._equivalent_text('сатин','сантин')
assert ai._equivalent_unit('шт.','штука')

def response(data, input_tokens=1000, output_tokens=200):
    return {
        'output':[{'type':'message','content':[{'type':'output_text','text':json.dumps(data,ensure_ascii=False)}]}],
        'usage':{'input_tokens':input_tokens,'output_tokens':output_tokens,'total_tokens':input_tokens+output_tokens,'input_tokens_details':{'cached_tokens':0}},
    }

def item(row,page,total,name='ТОВАР',barcode='4607136256514',article=None,quantity=1.0):
    return {'source_row':row,'source_page':page,'raw_name':name,'name':name,'quantity':quantity,'unit':'шт',
            'purchase_price':total/max(quantity,1),'line_total':total,'article':article if article is not None else f'A{row}',
            'barcodes':([barcode] if barcode else []),'confidence':0.9,'note':''}

def doc(items,total=0.0,supplier='ТЕСТОВЫЙ ПОСТАВЩИК',date='2026-07-18',number='AI-1'):
    return {'supplier':supplier,'invoice_date':date,'invoice_number':number,'currency':'RUB',
            'document_total':total,'document_total_note':'','items':items,'warnings':[]}

# First-page headers are authoritative. Continuation-page hallucinations are ignored.
merged=ai._merge_page_documents([
    (1,doc([item(1,1,100.0)],0.0,supplier='ИП СМИРНОВ',date='16.07.2026',number='G-1')),
    (2,doc([item(2,2,200.0)],300.0,supplier='ДРУГОЙ',date='18.07.2026',number='BAD')),
])
assert merged['supplier']=='ИП СМИРНОВ'
assert merged['invoice_date']=='16.07.2026'
assert merged['invoice_number']=='G-1'
assert merged['document_total']==300.0

# Two Luna readings: script-only difference is cosmetic, missing article is filled,
# barcode disagreement is safely omitted without a Terra target.
primary=doc([
    item(1,1,100.0,name='РОТАТО СМЕСИТЕЛЬ P0042S',article=''),
    item(2,1,200.0,name='КОРОБКА',barcode='4607136256514'),
],300.0,date='')
verify=doc([
    item(1,1,100.0,name='POTATO СМЕСИТЕЛЬ P0042S',article='59279638'),
    item(2,1,200.0,name='КОРОБКА',barcode=''),
],300.0,date='16.07.2026')
rec,problems,notes,omitted,changes=ai.reconcile_luna_page(primary,verify,1)
assert problems==[]
assert omitted==[2]
assert rec['invoice_date']=='16.07.2026'
assert rec['items'][0]['article']=='59279638'
assert rec['items'][0]['raw_name'].startswith('POTATO')
assert rec['items'][1]['barcodes']==[]

# Material name difference remains a precise row target.
verify_bad=doc([item(1,1,100.0,name='POTATO СМЕСИТЕЛЬ P0042S')],100.0)
primary_bad=doc([item(1,1,100.0,name='POTATO УДЛИНИТЕЛЬ P0042S')],100.0)
_rec,problems,notes,_omitted,_changes=ai.reconcile_luna_page(primary_bad,verify_bad,1)
assert problems==[1]
assert any('raw_name' in note for note in notes)

# Compact repair draft and crop groups contain only requested rows.
draft=doc([item(1,1,10),item(2,1,20),item(3,2,30),item(4,2,40)],100)
compact=ai._compact_audit_draft(draft,[2,4])
assert [row['source_row'] for row in compact['items']]==[2,4]
groups=ai._row_groups_for_targets(draft,[2,4])
assert set(groups)=={1,2}
assert groups[1][0]['source_rows']==[2]
assert groups[2][0]['source_rows']==[4]

# End-to-end mocked visual agent: four Luna calls, no Terra; date comes from
# the independent first-page read and disputed barcode remains empty.
work=Path(tempfile.mkdtemp(prefix='sai_ai_case_'))
p1=work/'page1.png'; p2=work/'page2.png'
p1.write_bytes(b'fake1'); p2.write_bytes(b'fake2')
plan={str(p1.resolve()):[0],str(p2.resolve()):[0]}
calls=[]
original_build=ai.build_request_payload
original_call=ai.call_openai

def fake_build(paths,model='',supplier_hint='',date_hint='',invoice_hint='',stage='extract',draft=None,target_rows=None,audit_notes=None,orientation_plan=None,target_global_pages=None):
    return {'model':model or ai.DEFAULT_MODEL,'_stage':stage,'_page':int((target_global_pages or [0])[0]),
            '_target_rows':list(target_rows or []),'_sai_precision_views_used':True,'_sai_precision_views_count':5}

def fake_call(payload,*args,**kwargs):
    calls.append((payload['_stage'],payload['_page'],tuple(payload.get('_target_rows') or [])))
    page=payload['_page']; stage=payload['_stage']
    if page==1 and stage=='extract_luna':
        return response(doc([item(1,1,100,name='РОТАТО СМЕСИТЕЛЬ',article='')],0,date=''))
    if page==1 and stage=='extract_luna_verify':
        return response(doc([item(1,1,100,name='POTATO СМЕСИТЕЛЬ',article='59279638')],0,date='16.07.2026'))
    if page==2 and stage=='extract_luna':
        return response(doc([item(2,2,200,barcode='4607136256514')],300,date='',supplier='',number=''))
    if page==2 and stage=='extract_luna_verify':
        return response(doc([item(2,2,200,barcode='')],300,date='',supplier='',number=''))
    raise AssertionError(f'unexpected call: {payload}')

ai.build_request_payload=fake_build
ai.call_openai=fake_call
try:
    result=ai.analyze_invoice([p1,p2],'sk-test',orientation_plan=plan)
finally:
    ai.build_request_payload=original_build
    ai.call_openai=original_call
assert calls==[
    ('extract_luna',1,()),('extract_luna_verify',1,()),
    ('extract_luna',2,()),('extract_luna_verify',2,()),
]
assert len(result.items)==2
assert str(result.date)=='2026-07-16'
assert result.items[0].article=='59279638'
assert result.items[1].barcodes==[]
assert result.validation['agent_mode']=='dual_luna_consensus_cropped_terra_sol'
assert result.validation['audit_model']=='dual_luna_local_consensus'

ui_path=root/'app'/'sai_pyside_preview.py'
ui=ui_path.read_text(encoding='utf-8')
ast.parse(ui,filename=str(ui_path))
assert 'две независимые Luna' in ui
assert 'нечитаемый ШК оставлен пустым' not in ui
print('PATCH_AI_SELF_TEST_OK')
