#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Publish an already verified SAI installer into the organization channel."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--organization-root", type=Path, required=True)
    parser.add_argument("--version", required=True)
    parser.add_argument("--package", type=Path, required=True)
    args = parser.parse_args()
    package = args.package.resolve()
    if not package.is_file():
        raise SystemExit(f"Package not found: {package}")
    updates = args.organization_root.resolve() / "updates"
    updates.mkdir(parents=True, exist_ok=True)
    target = updates / package.name
    temporary = target.with_suffix(target.suffix + ".tmp")
    shutil.copy2(package, temporary)
    os.replace(temporary, target)
    manifest = {
        "schema_version": 1,
        "version": str(args.version).strip().lstrip("v"),
        "package": target.name,
        "sha256": sha256(target),
    }
    temp_manifest = updates / "latest.json.tmp"
    temp_manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp_manifest, updates / "latest.json")
    print(f"Published SAI {manifest['version']}: {target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
