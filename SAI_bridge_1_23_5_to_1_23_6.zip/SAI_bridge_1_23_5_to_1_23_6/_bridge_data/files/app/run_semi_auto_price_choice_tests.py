#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Regression: operator-selected semi-auto price reaches SIGMA unchanged."""
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

import sai_package
from sai_api_first_apply import resolve_final_selling_price
from sai_app import DEFAULT_SAI_SHEET, write_sai_rows_to_xlsx
from sai_core_v2.semi_auto_receipt_refactor import lock_sale_price_for_thermal_label, row_barcodes
from sai_semi_auto_receipt import SemiAutoReceiptService
from sigma_autoprihod import read_excel_rows


def main() -> int:
    row = {
        "name": "ТЕСТ",
        "qty": 2,
        "buy": 50,
        "sale": 80,
        "unit": "штука",
        "barcodes": ["4601234567893"],
        "price_operator_approved": True,
        "price_approval_source": "incoming",
        "catalog_price_snapshot": 120,
        "price_approval_barcode": "4601234567893",
    }
    with tempfile.TemporaryDirectory() as raw:
        folder = Path(raw)
        package = folder / "draft.sai"
        SemiAutoReceiptService().save_rows([dict(row)], source_path=None, output_path=package)
        _sheet, loaded, _meta = sai_package.load_rows(package)
        assert loaded[0]["price_operator_approved"] is True
        assert loaded[0]["price_approval_source"] == "incoming"

        workbook = folder / "effective.xlsx"
        write_sai_rows_to_xlsx(loaded, workbook)
        apply_rows = read_excel_rows(str(workbook), DEFAULT_SAI_SHEET)
        final, source, policy = resolve_final_selling_price(apply_rows[0], 120, "max")
        assert (final, source, policy) == (80, "OPERATOR_APPROVED_INCOMING", "incoming")

        normal, _source, normal_policy = resolve_final_selling_price(
            {"selling_price": 80, "price_operator_approved": False}, 120, "max"
        )
        assert normal == 120
        assert normal_policy == "max"

        # Merely printing the visible P/A price is also an operator decision:
        # the sticker must never be invalidated by the later max-price policy.
        untouched = dict(row)
        untouched["price_operator_approved"] = False
        untouched["price_approval_source"] = ""
        locked = lock_sale_price_for_thermal_label(untouched)
        assert locked["sale"] == 80
        assert locked["price_operator_approved"] is True
        assert locked["price_approval_source"] == "thermal_label"

        printed = []
        saved = []
        events = []
        page = SimpleNamespace(
            rows=[untouched],
            _current_qty_copies=lambda _row: 2,
            row_barcodes=row_barcodes,
        )
        def save_before_print(**_kwargs):
            events.append("saved")
            saved.append(dict(page.rows[0]))
            return package

        def capture_print(item, **_kwargs):
            events.append("printed")
            printed.append(dict(item))
            return True

        page.save_updated_sai_file = save_before_print
        import sai_pyside_preview as ui
        with patch.object(ui, "_thermal_config", return_value={"max_without_confirm": 20, "printer": "test"}), \
             patch.object(ui, "print_thermal_price_label", side_effect=capture_print):
            copies = ui.SemiAutoReceiptPage.print_thermal_labels_for_row(page, untouched)
        assert copies == 2
        assert events == ["saved", "printed"]
        assert saved and saved[0]["price_operator_approved"] is True
        assert saved[0]["price_approval_source"] == "thermal_label"
        assert printed == [{"name": "ТЕСТ", "barcode": "4601234567893", "price": 80, "unit": "штука"}]

        print_locked_package = folder / "printed.sai"
        SemiAutoReceiptService().save_rows(page.rows, source_path=None, output_path=print_locked_package)
        _sheet, print_locked_rows, _meta = sai_package.load_rows(print_locked_package)
        print_locked_workbook = folder / "printed-effective.xlsx"
        write_sai_rows_to_xlsx(print_locked_rows, print_locked_workbook)
        printed_apply_rows = read_excel_rows(str(print_locked_workbook), DEFAULT_SAI_SHEET)
        final, source, policy = resolve_final_selling_price(printed_apply_rows[0], 120, "max")
        assert (final, source, policy) == (80, "OPERATOR_APPROVED_THERMAL_LABEL", "incoming")
    print("Semi-auto operator price choice tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
