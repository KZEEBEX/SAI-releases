#!/usr/bin/env python
"""Regression tests for price-tag data extraction."""
from __future__ import annotations

import ast
import tempfile
from pathlib import Path

from sai_price_tags import (
    price_number,
    price_tag_name,
    price_text,
    read_sai_price_items,
    read_sai_xml_price_items,
    unit_text,
)


HERE = Path(__file__).resolve().parent


def main() -> None:
    assert price_number("1 234,50 руб.") == 1234.5
    assert price_text("1234") == "1 234"
    assert price_text("1234,5") == "1 234,50"
    assert price_tag_name('Кисть №2 (12/720) "КЕДР" 006-4020') == "КИСТЬ №2 КЕДР 006-4020"
    assert price_tag_name("Лента (вспененная) 24 мм") == "ЛЕНТА (ВСПЕНЕННАЯ) 24 ММ"
    assert unit_text("шт") == "шт."
    assert unit_text("килограмм") == "кг"

    xml = """<?xml version='1.0' encoding='utf-8'?>
<receipt><items>
  <item><name>Товар А</name><unit>шт</unit><sale_price>125,50</sale_price><barcodes><barcode>4601234567893</barcode></barcodes></item>
  <item><name>Товар А</name><unit>шт</unit><sale_price>125,50</sale_price><barcode>4601234567893</barcode></item>
  <item><name>Товар Б</name><unit>кг</unit><price>200</price><bar_code>10000542</bar_code></item>
</items></receipt>"""
    with tempfile.TemporaryDirectory(prefix="sai_price_tag_test_") as tmp:
        source = Path(tmp) / "receipt.xml"
        source.write_text(xml, encoding="utf-8")
        items = read_sai_xml_price_items(source)
        assert items == read_sai_price_items(source)
        assert len(items) == 2
        assert items[0] == {"name": "Товар А", "barcode": "4601234567893", "price": 125.5, "unit": "шт"}
        assert items[1]["barcode"] == "10000542"

    ui_text = (HERE / "sai_pyside_preview.py").read_text(encoding="utf-8")
    ui_tree = ast.parse(ui_text)
    forbidden = {
        "read_sai_xml_price_items", "read_sai_xlsx_price_items",
        "read_sai_package_price_items", "read_sai_price_items",
        "_price_tag_num", "_price_tag_price_text", "_price_tag_unit_text",
    }
    remaining = {node.name for node in ast.walk(ui_tree) if isinstance(node, ast.FunctionDef)}
    assert not forbidden & remaining, f"price-tag data logic leaked into UI: {sorted(forbidden & remaining)}"
    assert "from sai_price_tags import" in ui_text
    print("SAI price-tag data refactor tests: OK")


if __name__ == "__main__":
    main()
