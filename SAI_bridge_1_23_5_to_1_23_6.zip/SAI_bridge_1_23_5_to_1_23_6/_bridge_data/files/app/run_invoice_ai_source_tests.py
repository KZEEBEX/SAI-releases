#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent regression tests for invoice AI contract/source boundaries."""
from __future__ import annotations

import inspect
import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_invoice_sources_")
sys.path.insert(0, str(root / "app"))

import sai_invoice_ai_contract as contract
import sai_invoice_ai_sources as sources
import sai_openai_invoice as ai
import sai_converter
import sai_page_orientation as orientation
from sai_invoice_ai_errors import OpenAIInvoiceError

assert ai.OpenAIInvoiceError is OpenAIInvoiceError
assert sources.OpenAIInvoiceError is OpenAIInvoiceError
assert ai.CONTRACT_VERSION == contract.CONTRACT_VERSION == "invoice_ai_contract_v15"
assert ai.PROMPT_VERSION == contract.PROMPT_VERSION == "invoice_prompt_v13"
assert ai.IMAGE_EXTENSIONS is sources.IMAGE_EXTENSIONS
assert ai.SUPPORTED_EXTENSIONS is sources.SUPPORTED_EXTENSIONS

metadata = ai.invoice_contract_metadata()
assert metadata == contract.invoice_contract_metadata()
assert metadata["contract_version"] == "invoice_ai_contract_v15"
assert len(metadata["prompt_sha256"]) == 64
assert ai.build_invoice_schema() == contract.load_invoice_schema()
assert ai.build_audit_schema() == contract.load_audit_schema()
ui_source = (root / "app" / "sai_pyside_preview.py").read_text(encoding="utf-8")
assert "failed_pages or len(loaded_pages) != page_count" in ui_source
assert "Распознавание не запущено, чтобы не потерять листы" in ui_source
assert ai.build_header_schema() == contract.load_header_schema()

work = Path(tempfile.mkdtemp(prefix="sai_invoice_source_case_"))
text_file = work / "invoice.txt"
text_file.write_text("test invoice", encoding="utf-8")
assert ai.validate_source_paths([text_file]) == sources.validate_source_paths([text_file])
assert ai._mime_for(text_file) == sources.mime_for(text_file) == "text/plain"

diadoc_zip = work / "Входящий УПД.zip"
upd_xml = '''<?xml version="1.0" encoding="windows-1251"?>
<Файл><Документ><СвСчФакт НомерДок="G-42" ДатаДок="09.09.2026"/>
<СвПрод><ИдСв><СвИП ИННФЛ="123"><ФИО Фамилия="Смирнов" Имя="Игорь" Отчество="Алексеевич"/></СвИП></ИдСв></СвПрод>
<ТаблСчФакт><СведТов НомСтр="1" НаимТов="Товар один" КолТов="3" ЦенаТов="100" СтТовУчНал="366">
<ДопСведТов КодТов="4601234567893"/></СведТов>
<СведТов НомСтр="2" НаимТов="Товар два" КолТов="2" ЦенаТов="50" СтТовУчНал="122">
<ДопСведТов КодТов="4607000000008"/></СведТов></ТаблСчФакт>
</Документ></Файл>'''.encode("cp1251")
with zipfile.ZipFile(diadoc_zip, "w") as archive:
    archive.writestr("DP_PDOTPR_service.xml", "<Файл><Статус>Принят</Статус></Файл>")
    archive.writestr("ON_NSCHFDOPPR_document.xml", upd_xml)
    archive.writestr("ON_NSCHFDOPPR_document.xml.sgn", b"signature")
assert diadoc_zip in ai.validate_source_paths([diadoc_zip])
assert sources.mime_for(diadoc_zip) == "application/zip"
diadoc = ai.analyze_invoice([diadoc_zip], api_key="", markup_percent=60)
assert diadoc.source_type == "DIADOC/UPD"
assert diadoc.supplier == "ИП СМИРНОВ ИГОРЬ АЛЕКСЕЕВИЧ"
assert diadoc.date == "2026-09-09" and diadoc.invoice_number == "G-42"
assert len(diadoc.items) == 2
assert diadoc.items[0].barcodes == ["4601234567893"]
assert diadoc.items[0].purchase_price == 122.0
assert diadoc.items[0].purchase_price_source == "сумма строки с НДС / количество"
assert diadoc.validation["agent_mode"] == "local_diadoc_upd"
assert diadoc.validation["estimated_cost_usd"] == 0.0

visual = work / "crop-page.png"
from PySide6.QtGui import QColor, QImage
image = QImage(1200, 1600, QImage.Format_RGB32)
image.fill(QColor("white"))
assert image.save(str(visual))
crop_plan = {str(visual.resolve()): [{"angle": 90, "crop": [0.1, 0.2, 0.5, 0.25]}]}
normalized_crop_plan = orientation.normalize_plan([visual], crop_plan)
assert orientation.angle_for_page(visual, 0, normalized_crop_plan) == 90
assert orientation.crop_for_page(visual, 0, normalized_crop_plan) == (0.1, 0.2, 0.5, 0.25)
assert orientation.normalize_crop([0.1, 0.1, 0.01, 0.01]) is None
views, complete = sources.render_prepared_visual_views([visual], normalized_crop_plan)
assert visual.resolve() in complete and len(views) == 1
rendered_crop = QImage.fromData(views[0][2])
assert rendered_crop.width() > rendered_crop.height()
assert "область, выбранная оператором" in views[0][1]
assert "страница SAI 1" in views[0][1]

unsupported = work / "invoice.exe"
unsupported.write_bytes(b"x")
for validator in (ai.validate_source_paths, sources.validate_source_paths):
    try:
        validator([unsupported])
    except OpenAIInvoiceError as exc:
        assert "не поддерживается" in str(exc)
    else:
        raise AssertionError("unsupported file was accepted")

try:
    ai.validate_source_paths([])
except OpenAIInvoiceError as exc:
    assert "Не выбраны файлы" in str(exc)
else:
    raise AssertionError("empty source list was accepted")

odt = work / "invoice.odt"
with zipfile.ZipFile(odt, "w") as archive:
    archive.writestr(
        "content.xml",
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
        'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0">'
        '<office:body><office:text><text:p>ТОВАР 2 10-00</text:p></office:text></office:body>'
        '</office:document-content>',
    )
odt_content = []
sources.append_sources(odt_content, [odt])
assert any("ТОВАР 2 10-00" in str(item.get("text") or "") for item in odt_content)
assert not any(item.get("type") == "input_file" for item in odt_content)

from openpyxl import Workbook
quantity_book = work / "quantity.xlsx"
workbook = Workbook()
sheet = workbook.active
sheet.append(["Наименование", "Количество", "Цена"])
sheet.append(["ТОВАР", "2/15", 78])
workbook.save(quantity_book)
workbook.close()
assert sources.ambiguous_quantity_hints([quantity_book]) == {"ТОВАР": "2/15"}

draft = {
    "items": [
        {"source_row": 1, "source_page": 1},
        {"source_row": 2, "source_page": 1},
        {"source_row": 3, "source_page": 1},
        {"source_row": 4, "source_page": 2},
        {"source_row": 5, "source_page": 2},
    ]
}
expected_groups = {
    1: [{"start_index": 1, "end_index": 2, "total_rows": 3, "source_rows": [2, 3]}],
    2: [{"start_index": 1, "end_index": 1, "total_rows": 2, "source_rows": [5]}],
}
assert ai._row_groups_for_targets(draft, [2, 3, 5]) == expected_groups
assert sources.row_groups_for_targets(draft, [2, 3, 5]) == expected_groups
assert "operator-confirmed" in inspect.getsource(ai._render_prepared_visual_views)

payload = ai.build_request_payload([text_file], model="gpt-custom", stage="extract")
assert payload["model"] == "gpt-custom"
assert payload["_sai_precision_views_used"] is False
assert payload["_sai_precision_views_count"] == 0
content = payload["input"][0]["content"]
assert any(part.get("type") == "input_file" and part.get("filename") == "invoice.txt" for part in content)
assert json.dumps(payload, ensure_ascii=False)

batch_payload = ai.build_request_payload([text_file], model="gpt-custom", stage="extract_batch")
assert batch_payload["model"] == "gpt-custom"
assert batch_payload["_sai_precision_views_used"] is False
batch_text = "\n".join(part.get("text", "") for part in batch_payload["input"][0]["content"])
assert "ВЕСЬ КОМПЛЕКТ" in batch_text and "ТОЛЬКО ОДИН РАЗ" in batch_text
assert "Обработай каждый полный лист" in batch_text

print("INVOICE_AI_SOURCE_TESTS_OK")
