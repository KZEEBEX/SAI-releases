#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Cost accounting and privacy-minimized shadow telemetry for SAI Invoice AI.

This module is deliberately independent from the network/orchestration code.  It
contains only deterministic calculations and best-effort local JSONL logging, so
it can be tested without OpenAI calls and reused by future economical routes.
"""
from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

import sai_converter
from sai_core import gtin_check_digit_ok
from sai_runtime_paths import USER_DATA_DIR

AI_ECONOMY_TELEMETRY_PATH = USER_DATA_DIR / "logs" / "ai_invoice_economy.jsonl"
SHADOW_ECONOMY_VERSION = "adaptive_second_luna_shadow_v1"
MODEL_PRICES_USD_PER_MILLION: Dict[str, tuple[float, float, float]] = {
    "gpt-5.6-sol": (5.00, 0.50, 30.00),
    "gpt-5.6": (5.00, 0.50, 30.00),
    "gpt-5.6-terra": (2.50, 0.25, 15.00),
    "gpt-5.6-luna": (1.00, 0.10, 6.00),
    "gpt-5.5": (5.00, 0.50, 30.00),
    "gpt-5.4": (2.50, 0.25, 15.00),
    "gpt-5.4-mini": (0.75, 0.075, 4.50),
    "gpt-5.4-nano": (0.20, 0.02, 1.25),
    "gpt-5": (1.25, 0.125, 10.00),
    "gpt-5-mini": (0.25, 0.025, 2.00),
}


def response_usage(response: Mapping[str, Any] | None) -> Dict[str, int]:
    raw = response.get("usage") if isinstance(response, Mapping) else {}
    raw = raw if isinstance(raw, Mapping) else {}
    details = raw.get("input_tokens_details") or raw.get("input_token_details") or {}
    details = details if isinstance(details, Mapping) else {}
    out = raw.get("output_tokens_details") or raw.get("output_token_details") or {}
    out = out if isinstance(out, Mapping) else {}
    return {
        "input_tokens": max(0, int(raw.get("input_tokens") or 0)),
        "cached_tokens": max(0, int(details.get("cached_tokens") or 0)),
        "output_tokens": max(0, int(raw.get("output_tokens") or 0)),
        "reasoning_tokens": max(0, int(out.get("reasoning_tokens") or 0)),
        "total_tokens": max(0, int(raw.get("total_tokens") or 0)),
    }


def _price_for_model(model: str) -> tuple[float, float, float] | None:
    value = str(model or "").strip().lower()
    for key in sorted(MODEL_PRICES_USD_PER_MILLION, key=len, reverse=True):
        if value == key or value.startswith(key + "-"):
            return MODEL_PRICES_USD_PER_MILLION[key]
    return None


def estimate_response_cost_usd(response: Mapping[str, Any], model: str) -> float | None:
    prices = _price_for_model(model)
    if prices is None:
        return None
    usage = response_usage(response)
    cached = min(usage["cached_tokens"], usage["input_tokens"])
    normal = max(0, usage["input_tokens"] - cached)
    return round(
        (normal * prices[0] + cached * prices[1] + usage["output_tokens"] * prices[2]) / 1_000_000,
        8,
    )


def stage_record(name: str, model: str, response: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "name": name,
        "model": model,
        "usage": response_usage(response),
        "estimated_cost_usd": estimate_response_cost_usd(response, model),
    }


def aggregate_stages(stages: Sequence[Mapping[str, Any]]) -> tuple[Dict[str, int], float | None]:
    usage = {
        "input_tokens": 0,
        "cached_tokens": 0,
        "output_tokens": 0,
        "reasoning_tokens": 0,
        "total_tokens": 0,
    }
    costs: List[float] = []
    for stage in stages:
        stage_usage = stage.get("usage") or {}
        for key in usage:
            usage[key] += int(stage_usage.get(key) or 0)
        if stage.get("estimated_cost_usd") is not None:
            costs.append(float(stage["estimated_cost_usd"]))
    return usage, (round(sum(costs), 8) if len(costs) == len(stages) else None)


def _valid_barcodes(value: Any) -> List[str]:
    result: List[str] = []
    for raw in value or []:
        for code in re.findall(
            r"(?<!\d)(\d{8}|\d{12}|\d{13}|\d{14})(?!\d)",
            sai_converter.safe_str(raw),
        ):
            if gtin_check_digit_ok(code) and code not in result:
                result.append(code)
    return result


def shadow_page_risk(doc: Mapping[str, Any], page_number: int) -> Dict[str, Any]:
    """Predict locally whether the second Luna read would be required."""
    items = list(doc.get("items") or []) if isinstance(doc, Mapping) else []
    reasons: List[str] = []
    observations: List[str] = []
    score = 0

    def add(points: int, message: str, critical: bool = False) -> None:
        nonlocal score
        score = min(100, score + max(0, int(points)))
        if message not in reasons:
            reasons.append(message)
        if critical:
            observations.append("critical")

    if not items:
        add(100, "страница не содержит товарных строк", True)
    row_numbers: List[int] = []
    seen_rows: set[int] = set()
    seen_codes: Dict[str, int] = {}
    for position, row in enumerate(items, start=1):
        try:
            number = int(row.get("source_row") or position)
        except Exception:
            number = position
            add(60, f"строка {position}: неверный source_row", True)
        if number <= 0:
            add(60, f"строка {position}: неположительный source_row", True)
            number = position
        if number in seen_rows:
            add(85, f"дубликат source_row {number}", True)
        seen_rows.add(number)
        row_numbers.append(number)
        if not sai_converter.safe_str(row.get("raw_name") or row.get("name")):
            add(55, f"строка {number}: нет наименования", True)
        if sai_converter.parse_float(row.get("quantity")) <= 0:
            add(55, f"строка {number}: нет количества", True)
        if sai_converter.parse_float(row.get("line_total")) <= 0:
            add(55, f"строка {number}: нет финальной суммы", True)
        try:
            source_page = max(1, int(row.get("source_page") or page_number))
        except Exception:
            source_page = page_number
        if source_page != int(page_number):
            add(15, f"строка {number}: модель указала страницу {source_page}")
        confidence = sai_converter.parse_float(row.get("confidence"))
        if 0 < confidence < 0.78:
            add(40, f"строка {number}: низкая уверенность {confidence:.2f}", True)
        elif 0 < confidence < 0.86:
            add(18, f"строка {number}: пониженная уверенность {confidence:.2f}")
        note = sai_converter.safe_str(row.get("note"))
        if note:
            add(30, f"строка {number}: модель оставила примечание", True)
        for code in _valid_barcodes(row.get("barcodes")):
            previous = seen_codes.get(code)
            if previous is not None and previous != number:
                add(75, f"одинаковый ШК повторяется в строках {previous} и {number}", True)
            else:
                seen_codes[code] = number

    ordered = sorted(row_numbers)
    if ordered and len(set(ordered)) == len(ordered):
        expected = list(range(ordered[0], ordered[-1] + 1))
        if ordered != expected:
            add(70, "номера строк внутри страницы имеют пропуски", True)
    warnings = (
        [sai_converter.safe_str(x) for x in (doc.get("warnings") or []) if sai_converter.safe_str(x)]
        if isinstance(doc, Mapping)
        else []
    )
    if warnings:
        add(25, "модель вернула предупреждения", True)
    if len(items) > 80:
        add(25, "на странице необычно много строк")

    must_verify = "critical" in observations or score >= 35
    return {
        "page": int(page_number),
        "decision": "verify" if must_verify else "skip",
        "risk_score": int(score),
        "reasons": reasons,
        "item_count": len(items),
        "valid_barcode_count": len(seen_codes),
    }


def shadow_actual_impact(
    page_problem_rows: Sequence[int],
    page_omitted: Sequence[int],
    page_changes: Mapping[int, Sequence[str]],
) -> Dict[str, Any]:
    problem = {int(x) for x in page_problem_rows if int(x) > 0}
    omitted = {int(x) for x in page_omitted if int(x) > 0}
    any_changed = set(problem) | set(omitted)
    material = set(problem) | set(omitted)
    noncritical = {"raw_name", "name", "article"}
    normalized_changes: Dict[str, List[str]] = {}
    for raw_row, reasons in (page_changes or {}).items():
        row = int(raw_row)
        clean = sorted({sai_converter.safe_str(x) for x in (reasons or []) if sai_converter.safe_str(x)})
        if clean:
            normalized_changes[str(row)] = clean
            any_changed.add(row)
            if any(reason not in noncritical for reason in clean):
                material.add(row)
    return {
        "any_change_rows": sorted(any_changed),
        "material_change_rows": sorted(material),
        "barcode_disagreement_rows": sorted(omitted),
        "corrections": normalized_changes,
    }


def summarize_shadow_pages(pages: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    values = [dict(page) for page in pages]
    candidates = [page for page in values if page.get("decision") == "skip"]
    false_negative = [page for page in candidates if (page.get("actual") or {}).get("material_change_rows")]
    safe = [page for page in candidates if not (page.get("actual") or {}).get("material_change_rows")]
    conservative = [
        page
        for page in values
        if page.get("decision") == "verify" and not (page.get("actual") or {}).get("material_change_rows")
    ]
    predicted_cost = sum(
        float(page.get("verification_route_cost_usd") or page.get("second_luna_cost_usd") or 0)
        for page in candidates
    )
    validated_cost = sum(
        float(page.get("verification_route_cost_usd") or page.get("second_luna_cost_usd") or 0)
        for page in safe
    )
    return {
        "version": SHADOW_ECONOMY_VERSION,
        "enabled": True,
        "actual_route_unchanged": True,
        "page_count": len(values),
        "candidate_skip_pages": [int(page.get("page") or 0) for page in candidates],
        "validated_safe_skip_pages": [int(page.get("page") or 0) for page in safe],
        "material_false_negative_pages": [int(page.get("page") or 0) for page in false_negative],
        "conservative_verify_pages": [int(page.get("page") or 0) for page in conservative],
        "predicted_savings_usd": round(predicted_cost, 8),
        "validated_savings_usd": round(validated_cost, 8),
        "pages": values,
    }


def empty_shadow_summary() -> Dict[str, Any]:
    return {
        "version": SHADOW_ECONOMY_VERSION,
        "enabled": True,
        "actual_route_unchanged": True,
        "page_count": 0,
        "candidate_skip_pages": [],
        "validated_safe_skip_pages": [],
        "material_false_negative_pages": [],
        "conservative_verify_pages": [],
        "predicted_savings_usd": 0.0,
        "validated_savings_usd": 0.0,
        "pages": [],
        "note": "Теневой адаптивный режим применяется к PDF и изображениям после подтверждения страниц.",
    }


def source_telemetry_summary(paths: Sequence[str | Path]) -> Dict[str, Any]:
    extensions: Dict[str, int] = {}
    total_bytes = 0
    for raw in paths:
        try:
            path = Path(raw)
            ext = path.suffix.lower() or "(none)"
            extensions[ext] = extensions.get(ext, 0) + 1
            total_bytes += max(0, int(path.stat().st_size))
        except Exception:
            continue
    return {
        "file_count": sum(extensions.values()),
        "extensions": extensions,
        "total_bytes": total_bytes,
    }


def append_economy_telemetry(record: Mapping[str, Any]) -> None:
    """Append a privacy-minimized local JSONL record; observability never blocks work."""
    try:
        AI_ECONOMY_TELEMETRY_PATH.parent.mkdir(parents=True, exist_ok=True)
        payload = dict(record)
        payload.setdefault("recorded_at", dt.datetime.now(dt.timezone.utc).isoformat())
        with AI_ECONOMY_TELEMETRY_PATH.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception:
        return
