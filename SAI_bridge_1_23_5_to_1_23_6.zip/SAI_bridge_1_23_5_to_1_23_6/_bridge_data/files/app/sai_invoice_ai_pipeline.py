#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""State and deterministic helpers for the SAI invoice AI pipeline."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Mapping, Sequence

import sai_converter


@dataclass
class InvoicePipelineState:
    """Mutable state owned by one invoice analysis run.

    Network calls remain in ``sai_openai_invoice``.  This object only collects
    stage accounting and quality decisions, making the orchestration smaller and
    easier to test without changing the paid route.
    """

    stages: List[Dict[str, Any]] = field(default_factory=list)
    row_corrections: Dict[int, List[str]] = field(default_factory=dict)
    barcode_omitted: set[int] = field(default_factory=set)
    unresolved: set[int] = field(default_factory=set)
    arbitration_rows: List[int] = field(default_factory=list)
    precision_views_count: int = 0
    primary_precision_used: bool = False
    consensus_problems: set[int] = field(default_factory=set)
    consensus_notes: List[str] = field(default_factory=list)
    shadow_pages: List[Dict[str, Any]] = field(default_factory=list)
    manual_header_fields: List[str] = field(default_factory=list)

    def record_payload(self, payload: Mapping[str, Any]) -> None:
        self.precision_views_count += int(payload.get("_sai_precision_views_count") or 0)
        self.primary_precision_used = self.primary_precision_used or bool(payload.get("_sai_precision_views_used"))

    def add_corrections(self, changes: Mapping[int, Sequence[str]]) -> None:
        for raw_row, reasons in (changes or {}).items():
            row = int(raw_row)
            self.row_corrections.setdefault(row, []).extend(str(reason) for reason in reasons)

    def normalized_corrections(self) -> Dict[str, List[str]]:
        return {
            str(row): sorted(set(reasons))
            for row, reasons in self.row_corrections.items()
        }


def restore_document_total(document: Dict[str, Any]) -> None:
    """Fill a missing document total from final line totals, in-place."""
    if sai_converter.parse_float(document.get("document_total")) > 0:
        return
    calculated = 0.0
    for row in (document.get("items") or []):
        line_total = sai_converter.parse_float(row.get("line_total"))
        if line_total <= 0:
            quantity = sai_converter.parse_float(row.get("quantity"))
            purchase_price = sai_converter.parse_float(row.get("purchase_price"))
            if quantity > 0 and purchase_price > 0:
                line_total = round(quantity * purchase_price, 4)
                row["line_total"] = line_total
                row["line_total_derived"] = True
        calculated += max(0.0, line_total)
    if calculated > 0:
        document["document_total"] = calculated
        document["document_total_note"] = (
            "Итог восстановлен SAI как сумма финальных сумм товарных строк."
        )


def merge_problem_notes(*groups: Sequence[str]) -> List[str]:
    return list(dict.fromkeys(note for group in groups for note in group))


def build_quality_metadata(
    state: InvoicePipelineState,
    *,
    visual_pages: Sequence[int],
    normalized_orientation: Mapping[str, Sequence[Any]],
    problem_notes: Sequence[str],
    economy_shadow: Mapping[str, Any],
    audit_model: str,
    fallback_model: str,
) -> Dict[str, Any]:
    corrections = state.normalized_corrections()
    return {
        "agent_mode": "single_batch_luna_targeted_terra_sol",
        "arbitrated": bool(state.arbitration_rows),
        "correction_count": len(corrections),
        "row_corrections": corrections,
        "precision_views_used": bool(state.primary_precision_used),
        "precision_views_count": state.precision_views_count,
        "pagewise_primary": bool(visual_pages),
        "pagewise_pages": len(visual_pages),
        "audit_model": (
            audit_model
            if any(stage.get("model") == audit_model for stage in state.stages)
            else "dual_luna_local_consensus"
        ),
        "fallback_model": (
            fallback_model
            if any(stage.get("model") == fallback_model for stage in state.stages)
            else ""
        ),
        "arbitration_rows": list(state.arbitration_rows),
        "unresolved_rows": sorted(state.unresolved),
        "barcode_omitted_rows": sorted(state.barcode_omitted),
        "page_orientation_plan": normalized_orientation,
        "local_quality_notes": list(problem_notes),
        "manual_header_fields": list(state.manual_header_fields),
        "economy_shadow": dict(economy_shadow),
    }
