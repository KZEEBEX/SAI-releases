#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Stable regression tests for the refactored SAI Invoice AI pipeline."""
from __future__ import annotations

import ast
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
os.environ["SAI_USER_DATA_DIR"] = tempfile.mkdtemp(prefix="sai_invoice_pipeline_tests_")
sys.path.insert(0, str(ROOT / "app"))

import sai_invoice_ai_pipeline as pipeline
import sai_invoice_ai_telemetry as telemetry
import sai_openai_invoice as ai

# Module boundaries and compatibility aliases.
assert ai.response_usage is telemetry.response_usage
assert ai.estimate_response_cost_usd is telemetry.estimate_response_cost_usd
assert ai._shadow_page_risk is telemetry.shadow_page_risk
assert ai._summarize_shadow_pages is telemetry.summarize_shadow_pages
assert ai.AI_ECONOMY_TELEMETRY_PATH == telemetry.AI_ECONOMY_TELEMETRY_PATH
state = pipeline.InvoicePipelineState()
state.record_payload({"_sai_precision_views_count": 5, "_sai_precision_views_used": True})
state.add_corrections({2: ["raw_name", "raw_name"], 3: ["quantity"]})
assert state.precision_views_count == 5 and state.primary_precision_used is True
assert state.normalized_corrections() == {"2": ["raw_name"], "3": ["quantity"]}
derived_document = {
    "document_total": 0,
    "items": [{"quantity": 3, "purchase_price": 25, "line_total": 0}],
}
pipeline.restore_document_total(derived_document)
assert derived_document["items"][0]["line_total"] == 75
assert derived_document["document_total"] == 75

source = (ROOT / "app" / "sai_openai_invoice.py").read_text(encoding="utf-8")
tree = ast.parse(source)
analyze = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "analyze_invoice")
assert analyze.end_lineno - analyze.lineno + 1 <= 140, "analyze_invoice снова превратилась в монолит"
for extracted in ("response_usage", "_shadow_page_risk", "_summarize_shadow_pages"):
    assert not any(isinstance(node, ast.FunctionDef) and node.name == extracted for node in tree.body)


def response(data, input_tokens=1000, output_tokens=200):
    return {
        "output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(data, ensure_ascii=False)}]}],
        "usage": {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "total_tokens": input_tokens + output_tokens,
            "input_tokens_details": {"cached_tokens": 0},
        },
    }


def item(row, page, total, name="ТОВАР", barcode="4607136256514", article=None, quantity=1.0):
    return {
        "source_row": row,
        "source_page": page,
        "raw_name": name,
        "name": name,
        "quantity": quantity,
        "unit": "шт",
        "purchase_price": total / max(quantity, 1),
        "line_total": total,
        "article": article if article is not None else f"A{row}",
        "barcodes": ([barcode] if barcode else []),
        "confidence": 0.9,
        "note": "",
    }


def doc(items, total=0.0, supplier="ПОСТАВЩИК", date="2026-07-18", number="AQ-1"):
    return {
        "supplier": supplier,
        "invoice_date": date,
        "invoice_number": number,
        "currency": "RUB",
        "document_total": total,
        "document_total_note": "",
        "items": items,
        "warnings": [],
    }


def run_case(case: str):
    work = Path(tempfile.mkdtemp(prefix=f"sai_aq_{case}_"))
    source_file = work / ("document.xlsx" if case in {"nonvisual", "mismatch", "hard_blocker"} else "page.png")
    source_file.write_bytes(("fixture-" + case).encode("utf-8"))
    source_paths = [source_file]
    if case == "visual_missing":
        # One four-page visual source reproduces the real failure: a successful
        # batch response covered only two pages while its partial total matched.
        orientation = {str(source_file.resolve()): [0, 0, 0, 0]}
    else:
        orientation = None if case == "nonvisual" else {str(source_file.resolve()): [0]}
    calls = []
    original_build = ai.build_request_payload
    original_call = ai.call_openai

    def fake_build(paths, model="", supplier_hint="", date_hint="", invoice_hint="", stage="extract", draft=None,
                   target_rows=None, audit_notes=None, orientation_plan=None, target_global_pages=None):
        return {
            "model": model or ai.DEFAULT_MODEL,
            "_stage": stage,
            "_page": int((target_global_pages or [0])[0]),
            "_target_rows": list(target_rows or []),
            "_sai_precision_views_used": True,
            "_sai_precision_views_count": 5,
        }

    def fake_call(payload, *args, **kwargs):
        stage_name = payload["_stage"]
        calls.append((stage_name, payload["_page"], tuple(payload.get("_target_rows") or [])))
        if case == "nonvisual" and stage_name == "extract":
            return response(doc([item(1, 1, 100)], 0))
        if case == "mismatch":
            if stage_name == "extract":
                return response(doc([item(1, 1, 100)], 125))
            if stage_name in {"repair", "escalate"}:
                return response({
                    "supplier": "ПОСТАВЩИК", "invoice_date": "2026-07-18", "invoice_number": "AQ-1",
                    "document_total": 125, "checked_rows": [1],
                    "rows": [dict(
                        item(1, 1, 100),
                        status="uncertain",
                        uncertain_fields=["document_total"],
                        note="Повреждённый итог документа",
                    )],
                    "warnings": [],
                })
        if case == "hard_blocker":
            if stage_name == "extract":
                return response(doc([item(1, 1, 0)], 125))
            if stage_name in {"repair", "escalate"}:
                return response({
                    "supplier": "ПОСТАВЩИК", "invoice_date": "2026-07-18", "invoice_number": "AQ-1",
                    "document_total": 125, "checked_rows": [1],
                    "rows": [dict(
                        item(1, 1, 0),
                        status="uncertain",
                        uncertain_fields=["line_total", "document_total"],
                        note="Сумма строки не читается",
                    )],
                    "warnings": [],
                })
        if case == "clean" and stage_name == "extract_batch":
            return response(doc([item(1, 1, 100)], 100))
        if case == "visual_missing":
            if stage_name == "extract_batch":
                return response(doc([
                    item(1, 1, 100, name="ТОВАР 1", barcode="4607136256514", article="A1"),
                    item(2, 2, 30, name="ТОВАР 2", barcode="4607136256521", article="A2"),
                ], 130))
            if stage_name == "extract_luna" and payload["_page"] == 1:
                return response(doc([item(1, 1, 100, name="ТОВАР 1")], 200))
            if stage_name == "extract_luna" and payload["_page"] == 2:
                return response(doc([
                    item(2, 2, 30, name="ТОВАР 2", barcode="4607136256521", article="A2"),
                ], 200))
            if stage_name == "extract_luna" and payload["_page"] == 3:
                return response(doc([
                    item(3, 3, 20, name="ТОВАР 3", barcode="4607136256538", article="A3"),
                ], 200))
            if stage_name == "extract_luna" and payload["_page"] == 4:
                return response(doc([
                    item(4, 4, 50, name="ТОВАР 4", barcode="4607136256545", article="A4"),
                ], 200))
        if case == "header":
            if stage_name == "extract_batch":
                return response(doc([item(1, 1, 100)], 100, supplier="", date="", number=""))
            if stage_name == "header_luna":
                return response({"supplier": "ПОСТАВЩИК", "invoice_date": "2026-07-18", "invoice_number": "H-1", "document_total": 100})
        if case == "manual_header":
            if stage_name == "extract_batch":
                return response(doc([item(1, 1, 100)], 100, date="", number=""))
            if stage_name in {"header_luna", "header_terra"}:
                return response({"supplier": "ПОСТАВЩИК", "invoice_date": "", "invoice_number": "", "document_total": 100})
        if case in {"terra", "sol"}:
            if stage_name == "extract_luna":
                return response(doc([item(1, 1, 100, name="ТОВАР А")], 100))
            if stage_name == "extract_luna_verify":
                return response(doc([item(1, 1, 100, name="ТОВАР Б")], 100))
            if stage_name == "repair":
                confirmed = case == "terra"
                return response({
                    "supplier": "ПОСТАВЩИК", "invoice_date": "2026-07-18", "invoice_number": "AQ-1",
                    "document_total": 100, "checked_rows": [1],
                    "rows": [dict(item(1, 1, 100, name="ТОВАР А"), status="verified" if confirmed else "uncertain",
                                  uncertain_fields=[] if confirmed else ["raw_name"], note="" if confirmed else "спорно")],
                    "warnings": [],
                })
            if case == "sol" and stage_name == "escalate":
                return response({
                    "supplier": "ПОСТАВЩИК", "invoice_date": "2026-07-18", "invoice_number": "AQ-1",
                    "document_total": 100, "checked_rows": [1],
                    "rows": [dict(item(1, 1, 100, name="ТОВАР А"), status="verified", uncertain_fields=[], note="")],
                    "warnings": [],
                })
        raise AssertionError((case, payload))

    ai.build_request_payload = fake_build
    ai.call_openai = fake_call
    try:
        result = ai.analyze_invoice(source_paths, "sk-test", orientation_plan=orientation)
    finally:
        ai.build_request_payload = original_build
        ai.call_openai = original_call
    return result, calls


clean, clean_calls = run_case("clean")
assert [call[0] for call in clean_calls] == ["extract_batch"]
assert clean.validation["agent_mode"] == "single_batch_luna_targeted_terra_sol"
assert clean.validation["precision_views_count"] == 5

visual_missing, visual_missing_calls = run_case("visual_missing")
assert [call[0] for call in visual_missing_calls] == [
    "extract_batch", "extract_luna", "extract_luna", "extract_luna", "extract_luna",
], visual_missing_calls
assert len(visual_missing.items) == 4
assert visual_missing.validation["items_total"] == 200
assert [call[1] for call in visual_missing_calls[1:]] == [1, 2, 3, 4]
assert not visual_missing.critical_issues

nonvisual, nonvisual_calls = run_case("nonvisual")
assert [call[0] for call in nonvisual_calls] == ["extract"]
assert nonvisual.validation["document_total"] == 100

mismatch, mismatch_calls = run_case("mismatch")
assert [call[0] for call in mismatch_calls] == ["extract", "repair", "escalate"]
assert mismatch.items and mismatch.critical_issues
assert mismatch.validation["manual_review_required"] is True
assert mismatch.validation["manual_review_accepted"] is False
assert mismatch.validation["manual_review_reasons"]

try:
    run_case("hard_blocker")
except ai.OpenAIInvoiceError as exc:
    assert "нет финальной суммы строки" in str(exc)
else:
    raise AssertionError("missing line total must remain a hard blocker")

header, header_calls = run_case("header")
assert [call[0] for call in header_calls] == ["extract_batch", "header_luna"]
assert header.invoice_number == "H-1"

manual_header, manual_header_calls = run_case("manual_header")
assert [call[0] for call in manual_header_calls] == [
    "extract_batch", "header_luna", "header_terra",
]
assert manual_header.items and not manual_header.date and not manual_header.invoice_number
assert manual_header.validation["manual_header_fields"] == ["invoice_date", "invoice_number"]

print("INVOICE_AI_PIPELINE_TESTS_OK")
