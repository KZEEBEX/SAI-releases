#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Read-only recommendations for the Warehouse analytics screen."""
from __future__ import annotations

import calendar
import datetime as dt
import json
import sqlite3
from typing import Any

from sai_analytics_dataset import build_ai_dataset
from sai_invoice_ai_client import call_openai, extract_output_text
from sai_runtime_paths import CACHE_DIR
from sai_core_v2.sigma_warehouse import history_period_loaded


CACHE_PATH = CACHE_DIR / "sai_analytic_recommendation.json"
MONTH_NAMES = ("Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек")


def _date(value: Any) -> dt.date | None:
    try:
        return dt.date.fromisoformat(str(value or "")[:10])
    except Exception:
        return None


def archive_month_coverage(
    con: sqlite3.Connection, *, year: int = 2026, today: dt.date | None = None,
) -> list[dict[str, Any]]:
    """Return an honest month-by-month view of the resumable sales archive."""
    current = today or dt.date.today()
    periods = con.execute(
        """SELECT period_start, period_end, status, records_count, detail_errors, error
           FROM sigma_history_periods WHERE source='sales' ORDER BY period_start"""
    ).fetchall()
    operation_months = {
        str(row[0]) for row in con.execute(
            """SELECT DISTINCT substr(operation_time, 1, 7) FROM sigma_sale_operations
               WHERE substr(operation_time, 1, 4)=?""", (str(year),),
        ) if row[0]
    }
    result: list[dict[str, Any]] = []
    for month in range(1, 13):
        begin = dt.date(year, month, 1)
        end = dt.date(year, month, calendar.monthrange(year, month)[1])
        if begin > current:
            status, hint = "future", "ещё не наступил"
        else:
            target_end = min(end, current)
            relevant: list[tuple[str, int, int]] = []
            covered: set[dt.date] = set()
            for period_start, period_end, period_status, records, errors, error in periods:
                left, right = _date(period_start), _date(period_end)
                if left is None or right is None or right < begin or left > target_end:
                    continue
                relevant.append((str(period_status), int(records or 0), int(errors or 0)))
                if history_period_loaded(str(period_status), errors, error):
                    cursor = max(left, begin)
                    while cursor <= min(right, target_end):
                        covered.add(cursor)
                        cursor += dt.timedelta(days=1)
            needed = (target_end - begin).days + 1
            statuses = {item[0] for item in relevant}
            key = f"{year:04d}-{month:02d}"
            if len(covered) >= needed:
                status, hint = "complete", "архив готов"
                if target_end < end:
                    hint = f"данные загружены по {target_end:%d.%m}; текущий месяц будет обновляться"
            elif "error" in statuses:
                status, hint = "error", "есть ошибка загрузки"
            elif relevant or key in operation_months:
                status, hint = "partial", "данные неполные"
            else:
                status, hint = "missing", "нет архива"
        result.append({"month": month, "label": MONTH_NAMES[month - 1], "status": status, "hint": hint})
    return result


def local_recommendation(
    con: sqlite3.Connection, *, location_id: str, coverage: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    coverage = coverage or archive_month_coverage(con)
    current_month = dt.date.today().month
    gaps = [item for item in coverage if item["month"] < current_month and item["status"] in {"missing", "partial", "error"}]
    if gaps:
        groups: list[list[dict[str, Any]]] = []
        for item in gaps:
            if groups and int(item["month"]) == int(groups[-1][-1]["month"]) + 1:
                groups[-1].append(item)
            else:
                groups.append([item])
        months = ", ".join(
            str(group[0]["label"]).lower() if len(group) == 1
            else f"{str(group[0]['label']).lower()}–{str(group[-1]['label']).lower()}"
            for group in groups
        )
        return {
            "level": "warning", "badge": "ДАННЫЕ НЕПОЛНЫЕ",
            "title": f"Докачайте архив: {months}",
            "why": "Без этих месяцев SAI видит тренды кусками и может ошибиться в прогнозе спроса и сезонности. Уже загруженные периоды повторно не скачаются.",
            "actions": ["Нажмите «Докачать архив»", "После загрузки запустите анализ ещё раз"],
            "source": "local",
        }
    row = con.execute("SELECT COUNT(*) FROM sigma_stock_current WHERE location_id=? AND CAST(quantity AS REAL)>0", (location_id,)).fetchone()
    stock_count = int(row[0] or 0) if row else 0
    return {
        "level": "ready", "badge": "ГОТОВО К АНАЛИЗУ",
        "title": "Данные готовы — найдём главное действие для магазина",
        "why": f"SAI видит продажи и текущие остатки по {stock_count} позициям.",
        "actions": ["Нажмите «Провести анализ»"], "source": "local",
    }


def recommendation_revision(con: sqlite3.Connection, location_id: str) -> list:
    periods = con.execute("SELECT COUNT(*), COALESCE(MAX(updated_at), '') FROM sigma_history_periods").fetchone()
    stock = con.execute("SELECT COUNT(*), COALESCE(MAX(captured_at), '') FROM sigma_stock_current WHERE location_id=?", (location_id,)).fetchone()
    return [str(location_id), list(periods), list(stock), dt.date.today().isoformat()]


def load_cached_recommendation(con: sqlite3.Connection | None = None, location_id: str = "") -> dict[str, Any] | None:
    try:
        value = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return None
        if con is not None and value.get("data_revision") != recommendation_revision(con, location_id):
            return None
        return value
    except Exception:
        return None


def run_ai_analysis(
    con: sqlite3.Connection, *, location_id: str, api_key: str, model: str,
    api_base: str, proxy_url: str = "",
) -> dict[str, Any]:
    revision = recommendation_revision(con, location_id)
    dataset = build_ai_dataset(con, location_id=location_id, product_limit=120)
    compact = {
        "period": dataset["period"], "coverage": dataset["coverage"], "totals": dataset["totals"],
        "monthly": dataset["monthly"], "data_quality": dataset["data_quality"], "top_products": dataset["products"][:80],
    }
    schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "level": {"type": "string", "enum": ["info", "warning", "urgent"]},
            "badge": {"type": "string"}, "title": {"type": "string"}, "why": {"type": "string"},
            "actions": {"type": "array", "items": {"type": "string"}, "maxItems": 3},
            "confidence": {"type": "string", "enum": ["low", "medium", "high"]},
        },
        "required": ["level", "badge", "title", "why", "actions", "confidence"],
    }
    prompt = (
        "Ты SAI Analytic — аналитик небольшого хозяйственного магазина. Выбери ровно одно самое важное безопасное действие на ближайшие 7 дней. "
        "Опирайся только на JSON ниже, не выдумывай товары, причины или числа. Учитывай неполноту архива и качество данных. "
        "Если данных недостаточно, главным действием назначь улучшение данных. Не предлагай автоматически менять SIGMA. Пиши по-русски, коротко и конкретно.\n\n"
        + json.dumps(compact, ensure_ascii=False, separators=(",", ":"))
    )
    response = call_openai({
        "model": model, "store": False, "reasoning": {"effort": "low"}, "max_output_tokens": 900,
        "input": [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}],
        "text": {"verbosity": "low", "format": {"type": "json_schema", "name": "sai_store_recommendation", "strict": True, "schema": schema}},
    }, api_key, api_base, proxy_url, timeout=90)
    result = json.loads(extract_output_text(response))
    result.update({"source": "ai", "generated_at": dt.datetime.now().astimezone().isoformat(), "model": model, "data_revision": revision})
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temporary = CACHE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(CACHE_PATH)
    return result
