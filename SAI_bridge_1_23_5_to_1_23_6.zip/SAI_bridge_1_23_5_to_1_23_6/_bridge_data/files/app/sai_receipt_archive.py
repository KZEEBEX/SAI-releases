#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Permanent, user-visible archive for successfully completed SAI receipts."""
from __future__ import annotations

import datetime as dt
import json
import re
import shutil
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Iterable, List, Optional

import sai_db
import sai_package
from sai_runtime_paths import USER_DATA_DIR, ensure_runtime_dirs

ARCHIVE_ROOT = USER_DATA_DIR / "История приходов"

KIND_DIRS = {
    "sai": "01_SAI",
    "source": "02_Входные_накладные",
    "approval_preview": "03_Согласование",
    "approval_final": "03_Согласование",
    "ndp": "04_НДП",
    "price_tags": "05_Ценники",
    "service_log": "99_Служебные",
    "price_audit": "99_Служебные",
}

KIND_LABELS = {
    "sai": "SAI-файл",
    "source": "Входная накладная",
    "approval_preview": "Накладная на согласование",
    "approval_final": "Согласованная накладная",
    "ndp": "НДП",
    "price_tags": "Ценники",
    "service_log": "Журнал ввода",
    "price_audit": "Проверка цен",
}


def safe_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def safe_component(value: Any, fallback: str = "Без названия", limit: int = 80) -> str:
    text = safe_text(value) or fallback
    text = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", text)
    text = re.sub(r"\s+", " ", text).strip(" ._")
    return (text or fallback)[:limit].rstrip(" ._")


def normalize_date(value: Any) -> str:
    text = safe_text(value)
    if not text:
        return dt.date.today().isoformat()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y", "%Y.%m.%d"):
        try:
            return dt.datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    m = re.search(r"(\d{2})[.\-_](\d{2})[.\-_](\d{4}|\d{2})", text)
    if m:
        d, mo, y = m.groups()
        if len(y) == 2:
            y = "20" + y
        try:
            return dt.date(int(y), int(mo), int(d)).isoformat()
        except ValueError:
            pass
    return dt.date.today().isoformat()


def archive_dir_for_run(run: dict[str, Any]) -> Path:
    existing = Path(safe_text(run.get("archive_dir"))) if safe_text(run.get("archive_dir")) else None
    if existing and existing.exists():
        return existing
    date_iso = normalize_date(run.get("invoice_date"))
    supplier = safe_component(run.get("supplier_name"), "Без поставщика", 70)
    waybill = safe_component(run.get("waybill_id"), f"receipt-{run.get('id')}", 24)
    folder = f"{date_iso} — {supplier} — {waybill[:12]} — #{int(run.get('id') or 0):05d}"
    path = ARCHIVE_ROOT / date_iso[:4] / safe_component(folder, "Приход")
    path.mkdir(parents=True, exist_ok=True)
    sai_db.update_apply_archive_dir(int(run["id"]), str(path))
    return path


def _unique_target(folder: Path, name: str) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    name = safe_component(Path(name).stem, "Файл", 110) + Path(name).suffix
    target = folder / name
    index = 2
    while target.exists():
        target = folder / f"{Path(name).stem}_{index}{Path(name).suffix}"
        index += 1
    return target


def _copy_file(apply_run_id: int, kind: str, source: Path, replace_kind: bool = False) -> Optional[Path]:
    source = Path(source)
    if not source.is_file():
        return None
    run = sai_db.get_apply_run(apply_run_id)
    if not run:
        raise RuntimeError(f"Не найдена запись прихода #{apply_run_id}.")
    root = archive_dir_for_run(run)
    subdir = root / KIND_DIRS.get(kind, "90_Прочее")

    # Avoid duplicate copies of the exact same already-archived source.
    all_existing = sai_db.receipt_files(apply_run_id)
    try:
        source_resolved = source.resolve()
        for item in all_existing:
            archived = Path(safe_text(item.get("archived_path")))
            if archived.exists() and archived.resolve() == source_resolved:
                return archived
    except Exception:
        pass

    # One current SAI/NDP/price-tags artifact per receipt. Source invoices remain plural.
    existing = [r for r in all_existing if r.get("kind") == kind]
    if replace_kind and existing:
        for item in existing:
            try:
                Path(safe_text(item.get("archived_path"))).unlink(missing_ok=True)
            except Exception:
                pass
        # Database rows are kept only if a copy survives. Delete stale entries directly.
        try:
            with sai_db.connect() as con:
                con.execute("DELETE FROM receipt_files WHERE apply_run_id=? AND kind=?", (int(apply_run_id), kind))
                con.commit()
        except Exception:
            pass

    target = _unique_target(subdir, source.name)
    shutil.copy2(source, target)
    sai_db.register_receipt_file(
        apply_run_id,
        kind,
        source.name,
        target.name,
        str(target),
        target.stat().st_size,
    )
    write_manifest(apply_run_id)
    return target


def sidecar_path(sai_path: Path) -> Path:
    return sai_path.with_name(sai_path.stem + ".sources.json")


def write_source_sidecar(sai_path: Path, source_paths: Iterable[Path]) -> Optional[Path]:
    sai_path = Path(sai_path)
    paths = []
    for value in source_paths or []:
        p = Path(value)
        if p.is_file():
            paths.append(str(p.resolve()))
    if not paths:
        return None
    sidecar = sidecar_path(sai_path)
    sidecar.write_text(json.dumps({"source_files": paths}, ensure_ascii=False, indent=2), encoding="utf-8")
    return sidecar


def discover_source_documents(sai_path: Path) -> List[Path]:
    """Find original invoice files linked to a SAI document.

    Current local converter writes a .sources.json sidecar. Older XML files may only
    contain <source_file>; in that case we resolve the name next to the SAI file.
    """
    sai_path = Path(sai_path)
    found: List[Path] = []
    sidecars = [sidecar_path(sai_path), sai_path.with_suffix(sai_path.suffix + ".sources.json")]
    for sidecar in sidecars:
        if not sidecar.is_file():
            continue
        try:
            data = json.loads(sidecar.read_text(encoding="utf-8-sig"))
            values = data.get("source_files") if isinstance(data, dict) else data
            for value in values or []:
                p = Path(safe_text(value))
                if not p.is_absolute():
                    p = sai_path.parent / p
                if p.is_file():
                    found.append(p)
        except Exception:
            pass

    if sai_path.suffix.lower() == ".xml" and sai_path.is_file():
        try:
            root = ET.parse(sai_path).getroot()
            values = []
            for tag in ("source_file", "source_document", "source_path"):
                values.extend([safe_text(el.text) for el in root.findall(f"./meta/{tag}") if safe_text(el.text)])
            for parent in root.findall("./meta/source_files"):
                values.extend([safe_text(el.text) for el in list(parent) if safe_text(el.text)])
            for value in values:
                p = Path(value)
                if not p.is_absolute():
                    p = sai_path.parent / p
                if p.is_file():
                    found.append(p)
        except Exception:
            pass

    unique: List[Path] = []
    seen = set()
    try:
        sai_resolved = sai_path.resolve()
    except Exception:
        sai_resolved = sai_path
    for p in found:
        try:
            key = str(p.resolve()).lower()
            if p.resolve() == sai_resolved:
                continue
        except Exception:
            key = str(p).lower()
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def archive_successful_receipt(
    apply_run_id: int,
    sai_path: Path,
    extra_source_paths: Optional[Iterable[Path]] = None,
    approval_preview_path: Optional[Path] = None,
    approval_final_path: Optional[Path] = None,
    log_path: Optional[Path] = None,
    audit_path: Optional[Path] = None,
) -> Path:
    run = sai_db.get_apply_run(apply_run_id)
    if not run:
        raise RuntimeError(f"Не найдена запись прихода #{apply_run_id}.")
    root = archive_dir_for_run(run)
    _copy_file(apply_run_id, "sai", Path(sai_path), replace_kind=True)
    sources = discover_source_documents(Path(sai_path))
    sources.extend([Path(x) for x in (extra_source_paths or []) if Path(x).is_file()])
    temp_context = None
    if Path(sai_path).suffix.lower() == ".sai":
        try:
            temp_context = tempfile.TemporaryDirectory(prefix="sai_package_sources_")
            sources.extend(sai_package.extract_sources(Path(sai_path), Path(temp_context.name)))
        except Exception:
            if temp_context is not None:
                temp_context.cleanup()
                temp_context = None
    try:
        seen = set()
        for source in sources:
            try:
                key = str(source.resolve()).lower()
            except Exception:
                key = str(source).lower()
            if key in seen:
                continue
            seen.add(key)
            _copy_file(apply_run_id, "source", source, replace_kind=False)
    finally:
        if temp_context is not None:
            temp_context.cleanup()
    if approval_preview_path:
        _copy_file(apply_run_id, "approval_preview", Path(approval_preview_path), replace_kind=True)
    if approval_final_path:
        _copy_file(apply_run_id, "approval_final", Path(approval_final_path), replace_kind=True)
    if log_path:
        _copy_file(apply_run_id, "service_log", Path(log_path), replace_kind=True)
    if audit_path:
        _copy_file(apply_run_id, "price_audit", Path(audit_path), replace_kind=True)
    write_manifest(apply_run_id)
    return root


def archive_generated_document(apply_run_id: int, kind: str, path: Path) -> Optional[Path]:
    return _copy_file(apply_run_id, kind, Path(path), replace_kind=kind in {"sai", "approval_preview", "approval_final", "ndp", "price_tags", "service_log", "price_audit"})


def add_source_documents(apply_run_id: int, paths: Iterable[Path]) -> List[Path]:
    copied: List[Path] = []
    for path in paths or []:
        result = _copy_file(apply_run_id, "source", Path(path), replace_kind=False)
        if result:
            copied.append(result)
    return copied


def write_manifest(apply_run_id: int) -> Optional[Path]:
    run = sai_db.get_apply_run(apply_run_id)
    if not run:
        return None
    root = archive_dir_for_run(run)
    files = []
    for item in sai_db.receipt_files(apply_run_id):
        files.append({
            "kind": item.get("kind"),
            "label": KIND_LABELS.get(safe_text(item.get("kind")), safe_text(item.get("kind"))),
            "original_name": item.get("original_name"),
            "stored_name": item.get("stored_name"),
            "path": item.get("archived_path"),
            "size": item.get("file_size"),
        })
    data = {
        "apply_run_id": int(apply_run_id),
        "supplier_sigma": run.get("supplier_name"),
        "invoice_date": run.get("invoice_date"),
        "waybill_id": run.get("waybill_id"),
        "positions": int(run.get("ok_count") or 0),
        "total_quantity": float(run.get("total_quantity") or 0),
        "buying_total": float(run.get("buying_total") or 0),
        "selling_total": float(run.get("selling_total") or 0),
        "created_at": run.get("created_at"),
        "files": files,
    }
    manifest = root / "Приход.json"
    manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def delete_receipt_archive(apply_run_id: int) -> None:
    run = sai_db.get_apply_run(apply_run_id)
    if not run:
        return
    archive_dir = Path(safe_text(run.get("archive_dir"))) if safe_text(run.get("archive_dir")) else None
    if archive_dir and archive_dir.exists():
        shutil.rmtree(archive_dir)
        year_dir = archive_dir.parent
        try:
            if year_dir != ARCHIVE_ROOT and year_dir.exists() and not any(year_dir.iterdir()):
                year_dir.rmdir()
        except Exception:
            pass


def ensure_legacy_archive(apply_run_id: int) -> Optional[Path]:
    """Backfill whatever is still available for older successful receipt rows."""
    run = sai_db.get_apply_run(apply_run_id)
    if not run or safe_text(run.get("status")) != "ok" or int(run.get("error_count") or 0) != 0:
        return None
    archive_dir = safe_text(run.get("archive_dir"))
    if archive_dir and Path(archive_dir).exists():
        return Path(archive_dir)
    sai_path = Path(safe_text(run.get("sai_path")))
    if not sai_path.is_file():
        return None
    return archive_successful_receipt(
        apply_run_id,
        sai_path,
        log_path=Path(safe_text(run.get("log_path"))) if safe_text(run.get("log_path")) else None,
        audit_path=Path(safe_text(run.get("audit_path"))) if safe_text(run.get("audit_path")) else None,
    )
