#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Focused two-computer test for Yandex Disk folder synchronization."""
from __future__ import annotations

import csv
import json
import os
import tempfile
from pathlib import Path


def check(value, message):
    if not value:
        raise AssertionError(message)


def write_apply_log(path: Path) -> None:
    fields = [
        "status", "quantity", "buying_price", "final_selling_price", "incoming_selling_price",
        "product_id", "barcode", "used_barcode", "name", "sigma_existing_selling_price", "price_source",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter=";")
        writer.writeheader()
        writer.writerow({
            "status": "OK", "quantity": "2", "buying_price": "50", "final_selling_price": "75",
            "incoming_selling_price": "75", "product_id": "p1", "barcode": "460000000001",
            "used_barcode": "460000000001", "name": "ТЕСТОВЫЙ ТОВАР", "price_source": "incoming",
        })


def load_modules(user_data: Path):
    os.environ["SAI_USER_DATA_DIR"] = str(user_data)
    import importlib
    import sai_runtime_paths
    import sai_db
    import sai_receipt_drafts
    import sai_organization_sync
    importlib.reload(sai_runtime_paths)
    importlib.reload(sai_db)
    importlib.reload(sai_receipt_drafts)
    importlib.reload(sai_organization_sync)
    return sai_db, sai_organization_sync, sai_receipt_drafts


def create_draft(drafts, draft_id: str = "receipt_shared_test") -> None:
    folder = drafts.DRAFTS_DIR / draft_id
    folder.mkdir(parents=True, exist_ok=True)
    package = folder / "receipt.sai"
    package.write_bytes(b"SHARED DRAFT")
    (folder / "draft.json").write_text(json.dumps({
        "id": draft_id,
        "kind": "ai",
        "status": "active",
        "stage": "ai_review",
        "stage_label": "Проверка",
        "package_path": str(package),
        "supplier": "ЧЕРНОВИК ПОСТАВЩИКА",
        "item_count": 3,
        "created_at": "2026-08-07 12:00:00",
        "updated_at": "2026-08-07 12:00:00",
    }, ensure_ascii=False), encoding="utf-8")


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="sai_org_sync_") as tmp:
        root = Path(tmp)
        shared = root / "YandexDisk" / "SAI Organization"
        db_a, sync_a, drafts_a = load_modules(root / "pc-a")
        create_draft(drafts_a)
        drafts_a.register_manual_autosave({
            "supplier_name": "РУЧНОЙ ЧЕРНОВИК",
            "date": "2026-08-07",
            "rows": [{"name": "ТОВАР", "qty": 2, "buy": 10, "barcodes": ["460000000002"]}],
            "current_card": {},
        })
        log = root / "apply.csv"
        write_apply_log(log)
        info = db_a.record_apply_log(log, supplier_name="ПОСТАВЩИК", invoice_date="2026-08-07", app_version="v-test")
        archive = root / "receipt.sai"
        archive.write_bytes(b"SAI TEST")
        db_a.register_receipt_file(info["apply_run_id"], "sai", archive.name, archive.name, str(archive), archive.stat().st_size)
        settings_a = sync_a.SyncSettings(True, shared, "Тест", "pc-a", "Компьютер A")
        report_a = sync_a.sync_once(settings_a, "v-test")
        check(report_a.ok and report_a.exported_receipts == 1, report_a.message)
        check(report_a.published_drafts == 2, "Drafts were not published by PC A")

        db_b, sync_b, drafts_b = load_modules(root / "pc-b")
        settings_b = sync_b.SyncSettings(True, shared, "Тест", "pc-b", "Компьютер B")
        report_b = sync_b.sync_once(settings_b, "v-test")
        check(report_b.ok and report_b.imported_receipts == 1, report_b.message)
        check(report_b.imported_drafts == 2, "Drafts were not imported by PC B")
        imported_draft = drafts_b.get("receipt_shared_test") or {}
        check(imported_draft.get("supplier") == "ЧЕРНОВИК ПОСТАВЩИКА", str(imported_draft))
        check(Path(imported_draft.get("package_path") or "").is_file(), "Imported draft package is missing")
        manual_draft = drafts_b.get("manual_current") or {}
        check(manual_draft.get("supplier") == "РУЧНОЙ ЧЕРНОВИК", str(manual_draft))
        check(drafts_b.MANUAL_AUTOSAVE.is_file(), "Manual draft payload is missing")
        rows = db_b.successful_apply_runs()
        check(len(rows) == 1 and rows[0]["supplier_name"] == "ПОСТАВЩИК", str(rows))
        check(len(db_b.get_apply_items(int(rows[0]["id"]))) == 1, "Receipt items were not imported")
        check(len(db_b.receipt_files(int(rows[0]["id"]))) == 1, "Receipt files were not imported")
        again = sync_b.sync_once(settings_b, "v-test")
        check(again.imported_receipts == 0, "Repeated sync duplicated history")
        check(again.imported_drafts == 0, "Repeated sync duplicated a draft")

        drafts_b.update("receipt_shared_test", supplier="ИЗМЕНЕНО НА КОМПЬЮТЕРЕ B")
        changed_b = sync_b.sync_once(settings_b, "v-test")
        check(changed_b.published_drafts == 1, "Changed draft was not published by PC B")
        _, sync_a, drafts_a = load_modules(root / "pc-a")
        changed_a = sync_a.sync_once(settings_a, "v-test")
        check(changed_a.imported_drafts == 1, "Changed draft was not returned to PC A")
        check(
            (drafts_a.get("receipt_shared_test") or {}).get("supplier") == "ИЗМЕНЕНО НА КОМПЬЮТЕРЕ B",
            "PC A did not receive the latest draft revision",
        )

        _, sync_b, drafts_b = load_modules(root / "pc-b")
        drafts_b.remove("receipt_shared_test")
        deleted_b = sync_b.sync_once(settings_b, "v-test")
        check(deleted_b.published_drafts == 1, "Draft deletion was not published")
        _, sync_a, drafts_a = load_modules(root / "pc-a")
        deleted_a = sync_a.sync_once(settings_a, "v-test")
        check(deleted_a.imported_drafts == 1, "Draft deletion was not imported")
        check(drafts_a.get("receipt_shared_test") is None, "Deleted draft was resurrected")
        package = shared / "updates" / "INSTALL.cmd"
        package.parent.mkdir(parents=True, exist_ok=True)
        package.write_text("@echo off\r\n", encoding="ascii")
        (package.parent / "latest.json").write_text(
            '{"version":"1.22.7zz","package":"INSTALL.cmd"}', encoding="utf-8"
        )
        update_report = sync_b.sync_once(settings_b, "1.22.7dp")
        check(update_report.available_version == "1.22.7zz", "New organization update was not detected")
        check(sync_b.update_package(settings_b) == package, "Update package was not resolved")
    print("SAI organization sync tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
