#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Versioned prompts and strict JSON schemas for SAI invoice AI."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict

from sai_invoice_ai_errors import OpenAIInvoiceError
from sai_runtime_paths import ROOT_DIR

AI_CONFIG_DIR = ROOT_DIR / "config" / "ai"
PROMPT_PATH = AI_CONFIG_DIR / "invoice_prompt_v13.txt"
AUDIT_PROMPT_PATH = AI_CONFIG_DIR / "invoice_audit_prompt_v7.txt"
HEADER_PROMPT_PATH = AI_CONFIG_DIR / "invoice_header_prompt_v1.txt"
ARBITRATE_PROMPT_PATH = AI_CONFIG_DIR / "invoice_arbitrate_prompt_v1.txt"
SCHEMA_PATH = AI_CONFIG_DIR / "invoice_schema_v6.json"
AUDIT_SCHEMA_PATH = AI_CONFIG_DIR / "invoice_audit_schema_v5.json"
HEADER_SCHEMA_PATH = AI_CONFIG_DIR / "invoice_header_schema_v1.json"
PROMPT_VERSION = "invoice_prompt_v13"
AUDIT_PROMPT_VERSION = "invoice_audit_prompt_v7"
HEADER_PROMPT_VERSION = "invoice_header_prompt_v1"
ARBITRATE_PROMPT_VERSION = "invoice_arbitrate_prompt_v1"
SCHEMA_VERSION = "invoice_schema_v6"
AUDIT_SCHEMA_VERSION = "invoice_audit_schema_v5"
HEADER_SCHEMA_VERSION = "invoice_header_schema_v1"
CONTRACT_VERSION = "invoice_ai_contract_v15"
OPERATOR_HINTS_TOKEN = "{{OPERATOR_HINTS}}"

_OPENAI_UNSUPPORTED_SCHEMA_KEYWORDS = {
    "uniqueItems", "allOf", "not", "dependentRequired", "dependentSchemas",
    "if", "then", "else",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_required_text(path: Path, label: str) -> str:
    try:
        text = path.read_text(encoding="utf-8-sig")
    except FileNotFoundError as exc:
        raise OpenAIInvoiceError(
            f"Не найден {label}: {path}. Переустанови актуальный патч SAI."
        ) from exc
    except Exception as exc:
        raise OpenAIInvoiceError(f"Не удалось прочитать {label}: {path}: {exc}") from exc
    if not text.strip():
        raise OpenAIInvoiceError(f"{label.capitalize()} пуст: {path}")
    return text


def assert_openai_schema_compatible(schema: Any, label: str) -> None:
    """Fail locally before a paid request when strict JSON Schema is incompatible."""
    found = []

    def walk(value: Any, path: str) -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                child_path = f"{path}.{key}" if path else key
                if key in _OPENAI_UNSUPPORTED_SCHEMA_KEYWORDS:
                    found.append(child_path)
                walk(child, child_path)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, f"{path}[{index}]")

    walk(schema, "")
    if found:
        raise OpenAIInvoiceError(
            f"{label} содержит неподдерживаемые OpenAI поля JSON Schema: " + ", ".join(found)
        )


def load_invoice_schema() -> Dict[str, Any]:
    try:
        schema = json.loads(read_required_text(SCHEMA_PATH, "JSON-схема AI"))
    except Exception as exc:
        raise OpenAIInvoiceError(f"JSON-схема AI повреждена: {SCHEMA_PATH}") from exc
    assert_openai_schema_compatible(schema, "JSON-схема AI")
    required = set(schema.get("required") or [])
    if schema.get("type") != "object" or not {
        "supplier", "invoice_date", "invoice_number", "document_total", "items"
    }.issubset(required):
        raise OpenAIInvoiceError("JSON-схема AI не содержит обязательные поля накладной.")
    item_required = set(schema["properties"]["items"]["items"].get("required") or [])
    if not {
        "source_row", "source_page", "raw_name", "article", "barcodes", "line_total"
    }.issubset(item_required):
        raise OpenAIInvoiceError("JSON-схема AI не требует критические поля строки.")
    return schema


def load_audit_schema() -> Dict[str, Any]:
    try:
        schema = json.loads(read_required_text(AUDIT_SCHEMA_PATH, "JSON-схема проверки AI"))
    except Exception as exc:
        raise OpenAIInvoiceError(
            f"JSON-схема проверки AI повреждена: {AUDIT_SCHEMA_PATH}"
        ) from exc
    assert_openai_schema_compatible(schema, "JSON-схема проверки AI")
    required = set(schema.get("required") or [])
    if schema.get("type") != "object" or not {
        "supplier", "invoice_date", "invoice_number", "document_total", "checked_rows", "rows"
    }.issubset(required):
        raise OpenAIInvoiceError("JSON-схема проверки AI имеет неправильную структуру.")
    return schema


def load_header_schema() -> Dict[str, Any]:
    try:
        schema = json.loads(read_required_text(HEADER_SCHEMA_PATH, "JSON-схема реквизитов AI"))
    except Exception as exc:
        raise OpenAIInvoiceError(
            f"JSON-схема реквизитов AI повреждена: {HEADER_SCHEMA_PATH}"
        ) from exc
    assert_openai_schema_compatible(schema, "JSON-схема реквизитов AI")
    required = set(schema.get("required") or [])
    if schema.get("type") != "object" or not {
        "supplier", "invoice_date", "invoice_number", "document_total"
    }.issubset(required):
        raise OpenAIInvoiceError("JSON-схема реквизитов AI имеет неправильную структуру.")
    return schema


def load_prompt(path: Path, marker: str) -> str:
    text = read_required_text(path, "файл задания AI")
    if marker not in text or OPERATOR_HINTS_TOKEN not in text:
        raise OpenAIInvoiceError(f"Файл задания AI имеет неизвестную версию: {path}")
    return text


def invoice_contract_metadata() -> Dict[str, str]:
    load_invoice_schema()
    load_audit_schema()
    load_header_schema()
    load_prompt(PROMPT_PATH, f"SAI_INVOICE_PROMPT_VERSION: {PROMPT_VERSION}")
    load_prompt(AUDIT_PROMPT_PATH, f"SAI_INVOICE_AUDIT_PROMPT_VERSION: {AUDIT_PROMPT_VERSION}")
    load_prompt(HEADER_PROMPT_PATH, f"SAI_INVOICE_HEADER_PROMPT_VERSION: {HEADER_PROMPT_VERSION}")
    return {
        "contract_version": CONTRACT_VERSION,
        "prompt_version": PROMPT_VERSION,
        "prompt_sha256": sha256_file(PROMPT_PATH),
        "audit_prompt_version": AUDIT_PROMPT_VERSION,
        "audit_prompt_sha256": sha256_file(AUDIT_PROMPT_PATH),
        "header_prompt_version": HEADER_PROMPT_VERSION,
        "header_prompt_sha256": sha256_file(HEADER_PROMPT_PATH),
        "schema_version": SCHEMA_VERSION,
        "schema_sha256": sha256_file(SCHEMA_PATH),
        "audit_schema_version": AUDIT_SCHEMA_VERSION,
        "audit_schema_sha256": sha256_file(AUDIT_SCHEMA_PATH),
        "header_schema_version": HEADER_SCHEMA_VERSION,
        "header_schema_sha256": sha256_file(HEADER_SCHEMA_PATH),
    }


def operator_hints(supplier_hint: str, date_hint: str, invoice_hint: str) -> str:
    hints = []
    if supplier_hint:
        hints.append(f"Поставщик, указанный оператором: {supplier_hint}")
    if date_hint:
        hints.append(f"Дата, указанная оператором: {date_hint}")
    if invoice_hint:
        hints.append(f"Номер документа, указанный оператором: {invoice_hint}")
    return "\n".join(hints) if hints else "Оператор не указал подсказки."


def instruction_text(stage: str, supplier_hint: str, date_hint: str, invoice_hint: str) -> str:
    path, marker = {
        "extract": (PROMPT_PATH, f"SAI_INVOICE_PROMPT_VERSION: {PROMPT_VERSION}"),
        "audit": (AUDIT_PROMPT_PATH, f"SAI_INVOICE_AUDIT_PROMPT_VERSION: {AUDIT_PROMPT_VERSION}"),
        "repair": (AUDIT_PROMPT_PATH, f"SAI_INVOICE_AUDIT_PROMPT_VERSION: {AUDIT_PROMPT_VERSION}"),
        "escalate": (AUDIT_PROMPT_PATH, f"SAI_INVOICE_AUDIT_PROMPT_VERSION: {AUDIT_PROMPT_VERSION}"),
        "header": (HEADER_PROMPT_PATH, f"SAI_INVOICE_HEADER_PROMPT_VERSION: {HEADER_PROMPT_VERSION}"),
        "arbitrate": (
            ARBITRATE_PROMPT_PATH,
            f"SAI_INVOICE_ARBITRATE_PROMPT_VERSION: {ARBITRATE_PROMPT_VERSION}",
        ),
    }[stage]
    return load_prompt(path, marker).replace(
        OPERATOR_HINTS_TOKEN,
        operator_hints(supplier_hint, date_hint, invoice_hint),
    )
