#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
SIGMA Autoprihod MVP.

Reads Excel sheet "Для робота SIGMA" and fills an existing SIGMA INCOME draft.
Safe by default: without --apply it is dry-run only.
"""

import argparse
import json
import csv
import datetime as dt
import math
import re
import sys

# SAI_FORCE_UTF8_STDIO
# Windows on some PCs can run Python with cp1252/cp1251 stdout even when GUI reads UTF-8.
# Force UTF-8 so Cyrillic paths/messages do not crash print().
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# SAI_PRINT_ALWAYS_FLUSH
# When bot is run through GUI pipe, force every print to flush immediately.
try:
    _sai_original_print = print
    def print(*args, **kwargs):
        kwargs.setdefault("flush", True)
        return _sai_original_print(*args, **kwargs)
except Exception:
    pass
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from sai_runtime_paths import CACHE_DIR, LOGS_DIR, PROFILE_DIR
import sai_package
from sai_core import (
    extract_barcode_candidates,
    choose_selling_price as core_choose_selling_price,
    price_source_label as core_price_source_label,
    classify_barcode,
)

from openpyxl import load_workbook
from playwright.sync_api import sync_playwright
import requests

from sai_direct_network import configure_direct_network, direct_chromium_args

configure_direct_network()


DEFAULT_API_BASE = "https://api-s07.sigma.ru"
DEFAULT_CLOUD_URL = "https://cloud.sigma.ru"


def normalize_sigma_login(value: Any) -> str:
    """Canonical ATOL ID phone: eleven digits beginning with 7."""
    digits = re.sub(r"\D+", "", str(value or "").strip())
    if len(digits) == 11 and digits.startswith("8"):
        digits = "7" + digits[1:]
    return digits


def sigma_backend_login(value: Any) -> str:
    """OAuth password grant expects the same Russian phone in +7 form."""
    digits = normalize_sigma_login(value)
    if len(digits) == 11 and digits.startswith("7"):
        return "+7" + digits[1:]
    return digits


def norm_header(value: Any) -> str:
    return str(value or "").strip().upper().replace("Ё", "Е")


def to_float(value: Any, field_name: str, row_num: int) -> float:
    if value is None or value == "":
        raise ValueError(f"row {row_num}: field '{field_name}' is empty")
    if isinstance(value, (int, float)):
        if isinstance(value, float) and math.isnan(value):
            raise ValueError(f"row {row_num}: field '{field_name}' is empty")
        return float(value)
    s = str(value).strip().replace("\xa0", "").replace(" ", "").replace(",", ".")
    return float(s)


def clean_barcode(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return str(value).strip()
    return str(value).strip().replace(" ", "")


def split_barcode_candidates(value: Any) -> List[str]:
    """
    One Excel cell can contain several barcodes:
    4602807596395,4602807783825,4602807595961

    Try them one by one and use the first product found in SIGMA.
    """
    raw = clean_barcode(value)
    if not raw:
        return []

    return extract_barcode_candidates(raw)


def normalize_waybill_id(value: str) -> str:
    """
    Accept either a bare SIGMA waybill UUID or the full URL:
    https://cloud.sigma.ru/documents/INCOME/one?id=<UUID>
    """
    s = str(value or "").strip().strip('"').strip("'")
    if not s:
        raise SystemExit("waybillId is empty.")

    m = re.search(r"[?&]id=([a-fA-F0-9-]{20,})", s)
    if m:
        s = m.group(1)

    # If user pasted something like id=<UUID>
    m = re.search(r"\bid=([a-fA-F0-9-]{20,})", s)
    if m:
        s = m.group(1)

    s = s.strip()
    if not re.match(r"^[a-fA-F0-9-]{20,}$", s):
        raise SystemExit(f"Invalid waybillId or URL: {value}")

    return s



def read_xml_rows(path: str) -> List[Dict[str, Any]]:
    """Read SAI XML v1.0 and return rows in the same shape as Excel reader."""
    try:
        tree = ET.parse(str(path))
    except ET.ParseError as exc:
        raise SystemExit(f"SAI XML is invalid: {exc}")
    root = tree.getroot()
    if root.tag != "sai_receipt":
        raise SystemExit("SAI XML root must be <sai_receipt>.")
    items = root.find("items")
    if items is None:
        raise SystemExit("SAI XML: <items> section not found.")
    rows: List[Dict[str, Any]] = []
    for idx, item in enumerate(items.findall("item"), start=1):
        def text(tag: str) -> str:
            el = item.find(tag)
            return str(el.text or "").strip() if el is not None else ""
        barcodes = []
        barcodes_el = item.find("barcodes")
        if barcodes_el is not None:
            for bc in barcodes_el.findall("barcode"):
                raw = str(bc.text or "").strip()
                if raw:
                    cleaned = re.sub(r"\D+", "", raw)
                    if cleaned:
                        barcodes.append(cleaned)
        barcode = ", ".join(barcodes)
        if not barcode:
            continue
        rows.append({
            "excel_row": idx + 1,
            "barcode": barcode,
            "quantity": to_float(text("quantity"), "quantity", idx),
            "buying_price": to_float(text("purchase_price"), "purchase_price", idx),
            "selling_price": to_float(text("sale_price"), "sale_price", idx),
            "name": text("name"),
            "price_operator_approved": text("price_operator_approved").lower() in {"true", "1", "yes", "да"},
            "price_approval_source": text("price_approval_source"),
        })
    return rows


def read_sai_package_rows(path: str) -> List[Dict[str, Any]]:
    try:
        _sheet, source_rows, _meta = sai_package.load_rows(path)
    except sai_package.SaiPackageError as exc:
        raise SystemExit(f"SAI Package is invalid: {exc}")
    rows: List[Dict[str, Any]] = []
    for idx, row in enumerate(source_rows, start=1):
        barcode = ", ".join(row.get("barcodes") or [])
        if not barcode:
            continue
        rows.append({
            "excel_row": idx + 1,
            "barcode": barcode,
            "quantity": float(row.get("qty") or 0),
            "buying_price": float(row.get("buy") or 0),
            "selling_price": float(row.get("sale") or 0),
            "name": str(row.get("name") or ""),
            "price_operator_approved": bool(row.get("price_operator_approved")),
            "price_approval_source": str(row.get("price_approval_source") or ""),
        })
    return rows

def read_excel_rows(path: str, sheet_name: str) -> List[Dict[str, Any]]:
    lower = str(path).lower()
    if lower.endswith(".sai"):
        return read_sai_package_rows(path)
    if lower.endswith(".xml"):
        return read_xml_rows(path)
    wb = load_workbook(path, data_only=True, read_only=False)
    if sheet_name not in wb.sheetnames:
        raise SystemExit(f"Excel sheet not found: {sheet_name}. Existing sheets: {', '.join(wb.sheetnames)}")
    ws = wb[sheet_name]

    header_row = None
    headers = {}
    max_row = ws.max_row or 0
    max_col = ws.max_column or 0
    if max_row == 0 or max_col == 0:
        raise SystemExit(f"Sheet is empty or unreadable: {sheet_name}")

    for r in range(1, min(max_row, 20) + 1):
        values = [norm_header(ws.cell(r, c).value) for c in range(1, max_col + 1)]
        if "ШК" in values and "КОЛ-ВО" in values:
            header_row = r
            headers = {h: i + 1 for i, h in enumerate(values) if h}
            break

    if not header_row:
        raise SystemExit("Header row not found. Required columns: ШК, КОЛ-ВО, ЗАКУП ЦЕНА, ПРОДАЖНАЯ ЦЕНА.")

    required = ["ШК", "КОЛ-ВО", "ЗАКУП ЦЕНА", "ПРОДАЖНАЯ ЦЕНА"]
    missing = [h for h in required if h not in headers]
    if missing:
        raise SystemExit(f"Missing required columns: {', '.join(missing)}")

    rows = []
    approved_col = headers.get("ЦЕНА УТВЕРЖДЕНА ОПЕРАТОРОМ")
    approved_source_col = headers.get("ИСТОЧНИК УТВЕРЖДЕННОЙ ЦЕНЫ")
    for r in range(header_row + 1, max_row + 1):
        barcode = clean_barcode(ws.cell(r, headers["ШК"]).value)
        if not barcode:
            continue
        qty = to_float(ws.cell(r, headers["КОЛ-ВО"]).value, "КОЛ-ВО", r)
        buying = to_float(ws.cell(r, headers["ЗАКУП ЦЕНА"]).value, "ЗАКУП ЦЕНА", r)
        selling = to_float(ws.cell(r, headers["ПРОДАЖНАЯ ЦЕНА"]).value, "ПРОДАЖНАЯ ЦЕНА", r)
        name = ""
        if "НАИМЕНОВАНИЕ" in headers:
            name = str(ws.cell(r, headers["НАИМЕНОВАНИЕ"]).value or "").strip()
        rows.append({
            "excel_row": r,
            "barcode": barcode,
            "quantity": qty,
            "buying_price": buying,
            "selling_price": selling,
            "name": name,
            "price_operator_approved": (
                str(ws.cell(r, approved_col).value or "").strip().upper() in {"ДА", "TRUE", "1", "YES"}
                if approved_col else False
            ),
            "price_approval_source": (
                str(ws.cell(r, approved_source_col).value or "").strip()
                if approved_source_col else ""
            ),
        })
    return rows


def recursive_find_first(obj: Any, keys: Tuple[str, ...]) -> Optional[Any]:
    keys_l = {k.lower() for k in keys}
    if isinstance(obj, dict):
        for k, v in obj.items():
            if str(k).lower() in keys_l and v not in (None, ""):
                return v
        for v in obj.values():
            found = recursive_find_first(v, keys)
            if found not in (None, ""):
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = recursive_find_first(item, keys)
            if found not in (None, ""):
                return found
    return None



def safe_compact_text(value: Any) -> str:
    s = str(value or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s


def score_supplier_path(path: str) -> int:
    p = path.lower()
    score = 0
    strong = ("supplier", "provider", "contractor", "counterparty", "partner", "vendor")
    medium = ("sender", "seller", "shipper", "contragent", "контрагент", "поставщик")
    weak = ("organization", "company", "legal")
    negative = ("storehouse", "warehouse", "recipient", "buyer", "customer", "shop", "sellpoint", "sell_point", "cashbox")

    for word in strong:
        if word in p:
            score += 100
    for word in medium:
        if word in p:
            score += 70
    for word in weak:
        if word in p:
            score += 20
    for word in negative:
        if word in p:
            score -= 100
    return score


def extract_supplier_name_from_waybill(data: Any) -> Tuple[str, str, List[Dict[str, Any]]]:
    """
    Try to find supplier/contractor name in SIGMA waybill JSON.
    Returns: (name, source_path, candidates)
    No secrets are involved; this is document metadata only.
    """
    candidates: List[Dict[str, Any]] = []
    name_keys = (
        "name", "title", "fullName", "shortName", "displayName", "legalName",
        "supplierName", "providerName", "contractorName", "counterpartyName",
        "vendorName", "partnerName", "senderName", "sellerName", "contragentName",
    )

    def add_candidate(name: Any, path: str, base_score: int = 0) -> None:
        s = safe_compact_text(name)
        if not s:
            return
        if len(s) < 2 or len(s) > 180:
            return
        # Filter obvious technical ids.
        if re.fullmatch(r"[a-fA-F0-9-]{20,}", s):
            return
        score = base_score + score_supplier_path(path)
        # Legal entity markers are a good sign for supplier names.
        if re.search(r'\b(ООО|ИП|АО|ПАО|ЗАО|ОАО|LLC|LTD)\b', s, re.IGNORECASE):
            score += 25
        candidates.append({"name": s, "path": path, "score": score})

    def walk(obj: Any, path: str = "") -> None:
        if isinstance(obj, dict):
            # If current dict path looks like supplier/contractor, name fields inside it are strong.
            for key in name_keys:
                if key in obj:
                    add_candidate(obj.get(key), f"{path}.{key}" if path else key, 10)

            for k, v in obj.items():
                kp = f"{path}.{k}" if path else str(k)
                if isinstance(v, str):
                    # Direct fields like supplierName/providerName.
                    if any(token.lower() in str(k).lower() for token in name_keys):
                        add_candidate(v, kp, 30)
                    elif score_supplier_path(kp) >= 70:
                        add_candidate(v, kp, 10)
                elif isinstance(v, (dict, list)):
                    walk(v, kp)

        elif isinstance(obj, list):
            for idx, item in enumerate(obj[:60]):
                walk(item, f"{path}[{idx}]")

    walk(data)

    if not candidates:
        return "", "", []

    # Deduplicate names, keep best score/path.
    by_name: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        key = c["name"].strip().lower()
        if key not in by_name or c["score"] > by_name[key]["score"]:
            by_name[key] = c

    ranked = sorted(by_name.values(), key=lambda x: x["score"], reverse=True)
    best = ranked[0]
    return best["name"], best["path"], ranked[:10]


def read_waybill_metadata(client: "SigmaClient", waybill_id: str, log_dir: Path) -> Dict[str, Any]:
    """
    Reads SIGMA waybill JSON and extracts safe metadata for GUI.
    Saves a diagnostic JSON if supplier cannot be found.
    """
    raw = client.get_waybill_info(waybill_id)
    supplier_name, supplier_path, candidates = extract_supplier_name_from_waybill(raw)

    meta = {
        "waybill_id": waybill_id,
        "supplier_name": supplier_name,
        "supplier_source_path": supplier_path,
        "supplier_candidates": candidates[:10],
    }

    log_dir.mkdir(parents=True, exist_ok=True)
    out = log_dir / f"waybill_metadata_{waybill_id}.json"
    try:
        diagnostic = {
            "metadata": meta,
            "raw_top_keys": list(raw.keys()) if isinstance(raw, dict) else [],
            "raw": raw if not supplier_name else None,
        }
        out.write_text(json.dumps(diagnostic, ensure_ascii=False, indent=2), encoding="utf-8")
        meta["diagnostic_path"] = str(out)
    except Exception:
        pass

    return meta



def extract_list_candidates(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]

    if isinstance(data, dict):
        for key in ("content", "items", "data", "products", "result", "results", "rows"):
            val = data.get(key)
            if isinstance(val, list):
                return [x for x in val if isinstance(x, dict)]

        candidates = []

        def walk(x: Any):
            if isinstance(x, dict):
                has_id = any(k in x for k in ("productId", "id", "uuid"))
                has_name = any(str(k).lower() in ("name", "title", "productname") for k in x.keys())
                if has_id and has_name:
                    candidates.append(x)
                for v in x.values():
                    walk(v)
            elif isinstance(x, list):
                for v in x:
                    walk(v)

        walk(data)
        return candidates

    return []


def extract_product_id(product: Dict[str, Any]) -> Optional[str]:
    for key in ("productId", "id", "uuid"):
        val = product.get(key)
        if isinstance(val, str) and val:
            return val
    found = recursive_find_first(product, ("productId",))
    return str(found) if found else None


def extract_element_id(element: Any) -> Optional[str]:
    if not element:
        return None
    found = recursive_find_first(element, ("elementId", "waybillElementId"))
    if found:
        return str(found)
    maybe = recursive_find_first(element, ("id",))
    if isinstance(maybe, str) and re.match(r"^[a-f0-9-]{20,}$", maybe, re.I):
        return maybe
    return None


def to_optional_float(value: Any) -> Optional[float]:
    if value is None or value == "":
        return None
    try:
        if isinstance(value, (int, float)):
            if isinstance(value, float) and math.isnan(value):
                return None
            return float(value)
        s = str(value).strip().replace("\xa0", "").replace(" ", "").replace(",", ".")
        if not s:
            return None
        return float(s)
    except Exception:
        return None


def recursive_find_price(obj: Any) -> Optional[float]:
    """
    Try to find current SIGMA selling price in product/waybill element response.
    Most valuable known key from HAR: productPrice.
    """
    preferred_keys = (
        "productPrice",
        "sellingCostPerUnit",
        "sellingCost",
        "sellingPrice",
        "salesPrice",
        "salePrice",
        "retailPrice",
        "price",
    )
    preferred_l = {k.lower() for k in preferred_keys}

    if isinstance(obj, dict):
        for k, v in obj.items():
            if str(k).lower() in preferred_l:
                num = to_optional_float(v)
                if num is not None:
                    return num
        for v in obj.values():
            found = recursive_find_price(v)
            if found is not None:
                return found

    elif isinstance(obj, list):
        for item in obj:
            found = recursive_find_price(item)
            if found is not None:
                return found

    return None


def choose_selling_price(excel_selling_price: float, existing_price: Optional[float], policy: str = "max") -> float:
    """Business rule wrapper. Default keeps old safe behavior: use the bigger price."""
    return core_choose_selling_price(excel_selling_price, existing_price, policy=policy)


def price_source_label(excel_selling_price: float, existing_price: Optional[float], final_selling_price: float, policy: str = "max") -> str:
    """Explain why final selling price was selected."""
    return core_price_source_label(excel_selling_price, existing_price, final_selling_price, policy=policy)

def click_common_popups(page, rounds: int = 5) -> None:
    """
    Best-effort UI fallback for SIGMA welcome/news/tutorial popups.
    Safe version: clicks only inside visible dialogs/modals/overlays,
    not normal SIGMA navigation such as "Документы".
    """
    labels = [
        "Спасибо",
        "Закрыть",
        "Понятно",
        "Ясно",
        "ОК",
        "OK",
        "Хорошо",
        "Готово",
        "Пропустить",
        "Не сейчас",
        "Начать работу",
        "Продолжить",
        "Далее",
    ]

    forbidden_exact = [
        "Документы",
        "Товары",
        "Кассы",
        "Отчёты",
        "Отчеты",
        "Продажи",
        "Закупки",
        "Склад",
        "Настройки",
        "Маркет",
    ]

    js = r"""({labels, forbiddenExact}) => {
        function visible(el) {
            if (!el) return false;
            const st = window.getComputedStyle(el);
            if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return false;
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
        }

        function textOf(el) {
            return (el.innerText || el.textContent || "").trim().replace(/\s+/g, " ");
        }

        function isForbiddenText(text) {
            const t = String(text || "").trim().toLowerCase();
            return forbiddenExact.some(x => t === String(x).toLowerCase());
        }

        function hasBackdrop(dialog) {
            if (!dialog) return false;
            const cls = String(dialog.className || "").toLowerCase();
            const role = String(dialog.getAttribute("role") || "").toLowerCase();
            const ariaModal = String(dialog.getAttribute("aria-modal") || "").toLowerCase();

            if (role === "dialog" || ariaModal === "true") return true;
            if (cls.includes("modal") || cls.includes("dialog") || cls.includes("popover") || cls.includes("drawer")) return true;

            return false;
        }

        // Only search inside actual modal/dialog/overlay containers.
        const modalSelectors = [
            '[role="dialog"]',
            '[aria-modal="true"]',
            '.ant-modal',
            '.ant-modal-content',
            '.ant-drawer',
            '.ant-drawer-content',
            '.MuiDialog-root',
            '.MuiDialog-container',
            '.MuiDialog-paper',
            '.modal',
            '.modal-content',
            '.dialog',
            '.popover',
            '.popup',
            '[class*="modal"]',
            '[class*="Modal"]',
            '[class*="dialog"]',
            '[class*="Dialog"]',
            '[class*="popup"]',
            '[class*="Popup"]',
            '[class*="popover"]',
            '[class*="Popover"]'
        ];

        const modalRoots = Array.from(document.querySelectorAll(modalSelectors))
            .filter(el => visible(el) && hasBackdrop(el));

        if (!modalRoots.length) {
            return null;
        }

        const buttonSelector = 'button, [role="button"], a, .ant-btn, .MuiButton-root';

        for (const root of modalRoots) {
            const candidates = Array.from(root.querySelectorAll(buttonSelector)).filter(visible);

            for (const label of labels) {
                const ll = String(label).toLowerCase();
                for (const el of candidates) {
                    const text = textOf(el);
                    if (!text || isForbiddenText(text)) continue;

                    const tl = text.toLowerCase();

                    // Exact or close modal-like match.
                    if (tl === ll || tl.includes(ll)) {
                        el.click();
                        return text;
                    }
                }
            }

            // Close common X buttons inside modals only.
            const closeCandidates = Array.from(root.querySelectorAll(
                '[aria-label*="close" i], [aria-label*="закры" i], .close, .modal-close, .ant-modal-close, .MuiDialog-root button'
            )).filter(visible);

            for (const el of closeCandidates) {
                const text = textOf(el);
                if (isForbiddenText(text)) continue;
                el.click();
                return text || "X/close";
            }
        }

        return null;
    }"""

    for _ in range(rounds):
        try:
            clicked = page.evaluate(js, {"labels": labels, "forbiddenExact": forbidden_exact})
            if clicked:
                print(f"  popup button clicked: {clicked[:80]}")
                time.sleep(1)
            else:
                break
        except Exception:
            break


def install_sigma_token_capture(page) -> None:
    """
    SIGMA often keeps its API access_token only in JS memory after POST /oauth/token.
    This init script captures the token response as the page logs in/loads and stores it
    in window.__sigmaCapturedAccessToken/sessionStorage for later API calls.
    """
    init_js = r"""
(() => {
  if (window.__sigmaTokenCaptureInstalled) return;
  window.__sigmaTokenCaptureInstalled = true;
  window.__sigmaCapturedAccessToken = window.__sigmaCapturedAccessToken || null;

  function saveTokenFromData(data) {
    try {
      if (data && typeof data === 'object' && typeof data.access_token === 'string' && data.access_token.length > 50) {
        window.__sigmaCapturedAccessToken = data.access_token;
        try { window.sessionStorage.setItem('__sigmaCapturedAccessToken', data.access_token); } catch (e) {}
      }
    } catch (e) {}
  }

  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);
    try {
      const url = String(args[0] && (args[0].url || args[0]) || '');
      if (url.includes('/oauth/token')) {
        response.clone().json().then(saveTokenFromData).catch(() => {});
      }
    } catch (e) {}
    return response;
  };

  const OriginalXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function() {
    const xhr = new OriginalXHR();
    let requestUrl = '';
    const originalOpen = xhr.open;
    xhr.open = function(method, url, ...rest) {
      requestUrl = String(url || '');
      return originalOpen.call(this, method, url, ...rest);
    };
    xhr.addEventListener('load', function() {
      try {
        if (requestUrl.includes('/oauth/token')) {
          saveTokenFromData(JSON.parse(xhr.responseText));
        }
      } catch (e) {}
    });
    return xhr;
  };
})();
"""
    try:
        page.add_init_script(init_js)
    except Exception:
        pass


def click_login_entry_buttons(page, rounds: int = 2) -> None:
    """
    Login phase only.
    Clicks broad SIGMA entry/login buttons on cloud.sigma.ru pages.
    Does not click inside ATOL login form; phone/password remains manual unless already saved.
    """
    labels = [
        "Войти",
        "Вход",
        "Войти в систему",
        "Продолжить",
        "Продолжить вход",
        "Начать работу",
    ]

    js = r"""({labels}) => {
        function visible(el) {
            if (!el) return false;
            const st = window.getComputedStyle(el);
            if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return false;
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
        }

        function textOf(el) {
            const txt = (el.innerText || el.textContent || el.value || "").trim().replace(/\s+/g, " ");
            return txt;
        }

        const candidates = Array.from(document.querySelectorAll(
            'button, [role="button"], a, input[type="button"], input[type="submit"], .ant-btn, .MuiButton-root'
        )).filter(visible);

        for (const label of labels) {
            const ll = String(label).toLowerCase();
            for (const el of candidates) {
                const text = textOf(el);
                if (!text) continue;
                const tl = text.toLowerCase();

                if (tl === ll || tl.includes(ll)) {
                    try {
                        el.click();
                        return text;
                    } catch (e) {}
                }
            }
        }

        return null;
    }"""

    for _ in range(rounds):
        try:
            clicked = page.evaluate(js, {"labels": labels})
            if clicked:
                print(f"  login button clicked: {clicked[:80]}")
                time.sleep(2)
            else:
                break
        except Exception:
            break


def try_autofill_sigma_credentials(
    page,
    sigma_login: str = "",
    sigma_password: str = "",
    *,
    return_state: bool = False,
):
    """
    Best-effort ATOL/SIGMA login autofill.
    Credentials are passed from local GUI fields; they are never printed.
    Handles both one-step and two-step login forms.
    """
    sigma_login = normalize_sigma_login(sigma_login)
    sigma_password = str(sigma_password or "")

    if not sigma_login and not sigma_password:
        return {} if return_state else False

    js = r"""({login, password}) => {
        function visible(el) {
            if (!el) return false;
            const st = window.getComputedStyle(el);
            if (st.display === "none" || st.visibility === "hidden" || Number(st.opacity) === 0) return false;
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
        }

        function txt(el) {
            return (el.innerText || el.textContent || el.value || "").trim().replace(/\s+/g, " ");
        }

        function meta(el) {
            return [
                el.type, el.name, el.id, el.placeholder,
                el.getAttribute("aria-label"), el.getAttribute("autocomplete")
            ].map(x => String(x || "").toLowerCase()).join(" ");
        }

        function setValue(el, value) {
            try {
                el.focus();
                el.value = value;
                el.dispatchEvent(new Event("input", {bubbles: true}));
                el.dispatchEvent(new Event("change", {bubbles: true}));
                el.blur();
                return true;
            } catch (e) {
                return false;
            }
        }

        const inputs = Array.from(document.querySelectorAll("input"))
            .filter(el => visible(el) && String(el.type || "").toLowerCase() !== "hidden" && !el.disabled && !el.readOnly);

        const passwordInput = inputs.find(el => String(el.type || "").toLowerCase() === "password");

        const loginInput =
            inputs.find(el => {
                const m = meta(el);
                const t = String(el.type || "").toLowerCase();
                return t !== "password" && (
                    t === "tel" || t === "email" || t === "text" || t === "" ||
                    m.includes("phone") || m.includes("tel") || m.includes("login") ||
                    m.includes("user") || m.includes("email") || m.includes("mail") ||
                    m.includes("тел") || m.includes("логин") || m.includes("почт")
                );
            }) ||
            inputs.find(el => String(el.type || "").toLowerCase() !== "password");

        let filledLogin = false;
        let filledPassword = false;

        if (login && loginInput && String(loginInput.value || "").trim() !== String(login).trim()) {
            filledLogin = setValue(loginInput, login);
        }

        if (password && passwordInput && String(passwordInput.value || "") !== String(password)) {
            filledPassword = setValue(passwordInput, password);
        }

        const btns = Array.from(document.querySelectorAll(
            'button, [role="button"], input[type="button"], input[type="submit"], a'
        )).filter(visible);

        const labels = [
            "войти", "вход", "продолжить", "далее", "login", "sign in", "submit"
        ];

        let clicked = false;

        // Click when either:
        // - login was just entered and there is no password field yet (two-step form);
        // - password is present and entered.
        const shouldClick =
            (filledLogin && !passwordInput) ||
            (passwordInput && password && String(passwordInput.value || "") === String(password));

        if (shouldClick) {
            for (const b of btns) {
                const text = txt(b).toLowerCase();
                const type = String(b.type || "").toLowerCase();
                if (type === "submit" || labels.some(label => text === label || text.includes(label))) {
                    try {
                        b.click();
                        clicked = true;
                        break;
                    } catch (e) {}
                }
            }
        }

        return {
            filledLogin,
            filledPassword,
            clicked,
            hasLoginInput: !!loginInput,
            hasPasswordInput: !!passwordInput
        };
    }"""

    try:
        result = page.evaluate(js, {"login": sigma_login, "password": sigma_password})
        if isinstance(result, dict) and (result.get("filledLogin") or result.get("filledPassword") or result.get("clicked")):
            parts = []
            if result.get("filledLogin"):
                parts.append("login filled")
            if result.get("filledPassword"):
                parts.append("password filled")
            if result.get("clicked"):
                parts.append("button clicked")
            print("  login autofill: " + ", ".join(parts))
            time.sleep(2)
            return result if return_state else True
    except Exception as e:
        print(f"  login autofill skipped: {str(e)[:120]}")

    return {} if return_state else False


def is_sigma_login_page(url: str) -> bool:
    """Never let credential autofill touch product/document search fields."""
    lower = str(url or "").lower()
    return (
        "id.atol.ru" in lower
        or "openid-connect" in lower
        or "cloud.sigma.ru/login" in lower
        or "/oldwaylogin" in lower
    )


def inject_sigma_token(page, token: str) -> bool:
    """Expose a verified SIGMA token to both the browser probe and API client."""
    try:
        if str(token or "").count(".") != 2:
            return False
        page.evaluate(
            r"""token => {
                window.__sigmaCapturedAccessToken = token;
                try { window.sessionStorage.setItem("__sigmaCapturedAccessToken", token); } catch (e) {}
                try { window.localStorage.setItem("__sigmaCapturedAccessToken", token); } catch (e) {}
                try { document.cookie = "token=" + encodeURIComponent(token) + "; path=/; SameSite=Lax"; } catch (e) {}
            }""",
            token,
        )
        return True
    except Exception:
        return False


def inject_recent_runtime_sigma_token(page, api_base: str, max_age_seconds: int = 3600) -> bool:
    """Reuse a freshly verified API token when the browser login UI gets stuck."""
    try:
        payload = json.loads((CACHE_DIR / "sigma_runtime_token.json").read_text(encoding="utf-8"))
        token = str(payload.get("token") or "").strip()
        cached_api_base = str(payload.get("api_base") or "").rstrip("/")
        created_at = dt.datetime.strptime(
            str(payload.get("created_at") or ""),
            "%Y-%m-%d %H:%M:%S",
        )
        age_seconds = (dt.datetime.now() - created_at).total_seconds()
        if (
            token.count(".") != 2
            or cached_api_base != api_base.rstrip("/")
            or age_seconds < 0
            or age_seconds > max_age_seconds
        ):
            return False

        return inject_sigma_token(page, token)
    except Exception:
        return False


def refresh_and_inject_runtime_sigma_token(
    page,
    cloud_url: str,
    api_base: str,
    sigma_login: str,
    sigma_password: str,
) -> bool:
    """Refresh the emergency session when SIGMA reaches /documents but loses its token."""
    login = normalize_sigma_login(sigma_login)
    password = str(sigma_password or "")
    if not login or not password:
        return False
    try:
        config_response = requests.get(cloud_url.rstrip("/") + "/configs/config.js", timeout=15)
        config_response.raise_for_status()
        config_text = config_response.text

        def setting(name: str) -> str:
            match = re.search(
                rf'{re.escape(name)}\s*:\s*["\']([^"\']+)["\']',
                config_text,
            )
            if not match:
                raise RuntimeError(f"missing {name}")
            return match.group(1)

        backend_login = sigma_backend_login(login)
        response = requests.post(
            api_base.rstrip("/") + "/oauth/token",
            auth=(setting("clientId"), setting("clientSecret")),
            data={
                "grant_type": "password",
                "scope": "read write",
                "username": backend_login,
                "password": password,
            },
            timeout=20,
        )
        response.raise_for_status()
        token = str((response.json() or {}).get("access_token") or "")
        if token.count(".") != 2:
            return False
        account = requests.get(
            api_base.rstrip("/") + "/rest/1.1/account",
            headers={"Authorization": "Bearer " + token, "Accept": "application/json"},
            timeout=15,
        )
        account.raise_for_status()

        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_path = CACHE_DIR / "sigma_runtime_token.json"
        temp_path = cache_path.with_suffix(".json.tmp")
        temp_path.write_text(
            json.dumps(
                {
                    "token": token,
                    "api_base": api_base.rstrip("/"),
                    "created_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        temp_path.replace(cache_path)
        return inject_sigma_token(page, token)
    except Exception:
        return False


def probe_sigma_login_ready(page, api_base: str) -> dict:
    """
    Hard-login readiness check:
    do not trust URL only. We need SIGMA API token and preferably /rest/1.1/account = 200.
    """
    try:
        result = page.evaluate(
            r"""async ({apiBase}) => {
                function looksLikeJwt(s) {
                    return typeof s === "string" && /^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(s);
                }

                function safeGetStorage(storage, key) {
                    try { return storage.getItem(key); } catch (e) { return null; }
                }

                function walk(value, depth, out, seen) {
                    if (depth > 4 || value === null || value === undefined) return;

                    if (typeof value === "string") {
                        if (looksLikeJwt(value) && !seen.has(value)) {
                            seen.add(value);
                            out.push(value);
                        }

                        const trimmed = value.trim();
                        if ((trimmed.startsWith("{") && trimmed.endsWith("}")) || (trimmed.startsWith("[") && trimmed.endsWith("]"))) {
                            try { walk(JSON.parse(trimmed), depth + 1, out, seen); } catch (e) {}
                        }
                        return;
                    }

                    if (typeof value === "object") {
                        for (const v of Object.values(value)) {
                            walk(v, depth + 1, out, seen);
                        }
                    }
                }

                const tokens = [];
                const seen = new Set();

                const direct = [
                    window.__sigmaCapturedAccessToken,
                    safeGetStorage(window.sessionStorage, "__sigmaCapturedAccessToken"),
                    safeGetStorage(window.localStorage, "__sigmaCapturedAccessToken"),
                    (() => {
                        try {
                            const item = document.cookie
                                .split(";")
                                .map(x => x.trim())
                                .find(x => x.startsWith("token="));
                            return item ? decodeURIComponent(item.slice("token=".length)) : null;
                        } catch (e) {
                            return null;
                        }
                    })()
                ];

                for (const item of direct) walk(item, 0, tokens, seen);

                for (const storage of [window.localStorage, window.sessionStorage]) {
                    try {
                        for (let i = 0; i < storage.length; i++) {
                            const key = storage.key(i);
                            walk(storage.getItem(key), 0, tokens, seen);
                        }
                    } catch (e) {}
                }

                if (!tokens.length) {
                    return {ready: false, hasToken: false, accountStatus: null, reason: "NO_SIGMA_TOKEN_YET"};
                }

                // Try tokens until account endpoint accepts one.
                let lastStatus = null;
                let lastError = null;

                for (const token of tokens) {
                    try {
                        const response = await fetch(apiBase.replace(/\/$/, "") + "/rest/1.1/account", {
                            method: "GET",
                            headers: {"Authorization": "Bearer " + token, "Accept": "application/json"},
                            credentials: "include"
                        });

                        lastStatus = response.status;

                        if (response.status >= 200 && response.status < 300) {
                            try {
                                window.__sigmaCapturedAccessToken = token;
                                window.sessionStorage.setItem("__sigmaCapturedAccessToken", token);
                            } catch (e) {}

                            return {
                                ready: true,
                                hasToken: true,
                                accountStatus: response.status,
                                reason: "SIGMA_ACCOUNT_OK"
                            };
                        }
                    } catch (e) {
                        lastError = String(e && e.message || e);
                    }
                }

                // If account probe failed due CORS/network but token exists, allow next phase:
                // the main client will still verify by using the same token for real API calls.
                if (lastStatus === null && lastError) {
                    return {
                        ready: true,
                        hasToken: true,
                        accountStatus: null,
                        reason: "TOKEN_PRESENT_ACCOUNT_PROBE_FAILED: " + lastError.slice(0, 120)
                    };
                }

                return {
                    ready: false,
                    hasToken: true,
                    accountStatus: lastStatus,
                    reason: "TOKEN_PRESENT_BUT_ACCOUNT_NOT_READY"
                };
            }""",
            {"apiBase": api_base.rstrip("/")}
        )
        if isinstance(result, dict):
            return result
    except Exception as e:
        return {"ready": False, "hasToken": False, "accountStatus": None, "reason": f"PROBE_ERROR: {str(e)[:120]}"}

    return {"ready": False, "hasToken": False, "accountStatus": None, "reason": "PROBE_EMPTY"}


def wait_until_sigma_income_ready(page, target_url: str, timeout_sec: int = 90) -> bool:
    """
    Wait through ATOL -> cloud.sigma.ru/login#code -> SIGMA income draft redirects.
    Do not fight SIGMA redirects with page.goto while they are still happening.
    """
    deadline = time.time() + timeout_sec
    last_url = ""
    last_print = 0.0

    while time.time() < deadline:
        try:
            url = page.url
        except Exception:
            url = ""

        now = time.time()
        lower_url = url.lower()
        if url != last_url and now - last_print > 1:
            print(f"  waiting for SIGMA draft, current URL: {url[:160]}")
            last_url = url
            last_print = now

        click_common_popups(page, rounds=1)

        if "cloud.sigma.ru" in url and "/documents/INCOME/one" in url:
            try:
                page.wait_for_load_state("domcontentloaded", timeout=5000)
            except Exception:
                pass
            time.sleep(2)
            return True

        # Auth/login redirect is in progress. Just wait; forcing goto here can cause
        # "Navigation interrupted by another navigation".
        if "id.atol.ru" in url or "openid-connect" in url or "cloud.sigma.ru/login" in url:
            time.sleep(2)
            continue

        # If we are already on SIGMA but not on the target draft, gently navigate once.
        if "cloud.sigma.ru" in url:
            try:
                page.goto(target_url, wait_until="domcontentloaded", timeout=15000)
            except Exception as e:
                print(f"  SIGMA draft navigation is still settling: {str(e)[:180]}")
            time.sleep(3)
            continue

        time.sleep(1)

    return False


def wait_until_sigma_logged_in(
    page,
    cloud_url: str,
    api_base: str,
    sigma_login: str = "",
    sigma_password: str = "",
    timeout_sec: int = 300,
    legacy_login: str = "",
    legacy_password: str = "",
    atol_max_attempts: int = 3,
) -> bool:
    """
    Phase 1 hard-login:
    - do not trust cloud.sigma.ru URL alone;
    - click SIGMA entry login buttons if needed;
    - wait until SIGMA API token is captured and /rest/1.1/account is ready.
    """
    sigma_login = normalize_sigma_login(sigma_login)
    # Keep the legacy form's locally configured spelling (8...) intact.
    legacy_login = re.sub(r"\D+", "", str(legacy_login or "").strip())
    legacy_password = str(legacy_password or "")
    atol_max_attempts = max(1, int(atol_max_attempts or 3))
    deadline = time.time() + timeout_sec
    last_url = ""
    last_print = 0.0
    last_reason = ""
    cloud_host = "cloud.sigma.ru"
    legacy_login_attempted = False
    legacy_login_url = cloud_url.rstrip("/") + "/oldWayLogin"
    runtime_token_injected = False
    atol_submit_attempts = 0

    while time.time() < deadline:
        try:
            if page.is_closed():
                print("  SIGMA login window was closed by the user")
                return False
        except Exception:
            pass
        try:
            url = page.url
        except Exception:
            url = ""

        now = time.time()
        lower_url = url.lower()
        if url != last_url and now - last_print > 1:
            print(f"  login phase, current URL: {url[:160]}")
            last_url = url
            last_print = now

        click_common_popups(page, rounds=1)

        # Never run the generic input finder on /documents, dashboard, catalog,
        # or any other business screen: their search fields are not login fields.
        if is_sigma_login_page(url):
            active_login = legacy_login if legacy_login_attempted else sigma_login
            active_password = legacy_password if legacy_login_attempted else sigma_password
            fill_state = try_autofill_sigma_credentials(
                page,
                active_login,
                active_password,
                return_state=True,
            )
            if (
                not legacy_login_attempted
                and isinstance(fill_state, dict)
                and fill_state.get("clicked")
                and fill_state.get("hasPasswordInput")
            ):
                atol_submit_attempts += 1
                print(
                    f"  ATOL ID: попытка входа {atol_submit_attempts}/{atol_max_attempts}",
                    flush=True,
                )

        # If on SIGMA entry page and not redirected automatically, press broad login/entry button.
        # Do not click ATOL form buttons: user may need to enter phone/password manually.
        if (
            cloud_host in lower_url
            and "openid-connect" not in lower_url
            and "/login" not in lower_url
            and "/oldwaylogin" not in lower_url
        ):
            click_login_entry_buttons(page, rounds=1)

        if (
            not runtime_token_injected
            and cloud_host in lower_url
            and "/documents" in lower_url
        ):
            runtime_token_injected = inject_recent_runtime_sigma_token(page, api_base)
            if not runtime_token_injected:
                runtime_token_injected = refresh_and_inject_runtime_sigma_token(
                    page,
                    cloud_url,
                    api_base,
                    sigma_login,
                    sigma_password,
                )
            if runtime_token_injected:
                print("  SIGMA session restored from verified runtime token", flush=True)

        probe = probe_sigma_login_ready(page, api_base)
        reason = str(probe.get("reason", ""))
        if reason != last_reason:
            extra = ""
            if probe.get("accountStatus") is not None:
                extra = f", accountStatus={probe.get('accountStatus')}"
            print(f"  login check: {reason}{extra}")
            last_reason = reason

        if probe.get("ready"):
            print("  SIGMA hard-login check OK")
            try:
                page.wait_for_load_state("domcontentloaded", timeout=5000)
            except Exception:
                pass
            time.sleep(2)
            click_common_popups(page, rounds=2)
            return True

        external_auth = (
            "id.atol.ru" in lower_url
            or "openid-connect" in lower_url
            or "cloud.sigma.ru/login" in lower_url
        )

        # The legacy route is allowed only after three submitted ATOL password
        # attempts. It uses a separate locally stored credential pair.
        if (
            external_auth
            and legacy_login
            and legacy_password
            and not legacy_login_attempted
            and atol_submit_attempts >= atol_max_attempts
        ):
            print(
                f"  ATOL ID не принял {atol_submit_attempts} попытки. "
                "Переключаюсь на аварийный вход SIGMA.",
                flush=True,
            )
            legacy_login_attempted = True
            try:
                page.goto(legacy_login_url, wait_until="domcontentloaded", timeout=30000)
            except Exception as e:
                print(f"  Аварийный вход SIGMA ещё загружается: {str(e)[:180]}", flush=True)
            time.sleep(2)
            continue
        # Still in ATOL/OIDC redirect chain or ATOL form. Just wait.
        if external_auth:
            time.sleep(2)
            continue

        # If we are on blank/new/other page, gently open neutral SIGMA documents page.
        if cloud_host not in url:
            try:
                page.goto(cloud_url.rstrip("/") + "/documents", wait_until="domcontentloaded", timeout=15000)
            except Exception as e:
                print(f"  SIGMA login navigation is still settling: {str(e)[:180]}")
            time.sleep(2)
            continue

        time.sleep(2)

    print(f"  last login check: {last_reason or 'NO_LOGIN_CHECK_RESULT'}")
    return False


class SigmaFetchError(RuntimeError):
    pass


class SigmaClient:
    def __init__(self, page, api_base: str, cloud_url: str, verbose: bool = False):
        self.page = page
        self.api_base = api_base.rstrip("/")
        self.cloud_url = cloud_url.rstrip("/")
        self.verbose = verbose
        self._api_access_token = None

    def _url(self, path: str) -> str:
        if path.startswith("http://") or path.startswith("https://"):
            return path
        if not path.startswith("/"):
            path = "/" + path
        return self.api_base + path

    def get_api_access_token(self) -> Optional[str]:
        """
        SIGMA API normally uses Authorization: Bearer <token>.
        The browser app stores tokens in localStorage/sessionStorage.
        We do not print tokens to console or log.
        """
        if self._api_access_token:
            return self._api_access_token

        try:
            captured = self.page.evaluate(
                """() => {
                    let cookieToken = null;
                    try {
                        const item = document.cookie
                            .split(";")
                            .map(x => x.trim())
                            .find(x => x.startsWith("token="));
                        cookieToken = item ? decodeURIComponent(item.slice("token=".length)) : null;
                    } catch (e) {}
                    return window.__sigmaCapturedAccessToken
                        || window.sessionStorage.getItem('__sigmaCapturedAccessToken')
                        || window.localStorage.getItem('__sigmaCapturedAccessToken')
                        || cookieToken
                        || null;
                }"""
            )
            if captured and isinstance(captured, str) and captured.count(".") == 2:
                self._api_access_token = captured
                print("  SIGMA API token captured from oauth/token response")
                return self._api_access_token
        except Exception:
            pass

        try:
            result = self.page.evaluate(
                """async ({apiBase}) => {
                    function looksLikeJwt(s) {
                        return typeof s === "string" && /^eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+$/.test(s);
                    }

                    const tokens = [];
                    const seen = new Set();

                    function addToken(s) {
                        if (looksLikeJwt(s) && !seen.has(s)) {
                            seen.add(s);
                            tokens.push(s);
                        }
                    }

                    function walk(value, depth) {
                        if (depth > 5 || value === null || value === undefined) return;
                        if (typeof value === "string") {
                            addToken(value);
                            // Some storage values are JSON strings.
                            if ((value.startsWith("{") && value.endsWith("}")) || (value.startsWith("[") && value.endsWith("]"))) {
                                try { walk(JSON.parse(value), depth + 1); } catch (e) {}
                            }
                            // Some values contain a JWT as substring.
                            const matches = value.match(/eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+/g);
                            if (matches) matches.forEach(addToken);
                            return;
                        }
                        if (Array.isArray(value)) {
                            value.forEach(v => walk(v, depth + 1));
                            return;
                        }
                        if (typeof value === "object") {
                            Object.keys(value).forEach(k => walk(value[k], depth + 1));
                        }
                    }

                    function scanStorage(storage) {
                        for (let i = 0; i < storage.length; i++) {
                            const k = storage.key(i);
                            const v = storage.getItem(k);
                            walk(k, 0);
                            walk(v, 0);
                        }
                    }

                    try { scanStorage(window.localStorage); } catch (e) {}
                    try { scanStorage(window.sessionStorage); } catch (e) {}
                    try { walk(document.cookie, 0); } catch (e) {}

                    // Prefer a token that can actually call SIGMA API.
                    for (const token of tokens) {
                        try {
                            const r = await fetch(apiBase + "/waybills/count?status=DRAFT&type=INCOME", {
                                method: "GET",
                                headers: {
                                    "accept": "application/json, text/plain, */*",
                                    "authorization": "Bearer " + token
                                }
                            });
                            if (r.ok) {
                                return {ok: true, tokenFound: true, token: token, candidates: tokens.length, status: r.status};
                            }
                        } catch (e) {}
                    }

                    return {ok: false, tokenFound: tokens.length > 0, token: null, candidates: tokens.length};
                }""",
                {"apiBase": self.api_base}
            )

            if result and result.get("ok") and result.get("token"):
                self._api_access_token = result.get("token")
                print(f"  SIGMA API token found in browser storage, candidates: {result.get('candidates')}")
                return self._api_access_token

            if result and self.verbose:
                print(f"  no usable SIGMA API token in browser storage, candidates: {result.get('candidates')}")

        except Exception as e:
            if self.verbose:
                print(f"  token discovery failed: {str(e)[:180]}")

        return None

    def request(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Any:
        url = self._url(path)
        if self.verbose:
            print(f"{method.upper()} {url}")

        last_error = None

        for attempt in range(1, 7):
            try:
                # SIGMA sometimes reloads the SPA after login/token refresh.
                # If we evaluate fetch during that moment, Chromium destroys the JS context.
                # So we wait a little and retry instead of failing the whole run.
                try:
                    self.page.wait_for_load_state("domcontentloaded", timeout=10000)
                except Exception:
                    pass

                time.sleep(0.7)

                token = self.get_api_access_token()
                result = self.page.evaluate(
                    """async ({url, method, body, token}) => {
                        const headers = {
                            "accept": "application/json, text/plain, */*",
                            "content-type": "application/json"
                        };
                        if (token) {
                            headers["authorization"] = "Bearer " + token;
                        }
                        const opts = {
                            method,
                            credentials: "include",
                            headers
                        };
                        if (body !== null && body !== undefined) {
                            opts.body = JSON.stringify(body);
                        }
                        const response = await fetch(url, opts);
                        const text = await response.text();
                        let data = null;
                        try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
                        return {
                            ok: response.ok,
                            status: response.status,
                            statusText: response.statusText,
                            data,
                            text
                        };
                    }""",
                    {"url": url, "method": method.upper(), "body": body, "token": token}
                )

                if not result.get("ok"):
                    if result.get("status") == 401:
                        # Token can expire between discovery and request.
                        self._api_access_token = None
                        raise SigmaFetchError(
                            f"{method.upper()} {url} -> 401 unauthorized. "
                            f"Browser is not logged into SIGMA or session expired, or API token was not found in browser storage. "
                            f"Login in opened browser and run again. Response: {str(result.get('text'))[:300]}"
                        )
                    raise SigmaFetchError(f"{method.upper()} {url} -> {result.get('status')} {result.get('statusText')}: {str(result.get('text'))[:500]}")
                return result.get("data")

            except SigmaFetchError:
                raise

            except Exception as e:
                last_error = e
                message = str(e)
                retryable = (
                    "Execution context was destroyed" in message
                    or "Cannot find context" in message
                    or "Target page, context or browser has been closed" in message
                    or "navigation" in message.lower()
                )
                if self.verbose or retryable:
                    print(f"  request retry {attempt}/6 after page navigation: {message[:180]}")
                if not retryable or attempt == 6:
                    break
                time.sleep(1.5 * attempt)

        raise last_error

    def request_batch_parallel(self, calls: List[Dict[str, Any]]) -> List[Any]:
        """
        Experimental speed mode.
        Sends several independent SIGMA API requests in one page.evaluate()
        and runs them in parallel in the browser with Promise.all.

        Used only for updating different fields of the same waybill element:
        quantity, buying price, selling price.
        """
        if not calls:
            return []

        prepared = []
        for call in calls:
            method = str(call.get("method", "GET")).upper()
            path = str(call.get("path", ""))
            body = call.get("body")
            prepared.append({
                "method": method,
                "url": self._url(path),
                "body": body,
            })

        last_error = None

        for attempt in range(1, 7):
            try:
                try:
                    self.page.wait_for_load_state("domcontentloaded", timeout=10000)
                except Exception:
                    pass

                time.sleep(0.5)
                token = self.get_api_access_token()

                result = self.page.evaluate(
                    """async ({calls, token}) => {
                        const headersBase = {
                            "accept": "application/json, text/plain, */*",
                            "content-type": "application/json"
                        };
                        if (token) {
                            headersBase["authorization"] = "Bearer " + token;
                        }

                        async function one(call) {
                            const headers = Object.assign({}, headersBase);
                            const opts = {
                                method: call.method,
                                credentials: "include",
                                headers
                            };
                            if (call.body !== null && call.body !== undefined) {
                                opts.body = JSON.stringify(call.body);
                            }
                            const response = await fetch(call.url, opts);
                            const text = await response.text();
                            let data = null;
                            try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
                            return {
                                ok: response.ok,
                                status: response.status,
                                statusText: response.statusText,
                                url: call.url,
                                method: call.method,
                                data,
                                text
                            };
                        }

                        return await Promise.all(calls.map(one));
                    }""",
                    {"calls": prepared, "token": token}
                )

                data = []
                for item in result:
                    if not item.get("ok"):
                        if item.get("status") == 401:
                            self._api_access_token = None
                            raise SigmaFetchError(
                                f"{item.get('method')} {item.get('url')} -> 401 unauthorized. "
                                f"Response: {str(item.get('text'))[:300]}"
                            )
                        raise SigmaFetchError(
                            f"{item.get('method')} {item.get('url')} -> {item.get('status')} "
                            f"{item.get('statusText')}: {str(item.get('text'))[:500]}"
                        )
                    data.append(item.get("data"))

                return data

            except SigmaFetchError:
                raise

            except Exception as e:
                last_error = e
                message = str(e)
                retryable = (
                    "Execution context was destroyed" in message
                    or "Cannot find context" in message
                    or "Target page, context or browser has been closed" in message
                    or "navigation" in message.lower()
                )
                if self.verbose or retryable:
                    print(f"  fast batch retry {attempt}/6 after page navigation: {message[:180]}")
                if not retryable or attempt == 6:
                    break
                time.sleep(1.5 * attempt)

        raise last_error

    def set_element_values_fast(self, waybill_id: str, element_id: str, quantity: float, buying_price: float, selling_price: float) -> None:
        """
        Experimental speed mode:
        instead of 3 sequential PUT requests, sends 3 PUT requests in parallel.
        """
        self.request_batch_parallel([
            {
                "method": "PUT",
                "path": f"/waybills/{waybill_id}/elements/{element_id}/quantity",
                "body": {"value": quantity},
            },
            {
                "method": "PUT",
                "path": f"/waybills/{waybill_id}/elements/{element_id}/buying-cost-per-unit",
                "body": {"value": buying_price},
            },
            {
                "method": "PUT",
                "path": f"/waybills/{waybill_id}/elements/{element_id}/selling-cost-per-unit",
                "body": {"value": selling_price},
            },
        ])

    def get_waybill_info(self, waybill_id: str) -> Any:
        return self.request("GET", f"/waybills/{waybill_id}")

    def infer_storehouse_id(self, waybill_id: str) -> Optional[str]:
        try:
            data = self.get_waybill_info(waybill_id)
        except Exception as e:
            print(f"Cannot read waybill info to infer storehouseId: {e}")
            return None

        # New SIGMA waybill JSON often stores destination as an object:
        # {"storehouseDestination": {"id": "...", "name": "..."}}
        for key in ("storehouseDestination", "destinationStorehouse", "recipientStorehouse", "storehouse"):
            obj = recursive_find_first(data, (key,))
            if isinstance(obj, dict) and obj.get("id"):
                return str(obj.get("id"))

        found = recursive_find_first(data, (
            "storehouseId",
            "storeHouseId",
            "warehouseId",
            "targetStorehouseId",
            "destinationStorehouseId",
            "recipientStorehouseId",
        ))
        return str(found) if found else None

    def find_product_by_barcode(self, barcode: str, storehouse_id: Optional[str], waybill_id: Optional[str] = None) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]]]:
        body = {
            "isProduced": None,
            "name": barcode,
            "storehouseId": storehouse_id,
            "waybillId": waybill_id,
        }
        data = self.request("POST", "/rest/v4/products/simple?page=0", body)
        candidates = extract_list_candidates(data)
        return (candidates[0] if candidates else None, candidates)

    def get_existing_element(self, waybill_id: str, product_id: str) -> Any:
        return self.request("GET", f"/waybills/{waybill_id}/elements/product/{product_id}")

    def add_product_to_waybill(self, waybill_id: str, product_id: str) -> Any:
        return self.request("POST", f"/waybills/{waybill_id}/elements/product/{product_id}", {"productId": product_id})

    def set_quantity(self, waybill_id: str, element_id: str, value: float) -> Any:
        return self.request("PUT", f"/waybills/{waybill_id}/elements/{element_id}/quantity", {"value": value})

    def set_buying_price(self, waybill_id: str, element_id: str, value: float) -> Any:
        return self.request("PUT", f"/waybills/{waybill_id}/elements/{element_id}/buying-cost-per-unit", {"value": value})

    def set_selling_price(self, waybill_id: str, element_id: str, value: float) -> Any:
        return self.request("PUT", f"/waybills/{waybill_id}/elements/{element_id}/selling-cost-per-unit", {"value": value})

    def get_totals(self, waybill_id: str) -> Tuple[Any, Any]:
        buying = self.request("GET", f"/waybills/{waybill_id}/buying-amount")
        selling = self.request("GET", f"/waybills/{waybill_id}/selling-amount")
        return buying, selling

    def dismiss_welcome_popups_api(self) -> None:
        """
        From HAR: SIGMA closes/acknowledges the welcome/what's-new modal by saving browser settings:
        GET /rest/v3/browser-settings
        POST /rest/v3/browser-settings with the data payload.
        """
        try:
            settings = self.request("GET", "/rest/v3/browser-settings")
            payload = None
            if isinstance(settings, dict):
                if isinstance(settings.get("data"), dict):
                    payload = settings.get("data")
                else:
                    payload = settings

            if isinstance(payload, dict):
                self.request("POST", "/rest/v3/browser-settings", payload)
                print("  browser-settings saved to suppress welcome popup")
        except Exception as e:
            print(f"  cannot save browser-settings for welcome popup: {str(e)[:180]}")


def format_num(x: float) -> str:
    """Format a number for logs without crashing on an empty SIGMA field."""
    value = to_optional_float(x)
    if value is None:
        return "—"
    if value.is_integer():
        return str(int(value))
    return str(value).replace(".", ",")


def run(args):
    from sai_secret_store import reveal_config_secret

    args.sigma_password = reveal_config_secret(args.sigma_password)
    args.sigma_legacy_password = reveal_config_secret(args.sigma_legacy_password)
    args.waybill_id = normalize_waybill_id(args.waybill_id)
    rows = read_excel_rows(args.excel, args.sheet)

    if args.fast:
        raise SystemExit(
            "FAST mode is disabled in fix13_safe: SIGMA can save quantity=0 or empty buying price "
            "when several PUT requests update one waybill element in parallel. "
            "Use normal run_apply.cmd or run_repair_safe.cmd to repair/fill the waybill safely."
        )

    if args.limit and args.limit > 0:
        rows = rows[:args.limit]
    if not rows:
        raise SystemExit("No rows to process in Excel.")

    log_dir = Path(args.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"sigma_autoprihod_{ts}.csv"

    print("=" * 72)
    print("SIGMA Autoprihod MVP")
    print(f"Excel: {args.excel}")
    print(f"Sheet: {args.sheet}")
    print(f"waybillId: {args.waybill_id}")
    print(f"Mode: {'APPLY / write to SIGMA' if args.apply else 'DRY-RUN / no write'}")
    print(f"Speed mode: {'FAST experimental' if args.fast else 'safe sequential'}")
    print(f"Rows: {len(rows)}")
    print("=" * 72)

    with sync_playwright() as p:
        user_data_dir = str(Path(args.user_data_dir).resolve())
        visible = not bool(getattr(args, "hidden_browser", False))
        browser_kwargs = {
            "headless": not visible,
            "args": direct_chromium_args(["--start-maximized"] if visible else []),
        }

        if bool(getattr(args, "prefer_bundled_chromium", False)):
            context = p.chromium.launch_persistent_context(
                user_data_dir=user_data_dir,
                **browser_kwargs
            )
        else:
            try:
                context = p.chromium.launch_persistent_context(
                    user_data_dir=user_data_dir,
                    channel="chrome",
                    **browser_kwargs
                )
            except Exception:
                print("System Chrome did not start, trying bundled Chromium.")
                context = p.chromium.launch_persistent_context(
                    user_data_dir=user_data_dir,
                    **browser_kwargs
                )

        page = context.pages[0] if context.pages else context.new_page()
        install_sigma_token_capture(page)

        target_url = f"{args.cloud_url.rstrip('/')}/documents/INCOME/one?id={args.waybill_id}"
        login_url = args.login_url or (args.cloud_url.rstrip("/") + "/documents")

        print("")
        print("PHASE 1/3: Hard login / SIGMA entry")
        print(f"Opening neutral SIGMA login page: {login_url}")
        try:
            page.goto(login_url, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            # Login redirects can interrupt the initial navigation; this is not fatal.
            print(f"Initial SIGMA login navigation interrupted by redirect: {str(e)[:180]}")

        login_ready = wait_until_sigma_logged_in(
            page,
            args.cloud_url,
            args.api_base,
            args.sigma_login,
            args.sigma_password,
            timeout_sec=args.login_timeout,
            legacy_login=args.sigma_legacy_login,
            legacy_password=args.sigma_legacy_password,
            atol_max_attempts=args.sigma_atol_max_attempts,
        )
        print(f"Current browser URL after login phase: {page.url}")

        if not login_ready:
            print("")
            print("ERROR: SIGMA login did not finish in time.")
            print("If ATOL asks for phone/password, finish it in the opened browser and run the command again.")
            context.close()
            raise SystemExit(3)

        print("Trying to close common SIGMA welcome/pop-up modals before opening draft...")
        click_common_popups(page, rounds=4)

        client = SigmaClient(page, args.api_base, args.cloud_url, verbose=args.verbose)

        # Capture/check API token BEFORE going to the draft.
        if not client.get_api_access_token():
            print("  API token not captured yet. Reloading neutral SIGMA page once to catch /oauth/token...")
            try:
                page.goto(login_url, wait_until="domcontentloaded", timeout=60000)
            except Exception as e:
                print(f"  neutral SIGMA reload interrupted by redirect: {str(e)[:180]}")
            wait_until_sigma_logged_in(
                page,
                args.cloud_url,
                args.api_base,
                args.sigma_login,
                args.sigma_password,
                timeout_sec=90,
                legacy_login=args.sigma_legacy_login,
                legacy_password=args.sigma_legacy_password,
                atol_max_attempts=args.sigma_atol_max_attempts,
            )
            time.sleep(3)
            click_common_popups(page, rounds=3)
            client.get_api_access_token()

        if not client.get_api_access_token():
            print("")
            print("ERROR: SIGMA API token is still not available after hard-login.")
            print("Finish ATOL/SIGMA login in the opened browser and run the command again.")
            context.close()
            raise SystemExit(4)

        client.dismiss_welcome_popups_api()
        click_common_popups(page, rounds=3)

        if args.login_only:
            print("")
            print("LOGIN-ONLY OK.")
            print("SIGMA is opened with persistent browser profile.")
            print("You can close this window or press Enter to close Chromium.")
            input("Press Enter here to close Chromium... ")
            context.close()
            return

        print("")
        print("PHASE 2/3: Opening needed income draft")
        print(f"Opening SIGMA income draft: {target_url}")
        try:
            page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
        except Exception as e:
            print(f"Draft navigation interrupted by SIGMA redirect: {str(e)[:180]}")

        ready = wait_until_sigma_income_ready(page, target_url, timeout_sec=90)
        print(f"Current browser URL after draft phase: {page.url}")

        if not ready:
            print("")
            print("ERROR: SIGMA income draft did not become ready in time.")
            print("Make sure the waybillId is correct and the draft exists.")
            context.close()
            raise SystemExit(3)

        print("Trying to close common SIGMA welcome/pop-up modals in draft...")
        click_common_popups(page, rounds=4)

        print("")
        print("Reading waybill metadata...")
        try:
            meta = read_waybill_metadata(client, args.waybill_id, Path(args.log_dir))
            if meta.get("supplier_name"):
                print(f"Поставщик из черновика прихода: {meta.get('supplier_name')}")
                print(f"SAI_WAYBILL_METADATA_JSON:{json.dumps(meta, ensure_ascii=False)}")
            else:
                print("Поставщик из черновика прихода: не найден в JSON черновика.")
                if meta.get("diagnostic_path"):
                    print(f"Диагностика waybill metadata: {meta.get('diagnostic_path')}")
                print(f"SAI_WAYBILL_METADATA_JSON:{json.dumps(meta, ensure_ascii=False)}")
        except Exception as e:
            print(f"Не удалось прочитать поставщика из черновика: {str(e)[:300]}")

        if args.metadata_only:
            print("")
            print("METADATA-ONLY OK.")
            context.close()
            return

        print("")
        print("PHASE 3/3: Starting normal bot work")

        storehouse_id = args.storehouse_id
        if not storehouse_id:
            print("Trying to infer storehouseId from waybill...")
            storehouse_id = client.infer_storehouse_id(args.waybill_id)
            if storehouse_id:
                print(f"storehouseId: {storehouse_id}")

        if not storehouse_id:
            print("")
            print("Could not infer storehouseId automatically.")
            print("Run again with --storehouse-id <ID>.")
            print("You can find it in HAR: request /rest/v4/products/simple, field storehouseId.")
            context.close()
            raise SystemExit(2)

        fieldnames = [
            "excel_row", "barcode", "used_barcode", "name", "quantity", "buying_price",
            "incoming_selling_price", "sigma_existing_selling_price", "final_selling_price", "price_source",
            "status", "product_id", "element_id", "message"
        ]

        processed = 0
        errors = 0

        with open(log_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
            writer.writeheader()

            for i, row in enumerate(rows, start=1):
                print(f"")
                print(f"[{i}/{len(rows)}] Barcode {row['barcode']} — {row.get('name') or ''}")
                log_row = {
                    "excel_row": row["excel_row"],
                    "barcode": row["barcode"],
                    "used_barcode": "",
                    "barcode_status": "",
                    "name": row.get("name", ""),
                    "quantity": row["quantity"],
                    "buying_price": row["buying_price"],
                    "incoming_selling_price": row["selling_price"],
                    "sigma_existing_selling_price": "",
                    "final_selling_price": "",
                    "price_source": "",
                    "status": "",
                    "product_id": "",
                    "element_id": "",
                    "message": "",
                }

                try:
                    barcode_candidates = split_barcode_candidates(row["barcode"])
                    if not barcode_candidates:
                        raise RuntimeError("barcode is empty")

                    product = None
                    candidates = []
                    used_barcode = ""
                    not_found_codes = []

                    for code in barcode_candidates:
                        search_attempts = []
                        if storehouse_id:
                            search_attempts.append(("storehouse", storehouse_id, None))
                            search_attempts.append(("storehouse+waybill", storehouse_id, args.waybill_id))
                        search_attempts.append(("waybill", None, args.waybill_id))
                        search_attempts.append(("global", None, None))

                        for attempt_label, attempt_storehouse_id, attempt_waybill_id in search_attempts:
                            try:
                                product, candidates = client.find_product_by_barcode(code, attempt_storehouse_id, attempt_waybill_id)
                            except Exception as search_error:
                                not_found_codes.append(f"{code}/{attempt_label}: {search_error}")
                                continue

                            if product:
                                used_barcode = code
                                if attempt_label != "storehouse":
                                    print(f"  product search fallback worked: {attempt_label}")
                                break

                        if product:
                            break

                        not_found_codes.append(code)

                    if not product:
                        details = ", ".join(not_found_codes[:8]) or ", ".join(barcode_candidates)
                        raise RuntimeError("product not found by any barcode: " + details)

                    log_row["used_barcode"] = used_barcode
                    log_row["barcode_status"] = classify_barcode(used_barcode)

                    if len(barcode_candidates) > 1:
                        print(f"  multiple barcodes in cell: {', '.join(barcode_candidates)}")
                        print(f"  used barcode: {used_barcode}")

                    if len(candidates) > 1 and args.skip_ambiguous:
                        raise RuntimeError(f"multiple products found for barcode {used_barcode}: {len(candidates)}")

                    product_id = extract_product_id(product)
                    if not product_id:
                        raise RuntimeError("cannot extract productId from SIGMA response")

                    log_row["product_id"] = product_id
                    print(f"  productId: {product_id}")

                    # Existing SIGMA selling price usually comes as productPrice.
                    # We compare it with incoming Excel selling price and use the bigger value.
                    product_existing_price = recursive_find_price(product)

                    existing = client.get_existing_element(args.waybill_id, product_id)
                    element_id = extract_element_id(existing)
                    element_existing_price = recursive_find_price(existing)

                    existing_selling_price = element_existing_price if element_existing_price is not None else product_existing_price
                    final_selling_price = choose_selling_price(row["selling_price"], existing_selling_price)
                    price_source = price_source_label(row["selling_price"], existing_selling_price, final_selling_price)

                    log_row["sigma_existing_selling_price"] = "" if existing_selling_price is None else existing_selling_price
                    log_row["final_selling_price"] = final_selling_price
                    log_row["price_source"] = price_source

                    if existing_selling_price is None:
                        print(f"  SIGMA existing selling price: not found, using incoming {format_num(row['selling_price'])}")
                    else:
                        print(f"  incoming selling price: {format_num(row['selling_price'])}")
                        print(f"  SIGMA existing selling price: {format_num(existing_selling_price)}")
                        print(f"  final selling price, max(): {format_num(final_selling_price)}")
                    print(f"  price source: {price_source}")

                    if element_id:
                        print(f"  product already in waybill, elementId: {element_id}")
                    else:
                        print("  product not yet in waybill")
                        if args.apply:
                            added = client.add_product_to_waybill(args.waybill_id, product_id)
                            element_id = extract_element_id(added)
                            if not element_id:
                                raise RuntimeError("product added, but elementId not found in response")

                            if existing_selling_price is None:
                                added_price = recursive_find_price(added)
                                if added_price is not None:
                                    existing_selling_price = added_price
                                    final_selling_price = choose_selling_price(row["selling_price"], existing_selling_price)
                                    price_source = price_source_label(row["selling_price"], existing_selling_price, final_selling_price)
                                    log_row["sigma_existing_selling_price"] = existing_selling_price
                                    log_row["final_selling_price"] = final_selling_price
                                    log_row["price_source"] = price_source
                                    print(f"  SIGMA existing selling price after add: {format_num(existing_selling_price)}")
                                    print(f"  final selling price, max(): {format_num(final_selling_price)}")
                                    print(f"  price source: {price_source}")

                            print(f"  added, elementId: {element_id}")
                        else:
                            element_id = "DRY-RUN"
                            print("  DRY-RUN: add skipped")

                    log_row["element_id"] = element_id

                    if args.apply:
                        if args.fast:
                            client.set_element_values_fast(
                                args.waybill_id,
                                element_id,
                                row["quantity"],
                                row["buying_price"],
                                final_selling_price,
                            )
                            print(
                                f"  FAST: quantity {format_num(row['quantity'])}, "
                                f"buying {format_num(row['buying_price'])}, "
                                f"selling {format_num(final_selling_price)}"
                            )
                        else:
                            client.set_quantity(args.waybill_id, element_id, row["quantity"])
                            print(f"  quantity: {format_num(row['quantity'])}")

                            client.set_buying_price(args.waybill_id, element_id, row["buying_price"])
                            print(f"  buying price: {format_num(row['buying_price'])}")

                            client.set_selling_price(args.waybill_id, element_id, final_selling_price)
                            print(f"  selling price written: {format_num(final_selling_price)}")
                    else:
                        print(f"  DRY-RUN: would set quantity {format_num(row['quantity'])}, buying {format_num(row['buying_price'])}, selling {format_num(final_selling_price)}")

                    log_row["status"] = "OK"
                    log_row["message"] = "processed" if args.apply else "dry-run ok"
                    processed += 1

                except Exception as e:
                    errors += 1
                    log_row["status"] = "ERROR"
                    log_row["message"] = str(e)
                    print(f"  ERROR: {e}")
                    if args.stop_on_error:
                        writer.writerow(log_row)
                        print("Stopped because --stop-on-error is enabled.")
                        break

                writer.writerow(log_row)

        if args.apply:
            try:
                buying, selling = client.get_totals(args.waybill_id)
                print("")
                print("SIGMA totals after run:")
                print(f"  Buying: {buying}")
                print(f"  Selling: {selling}")
            except Exception as e:
                print(f"Cannot read totals: {e}")

        print("")
        print("Done.")
        print(f"OK: {processed}")
        print(f"Errors: {errors}")
        print(f"Log: {log_path}")

        context.close()

        if errors:
            print("")
            print(f"ERROR: completed with row errors: {errors}")
            raise SystemExit(5)


def parse_args():
    parser = argparse.ArgumentParser(description="SIGMA Autoprihod MVP")
    parser.add_argument("--excel", required=True, help="Path to Excel file")
    parser.add_argument("--sheet", default="Для робота SIGMA", help="Excel sheet name")
    parser.add_argument("--waybill-id", required=True, help="SIGMA waybill id from URL")
    parser.add_argument("--apply", action="store_true", help="Write to SIGMA. Without this, dry-run only.")
    parser.add_argument("--limit", type=int, default=0, help="How many rows to process. 0 = all rows to the end of Excel table.")
    parser.add_argument("--api-base", default=DEFAULT_API_BASE, help="API base, e.g. https://api-s07.sigma.ru")
    parser.add_argument("--cloud-url", default=DEFAULT_CLOUD_URL, help="Cloud URL")
    parser.add_argument("--login-url", default="", help="Neutral SIGMA entry URL for phase 1 login. Default: cloud-url /documents.")
    parser.add_argument("--login-timeout", type=int, default=300, help="Seconds to wait for SIGMA/ATOL login redirects and API token.")
    parser.add_argument("--sigma-login", default="", help="Local SIGMA/ATOL login for autofill. Do not print.")
    parser.add_argument("--sigma-password", default="", help="Local SIGMA/ATOL password for autofill. Do not print.")
    parser.add_argument("--sigma-legacy-login", default="", help="Fallback SIGMA login after failed ATOL attempts. Do not print.")
    parser.add_argument("--sigma-legacy-password", default="", help="Fallback SIGMA password after failed ATOL attempts. Do not print.")
    parser.add_argument("--sigma-atol-max-attempts", type=int, default=3)
    parser.add_argument("--storehouse-id", default="", help="Storehouse ID. If empty, script tries to infer.")
    parser.add_argument("--user-data-dir", default=str(PROFILE_DIR), help="Browser profile folder for SIGMA session")
    parser.add_argument("--log-dir", default=str(LOGS_DIR), help="Logs folder")
    parser.add_argument("--verbose", action="store_true", help="Print request URLs")
    parser.add_argument("--stop-on-error", action="store_true", help="Stop on first error")
    parser.add_argument("--skip-ambiguous", action="store_true", help="Skip if barcode finds multiple products")
    parser.add_argument("--fast", action="store_true", help="DISABLED in fix13_safe: unsafe with SIGMA waybill autosave.")
    parser.add_argument("--login-only", action="store_true", help="Open SIGMA with persistent browser profile and save login session.")
    parser.add_argument("--metadata-only", action="store_true", help="Open SIGMA draft, read supplier/waybill metadata, print SAI_WAYBILL_METADATA_JSON and exit.")
    parser.add_argument("--visible-browser", action="store_true", help="Show SIGMA browser window")
    parser.add_argument("--hidden-browser", action="store_true", help="Run SIGMA browser headless when possible")
    parser.add_argument("--prefer-bundled-chromium", action="store_true", help="Skip System Chrome probe and use Playwright bundled Chromium")
    return parser.parse_args()


if __name__ == "__main__":
    try:
        run(parse_args())
    except KeyboardInterrupt:
        print("")
        print("Stopped by user.")
        sys.exit(130)
