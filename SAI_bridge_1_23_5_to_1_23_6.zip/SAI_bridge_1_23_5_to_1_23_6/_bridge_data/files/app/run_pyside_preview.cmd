@echo off
rem Compatibility launcher. Main console launcher is run_sai_hub.cmd.
call "%~dp0run_sai_hub.cmd"
exit /b %ERRORLEVEL%
