#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""PySide6 shell for SAI.

v1.20.0 starts the real merge: the PySide6 Hub gets an in-window receiving workbench.
The classic Tkinter SAI is still available as a safety fallback, but the first
steps of a receipt (select SAI-file, read it, preview totals, prepare for the
workflow) now happen in the Qt window.
"""
from __future__ import annotations

import base64
import csv
import ctypes
import datetime as dt
import html
import json
import math
import os
import secrets
import socket
import re
import shutil
import sqlite3
import ssl
import struct
import subprocess
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from sai_version import APP_VERSION
import sai_organization_sync
import sai_github_updates
import sai_github_bootstrap
import sai_scan_inbox

from sai_direct_network import configure_direct_network, direct_chromium_args

configure_direct_network()

try:
    from PySide6.QtCore import Qt, QTimer, QUrl, QProcess, QObject, Signal, QPropertyAnimation, QEvent, QStandardPaths, QEasingCurve, QPoint, QPointF, QRect, QRectF, QSize, QSizeF, QMarginsF, QTime
    from PySide6.QtGui import QAction, QDesktopServices, QFont, QKeySequence, QTextCursor, QPixmap, QPainter, QColor, QPen, QPainterPath, QLinearGradient, QRadialGradient, QPdfWriter, QPageSize, QPageLayout, QImage, QIcon, QRegion
    from PySide6.QtWidgets import (
        QApplication,
        QAbstractItemView,
        QAbstractSpinBox,
        QButtonGroup,
        QCheckBox,
        QComboBox,
        QDialog,
        QDialogButtonBox,
        QFormLayout,
        QGraphicsOpacityEffect,
        QFileDialog,
        QFrame,
        QGridLayout,
        QHBoxLayout,
        QInputDialog,
        QLayout,
        QHeaderView,
        QLabel,
        QLineEdit,
        QMainWindow,
        QPushButton,
        QProgressBar,
        QScrollArea,
        QSlider,
        QSizePolicy,
        QStackedWidget,
        QStyle,
        QTableWidget,
        QTableWidgetItem,
        QTabWidget,
        QTimeEdit,
        QTextEdit,
        QVBoxLayout,
        QWidget,
    )
    try:
        from PySide6.QtPrintSupport import QPrinter, QPrinterInfo
    except Exception:
        QPrinter = None
        QPrinterInfo = None
except Exception as exc:  # pragma: no cover - user-facing fallback
    print("PySide6 is not installed.")
    print("Run app\\run_pyside_preview.cmd or install PySide6 into app\\.venv.")
    print(f"Original error: {exc}")
    raise

from sai_notifications import CatalogStatusBadge, NotificationCenter, QMessageBox
from sai_mobile_https import build_apple_ca_profile, ensure_mobile_https_material
from sai_accounts import AccountService
from sai_stock_ui import WarehousePage
from sai_store_dashboard import StoreDashboardPage
from sai_staff_ui import StaffPage
from sai_marking_ui import MarkingCheckPage
from sai_thermal_text_ui import ThermalTextPrintPage
from sai_ui_style import ui_polish_stylesheet
from sai_design_tokens import METRICS
from sai_guided_tour import GuidedTourOverlay, GuidedTourStep
from sai_receipt_hub import (
    DraftsTileButton, ManualReceiptTileButton, NewReceiptHeroButton,
    ReceiptDraftsDialog, UxTwoLineButton,
)
from sai_core_v2.receipt_routing import (
    DraftResumeKind, build_draft_resume_plan, build_receipt_route_plan,
    missing_barcode_indices, numeric_barcodes, receipt_quantity,
    resolve_prepared_receipt_path,
)
from sai_manual_receipt import ManualReceiptService, supplier_fields
from sai_free_receipt import FreeReceiptCatalogService
from sai_core_v2.free_receipt import (
    highest_internal_counter as free_highest_internal_counter,
    is_barcode_like_query as free_is_barcode_like_query,
    merge_barcodes as free_merge_barcodes,
    normalize_markup as free_normalize_markup,
    normalize_unit as free_normalize_unit,
    normalized_internal_prefix as free_normalized_internal_prefix,
    price_text as free_core_price_text,
)
from sai_core_v2.barcodes import (
    barcode_kind,
    barcode_modules_for_print,
    code128b_modules,
    code128c_modules,
    ean_checksum,
    ean13_modules,
    ean8_modules,
    is_valid_ean,
)
from sai_semi_auto_receipt import SemiAutoReceiptService as SemiAutoPersistenceService
from sai_core_v2.semi_auto_receipt_refactor import (
    approve_operator_sale_price as semi_approve_operator_sale_price,
    collection_progress as semi_collection_progress,
    find_barcode_owner as semi_find_barcode_owner,
    is_zero_quantity as semi_is_zero_quantity,
    label_copies as semi_label_copies,
    label_quantity_is_manual as semi_label_quantity_is_manual,
    lock_sale_price_for_thermal_label as semi_lock_sale_price_for_thermal_label,
    missing_barcode_indices as semi_missing_barcode_indices,
    quantity_value as semi_quantity_value,
    receipt_quantity_int as semi_receipt_quantity_int,
    row_barcodes as semi_row_barcodes,
    valid_barcodes_from_text as semi_valid_barcodes_from_text,
)
from sai_semi_auto import SemiAutoReceiptService as SemiAutoWorkflowService
from sai_sigma_import_state import (
    load_import_category_memory,
    read_import_xlsx_category_memory,
    remembered_categories_by_row,
    save_import_category_memory,
)
from sai_price_tag_sigma_ui import PriceTagSigmaBatchMixin


_SHARED_FREE_CATALOG_SERVICE: Optional[FreeReceiptCatalogService] = None
_SHARED_FREE_CATALOG_LOCK = threading.Lock()


def shared_free_catalog_service() -> FreeReceiptCatalogService:
    """One in-memory catalog index for manual receipt and price tags."""
    global _SHARED_FREE_CATALOG_SERVICE
    with _SHARED_FREE_CATALOG_LOCK:
        if _SHARED_FREE_CATALOG_SERVICE is None:
            _SHARED_FREE_CATALOG_SERVICE = FreeReceiptCatalogService()
        return _SHARED_FREE_CATALOG_SERVICE
from sai_price_tags import (
    price_number as _price_tag_num,
    price_text as _price_tag_price_text,
    read_sai_package_price_items,
    read_sai_price_items,
    read_sai_xlsx_price_items,
    read_sai_xml_price_items,
    unit_text as _price_tag_unit_text,
)
from sai_price_tag_pdf import (
    PRICE_TAG_DPI,
    PRICE_TAG_H_MM,
    PRICE_TAG_W_MM,
    create_price_tags_pdf,
    create_price_tags_pdf_from_sai_file,
    draw_price_tag as _draw_one_price_tag,
    fit_font as _fit_font,
    make_price_tag_preview_pixmap,
    print_price_tags_a4,
    price_tag_date_text as _price_tag_date_text,
)
from sai_thermal_printing import (
    get_default_windows_printer as _get_default_windows_printer,
    list_windows_printers as _list_windows_printers,
    normalize_thermal_config,
    print_thermal_label,
    render_thermal_label,
    resolve_windows_printer_name as _resolve_windows_printer_name,
)
from sai_print_routing import (
    is_thermal_printer_name as _is_thermal_printer_name,
    require_a4_printer_name as _require_a4_printer_name,
    resolve_a4_printer_name as _resolve_a4_printer_name,
)
from sai_core_v2.manual_receipt import (
    ManualReceiptRow, card_has_data as manual_card_has_data,
    label_copies as manual_label_copies, merge_row as merge_manual_row,
    money_float as manual_money_float, price_text as manual_price_text,
    round_sale_from_purchase as manual_round_sale_from_purchase,
)


class NoWheelComboBox(QComboBox):
    """ComboBox that does not change value from accidental mouse-wheel scrolling.

    In the fact table this prevents changing the row status just because the
    cursor is hovering over the "Состояние" cell while the user scrolls the table.
    """

    def wheelEvent(self, event):  # noqa: N802 - Qt override name
        event.ignore()


class BarcodeCopyLineEdit(QLineEdit):
    """A barcode field where a double click copies the selected code."""

    def mouseDoubleClickEvent(self, event):  # noqa: N802 - Qt override name
        super().mouseDoubleClickEvent(event)

        def copy_selected_code() -> None:
            selected_codes = list(semi_valid_barcodes_from_text(self.selectedText()))
            all_codes = list(semi_valid_barcodes_from_text(self.text()))
            codes = selected_codes or all_codes
            if codes:
                QApplication.clipboard().setText(codes[0] if selected_codes else ", ".join(codes))

        QTimer.singleShot(0, copy_selected_code)


class NoWheelFilter(QObject):
    """Application-wide protection against accidental combo-box wheel changes."""

    def eventFilter(self, obj, event):  # noqa: N802 - Qt override name
        try:
            if event.type() == QEvent.Wheel and isinstance(obj, QComboBox):
                event.ignore()
                return True
        except Exception:
            pass
        return super().eventFilter(obj, event)


class SaiToggleSwitch(QCheckBox):
    """Compact SAI switch with a real moving thumb."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("SaiToggleSwitch")
        self.setFixedSize(48, 28)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

    def hitButton(self, pos):  # noqa: N802 - Qt override name
        return self.rect().contains(pos)

    def paintEvent(self, event):  # noqa: N802 - Qt override name
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        track = QRectF(1.0, 2.0, 46.0, 24.0)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#2563eb" if self.isChecked() else "#cbd5e1"))
        painter.drawRoundedRect(track, 12.0, 12.0)
        knob_x = 24.0 if self.isChecked() else 4.0
        painter.setBrush(QColor("#ffffff"))
        painter.drawEllipse(QRectF(knob_x, 5.0, 18.0, 18.0))


class RoundedQrLabel(QLabel):
    """QR surface with a painted opaque contour instead of stylesheet holes."""

    def __init__(self, text: str = "", parent=None) -> None:
        self._qr_pixmap = QPixmap()
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)

    def setPixmap(self, pixmap):  # noqa: N802 - Qt override name
        self._qr_pixmap = QPixmap(pixmap) if pixmap is not None else QPixmap()
        super().setText("")
        self.update()

    def setText(self, text):  # noqa: N802 - Qt override name
        self._qr_pixmap = QPixmap()
        super().setText(text)
        self.update()

    def paintEvent(self, event):  # noqa: N802 - Qt override name
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        contour = QRectF(self.rect()).adjusted(0.75, 0.75, -0.75, -0.75)
        painter.setPen(QPen(QColor("#e2e8f0"), 1.5))
        painter.setBrush(QColor("#ffffff"))
        painter.drawRoundedRect(contour, 11.0, 11.0)
        inner = self.rect().adjusted(7, 7, -7, -7)
        if not self._qr_pixmap.isNull():
            scaled = self._qr_pixmap.scaled(
                inner.size(),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.FastTransformation,
            )
            x = inner.x() + (inner.width() - scaled.width()) // 2
            y = inner.y() + (inner.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)
        else:
            painter.setPen(QColor("#64748b"))
            painter.drawText(inner, Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self.text())


class DropPlusIndicator(QWidget):
    """Paint a mathematically centred plus instead of relying on font metrics."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("InvoiceDropPlus")
        self.setFixedSize(92, 92)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def paintEvent(self, event):  # noqa: N802 - Qt override name
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        circle = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        app = QApplication.instance()
        dark = bool(app and app.property("saiNightTheme"))
        painter.setPen(QPen(QColor("#93c5fd" if dark else "#bfdbfe"), 2.0))
        painter.setBrush(QColor("#1d4ed8" if dark else "#2563eb"))
        painter.drawEllipse(circle)

        center = circle.center()
        half = 15.0
        plus_pen = QPen(QColor("#ffffff"), 4.0)
        plus_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(plus_pen)
        painter.drawLine(QPointF(center.x() - half, center.y()), QPointF(center.x() + half, center.y()))
        painter.drawLine(QPointF(center.x(), center.y() - half), QPointF(center.x(), center.y() + half))


class RoundedTableWidget(QTableWidget):
    """QTableWidget whose header and viewport are clipped by one outer contour.

    The child header sections deliberately stay rectangular. Rounding them a
    second time creates transparent wedges (the visible "holes" in table
    corners). Only the table-level mask owns the corner geometry.
    """

    CORNER_RADIUS = float(METRICS["table_radius"])

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        # SAI table standard: a click starts editing when the data cell itself
        # is editable. Protected/action cells keep their existing behaviour.
        self.cellClicked.connect(self._edit_clicked_cell)

    def _edit_clicked_cell(self, row: int, column: int) -> None:
        if not bool(self.property("saiInlineEdit")):
            return
        item = self.item(row, column)
        if item is None or not bool(item.flags() & Qt.ItemFlag.ItemIsEditable):
            return
        QTimer.singleShot(0, lambda r=row, c=column: self._begin_cell_edit(r, c))

    def _begin_cell_edit(self, row: int, column: int) -> None:
        item = self.item(row, column)
        if item is not None and bool(item.flags() & Qt.ItemFlag.ItemIsEditable):
            self.editItem(item)

    def keyPressEvent(self, event):  # noqa: N802 - Qt override name
        if event.matches(QKeySequence.StandardKey.Copy):
            ranges = self.selectedRanges()
            if ranges:
                selected = ranges[0]
                lines = []
                for row in range(selected.topRow(), selected.bottomRow() + 1):
                    values = []
                    for column in range(selected.leftColumn(), selected.rightColumn() + 1):
                        item = self.item(row, column)
                        values.append(item.text() if item is not None else "")
                    lines.append("\t".join(values))
                QApplication.clipboard().setText("\n".join(lines))
                event.accept()
                return
        super().keyPressEvent(event)

    def resizeEvent(self, event):  # noqa: N802 - Qt override name
        super().resizeEvent(event)
        if bool(self.property("saiRoundedByShell")):
            self.clearMask()
            return
        if self.width() <= 1 or self.height() <= 1:
            return
        path = QPainterPath()
        contour = QRectF(self.rect()).adjusted(0.0, 0.0, -0.5, -0.5)
        path.addRoundedRect(contour, self.CORNER_RADIUS, self.CORNER_RADIUS)
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))


class RoundedTopHeaderView(QHeaderView):
    """Clip only the two upper header corners inside an opaque table shell."""

    CORNER_RADIUS = float(METRICS["table_radius"] - 3)

    def resizeEvent(self, event):  # noqa: N802 - Qt override name
        super().resizeEvent(event)
        width, height = float(self.width()), float(self.height())
        if width <= 1 or height <= 1:
            return
        radius = min(self.CORNER_RADIUS, width / 2.0, height)
        path = QPainterPath()
        path.moveTo(0.0, height)
        path.lineTo(0.0, radius)
        path.quadTo(0.0, 0.0, radius, 0.0)
        path.lineTo(width - radius, 0.0)
        path.quadTo(width, 0.0, width, radius)
        path.lineTo(width, height)
        path.closeSubpath()
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))


from sai_ui_components import ReceiptWorkflowTracker, TableEditButton


class HistoryDeleteButton(QPushButton):
    """Compact history-row delete action with stable custom painting."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("HistoryDeleteButton")
        self.setToolTip("Удалить запись из истории")
        self.setFixedSize(26, 26)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFlat(True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setText("")

    def paintEvent(self, event):  # noqa: N802 - Qt override name
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        app = QApplication.instance()
        dark = bool(app and app.property("saiNightTheme"))
        hovered = self.underMouse()
        pressed = self.isDown()

        if hovered or pressed:
            fill = QColor(248, 113, 113, 48 if pressed else 30) if dark else QColor("#fecaca" if pressed else "#fee2e2")
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(fill)
            painter.drawEllipse(QRectF(1.0, 1.0, 24.0, 24.0))

        stroke = QColor("#fecaca" if hovered else "#94a3b8") if dark else QColor("#b91c1c" if hovered else "#64748b")
        painter.setPen(QPen(stroke, 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        center = QPointF(self.width() / 2.0, self.height() / 2.0)
        radius = 4.1
        painter.drawLine(QPointF(center.x() - radius, center.y() - radius), QPointF(center.x() + radius, center.y() + radius))
        painter.drawLine(QPointF(center.x() + radius, center.y() - radius), QPointF(center.x() - radius, center.y() + radius))


def make_standard_page_header(title_text: str, subtitle_text: str) -> QFrame:
    """Create the same title/description block for every top-level page."""
    header = QFrame()
    header.setObjectName("PageHeader")
    layout = QVBoxLayout(header)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(5)

    title = QLabel(title_text)
    title.setObjectName("PageHeaderTitle")
    subtitle = QLabel(subtitle_text)
    subtitle.setObjectName("PageHeaderSubtitle")
    subtitle.setWordWrap(True)

    layout.addWidget(title)
    layout.addWidget(subtitle)
    return header


class FlowLayout(QLayout):
    """Compact chip layout: widgets keep text width and wrap to the next line."""

    def __init__(self, parent=None, margin: int = 0, spacing: int = 6):
        super().__init__(parent)
        self._items = []
        self.setContentsMargins(margin, margin, margin, margin)
        self.setSpacing(spacing)

    def addItem(self, item):  # noqa: N802 - Qt override name
        self._items.append(item)

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, index: int):  # noqa: N802 - Qt override name
        return self._items[index] if 0 <= index < len(self._items) else None

    def takeAt(self, index: int):  # noqa: N802 - Qt override name
        if 0 <= index < len(self._items):
            return self._items.pop(index)
        return None

    def expandingDirections(self):  # noqa: N802 - Qt override name
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:  # noqa: N802 - Qt override name
        return True

    def heightForWidth(self, width: int) -> int:  # noqa: N802 - Qt override name
        return self._do_layout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect):  # noqa: N802 - Qt override name
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self) -> QSize:  # noqa: N802 - Qt override name
        return self.minimumSize()

    def minimumSize(self) -> QSize:  # noqa: N802 - Qt override name
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        l, t, r, b = self.getContentsMargins()
        size += QSize(l + r, t + b)
        return size

    def _do_layout(self, rect: QRect, test_only: bool) -> int:
        x = rect.x()
        y = rect.y()
        line_height = 0
        spacing = max(0, self.spacing())
        for item in self._items:
            hint = item.sizeHint()
            next_x = x + hint.width() + spacing
            if next_x - spacing > rect.right() and line_height > 0:
                x = rect.x()
                y += line_height + spacing
                next_x = x + hint.width() + spacing
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - rect.y()


try:
    from openpyxl import load_workbook
    from sai_app import (
        DEFAULT_STOREHOUSE_ID,
        API_FIRST_SCRIPT,
        WAYBILL_CREATOR_SCRIPT,
        CACHE_DIR,
        PROFILE_DIR,
        create_import_file_from_sigma_api,
        create_ndp_file,
        date_display_from_text,
        find_headers,
        load_private_config as sai_load_private_config,
        load_sai_rows,
        normalize_unit,
        parse_int_or_float,
        pick_col,
        read_bot_log_rows,
        save_barcode_conflict_resolution,
        safe_str as sai_safe_str,
    )
except Exception:  # pragma: no cover - Hub must still open even if classic SAI has an issue
    load_sai_rows = None
    def normalize_unit(value):
        text = str(value or "").strip().lower().replace(".", "")
        return "м" if text in ("м", "m", "метр", "метра", "метров") or "метр" in text else "штука"
    date_display_from_text = None
    create_import_file_from_sigma_api = None
    create_ndp_file = None
    sai_load_private_config = None
    read_bot_log_rows = None
    save_barcode_conflict_resolution = None
    DEFAULT_STOREHOUSE_ID = ""
    API_FIRST_SCRIPT = APP_DIR / "sai_api_first_apply.py" if 'APP_DIR' in globals() else Path("sai_api_first_apply.py")
    WAYBILL_CREATOR_SCRIPT = APP_DIR / "sai_waybill_creator.py" if 'APP_DIR' in globals() else Path("sai_waybill_creator.py")
    CACHE_DIR = Path("cache")
    PROFILE_DIR = Path("Profile")

from sai_runtime_paths import (
    APP_DIR,
    ROOT_DIR,
    USER_DATA_DIR,
    LOGS_DIR,
    DB_PATH,
    PRIVATE_CONFIG_PATH,
    ensure_runtime_dirs,
)

import sai_db
import sai_package
import sai_converter
import sai_openai_invoice
import sai_page_orientation
import sai_product_names
import sai_receipt_archive
import sai_catalog_ready
import sai_ready_autostart
import sai_receipt_drafts


def _sai_package_barcodes(value: Any) -> List[str]:
    values = value if isinstance(value, (list, tuple, set)) else re.split(r"[,;\s]+", safe_str(value))
    result: List[str] = []
    for item in values:
        digits = re.sub(r"\D+", "", safe_str(item))
        if digits and digits not in result:
            result.append(digits)
    return result


def _sai_package_item_from_row(row: Dict[str, Any], index: int) -> Dict[str, Any]:
    qty = row.get("qty") if row.get("qty") not in (None, "") else row.get("quantity")
    buy = row.get("buy") if row.get("buy") not in (None, "") else row.get("purchase_price")
    sale = row.get("sale") if row.get("sale") not in (None, "") else row.get("price")
    return {
        "row": int(row.get("source_row") or index + 1),
        "name": safe_str(row.get("name")),
        "quantity": float(qty or 0),
        "unit": normalize_unit(row.get("unit") or "штука"),
        "purchase_price": float(buy or 0),
        "sale_price": float(sale or 0),
        "article": safe_str(row.get("article") or row.get("vendor_code") or row.get("code")),
        "category": safe_str(row.get("category")),
        "barcodes": _sai_package_barcodes(row.get("barcodes") or row.get("barcode_cell")),
        "comment": safe_str(row.get("comment")),
        "issues": [safe_str(value) for value in (row.get("issues") or []) if safe_str(value)],
    }


def _sai_package_match_item(items: List[Dict[str, Any]], row: Dict[str, Any], fallback_index: int) -> Dict[str, Any]:
    source_row = safe_str(row.get("source_row"))
    if source_row:
        for item in items:
            if safe_str(item.get("row")) == source_row:
                return item
    row_barcodes = tuple(sorted(_sai_package_barcodes(row.get("barcodes") or row.get("barcode_cell"))))
    if row_barcodes:
        matches = [item for item in items if tuple(sorted(_sai_package_barcodes(item.get("barcodes")))) == row_barcodes]
        if len(matches) == 1:
            return matches[0]
    if 0 <= fallback_index < len(items):
        return items[fallback_index]
    raise RuntimeError(f"Не удалось сопоставить строку SAI Package: {safe_str(row.get('name'))}")


# ---------------------------------------------------------------------------
# Small utilities
# ---------------------------------------------------------------------------

def safe_str(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    # Make long DB statuses and file names friendlier in compact tables.
    return text.replace("import_required", "нужен импорт").replace("ready", "готово")


def normalize_sigma_login(value: Any) -> str:
    """Store only digits in SIGMA login; Russian leading 8 becomes 7."""
    digits = re.sub(r"\D+", "", safe_str(value))
    if digits.startswith("8"):
        digits = "7" + digits[1:]
    return digits


def bind_sigma_login_editor(edit: QLineEdit) -> None:
    """Keep SIGMA login field numeric while the user types or pastes text."""
    edit.setInputMethodHints(Qt.ImhDigitsOnly)

    def cleanup(text: str) -> None:
        cleaned = normalize_sigma_login(text)
        if cleaned == text:
            return
        pos = edit.cursorPosition()
        edit.blockSignals(True)
        edit.setText(cleaned)
        edit.setCursorPosition(min(len(cleaned), max(0, pos)))
        edit.blockSignals(False)

    edit.textChanged.connect(cleanup)


def short_text(value: Any, max_len: int = 42) -> str:
    text = safe_str(value)
    return text if len(text) <= max_len else text[: max_len - 1] + "…"


def money(value: Any) -> str:
    try:
        return f"{float(value):,.2f}".replace(",", " ")
    except Exception:
        return ""



def quantity_text(value: Any) -> str:
    try:
        number = float(value or 0)
    except Exception:
        return "0"
    if abs(number - round(number)) < 1e-9:
        return str(int(round(number)))
    return (f"{number:.3f}").rstrip("0").rstrip(".").replace(".", ",")

def friendly_dt(value: Any) -> str:
    text = safe_str(value)
    if not text:
        return ""
    # Keep the Hub readable: SQLite stores simple ISO-like timestamps.
    # Examples: 2026-07-04 19:52:04 -> 04.07 19:52
    try:
        date, time = text.split(" ", 1)
        y, m, d = date.split("-", 2)
        hhmm = time[:5]
        return f"{d}.{m} {hhmm}"
    except Exception:
        return short_text(text, 16)


_PRIVATE_CONFIG_LOCK = threading.RLock()
_PRIVATE_CONFIG_LAST_GOOD = USER_DATA_DIR / "backups" / "sai_private_config.last-good.json"
_PRIVATE_SECRET_KEYS = (
    "sigma_login", "sigma_password", "sigma_company_key", "sigma_api_token",
    "sigma_sell_point_id", "sigma_internal_company_id", "storehouse_id",
    "openai_api_key", "openai_model", "openai_api_base",
)


def _with_private_config_defaults(value: Dict[str, Any]) -> Dict[str, Any]:
    """Restore safe operator defaults when an older config lacks newer keys."""
    cfg = dict(value or {})
    # Final documents are expected immediately after a successful receipt.  An
    # explicitly saved False remains respected; only a missing legacy key is
    # repaired.  This also survives config recovery and upgrades.
    cfg.setdefault("auto_print_ndp", True)
    cfg.setdefault("auto_print_price_tags", True)
    cfg.setdefault("github_update_channel", "production")
    return cfg


def _read_private_config_file(path: Path) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig")) or {}
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _atomic_write_private_config(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def _has_sigma_credentials(cfg: Dict[str, Any]) -> bool:
    return all(safe_str(cfg.get(key)) for key in ("sigma_login", "sigma_password", "sigma_company_key", "sigma_api_token"))


def load_private_config() -> Dict[str, Any]:
    with _PRIVATE_CONFIG_LOCK:
        cfg = _read_private_config_file(PRIVATE_CONFIG_PATH) if PRIVATE_CONFIG_PATH.exists() else {}
        backup = _read_private_config_file(_PRIVATE_CONFIG_LAST_GOOD) if _PRIVATE_CONFIG_LAST_GOOD.exists() else {}
        # A settings write or interrupted update must never turn a configured SAI
        # back into a first-launch installation. Recover only missing private values;
        # current non-secret settings always remain authoritative.
        if backup and not _has_sigma_credentials(cfg) and _has_sigma_credentials(backup):
            recovered = False
            for key in _PRIVATE_SECRET_KEYS:
                if not safe_str(cfg.get(key)) and safe_str(backup.get(key)):
                    cfg[key] = backup[key]
                    recovered = True
            if recovered:
                cfg["first_run_setup_done"] = True
                _atomic_write_private_config(PRIVATE_CONFIG_PATH, cfg)
        if cfg.get("sigma_login"):
            cfg["sigma_login"] = normalize_sigma_login(cfg.get("sigma_login"))
        return _with_private_config_defaults(cfg)


def save_private_config_patch(patch: Dict[str, Any]) -> None:
    with _PRIVATE_CONFIG_LOCK:
        ensure_runtime_dirs()
        patch = dict(patch or {})
        if "sigma_login" in patch:
            patch["sigma_login"] = normalize_sigma_login(patch.get("sigma_login"))
        cfg = load_private_config()
        # Empty widgets or a stale process may not erase credentials that are
        # already present. A replacement must contain an actual new value.
        for key in _PRIVATE_SECRET_KEYS:
            if key in patch and not safe_str(patch.get(key)) and safe_str(cfg.get(key)):
                patch.pop(key, None)
        cfg.update(patch)
        _atomic_write_private_config(PRIVATE_CONFIG_PATH, cfg)
        if _has_sigma_credentials(cfg):
            _atomic_write_private_config(_PRIVATE_CONFIG_LAST_GOOD, cfg)


def append_sigma_auth_cli_args(args: List[str], cfg: Dict[str, Any]) -> None:
    options = (("--sigma-login", "sigma_login"), ("--sigma-password", "sigma_password"),
               ("--sigma-legacy-login", "sigma_legacy_login"), ("--sigma-legacy-password", "sigma_legacy_password"))
    for option, key in options:
        value = str(cfg.get(key) or "").strip()
        if value: args += [option, value]
    args += ["--sigma-atol-max-attempts", str(max(1, int(cfg.get("sigma_atol_max_attempts") or 3)))]

def apply_v12119_startup_defaults() -> None:
    """One-time migration: keep SIGMA browser hidden by default for existing installs too."""
    cfg = load_private_config()
    if bool(cfg.get("startup_defaults_v12119_applied", False)):
        return
    save_private_config_patch({
        "browser_visible": False,
        "hidden_browser_auto_visible_after_seconds": 0,
        "startup_defaults_v12119_applied": True,
    })


def apply_v1227av_ready_defaults() -> None:
    """Enable non-blocking SAI Ready catalog warm-up for existing installs."""
    cfg = load_private_config()
    if bool(cfg.get("sai_ready_defaults_v1227av_applied", False)):
        return
    save_private_config_patch({
        "sai_ready_enabled": True,
        "sai_ready_startup_delay_seconds": 45,
        "sai_ready_startup_min_age_minutes": 30,
        "sai_ready_retry_attempts": 4,
        "sai_ready_retry_seconds": 45,
        "catalog_background_refresh_interval_minutes": 360,
        "catalog_force_refresh_on_startup": False,
        "sai_ready_defaults_v1227av_applied": True,
    })
    try:
        sai_ready_autostart.install_autostart(ROOT_DIR)
    except Exception:
        pass


def ensure_private_config_file() -> Path:
    ensure_runtime_dirs()
    if not PRIVATE_CONFIG_PATH.exists():
        PRIVATE_CONFIG_PATH.write_text("{}\n", encoding="utf-8")
    return PRIVATE_CONFIG_PATH


def desktop_dir() -> Path:
    desktop = Path.home() / "Desktop"
    return desktop if desktop.exists() else Path.home()


def open_path(path: Path) -> None:
    path = Path(path)
    if not path.suffix:
        path.mkdir(parents=True, exist_ok=True)
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


def db_rows(query: str, params: tuple = ()) -> List[Dict[str, Any]]:
    if not DB_PATH.exists():
        return []
    try:
        con = sqlite3.connect(str(DB_PATH), timeout=10)
        con.row_factory = sqlite3.Row
        try:
            rows = con.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        finally:
            con.close()
    except Exception:
        return []


def db_scalar(query: str, default: Any = 0) -> Any:
    if not DB_PATH.exists():
        return default
    try:
        con = sqlite3.connect(str(DB_PATH), timeout=10)
        try:
            row = con.execute(query).fetchone()
            return row[0] if row and row[0] is not None else default
        finally:
            con.close()
    except Exception:
        return default


def latest_row(table: str) -> Optional[Dict[str, Any]]:
    rows = db_rows(f"SELECT * FROM {table} ORDER BY id DESC LIMIT 1")
    return rows[0] if rows else None


def find_latest_sai_file() -> Optional[Path]:
    candidates: List[Path] = []
    roots = [Path.home() / "Desktop", Path.home() / "Downloads", Path.cwd()]
    for root in roots:
        if not root.exists():
            continue
        try:
            candidates.extend(root.glob("SAI_*.sai"))
            candidates.extend(root.glob("SAI_*.xml"))
            candidates.extend(root.glob("SAI_*.xlsx"))
            candidates.extend(root.glob("SAI_*.xlsm"))
        except Exception:
            pass
    candidates = [p for p in candidates if p.is_file() and not p.name.startswith("~$")]
    if not candidates:
        return None
    best = max(candidates, key=lambda p: p.stat().st_mtime)
    if best.suffix.lower() in (".xlsx", ".xlsm"):
        package = best.with_suffix(".sai")
        if package.exists() and package.is_file():
            return package
        xml = best.with_suffix(".xml")
        if xml.exists() and xml.is_file():
            return xml
    return best


def infer_date_from_sai_file(path: Path) -> str:
    """Read the receipt date from XML meta first, then from a standalone filename date.

    A remembered date from the previous receipt must never leak into a newly selected
    SAI file. Copies such as ``..._170726 (1).xml`` still resolve to 17.07.2026.
    """
    p = Path(path)
    if p.suffix.lower() == ".sai":
        try:
            summary = sai_package.read_summary(p)
            raw = safe_str(summary.get("date"))
            if raw and date_display_from_text is not None:
                return date_display_from_text(raw)
        except Exception:
            pass
    if p.suffix.lower() == ".xml":
        try:
            root = ET.parse(str(p)).getroot()
            meta = root.find("meta")
            if meta is not None:
                raw = safe_str(meta.findtext("date") or meta.findtext("invoice_date"))
                iso = re.search(r"(?<!\d)(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)", raw)
                if iso:
                    year, month, day = iso.groups()
                    return f"{int(day):02d}.{int(month):02d}.{int(year):04d}"
                if raw and date_display_from_text is not None:
                    return date_display_from_text(raw)
        except Exception:
            pass
    matches = re.findall(r"(?<!\d)(\d{8}|\d{6})(?!\d)", p.stem)
    if matches and date_display_from_text is not None:
        try:
            return date_display_from_text(matches[-1])
        except Exception:
            pass
    return dt.date.today().strftime("%d.%m.%Y")


def latest_api_first_log() -> Optional[Path]:
    if not LOGS_DIR.exists():
        return None
    files = sorted(LOGS_DIR.glob("sigma_api_first_*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


def latest_price_audit_for_log(log_path: Optional[Path]) -> str:
    if not log_path:
        return ""
    p = Path(log_path)
    audit = p.with_name(p.stem.replace("sigma_api_first", "price_audit") + ".xlsx")
    return str(audit) if audit.exists() else ""


def simple_file_history_mark(sai_path: Any, status: str, supplier: str = "", waybill: str = "", import_path: str = "") -> None:
    # Same file-history format as classic SAI uses. It lets repeated checks after import force a live catalog refresh.
    try:
        from sai_app import file_fingerprint, sai_file_history_key, load_sai_file_history, save_sai_file_history
        p = Path(str(sai_path))
        if not p.exists():
            return
        info = file_fingerprint(p)
        key = sai_file_history_key(info)
        data = load_sai_file_history()
        files = data.setdefault("files", {})
        entry = dict(files.get(key) or {})
        entry.update(info)
        entry["status"] = status
        entry["updated_at"] = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry["supplier"] = supplier
        entry["waybill"] = waybill
        if import_path:
            entry["import_path"] = import_path
        if status in ("проверен: все позиции найдены", "приход заполнен"):
            entry.pop("import_path", None)
        files[key] = entry
        save_sai_file_history(data)
    except Exception:
        pass


class WorkerSignals(QObject):
    log = Signal(str)
    check_done = Signal(dict)
    check_error = Signal(str)



class SigmaImportSignals(QObject):
    log = Signal(str)
    done = Signal(dict)
    error = Signal(str)


def load_sigma_categories_static(cfg: Optional[Dict[str, Any]] = None) -> List[Dict[str, str]]:
    """Read SIGMA product categories through the stable X-Api-Key API."""
    cfg = dict(cfg or load_private_config())
    company = safe_str(cfg.get("sigma_company_key"))
    token = safe_str(cfg.get("sigma_api_token"))
    sell_point_id = safe_str(cfg.get("sigma_sell_point_id"))
    if not company or not token:
        return []
    try:
        import requests
        base = f"https://api.sigma.ru/v1/companies/{company}"
        headers = {"Accept": "application/json", "X-Api-Key": token, "User-Agent": f"SAI-Hub/{APP_VERSION}"}
        params = {"sellPointId": sell_point_id} if sell_point_id else None
        resp = requests.get(base + "/product-categories", headers=headers, params=params, timeout=20)
        if not (200 <= resp.status_code < 300):
            return []
        out: List[Dict[str, str]] = []
        seen = set()
        for item in _collect_api_items(resp.json()):
            name = safe_str(item.get("name") or item.get("title") or item.get("displayName"))
            cid = safe_str(item.get("id") or item.get("uuid"))
            if not name:
                continue
            key = name.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append({"id": cid, "name": name})
        return sorted(out, key=lambda x: _free_norm(x.get("name")))
    except Exception:
        return []


def _xlsx_header_map(ws) -> Dict[str, int]:
    headers: Dict[str, int] = {}
    for cell in ws[1]:
        text = safe_str(cell.value).lower().replace("ё", "е")
        if text:
            headers[text] = int(cell.column)
    return headers


def _xlsx_pick(headers: Dict[str, int], *names: str) -> int:
    for name in names:
        key = safe_str(name).lower().replace("ё", "е")
        if key in headers:
            return headers[key]
    for key, col in headers.items():
        for name in names:
            if safe_str(name).lower().replace("ё", "е") in key:
                return col
    return 0


def read_import_xlsx_category_rows(path: str | Path) -> List[Dict[str, Any]]:
    """Rows in SIGMA import XLSX that still require a product category."""
    if load_workbook is None:
        raise RuntimeError("openpyxl недоступен, XLSX импорта прочитать нельзя.")
    wb = load_workbook(str(path), data_only=False)
    ws = wb[wb.sheetnames[0]]
    headers = _xlsx_header_map(ws)
    c_name = _xlsx_pick(headers, "Наименование")
    c_article = _xlsx_pick(headers, "Артикул")
    c_unit = _xlsx_pick(headers, "Единица измерения", "Ед")
    c_barcode = _xlsx_pick(headers, "Штрихкод", "ШК")
    c_category = _xlsx_pick(headers, "Категория")
    c_price = _xlsx_pick(headers, "Цена")
    if not c_name or not c_category:
        return []
    rows: List[Dict[str, Any]] = []
    for excel_row in range(2, ws.max_row + 1):
        name = safe_str(ws.cell(excel_row, c_name).value)
        if not name:
            continue
        category = safe_str(ws.cell(excel_row, c_category).value)
        if category:
            continue
        rows.append({
            "excel_row": excel_row,
            "name": name,
            "article": safe_str(ws.cell(excel_row, c_article).value) if c_article else "",
            "unit": safe_str(ws.cell(excel_row, c_unit).value) if c_unit else "штука",
            "barcode": safe_str(ws.cell(excel_row, c_barcode).value) if c_barcode else "",
            "price": ws.cell(excel_row, c_price).value if c_price else "",
        })
    return rows


def persist_import_xlsx_category(path: str | Path, excel_row: int, category: str) -> None:
    """Atomically save one confirmed category without waiting for the whole wizard."""
    if load_workbook is None:
        raise RuntimeError("openpyxl недоступен, категорию сохранить нельзя.")
    target = Path(path)
    temporary = target.with_name(target.stem + ".category.tmp" + target.suffix)
    workbook = load_workbook(str(target))
    try:
        sheet = workbook[workbook.sheetnames[0]]
        category_column = _xlsx_pick(_xlsx_header_map(sheet), "Категория")
        row_number = int(excel_row or 0)
        value = safe_str(category)
        if not category_column:
            raise RuntimeError("В XLSX импорта нет колонки «Категория».")
        if row_number < 2 or row_number > sheet.max_row or not value:
            raise RuntimeError("Не удалось определить товар или выбранную категорию.")
        sheet.cell(row_number, category_column).value = value
        workbook.save(str(temporary))
        os.replace(temporary, target)
    finally:
        workbook.close()
        try:
            temporary.unlink(missing_ok=True)
        except Exception:
            pass


def _import_xlsx_row_has_product(ws, row: int, headers: Dict[str, int]) -> bool:
    """True only for real SIGMA import product rows.

    The import template may contain styled empty rows.  They must stay empty or be
    removed completely; otherwise SIGMA sees phantom products with only unit/VAT/type.
    """
    c_name = _xlsx_pick(headers, "Наименование")
    if c_name and safe_str(ws.cell(row, c_name).value):
        return True
    # Fallback for damaged/renamed headers: keep a row only if it has meaningful
    # product identity, not just defaults like «штука», «Без НДС», «Обычный товар».
    meaningful_cols = [
        _xlsx_pick(headers, "Артикул"),
        _xlsx_pick(headers, "Штрихкод", "ШК"),
        _xlsx_pick(headers, "Категория"),
        _xlsx_pick(headers, "Цена"),
    ]
    return any(c and safe_str(ws.cell(row, c).value) for c in meaningful_cols)


def trim_import_xlsx_to_product_rows(ws, headers: Dict[str, int]) -> None:
    """Delete all blank/template rows below the header from SIGMA import XLSX."""
    for excel_row in range(ws.max_row, 1, -1):
        if not _import_xlsx_row_has_product(ws, excel_row, headers):
            ws.delete_rows(excel_row, 1)


def patch_import_xlsx_for_sigma(path: str | Path, categories_by_row: Dict[int, str]) -> None:
    """Apply categories and canonical SIGMA constants only to real product rows."""
    if load_workbook is None:
        raise RuntimeError("openpyxl недоступен, XLSX импорта изменить нельзя.")
    p = Path(path)
    wb = load_workbook(str(p))
    ws = wb[wb.sheetnames[0]]
    headers = _xlsx_header_map(ws)
    c_category = _xlsx_pick(headers, "Категория")
    c_vat = _xlsx_pick(headers, "НДС")
    c_type = _xlsx_pick(headers, "Тип")
    c_unit = _xlsx_pick(headers, "Единица измерения", "Ед")
    if not c_category:
        raise RuntimeError("В XLSX импорта нет колонки «Категория».")

    # First write category assignments to their original rows.
    for excel_row, category in (categories_by_row or {}).items():
        try:
            excel_row = int(excel_row)
        except Exception:
            continue
        if excel_row >= 2 and excel_row <= ws.max_row:
            ws.cell(excel_row, c_category).value = safe_str(category)

    # Remove empty template rows before filling defaults.  This prevents rows that
    # contain only «штука» / «Без НДС» / «Обычный товар».
    headers = _xlsx_header_map(ws)
    trim_import_xlsx_to_product_rows(ws, headers)
    headers = _xlsx_header_map(ws)
    c_vat = _xlsx_pick(headers, "НДС")
    c_type = _xlsx_pick(headers, "Тип")
    c_unit = _xlsx_pick(headers, "Единица измерения", "Ед")

    for excel_row in range(2, ws.max_row + 1):
        if not _import_xlsx_row_has_product(ws, excel_row, headers):
            continue
        if c_vat:
            ws.cell(excel_row, c_vat).value = "Без НДС"
        if c_type:
            ws.cell(excel_row, c_type).value = "Обычный товар"
        if c_unit:
            unit = safe_str(ws.cell(excel_row, c_unit).value) or "штука"
            try:
                ws.cell(excel_row, c_unit).value = normalize_unit(unit)
            except Exception:
                ws.cell(excel_row, c_unit).value = "штука"
    wb.save(str(p))
    try:
        from sai_app import make_xlsx_sigma_compatible
        make_xlsx_sigma_compatible(p)
    except Exception:
        pass


def sigma_import_xlsx_via_cloud(import_path: str | Path, cfg: Dict[str, Any], log_callback=None) -> Dict[str, Any]:
    """Upload and commit SIGMA universal import XLSX through the cloud API using the existing browser profile.

    Важно: импорт новых товаров — это cloud endpoint SIGMA, а не обычный X-Api-Key API.
    Реальный HAR пользователя показывает upload на api-s07.sigma.ru. Поэтому основной путь
    выполняется прямо из браузерной страницы cloud.sigma.ru через JS fetch: так запрос получается
    максимально похожим на тот, который делает сама SIGMA, и не сваливается в api.sigma.ru.
    """
    p = Path(import_path)
    if not p.exists():
        raise RuntimeError(f"Файл импорта не найден: {p}")
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        raise RuntimeError("Playwright недоступен, автоматический импорт невозможен.") from exc

    def log(msg: str) -> None:
        if log_callback:
            try:
                log_callback(str(msg))
            except Exception:
                pass

    def short_text(value: Any, limit: int = 500) -> str:
        text = safe_str(value).replace("\r", " ").replace("\n", " ").strip()
        return text[:limit]

    def normalize_host(host: Any) -> str:
        h = safe_str(host).strip()
        h = h.replace("https://", "").replace("http://", "").strip("/")
        return h

    runtime_token = ""
    runtime_api_host = ""
    try:
        from sai_api_first_apply import load_runtime_token_cache_payload
        runtime_auth = load_runtime_token_cache_payload(max_age_seconds=4 * 3600)
        runtime_token = safe_str(runtime_auth.get("token"))
        runtime_api_host = normalize_host(runtime_auth.get("api_base"))
    except Exception:
        runtime_auth = {}

    # HAR from real SIGMA import uses api-s07.sigma.ru. api.sigma.ru answers 404 for this endpoint.
    saved_host = normalize_host(cfg.get("sigma_import_api_host") or cfg.get("sigma_cloud_api_host"))
    menu_id = safe_str(cfg.get("sigma_import_menu_id") or "ade982a9-c5c9-4986-a66a-1f17db1d3744")
    candidates: List[str] = []
    for host in [runtime_api_host, saved_host, "api-s07.sigma.ru", "api-s06.sigma.ru", "api-s08.sigma.ru"]:
        host = normalize_host(host)
        if host and host not in candidates and host != "api.sigma.ru":
            candidates.append(host)
    # api.sigma.ru оставляем только как последний диагностический fallback, чтобы больше не прятать правильную ошибку.
    if "api.sigma.ru" not in candidates:
        candidates.append("api.sigma.ru")

    file_b64 = base64.b64encode(p.read_bytes()).decode("ascii")
    mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    with sync_playwright() as pw:
        launch_kwargs = {
            "headless": not bool(cfg.get("browser_visible", False)),
            "accept_downloads": True,
            "args": direct_chromium_args(),
        }
        ctx = pw.chromium.launch_persistent_context(str(PROFILE_DIR), **launch_kwargs)
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            try:
                page.set_default_timeout(90000)
            except Exception:
                pass
            try:
                page.goto("https://cloud.sigma.ru", wait_until="domcontentloaded", timeout=45000)
            except Exception:
                pass
            try:
                page.wait_for_load_state("networkidle", timeout=10000)
            except Exception:
                pass

            js_upload = """
                async ({host, filename, mime, b64, token}) => {
                    const bin = atob(b64);
                    const bytes = new Uint8Array(bin.length);
                    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
                    const form = new FormData();
                    form.append('file', new File([bytes], filename, {type: mime}));
                    form.append('type', 'PRICE_MATRIX');
                    const url = `https://${host}/rest/v3/imports/universal/file/upload`;
                    const headers = {'Accept': 'application/json, text/plain, */*'};
                    if (token) headers['Authorization'] = `Bearer ${token}`;
                    const resp = await fetch(url, {
                        method: 'POST',
                        body: form,
                        credentials: 'include',
                        headers
                    });
                    const text = await resp.text();
                    let json = null;
                    try { json = JSON.parse(text); } catch (e) {}
                    return {ok: resp.ok, status: resp.status, text, json, url};
                }
            """
            js_post = """
                async ({url, token}) => {
                    const headers = {'Accept': 'application/json, text/plain, */*'};
                    if (token) headers['Authorization'] = `Bearer ${token}`;
                    const resp = await fetch(url, {
                        method: 'POST',
                        credentials: 'include',
                        headers
                    });
                    const text = await resp.text();
                    let json = null;
                    try { json = JSON.parse(text); } catch (e) {}
                    return {ok: resp.ok, status: resp.status, text, json, url};
                }
            """
            js_get = """
                async ({url, token}) => {
                    const headers = {'Accept': 'application/json, text/plain, */*'};
                    if (token) headers['Authorization'] = `Bearer ${token}`;
                    const resp = await fetch(url, {
                        method: 'GET',
                        credentials: 'include',
                        headers
                    });
                    const text = await resp.text();
                    let json = null;
                    try { json = JSON.parse(text); } catch (e) {}
                    return {ok: resp.ok, status: resp.status, text, json, url};
                }
            """

            upload_payload = None
            api_host = ""
            errors: List[str] = []
            if runtime_token:
                log(f"SIGMA import: использую свежую авторизацию черновика ({runtime_api_host or 'SIGMA API'}).")
            for host in candidates:
                log(f"SIGMA import: загружаю XLSX через {host}…")
                # Main route: real browser fetch from cloud.sigma.ru.
                try:
                    result = page.evaluate(
                        js_upload,
                        {"host": host, "filename": p.name, "mime": mime, "b64": file_b64, "token": runtime_token},
                    )
                    status = int(result.get("status") or 0)
                    if result.get("ok") and isinstance(result.get("json"), dict):
                        upload_payload = result.get("json")
                        api_host = host
                        try:
                            save_private_config_patch({"sigma_import_api_host": host, "sigma_import_menu_id": menu_id})
                        except Exception:
                            pass
                        break
                    errors.append(f"{host} через browser fetch: HTTP {status} {short_text(result.get('text'))}")
                except Exception as exc:
                    errors.append(f"{host} через browser fetch: {short_text(exc)}")

                # Safety fallback: Playwright request context with explicit browser-like headers.
                try:
                    url = f"https://{host}/rest/v3/imports/universal/file/upload"
                    request_headers = {
                        "Accept": "application/json, text/plain, */*",
                        "Origin": "https://cloud.sigma.ru",
                        "Referer": "https://cloud.sigma.ru/",
                    }
                    if runtime_token:
                        request_headers["Authorization"] = "Bearer " + runtime_token
                    resp = ctx.request.post(
                        url,
                        headers=request_headers,
                        multipart={
                            "file": {
                                "name": p.name,
                                "mimeType": mime,
                                "buffer": p.read_bytes(),
                            },
                            "type": "PRICE_MATRIX",
                        },
                        timeout=90000,
                    )
                    if 200 <= resp.status < 300:
                        upload_payload = resp.json()
                        api_host = host
                        try:
                            save_private_config_patch({"sigma_import_api_host": host, "sigma_import_menu_id": menu_id})
                        except Exception:
                            pass
                        break
                    errors.append(f"{host} через request: HTTP {resp.status} {short_text(resp.text())}")
                except Exception as exc:
                    errors.append(f"{host} через request: {short_text(exc)}")

            if not upload_payload:
                details = "; ".join(errors[-8:]) or "нет подробностей"
                raise RuntimeError("SIGMA не приняла XLSX импорта. Проверенные адреса: " + details)

            task_id = safe_str(upload_payload.get("id"))
            if not task_id:
                raise RuntimeError("SIGMA загрузила файл, но не вернула id задачи.")

            commit_url = f"https://{api_host}/rest/v3/imports/universal/task/{task_id}/commit?menuId={menu_id}"
            log(f"SIGMA import: подтверждаю задачу {task_id} через {api_host}…")
            commit_result = None
            try:
                commit_result = page.evaluate(js_post, {"url": commit_url, "token": runtime_token})
            except Exception as exc:
                commit_result = {"ok": False, "status": 0, "text": short_text(exc), "url": commit_url}
            if not commit_result.get("ok"):
                # request fallback for commit
                try:
                    request_headers = {
                        "Accept": "application/json, text/plain, */*",
                        "Origin": "https://cloud.sigma.ru",
                        "Referer": "https://cloud.sigma.ru/",
                    }
                    if runtime_token:
                        request_headers["Authorization"] = "Bearer " + runtime_token
                    commit = ctx.request.post(
                        commit_url,
                        headers=request_headers,
                        timeout=60000,
                    )
                    if commit.status not in (200, 201, 202, 204):
                        raise RuntimeError(f"HTTP {commit.status}: {commit.text()[:300]}")
                except Exception as exc:
                    raise RuntimeError(f"SIGMA commit вернул ошибку: {commit_result.get('status')} {short_text(commit_result.get('text'))}; fallback: {short_text(exc)}")

            status_url = f"https://{api_host}/rest/v3/imports/universal/task/{task_id}"
            payload = upload_payload
            deadline = time.time() + 180
            while time.time() < deadline:
                time.sleep(2)
                result = None
                try:
                    result = page.evaluate(js_get, {"url": status_url, "token": runtime_token})
                except Exception:
                    result = None
                if not result or not result.get("ok"):
                    try:
                        request_headers = {
                            "Accept": "application/json, text/plain, */*",
                            "Origin": "https://cloud.sigma.ru",
                            "Referer": "https://cloud.sigma.ru/",
                        }
                        if runtime_token:
                            request_headers["Authorization"] = "Bearer " + runtime_token
                        st = ctx.request.get(
                            status_url,
                            headers=request_headers,
                            timeout=30000,
                        )
                        if not (200 <= st.status < 300):
                            continue
                        payload = st.json()
                    except Exception:
                        continue
                else:
                    payload = result.get("json") or {}
                status = safe_str(payload.get("status"))
                progress = payload.get("progress") or {}
                log(f"SIGMA import: {status} · обработано {progress.get('processed', 0)}/{progress.get('total', 0)}")
                if status.upper() == "DONE":
                    return payload
                if status.upper() in {"ERROR", "FAILED", "CANCELED", "CANCELLED"}:
                    raise RuntimeError(f"Импорт SIGMA остановился со статусом {status}: {payload}")
            raise RuntimeError("SIGMA импорт не завершился за 180 секунд.")
        finally:
            try:
                ctx.close()
            except Exception:
                pass

class BackgroundCatalogSignals(QObject):
    finished = Signal(bool, str)


class OrganizationSyncSignals(QObject):
    finished = Signal(object, bool)


class GithubUpdateSignals(QObject):
    checked = Signal(object, str, bool)
    downloaded = Signal(object, str)


# ---------------------------------------------------------------------------
# UI components
# ---------------------------------------------------------------------------

class SplashPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("SplashPage")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.phase = 0
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(10)
        layout.addStretch(1)

        title = QLabel("SAI — мастер приёмки SIGMA")
        title.setObjectName("SplashTitle")
        title.setAttribute(Qt.WA_TranslucentBackground, True)
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont("Segoe UI", 22, QFont.Bold))
        layout.addWidget(title)

        version = QLabel(APP_VERSION)
        version.setObjectName("SplashVersion")
        version.setAttribute(Qt.WA_TranslucentBackground, True)
        version.setAlignment(Qt.AlignCenter)
        version.setFont(QFont("Segoe UI", 10))
        layout.addWidget(version)

        self.dots = QLabel("●  ○  ○")
        self.dots.setObjectName("SplashDots")
        self.dots.setAttribute(Qt.WA_TranslucentBackground, True)
        self.dots.setAlignment(Qt.AlignCenter)
        self.dots.setFont(QFont("Segoe UI", 18))
        layout.addWidget(self.dots)
        layout.addStretch(1)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(180)

    def tick(self) -> None:
        variants = ["●  ○  ○", "○  ●  ○", "○  ○  ●", "○  ●  ○"]
        self.phase = (self.phase + 1) % len(variants)
        self.dots.setText(variants[self.phase])


class MetricCard(QFrame):
    def __init__(self, title: str, value: str = "—", hint: str = "", tone: str = "blue") -> None:
        super().__init__()
        self.setObjectName("MetricCard")
        self.tone = tone
        self.setMinimumSize(150, 112)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(5)

        top = QHBoxLayout()
        self.dot = QLabel("●")
        self.dot.setObjectName(f"Dot_{tone}")
        self.title_label = QLabel(title)
        self.title_label.setObjectName("CardTitle")
        top.addWidget(self.dot)
        top.addWidget(self.title_label)
        top.addStretch(1)
        layout.addLayout(top)

        self.value_label = QLabel(value)
        self.value_label.setObjectName("CardValue")
        self.value_label.setMinimumHeight(38)
        self.value_label.setWordWrap(False)
        layout.addWidget(self.value_label)

        self.hint_label = QLabel(hint)
        self.hint_label.setObjectName("CardHint")
        self.hint_label.setMinimumHeight(30)
        self.hint_label.setWordWrap(True)
        layout.addWidget(self.hint_label)

    def set_value(self, value: str, hint: str = "") -> None:
        self.value_label.setText(value)
        self.hint_label.setText(hint)


class StepPill(QFrame):
    def __init__(self, number: str, text: str) -> None:
        super().__init__()
        self.setObjectName("StepPill")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(8)
        n = QLabel(number)
        n.setObjectName("StepNumber")
        label = QLabel(text)
        label.setObjectName("StepText")
        layout.addWidget(n)
        layout.addWidget(label)
        layout.addStretch(1)



class WorkbenchPage(QWidget):
    """Qt-native receiving workbench.

    v1.20.11 stores SIGMA import prices as numeric cells with one decimal place (0.0), which matches the importer behavior observed in SIGMA.
    v1.20.7 fixes the action panel so buttons stay in one predictable group:
    SAI-file -> draft -> product check/import -> fact -> APPLY -> NDP.
    The classic Tkinter SAI remains only as an explicit emergency fallback.
    """
    def __init__(self, parent_page: "MainPage") -> None:
        super().__init__()
        self.parent_page = parent_page
        self.sai_path: Optional[Path] = None
        self.sheet_name: str = "Для робота SIGMA"
        self.source_rows: List[Dict[str, Any]] = []
        self.last_check_result: Dict[str, Any] = {}
        self.waybill_id: str = ""
        self.storehouse_id: str = ""
        self.supplier_id: str = ""
        self.supplier_list: List[Dict[str, Any]] = []
        self.pending_supplier_name: str = ""
        self.suppliers_proc: QProcess | None = None
        self.suppliers_buffer: str = ""
        self.suppliers_finished_callback = None
        self.suppliers_manual_login: bool = False
        self.supplier_combo: QComboBox | None = None
        self.supplier_reload_btn: QPushButton | None = None
        self.last_log_path: str = ""
        self.created_import_path: str = ""
        self.barcode_update_path: str = ""
        self.processing_sai_path: str = ""
        self.zero_qty_skipped_count: int = 0
        self.price_preview_done: bool = False
        self.price_preview_log_path: str = ""
        self.price_proc: QProcess | None = None
        self.last_effective_sai_path: str = ""
        self.approved_source_backup_path: str = ""
        self.fact_source_backup_path: str = ""
        self.fact_persisted: bool = False
        self.manual_price_approval_used: bool = False
        self.approved_ndp_path: str = ""
        self.price_approval_document_path: str = ""
        self.current_apply_run_id: int = 0
        self._final_print_in_progress: bool = False
        self._last_final_print_apply_run_id: int = 0
        self._last_final_print_at: float = 0.0
        self.final_document_source_path: str = ""
        self.barcode_fix_rows: List[int] = []
        self.barcode_fix_continue_mode: str = ""
        self.catalog_refreshed_this_session: bool = False
        self.import_category_memory: Dict[str, str] = load_import_category_memory()
        self.awaiting_post_import_verification: bool = False
        self.post_import_retry_count: int = 0
        self.workflow_products_used: bool = False
        self.proc: QProcess | None = None
        self.running: bool = False
        self.autosave_timer: QTimer | None = None
        self.build_ui()
        # The release hub is the only entry point for a new receipt. It finds
        # the freshest SAI file and routes it before this processing stage opens.
        # StartupGate performs the initial SIGMA login/check first. Suppliers
        # are loaded after that, so there are no parallel Playwright logins.

    # ---------- UI ----------
    def build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.workbench_scroll = QScrollArea()
        self.workbench_scroll.setObjectName("WorkbenchScroll")
        self.workbench_scroll.setWidgetResizable(True)
        self.workbench_scroll.setFrameShape(QFrame.NoFrame)
        self.workbench_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.workbench_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(self.workbench_scroll, 1)

        body = QWidget()
        body.setObjectName("WorkbenchBody")
        self.workbench_scroll.setWidget(body)

        root = QVBoxLayout(body)
        root.setContentsMargins(22, 18, 22, 18)
        root.setSpacing(12)

        # Receiving is intentionally split into two calm, sequential screens.
        # The operator first checks the prepared file and parameters, then
        # confirms them and sees only the live SIGMA workflow and final fact.
        self.workbench_stack = QStackedWidget()
        self.workbench_stack.setObjectName("WorkbenchStageStack")
        self.setup_stage = QWidget()
        self.setup_stage.setObjectName("WorkbenchSetupStage")
        setup_layout = QVBoxLayout(self.setup_stage)
        setup_layout.setContentsMargins(0, 0, 0, 0)
        setup_layout.setSpacing(12)
        self.workflow_stage = QWidget()
        self.workflow_stage.setObjectName("WorkbenchWorkflowStage")
        workflow_layout = QVBoxLayout(self.workflow_stage)
        workflow_layout.setContentsMargins(0, 0, 0, 0)
        workflow_layout.setSpacing(12)
        self.workbench_stack.addWidget(self.setup_stage)
        self.workbench_stack.addWidget(self.workflow_stage)
        root.addWidget(self.workbench_stack, 1)

        # Only operator decisions belong here: supplier and receipt date.
        file_card = QFrame(); file_card.setObjectName("WorkbenchCard"); file_card.setMinimumHeight(100); file_card.setMaximumHeight(116)
        file_layout = QVBoxLayout(file_card); file_layout.setContentsMargins(18, 14, 18, 14); file_layout.setSpacing(7)
        self.file_label = QLabel("Файл ещё не выбран")
        self.file_label.hide()
        params = QGridLayout(); params.setHorizontalSpacing(12); params.setVerticalSpacing(8)
        cfg = self.load_shared_config()
        self.pending_supplier_name = str(cfg.get("supplier_choice") or cfg.get("supplier") or "").strip()

        self.supplier_combo = QComboBox(); self.supplier_combo.setObjectName("WorkbenchCombo")
        self.supplier_combo.setEditable(False)
        self.supplier_combo.setMinimumHeight(42)
        self.supplier_combo.addItem("Загружаю поставщиков SIGMA…", "")
        self.supplier_combo.setEnabled(False)
        self.supplier_combo.currentIndexChanged.connect(self.supplier_selection_changed)

        self.date_edit = QLineEdit(); self.date_edit.setObjectName("WorkbenchInput")
        self.date_edit.setPlaceholderText("дд.мм.гггг")
        self.date_edit.setText(str(cfg.get("invoice_date") or ""))
        self.date_edit.textChanged.connect(lambda *_: self.schedule_autosave())
        params.addWidget(QLabel("Поставщик SIGMA"), 0, 0)
        params.addWidget(self.supplier_combo, 1, 0)
        params.addWidget(QLabel("Дата"), 0, 1)
        params.addWidget(self.date_edit, 1, 1)
        params.setColumnStretch(0, 2); params.setColumnStretch(1, 1)
        self.supplier_reload_btn = None
        file_layout.addLayout(params)
        setup_layout.addWidget(file_card)

        # Preview
        preview_card = QFrame(); preview_card.setObjectName("WorkbenchCard"); preview_card.setMinimumHeight(126); preview_card.setMaximumHeight(144)
        preview_layout = QGridLayout(preview_card); preview_layout.setContentsMargins(16, 12, 16, 12); preview_layout.setHorizontalSpacing(10); preview_layout.setVerticalSpacing(6)
        section = QLabel("Предпросмотр")
        section.setObjectName("WorkbenchSection")
        preview_layout.addWidget(section, 0, 0, 1, 4)
        self.rows_metric = MetricCard("Строк", "—", "", "blue")
        self.buy_metric = MetricCard("Закупка", "—", "", "amber")
        self.sale_metric = MetricCard("Продажа", "—", "", "green")
        self.date_metric = MetricCard("Дата", "—", "", "purple")
        for card in (self.rows_metric, self.buy_metric, self.sale_metric, self.date_metric):
            card.setMinimumSize(130, 76)
            card.setMaximumHeight(80)
            card.layout().setContentsMargins(12, 8, 12, 8)
            card.layout().setSpacing(2)
            card.value_label.setMinimumHeight(26)
            card.hint_label.hide()
        for col in range(4):
            preview_layout.setColumnStretch(col, 1); preview_layout.setColumnMinimumWidth(col, 130)
        preview_layout.addWidget(self.rows_metric, 1, 0)
        preview_layout.addWidget(self.buy_metric, 1, 1)
        preview_layout.addWidget(self.sale_metric, 1, 2)
        preview_layout.addWidget(self.date_metric, 1, 3)
        setup_layout.addWidget(preview_card)

        setup_actions = QHBoxLayout()
        setup_actions.addStretch(1)
        self.confirm_setup_btn = QPushButton("Подтвердить и продолжить")
        self.confirm_setup_btn.setObjectName("WorkbenchPrimaryButton")
        self.confirm_setup_btn.setMinimumHeight(46)
        self.confirm_setup_btn.setMinimumWidth(260)
        self.confirm_setup_btn.setEnabled(False)
        self.confirm_setup_btn.clicked.connect(self.confirm_setup_and_start)
        setup_actions.addWidget(self.confirm_setup_btn)
        setup_layout.addLayout(setup_actions)
        setup_layout.addStretch(1)

        # Actions
        action_card = QFrame(); action_card.setObjectName("WorkbenchCard"); action_card.setMinimumHeight(250); action_card.setMaximumHeight(330)
        action_layout = QVBoxLayout(action_card); action_layout.setContentsMargins(18, 14, 18, 14); action_layout.setSpacing(8)
        section2 = QLabel("Рабочий процесс")
        section2.setObjectName("WorkbenchSection")
        self.workflow_tracker = ReceiptWorkflowTracker()
        self.inline_status = QLabel("Открой SAI-файл, чтобы начать обработку прихода.")
        self.inline_status.setObjectName("InlineStatus"); self.inline_status.setWordWrap(True)
        self.actions_grid = QGridLayout()
        self.actions_grid.setHorizontalSpacing(10)
        self.actions_grid.setVerticalSpacing(10)
        self.create_btn = QPushButton("Создать черновик и проверить")
        self.create_btn.setObjectName("WorkbenchPrimaryButton"); self.create_btn.setMinimumHeight(46); self.create_btn.clicked.connect(self.create_waybill_and_check)
        self.create_btn.setProperty("hide_when_disabled", True)

        self.fix_barcodes_btn = QPushButton("Сохранить ШК и продолжить")
        self.fix_barcodes_btn.setObjectName("WorkbenchPrimaryButton"); self.fix_barcodes_btn.setMinimumHeight(46); self.fix_barcodes_btn.clicked.connect(self.save_missing_barcodes_and_continue); self.fix_barcodes_btn.setEnabled(False)
        self.fix_barcodes_btn.setProperty("hide_when_disabled", True)

        self.imported_btn = QPushButton("Импорт выполнен — обновить и проверить")
        self.imported_btn.setObjectName("SoftButton"); self.imported_btn.setMinimumHeight(42); self.imported_btn.clicked.connect(self.confirm_manual_import); self.imported_btn.setEnabled(False)
        self.imported_btn.setProperty("hide_when_disabled", True)

        self.import_later_btn = QPushButton("Продолжить позже")
        self.import_later_btn.setObjectName("SoftButton")
        self.import_later_btn.setMinimumHeight(42)
        self.import_later_btn.clicked.connect(self.continue_import_later)
        self.import_later_btn.setEnabled(False)
        self.import_later_btn.setProperty("hide_when_disabled", True)

        self.conflict_file_btn = QPushButton("Открыть список конфликтов")
        self.conflict_file_btn.setObjectName("SoftButton"); self.conflict_file_btn.setMinimumHeight(42); self.conflict_file_btn.clicked.connect(self.open_conflict_report); self.conflict_file_btn.setEnabled(False)
        self.conflict_file_btn.setProperty("hide_when_disabled", True)

        self.conflict_continue_btn = QPushButton("Исправлено — проверить и продолжить")
        self.conflict_continue_btn.setObjectName("WorkbenchPrimaryButton"); self.conflict_continue_btn.setMinimumHeight(46); self.conflict_continue_btn.clicked.connect(self.continue_after_conflict); self.conflict_continue_btn.setEnabled(False)
        self.conflict_continue_btn.setProperty("hide_when_disabled", True)

        self.fact_btn = QPushButton("Факт приёмки")
        self.fact_btn.setObjectName("SoftButton"); self.fact_btn.setMinimumHeight(42); self.fact_btn.clicked.connect(self.show_fact_table); self.fact_btn.setEnabled(False)
        self.fact_btn.setProperty("hide_when_disabled", True)

        self.price_approval_btn = QPushButton("Подготовить накладную на согласование")
        self.price_approval_btn.setObjectName("WorkbenchPrimaryButton"); self.price_approval_btn.setMinimumHeight(46); self.price_approval_btn.clicked.connect(self.start_price_approval); self.price_approval_btn.setEnabled(False)
        self.price_approval_btn.setProperty("hide_when_disabled", True)

        self.approved_ndp_btn = QPushButton("Сохранить согласованную накладную")
        self.approved_ndp_btn.setObjectName("SoftButton"); self.approved_ndp_btn.setMinimumHeight(42); self.approved_ndp_btn.clicked.connect(self.save_approved_ndp); self.approved_ndp_btn.setEnabled(False)
        self.approved_ndp_btn.setProperty("hide_when_disabled", True)

        self.apply_btn = QPushButton("Ввести приход")
        self.apply_btn.setObjectName("WorkbenchPrimaryButton"); self.apply_btn.setMinimumHeight(46); self.apply_btn.clicked.connect(self.apply_waybill); self.apply_btn.setEnabled(False)
        self.apply_btn.setProperty("hide_when_disabled", True)

        self.ndp_btn = QPushButton("Печатать НДП и Ценники")
        self.ndp_btn.setObjectName("WorkbenchPrimaryButton"); self.ndp_btn.setMinimumHeight(46); self.ndp_btn.clicked.connect(self.print_final_documents); self.ndp_btn.setEnabled(False)
        self.ndp_btn.setProperty("hide_when_disabled", True)


        # Keep action buttons in one dynamic grid. Hidden buttons are removed from
        # the layout instead of leaving empty cells, so the panel does not "wander".
        self.action_buttons_order = [
            self.create_btn,
            self.fix_barcodes_btn,
            self.imported_btn,
            self.import_later_btn,
            self.conflict_file_btn,
            self.conflict_continue_btn,
            self.price_approval_btn,
            self.apply_btn,
            self.ndp_btn,
        ]
        # Fact acceptance is shown directly in the table after product checking.
        # The separate Fact and Save-approved-invoice buttons were ambiguous and
        # are intentionally not part of the workflow anymore.
        self.fact_btn.hide()
        self.approved_ndp_btn.hide()
        for btn in self.action_buttons_order:
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        for col in range(3):
            self.actions_grid.setColumnStretch(col, 1)
            self.actions_grid.setColumnMinimumWidth(col, 190)
        action_layout.addWidget(section2)
        action_layout.addWidget(self.workflow_tracker)
        action_layout.addWidget(self.inline_status)
        action_layout.addLayout(self.actions_grid)
        workflow_layout.addWidget(action_card, 0)

        # Logical enabled state is separate from Qt enabled state, so operations can disable everything while running.
        self.create_btn.setProperty("logical_enabled", False)
        self.fix_barcodes_btn.setProperty("logical_enabled", False)
        self.imported_btn.setProperty("logical_enabled", False)
        self.import_later_btn.setProperty("logical_enabled", False)
        self.conflict_file_btn.setProperty("logical_enabled", False)
        self.conflict_continue_btn.setProperty("logical_enabled", False)
        self.fact_btn.setProperty("logical_enabled", False)
        self.price_approval_btn.setProperty("logical_enabled", False)
        self.approved_ndp_btn.setProperty("logical_enabled", False)
        self.apply_btn.setProperty("logical_enabled", False)
        self.ndp_btn.setProperty("logical_enabled", False)
        for _btn in (self.fix_barcodes_btn, self.imported_btn, self.import_later_btn, self.conflict_file_btn, self.conflict_continue_btn, self.fact_btn, self.price_approval_btn, self.approved_ndp_btn, self.apply_btn, self.ndp_btn):
            _btn.hide()
        self.rebuild_action_buttons()

        # Receipt/fact table. It is hidden until it becomes useful.
        self.result_table = RoundedTableWidget(0, 10)
        self.result_table.setObjectName("ReceiptTable")
        result_header = RoundedTopHeaderView(Qt.Orientation.Horizontal, self.result_table)
        result_header.setObjectName("RoundedTableHeader")
        self.result_table.setHorizontalHeader(result_header)
        self.result_table.setHorizontalHeaderLabels(["№", "Товар", "ШК", "Накл.", "Состояние", "Факт", "Цена SAI", "Цена SIGMA", "Утвержд.", ""])
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.result_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.result_table.horizontalHeader().setStretchLastSection(False)
        self.result_table.verticalHeader().setVisible(False)
        self.result_table.setMinimumHeight(250)
        self.result_table.setMaximumHeight(16777215)
        self.result_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.result_table.setAlternatingRowColors(True)
        self.result_table.setShowGrid(True)
        self.result_table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.result_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.result_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.result_table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.result_table.setWordWrap(False)
        self.result_table.installEventFilter(self)
        self.result_table.hide()
        workflow_layout.addWidget(self.result_table, 1)

        self.log_box = QTextEdit(); self.log_box.setObjectName("WorkbenchLog"); self.log_box.setReadOnly(True); self.log_box.setMinimumHeight(160)
        self.log_box.hide()
        workflow_layout.addWidget(self.log_box)
        self.workbench_stack.setCurrentWidget(self.setup_stage)

    def show_setup_stage(self) -> None:
        self.workbench_stack.setCurrentWidget(self.setup_stage)
        ready = bool(self.sai_path and self.selected_supplier_id())
        self.confirm_setup_btn.setEnabled((not self.running) and ready)

    def show_workflow_stage(self) -> None:
        self.workbench_stack.setCurrentWidget(self.workflow_stage)

    def set_receipt_stage(self, stage_id: str, *, error: bool = False, complete: bool = False) -> None:
        """Reflect the real receipt state without inventing progress."""
        tracker = getattr(self, "workflow_tracker", None)
        if tracker is None:
            return
        skipped: set[str] = set()
        order = [stage[0] for stage in tracker.STAGES]
        try:
            current_index = order.index(stage_id)
        except ValueError:
            return
        if stage_id == "products":
            self.workflow_products_used = True
        if current_index > order.index("products") and not self.workflow_products_used:
            skipped.add("products")
        tracker.set_current(stage_id, skipped=skipped, error=error, complete=complete)

    def confirm_setup_and_start(self) -> None:
        """Commit the operator's setup choice and enter the live workflow."""
        if self.running:
            return
        if not self.sai_path or not self.sai_path.exists():
            QMessageBox.warning(self, "SAI", "SAI-файл не найден.")
            return
        if not self.selected_supplier_id():
            QMessageBox.warning(self, "SAI", "Выберите поставщика SIGMA.")
            return
        self.show_workflow_stage()
        self.set_receipt_stage("draft")
        self.create_waybill_and_check()

    # ---------- suppliers ----------
    def selected_supplier_data(self) -> Dict[str, Any]:
        if not self.supplier_combo:
            return {}
        data = self.supplier_combo.currentData()
        return data if isinstance(data, dict) else {}

    def selected_supplier_name(self) -> str:
        data = self.selected_supplier_data()
        if data:
            return str(data.get("name") or "").strip()
        if self.supplier_combo and self.supplier_combo.isEnabled():
            return str(self.supplier_combo.currentText() or "").strip()
        return ""

    def selected_supplier_id(self) -> str:
        data = self.selected_supplier_data()
        return str(data.get("id") or "").strip() if data else ""

    @staticmethod
    def normalize_supplier_match_name(value: str) -> str:
        text = str(value or "").upper().replace("Ё", "Е")
        text = re.sub(r"[«»\"'`]+", " ", text)
        text = re.sub(r"\b(ООО|ОАО|ПАО|АО|ЗАО|ИП|ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ)\b", " ", text)
        text = re.sub(r"[^0-9A-ZА-Я]+", " ", text)
        return " ".join(text.split())

    def supplier_match_index(self, supplier_name: str) -> int:
        wanted = self.normalize_supplier_match_name(supplier_name)
        if not wanted or not self.supplier_combo:
            return -1
        wanted_tokens = set(wanted.split())
        candidates = []
        for i in range(self.supplier_combo.count()):
            data = self.supplier_combo.itemData(i)
            if not isinstance(data, dict):
                continue
            name = self.normalize_supplier_match_name(str(data.get("name") or ""))
            if not name:
                continue
            tokens = set(name.split())
            if name == wanted:
                score = 100.0
            elif len(wanted) >= 5 and (wanted in name or name in wanted):
                score = 92.0
            else:
                union = wanted_tokens | tokens
                common = wanted_tokens & tokens
                score = (len(common) / len(union) * 100.0) if union else 0.0
            candidates.append((score, i))
        candidates.sort(reverse=True)
        if not candidates:
            return -1
        best_score, best_index = candidates[0]
        second_score = candidates[1][0] if len(candidates) > 1 else 0.0
        if best_score >= 90.0 or (best_score >= 72.0 and best_score - second_score >= 18.0):
            return best_index
        return -1

    def supplier_selection_changed(self, *_args) -> None:
        ready = bool(self.sai_path and self.selected_supplier_id())
        self.set_logical_enabled(self.create_btn, ready)
        if self.sai_path and not self.running:
            self.update_initial_workflow_status()
        self.schedule_autosave()

    def update_initial_workflow_status(self) -> None:
        if not self.sai_path:
            self.inline_status.setText("Открой SAI-файл, чтобы начать обработку прихода.")
            return
        if self.suppliers_proc is not None and not self.supplier_list:
            self.inline_status.setText("SAI-файл загружен. Получаю список поставщиков SIGMA и подбираю нужного…")
            return
        if self.selected_supplier_id():
            self.inline_status.setText("SAI-файл загружен. Проверь поставщика и дату, затем нажми «Создать черновик и проверить».")
            return
        if self.supplier_list:
            self.inline_status.setText("SAI-файл загружен, но поставщик не подобран однозначно. Выбери поставщика SIGMA.")
            return
        self.inline_status.setText("SAI-файл загружен. Загружаю поставщиков SIGMA…")

    def select_supplier(self, supplier_id: str = "", supplier_name: str = "") -> bool:
        if not self.supplier_combo:
            return False
        supplier_id = str(supplier_id or "").strip()
        for i in range(self.supplier_combo.count()):
            data = self.supplier_combo.itemData(i)
            if isinstance(data, dict) and supplier_id and str(data.get("id") or "") == supplier_id:
                self.supplier_combo.setCurrentIndex(i)
                return True
        match_index = self.supplier_match_index(supplier_name)
        if match_index >= 0:
            self.supplier_combo.setCurrentIndex(match_index)
            return True
        return False

    def supplier_cache_path(self) -> Path:
        return USER_DATA_DIR / "suppliers_cache.json"

    def save_supplier_cache(self, suppliers: List[Dict[str, Any]], company_id: str = "") -> None:
        try:
            clean = []
            seen = set()
            for s in suppliers:
                if not isinstance(s, dict):
                    continue
                sid = str(s.get("id") or "").strip()
                name = str(s.get("name") or "").strip()
                if not sid or not name or sid in seen:
                    continue
                seen.add(sid)
                inn = str(s.get("inn") or s.get("taxpayerIdentificationNumber") or "").strip()
                clean.append({"id": sid, "name": name, "inn": inn})
            if not clean:
                return
            payload = {
                "company_id": str(company_id or "").strip(),
                "updated_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "suppliers": clean,
            }
            tmp = self.supplier_cache_path().with_suffix(".json.tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.supplier_cache_path())
        except Exception:
            pass

    def load_supplier_cache(self) -> List[Dict[str, Any]]:
        try:
            p = self.supplier_cache_path()
            if not p.exists():
                return []
            payload = json.loads(p.read_text(encoding="utf-8")) or {}
            suppliers = payload.get("suppliers") or []
            return [s for s in suppliers if isinstance(s, dict) and str(s.get("name") or "").strip()]
        except Exception:
            return []

    def notify_supplier_consumers(self) -> None:
        try:
            page = getattr(self.parent_page, "free_receipt_page", None)
            if page is not None and getattr(page, "supplier_combo", None) is not None:
                page.refresh_suppliers_from_workbench(preserve_current=True)
        except Exception:
            pass
        try:
            page = getattr(self.parent_page, "converter_page", None)
            if page is not None and getattr(page, "supplier_combo", None) is not None:
                page.refresh_supplier_choices(preserve_current=True)
        except Exception:
            pass

    def fill_suppliers(self, suppliers: List[Dict[str, Any]], company_id: str = "") -> None:
        self.supplier_list = [s for s in suppliers if isinstance(s, dict) and str(s.get("name") or "").strip()]
        if self.supplier_list:
            self.save_supplier_cache(self.supplier_list, company_id)
            if company_id:
                try:
                    save_private_config_patch({"sigma_internal_company_id": str(company_id).strip()})
                except Exception:
                    pass
        if not self.supplier_combo:
            self.notify_supplier_consumers()
            return
        self.supplier_combo.blockSignals(True)
        self.supplier_combo.clear()
        if not self.supplier_list:
            cached = self.load_supplier_cache()
            if cached:
                self.supplier_list = cached
            else:
                self.supplier_combo.addItem("Поставщики не загружены", "")
                self.supplier_combo.setEnabled(False)
                self.supplier_combo.blockSignals(False)
                self.set_logical_enabled(self.create_btn, False)
                self.notify_supplier_consumers()
                return
        # Never silently use the first supplier. Add a neutral placeholder and
        # select only an exact or confidently unique match.
        self.supplier_combo.addItem("Выберите поставщика SIGMA", "")
        for s in sorted(self.supplier_list, key=lambda x: str(x.get("name") or "").lower()):
            name = str(s.get("name") or "").strip()
            inn = str(s.get("inn") or s.get("taxpayerIdentificationNumber") or "").strip()
            label = f"{name} · ИНН {inn}" if inn else name
            self.supplier_combo.addItem(label, {"id": str(s.get("id") or ""), "name": name, "inn": inn})
        self.supplier_combo.setEnabled(True)
        self.supplier_combo.blockSignals(False)
        wanted_id = str(self.load_shared_config().get("supplier_id") or "").strip()
        wanted_name = self.pending_supplier_name or str(self.load_shared_config().get("supplier_choice") or "").strip()
        matched = self.select_supplier(wanted_id, wanted_name)
        if not matched:
            self.supplier_combo.setCurrentIndex(0)
        self.set_logical_enabled(self.create_btn, bool(self.sai_path and self.selected_supplier_id()))
        self.update_initial_workflow_status()
        self.log(f"Поставщики SIGMA загружены: {len(self.supplier_list)}")
        if company_id:
            self.log(f"Компания SIGMA: {company_id}")
        self.save_work_context()
        self.notify_supplier_consumers()

    def load_suppliers_async(self, *, manual_login: bool = False, on_finished=None) -> bool:
        if self.suppliers_proc is not None:
            self.log("Список поставщиков уже обновляется в фоне…")
            if callable(on_finished):
                on_finished(False, "Список поставщиков уже обновляется.")
            return False
        cfg = self.private_cfg()
        self.suppliers_buffer = ""
        self.suppliers_manual_login = bool(manual_login)
        self.suppliers_finished_callback = on_finished
        cached = self.load_supplier_cache()
        if cached and not self.supplier_list:
            # Show last known list immediately; the SIGMA refresh continues in background.
            self.fill_suppliers(cached)
        elif self.supplier_combo and not self.supplier_list:
            self.supplier_combo.clear()
            self.supplier_combo.addItem("Загружаю поставщиков SIGMA…", "")
            self.supplier_combo.setEnabled(False)
            self.set_logical_enabled(self.create_btn, False)
        # When a cached/current list is already visible, keep it usable while the
        # background refresh runs. Never replace a good selection with a spinner.
        self.log(
            "Жду ручного входа в SIGMA и затем обновлю поставщиков…"
            if manual_login else
            "Загружаю список поставщиков из SIGMA…"
        )
        args = [sys.executable, "-u", str(WAYBILL_CREATOR_SCRIPT), "--mode", "list-suppliers", "--user-data-dir", str(PROFILE_DIR)]
        if str(cfg.get("sigma_internal_company_id") or "").strip():
            args += ["--company-id", str(cfg.get("sigma_internal_company_id")).strip()]
        if manual_login:
            # ATOL ID belongs to the user: SAI opens its persistent browser
            # profile and deliberately does not receive or store the credentials.
            args += ["--manual-login", "--visible-browser", "--login-timeout", "900"]
        else:
            append_sigma_auth_cli_args(args, cfg)
        if (not manual_login) and bool(load_private_config().get("browser_visible", False)):
            args += ["--visible-browser"]
        elif not manual_login:
            args += ["--hidden-browser"]
        if bool(cfg.get("prefer_bundled_chromium", True)):
            args += ["--prefer-bundled-chromium"]
        # Supplier refresh is an interactive business step. If SIGMA/ATOL has
        # expired the saved session, do not leave the user staring at a hidden
        # browser until the full timeout. Keep the cached list usable and reopen
        # SIGMA visibly so the user can finish the login themselves.
        auto_after = int(cfg.get("hidden_browser_auto_visible_after_seconds") or 20)
        args += ["--hidden-auto-visible-after", str(max(5, auto_after))]
        self.suppliers_proc = QProcess(self)
        self.suppliers_proc.setWorkingDirectory(str(APP_DIR))
        self.suppliers_proc.readyReadStandardOutput.connect(self._suppliers_stdout)
        self.suppliers_proc.readyReadStandardError.connect(self._suppliers_stdout)
        self.suppliers_proc.errorOccurred.connect(self._suppliers_process_error)
        self.suppliers_proc.finished.connect(self._suppliers_finished)
        self.suppliers_proc.start(args[0], args[1:])
        return True

    def _suppliers_process_error(self, error: QProcess.ProcessError) -> None:
        if error != QProcess.ProcessError.FailedToStart or self.suppliers_proc is None:
            return
        process = self.suppliers_proc
        try:
            process.finished.disconnect(self._suppliers_finished)
        except Exception:
            pass
        callback = self.suppliers_finished_callback
        manual_login = self.suppliers_manual_login
        self.suppliers_finished_callback = None
        self.suppliers_manual_login = False
        self.suppliers_proc = None
        process.deleteLater()
        message = (
            "Не удалось открыть браузер для ручного входа в SIGMA."
            if manual_login else
            "Не удалось запустить обновление поставщиков SIGMA."
        )
        self.log(message)
        if callable(callback):
            callback(False, message)

    def _suppliers_stdout(self) -> None:
        if not self.suppliers_proc:
            return
        data = bytes(self.suppliers_proc.readAllStandardOutput()).decode("utf-8", errors="replace")
        data += bytes(self.suppliers_proc.readAllStandardError()).decode("utf-8", errors="replace")
        self.suppliers_buffer += data
        for line in data.splitlines():
            if not line:
                continue
            if "SAI_SUPPLIERS_JSON:" not in line:
                self.log(line)

    def _suppliers_finished(self, code: int, status: QProcess.ExitStatus) -> None:
        payload = None
        for line in self.suppliers_buffer.splitlines():
            if "SAI_SUPPLIERS_JSON:" in line:
                raw = line.split("SAI_SUPPLIERS_JSON:", 1)[1].strip()
                try:
                    payload = json.loads(raw)
                except Exception as exc:
                    self.log(f"Не смог прочитать список поставщиков: {exc}")
                break
        callback = self.suppliers_finished_callback
        manual_login = self.suppliers_manual_login
        self.suppliers_finished_callback = None
        self.suppliers_manual_login = False
        self.suppliers_proc = None
        if code == 0 and isinstance(payload, dict):
            self.fill_suppliers(payload.get("suppliers") or [], company_id=str(payload.get("company_id") or ""))
            if callable(callback):
                callback(True, f"Поставщики SIGMA обновлены: {len(payload.get('suppliers') or [])}.")
        else:
            auth_required = any(marker in self.suppliers_buffer.lower() for marker in (
                "id.atol.ru",
                "cloud.sigma.ru/login",
                "no_sigma_token_yet",
                "не завершила вход",
            ))
            if self.supplier_list:
                # A network refresh may fail while the last valid cache remains usable.
                self.supplier_combo.setEnabled(True)
                self.set_logical_enabled(self.create_btn, bool(self.sai_path and self.selected_supplier_id()))
                self.update_initial_workflow_status()
                if auth_required:
                    self.log(
                        "SIGMA требует повторный вход через ATOL ID. "
                        "Используется последний сохранённый список поставщиков; "
                        "для обновления повторите действие и завершите вход в открывшемся окне."
                    )
                else:
                    self.log(f"Не удалось обновить поставщиков SIGMA (код {code}); используется последний сохранённый список.")
            else:
                if self.supplier_combo:
                    self.supplier_combo.clear()
                    self.supplier_combo.addItem(
                        "Требуется вход в SIGMA через ATOL ID"
                        if auth_required else
                        "Поставщики не загружены — повторите позже",
                        "",
                    )
                    self.supplier_combo.setEnabled(False)
                self.set_logical_enabled(self.create_btn, False)
                self.update_initial_workflow_status()
                if auth_required:
                    self.log(
                        "Поставщики SIGMA не загружены: требуется повторный вход через ATOL ID. "
                        "Нажмите «Обновить поставщиков» и завершите вход в открывшемся окне."
                    )
                else:
                    self.log(f"Поставщики SIGMA не загружены. Код {code}. Создание прихода заблокировано.")
            if callable(callback):
                reason = (
                    "Ручной вход не завершён или окно SIGMA было закрыто."
                    if manual_login else
                    "SIGMA требует повторный вход через ATOL ID."
                    if auth_required else
                    f"Не удалось обновить поставщиков SIGMA (код {code})."
                )
                callback(False, reason)

    # ---------- config/context ----------
    def load_shared_config(self) -> Dict[str, Any]:
        try:
            cfg_path = USER_DATA_DIR / "sai_config.json"
            if cfg_path.exists():
                return json.loads(cfg_path.read_text(encoding="utf-8")) or {}
        except Exception:
            pass
        return {}

    def private_cfg(self) -> Dict[str, Any]:
        if sai_load_private_config:
            cfg = dict(sai_load_private_config())
        else:
            cfg = load_private_config()
        cfg["_catalog_refreshed_this_session"] = bool(self.catalog_refreshed_this_session)
        return cfg

    def log(self, text: str) -> None:
        self.log_box.append(str(text))
        self.log_box.moveCursor(QTextCursor.End)

    def rebuild_action_buttons(self) -> None:
        layout = getattr(self, "actions_grid", None)
        if layout is None:
            return
        while layout.count():
            layout.takeAt(0)

        visible: List[QWidget] = []
        for btn in getattr(self, "action_buttons_order", []):
            logical = bool(btn.property("logical_enabled"))
            hide_when_disabled = bool(btn.property("hide_when_disabled"))
            should_show = (not hide_when_disabled) or logical
            btn.setVisible(should_show)
            if should_show:
                visible.append(btn)

        for i, widget in enumerate(visible):
            row = i // 3
            col = i % 3
            layout.addWidget(widget, row, col)
        for col in range(3):
            layout.setColumnStretch(col, 1)

    def set_busy(self, busy: bool, status: str = "") -> None:
        self.running = busy
        for btn in [self.create_btn, self.fix_barcodes_btn, self.imported_btn, self.import_later_btn, self.conflict_file_btn, self.conflict_continue_btn, self.fact_btn, self.price_approval_btn, self.approved_ndp_btn, self.apply_btn, self.ndp_btn]:
            if btn:
                logical = bool(btn.property("logical_enabled"))
                btn.setEnabled((not busy) and logical)
                if bool(btn.property("hide_when_disabled")):
                    btn.setVisible(logical)
        if self.supplier_combo:
            self.supplier_combo.setEnabled((not busy) and bool(self.supplier_list))
        if self.supplier_reload_btn:
            self.supplier_reload_btn.setEnabled(not busy)
        if getattr(self, "confirm_setup_btn", None) is not None:
            ready = bool(self.sai_path and self.selected_supplier_id())
            self.confirm_setup_btn.setEnabled((not busy) and ready)
        if status:
            self.inline_status.setText(status)
        self.rebuild_action_buttons()

    def set_logical_enabled(self, btn: QPushButton, enabled: bool) -> None:
        if btn in (getattr(self, "fact_btn", None), getattr(self, "approved_ndp_btn", None)):
            enabled = False
        enabled = bool(enabled)
        btn.setProperty("logical_enabled", enabled)
        btn.setEnabled((not self.running) and enabled)
        if bool(btn.property("hide_when_disabled")):
            btn.setVisible(enabled)
        if btn is getattr(self, "create_btn", None) and getattr(self, "confirm_setup_btn", None) is not None:
            self.confirm_setup_btn.setEnabled((not self.running) and enabled)
        self.rebuild_action_buttons()

    def set_logs_visible(self, visible: bool) -> None:
        self.log_box.setVisible(bool(visible))
        self.workbench_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarAsNeeded if visible else Qt.ScrollBarAlwaysOff
        )

    def schedule_autosave(self) -> None:
        """Debounced local autosave: fast typing never writes config on every key."""
        if self.autosave_timer is None:
            self.autosave_timer = QTimer(self)
            self.autosave_timer.setSingleShot(True)
            self.autosave_timer.setInterval(900)
            self.autosave_timer.timeout.connect(self.save_work_context)
        self.autosave_timer.start()

    def save_work_context(self) -> bool:
        if not self.sai_path:
            # Supplier can be selected before the SAI-file; save the full context later.
            return True
        supplier = self.selected_supplier_name()
        supplier_id = self.selected_supplier_id()
        date = self.date_edit.text().strip() or infer_date_from_sai_file(self.sai_path)
        if date:
            self.date_edit.setText(date)
        try:
            cfg_path = USER_DATA_DIR / "sai_config.json"
            cfg = self.load_shared_config()
            cfg.update({
                "sai_path": str(self.sai_path),
                "last_sai_dir": str(self.sai_path.parent),
                "supplier": supplier,
                "supplier_choice": supplier,
                "supplier_id": supplier_id,
                "invoice_date": date,
                "waybill": self.waybill_id,
                "runtime_storehouse_id": self.storehouse_id,
            })
            cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
            return True
        except Exception as exc:
            self.log(f"Не смог сохранить контекст приёмки: {exc}")
            return False

    def choose_file(self) -> bool:
        path, _ = QFileDialog.getOpenFileName(self, "Выберите SAI-файл", str(Path.home() / "Desktop"), "SAI Package (*.sai);;Все SAI-файлы (*.sai *.xml *.xlsx *.xlsm);;Старый SAI XML (*.xml);;Excel (*.xlsx *.xlsm)")
        if not path:
            return False
        self.set_sai_file(Path(path))
        return True

    def auto_pick_latest(self) -> None:
        path = find_latest_sai_file()
        if path:
            self.set_sai_file(path)
        else:
            self.log("Свежий SAI-файл не найден на рабочем столе или в загрузках.")

    def set_sai_file(self, path: Path) -> None:
        path = Path(path)
        if path.suffix.lower() in (".xlsx", ".xlsm"):
            package = path.with_suffix(".sai")
            xml = path.with_suffix(".xml")
            if package.exists() and package.is_file():
                path = package
            elif xml.exists() and xml.is_file():
                path = xml
        self.sai_path = path
        sai_receipt_drafts.update_by_package(path, stage="automatic")
        self.processing_sai_path = ""
        self.zero_qty_skipped_count = 0
        self.barcode_update_path = ""
        self.price_preview_done = False
        self.price_preview_log_path = ""
        self.last_effective_sai_path = ""
        self.approved_source_backup_path = ""
        self.fact_source_backup_path = ""
        self.fact_persisted = False
        self.manual_price_approval_used = False
        self.approved_ndp_path = ""
        self.price_approval_document_path = ""
        self.current_apply_run_id = 0
        self._final_print_in_progress = False
        self._last_final_print_apply_run_id = 0
        self._last_final_print_at = 0.0
        self.final_document_source_path = ""
        self.workflow_products_used = False
        self.set_receipt_stage("setup")
        # A filesystem path is technical noise and may expose local user data.
        # The filename is enough to identify the prepared receipt.
        self.file_label.setText(path.name)
        self.show_setup_stage()
        # Package metadata is the source of truth. Filename parsing is only a
        # compatibility fallback for old XML/XLSX files.
        package_supplier = ""
        package_supplier_id = ""
        package_date = ""
        if path.suffix.lower() == ".sai":
            try:
                _manifest, receipt = sai_package.read_package(path, verify_integrity=True)
                package_supplier = str(receipt.get("supplier") or "").strip()
                package_date = str(receipt.get("invoice_date") or "").strip()
                supplier_selection = receipt.get("validation", {}).get("supplier_selection", {}) if isinstance(receipt.get("validation"), dict) else {}
                if isinstance(supplier_selection, dict):
                    package_supplier_id = str(supplier_selection.get("id") or "").strip()
            except Exception as exc:
                self.log(f"Не удалось прочитать метаданные SAI Package: {exc}")
        shown_package_date = (
            date_display_from_text(package_date)
            if package_date and date_display_from_text is not None
            else package_date
        )
        self.date_edit.setText(shown_package_date or infer_date_from_sai_file(path))
        if package_supplier:
            self.pending_supplier_name = package_supplier
        else:
            stem = path.stem
            parts = stem.split("_")
            self.pending_supplier_name = parts[1].replace("-", " ") if len(parts) >= 2 else ""

        if not self.supplier_list:
            cached = self.load_supplier_cache()
            if cached:
                self.fill_suppliers(cached)
        if self.supplier_list:
            self.select_supplier(supplier_id=package_supplier_id, supplier_name=self.pending_supplier_name)

        self.log(f"SAI-файл: {path.name}")
        self.refresh_preview()
        self.set_logical_enabled(self.create_btn, bool(self.selected_supplier_id()))
        self.update_initial_workflow_status()
        self.set_logical_enabled(self.fix_barcodes_btn, False)
        self.set_logical_enabled(self.imported_btn, False)
        self.set_logical_enabled(self.import_later_btn, False)
        self.set_logical_enabled(self.conflict_file_btn, False)
        self.set_logical_enabled(self.conflict_continue_btn, False)
        self.set_logical_enabled(self.fact_btn, False)
        self.set_logical_enabled(self.price_approval_btn, False)
        self.set_logical_enabled(self.approved_ndp_btn, False)
        self.set_logical_enabled(self.apply_btn, False)
        self.set_logical_enabled(self.ndp_btn, False)
        self.save_work_context()

    def refresh_preview(self) -> None:
        if not self.sai_path or load_sai_rows is None:
            return
        try:
            self.sheet_name, rows = load_sai_rows(str(self.sai_path))
            self.source_rows = rows
            total_buy = sum(float(r.get("qty") or 0) * float(r.get("buy") or 0) for r in rows)
            total_sale = sum(float(r.get("qty") or 0) * float(r.get("sale") or 0) for r in rows)
            zero_count = len(self.zero_qty_receipt_rows(rows))
            active_count = len(rows) - zero_count
            self.rows_metric.set_value(str(len(rows)))
            self.buy_metric.set_value(money(total_buy))
            self.sale_metric.set_value(money(total_sale))
            date = self.date_edit.text().strip() or infer_date_from_sai_file(self.sai_path)
            self.date_metric.set_value(date or "—")
            self.log(f"Прочитано строк: {len(rows)} · закупка {money(total_buy)} · продажа {money(total_sale)}")
            self.populate_table(rows, status="ожидает проверки")
        except Exception as exc:
            self.rows_metric.set_value("ошибка", "не смог прочитать файл")
            self.log(f"ОШИБКА чтения SAI-файла: {exc}")


    # ---------- barcode preflight / rescue ----------
    def valid_barcode_list_from_text(self, text: str) -> List[str]:
        """Parse one editable table cell into distinct retail barcodes."""
        raw = str(text or "")
        chunks = re.split(r"[,;\s]+", raw)
        out: List[str] = []
        for chunk in chunks:
            code = re.sub(r"\D+", "", chunk)
            if code and len(code) in (8, 12, 13, 14) and code not in out:
                out.append(code)
        return out

    def row_qty_value(self, row: Optional[Dict[str, Any]]) -> float:
        """Receipt quantity as a number; 0 means full shortage / do not receive."""
        try:
            if parse_int_or_float:
                return float(parse_int_or_float((row or {}).get("qty")))
        except Exception:
            pass
        return _free_money_float((row or {}).get("qty"))

    def row_is_zero_qty(self, row: Optional[Dict[str, Any]]) -> bool:
        # Only an explicitly filled 0 means full shortage. Empty/unknown qty should not be silently skipped.
        raw = (row or {}).get("qty")
        if raw is None or safe_str(raw) == "":
            return False
        try:
            return self.row_qty_value(row) <= 0
        except Exception:
            return False

    def active_receipt_rows(self, rows: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        return [r for r in (rows if rows is not None else self.source_rows) or [] if not self.row_is_zero_qty(r)]

    def zero_qty_receipt_rows(self, rows: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, Any]]:
        return [r for r in (rows if rows is not None else self.source_rows) or [] if self.row_is_zero_qty(r)]

    def rows_without_barcodes(self, rows: Optional[List[Dict[str, Any]]] = None) -> List[int]:
        rows = rows if rows is not None else self.source_rows
        missing: List[int] = []
        for idx, row in enumerate(rows or []):
            # qty=0 is a full shortage: it must not block the workflow or require a barcode.
            if self.row_is_zero_qty(row):
                continue
            bcs = [safe_str(x) for x in (row.get("barcodes") or []) if safe_str(x)]
            if not bcs and not safe_str(row.get("barcode_cell")):
                missing.append(idx)
        return missing

    def processing_sai_file(self) -> Path:
        """Return a temporary SAI file without qty=0 rows for SIGMA/APPLY/NDP/tags.

        Semi-auto mode keeps zero-quantity rows in the saved SAI file as an audit trail
        of full shortages. For actual SIGMA import, NDP and price tags those rows must
        disappear completely, not be sent as qty=0.
        """
        if not self.sai_path or not self.source_rows:
            return Path(self.sai_path or "")
        skipped = [i for i, row in enumerate(self.source_rows) if self.row_is_zero_qty(row)]
        self.zero_qty_skipped_count = len(skipped)
        if not skipped:
            self.processing_sai_path = str(self.sai_path)
            return Path(self.sai_path)
        src = Path(self.sai_path)
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        out = CACHE_DIR / f"SAI_активные_позиции_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}{src.suffix.lower() or '.xlsx'}"
        skip_set = set(skipped)
        if src.suffix.lower() == ".sai":
            receipt = sai_package.read_receipt(src)
            package_items = list(receipt.get("items") or [])
            receipt["items"] = [item for idx, item in enumerate(package_items) if idx not in skip_set]
            sai_package.rewrite_receipt(src, receipt, out_path=out)
        elif src.suffix.lower() == ".xml":
            tree = ET.parse(str(src))
            root = tree.getroot()
            items_el = root.find("items")
            if items_el is None:
                raise RuntimeError("В XML не найден раздел <items>.")
            xml_items = list(items_el.findall("item"))
            for idx in sorted(skip_set, reverse=True):
                if idx < len(xml_items):
                    items_el.remove(xml_items[idx])
            try:
                ET.indent(tree, space="  ")
            except Exception:
                pass
            tree.write(str(out), encoding="utf-8", xml_declaration=True)
        else:
            shutil.copy2(src, out)
            wb = load_workbook(out)
            ws = wb[self.sheet_name] if self.sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
            rows_to_delete = []
            for idx in skip_set:
                try:
                    excel_row = int((self.source_rows[idx] or {}).get("excel_row") or 0)
                    if excel_row > 0:
                        rows_to_delete.append(excel_row)
                except Exception:
                    pass
            for excel_row in sorted(set(rows_to_delete), reverse=True):
                ws.delete_rows(excel_row, 1)
            wb.save(out)
        self.processing_sai_path = str(out)
        return out

    def visible_import_output_dir(self) -> Path:
        """Folder where a human can always find the manual SIGMA import XLSX."""
        try:
            if self.sai_path:
                src_dir = Path(self.sai_path).resolve().parent
                if src_dir.exists():
                    return src_dir
        except Exception:
            pass
        try:
            d = desktop_dir()
            if d.exists():
                return d
        except Exception:
            pass
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        return CACHE_DIR

    def show_missing_barcode_editor(self, rows: Optional[List[Dict[str, Any]]] = None, continue_mode: str = "check_products") -> None:
        self.set_receipt_stage("products")
        if rows is not None:
            self.source_rows = rows
        self.barcode_fix_rows = self.rows_without_barcodes(self.source_rows)
        self.barcode_fix_continue_mode = continue_mode or "check_products"
        count = len(self.barcode_fix_rows)
        self.populate_table(self.source_rows, status="barcode_fix")
        self.result_table.show()
        self.set_logical_enabled(self.create_btn, False)
        self.set_logical_enabled(self.fix_barcodes_btn, bool(count))
        self.set_logical_enabled(self.imported_btn, False)
        self.set_logical_enabled(self.fact_btn, False)
        self.set_logical_enabled(self.apply_btn, False)
        self.set_logical_enabled(self.ndp_btn, False)
        self.set_busy(False, f"СТОП: {count} позиций без ШК. Впишите ШК прямо в таблице и нажмите «Сохранить ШК и продолжить».")
        self.log(f"СТОП: позиции без ШК: {count}. Импорт SIGMA не создаётся, пока ШК не заполнены.")
        if self.barcode_fix_rows:
            r = self.barcode_fix_rows[0]
            self.result_table.setCurrentCell(r, 2)
            self.result_table.editItem(self.result_table.item(r, 2))


    def eventFilter(self, obj, event):  # noqa: N802 - Qt override name
        try:
            if obj is getattr(self, "result_table", None) and event.type() == QEvent.KeyPress:
                if event.key() in (Qt.Key_Return, Qt.Key_Enter) and getattr(self, "barcode_fix_rows", []):
                    row = self.result_table.currentRow()
                    col = self.result_table.currentColumn()
                    if col == 2 and 0 <= row < len(self.source_rows):
                        item = self.result_table.item(row, 2)
                        text = item.text() if item else ""
                        bcs = self.valid_barcode_list_from_text(text)
                        if bcs:
                            self.source_rows[row]["barcodes"] = bcs
                            self.source_rows[row]["barcode_cell"] = ", ".join(bcs)
                            if item:
                                item.setText(", ".join(bcs))
                                item.setBackground(QColor("#ffffff"))
                            # move to the next row still missing a valid barcode
                            for nr in self.barcode_fix_rows:
                                if nr > row:
                                    ni = self.result_table.item(nr, 2)
                                    if not self.valid_barcode_list_from_text(ni.text() if ni else ""):
                                        self.result_table.setCurrentCell(nr, 2)
                                        self.result_table.editItem(ni)
                                        return True
                            for nr in self.barcode_fix_rows:
                                ni = self.result_table.item(nr, 2)
                                if not self.valid_barcode_list_from_text(ni.text() if ni else ""):
                                    self.result_table.setCurrentCell(nr, 2)
                                    self.result_table.editItem(ni)
                                    return True
                            self.result_table.clearFocus()
                            return True
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def preflight_barcodes_or_stop(self, continue_mode: str) -> bool:
        """Return True if workflow may continue. If false, table is opened for ШК entry."""
        if not self.sai_path or load_sai_rows is None:
            return True
        try:
            sheet_name, rows = load_sai_rows(str(self.sai_path))
            self.sheet_name = sheet_name
            self.source_rows = rows
        except Exception as exc:
            self.log(f"Не смог проверить ШК до старта: {exc}")
            return True
        if self.rows_without_barcodes(rows):
            self.show_missing_barcode_editor(rows, continue_mode=continue_mode)
            return False
        return True

    def write_barcodes_back_to_sai_file(self) -> None:
        if not self.sai_path:
            raise RuntimeError("SAI-файл не выбран.")
        src = Path(self.sai_path)
        if src.suffix.lower() == ".sai":
            receipt = sai_package.read_receipt(src)
            items = list(receipt.get("items") or [])
            for idx, row in enumerate(self.source_rows):
                target = _sai_package_match_item(items, row, idx)
                target["barcodes"] = _sai_package_barcodes(row.get("barcodes") or row.get("barcode_cell"))
            receipt["items"] = items
            sai_package.rewrite_receipt(src, receipt)
            return
        if src.suffix.lower() == ".xml":
            tree = ET.parse(str(src))
            root = tree.getroot()
            items_el = root.find("items")
            if items_el is None:
                raise RuntimeError("В XML не найден раздел <items>.")
            xml_items = list(items_el.findall("item"))
            for idx, row in enumerate(self.source_rows):
                if idx >= len(xml_items):
                    break
                item_el = xml_items[idx]
                bcs_el = item_el.find("barcodes")
                if bcs_el is None:
                    bcs_el = ET.SubElement(item_el, "barcodes")
                for child in list(bcs_el):
                    bcs_el.remove(child)
                for bc in row.get("barcodes") or []:
                    bc_el = ET.SubElement(bcs_el, "barcode")
                    bc_el.text = str(bc)
            # keep UTF-8 and make a best-effort pretty output where Python supports it
            try:
                ET.indent(tree, space="  ")
            except Exception:
                pass
            tree.write(str(src), encoding="utf-8", xml_declaration=True)
            return

        wb = load_workbook(src)
        ws = wb[self.sheet_name] if self.sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
        _header_row, headers = find_headers(ws)
        col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
        if not col_barcode:
            col_barcode = pick_col(headers, ["BARCODE"], contains_any=["ШК"])
        if not col_barcode:
            raise RuntimeError("Не могу сохранить ШК: в SAI-файле не найдена колонка ШК.")
        for row in self.source_rows:
            excel_row = int(row.get("excel_row") or 0)
            if excel_row <= 0:
                continue
            ws.cell(excel_row, col_barcode).value = ", ".join([str(x) for x in (row.get("barcodes") or []) if str(x)])
            ws.cell(excel_row, col_barcode).number_format = "@"
        wb.save(src)

    def save_missing_barcodes_and_continue(self) -> None:
        if not self.source_rows:
            QMessageBox.warning(self, "SAI", "Нет строк для сохранения ШК.")
            return
        bad_rows: List[str] = []
        changed = 0
        for idx in self.barcode_fix_rows or self.rows_without_barcodes(self.source_rows):
            item = self.result_table.item(idx, 2)
            text = item.text() if item else ""
            bcs = self.valid_barcode_list_from_text(text)
            if not bcs:
                name = safe_str((self.source_rows[idx] or {}).get("name"))
                bad_rows.append(f"{idx + 1}. {name}")
                continue
            self.source_rows[idx]["barcodes"] = bcs
            self.source_rows[idx]["barcode_cell"] = ", ".join(bcs)
            changed += 1
        if bad_rows:
            QMessageBox.warning(
                self,
                "SAI",
                "Заполните корректный ШК 8/12/13/14 цифр для всех строк без ШК:\n\n" + "\n".join(bad_rows[:12])
            )
            if self.barcode_fix_rows:
                self.result_table.setCurrentCell(self.barcode_fix_rows[0], 2)
            return
        try:
            self.write_barcodes_back_to_sai_file()
        except Exception as exc:
            QMessageBox.critical(self, "SAI", f"Не смог сохранить ШК в SAI-файл:\n{exc}")
            return
        self.log(f"ШК сохранены в SAI-файл: {changed} строк. Теперь можно продолжать проверку.")
        self.barcode_fix_rows = []
        mode = self.barcode_fix_continue_mode or "check_products"
        self.barcode_fix_continue_mode = ""
        self.set_logical_enabled(self.fix_barcodes_btn, False)
        # Re-read from disk so preview/table and the real import generator see the same data.
        self.refresh_preview()
        if mode == "create_waybill":
            QTimer.singleShot(60, self.create_waybill_and_check)
        else:
            QTimer.singleShot(60, lambda: self.check_products(force_after_import=False))

    # ---------- table/fact ----------
    def populate_table(self, rows: List[Dict[str, Any]], status: str = "") -> None:
        self.result_table.setRowCount(len(rows))
        headers = self.result_table.horizontalHeader()
        widths = [48, 260, 120, 64, 132, 64, 84, 104, 92, 42]
        for idx, width in enumerate(widths):
            headers.setSectionResizeMode(idx, QHeaderView.Fixed)
            self.result_table.setColumnWidth(idx, width)
        headers.setSectionResizeMode(1, QHeaderView.Stretch)

        for i, row in enumerate(rows):
            excel_row = str(row.get("excel_row", ""))
            name = str(row.get("name", ""))
            barcodes = ", ".join(row.get("barcodes") or [])
            qty = str(row.get("qty", ""))
            incoming_sale = str(row.get("sale", ""))
            sigma_sale = str(row.get("_sigma_sale", ""))
            approved_sale = str(row.get("_approved_sale", ""))

            row_zero_qty = self.row_is_zero_qty(row)
            row_needs_barcode = (not row_zero_qty) and (i in set(self.barcode_fix_rows or []) or (status == "barcode_fix" and not barcodes.strip()))
            state_text = "НЕДОВОЗ 0" if row_zero_qty else ("НУЖЕН ШК" if row_needs_barcode else (status or ""))
            vals = [str(i + 1), name, barcodes, qty, state_text, qty, incoming_sale, sigma_sale, approved_sale]
            for c, val in enumerate(vals):
                item = QTableWidgetItem(str(val))
                if c in (0, 3, 5, 6):
                    item.setTextAlignment(Qt.AlignCenter)
                if row_zero_qty:
                    item.setBackground(QColor("#e5e7eb"))
                    item.setToolTip("Фактическое количество 0: позиция не попадёт в SIGMA, НДП и ценники.")
                elif status == "barcode_fix" and row_needs_barcode:
                    item.setBackground(QColor("#ffe7d6"))
                if status == "barcode_fix" and c == 2 and row_needs_barcode:
                    item.setFlags(item.flags() | Qt.ItemIsEditable)
                    item.setBackground(QColor("#ffd6bd"))
                    item.setToolTip("Введите один или несколько ШК через пробел или запятую. Допустимы 8/12/13/14 цифр. Enter перейдёт к следующей пустой строке.")
                elif status == "price_approval" and c in (1, 8):
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    item.setBackground(QColor("#fff4cc"))
                    item.setToolTip("Нажмите карандаш справа, чтобы отредактировать всю строку.")
                elif c != 5:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                if c == 4 and row_needs_barcode:
                    item.setTextAlignment(Qt.AlignCenter)
                    item.setBackground(QColor("#ffd9c9"))
                if c == 0:
                    item.setData(Qt.UserRole, excel_row)
                    item.setToolTip(f"Строка Excel: {excel_row}")
                self.result_table.setItem(i, c, item)

            if status != "barcode_fix":
                combo = NoWheelComboBox()
                combo.setObjectName("FactStatusCombo")
                combo.addItems(["принять", "недовоз", "не принимать", "возврат"])
                if row_zero_qty:
                    combo.setCurrentText("не принимать")
                    combo.setToolTip("Фактическое количество 0: позиция будет исключена из ввода прихода, НДП и ценников.")
                combo.currentTextChanged.connect(lambda text, row_index=i: self.on_fact_status_changed(row_index, text))
                self.result_table.setCellWidget(i, 4, combo)
                edit_btn = TableEditButton(tooltip="Редактировать товар")
                edit_btn.clicked.connect(lambda _checked=False, row_index=i: self.open_final_row_editor(row_index))
                self.result_table.setCellWidget(i, 9, edit_btn)
            else:
                self.result_table.removeCellWidget(i, 4)
                self.result_table.removeCellWidget(i, 9)

        self.result_table.resizeRowsToContents()
        # Hide the table during the early preview/check phase; show it only when the fact step is actually opened.
        if status == "barcode_fix":
            self.result_table.show()
        elif status in ("найдено", "готово", "проверить", "ожидает проверки"):
            self.result_table.hide()

    def on_fact_status_changed(self, row_index: int, text: str) -> None:
        text_l = str(text or "").lower()
        qty_item = self.result_table.item(row_index, 3)
        fact_item = self.result_table.item(row_index, 5)
        if fact_item is None:
            fact_item = QTableWidgetItem("")
            fact_item.setTextAlignment(Qt.AlignCenter)
            self.result_table.setItem(row_index, 5, fact_item)
        original_qty = qty_item.text() if qty_item else ""
        if "не принимать" in text_l or "возв" in text_l:
            fact_item.setText("0")
        elif "недовоз" in text_l:
            if fact_item.text().strip() in ("", "0"):
                fact_item.setText(original_qty)
            self.inline_status.setText("Недовоз: укажи фактическое количество в колонке «Факт».")
        else:
            fact_item.setText(original_qty)

    def open_final_row_editor(self, row_index: int) -> None:
        """Open the standard pencil editor for a final receipt row."""
        if not (0 <= row_index < len(self.source_rows)):
            return
        row = self.source_rows[row_index]
        dialog = QDialog(self)
        dialog.setWindowTitle("Редактирование товара")
        dialog.setMinimumWidth(520)
        root = QVBoxLayout(dialog)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(14)
        title = QLabel("Товар перед вводом прихода")
        title.setObjectName("WorkbenchSection")
        root.addWidget(title)
        form = QFormLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(10)

        name_edit = QLineEdit(safe_str(row.get("name")))
        article_edit = QLineEdit(safe_str(row.get("article")))
        barcode_edit = QLineEdit(", ".join(row.get("barcodes") or []))
        unit_edit = QLineEdit(safe_str(row.get("unit") or "штука"))
        invoice_qty_edit = QLineEdit(safe_str(row.get("qty")))
        fact_item = self.result_table.item(row_index, 5)
        fact_edit = QLineEdit(fact_item.text() if fact_item else safe_str(row.get("qty")))
        buy_edit = QLineEdit(safe_str(row.get("buy")))
        approved_item = self.result_table.item(row_index, 8)
        approved_value = approved_item.text() if approved_item and approved_item.text().strip() else safe_str(row.get("sale"))
        sale_edit = QLineEdit(approved_value)
        accent_edit = QLineEdit(safe_str(row.get("price_tag_accent")))
        accent_edit.setPlaceholderText("Например: 650 МЛ, БЕЛЫЙ, УСИЛЕННЫЙ")
        accent_edit.setMaxLength(80)
        accent_edit.setObjectName("WorkbenchInput")
        status_edit = NoWheelComboBox()
        status_edit.addItems(["принять", "недовоз", "не принимать", "возврат"])
        status_edit.setCurrentText(self.row_fact_status(row_index))
        for widget in (name_edit, article_edit, barcode_edit, unit_edit, invoice_qty_edit, fact_edit, buy_edit, sale_edit):
            widget.setObjectName("WorkbenchInput")
        status_edit.setObjectName("WorkbenchCombo")
        for label, widget in (
            ("Товар", name_edit), ("Артикул", article_edit), ("Штрихкоды", barcode_edit),
            ("Единица", unit_edit), ("Количество в накладной", invoice_qty_edit),
            ("Фактическое количество", fact_edit), ("Закупочная цена", buy_edit),
            ("Продажная цена", sale_edit), ("Состояние", status_edit),
        ):
            form.addRow(label, widget)
        accent_label = QLabel("ВАЖНОЕ ОТЛИЧИЕ")
        accent_label.setObjectName("ImportantAccentLabel")
        form.addRow(accent_label, accent_edit)
        root.addLayout(form)
        hint = QLabel("Продажная цена, изменённая здесь, считается ручным решением и не будет заменена большей ценой из каталога SIGMA.")
        hint.setObjectName("WorkbenchSubtitle")
        hint.setWordWrap(True)
        root.addWidget(hint)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel | QDialogButtonBox.StandardButton.Save)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        root.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        try:
            name = safe_str(name_edit.text())
            if not name:
                raise ValueError("Название товара не может быть пустым.")
            barcodes: List[str] = []
            for part in re.split(r"[,;\s]+", barcode_edit.text().strip()):
                digits = re.sub(r"\D+", "", part)
                if not digits:
                    continue
                if len(digits) not in (8, 12, 13, 14):
                    raise ValueError(f"Некорректный ШК: {part}")
                if digits not in barcodes:
                    barcodes.append(digits)
            invoice_qty = float(parse_int_or_float(invoice_qty_edit.text()))
            fact_qty = float(parse_int_or_float(fact_edit.text()))
            buy = float(str(buy_edit.text()).replace(" ", "").replace(",", "."))
            sale = float(str(sale_edit.text()).replace(" ", "").replace(",", "."))
            if min(invoice_qty, fact_qty, buy, sale) < 0:
                raise ValueError("Количество и цены не могут быть отрицательными.")
        except Exception as exc:
            QMessageBox.warning(self, "Редактирование товара", str(exc))
            return

        old_sale = float(row.get("_approved_sale") or row.get("sale") or 0)
        row.update({
            "name": name,
            "article": safe_str(article_edit.text()),
            "barcodes": barcodes,
            "barcode_cell": ", ".join(barcodes),
            "unit": normalize_unit(unit_edit.text()),
            "qty": invoice_qty,
            "buy": buy,
            "sale": sale,
            "_approved_sale": sale,
            "price_tag_accent": safe_str(accent_edit.text()),
            "_final_review_edited": True,
        })
        if abs(sale - old_sale) > 1e-9:
            row["price_operator_approved"] = True
            row["price_approval_source"] = "manual_final_review"
            self.manual_price_approval_used = True
        self.source_rows[row_index] = row

        state_widget = self.result_table.cellWidget(row_index, 4)
        if isinstance(state_widget, QComboBox):
            state_widget.setCurrentText(status_edit.currentText())
        for column, value in (
            (1, name), (2, ", ".join(barcodes)), (3, quantity_text(invoice_qty)),
            (5, quantity_text(fact_qty)), (6, manual_price_text(sale)), (8, manual_price_text(sale)),
        ):
            item = self.result_table.item(row_index, column)
            if item is not None:
                item.setText(value)
        self.fact_persisted = False
        self.processing_sai_path = ""
        self.last_effective_sai_path = ""
        self.final_document_source_path = ""
        self.inline_status.setText("Изменения строки сохранены. Можно редактировать другие товары или ввести приход.")

    def show_fact_table(self) -> None:
        if not self.source_rows:
            QMessageBox.information(self, "SAI", "Сначала проверь товары.")
            return
        self.result_table.show()
        self.set_receipt_stage("fact")
        self.inline_status.setText("Факт приёмки: выберите состояние строки. Для недовоза укажите фактическое количество.")
        self.log("Факт приёмки открыт. Состояния: недовоз / не принимать / возврат. Обычные строки оставь 'принять'.")

    def lock_fact_controls(self) -> None:
        """Freeze fact quantity/status after the user starts the next stage."""
        for r in range(self.result_table.rowCount()):
            combo = self.result_table.cellWidget(r, 4)
            if isinstance(combo, QComboBox):
                combo.setEnabled(False)
            fact_item = self.result_table.item(r, 5)
            if fact_item is not None:
                fact_item.setFlags(fact_item.flags() & ~Qt.ItemIsEditable)

    def persist_fact_values_to_source(self) -> tuple[int, Optional[Path]]:
        """Write accepted fact quantities into the currently selected SAI file.

        This is executed exactly once before either price approval or direct APPLY.
        Skip/return/full shortage is stored as quantity 0. The source file therefore
        becomes the single source for SIGMA, NDP and price tags.
        """
        if self.fact_persisted:
            return 0, Path(self.fact_source_backup_path) if self.fact_source_backup_path else None
        if not self.sai_path or not self.source_rows:
            raise RuntimeError("Нет SAI-файла или строк для сохранения факта приёмки.")
        src = Path(self.sai_path)
        adjustments = self.current_adjustments()
        planned: List[tuple[Dict[str, Any], float]] = []
        for row in self.source_rows:
            key = str(row.get("excel_row") or "")
            adj = adjustments.get(key) or {}
            status = safe_str(adj.get("status") or "accept")
            if status in ("skip", "return"):
                qty = 0.0
            else:
                try:
                    qty = float(parse_int_or_float(adj.get("fact_qty", row.get("qty"))))
                except Exception:
                    raise RuntimeError(f"Некорректное фактическое количество в строке {key}.")
                if qty < 0:
                    raise RuntimeError(f"Фактическое количество не может быть отрицательным, строка {key}.")
            planned.append((row, qty))

        backup_dir = USER_DATA_DIR / "backups" / "fact_sai"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup_path = backup_dir / f"{src.stem}_до_факта_{stamp}{src.suffix}"
        changed = 0

        def barcode_key(values: Any) -> tuple[str, ...]:
            if isinstance(values, (list, tuple, set)):
                parts = values
            else:
                parts = re.split(r"[,;\n]+", safe_str(values))
            return tuple(sorted({re.sub(r"\D+", "", safe_str(v)) for v in parts if re.sub(r"\D+", "", safe_str(v))}))

        if src.suffix.lower() == ".sai":
            receipt = sai_package.read_receipt(src)
            items = list(receipt.get("items") or [])
            for idx, (row, qty) in enumerate(planned):
                target = _sai_package_match_item(items, row, idx)
                old_qty = float(target.get("quantity") or 0)
                if abs(old_qty - qty) > 1e-9:
                    target["quantity"] = qty
                    changed += 1
            if changed:
                shutil.copy2(src, backup_path)
                try:
                    receipt["items"] = items
                    sai_package.rewrite_receipt(src, receipt)
                except Exception:
                    shutil.copy2(backup_path, src)
                    raise
        elif src.suffix.lower() == ".xml":
            tree = ET.parse(str(src))
            root = tree.getroot()
            items_el = root.find("items")
            if items_el is None:
                raise RuntimeError("В XML не найден раздел <items>.")
            items = list(items_el.findall("item"))
            by_source_row = {safe_str(item.attrib.get("row")): item for item in items if safe_str(item.attrib.get("row"))}
            by_barcodes: Dict[tuple[str, ...], ET.Element] = {}
            duplicate_keys: set[tuple[str, ...]] = set()
            for item in items:
                key = barcode_key([el.text for el in item.findall("./barcodes/barcode")])
                if not key:
                    continue
                if key in by_barcodes:
                    duplicate_keys.add(key)
                else:
                    by_barcodes[key] = item
            for key in duplicate_keys:
                by_barcodes.pop(key, None)
            for row, qty in planned:
                target = by_source_row.get(safe_str(row.get("source_row")))
                if target is None:
                    target = by_barcodes.get(barcode_key(row.get("barcodes") or row.get("barcode_cell")))
                if target is None:
                    fallback = int(row.get("excel_row") or 0) - 2
                    target = items[fallback] if 0 <= fallback < len(items) else None
                if target is None:
                    raise RuntimeError(f"Не удалось сопоставить строку SAI: {safe_str(row.get('name'))}")
                qty_el = target.find("quantity")
                if qty_el is None:
                    qty_el = ET.SubElement(target, "quantity")
                old_qty = float(parse_int_or_float(qty_el.text or 0))
                if abs(old_qty - qty) > 1e-9:
                    qty_el.text = str(int(qty)) if abs(qty - round(qty)) < 1e-9 else f"{qty:.3f}".rstrip("0").rstrip(".")
                    changed += 1
            if changed:
                shutil.copy2(src, backup_path)
                temp_path = src.with_name(src.name + ".fact.tmp")
                try:
                    try:
                        ET.indent(tree, space="  ")
                    except Exception:
                        pass
                    tree.write(str(temp_path), encoding="utf-8", xml_declaration=True)
                    os.replace(temp_path, src)
                except Exception:
                    temp_path.unlink(missing_ok=True)
                    shutil.copy2(backup_path, src)
                    raise
        else:
            wb = load_workbook(src)
            ws = wb[self.sheet_name] if self.sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
            header_row, headers = find_headers(ws)
            col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
            col_qty = pick_col(headers, ["КОЛ-ВО", "КОЛИЧЕСТВО", "КОЛ-ВО ЕД."], contains_any=["КОЛ"])
            if not col_barcode or not col_qty:
                raise RuntimeError("Не могу сохранить факт: не найдены колонки ШК/КОЛ-ВО.")
            by_barcodes: Dict[tuple[str, ...], int] = {}
            duplicate_keys: set[tuple[str, ...]] = set()
            for excel_row in range(header_row + 1, ws.max_row + 1):
                key = barcode_key(ws.cell(excel_row, col_barcode).value)
                if not key:
                    continue
                if key in by_barcodes:
                    duplicate_keys.add(key)
                else:
                    by_barcodes[key] = excel_row
            for key in duplicate_keys:
                by_barcodes.pop(key, None)
            for row, qty in planned:
                target_row = by_barcodes.get(barcode_key(row.get("barcodes") or row.get("barcode_cell")))
                if not target_row:
                    candidate = int(row.get("excel_row") or 0)
                    target_row = candidate if header_row < candidate <= ws.max_row else None
                if not target_row:
                    raise RuntimeError(f"Не удалось сопоставить строку SAI: {safe_str(row.get('name'))}")
                old_qty = float(parse_int_or_float(ws.cell(target_row, col_qty).value or 0))
                if abs(old_qty - qty) > 1e-9:
                    ws.cell(target_row, col_qty).value = qty
                    changed += 1
            if changed:
                shutil.copy2(src, backup_path)
                temp_path = src.with_name(src.stem + ".fact.tmp" + src.suffix)
                try:
                    wb.save(temp_path)
                    os.replace(temp_path, src)
                except Exception:
                    temp_path.unlink(missing_ok=True)
                    shutil.copy2(backup_path, src)
                    raise
            try:
                wb.close()
            except Exception:
                pass

        for row, qty in planned:
            row["qty"] = qty
        self.fact_persisted = True
        self.fact_source_backup_path = str(backup_path) if changed else ""
        self.processing_sai_path = ""
        self.last_effective_sai_path = ""
        self.final_document_source_path = ""
        self.lock_fact_controls()
        if changed:
            self.log(f"Факт приёмки записан в SAI-файл: изменено строк {changed}. Резервная копия: {backup_path}")
        else:
            self.log("Факт приёмки совпадает с SAI-файлом; дополнительная запись не нужна.")
        return changed, backup_path if changed else None

    def row_fact_status(self, row_index: int) -> str:
        widget = self.result_table.cellWidget(row_index, 4)
        if isinstance(widget, QComboBox):
            return str(widget.currentText() or "принять").strip().lower()
        item = self.result_table.item(row_index, 4)
        return (item.text() if item else "принять").strip().lower()

    def current_adjustments(self) -> Dict[str, Dict[str, Any]]:
        out: Dict[str, Dict[str, Any]] = {}
        for r in range(self.result_table.rowCount()):
            row_item = self.result_table.item(r, 0)
            excel_row = str(row_item.data(Qt.UserRole) if row_item and row_item.data(Qt.UserRole) else (r + 2))
            status_raw = self.row_fact_status(r)
            fact_qty = self.result_table.item(r, 5).text() if self.result_table.item(r, 5) else ""
            name_override = self.result_table.item(r, 1).text().strip() if self.result_table.item(r, 1) else ""
            sale_override = self.result_table.item(r, 8).text() if self.result_table.item(r, 8) else ""
            status = "accept"
            if "возв" in status_raw:
                status = "return"
            elif "не принимать" in status_raw or "проп" in status_raw or "skip" in status_raw:
                status = "skip"
            elif "недовоз" in status_raw:
                status = "shortage"
            out[str(excel_row)] = {"status": status, "fact_qty": fact_qty, "name_override": name_override, "sale_override": sale_override, "comment": ""}
        return out

    def persist_approved_values_to_source(self) -> tuple[int, int, Optional[Path]]:
        """Write approved sale prices and edited names back to the selected SAI file.

        The original source remains the single source of truth for later price tags and
        repeated document generation. A timestamped backup is created before the first
        physical write. Quantity/fact corrections stay in the temporary effective file.
        """
        if not self.sai_path or not self.source_rows:
            raise RuntimeError("Нет SAI-файла или строк для сохранения утверждённых цен.")
        if not self.price_preview_done:
            raise RuntimeError("Сначала подготовьте накладную на согласование цен.")

        src = Path(self.sai_path)
        adjustments = self.current_adjustments()
        planned: List[Dict[str, Any]] = []
        for row in self.source_rows:
            key = str(row.get("excel_row") or "")
            adj = adjustments.get(key) or {}
            sale_text = safe_str(adj.get("sale_override"))
            name_text = safe_str(adj.get("name_override"))
            sale_value: Optional[float] = None
            if sale_text:
                try:
                    sale_value = float(sale_text.replace(" ", "").replace(",", "."))
                except Exception:
                    raise RuntimeError(f"Некорректная утверждённая цена в строке {key}: {sale_text}")
                if sale_value < 0:
                    raise RuntimeError(f"Цена не может быть отрицательной, строка {key}.")
            planned.append({"row": row, "sale": sale_value, "name": name_text})

        backup_dir = USER_DATA_DIR / "backups" / "approved_sai"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup_path = backup_dir / f"{src.stem}_до_утверждения_{stamp}{src.suffix}"
        price_changes = 0
        name_changes = 0

        def barcode_key(values: Any) -> tuple[str, ...]:
            if isinstance(values, (list, tuple, set)):
                parts = values
            else:
                parts = re.split(r"[,;\n]+", safe_str(values))
            cleaned = []
            for value in parts:
                digits = re.sub(r"\D+", "", safe_str(value))
                if digits:
                    cleaned.append(digits)
            return tuple(sorted(set(cleaned)))

        if src.suffix.lower() == ".sai":
            receipt = sai_package.read_receipt(src)
            items = list(receipt.get("items") or [])
            for idx, payload in enumerate(planned):
                row = payload["row"]
                target = _sai_package_match_item(items, row, idx)
                sale_value = payload["sale"]
                if sale_value is not None:
                    old_sale = float(target.get("sale_price") or 0)
                    if abs(old_sale - sale_value) > 1e-9:
                        target["sale_price"] = sale_value
                        price_changes += 1
                name_text = payload["name"]
                if name_text and safe_str(target.get("name")) != name_text:
                    target["name"] = name_text
                    name_changes += 1
            if price_changes or name_changes:
                shutil.copy2(src, backup_path)
                try:
                    receipt["items"] = items
                    sai_package.rewrite_receipt(src, receipt)
                except Exception:
                    shutil.copy2(backup_path, src)
                    raise
        elif src.suffix.lower() == ".xml":
            tree = ET.parse(str(src))
            root = tree.getroot()
            items_el = root.find("items")
            if items_el is None:
                raise RuntimeError("В XML не найден раздел <items>.")
            items = list(items_el.findall("item"))
            by_source_row: Dict[str, ET.Element] = {}
            by_barcodes: Dict[tuple[str, ...], ET.Element] = {}
            duplicates: set[tuple[str, ...]] = set()
            for item in items:
                source_row = safe_str(item.attrib.get("row"))
                if source_row:
                    by_source_row[source_row] = item
                bcs = barcode_key([el.text for el in item.findall("./barcodes/barcode")])
                if bcs:
                    if bcs in by_barcodes:
                        duplicates.add(bcs)
                    else:
                        by_barcodes[bcs] = item
            for key in duplicates:
                by_barcodes.pop(key, None)

            for payload in planned:
                row = payload["row"]
                target = by_source_row.get(safe_str(row.get("source_row")))
                if target is None:
                    target = by_barcodes.get(barcode_key(row.get("barcodes") or row.get("barcode_cell")))
                if target is None:
                    fallback = int(row.get("excel_row") or 0) - 2
                    if 0 <= fallback < len(items):
                        target = items[fallback]
                if target is None:
                    raise RuntimeError(f"Не удалось сопоставить строку SAI: {safe_str(row.get('name'))}")

                sale_value = payload["sale"]
                if sale_value is not None:
                    sale_el = target.find("sale_price")
                    if sale_el is None:
                        sale_el = ET.SubElement(target, "sale_price")
                    try:
                        old_sale = float(safe_str(sale_el.text).replace(",", ".") or 0)
                    except Exception:
                        old_sale = 0.0
                    if abs(old_sale - sale_value) > 1e-9:
                        sale_el.text = f"{sale_value:.2f}"
                        price_changes += 1
                name_text = payload["name"]
                if name_text:
                    name_el = target.find("name")
                    if name_el is None:
                        name_el = ET.SubElement(target, "name")
                    if safe_str(name_el.text) != name_text:
                        name_el.text = name_text
                        name_changes += 1

            if price_changes or name_changes:
                shutil.copy2(src, backup_path)
                temp_path = src.with_name(src.name + ".approved.tmp")
                try:
                    try:
                        ET.indent(tree, space="  ")
                    except Exception:
                        pass
                    tree.write(str(temp_path), encoding="utf-8", xml_declaration=True)
                    os.replace(temp_path, src)
                except Exception:
                    temp_path.unlink(missing_ok=True)
                    shutil.copy2(backup_path, src)
                    raise
        else:
            wb = load_workbook(src)
            ws = wb[self.sheet_name] if self.sheet_name in wb.sheetnames else wb[wb.sheetnames[0]]
            _header_row, headers = find_headers(ws)
            col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
            col_name = pick_col(headers, ["НАИМЕНОВАНИЕ", "ТОВАР", "НАЗВАНИЕ"], contains_any=["НАИМЕНОВАН"])
            col_sale = pick_col(headers, ["ПРОДАЖНАЯ ЦЕНА", "ЦЕНА ПРОДАЖИ", "РОЗНИЧНАЯ ЦЕНА"], contains_any=["ПРОДАЖ"]) or pick_col(headers, ["ЦЕНА"])
            if not col_barcode or not col_sale:
                raise RuntimeError("Не могу сохранить утверждённые цены: не найдены колонки ШК/Продажная цена.")
            by_barcodes: Dict[tuple[str, ...], int] = {}
            duplicates: set[tuple[str, ...]] = set()
            for excel_row in range(_header_row + 1, ws.max_row + 1):
                bcs = barcode_key(ws.cell(excel_row, col_barcode).value)
                if not bcs:
                    continue
                if bcs in by_barcodes:
                    duplicates.add(bcs)
                else:
                    by_barcodes[bcs] = excel_row
            for key in duplicates:
                by_barcodes.pop(key, None)

            for payload in planned:
                row = payload["row"]
                target_row = by_barcodes.get(barcode_key(row.get("barcodes") or row.get("barcode_cell")))
                if not target_row:
                    candidate = int(row.get("excel_row") or 0)
                    if _header_row < candidate <= ws.max_row:
                        target_row = candidate
                if not target_row:
                    raise RuntimeError(f"Не удалось сопоставить строку SAI: {safe_str(row.get('name'))}")
                sale_value = payload["sale"]
                if sale_value is not None:
                    old_value = ws.cell(target_row, col_sale).value
                    try:
                        old_sale = float(str(old_value or 0).replace(" ", "").replace(",", "."))
                    except Exception:
                        old_sale = 0.0
                    if abs(old_sale - sale_value) > 1e-9:
                        ws.cell(target_row, col_sale).value = sale_value
                        ws.cell(target_row, col_sale).number_format = "0.00"
                        price_changes += 1
                name_text = payload["name"]
                if name_text and col_name and safe_str(ws.cell(target_row, col_name).value) != name_text:
                    ws.cell(target_row, col_name).value = name_text
                    name_changes += 1

            if price_changes or name_changes:
                shutil.copy2(src, backup_path)
                temp_path = src.with_name(src.stem + ".approved.tmp" + src.suffix)
                try:
                    wb.save(temp_path)
                    os.replace(temp_path, src)
                except Exception:
                    temp_path.unlink(missing_ok=True)
                    shutil.copy2(backup_path, src)
                    raise
            try:
                wb.close()
            except Exception:
                pass

        # Never keep a temporary pre-approval workbook as a later document source.
        self.processing_sai_path = ""
        self.last_effective_sai_path = ""
        self.final_document_source_path = ""
        if price_changes or name_changes:
            self.approved_source_backup_path = str(backup_path)
            for payload in planned:
                row = payload["row"]
                if payload["sale"] is not None:
                    row["sale"] = payload["sale"]
                if payload["name"]:
                    row["name"] = payload["name"]
            self.log(f"SAI-файл обновлён: цены {price_changes}, названия {name_changes}. Резервная копия: {backup_path}")
        else:
            backup_path = None
            self.log("SAI-файл уже содержит утверждённые цены и названия; повторная запись не нужна.")
        return price_changes, name_changes, backup_path

    def create_effective_sai_for_apply(self) -> str:
        if not self.sai_path or not self.source_rows:
            self.effective_sheet_name = self.sheet_name
            self.last_effective_sai_path = str(self.sai_path or "")
            return self.last_effective_sai_path
        adjustments = self.current_adjustments()
        # Product-check temporary files may contain prices from before approval.
        # APPLY and all final documents must always start from the selected source.
        src = Path(self.sai_path)
        is_structured_source = src.suffix.lower() in (".xml", ".sai")
        changed = False
        for row in self.source_rows:
            key = str(row.get("excel_row"))
            adj = adjustments.get(key) or {}
            status = adj.get("status") or "accept"
            fact = parse_int_or_float(adj.get("fact_qty")) if 'parse_int_or_float' in globals() else float(adj.get("fact_qty") or row.get("qty") or 0)
            orig = parse_int_or_float(row.get("qty")) if 'parse_int_or_float' in globals() else float(row.get("qty") or 0)
            current_name = safe_str(row.get("name"))
            edited_name = safe_str(adj.get("name_override"))
            if row.get("_final_review_edited") or status in ("skip", "return") or abs(float(fact) - float(orig)) > 1e-9 or str(adj.get("sale_override") or "").strip() or (edited_name and edited_name != current_name):
                changed = True
                break

        # The APPLY script works with Excel workbooks. Structured SAI input is converted to a
        # temporary canonical XLSX even when there are no fact changes. This also
        # avoids passing the virtual structured-data sheet name to an Excel file
        # whose real sheet is "Для робота SIGMA".
        if not changed and not is_structured_source:
            self.effective_sheet_name = self.sheet_name
            self.last_effective_sai_path = str(src)
            return self.last_effective_sai_path

        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        out = CACHE_DIR / f"SAI_рабочий_факт_{dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.xlsx"
        if is_structured_source:
            from sai_app import write_sai_rows_to_xlsx, DEFAULT_SAI_SHEET
            self.effective_sheet_name = DEFAULT_SAI_SHEET
            write_sai_rows_to_xlsx(self.source_rows, out, sheet_name=self.effective_sheet_name)
        else:
            self.effective_sheet_name = self.sheet_name
            shutil.copy2(src, out)
        wb = load_workbook(out)
        target_sheet = getattr(self, "effective_sheet_name", None) or self.sheet_name
        ws = wb[target_sheet] if target_sheet in wb.sheetnames else wb[wb.sheetnames[0]]
        if target_sheet not in wb.sheetnames:
            self.effective_sheet_name = ws.title
        _header_row, headers = find_headers(ws)
        col_barcode = pick_col(headers, ["ШК", "ШТРИХКОД", "ШТРИХКОД ДЛЯ СКАНИРОВАНИЯ"], contains_any=["ШТРИХ"])
        col_qty = pick_col(headers, ["КОЛ-ВО", "КОЛИЧЕСТВО", "КОЛ-ВО ЕД."], contains_any=["КОЛ"])
        col_unit = pick_col(headers, ["ЕД.", "ЕД", "ЕДИНИЦА", "ЕДИНИЦА ИЗМЕРЕНИЯ"], contains_any=["ЕД"])
        col_buy = pick_col(headers, ["ЗАКУП ЦЕНА", "ЗАКУПОЧНАЯ ЦЕНА", "ЦЕНА ЗАКУПКИ"], contains_any=["ЗАКУП"])
        col_article = pick_col(headers, ["АРТИКУЛ", "КОД", "КОД ТОВАРА", "КОД ПОСТАВЩИКА"])
        col_name = pick_col(headers, ["НАИМЕНОВАНИЕ", "ТОВАР", "НАЗВАНИЕ"], contains_any=["НАИМЕНОВАН"])
        col_sale = pick_col(headers, ["ПРОДАЖНАЯ ЦЕНА", "ЦЕНА ПРОДАЖИ", "РОЗНИЧНАЯ ЦЕНА"], contains_any=["ПРОДАЖ"])
        col_price_approved = pick_col(headers, ["ЦЕНА УТВЕРЖДЕНА ОПЕРАТОРОМ"])
        col_price_source = pick_col(headers, ["ИСТОЧНИК УТВЕРЖДЕННОЙ ЦЕНЫ"])
        col_price_tag_accent = pick_col(headers, ["ВАЖНОЕ ОТЛИЧИЕ", "АКЦЕНТ ЦЕННИКА"])
        if not col_sale:
            col_sale = pick_col(headers, ["ЦЕНА"])
        if not col_barcode or not col_qty:
            raise RuntimeError("Не могу подготовить рабочий SAI-файл: не найдены колонки ШК/КОЛ-ВО.")
        if not col_price_approved:
            col_price_approved = ws.max_column + 1
            ws.cell(_header_row, col_price_approved).value = "Цена утверждена оператором"
        if not col_price_source:
            col_price_source = ws.max_column + 1
            ws.cell(_header_row, col_price_source).value = "Источник утвержденной цены"
        if not col_price_tag_accent:
            col_price_tag_accent = ws.max_column + 1
            ws.cell(_header_row, col_price_tag_accent).value = "Важное отличие"

        # Canonical units in the temporary fact workbook too: only 'штука' or 'м'.
        if col_unit:
            for row in self.source_rows:
                excel_row = int(row.get("excel_row") or 0)
                if excel_row > 0:
                    ws.cell(excel_row, col_unit).value = normalize_unit(row.get("unit") or ws.cell(excel_row, col_unit).value)

        skipped = partial = sale_changed = name_changed = 0
        for row in self.source_rows:
            excel_row = int(row.get("excel_row") or 0)
            if excel_row <= 0:
                continue
            adj = adjustments.get(str(excel_row)) or {}
            status = adj.get("status") or "accept"
            fact = parse_int_or_float(adj.get("fact_qty", row.get("qty")))
            orig = parse_int_or_float(row.get("qty"))
            if status in ("skip", "return") or fact <= 0:
                ws.cell(excel_row, col_barcode).value = ""
                ws.cell(excel_row, col_qty).value = 0
                skipped += 1
            else:
                ws.cell(excel_row, col_barcode).value = ", ".join(row.get("barcodes") or [])
                if abs(float(fact) - float(orig)) > 1e-9:
                    partial += 1
                ws.cell(excel_row, col_qty).value = fact
            if col_unit:
                ws.cell(excel_row, col_unit).value = normalize_unit(row.get("unit") or "штука")
            if col_buy:
                ws.cell(excel_row, col_buy).value = float(row.get("buy") or 0)
            if col_article:
                ws.cell(excel_row, col_article).value = safe_str(row.get("article"))
            if col_name and row.get("_final_review_edited"):
                ws.cell(excel_row, col_name).value = safe_str(row.get("name"))
            name_override = safe_str(adj.get("name_override"))
            if name_override and col_name and name_override != safe_str(row.get("name")):
                ws.cell(excel_row, col_name).value = name_override
                name_changed += 1
            sale_override = str(adj.get("sale_override") or "").strip()
            if sale_override and col_sale:
                ws.cell(excel_row, col_sale).value = float(sale_override.replace(" ", "").replace(",", "."))
                sale_changed += 1
            if row.get("price_operator_approved"):
                ws.cell(excel_row, col_price_approved).value = "ДА"
                ws.cell(excel_row, col_price_source).value = safe_str(row.get("price_approval_source") or "manual_final_review")
            ws.cell(excel_row, col_price_tag_accent).value = safe_str(row.get("price_tag_accent"))
        wb.save(out)
        self.log(f"Факт: создан рабочий файл {out.name}; пропущено {skipped}, частично {partial}, цены {sale_changed}, названия {name_changed}.")
        self.last_effective_sai_path = str(out)
        return self.last_effective_sai_path

    # ---------- workflow ----------
    def create_waybill_and_check(self) -> None:
        if self.running:
            return
        if not self.sai_path or not self.sai_path.exists():
            QMessageBox.warning(self, "SAI", "Выберите SAI-файл.")
            return
        if not self.preflight_barcodes_or_stop("create_waybill"):
            return
        supplier = self.selected_supplier_name()
        supplier_id = self.selected_supplier_id()
        if not supplier or not supplier_id:
            QMessageBox.warning(self, "SAI", "Дождитесь загрузки поставщиков SIGMA и выберите поставщика из списка.")
            return
        date = self.date_edit.text().strip() or infer_date_from_sai_file(self.sai_path)
        self.date_edit.setText(date)
        self.save_work_context()
        self.waybill_id = ""; self.storehouse_id = ""; self.created_import_path = ""
        self.set_receipt_stage("draft")
        self.set_busy(True, "Создаю черновик прихода в SIGMA…")
        self.log(f"Создаю черновик: {supplier}, дата {date}")
        cfg = self.private_cfg()
        args = [sys.executable, "-u", str(WAYBILL_CREATOR_SCRIPT), "--mode", "create-waybill", "--user-data-dir", str(PROFILE_DIR), "--invoice-date", date, "--supplier-id", supplier_id, "--supplier-name", supplier]
        storehouse_id = str(cfg.get("storehouse_id") or DEFAULT_STOREHOUSE_ID or "").strip()
        if storehouse_id:
            args += ["--storehouse-id", storehouse_id]
        if str(cfg.get("sigma_internal_company_id") or "").strip():
            args += ["--company-id", str(cfg.get("sigma_internal_company_id")).strip()]
        append_sigma_auth_cli_args(args, cfg)
        if bool(load_private_config().get("browser_visible", False)):
            args += ["--visible-browser"]
        else:
            args += ["--hidden-browser"]
        if bool(cfg.get("prefer_bundled_chromium", True)):
            args += ["--prefer-bundled-chromium"]
        auto_after = int(cfg.get("hidden_browser_auto_visible_after_seconds") or 0)
        if auto_after > 0:
            args += ["--hidden-auto-visible-after", str(auto_after)]
        self.proc = QProcess(self)
        self.proc.setWorkingDirectory(str(APP_DIR))
        self.proc.readyReadStandardOutput.connect(self._waybill_stdout)
        self.proc.readyReadStandardError.connect(self._waybill_stdout)
        self.proc.finished.connect(self._waybill_finished)
        self.proc.start(args[0], args[1:])

    def _waybill_stdout(self) -> None:
        if not self.proc:
            return
        data = bytes(self.proc.readAllStandardOutput()).decode("utf-8", errors="replace")
        data += bytes(self.proc.readAllStandardError()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            if not line:
                continue
            if "SAI_WAYBILL_CREATED_JSON:" in line:
                raw = line.split("SAI_WAYBILL_CREATED_JSON:", 1)[1].strip()
                try:
                    payload = json.loads(raw)
                    self.waybill_id = str(payload.get("waybill_id") or "")
                    self.storehouse_id = str(payload.get("storehouse_id") or "")
                    self.supplier_id = str(payload.get("supplier_id") or "")
                    supplier = str(payload.get("supplier_name") or self.selected_supplier_name()).strip()
                    if supplier:
                        self.select_supplier(str(payload.get("supplier_id") or ""), supplier)
                    self.log(f"Черновик создан: {self.waybill_id}")
                    if self.storehouse_id:
                        self.log(f"Склад: {payload.get('storehouse_name') or self.storehouse_id}")
                    self.save_work_context()
                except Exception as exc:
                    self.log(f"Не смог прочитать JSON черновика: {exc}")
            else:
                self.log(line)

    def _waybill_finished(self, code: int, status: QProcess.ExitStatus) -> None:
        if code == 0 and self.waybill_id:
            self.log("Черновик создан. Запускаю проверку товаров…")
            self.set_receipt_stage("catalog")
            self.set_busy(False)
            self.check_products(force_after_import=False)
        else:
            self.set_receipt_stage("draft", error=True)
            self.set_busy(False, f"Черновик не создан. Код {code}.")
            QMessageBox.warning(self, "SAI", f"Создание черновика завершилось с кодом {code}. Смотри лог.")

    def check_products(self, force_after_import: bool = False, force_catalog_refresh: bool = False) -> None:
        if self.running:
            return
        if not self.sai_path:
            QMessageBox.warning(self, "SAI", "Выберите SAI-файл.")
            return
        if create_import_file_from_sigma_api is None:
            QMessageBox.critical(self, "SAI", "Не подключилась рабочая логика проверки товаров.")
            return
        if not self.preflight_barcodes_or_stop("check_products"):
            return
        self.save_work_context()
        self.set_receipt_stage("catalog")
        if force_after_import:
            self.awaiting_post_import_verification = True
            simple_file_history_mark(self.sai_path, "импортирован вручную — обновить каталог", self.selected_supplier_name(), self.waybill_id, self.created_import_path or "import")
        self.set_busy(True, "Проверяю товары в SIGMA/SQLite текущей сессии…")
        signals = WorkerSignals()
        signals.log.connect(self.log)
        signals.check_done.connect(self.handle_check_result)
        signals.check_error.connect(self.handle_check_error)
        def worker():
            try:
                cfg = self.private_cfg()
                if force_after_import or force_catalog_refresh:
                    cfg["_catalog_refreshed_this_session"] = False
                processing_path = self.processing_sai_file()
                if Path(processing_path) != Path(self.sai_path):
                    signals.log.emit(f"Факт 0: для проверки/импорта используется файл без нулевых позиций: {Path(processing_path).name}")
                # v1.21.72: even when the actual checked file is a temporary working copy
                # without zero-quantity shortage rows, the manual Import_*.xlsx must be
                # created in a visible user folder next to the original SAI file.
                # Otherwise autoimport failure leaves the user with no obvious fallback.
                visible_import_dir = self.visible_import_output_dir()
                signals.log.emit(f"Импорт новых товаров: ручной XLSX будет сохранён в {visible_import_dir}")
                result = create_import_file_from_sigma_api(
                    str(processing_path),
                    self.selected_supplier_name() or "Поставщик",
                    self.date_edit.text().strip(),
                    cfg,
                    out_dir=visible_import_dir,
                    log_callback=signals.log.emit,
                )
                # Product checks are intentionally not added to user history.
                # History contains only successfully completed SIGMA receipts.
                signals.check_done.emit(result)
            except Exception as exc:
                signals.check_error.emit(str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def return_to_semi_auto(self) -> None:
        """Return the current saved receipt to barcode collection without resetting it."""
        if self.running:
            QMessageBox.warning(self, "SAI", "Дождитесь завершения текущей операции.")
            return
        path = Path(self.sai_path) if self.sai_path else None
        if path is None or not path.exists():
            QMessageBox.warning(self, "SAI", "Текущий SAI-файл не найден.")
            return
        try:
            self.save_work_context()
            page = getattr(self.parent_page, "semi_receipt_page", None)
            if page is None:
                raise RuntimeError("Полуавтоматический режим не подключён.")
            sai_receipt_drafts.update_by_package(path, stage="semi_auto")
            page.set_sai_file(path)
            self.parent_page.show_semi_receipt()
            self.parent_page.notify(
                "Сбор штрихкодов",
                "Текущий привоз сохранён и открыт в полуавтоматическом режиме.",
                "success",
            )
        except Exception as exc:
            QMessageBox.critical(self, "SAI", f"Не удалось вернуться к сбору ШК:\n{exc}")

    def handle_check_error(self, text: str) -> None:
        self.set_receipt_stage("catalog", error=True)
        self.set_busy(False, "Ошибка проверки товаров.")
        self.log(f"ОШИБКА проверки: {text}")
        if self.awaiting_post_import_verification:
            self.imported_btn.setText("Проверить появление товаров")
            self.set_logical_enabled(self.imported_btn, True)
        QMessageBox.critical(self, "SAI", text)

    def handle_check_result(self, result: Dict[str, Any]) -> None:
        self.last_check_result = result or {}
        self.source_rows = self.last_check_result.get("source_rows") or self.source_rows
        if self.last_check_result.get("catalog_force_refreshed") or self.last_check_result.get("catalog_session_refreshed"):
            self.catalog_refreshed_this_session = True
        for line in self.last_check_result.get("catalog_debug", []):
            self.log("SIGMA: " + str(line))
        total = int(self.last_check_result.get("total") or 0)
        ok = int(self.last_check_result.get("ok_full") or 0)
        missing = int(self.last_check_result.get("missing") or 0)
        no_barcode = int(self.last_check_result.get("no_barcode") or 0)
        conflicts = int(self.last_check_result.get("conflicts") or 0)
        add_needed = int(self.last_check_result.get("barcode_add_needed") or 0)
        self.log(f"Проверка: строк {total}, найдено {ok}, импорт {missing}, без ШК {no_barcode}, конфликты {conflicts}, добавить ШК {add_needed}")
        self.created_import_path = str(self.last_check_result.get("import_path") or "")
        self.barcode_update_path = str(self.last_check_result.get("barcode_update_path") or "")
        self.price_preview_done = False
        self.price_preview_log_path = ""
        self.set_logical_enabled(self.price_approval_btn, False)
        self.set_logical_enabled(self.approved_ndp_btn, False)
        self.set_logical_enabled(self.apply_btn, False)
        self.set_logical_enabled(self.import_later_btn, False)
        self.set_logical_enabled(self.conflict_file_btn, False)
        self.set_logical_enabled(self.conflict_continue_btn, False)
        if no_barcode:
            self.set_receipt_stage("products")
            # Safety net: the GUI should stop before import generation, but if the core check still returned no_barcode,
            # do not offer/import the generated file yet. Let the user fix barcodes in-place first.
            if self.created_import_path:
                try:
                    Path(self.created_import_path).unlink(missing_ok=True)
                    self.log("Импорт SIGMA удалён: он будет создан заново после заполнения ШК.")
                except Exception:
                    pass
                self.created_import_path = ""
            rows = self.last_check_result.get("no_barcode_rows") or self.source_rows
            self.show_missing_barcode_editor(self.source_rows, continue_mode="check_products")
            return
        self.populate_table(self.source_rows, status="найдено" if not (missing or conflicts or add_needed) else "проверить")
        if conflicts and self.resolve_barcode_conflicts(self.last_check_result.get("conflict_rows") or []):
            self.set_busy(False, "Выбор правильных карточек сохранён. Повторяю проверку…")
            QTimer.singleShot(80, lambda: self.check_products(force_catalog_refresh=False))
            return
        if conflicts or add_needed:
            self.set_receipt_stage("products")
            self.set_busy(False, "СТОП: исправь конфликт ШК, затем нажми «Исправлено — проверить и продолжить».")
            self.set_logical_enabled(self.create_btn, False)
            self.set_logical_enabled(self.fix_barcodes_btn, False)
            self.set_logical_enabled(self.imported_btn, False)
            self.set_logical_enabled(self.fact_btn, False)
            self.set_logical_enabled(self.price_approval_btn, False)
            self.set_logical_enabled(self.approved_ndp_btn, False)
            self.set_logical_enabled(self.apply_btn, False)
            self.set_logical_enabled(self.conflict_file_btn, bool(self.barcode_update_path and Path(self.barcode_update_path).exists()))
            self.set_logical_enabled(self.conflict_continue_btn, True)
            if self.barcode_update_path:
                self.log(f"Файл конфликтов/ШК: {self.barcode_update_path}")
            return
        if missing:
            self.set_receipt_stage("products")
            if self.awaiting_post_import_verification:
                try:
                    import_path = Path(self.created_import_path or "")
                    if import_path.exists():
                        need_category = read_import_xlsx_category_rows(import_path)
                        remembered = remembered_categories_by_row(need_category, self.import_category_memory)
                        if remembered:
                            patch_import_xlsx_for_sigma(import_path, remembered)
                            self.log(
                                "Повторная проверка: прежние категории сохранены "
                                f"для {len(remembered)} товаров; запрашивать их заново не буду."
                            )
                except Exception as exc:
                    self.log(f"Не удалось восстановить категории повторного импорта: {exc}")
                self.set_busy(
                    False,
                    f"Импорт принят. SIGMA пока не показала {missing} товаров в каталоге. "
                    "Категории сохранены; повторно назначать их не нужно.",
                )
                self.imported_btn.setText("Проверить появление товаров")
                self.set_logical_enabled(self.imported_btn, True)
                self.import_later_btn.setText("Продолжить сейчас")
                self.import_later_btn.setToolTip(
                    "Продолжить без ожидания локального каталога. Перед вводом SAI проверит все товары напрямую в SIGMA."
                )
                self.set_logical_enabled(self.import_later_btn, True)
                self.post_import_retry_count += 1
                if self.post_import_retry_count <= 2:
                    delay_seconds = 8 if self.post_import_retry_count == 1 else 20
                    self.log(
                        f"SIGMA ещё индексирует импорт. Автоматически проверю снова через {delay_seconds} сек."
                    )
                    QTimer.singleShot(
                        delay_seconds * 1000,
                        lambda: self.check_products(force_after_import=True),
                    )
                return
            simple_file_history_mark(self.sai_path, "создан импорт новых товаров", self.selected_supplier_name(), self.waybill_id, self.created_import_path)
            self.log(f"Создан импорт новых товаров: {self.created_import_path}")
            try:
                p = Path(self.created_import_path)
                if p.exists():
                    self.log(f"Файл ручного импорта доступен: {p.parent}")
            except Exception:
                pass
            self.set_logical_enabled(self.create_btn, False)
            self.set_logical_enabled(self.fix_barcodes_btn, False)
            self.set_logical_enabled(self.imported_btn, False)
            self.set_logical_enabled(self.fact_btn, False)
            self.set_logical_enabled(self.apply_btn, False)
            self.start_new_products_import_flow(missing)
            return
        simple_file_history_mark(self.sai_path, "проверен: все позиции найдены", self.selected_supplier_name(), self.waybill_id)
        self.awaiting_post_import_verification = False
        self.post_import_retry_count = 0
        self.imported_btn.setText("Импорт выполнен — обновить и проверить")
        self.import_later_btn.setText("Продолжить позже")
        self.import_later_btn.setToolTip("")
        self.set_logical_enabled(self.import_later_btn, False)
        self.set_logical_enabled(self.create_btn, False)
        self.set_logical_enabled(self.fix_barcodes_btn, False)
        self.set_logical_enabled(self.imported_btn, False)
        self.set_logical_enabled(self.fact_btn, False)
        self.set_logical_enabled(self.price_approval_btn, bool(self.waybill_id))
        self.set_logical_enabled(self.approved_ndp_btn, False)
        self.set_logical_enabled(self.apply_btn, bool(self.waybill_id))
        self.set_receipt_stage("fact")
        self.set_busy(False, "Все позиции найдены. Проверьте факт приёмки, затем согласуйте цены или сразу введите приход.")
        # Fact is not a separate step/button anymore: show it once immediately.
        self.show_fact_table()


    def open_conflict_report(self) -> None:
        path = Path(self.barcode_update_path or "")
        if not path.exists():
            QMessageBox.warning(self, "SAI", "Файл конфликтов не найден. Исправь конфликт в SAI/SIGMA и нажми кнопку повторной проверки.")
            return
        open_path(path)

    def resolve_barcode_conflicts(self, conflict_rows: List[Dict[str, Any]]) -> bool:
        """Ask the operator once instead of returning to an endless conflict loop."""
        if not conflict_rows or save_barcode_conflict_resolution is None:
            return False
        selected: List[tuple] = []
        for index, conflict in enumerate(conflict_rows, 1):
            row = dict(conflict.get("row") or {})
            products = list(conflict.get("products") or [])
            if len(products) < 2:
                return False

            dialog = QDialog(self)
            dialog.setWindowTitle(f"Конфликт ШК {index} из {len(conflict_rows)}")
            dialog.setMinimumWidth(620)
            layout = QVBoxLayout(dialog)
            title = QLabel("Выбери правильную карточку товара SIGMA")
            title.setObjectName("SectionTitle")
            layout.addWidget(title)
            codes = ", ".join(conflict.get("codes") or row.get("barcodes") or [])
            source = QLabel(
                f"В накладной:\n{safe_str(row.get('name'))}\n"
                f"ШК: {codes}\n\n"
                "SIGMA всё ещё возвращает этот ШК у нескольких карточек. "
                "Твой выбор сохранится, и SAI больше не будет спрашивать для этого товара."
            )
            source.setWordWrap(True)
            layout.addWidget(source)
            combo = QComboBox()
            combo.setObjectName("WorkbenchInput")
            combo.setMinimumHeight(44)
            for product in products:
                name = safe_str(product.get("name")) or "Без названия"
                product_id = safe_str(product.get("id") or product.get("sigma_id"))
                combo.addItem(f"{name}  ·  ID {product_id}", product_id)
            layout.addWidget(combo)
            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            buttons.button(QDialogButtonBox.Ok).setText("Выбрать эту карточку")
            buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
            buttons.accepted.connect(dialog.accept)
            buttons.rejected.connect(dialog.reject)
            layout.addWidget(buttons)
            if dialog.exec() != QDialog.Accepted:
                return False
            selected.append((row, safe_str(combo.currentData())))

        try:
            for row, product_id in selected:
                save_barcode_conflict_resolution(row, product_id)
                self.log(f"Сохранён ручной выбор карточки SIGMA: {row.get('name')} → {product_id}")
        except Exception as exc:
            QMessageBox.critical(self, "Конфликт ШК", f"Не удалось сохранить выбор:\n{exc}")
            return False
        return True

    def continue_after_conflict(self) -> None:
        if self.running:
            return
        self.log("Конфликт отмечен как исправленный. Перечитываю SAI-файл и принудительно обновляю каталог SIGMA…")
        self.refresh_preview()
        self.catalog_refreshed_this_session = False
        self.set_logical_enabled(self.conflict_file_btn, False)
        self.set_logical_enabled(self.conflict_continue_btn, False)
        QTimer.singleShot(80, lambda: self.check_products(force_catalog_refresh=True))

    def start_new_products_import_flow(self, missing_count: int) -> None:
        """Collect categories for import XLSX, upload it to SIGMA, then re-check and continue."""
        import_path = Path(self.created_import_path or "")
        if not import_path.exists():
            self.set_busy(False, "Нужно импортировать новые товары, но файл импорта не найден.")
            self.set_logical_enabled(self.imported_btn, True)
            QMessageBox.warning(self, "SAI", "SAI нашёл новые товары, но не нашёл XLSX импорта. Можно нажать ручное обновление после импорта.")
            return
        # Product check finishes in the busy state. Release it before starting the
        # next stage; otherwise start_sigma_auto_import() sees running=True and
        # silently returns, leaving the workflow with no continuation button.
        self.set_busy(False, f"Файл импорта готов: {import_path.name}. Можно импортировать автоматически или вручную.")
        self.set_logical_enabled(self.imported_btn, True)
        self.log("Продолжение после ручного импорта доступно: «Импорт выполнен — обновить и проверить».")
        try:
            need_category = read_import_xlsx_category_rows(import_path)
        except Exception as exc:
            self.log(f"Мастер категорий недоступен: {exc}")
            need_category = []
        if need_category and self.import_category_memory:
            remembered = remembered_categories_by_row(need_category, self.import_category_memory)
            if remembered:
                patch_import_xlsx_for_sigma(import_path, remembered)
                need_category = read_import_xlsx_category_rows(import_path)
                self.log(
                    "Повторный импорт: ранее выбранные категории восстановлены "
                    f"для {len(remembered)} товаров."
                )
        if need_category:
            self.set_busy(False, f"Нужно указать категории для {len(need_category)} новых товаров.")
            cats = load_sigma_categories_static(self.private_cfg())
            if not cats:
                self.set_logical_enabled(self.imported_btn, True)
                QMessageBox.warning(self, "SAI", "Не удалось загрузить категории SIGMA. Импорт создан, но категории нужно заполнить вручную.")
                return
            def persist_category_choice(row: Dict[str, Any], category: str) -> None:
                persist_import_xlsx_category(
                    import_path,
                    int(row.get("excel_row") or 0),
                    category,
                )
                barcode = safe_str(row.get("barcode"))
                name_key = _free_norm(row.get("name"))
                if barcode:
                    self.import_category_memory["barcode:" + barcode] = category
                if name_key:
                    self.import_category_memory["name:" + name_key] = category
                save_import_category_memory(self.import_category_memory)

            dlg = ImportCategoryWizardDialog(
                need_category,
                cats,
                self,
                assignment_callback=persist_category_choice,
            )
            if dlg.exec() != QDialog.Accepted:
                self.set_busy(False, "Импорт новых товаров остановлен: категории не заполнены.")
                self.set_logical_enabled(self.imported_btn, True)
                return
            # Do not continue if user skipped some required categories.
            missing_rows = [r for r in need_category if int(r.get("excel_row") or 0) not in dlg.assignments]
            if missing_rows:
                self.set_busy(False, "Импорт остановлен: не все новые товары получили категорию.")
                self.set_logical_enabled(self.imported_btn, True)
                QMessageBox.warning(self, "SAI", f"Остались товары без категории: {len(missing_rows)}. Импорт не запущен.")
                return
            try:
                patch_import_xlsx_for_sigma(import_path, dlg.assignments)
                for row in need_category:
                    category = safe_str(dlg.assignments.get(int(row.get("excel_row") or 0)))
                    if not category:
                        continue
                    barcode = safe_str(row.get("barcode"))
                    name = _free_norm(row.get("name"))
                    if barcode:
                        self.import_category_memory["barcode:" + barcode] = category
                    if name:
                        self.import_category_memory["name:" + name] = category
                save_import_category_memory(self.import_category_memory)
                self.log(f"Категории сохранены в импорт: {import_path}")
            except Exception as exc:
                self.set_busy(False, "Не удалось сохранить категории в XLSX импорта.")
                self.set_logical_enabled(self.imported_btn, True)
                QMessageBox.critical(self, "SAI", str(exc))
                return
        else:
            try:
                patch_import_xlsx_for_sigma(import_path, {})
            except Exception as exc:
                self.log(f"XLSX импорта не удалось нормализовать: {exc}")
        self.start_sigma_auto_import(import_path)

    def confirm_manual_import(self) -> None:
        """Preserve category choices before SIGMA catalog verification rewrites Import_*.xlsx."""
        if self.running:
            return
        try:
            import_path = Path(self.created_import_path or "")
            if import_path.exists():
                remembered = read_import_xlsx_category_memory(import_path)
                if remembered:
                    self.import_category_memory.update(remembered)
                    save_import_category_memory(self.import_category_memory)
                    self.log(
                        "Ручной импорт подтверждён: сохранил выбранные категории "
                        f"({len(remembered)} ключей) до обновления каталога."
                    )
        except Exception as exc:
            self.log(f"Не удалось сохранить категории перед проверкой: {exc}")
        self.awaiting_post_import_verification = True
        self.post_import_retry_count = 0
        self.imported_btn.setText("Проверить появление товаров")
        self.check_products(force_after_import=True)

    def continue_import_later(self) -> None:
        """Leave post-import polling without losing the receipt or category choices."""
        if self.running:
            return
        missing = int((self.last_check_result or {}).get("missing") or 0)
        if self.awaiting_post_import_verification and missing:
            # The old catalogue endpoint can lag far behind a successful SIGMA
            # import. Do not trap the operator here: both price preview and APPLY
            # use the live product lookup, and APPLY runs a full read-only live
            # preflight before writing the first receipt row.
            self.awaiting_post_import_verification = False
            self.post_import_retry_count = 0
            self.imported_btn.setText("Импорт выполнен — обновить и проверить")
            self.import_later_btn.setText("Продолжить позже")
            self.import_later_btn.setToolTip("")
            self.populate_table(self.source_rows, status="ожидает live-проверки")
            self.set_logical_enabled(self.imported_btn, False)
            self.set_logical_enabled(self.import_later_btn, False)
            self.set_logical_enabled(self.price_approval_btn, bool(self.waybill_id))
            self.set_logical_enabled(self.apply_btn, bool(self.waybill_id))
            self.set_busy(
                False,
                "Импорт подтверждён. Можно продолжать: перед вводом SAI проверит все товары напрямую в SIGMA.",
            )
            self.log(
                f"Оператор подтвердил импорт. Не жду отстающий локальный каталог для {missing} товаров; "
                "перед APPLY будет выполнена полная live-проверка SIGMA без записи."
            )
            self.show_fact_table()
            return
        self.save_work_context()
        self.set_logical_enabled(self.import_later_btn, False)
        self.parent_page.notify(
            "Импорт товаров",
            "Привоз сохранён. Категории останутся назначенными; проверку можно продолжить позже.",
            "success",
        )
        self.parent_page.show_receipt_hub()

    def start_sigma_auto_import(self, import_path: Path) -> None:
        # This stage is allowed to start immediately after the check worker. The
        # manual continuation button remains logically available as a fallback.
        if self.running:
            self.set_busy(False)
        self.set_receipt_stage("products")
        self.set_logical_enabled(self.imported_btn, True)
        self.set_busy(True, "Импортирую новые товары в SIGMA…")
        signals = SigmaImportSignals()
        signals.log.connect(self.log)
        signals.done.connect(self.handle_sigma_import_done)
        signals.error.connect(self.handle_sigma_import_error)
        cfg = self.private_cfg()
        def worker():
            try:
                result = sigma_import_xlsx_via_cloud(import_path, cfg, log_callback=signals.log.emit)
                signals.done.emit(result or {})
            except Exception as exc:
                signals.error.emit(str(exc))
        threading.Thread(target=worker, daemon=True).start()

    def handle_sigma_import_done(self, payload: Dict[str, Any]) -> None:
        progress = payload.get("progress") or {}
        created = progress.get("created", 0)
        ignored = progress.get("ignored", 0)
        errors = progress.get("errors", 0)
        self.log(f"Импорт SIGMA завершён: создано {created}, пропущено {ignored}, ошибок {errors}.")
        if int(errors or 0) > 0:
            self.set_receipt_stage("products", error=True)
            self.set_busy(False, "Импорт завершён с ошибками. Проверь файл ошибок в SIGMA.")
            self.set_logical_enabled(self.imported_btn, True)
            QMessageBox.warning(self, "SAI", f"Импорт новых товаров завершён с ошибками: {errors}. Продолжение остановлено.")
            return
        simple_file_history_mark(self.sai_path, "импортирован автоматически", self.selected_supplier_name(), self.waybill_id, self.created_import_path or "import")
        try:
            remembered = read_import_xlsx_category_memory(self.created_import_path)
            if remembered:
                self.import_category_memory.update(remembered)
                save_import_category_memory(self.import_category_memory)
        except Exception:
            pass
        self.awaiting_post_import_verification = True
        self.post_import_retry_count = 0
        self.catalog_refreshed_this_session = False
        self.set_busy(False, "Новые товары импортированы. Обновляю каталог и продолжаю проверку…")
        QTimer.singleShot(120, lambda: self.check_products(force_after_import=True))

    def handle_sigma_import_error(self, text: str) -> None:
        self.set_receipt_stage("products", error=True)
        self.log(f"ОШИБКА автоимпорта SIGMA: {text}")
        self.set_busy(False, "Автоимпорт не удался. Можно импортировать XLSX вручную и нажать кнопку обновления.")
        self.set_logical_enabled(self.imported_btn, True)
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle("SAI")
        box.setText("Автоматический импорт новых товаров не удался.")
        box.setInformativeText(str(text) + "\n\nФайл для ручного импорта сохранён:\n" + str(self.created_import_path))
        open_btn = box.addButton("Открыть папку импорта", QMessageBox.ActionRole)
        box.addButton("OK", QMessageBox.AcceptRole)
        box.exec()
        if box.clickedButton() is open_btn:
            try:
                p = Path(self.created_import_path)
                open_path(p.parent if p.suffix else p)
            except Exception:
                pass

    def _api_first_args(self, excel_path: str, price_policy: str, apply: bool = False) -> List[str]:
        cfg = self.private_cfg()
        args = [
            sys.executable, "-u", str(API_FIRST_SCRIPT),
            "--excel", excel_path,
            "--sheet", getattr(self, "effective_sheet_name", None) or self.sheet_name,
            "--waybill-id", self.waybill_id,
            "--storehouse-id", self.storehouse_id or str(cfg.get("storehouse_id") or DEFAULT_STOREHOUSE_ID or ""),
            "--user-data-dir", str(PROFILE_DIR),
            "--price-policy", price_policy,
            "--stop-on-error",
        ]
        if apply:
            args.append("--apply")
            # Always verify every productId read-only before the first receipt write.
            # This prevents a short/internal barcode lookup failure from leaving a
            # partially filled waybill after earlier rows were already written.
            args.append("--live-preflight")
        if bool(load_private_config().get("browser_visible", False)):
            args.append("--visible-browser")
        else:
            args.append("--hidden-browser")
        if bool(cfg.get("prefer_bundled_chromium", True)):
            args.append("--prefer-bundled-chromium")
        auto_after = int(cfg.get("hidden_browser_auto_visible_after_seconds") or 0)
        if auto_after > 0:
            args += ["--hidden-auto-visible-after", str(auto_after)]
        append_sigma_auth_cli_args(args, cfg)
        return args

    def start_price_approval(self) -> None:
        if self.running:
            return
        if not self.waybill_id:
            QMessageBox.warning(self, "SAI", "Сначала создайте черновик прихода.")
            return
        try:
            # Fact is committed once before price comparison. From this moment the
            # quantity/status controls are frozen and the working SAI file is authoritative.
            self.persist_fact_values_to_source()
            excel_for_preview = self.create_effective_sai_for_apply()
        except Exception as exc:
            QMessageBox.critical(self, "SAI", str(exc))
            return
        policy = "max"
        self.price_preview_done = False
        self.manual_price_approval_used = False
        self.set_receipt_stage("prices")
        # Hide all continuation choices while the simulation is running.
        self.set_logical_enabled(self.price_approval_btn, False)
        self.set_logical_enabled(self.apply_btn, False)
        self.set_logical_enabled(self.fact_btn, False)
        self.set_logical_enabled(self.approved_ndp_btn, False)
        self.set_busy(True, "Симулирую приход: сравниваю цены SAI с действующими ценами SIGMA…")
        self.log(f"СОГЛАСОВАНИЕ ЦЕН: dry-run, политика {policy}. SIGMA не изменяется.")
        args = self._api_first_args(excel_for_preview, policy, apply=False)
        self.price_proc = QProcess(self)
        self.price_proc.setWorkingDirectory(str(APP_DIR))
        self.price_proc.readyReadStandardOutput.connect(self._price_preview_stdout)
        self.price_proc.readyReadStandardError.connect(self._price_preview_stdout)
        self.price_proc.finished.connect(self._price_preview_finished)
        self.price_proc.start(args[0], args[1:])

    def _price_preview_stdout(self) -> None:
        if not self.price_proc:
            return
        data = bytes(self.price_proc.readAllStandardOutput()).decode("utf-8", errors="replace")
        data += bytes(self.price_proc.readAllStandardError()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            if line:
                self.log(line)

    def _price_preview_finished(self, code: int, status: QProcess.ExitStatus) -> None:
        self.price_proc = None
        log_path = latest_api_first_log()
        if code != 0 or not log_path or not Path(log_path).exists():
            self.set_receipt_stage("prices", error=True)
            self.set_logical_enabled(self.price_approval_btn, True)
            self.set_logical_enabled(self.apply_btn, True)
            self.set_busy(False, f"Симуляция цен остановилась с кодом {code}. Можно повторить или ввести приход без согласования.")
            QMessageBox.warning(self, "Согласование цен", "Не удалось просимулировать приход. Данные SIGMA не изменялись. Можно повторить расчёт или ввести приход без согласования.")
            return
        try:
            self.price_preview_log_path = str(log_path)
            self.load_price_approval_table(Path(log_path))
            approval_path = self.create_approval_ndp(Path(log_path), agreed=False)
            self.price_approval_document_path = str(approval_path)
            self.price_preview_done = True
            self.manual_price_approval_used = True
            # No recalculate/save buttons: the approved values are saved
            # automatically when the user presses «Ввести приход».
            self.set_logical_enabled(self.price_approval_btn, False)
            self.set_logical_enabled(self.fact_btn, False)
            self.set_logical_enabled(self.approved_ndp_btn, False)
            self.set_logical_enabled(self.apply_btn, True)
            self.set_receipt_stage("prices")
            self.set_busy(False, "Цены рассчитаны. Измените жёлтые поля при необходимости и нажмите «Ввести приход».")
            self.show_document_actions(
                approval_path,
                "Накладная на согласование",
                "Предварительная накладная создана. Цена SAI сравнена с ценой SIGMA, в «Утвержд.» поставлена большая цена."
            )
        except Exception as exc:
            self.set_receipt_stage("prices", error=True)
            self.set_logical_enabled(self.price_approval_btn, True)
            self.set_logical_enabled(self.apply_btn, True)
            self.set_busy(False, "Не удалось подготовить накладную на согласование. Можно повторить или продолжить без неё.")
            self.log(f"ОШИБКА согласования цен: {exc}")
            QMessageBox.critical(self, "Согласование цен", str(exc))

    def load_price_approval_table(self, log_path: Path) -> None:
        if read_bot_log_rows is None:
            raise RuntimeError("Не подключилось чтение отчёта цен.")
        rows = read_bot_log_rows(str(log_path))
        by_excel: Dict[str, Dict[str, Any]] = {}
        errors = []
        for row in rows:
            key_raw = safe_str(row.get("excel_row"))
            try:
                key = str(int(float(key_raw)))
            except Exception:
                key = key_raw
            if key:
                by_excel[key] = row
            if safe_str(row.get("status")).upper() != "OK":
                errors.append(row)
        if errors:
            raise RuntimeError(f"Симуляция вернула ошибки по строкам: {len(errors)}. Утверждение цен остановлено.")

        for r in range(self.result_table.rowCount()):
            number_item = self.result_table.item(r, 0)
            key = safe_str(number_item.data(Qt.UserRole) if number_item else "")
            log_row = by_excel.get(key) or {}
            incoming = safe_str(log_row.get("incoming_selling_price"))
            sigma = safe_str(log_row.get("sigma_existing_selling_price"))
            final = safe_str(log_row.get("final_selling_price") or incoming)
            values = (incoming, sigma, final)
            for col, value in zip((6, 7, 8), values):
                item = self.result_table.item(r, col)
                if item is None:
                    item = QTableWidgetItem("")
                    self.result_table.setItem(r, col, item)
                item.setText(value)
                item.setTextAlignment(Qt.AlignCenter)
                if col == 8:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    item.setBackground(QColor("#fff4cc"))
                    item.setToolTip("Нажмите карандаш справа. Введённая вручную цена получит приоритет над ценой SIGMA.")
                else:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
            name_item = self.result_table.item(r, 1)
            if name_item:
                name_item.setFlags(name_item.flags() & ~Qt.ItemIsEditable)
                name_item.setBackground(QColor("#fff4cc"))
                name_item.setToolTip("Нажмите карандаш справа, чтобы изменить название и остальные поля товара.")
            if r < len(self.source_rows):
                self.source_rows[r]["_sigma_sale"] = sigma
                self.source_rows[r]["_approved_sale"] = final
        self.result_table.show()
        self.result_table.resizeRowsToContents()
        self.log("Согласование цен: таблица заполнена. Любая строка редактируется через карандаш справа.")

    def _renamed_document_path(self, path: Path, prefix: str) -> Path:
        base_name = path.name
        if base_name.startswith("Накладная_для_продавцов_"):
            base_name = prefix + base_name[len("Накладная_для_продавцов_"):]
        else:
            base_name = prefix + base_name
        candidate = path.with_name(base_name)
        if candidate.exists() and candidate.resolve() != path.resolve():
            candidate = candidate.with_name(candidate.stem + "_" + dt.datetime.now().strftime("%H%M%S") + candidate.suffix)
        if candidate.resolve() != path.resolve():
            path.replace(candidate)
        return candidate

    def create_approval_ndp(self, log_path: Optional[Path], agreed: bool) -> Path:
        if not self.sai_path or create_ndp_file is None:
            raise RuntimeError("Нет SAI-файла или не подключилась НДП-логика.")
        visible_dir = self.visible_import_output_dir()
        if agreed:
            source = Path(self.create_effective_sai_for_apply())
            out_path, _count = create_ndp_file(
                str(source), self.selected_supplier_name() or "Поставщик", self.date_edit.text().strip(),
                log_path=None, out_dir=visible_dir,
            )
            final_path = self._renamed_document_path(Path(out_path), "Накладная_согласованная_")
        else:
            source = Path(self.processing_sai_path or self.sai_path)
            out_path, _count = create_ndp_file(
                str(source), self.selected_supplier_name() or "Поставщик", self.date_edit.text().strip(),
                log_path=str(log_path) if log_path else None, out_dir=visible_dir,
            )
            final_path = self._renamed_document_path(Path(out_path), "Накладная_на_согласование_")
        self.log(f"Создан документ: {final_path}")
        return final_path

    def show_document_actions(self, path: Path, title: str, text: str) -> None:
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Information)
        box.setWindowTitle(title)
        box.setText(text)
        box.setInformativeText(str(path))
        open_btn = box.addButton("Открыть", QMessageBox.ActionRole)
        print_btn = box.addButton("Печатать", QMessageBox.ActionRole)
        box.addButton("Закрыть", QMessageBox.AcceptRole)
        box.exec()
        if box.clickedButton() is open_btn:
            open_path(path)
        elif box.clickedButton() is print_btn:
            if print_file_silent(path):
                self.parent_page.notify("Печать", f"Отправлено на печать: {path.name}", "success")
            else:
                QMessageBox.warning(self, title, "Не удалось отправить документ на печать. Открой его и напечатай вручную.")

    def save_approved_ndp(self) -> None:
        if not self.price_preview_done:
            QMessageBox.warning(self, "Согласование цен", "Сначала подготовьте предварительную накладную и получите цены SIGMA.")
            return
        try:
            self.persist_approved_values_to_source()
            path = self.create_approval_ndp(None, agreed=True)
            self.show_document_actions(
                path,
                "Согласованная накладная",
                "Согласованная накладная сохранена с текущими названиями, фактическим количеством и утверждёнными ценами."
            )
        except Exception as exc:
            QMessageBox.critical(self, "Согласованная накладная", str(exc))

    def apply_waybill(self) -> None:
        if self.running:
            return
        if not self.waybill_id:
            QMessageBox.warning(self, "SAI", "Сначала создайте черновик прихода.")
            return
        try:
            self.persist_fact_values_to_source()
            if self.price_preview_done:
                # Approved values are saved automatically, then compared once
                # more with the live SIGMA price so a stale preview can never
                # lower the product price during APPLY.
                self.persist_approved_values_to_source()
                price_policy = "max"
                self.log("APPLY: повторно сравниваю утверждённые цены с действующими ценами SIGMA и выбираю большие.")
                # The separate save button is gone: choosing approval implies that
                # the agreed invoice is saved automatically before real APPLY.
                agreed_path = self.create_approval_ndp(None, agreed=True)
                self.approved_ndp_path = str(agreed_path)
                self.log(f"Согласованная накладная сохранена автоматически: {agreed_path}")
            else:
                price_policy = "max"
                self.log("APPLY: согласование пропущено, обязательно выбираю большую цену между SAI и SIGMA.")
            self.processing_sai_path = ""
            self.last_effective_sai_path = ""
            self.final_document_source_path = ""
            excel_for_apply = self.create_effective_sai_for_apply()
        except Exception as exc:
            QMessageBox.critical(self, "SAI", str(exc)); return
        args = self._api_first_args(excel_for_apply, price_policy, apply=True)
        self.set_receipt_stage("apply")
        self.set_busy(True, "Заполняю приход через SIGMA API…")
        self.log("APPLY: старт заполнения прихода.")
        self.proc = QProcess(self)
        self.proc.setWorkingDirectory(str(APP_DIR))
        self.proc.readyReadStandardOutput.connect(self._apply_stdout)
        self.proc.readyReadStandardError.connect(self._apply_stdout)
        self.proc.finished.connect(self._apply_finished)
        self.proc.start(args[0], args[1:])

    def _apply_stdout(self) -> None:
        if not self.proc:
            return
        data = bytes(self.proc.readAllStandardOutput()).decode("utf-8", errors="replace")
        data += bytes(self.proc.readAllStandardError()).decode("utf-8", errors="replace")
        for line in data.splitlines():
            if line:
                self.log(line)

    def synchronize_final_prices_from_apply(self) -> None:
        """Make the successful APPLY result the single source for all documents.

        This also covers the optional fast path where price approval was skipped:
        final_selling_price from the live APPLY log is placed into «Утвержд.», then
        persisted to the selected SAI file before NDP or price tags can be printed.
        """
        log_path = Path(self.last_log_path or "")
        if not log_path.exists():
            raise RuntimeError("Не найден журнал успешного ввода прихода с итоговыми ценами.")
        if self.manual_price_approval_used and self.price_preview_done:
            # Never overwrite manually approved values from a later APPLY log.
            # They were persisted before APPLY and must remain authoritative.
            self.persist_approved_values_to_source()
            self.log("Ручные утверждённые цены сохранены без подмены журналом APPLY.")
        else:
            # Direct path without approval: take the actual final SIGMA prices.
            self.load_price_approval_table(log_path)
            self.price_preview_done = True
            self.price_preview_log_path = str(log_path)
            self.persist_approved_values_to_source()
        self.last_effective_sai_path = ""
        self.processing_sai_path = ""
        self.final_document_source_path = ""
        self.log("Единые итоговые цены записаны в SAI-файл для прихода, НДП и ценников.")

    def show_only_final_print_action(self) -> None:
        for btn in (
            self.create_btn, self.fix_barcodes_btn, self.imported_btn,
            self.conflict_file_btn, self.conflict_continue_btn, self.fact_btn,
            self.price_approval_btn, self.approved_ndp_btn, self.apply_btn,
        ):
            self.set_logical_enabled(btn, False)
        self.ndp_btn.setText("Печатать НДП и Ценники")
        self.set_logical_enabled(self.ndp_btn, True)

    def _apply_finished(self, code: int, status: QProcess.ExitStatus) -> None:
        self.last_log_path = str(latest_api_first_log() or "")
        if code == 0:
            info: Dict[str, Any] = {}
            audit = latest_price_audit_for_log(Path(self.last_log_path)) if self.last_log_path else ""
            try:
                info = sai_db.record_apply_log(
                    self.last_log_path,
                    str(self.sai_path),
                    self.selected_supplier_name(),
                    self.date_edit.text().strip(),
                    self.waybill_id,
                    audit_path=audit,
                    app_version=APP_VERSION,
                )
                self.current_apply_run_id = int(info.get("apply_run_id") or 0)
                self.log(
                    f"SQLite: успешный приход сохранён, позиций {info.get('ok_count')}, "
                    f"товаров {quantity_text(info.get('total_quantity'))}, продажа {money(info.get('selling_total'))}"
                )
            except Exception as exc:
                self.log(f"SQLite: не смог сохранить успешный приход — {str(exc)[:160]}")
            simple_file_history_mark(self.sai_path, "приход заполнен", self.selected_supplier_name(), self.waybill_id)
            try:
                self.synchronize_final_prices_from_apply()
            except Exception as exc:
                self.set_receipt_stage("apply", error=True)
                self.set_busy(False, "Приход заполнен, но итоговые цены не удалось подготовить для документов.")
                self.log(f"КРИТИЧЕСКАЯ ОШИБКА синхронизации итоговых цен: {exc}")
                QMessageBox.critical(
                    self,
                    "SAI",
                    "Приход в SIGMA заполнен, но SAI не смог синхронизировать итоговые цены. "
                    "НДП и ценники заблокированы, чтобы не напечатать старые цены.\n\n" + str(exc),
                )
                return

            if self.current_apply_run_id and self.sai_path:
                try:
                    archive_dir = sai_receipt_archive.archive_successful_receipt(
                        self.current_apply_run_id,
                        Path(self.sai_path),
                        approval_preview_path=Path(self.price_approval_document_path) if self.price_approval_document_path else None,
                        approval_final_path=Path(self.approved_ndp_path) if self.approved_ndp_path else None,
                        log_path=Path(self.last_log_path) if self.last_log_path else None,
                        audit_path=Path(audit) if audit else None,
                    )
                    self.log(f"Архив прихода создан: {archive_dir}")
                except Exception as exc:
                    self.log(f"Не удалось полностью сохранить файлы прихода в историю: {exc}")
                    self.parent_page.notify("История приходов", "Приход сохранён, но не все файлы удалось скопировать в архив.", "warning")

            try:
                if self.sai_path:
                    sai_receipt_drafts.mark_completed_by_package(self.sai_path)
            except Exception:
                pass
            self.show_only_final_print_action()
            self.set_receipt_stage("documents")
            self.set_busy(False, "Приход заполнен. НДП и ценники возьмут одинаковые итоговые цены.")
            self.parent_page.refresh_history_table()

            # Generate both final documents after every successful receipt.
            # Explicit settings decide which of them is sent to the printer.
            cfg = load_private_config()
            if bool(cfg.get("auto_print_ndp", False)) or bool(cfg.get("auto_print_price_tags", True)):
                QTimer.singleShot(80, lambda: self.create_ndp_and_price_tags(auto_print=True, quiet=True))
        else:
            self.set_receipt_stage("apply", error=True)
            # Failed or partial APPLY attempts are intentionally absent from user history.
            title = "Не удалось продолжить ввод прихода"
            details = ""
            try:
                rows = read_bot_log_rows(self.last_log_path) if self.last_log_path and read_bot_log_rows else []
                failed = next((row for row in rows if safe_str(row.get("status")).upper() not in {"", "OK"}), None)
                if failed:
                    product = safe_str(failed.get("name")) or safe_str(failed.get("barcode")) or "неизвестный товар"
                    reason = safe_str(failed.get("message")) or "SIGMA не подтвердила операцию"
                    if "timed out" in reason.casefold():
                        reason = "SIGMA слишком долго не отвечала. Автоматические повторы закончились."
                    elif "connection" in reason.casefold():
                        reason = "Соединение с SIGMA оборвалось. Автоматические повторы закончились."
                    details = f"\n\nТовар: {product}\nПричина: {reason}"
            except Exception:
                details = ""
            if code == 5:
                message = (
                    "SAI остановился на одной товарной строке, чтобы не продолжать приход с ошибкой."
                    f"{details}\n\nУже введённые строки не потеряны. Нажмите «Ввести приход» ещё раз: "
                    "SAI повторно проверит и безопасно продолжит заполнение."
                )
            else:
                message = f"Ввод прихода остановился.{details}\n\nТехнический код: {code}."
            self.set_busy(False, message.split("\n", 1)[0])
            QMessageBox.warning(self, title, message)

    def active_apply_run_id(self) -> int:
        if self.current_apply_run_id:
            return int(self.current_apply_run_id)
        if self.waybill_id:
            rows = db_rows(
                """
                SELECT id FROM apply_runs
                WHERE waybill_id=? AND status='ok' AND COALESCE(error_count,0)=0
                ORDER BY id DESC LIMIT 1
                """,
                (self.waybill_id,),
            )
            if rows:
                self.current_apply_run_id = int(rows[0].get("id") or 0)
        return int(self.current_apply_run_id or 0)

    def final_document_source(self) -> Path:
        """Create one canonical source and reuse it for both final documents."""
        cached = Path(self.final_document_source_path) if self.final_document_source_path else None
        if cached is not None and cached.exists():
            return cached
        self.processing_sai_path = ""
        self.last_effective_sai_path = ""
        source = Path(self.create_effective_sai_for_apply())
        if not source.exists():
            raise RuntimeError("Не удалось создать единый рабочий SAI-файл для документов.")
        self.final_document_source_path = str(source)
        return source

    def validate_ndp_against_source(self, source: Path, ndp_path: Path) -> None:
        """Block stale NDP output if any quantity or approved price differs."""
        if load_sai_rows is None:
            return
        _sheet, source_rows = load_sai_rows(str(source))
        expected = [
            (safe_str(row.get("name")), float(parse_int_or_float(row.get("qty"))), float(row.get("sale") or 0))
            for row in source_rows
            if safe_str(row.get("name")) and float(parse_int_or_float(row.get("qty"))) > 0
        ]
        wb = load_workbook(ndp_path, data_only=True, read_only=True)
        ws = wb.active
        actual = []
        for r in range(3, ws.max_row + 1):
            name = safe_str(ws.cell(r, 3).value)
            if not name:
                continue
            actual.append((name, float(parse_int_or_float(ws.cell(r, 4).value)), float(ws.cell(r, 5).value or 0)))
        try:
            wb.close()
        except Exception:
            pass
        if len(actual) != len(expected):
            raise RuntimeError(f"Проверка НДП не пройдена: ожидалось строк {len(expected)}, получено {len(actual)}.")
        for idx, (exp, got) in enumerate(zip(expected, actual), start=1):
            if exp[0] != got[0] or abs(exp[1] - got[1]) > 1e-6 or abs(exp[2] - got[2]) > 0.01:
                raise RuntimeError(
                    f"Проверка НДП не пройдена, строка {idx}: "
                    f"ожидалось «{exp[0]}», {exp[1]}, {exp[2]:.2f}; "
                    f"получено «{got[0]}», {got[1]}, {got[2]:.2f}."
                )

    def create_ndp_artifact(self) -> tuple[Optional[Path], int]:
        if not self.sai_path or create_ndp_file is None:
            raise RuntimeError("Нет SAI-файла или не подключилась НДП-логика.")
        source_for_docs = self.final_document_source()
        out_path, count = create_ndp_file(
            str(source_for_docs),
            self.selected_supplier_name() or "Поставщик",
            self.date_edit.text().strip(),
            log_path=None,
        )
        self.validate_ndp_against_source(source_for_docs, Path(out_path))
        self.log(f"НДП создана и проверена по единому утверждённому SAI-файлу: {out_path} · строк {count}")
        return Path(out_path), int(count or 0)

    def create_price_tags_artifact(self) -> tuple[Optional[Path], int]:
        if not self.sai_path:
            raise RuntimeError("Нет SAI-файла для ценников.")
        out = _unique_desktop_path("Ценники", ".pdf")
        source_for_tags = self.final_document_source()
        pdf_path, count = create_price_tags_pdf_from_sai_file(source_for_tags, out)
        self.log(f"Ценники созданы: {pdf_path} · {count} шт.")
        return pdf_path, int(count or 0)

    def create_ndp_and_price_tags(self, auto_print: bool = False, quiet: bool = False, force_print: bool = False) -> None:
        if hasattr(self, "set_receipt_stage"):
            self.set_receipt_stage("documents")
        apply_run_id = self.active_apply_run_id()
        if auto_print:
            now = time.monotonic()
            duplicate_recent = (
                apply_run_id > 0
                and self._last_final_print_apply_run_id == apply_run_id
                and now - self._last_final_print_at < 120.0
            )
            if self._final_print_in_progress or (duplicate_recent and not force_print):
                self.log("ПЕЧАТЬ: повторный запуск того же прихода заблокирован.")
                self.parent_page.notify(
                    "Печать уже выполнена",
                    "НДП и ценники этого прихода уже отправлены. Повторное задание не создано.",
                    "info",
                )
                return
            self._final_print_in_progress = True

        ndp_path: Optional[Path] = None
        tags_path: Optional[Path] = None
        ndp_count = 0
        tags_count = 0
        errors: List[str] = []
        printed: List[str] = []
        print_failed: List[str] = []
        try:
            ndp_path, ndp_count = self.create_ndp_artifact()
        except Exception as exc:
            errors.append(f"НДП: {exc}")
            self.log(f"ОШИБКА НДП: {exc}")
        try:
            tags_path, tags_count = self.create_price_tags_artifact()
        except Exception as exc:
            errors.append(f"Ценники: {exc}")
            self.log(f"ОШИБКА ценников: {exc}")

        if apply_run_id:
            try:
                if ndp_path:
                    sai_receipt_archive.archive_generated_document(apply_run_id, "ndp", ndp_path)
                if tags_path:
                    sai_receipt_archive.archive_generated_document(apply_run_id, "price_tags", tags_path)
                self.parent_page.refresh_history_table()
            except Exception as exc:
                self.log(f"ОШИБКА архива истории: {exc}")
                self.parent_page.notify("История приходов", "Документы созданы, но не скопировались в архив истории.", "warning")

        if auto_print:
            cfg = load_private_config()
            from sai_print_jobs import dispatch_once

            def dispatch_document(kind: str, submit) -> bool:
                if not apply_run_id:
                    raise RuntimeError("Нет идентификатора прихода для безопасной печати")
                outcome = dispatch_once(f"receipt:{apply_run_id}:{kind}", submit, reprint=force_print)
                state = outcome["state"]
                if state == "already_submitted":
                    self.log(f"ПЕЧАТЬ: {kind} уже отправлен ранее; повтор пропущен.")
                    return False
                if state != "submitted":
                    raise RuntimeError("Отправка уже выполняется или её результат не подтверждён. Проверьте очередь принтера; для повтора используйте явную повторную печать.")
                return True

            if ndp_path and (force_print or bool(cfg.get("auto_print_ndp", False))):
                try:
                    if dispatch_document("ndp", lambda: print_file_silent(ndp_path)):
                        printed.append("НДП")
                except Exception as exc:
                    print_failed.append(f"НДП не отправилась на принтер: {exc}")
            if tags_path and (force_print or bool(cfg.get("auto_print_price_tags", True))):
                try:
                    tags_printer = configured_a4_printer_name(cfg)
                    tag_items = read_sai_price_items(self.final_document_source())
                    if not tag_items:
                        raise RuntimeError("в итоговом приходе нет товаров для ценников")
                    if dispatch_document("price_tags", lambda: print_price_tags_a4(tag_items, tags_printer)):
                        printed.append(f"ценники → {tags_printer}")
                except Exception as exc:
                    print_failed.append(f"ценники не отправились на принтер: {exc}")
            if printed:
                self.parent_page.notify("Печать", "Отправлено на печать: " + ", ".join(printed), "success")
            if print_failed:
                self.parent_page.notify("Печать", "Не напечатано: " + "; ".join(print_failed), "warning")
            if force_print and print_failed:
                errors.extend(print_failed)

        if errors:
            if hasattr(self, "set_receipt_stage"):
                self.set_receipt_stage("documents", error=True)
            self._final_print_in_progress = False
            QMessageBox.warning(self, "НДП и ценники", "Создание завершилось с ошибками:\n\n" + "\n".join(errors))
            return

        msg = []
        if ndp_path:
            msg.append(f"НДП: {ndp_path}\nстрок: {ndp_count}")
        if tags_path:
            msg.append(f"Ценники: {tags_path}\nценников: {tags_count}")
        if not quiet:
            QMessageBox.information(self, "НДП и ценники", "Готово:\n\n" + "\n\n".join(msg))
            try:
                if tags_path:
                    open_path(tags_path.parent)
                elif ndp_path:
                    open_path(ndp_path.parent)
            except Exception:
                pass
        else:
            if auto_print and printed:
                self.parent_page.notify("НДП и ценники", "Файлы созданы. На печать отправлено: " + ", ".join(printed), "success")
            else:
                self.parent_page.notify("НДП и ценники", "Файлы созданы.", "success")
        if auto_print and printed and not print_failed:
            self._last_final_print_apply_run_id = int(apply_run_id or 0)
            self._last_final_print_at = time.monotonic()
        self._final_print_in_progress = False
        if hasattr(self, "set_receipt_stage"):
            self.set_receipt_stage("documents", complete=True)

    def print_final_documents(self) -> None:
        """The only final receipt action: create and print both documents."""
        self.create_ndp_and_price_tags(auto_print=True, quiet=False, force_print=True)

    def create_ndp(self) -> None:
        self.create_ndp_and_price_tags(auto_print=False, quiet=False)

    def launch_classic_with_context(self) -> None:
        if self.save_work_context():
            self.parent_page.launch_classic()
            self.log("Старый рабочий SAI открыт вручную как fallback.")


# ---------------------------------------------------------------------------
# Free receipt helpers
# ---------------------------------------------------------------------------

def _free_norm(text: Any) -> str:
    text = sai_product_names.searchable_text(text).upper().replace("Ё", "Е")
    text = re.sub(r"[^0-9A-ZА-Я]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _free_tokens(text: Any) -> List[str]:
    return [t for t in _free_norm(text).split() if t]


def _free_money_float(text: Any) -> float:
    return manual_money_float(text)


def _free_price_text(value: Any) -> str:
    return manual_price_text(value)


def _free_round_sale_from_purchase(purchase: Any, markup_percent: Any) -> float:
    return manual_round_sale_from_purchase(purchase, markup_percent)


def _free_default_markup_choice() -> int:
    cfg = load_private_config()
    value = _free_money_float(cfg.get("free_receipt_base_markup_percent") or cfg.get("default_markup_percent") or 60)
    choices = [50, 60, 70]
    return min(choices, key=lambda x: abs(x - value))


def _free_category_name_from_raw(obj: Any) -> str:
    """Best-effort category extraction from cached SIGMA product JSON."""
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except Exception:
            return ""
    if isinstance(obj, dict):
        direct_keys = {
            "categoryName", "productCategoryName", "category", "groupName",
            "productGroupName", "assortmentGroupName", "parentCategoryName",
        }
        nested_keys = {
            "category", "productCategory", "product_category", "group",
            "productGroup", "assortmentGroup", "parentCategory",
        }
        for key in direct_keys:
            value = obj.get(key)
            if isinstance(value, str) and value.strip():
                return safe_str(value)
        for key in nested_keys:
            value = obj.get(key)
            if isinstance(value, dict):
                for name_key in ("name", "title", "displayName", "fullName"):
                    got = value.get(name_key)
                    if isinstance(got, str) and got.strip():
                        return safe_str(got)
        for value in obj.values():
            got = _free_category_name_from_raw(value)
            if got:
                return got
    elif isinstance(obj, list):
        for value in obj:
            got = _free_category_name_from_raw(value)
            if got:
                return got
    return ""




def _free_category_id_from_raw(obj: Any) -> str:
    """Best-effort category id extraction from cached SIGMA product JSON."""
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except Exception:
            return ""
    if isinstance(obj, dict):
        for key in ("categoryId", "productCategoryId", "product_category_id", "groupId", "productGroupId", "assortmentGroupId"):
            value = obj.get(key)
            if value:
                return safe_str(value)
        for key in ("category", "productCategory", "product_category", "group", "productGroup", "assortmentGroup"):
            value = obj.get(key)
            if isinstance(value, dict):
                for id_key in ("id", "uuid", "categoryId"):
                    got = value.get(id_key)
                    if got:
                        return safe_str(got)
        for value in obj.values():
            got = _free_category_id_from_raw(value)
            if got:
                return got
    elif isinstance(obj, list):
        for value in obj:
            got = _free_category_id_from_raw(value)
            if got:
                return got
    return ""


def _free_generated_barcodes_path() -> Path:
    return USER_DATA_DIR / "free_receipt_generated_barcodes.json"


def _free_load_generated_barcodes() -> List[str]:
    try:
        data = json.loads(_free_generated_barcodes_path().read_text(encoding="utf-8"))
        if isinstance(data, list):
            return [safe_str(x) for x in data if safe_str(x)]
        if isinstance(data, dict):
            return [safe_str(x) for x in data.get("barcodes", []) if safe_str(x)]
    except Exception:
        pass
    return []


def _free_save_generated_barcodes(codes: List[str]) -> None:
    try:
        ensure_runtime_dirs()
        uniq = []
        for c in codes:
            c = safe_str(c)
            if c and c not in uniq:
                uniq.append(c)
        _free_generated_barcodes_path().write_text(json.dumps({"barcodes": uniq[-5000:]}, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

def _free_row_key(row: Dict[str, Any]) -> tuple:
    return ManualReceiptRow.from_mapping(row).identity_key


def _free_normalize_unit(value: Any) -> str:
    text = safe_str(value).lower().replace(".", " ").replace(",", " ").strip()
    compact = re.sub(r"[^0-9a-zа-яё]+", "", text)
    if compact in {"кг", "kg", "kgs", "килограмм", "килограмма", "килограммов"}:
        return "кг"
    if compact in {"г", "гр", "g", "gr", "gram", "grams", "грамм", "грамма", "граммов"}:
        return "г"
    if compact in {"пара", "пары", "пар", "pair", "pairs"}:
        return "пара"
    return normalize_unit(value)


def _free_recursive_price(obj: Any) -> float:
    price_keys = {
        "sellingCostPerUnit", "sellingCost", "sellingPrice", "productPrice",
        "retailPrice", "salePrice", "price", "cost", "value",
    }
    if isinstance(obj, str):
        try:
            obj = json.loads(obj)
        except Exception:
            return 0.0
    if isinstance(obj, dict):
        for key, value in obj.items():
            if key in price_keys:
                price = _free_money_float(value)
                if price:
                    return price
        for value in obj.values():
            price = _free_recursive_price(value)
            if price:
                return price
    elif isinstance(obj, list):
        for item in obj:
            price = _free_recursive_price(item)
            if price:
                return price
    return 0.0


def _json_pick(raw: Any, keys: List[str], default: Any = "") -> Any:
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            raw = {}
    if not isinstance(raw, dict):
        return default
    for key in keys:
        if key in raw and raw.get(key) not in (None, ""):
            return raw.get(key)
    for value in raw.values():
        if isinstance(value, dict):
            got = _json_pick(value, keys, None)
            if got not in (None, ""):
                return got
    return default


def _collect_api_items(payload: Any) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "content", "data", "results", "productCategories", "units", "sellPoints", "sell-points", "points", "shops"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
        # Some SIGMA endpoints return a dictionary keyed by ids.
        dict_values = [x for x in payload.values() if isinstance(x, dict)]
        if dict_values:
            return dict_values
    return []


def _api_item_id(item: Dict[str, Any]) -> str:
    for key in ("id", "uuid", "sellPointId", "shopId", "pointId"):
        value = item.get(key)
        if value:
            return safe_str(value)
    return ""


def make_barcode_pixmap(value: str, width: int = 560, height: int = 172) -> QPixmap:
    code = str(value or "").strip()
    pix = QPixmap(width, height)
    pix.fill(QColor("white"))
    painter = QPainter(pix)
    painter.setRenderHint(QPainter.Antialiasing, False)
    try:
        modules, symbology = barcode_modules_for_print(code)
        margin = 16 if symbology.startswith("EAN") or symbology == "UPC-A" else max(34, int(width * 0.12))
        bar_h = height - 42
        module_w = max(1, int((width - margin * 2) / max(1, len(modules))))
        if symbology.startswith("Code128") and len(modules) * 3 + margin * 2 <= width:
            module_w = max(module_w, 3)
        total_w = module_w * len(modules)
        x0 = max(margin, (width - total_w) // 2)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#111827"))
        for i, bit in enumerate(modules):
            if bit == "1":
                painter.drawRect(x0 + i * module_w, 10, module_w, bar_h)
        painter.setPen(QColor("#111827"))
        font = QFont("Consolas", 12)
        font.setBold(True)
        painter.setFont(font)
        painter.drawText(0, height - 20, width, 20, Qt.AlignHCenter, code)
    finally:
        painter.end()
    return pix


# ---------------------------------------------------------------------------
# Price tags (ценники)
# ---------------------------------------------------------------------------

def _unique_desktop_path(prefix: str, suffix: str) -> Path:
    base = desktop_dir() / f"{prefix}_{dt.datetime.now().strftime('%d%m%y')}{suffix}"
    if not base.exists():
        return base
    return desktop_dir() / f"{prefix}_{dt.datetime.now().strftime('%d%m%y_%H%M%S')}{suffix}"


def print_file_silent(path: str | Path) -> bool:
    """Print an A4 document only through the configured ordinary printer."""
    try:
        return print_file_to_windows_printer(path, configured_a4_printer_name())
    except Exception:
        return False



def configured_a4_printer_name(cfg: Optional[Dict[str, Any]] = None) -> str:
    settings = dict(cfg or load_private_config())
    selected = _resolve_a4_printer_name(
        settings.get("a4_printer") or settings.get("document_printer") or settings.get("price_tags_printer"),
        _list_windows_printers(),
        _get_default_windows_printer(),
    )
    return _require_a4_printer_name(selected)


def print_file_to_windows_printer(path: str | Path, printer_name: str = "") -> bool:
    """Print an A4 file to an explicitly selected non-thermal printer."""
    p = Path(path)
    printer_name = _require_a4_printer_name(printer_name)
    if sys.platform.startswith("win"):
        try:
            rc = ctypes.windll.shell32.ShellExecuteW(None, "printto", str(p), f'"{printer_name}"', None, 0)
            return int(rc) > 32
        except Exception:
            return False
    return False


# ---------------------------------------------------------------------------
# Thermal label printing (Xprinter / TSPL)
# ---------------------------------------------------------------------------

def _thermal_config() -> Dict[str, Any]:
    return normalize_thermal_config(load_private_config())


def _draw_thermal_label_image(item: Dict[str, Any], size_key: str = "58x40") -> QImage:
    return render_thermal_label(item, size_key, _thermal_config())


def print_thermal_price_label(item: Dict[str, Any], copies: int = 1, parent: QWidget | None = None, printer_override: str | None = None) -> bool:
    del parent
    return print_thermal_label(item, _thermal_config(), copies=copies, printer_override=printer_override)


def print_test_thermal_label(parent: QWidget | None = None) -> None:
    item = {"name": "ТЕСТОВЫЙ ЦЕННИК SAI", "barcode": "10000542", "price": 123, "unit": "штука"}
    try:
        print_thermal_price_label(item, copies=1, parent=parent)
        if parent is not None:
            QMessageBox.information(parent, "Термоэтикетка", "Тестовая этикетка отправлена на печать.")
    except Exception as exc:
        if parent is not None:
            QMessageBox.warning(parent, "Термоэтикетка", f"Не удалось напечатать тестовую этикетку.\n\n{exc}")

def _highlight_match_html(text: str, query: str) -> str:
    """Return escaped text with typed tokens highlighted in bold."""
    src = str(text or "")
    escaped = html.escape(src)
    tokens = []
    for token in _free_tokens(query):
        token = token.strip()
        if len(token) >= 2 and token not in tokens:
            tokens.append(token)
    if not tokens:
        return escaped
    out = []
    pos = 0
    lower_src = src.lower()
    spans = []
    for token in tokens:
        start = 0
        token_l = token.lower()
        while True:
            idx = lower_src.find(token_l, start)
            if idx < 0:
                break
            spans.append((idx, idx + len(token)))
            start = idx + max(1, len(token))
    if not spans:
        return escaped
    spans.sort()
    merged = []
    for a, b in spans:
        if not merged or a > merged[-1][1]:
            merged.append([a, b])
        else:
            merged[-1][1] = max(merged[-1][1], b)
    for a, b in merged:
        if a > pos:
            out.append(html.escape(src[pos:a]))
        out.append("<b>" + html.escape(src[a:b]) + "</b>")
        pos = b
    if pos < len(src):
        out.append(html.escape(src[pos:]))
    return "".join(out)


class SuggestionRow(QFrame):
    """One clickable row inside a floating overlay suggestion popup."""

    def __init__(self, title_html: str, meta: str, index: int, callback, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.index = index
        self.callback = callback
        self.setObjectName("SuggestionRow")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(58)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(2)
        title = QLabel(title_html)
        title.setObjectName("SuggestionTitle")
        title.setTextFormat(Qt.RichText)
        title.setWordWrap(False)
        subtitle = QLabel(html.escape(str(meta or "")))
        subtitle.setObjectName("SuggestionMeta")
        subtitle.setTextFormat(Qt.RichText)
        subtitle.setWordWrap(False)
        layout.addWidget(title)
        layout.addWidget(subtitle)

    def mousePressEvent(self, event):  # noqa: N802 - Qt override name
        if event.button() == Qt.LeftButton:
            self.callback(self.index)
            event.accept()
            return
        super().mousePressEvent(event)


class SuggestionPopup(QFrame):
    """Lightweight z-layer overlay used instead of table widgets in the form layout."""

    def __init__(self, parent: QWidget, on_pick) -> None:
        super().__init__(parent)
        self.on_pick = on_pick
        self.setObjectName("SuggestionPopup")
        self.setVisible(False)
        self.setMaximumHeight(420)
        self.setAttribute(Qt.WA_StyledBackground, True)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.setSpacing(0)
        self._scroll = QScrollArea(self)
        self._scroll.setObjectName("SuggestionScroll")
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(self._scroll)

        self._content = QWidget()
        self._content.setObjectName("SuggestionContent")
        self._layout = QVBoxLayout(self._content)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(3)
        self._scroll.setWidget(self._content)

    def clear(self) -> None:
        while self._layout.count():
            item = self._layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def show_rows(self, rows: List[Dict[str, Any]], anchor: QWidget, query: str, kind: str = "product", max_rows: Optional[int] = 8) -> None:
        self.clear()
        display_rows = list(rows if max_rows is None else rows[:max(0, int(max_rows))])
        if not display_rows:
            self.hide()
            return
        for i, r in enumerate(display_rows):
            if kind == "category":
                title = _highlight_match_html(r.get("name", ""), query)
                meta = "категория SIGMA"
            else:
                title = _highlight_match_html(r.get("name", ""), query)
                bcs = ", ".join([safe_str(x) for x in (r.get("barcodes") or []) if safe_str(x)])
                details = []
                if bcs:
                    details.append("ШК " + short_text(bcs, 52))
                article = safe_str(r.get("vendor_code") or r.get("article"))
                if article:
                    details.append("арт. " + short_text(article, 32))
                if r.get("price"):
                    details.append(money(r.get("price")) + " ₽")
                if r.get("category"):
                    details.append(short_text(str(r.get("category")), 32))
                meta = " · ".join(details)
            self._layout.addWidget(SuggestionRow(title, meta, i, self.on_pick, self._content))
        self._layout.addStretch(1)
        parent = self.parentWidget()
        if parent is None:
            return
        top_left = anchor.mapTo(parent, QPoint(0, anchor.height() + 6))
        width = max(360, anchor.width())
        visible_rows = min(len(display_rows), 7)
        height = min(self.maximumHeight(), 14 + max(1, visible_rows) * 62)
        self.setGeometry(top_left.x(), top_left.y(), width, height)
        self.raise_()
        self.show()




class ImportCategoryWizardDialog(QDialog):
    """Fast one-by-one category picker for new products before SIGMA import."""
    def __init__(
        self,
        rows: List[Dict[str, Any]],
        categories: List[Dict[str, str]],
        parent: QWidget | None = None,
        assignment_callback: Optional[Callable[[Dict[str, Any], str], None]] = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Категории новых товаров")
        self.setModal(True)
        self.resize(820, 560)
        self.rows = list(rows or [])
        self.categories = list(categories or [])
        self.assignments: Dict[int, str] = {}
        self.index = 0
        self.filtered: List[Dict[str, str]] = []
        self._auto_apply_guard = False
        self._filter_generation = 0
        self._assignment_callback = assignment_callback

        layout = QVBoxLayout(self)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        self.progress_label = QLabel("")
        self.progress_label.setObjectName("WorkbenchSection")
        layout.addWidget(self.progress_label)

        self.name_label = QLabel("")
        self.name_label.setWordWrap(True)
        f = QFont("Segoe UI", 16)
        f.setWeight(QFont.Bold)
        self.name_label.setFont(f)
        layout.addWidget(self.name_label)

        self.meta_label = QLabel("")
        self.meta_label.setObjectName("WorkbenchSubtitle")
        self.meta_label.setWordWrap(True)
        layout.addWidget(self.meta_label)

        self.category_edit = QLineEdit()
        self.category_edit.setObjectName("WorkbenchInput")
        self.category_edit.setMinimumHeight(44)
        self.category_edit.setPlaceholderText("Напечатай категорию: 03, сад, кухня...")
        self.category_edit.textChanged.connect(self.filter_categories)
        self.category_edit.returnPressed.connect(self.apply_first_match)
        layout.addWidget(self.category_edit)

        self.table = RoundedTableWidget(0, 1)
        self.table.setObjectName("DataTable")
        self.table.setHorizontalHeaderLabels(["Подходящие категории"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.doubleClicked.connect(lambda *_: self.apply_selected())
        layout.addWidget(self.table, 1)

        buttons = QHBoxLayout()
        self.skip_btn = QPushButton("Пропустить")
        self.skip_btn.setObjectName("SoftButton")
        self.skip_btn.clicked.connect(self.skip_current)
        self.cancel_btn = QPushButton("Отмена")
        self.cancel_btn.setObjectName("GhostButton")
        self.cancel_btn.clicked.connect(self.reject)
        buttons.addWidget(self.skip_btn)
        buttons.addStretch(1)
        buttons.addWidget(self.cancel_btn)
        layout.addLayout(buttons)

        self.show_current()

    def show_current(self) -> None:
        self._filter_generation += 1
        while self.index < len(self.rows) and int(self.rows[self.index].get("excel_row") or 0) in self.assignments:
            self.index += 1
        if self.index >= len(self.rows):
            self.accept()
            return
        row = self.rows[self.index]
        self.progress_label.setText(f"Новые товары: {self.index + 1} из {len(self.rows)}")
        self.name_label.setText(safe_str(row.get("name")))
        parts = []
        if safe_str(row.get("barcode")):
            parts.append("ШК: " + safe_str(row.get("barcode")))
        if safe_str(row.get("article")):
            parts.append("Артикул: " + safe_str(row.get("article")))
        if safe_str(row.get("price")):
            parts.append("Цена: " + money(row.get("price")))
        if safe_str(row.get("unit")):
            parts.append("Ед.: " + safe_str(row.get("unit")))
        self.meta_label.setText(" · ".join(parts) or "Выберите категорию для импорта товара в SIGMA.")
        self.category_edit.blockSignals(True)
        self.category_edit.clear()
        self.category_edit.blockSignals(False)
        self.category_edit.setFocus()
        self.filter_categories("")

    def filter_categories(self, text: str) -> None:
        self._filter_generation += 1
        generation = self._filter_generation
        q = _free_norm(text)
        toks = [x for x in q.split() if x]
        if not toks:
            self.filtered = self.categories[:80]
        else:
            self.filtered = [c for c in self.categories if all(t in _free_norm(c.get("name")) for t in toks)][:80]
        self.table.setRowCount(len(self.filtered))
        for i, c in enumerate(self.filtered):
            item = QTableWidgetItem(safe_str(c.get("name")))
            self.table.setItem(i, 0, item)
        if self.filtered:
            self.table.selectRow(0)
        # If the query uniquely resolves a category, apply immediately: type -> apply -> next product.
        if q and len(self.filtered) == 1 and not self._auto_apply_guard:
            cat_name = safe_str(self.filtered[0].get("name"))
            norm_name = _free_norm(cat_name)
            strong = q == norm_name or norm_name.startswith(q) or all(t in norm_name for t in toks)
            if strong and len(q) >= 2:
                self._auto_apply_guard = True
                expected_index = self.index
                selected = dict(self.filtered[0])
                QTimer.singleShot(
                    180,
                    lambda: self.apply_scheduled_category(selected, expected_index, generation),
                )

    def apply_scheduled_category(self, cat: Dict[str, str], expected_index: int, generation: int) -> None:
        if self.index != expected_index or self._filter_generation != generation:
            return
        self.apply_category(cat)

    def apply_first_match(self) -> None:
        if self.filtered:
            self.apply_category(self.filtered[0])

    def apply_selected(self) -> None:
        row = self.table.currentRow()
        if 0 <= row < len(self.filtered):
            self.apply_category(self.filtered[row])

    def apply_category(self, cat: Dict[str, str]) -> None:
        if self.index >= len(self.rows):
            self.accept(); return
        excel_row = int(self.rows[self.index].get("excel_row") or 0)
        name = safe_str(cat.get("name"))
        if not excel_row or not name:
            return
        self._filter_generation += 1
        if self._assignment_callback is not None:
            try:
                self._assignment_callback(dict(self.rows[self.index]), name)
            except Exception as exc:
                self._auto_apply_guard = False
                QMessageBox.critical(self, "Категория не сохранена", str(exc))
                return
        self.assignments[excel_row] = name
        self.index += 1
        self._auto_apply_guard = False
        self.show_current()

    def skip_current(self) -> None:
        self.index += 1
        self._auto_apply_guard = False
        self.show_current()

class FreeReceiptPage(QWidget):
    """Manual add-card for the unified manual receipt workflow.

    It collects rows, searches the local SIGMA catalog, edits barcodes/quantity/price
    and then passes an internal SAI Package into the normal workbench. Categories are
    intentionally not requested here: new-product categories are handled later by
    the common import/category wizard.
    """

    def __init__(self, parent_page: "MainPage") -> None:
        super().__init__()
        self.parent_page = parent_page
        self.manual_service = ManualReceiptService()
        self.free_catalog_service = shared_free_catalog_service()
        self.categories: List[Dict[str, str]] = []
        self.units: List[str] = ["штука", "м", "кг", "г", "пара"]
        self.quick_category_buttons: List[QPushButton] = []
        self.selected_category: Dict[str, str] = {}
        self.current_product: Dict[str, Any] = {}
        self.current_old_sale_price: float = 0.0
        self.current_barcodes: List[str] = []
        self.active_barcode_index: int = 0
        self.search_results: List[Dict[str, Any]] = []
        self.category_search_results: List[Dict[str, str]] = []
        self.rows: List[Dict[str, Any]] = []
        self.search_timer = QTimer(self)
        self.search_timer.setInterval(160)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.run_product_search)
        self.autosave_timer = QTimer(self)
        self.autosave_timer.setSingleShot(True)
        self.autosave_timer.setInterval(900)
        self.autosave_timer.timeout.connect(self.save_free_receipt_draft)
        self._references_loaded = False
        self._draft_loaded = False
        self._suspend_manual_autosave = False
        self._auto_barcode_applied = ""
        self.free_receipt_saved_xml_path: Optional[Path] = None
        self.free_receipt_saved_meta: Dict[str, Any] = {}
        self.free_receipt_saved_signature: str = ""
        self.last_free_print_row: Dict[str, Any] = {}
        self.last_free_print_copies: int = 0
        self._free_label_qty_manual = False
        self.free_catalog_service.warm_catalog_cache(background=True)
        self.build_ui()
        self.populate_rows()
        self.load_free_receipt_draft()

    def build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        scroll = QScrollArea(); scroll.setObjectName("WorkbenchScroll"); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll, 1)
        body = QWidget(); body.setObjectName("WorkbenchBody"); scroll.setWidget(body)
        root = QVBoxLayout(body); root.setContentsMargins(28, 22, 28, 30); root.setSpacing(16)

        top_card = QFrame(); top_card.setObjectName("WorkbenchCard")
        top = QGridLayout(top_card); top.setContentsMargins(22, 18, 22, 18); top.setHorizontalSpacing(14); top.setVerticalSpacing(10)
        top.addWidget(QLabel("Поставщик SIGMA"), 0, 0)
        self.supplier_combo = NoWheelComboBox(); self.supplier_combo.setObjectName("WorkbenchCombo"); self.supplier_combo.setMinimumHeight(42)
        self.supplier_combo.currentIndexChanged.connect(lambda *_: self.schedule_free_receipt_autosave())
        top.addWidget(self.supplier_combo, 1, 0)
        top.addWidget(QLabel("Дата"), 0, 1)
        self.date_edit = QLineEdit(dt.date.today().strftime("%d.%m.%Y")); self.date_edit.setObjectName("WorkbenchInput"); self.date_edit.setMinimumHeight(42)
        self.date_edit.textChanged.connect(lambda *_: self.schedule_free_receipt_autosave())
        top.addWidget(self.date_edit, 1, 1)
        top.setColumnStretch(0, 2); top.setColumnStretch(1, 1)
        root.addWidget(top_card)

        form_card = QFrame(); form_card.setObjectName("FreeReceiptInnerCard")
        form = QGridLayout(form_card); form.setContentsMargins(22, 22, 22, 22); form.setHorizontalSpacing(14); form.setVerticalSpacing(12)
        section = QLabel("Товар"); section.setObjectName("WorkbenchSection"); form.addWidget(section, 0, 0, 1, 5)

        form.addWidget(QLabel("Название / ШК / поиск товара"), 1, 0, 1, 5)
        name_tools = QWidget(); name_tools.setObjectName("BarcodeTools")
        name_tools_layout = QHBoxLayout(name_tools); name_tools_layout.setContentsMargins(0, 0, 0, 0); name_tools_layout.setSpacing(10)
        self.name_edit = QLineEdit(); self.name_edit.setObjectName("WorkbenchInput"); self.name_edit.setPlaceholderText("Просканируйте ШК или введите наименование товара")
        self.name_edit.textChanged.connect(lambda *_: self.search_timer.start())
        self.name_edit.returnPressed.connect(self.accept_name_input)
        self.generate_barcode_btn = QPushButton("Товар без ШК ⇒ Создать ШК"); self.generate_barcode_btn.setObjectName("SoftButton"); self.generate_barcode_btn.setMinimumHeight(42); self.generate_barcode_btn.clicked.connect(self.generate_barcode)
        name_tools_layout.addWidget(self.name_edit, 1)
        name_tools_layout.addWidget(self.generate_barcode_btn, 0)
        form.addWidget(name_tools, 2, 0, 1, 5)

        self.search_popup = SuggestionPopup(body, self.select_search_row)

        self.barcode_list_widget = QWidget(); self.barcode_list_widget.setObjectName("BarcodeList")
        self.barcode_list_layout = QVBoxLayout(self.barcode_list_widget); self.barcode_list_layout.setContentsMargins(0, 0, 0, 0); self.barcode_list_layout.setSpacing(6)
        form.addWidget(self.barcode_list_widget, 5, 0, 1, 5)
        self.barcode_kind_label = QLabel(""); self.barcode_kind_label.setObjectName("StatsSubtitle"); self.barcode_kind_label.setVisible(False)
        form.addWidget(self.barcode_kind_label, 6, 0, 1, 5)

        form.addWidget(QLabel("Категория"), 7, 0, 1, 5)
        self.quick_chip_box = QWidget(); self.quick_chip_box.setObjectName("QuickCategoryBox")
        self.quick_grid = FlowLayout(self.quick_chip_box, margin=0, spacing=6)
        form.addWidget(self.quick_chip_box, 8, 0, 1, 5)

        self.category_box = QWidget(); self.category_box.setObjectName("CategoryBox")
        category_box_layout = QHBoxLayout(self.category_box); category_box_layout.setContentsMargins(0, 0, 0, 0); category_box_layout.setSpacing(10)
        self.category_input_shell = QFrame(); self.category_input_shell.setObjectName("CategoryInputShell")
        shell_layout = QHBoxLayout(self.category_input_shell); shell_layout.setContentsMargins(9, 5, 7, 5); shell_layout.setSpacing(7)
        self.category_chip = QFrame(); self.category_chip.setObjectName("CategoryInlineChip"); self.category_chip.setVisible(False)
        chip_layout = QHBoxLayout(self.category_chip); chip_layout.setContentsMargins(9, 3, 3, 3); chip_layout.setSpacing(5)
        self.category_chip_label = QLabel(""); self.category_chip_label.setObjectName("CategoryInlineChipLabel")
        self.category_chip_close = QPushButton("×"); self.category_chip_close.setObjectName("CategoryInlineChipClose"); self.category_chip_close.setFixedSize(18, 18)
        self.category_chip_close.clicked.connect(self.clear_category_selection)
        chip_layout.addWidget(self.category_chip_label, 0); chip_layout.addWidget(self.category_chip_close, 0)
        self.category_edit = QLineEdit(); self.category_edit.setObjectName("CategoryInlineEdit"); self.category_edit.setPlaceholderText("Начни вводить: 03, сад, сантехника...")
        self.category_edit.textEdited.connect(self.on_category_text_edited)
        self.category_edit.returnPressed.connect(self.pick_first_category_match)
        shell_layout.addWidget(self.category_chip, 0); shell_layout.addWidget(self.category_edit, 1)
        self.category_all_btn = QPushButton("Все категории"); self.category_all_btn.setObjectName("SoftButton"); self.category_all_btn.setMinimumHeight(42)
        self.category_all_btn.clicked.connect(self.show_all_categories)
        category_box_layout.addWidget(self.category_input_shell, 1); category_box_layout.addWidget(self.category_all_btn)
        form.addWidget(self.category_box, 9, 0, 1, 5)

        self.category_popup = SuggestionPopup(body, self.select_category_row)

        # v1.21.74: categories are no longer part of manual row entry.
        # They are assigned only when SAI creates missing products in SIGMA.
        # Keep widgets alive for compatibility with old drafts/search code, but
        # hide the whole block from the operator.
        self.category_title_label = form.itemAtPosition(7, 0).widget() if form.itemAtPosition(7, 0) else None
        for w in (self.category_title_label, self.quick_chip_box, self.category_box):
            try:
                if w is not None:
                    w.setVisible(False)
            except Exception:
                pass

        form.addWidget(QLabel("Ед."), 10, 0)
        self.unit_combo = NoWheelComboBox(); self.unit_combo.setObjectName("WorkbenchCombo"); self.unit_combo.addItems(self.units)
        form.addWidget(self.unit_combo, 11, 0)
        form.addWidget(QLabel("Количество"), 10, 1)
        self.qty_edit = QLineEdit(); self.qty_edit.setObjectName("WorkbenchInput"); self.qty_edit.setPlaceholderText("кол-во")
        form.addWidget(self.qty_edit, 11, 1)
        form.addWidget(QLabel("Закупочная цена"), 10, 2)
        self.sale_edit = QLineEdit(); self.sale_edit.setObjectName("WorkbenchInput"); self.sale_edit.setPlaceholderText("закупка")
        self.sale_edit.textEdited.connect(lambda *_: self.on_price_field_edited("buy"))
        self.sale_edit.editingFinished.connect(lambda: self.resolve_price_equation("buy"))
        form.addWidget(self.sale_edit, 11, 2)

        form.addWidget(QLabel("Наценка %"), 10, 3)
        self.markup_edit = QLineEdit(); self.markup_edit.setObjectName("WorkbenchInput"); self.markup_edit.setMinimumHeight(42); self.markup_edit.setPlaceholderText("60"); self.markup_edit.setText(str(_free_default_markup_choice()))
        self.markup_edit.setToolTip("Заполните любые два поля из трёх: закупка, наценка, продажная цена.")
        self.markup_edit.textEdited.connect(lambda *_: self.on_price_field_edited("markup"))
        self.markup_edit.editingFinished.connect(lambda: self.resolve_price_equation("markup"))
        form.addWidget(self.markup_edit, 11, 3)

        form.addWidget(QLabel("Продажная цена"), 10, 4)
        self.retail_price_edit = QLineEdit(); self.retail_price_edit.setObjectName("WorkbenchInput"); self.retail_price_edit.setMinimumHeight(42); self.retail_price_edit.setPlaceholderText("цена продажи")
        self.retail_price_edit.setToolTip("Недостающее значение рассчитается только после завершения ввода.")
        self.retail_price_edit.textEdited.connect(lambda *_: self.on_price_field_edited("retail"))
        self.retail_price_edit.editingFinished.connect(lambda: self.resolve_price_equation("retail"))
        form.addWidget(self.retail_price_edit, 11, 4)

        print_tools = QWidget(); print_tools.setObjectName("FreePrintTools")
        print_tools_layout = QHBoxLayout(print_tools); print_tools_layout.setContentsMargins(0, 0, 0, 0); print_tools_layout.setSpacing(10)
        self.print_label_check = QCheckBox("Печатать ценники")
        self.print_label_check.setObjectName("FreePrintLabelCheck")
        self.print_label_check.setToolTip("Если включено, после добавления товара SAI сразу отправит на Xprinter количество этикеток по количеству товара. После добавления галочка сбрасывается.")
        self.print_label_check.setChecked(False)
        self.print_label_check.toggled.connect(self.sync_free_label_qty_enabled)
        self.free_label_qty_minus = QPushButton("−"); self.free_label_qty_minus.setObjectName("SoftButton"); self.free_label_qty_minus.setFixedSize(38, 38)
        self.free_label_qty_minus.clicked.connect(lambda: self.adjust_free_label_qty(-1))
        self.free_label_qty_edit = QLineEdit(); self.free_label_qty_edit.setObjectName("WorkbenchInput"); self.free_label_qty_edit.setFixedWidth(74); self.free_label_qty_edit.setMinimumHeight(38)
        self.free_label_qty_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.free_label_qty_edit.editingFinished.connect(self.apply_free_label_qty)
        self.free_label_qty_plus = QPushButton("+"); self.free_label_qty_plus.setObjectName("SoftButton"); self.free_label_qty_plus.setFixedSize(38, 38)
        self.free_label_qty_plus.clicked.connect(lambda: self.adjust_free_label_qty(1))
        print_tools_layout.addWidget(self.print_label_check, 0)
        print_tools_layout.addWidget(self.free_label_qty_minus, 0)
        print_tools_layout.addWidget(self.free_label_qty_edit, 0)
        print_tools_layout.addWidget(self.free_label_qty_plus, 0)
        print_tools_layout.addStretch(1)
        form.addWidget(print_tools, 12, 0, 1, 5)
        self.qty_edit.textChanged.connect(self.sync_free_label_qty_from_quantity)
        self.sync_free_label_qty_enabled(False)

        for column in range(5):
            form.setColumnStretch(column, 1)

        form_wrap = QFrame(); form_wrap.setObjectName("FreeReceiptCardShell")
        form_wrap_layout = QHBoxLayout(form_wrap); form_wrap_layout.setContentsMargins(0, 0, 0, 0); form_wrap_layout.setSpacing(0)
        self.clear_hold_timer = QTimer(self); self.clear_hold_timer.setSingleShot(True); self.clear_hold_timer.setInterval(5000); self.clear_hold_timer.timeout.connect(self.clear_current_by_hold)
        self.clear_side_button = QPushButton("−"); self.clear_side_button.setObjectName("FreeClearSideButton"); self.clear_side_button.setToolTip("Удерживай 5 секунд, чтобы очистить карточку")
        self.clear_side_button.setFixedWidth(30); self.clear_side_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.clear_side_button.pressed.connect(self.start_clear_hold)
        self.clear_side_button.released.connect(self.cancel_clear_hold)
        self.clear_side_button.leaveEvent = lambda event, _orig=self.clear_side_button.leaveEvent: (self.cancel_clear_hold(), _orig(event))[1]
        add_side = QPushButton("+"); add_side.setObjectName("FreeAddSideButton"); add_side.setToolTip("Добавить товар")
        add_side.setFixedWidth(30); add_side.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding); add_side.clicked.connect(self.add_current_row)
        form_wrap_layout.addWidget(self.clear_side_button)
        form_wrap_layout.addWidget(form_card, 1)
        form_wrap_layout.addWidget(add_side)
        root.addWidget(form_wrap)

        table_card = QFrame(); table_card.setObjectName("WorkbenchCard")
        tv = QVBoxLayout(table_card); tv.setContentsMargins(22, 18, 22, 18); tv.setSpacing(10)
        table_title = QHBoxLayout()
        self.rows_label = QLabel("Добавленные товары: 0"); self.rows_label.setObjectName("WorkbenchSection")
        self.save_now_btn = QPushButton("Сохранить"); self.save_now_btn.setObjectName("SoftButton"); self.save_now_btn.clicked.connect(self.save_free_receipt_draft_manual)
        self.finish_btn = QPushButton("Сохранить как черновик"); self.finish_btn.setObjectName("SoftButton"); self.finish_btn.clicked.connect(self.finish_free_receipt)
        self.finish_btn.setToolTip("Перенести ручную накладную в общие черновики SAI.")
        self.enter_receipt_btn = QPushButton("Ввести приход"); self.enter_receipt_btn.setObjectName("WorkbenchPrimaryButton"); self.enter_receipt_btn.clicked.connect(self.enter_free_receipt)
        self.enter_receipt_btn.setToolTip("Сохранить накладную и сразу продолжить подходящий сценарий привоза.")
        for button in (self.save_now_btn, self.finish_btn, self.enter_receipt_btn):
            button.setMinimumHeight(40)
        table_title.addWidget(self.rows_label, 1)
        table_title.addWidget(self.save_now_btn, 0)
        table_title.addWidget(self.finish_btn, 0)
        table_title.addWidget(self.enter_receipt_btn, 0)
        tv.addLayout(table_title)
        self.rows_table = RoundedTableWidget(0, 8); self.rows_table.setObjectName("ReceiptTable")
        self.rows_table.setHorizontalHeaderLabels(["№", "Товар", "ШК", "Ед.", "Кол-во", "Цена", "", ""])
        self.rows_table.verticalHeader().setVisible(False)
        self.rows_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.rows_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.rows_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.rows_table.cellDoubleClicked.connect(lambda row, _column: self.edit_manual_row(row))
        header = self.rows_table.horizontalHeader()
        header.setDefaultAlignment(Qt.AlignmentFlag.AlignCenter)
        header.setSectionResizeMode(0, QHeaderView.Fixed); self.rows_table.setColumnWidth(0, 44)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.Fixed); self.rows_table.setColumnWidth(3, 52)
        header.setSectionResizeMode(4, QHeaderView.Fixed); self.rows_table.setColumnWidth(4, 74)
        header.setSectionResizeMode(5, QHeaderView.Fixed); self.rows_table.setColumnWidth(5, 78)
        for column in (6, 7):
            header.setSectionResizeMode(column, QHeaderView.Fixed); self.rows_table.setColumnWidth(column, 42)
        tv.addWidget(self.rows_table, 1)
        root.addWidget(table_card)

    def accept_name_input(self) -> None:
        """Enter in the combined field confirms either a barcode or a typed name."""
        if getattr(self, "search_timer", None) is not None:
            self.search_timer.stop()
        if getattr(self, "search_popup", None) is not None:
            self.search_popup.hide()
        text = self.name_edit.text().strip() if getattr(self, "name_edit", None) is not None else ""
        if not text:
            return
        if self.is_barcode_like_query(text):
            digits = re.sub(r"\D+", "", text)
            if self.current_product:
                product_name = safe_str(self.current_product.get("name"))
                self.add_scanned_barcode_to_current(digits)
                self.name_edit.blockSignals(True)
                self.name_edit.setText(product_name)
                self.name_edit.selectAll()
                self.name_edit.blockSignals(False)
                self.schedule_free_receipt_autosave()
                return
            exact = self.find_product_by_exact_barcode(digits)
            unique_ids = {safe_str(r.get("id")) for r in exact}
            if len(exact) == 1 and len(unique_ids) == 1:
                self.add_scanned_barcode_to_current(digits)
                self.apply_product_result(exact[0], focus_qty=True)
                return
            # Unknown or ambiguous barcode: keep it on the card, let the user type a name.
            self.add_scanned_barcode_to_current(digits)
            self.name_edit.blockSignals(True)
            self.name_edit.clear()
            self.name_edit.setPlaceholderText("ШК добавлен. Теперь введи наименование товара")
            self.name_edit.blockSignals(False)
            self.name_edit.setFocus()
            self.schedule_free_receipt_autosave()
            return
        # Manual name confirmation.
        name = text.upper()
        self.name_edit.blockSignals(True)
        self.name_edit.setText(name)
        self.name_edit.selectAll()
        self.name_edit.blockSignals(False)
        if not self.current_product:
            self.current_product = {"name": name, "id": ""}
        self.schedule_free_receipt_autosave()
        self.qty_edit.setFocus()

    def current_card_has_data(self) -> bool:
        return manual_card_has_data(self.current_card_payload())

    def start_clear_hold(self) -> None:
        """Start hold-to-clear confirmation for the left red side button."""
        if not self.current_card_has_data():
            self.clear_current()
            return
        if getattr(self, "clear_side_button", None) is not None:
            self.clear_side_button.setText("5")
            self.clear_side_button.setToolTip("Не отпускай: очистка через 5 секунд")
        if getattr(self, "clear_hold_timer", None) is not None:
            self.clear_hold_timer.start()

    def cancel_clear_hold(self) -> None:
        if getattr(self, "clear_hold_timer", None) is not None and self.clear_hold_timer.isActive():
            self.clear_hold_timer.stop()
        if getattr(self, "clear_side_button", None) is not None:
            self.clear_side_button.setText("−")
            self.clear_side_button.setToolTip("Удерживай 5 секунд, чтобы очистить карточку")

    def clear_current_by_hold(self) -> None:
        if getattr(self, "clear_side_button", None) is not None:
            self.clear_side_button.setText("−")
            self.clear_side_button.setToolTip("Удерживай 5 секунд, чтобы очистить карточку")
        self.clear_current()

    def refresh_reference_data(self) -> None:
        self.refresh_suppliers_from_workbench()
        self.load_categories_units()
        self.filter_categories()
        self._references_loaded = True

    def refresh_suppliers_from_workbench(self, preserve_current: bool = False) -> None:
        current_id = ""
        current_name = ""
        if preserve_current and getattr(self, "supplier_combo", None) is not None:
            data = self.supplier_combo.currentData()
            if isinstance(data, dict):
                current_id = str(data.get("id") or "").strip()
                current_name = str(data.get("name") or "").strip().lower()
            else:
                current_name = str(self.supplier_combo.currentText() or "").strip().lower()

        self.supplier_combo.clear()
        suppliers = []
        workbench = getattr(self.parent_page, "workbench_page", None)
        if workbench is not None:
            suppliers = list(getattr(workbench, "supplier_list", []) or [])
            if not suppliers:
                try:
                    suppliers = list(workbench.load_supplier_cache() or [])
                except Exception:
                    suppliers = []
        if not suppliers:
            self.supplier_combo.addItem("Поставщики не загружены — обновите вручную", "")
            return
        for s in sorted(suppliers, key=lambda x: str(x.get("name") or "").lower()):
            name = str(s.get("name") or "").strip()
            inn = str(s.get("inn") or s.get("taxpayerIdentificationNumber") or "").strip()
            label = f"{name} · ИНН {inn}" if inn else name
            self.supplier_combo.addItem(label, {"id": str(s.get("id") or ""), "name": name, "inn": inn})

        wanted = str(load_private_config().get("free_receipt_default_supplier") or "СВОБОД").lower()
        target_index = 0
        for i in range(self.supplier_combo.count()):
            data = self.supplier_combo.itemData(i)
            if not isinstance(data, dict):
                continue
            name = str(data.get("name") or "").strip().lower()
            sid = str(data.get("id") or "").strip()
            if current_id and sid == current_id:
                target_index = i; break
            if current_name and name == current_name:
                target_index = i; break
            if not current_id and not current_name and wanted and wanted in name:
                target_index = i
                break
        if self.supplier_combo.count():
            self.supplier_combo.setCurrentIndex(target_index)

    def load_categories_units(self) -> None:
        cfg = load_private_config()
        company = safe_str(cfg.get("sigma_company_key")); token = safe_str(cfg.get("sigma_api_token")); sp = safe_str(cfg.get("sigma_sell_point_id"))
        if not company or not token:
            return
        try:
            import requests
            base = f"https://api.sigma.ru/v1/companies/{company}"
            headers = {"Accept": "application/json", "X-Api-Key": token, "User-Agent": "SAI-Hub/1.21.13"}
            params = {"sellPointId": sp} if sp else None
            r = requests.get(base + "/product-categories", headers=headers, params=params, timeout=15)
            if 200 <= r.status_code < 300:
                cats = []
                for item in _collect_api_items(r.json()):
                    name = safe_str(item.get("name") or item.get("title") or item.get("displayName"))
                    cid = safe_str(item.get("id") or item.get("uuid"))
                    if name:
                        cats.append({"id": cid, "name": name})
                if cats:
                    seen = set(); self.categories = []
                    for c in sorted(cats, key=lambda x: _free_norm(x.get("name"))):
                        key = c.get("name")
                        if key not in seen:
                            seen.add(key); self.categories.append(c)
            ru = requests.get(base + "/units", headers=headers, timeout=15)
            if 200 <= ru.status_code < 300:
                units = []
                for item in _collect_api_items(ru.json()):
                    name = safe_str(item.get("name") or item.get("shortName") or item.get("title"))
                    if name:
                        units.append(_free_normalize_unit(name))
                if units:
                    ordered = []
                    for u in ["штука", "м", "кг", "г", "пара"] + units:
                        if u and u not in ordered:
                            ordered.append(u)
                    self.units = ordered
                    self.unit_combo.clear(); self.unit_combo.addItems(self.units)
        except Exception:
            pass

    def category_usage_counts(self) -> Dict[str, int]:
        return self.free_catalog_service.category_usage_counts(self.rows)

    def rebuild_quick_categories(self) -> None:
        """Compatibility no-op: quick categories were removed from SAI."""
        self.quick_category_buttons = []

    def on_category_text_edited(self, _text: str = "") -> None:
        if self.selected_category:
            self.selected_category = {}
            self.update_category_chip()
        self.filter_categories()

    def filter_categories(self) -> None:
        q_text = self.category_edit.text()
        q = _free_norm(q_text)
        if not q:
            self.category_search_results = []
            self.category_popup.hide()
            return
        toks = q.split()
        matches = [c for c in self.categories if all(t in _free_norm(c.get("name")) for t in toks)]
        self.category_search_results = matches[:120]
        if matches:
            self.category_popup.show_rows(self.category_search_results, self.category_box, q_text, kind="category", max_rows=80)
        else:
            self.category_popup.hide()

    def show_all_categories(self) -> None:
        if not self.categories:
            try:
                self.load_categories_units()
            except Exception:
                pass
        if not self.categories:
            self.parent_page.notify("Категории", "Справочник категорий ещё загружается.", "info")
            return
        self.category_search_results = list(self.categories)
        self.category_popup.show_rows(self.category_search_results, self.category_box, "", kind="category", max_rows=None)

    def pick_first_category_match(self) -> None:
        if self.category_search_results:
            self.set_category(self.category_search_results[0], update_text=True)
            self.category_popup.hide()

    def select_category_row(self, row: int, col: int = 0) -> None:
        if 0 <= row < len(getattr(self, "category_search_results", [])):
            self.set_category(self.category_search_results[row], update_text=True)
            self.category_popup.hide()

    def set_category(self, cat: Dict[str, str], update_text: bool = True) -> None:
        self.selected_category = dict(cat or {})
        if update_text:
            self.category_edit.blockSignals(True)
            self.category_edit.clear()
            self.category_edit.setPlaceholderText("")
            self.category_edit.blockSignals(False)
        self.update_category_chip()
        self.schedule_free_receipt_autosave()

    def clear_category_selection(self) -> None:
        self.selected_category = {}
        self.category_edit.blockSignals(True)
        self.category_edit.clear()
        self.category_edit.setPlaceholderText("Начни вводить: 03, сад, сантехника...")
        self.category_edit.blockSignals(False)
        self.category_popup.hide()
        self.update_category_chip()
        self.schedule_free_receipt_autosave()
        self.category_edit.setFocus()

    def update_category_chip(self) -> None:
        selected_name = self.selected_category.get("name", "")
        if getattr(self, "category_chip", None) is not None:
            self.category_chip_label.setText(short_text(selected_name, 34))
            self.category_chip.setVisible(bool(selected_name))
        if getattr(self, "category_edit", None) is not None:
            self.category_edit.setPlaceholderText("" if selected_name else "Начни вводить: 03, сад, сантехника...")
        for btn in self.quick_category_buttons:
            btn.setChecked(bool(selected_name and btn.property("category_name") == selected_name))


    def is_barcode_like_query(self, text: str) -> bool:
        return free_is_barcode_like_query(text)

    def resolve_category_from_product_raw(self, raw: Any, fallback: str = "") -> str:
        return self.free_catalog_service.resolve_category(raw, self.categories, fallback)

    def find_product_by_exact_barcode(self, code: str) -> List[Dict[str, Any]]:
        return self.free_catalog_service.find_exact_barcode(
            code,
            self.categories,
            non_blocking=True,
        )

    def add_scanned_barcode_to_current(self, code: str) -> bool:
        merged = free_merge_barcodes(self.current_barcodes, [code], limit=1000)
        changed = list(merged.barcodes) != list(self.current_barcodes)
        self.current_barcodes = list(merged.barcodes)
        if merged.added:
            self.active_barcode_index = len(self.current_barcodes) - 1
        if changed:
            self.render_barcodes()
        return bool(self.current_barcodes)

    def run_product_search(self) -> None:
        name_query = self.name_edit.text().strip()
        barcode_query = name_query if self.is_barcode_like_query(name_query) else ""
        use_barcode = bool(barcode_query)
        rows = self.free_catalog_service.search(
            name_query=name_query,
            barcode_query=barcode_query,
            barcode_mode=use_barcode,
            categories=self.categories,
            selected_category=safe_str(self.selected_category.get("name")),
            limit=10,
            non_blocking=True,
        )
        if not self.free_catalog_service.catalog_ready:
            self.search_timer.start(60)
            return
        self.search_timer.setInterval(160)
        digit_query = re.sub(r"\D+", "", barcode_query)
        if use_barcode and digit_query:
            # Once a card is chosen, every following scanned code belongs to
            # that same card until the operator adds or clears it.
            if self.current_product:
                self.populate_search(rows)
                return
            exact = [row for row in rows if row.get("exact_barcode_match")]
            unique_ids = {safe_str(row.get("id")) for row in exact}
            if len(exact) == 1 and len(unique_ids) == 1:
                if self._auto_barcode_applied != digit_query:
                    self._auto_barcode_applied = digit_query
                    self.add_scanned_barcode_to_current(digit_query)
                    self.apply_product_result(exact[0], focus_qty=True)
                return
            if len(exact) != 1:
                self._auto_barcode_applied = ""
        self.populate_search(rows)

    def extract_product_price(self, con: sqlite3.Connection, product_id: str, raw: Any) -> float:
        return self.free_catalog_service.extract_product_price(con, product_id, raw)

    def populate_search(self, rows: List[Dict[str, Any]]) -> None:
        self.search_results = rows
        query = self.name_edit.text().strip()
        self.search_popup.show_rows(rows, self.name_edit, query, kind="product")

    def select_search_row(self, row: int, col: int = 0) -> None:
        if row < 0 or row >= len(getattr(self, "search_results", [])):
            return
        self.apply_product_result(self.search_results[row], focus_qty=True)

    def apply_product_result(self, r: Dict[str, Any], focus_qty: bool = False) -> None:
        self.current_product = r
        scanned = re.sub(r"\D+", "", self.name_edit.text().strip()) if self.is_barcode_like_query(self.name_edit.text().strip()) else ""
        self.name_edit.blockSignals(True); self.name_edit.setText(r.get("name", "")); self.name_edit.blockSignals(False)
        merged_barcodes: List[str] = []
        for bc in list(self.current_barcodes or []) + ([scanned] if scanned else []) + [safe_str(x) for x in (r.get("barcodes") or []) if safe_str(x)]:
            bc = safe_str(bc)
            if bc and bc not in merged_barcodes:
                merged_barcodes.append(bc)
        self.current_barcodes = merged_barcodes
        self.render_barcodes()
        if r.get("category"):
            category_name = safe_str(r.get("category"))
            match = next((c for c in self.categories if _free_norm(c.get("name")) == _free_norm(category_name)), None)
            if match is None:
                match = next((c for c in self.categories if category_name and (_free_norm(category_name) in _free_norm(c.get("name")) or _free_norm(c.get("name")) in _free_norm(category_name))), None)
            self.set_category(match or {"name": category_name, "id": ""})
        self.set_unit(r.get("unit") or "штука")
        price = _free_money_float(r.get("price") or 0)
        self.current_old_sale_price = price
        self.sale_edit.blockSignals(True)
        self.sale_edit.clear()
        self.sale_edit.setPlaceholderText("закупка")
        self.sale_edit.blockSignals(False)
        self.retail_price_edit.blockSignals(True)
        self.retail_price_edit.setText(_free_price_text(price) if price else "")
        self.retail_price_edit.blockSignals(False)
        if price:
            # The catalog price is factual. Leave markup empty so entering the
            # new purchase price calculates the real markup instead of silently
            # preserving the default 60%.
            self.markup_edit.blockSignals(True)
            self.markup_edit.clear()
            self.markup_edit.blockSignals(False)
        self.search_timer.stop()
        self.search_popup.hide()
        self.name_edit.selectAll()
        if focus_qty:
            self.qty_edit.setFocus()

    def set_unit(self, unit: str) -> None:
        unit = free_normalize_unit(unit)
        idx = self.unit_combo.findText(unit)
        if idx < 0:
            self.unit_combo.addItem(unit); idx = self.unit_combo.findText(unit)
        self.unit_combo.setCurrentIndex(max(0, idx))

    def default_free_label_qty(self) -> int:
        return max(1, int(round(_free_money_float(self.qty_edit.text().strip()) or 1)))

    def sync_free_label_qty_enabled(self, checked: bool) -> None:
        enabled = bool(checked)
        for widget in (
            getattr(self, "free_label_qty_minus", None),
            getattr(self, "free_label_qty_edit", None),
            getattr(self, "free_label_qty_plus", None),
        ):
            if widget is not None:
                widget.setEnabled(enabled)
        if enabled and getattr(self, "free_label_qty_edit", None) is not None:
            if not self._free_label_qty_manual or not self.free_label_qty_edit.text().strip():
                self.free_label_qty_edit.setText(str(self.default_free_label_qty()))

    def sync_free_label_qty_from_quantity(self, *_args: Any) -> None:
        if (
            getattr(self, "print_label_check", None) is not None
            and self.print_label_check.isChecked()
            and not self._free_label_qty_manual
            and getattr(self, "free_label_qty_edit", None) is not None
        ):
            self.free_label_qty_edit.setText(str(self.default_free_label_qty()))

    def apply_free_label_qty(self) -> None:
        edit = getattr(self, "free_label_qty_edit", None)
        if edit is None or not edit.isEnabled():
            return
        try:
            value = max(1, int(round(float(edit.text().replace(",", ".")))))
        except Exception:
            value = self.default_free_label_qty()
        self._free_label_qty_manual = True
        edit.setText(str(value))

    def adjust_free_label_qty(self, delta: int) -> None:
        edit = getattr(self, "free_label_qty_edit", None)
        if edit is None or not edit.isEnabled():
            return
        try:
            current = max(1, int(edit.text() or self.default_free_label_qty()))
        except Exception:
            current = self.default_free_label_qty()
        self._free_label_qty_manual = True
        edit.setText(str(max(1, current + int(delta))))

    def generate_barcode(self) -> None:
        if self.current_barcodes:
            QMessageBox.information(self, "Ручная накладная", "У товара уже есть ШК. Создавать внутренний ШК не требуется.")
            return
        try:
            generated = self.free_catalog_service.generate_internal_barcode(self.current_barcodes, self.rows)
            self.current_barcodes.append(generated.code)
            self.active_barcode_index = len(self.current_barcodes) - 1
            self.render_barcodes()
        except Exception as exc:
            QMessageBox.warning(self, "Ручная накладная", f"Не удалось подобрать свободный внутренний ШК.\n\n{exc}")

    def set_active_barcode(self, idx: int) -> None:
        if 0 <= idx < len(self.current_barcodes):
            self.active_barcode_index = idx
            self.render_barcodes()

    def remove_barcode(self, idx: int) -> None:
        if 0 <= idx < len(self.current_barcodes):
            self.current_barcodes.pop(idx)
            self.active_barcode_index = min(self.active_barcode_index, max(0, len(self.current_barcodes) - 1))
            self.render_barcodes()

    def edit_barcode(self, idx: int, text: str) -> None:
        if not (0 <= idx < len(self.current_barcodes)):
            return
        bc = safe_str(text)
        if not bc:
            self.remove_barcode(idx)
            return
        duplicate = any(i != idx and safe_str(v) == bc for i, v in enumerate(self.current_barcodes))
        if duplicate:
            QMessageBox.information(self, "Ручная накладная", "Такой штрихкод уже добавлен к этой позиции.")
            self.render_barcodes()
            return
        self.current_barcodes[idx] = bc
        self.active_barcode_index = idx
        self.update_barcode_preview()

    def preview_barcode_edit(self, idx: int, text: str) -> None:
        if 0 <= idx < len(self.current_barcodes):
            self.active_barcode_index = idx
            code = safe_str(text)
            self.barcode_kind_label.setText(("Тип активного ШК: " + barcode_kind(code)) if code else "")
            self.barcode_kind_label.setVisible(bool(code))

    def render_barcodes(self) -> None:
        while self.barcode_list_layout.count():
            item = self.barcode_list_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        for idx, bc in enumerate(self.current_barcodes):
            row = QHBoxLayout(); row.setSpacing(6)
            edit = QLineEdit(bc); edit.setObjectName("BarcodeEdit")
            edit.setPlaceholderText("ШК")
            edit.setMinimumHeight(36)
            edit.setProperty("active", "true" if idx == self.active_barcode_index else "false")
            edit.textEdited.connect(lambda text, i=idx: self.preview_barcode_edit(i, text))
            edit.editingFinished.connect(lambda i=idx, e=edit: self.edit_barcode(i, e.text()))
            rm = QPushButton("×"); rm.setObjectName("TinyDangerButton"); rm.setFixedWidth(32); rm.clicked.connect(lambda _=False, i=idx: self.remove_barcode(i))
            row.addWidget(edit, 1); row.addWidget(rm)
            wrap = QWidget(); wrap.setObjectName("BarcodeRow"); wrap.setLayout(row)
            self.barcode_list_layout.addWidget(wrap)
        self.update_barcode_preview()

    def update_barcode_preview(self) -> None:
        code = ""
        if self.current_barcodes:
            self.active_barcode_index = max(0, min(self.active_barcode_index, len(self.current_barcodes) - 1))
            code = safe_str(self.current_barcodes[self.active_barcode_index])
        if not code:
            self.barcode_kind_label.clear()
            self.barcode_kind_label.setVisible(False)
            return
        self.barcode_kind_label.setVisible(True)
        self.barcode_kind_label.setText("Тип активного ШК: " + barcode_kind(code))

    def current_markup_percent(self) -> float:
        raw = self.markup_edit.text().strip() if getattr(self, "markup_edit", None) is not None else ""
        return free_normalize_markup(raw, 0)

    @staticmethod
    def _equation_value(edit: QLineEdit, *, allow_zero: bool = False) -> Optional[float]:
        raw = edit.text().strip().replace(" ", "").replace(",", ".")
        if not raw:
            return None
        try:
            value = float(raw)
        except ValueError:
            return None
        if not math.isfinite(value) or value < 0 or (not allow_zero and value == 0):
            return None
        return value

    @staticmethod
    def _set_equation_value(edit: QLineEdit, value: float, *, percent: bool = False) -> None:
        text = f"{value:.2f}".rstrip("0").rstrip(".").replace(".", ",")
        if not text:
            text = "0"
        edit.blockSignals(True)
        edit.setText(text)
        edit.blockSignals(False)

    def on_price_field_edited(self, field: str) -> None:
        self._price_last_edited = field
        self.schedule_free_receipt_autosave()

    def resolve_price_equation(self, trigger: str = "") -> None:
        """Resolve the three price fields after input is finished.

        Text changes never trigger calculation. This lets the operator erase or
        replace a number normally; calculation happens only on Enter/focus loss.
        A manually changed retail price is authoritative: when purchase price is
        known, overwrite the previous markup with the actual resulting percent.
        """
        buy = self._equation_value(self.sale_edit)
        markup = self._equation_value(self.markup_edit, allow_zero=True)
        retail = self._equation_value(self.retail_price_edit)
        if trigger == "retail" and buy and retail is not None:
            self._set_equation_value(
                self.markup_edit,
                max(0.0, (retail / buy - 1.0) * 100.0),
                percent=True,
            )
            self.schedule_free_receipt_autosave()
            return
        if trigger == "markup" and buy is not None and markup is not None:
            self._set_equation_value(
                self.retail_price_edit,
                _free_round_sale_from_purchase(buy, markup),
            )
            self.schedule_free_receipt_autosave()
            return
        missing = [
            name for name, value in (
                ("buy", buy), ("markup", markup), ("retail", retail),
            ) if value is None
        ]
        if len(missing) != 1:
            self.schedule_free_receipt_autosave()
            return
        target = missing[0]
        # Clearing a field is an explicit operator decision. Never put the
        # value back merely because focus left that same empty field.
        if trigger and target == trigger:
            self.schedule_free_receipt_autosave()
            return
        if target == "retail" and buy is not None and markup is not None:
            self._set_equation_value(
                self.retail_price_edit,
                _free_round_sale_from_purchase(buy, markup),
            )
        elif target == "markup" and buy and retail is not None:
            self._set_equation_value(
                self.markup_edit,
                max(0.0, (retail / buy - 1.0) * 100.0),
                percent=True,
            )
        elif target == "buy" and retail is not None and markup is not None:
            divisor = 1.0 + markup / 100.0
            if divisor > 0:
                self._set_equation_value(self.sale_edit, round(retail / divisor, 2))
        self.schedule_free_receipt_autosave()

    def purchase_value(self) -> float:
        return _free_money_float(self.sale_edit.text().strip())

    def sale_value(self) -> float:
        return _free_money_float(self.retail_price_edit.text().strip())

    def schedule_free_receipt_autosave(self) -> None:
        self.update_free_receipt_finish_button()
        if getattr(self, "_suspend_manual_autosave", False):
            return
        if getattr(self, "autosave_timer", None) is not None:
            self.autosave_timer.start()

    def free_receipt_draft_path(self) -> Path:
        return self.manual_service.autosave_path

    def current_card_payload(self) -> Dict[str, Any]:
        try:
            return {
                "name": self.name_edit.text().strip() if getattr(self, "name_edit", None) is not None else "",
                "barcode_input": "",
                "barcodes": list(self.current_barcodes or []),
                "category": dict(self.selected_category or {}),
                "unit": self.unit_combo.currentText().strip() if getattr(self, "unit_combo", None) is not None else "",
                "qty": self.qty_edit.text().strip() if getattr(self, "qty_edit", None) is not None else "",
                "purchase_price": self.sale_edit.text().strip() if getattr(self, "sale_edit", None) is not None else "",
                "sale_price": self.retail_price_edit.text().strip() if getattr(self, "retail_price_edit", None) is not None else "",
                "old_sale_price": float(getattr(self, "current_old_sale_price", 0.0) or 0.0),
                "product": dict(self.current_product or {}),
                "markup": self.markup_edit.text().strip() if getattr(self, "markup_edit", None) is not None else None,
                "print_labels": bool(getattr(self, "print_label_check", None) and self.print_label_check.isChecked()),
                "label_copies": self.free_label_qty_edit.text().strip() if getattr(self, "free_label_qty_edit", None) is not None else "",
                "label_copies_manual": bool(getattr(self, "_free_label_qty_manual", False)),
            }
        except Exception:
            return {}


    def save_free_receipt_draft(self) -> None:
        if getattr(self, "_suspend_manual_autosave", False) or self.manual_service.is_deleted():
            return
        try:
            data = self.supplier_combo.currentData() if getattr(self, "supplier_combo", None) is not None else None
            supplier_id, supplier_name = supplier_fields(
                data,
                self.supplier_combo.currentText() if getattr(self, "supplier_combo", None) is not None else "",
            )
            payload = {
                "saved_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "supplier_id": supplier_id,
                "supplier_name": supplier_name,
                "date": self.date_edit.text().strip() if getattr(self, "date_edit", None) is not None else "",
                "rows": list(self.rows or []),
                "current_card": self.current_card_payload(),
            }
            self.manual_service.save_autosave(payload)
        except Exception:
            pass

    def save_free_receipt_draft_manual(self) -> None:
        self.save_free_receipt_draft()
        self.parent_page.notify(
            "Ручная накладная",
            "Всё сохранено. Можно спокойно закрыть SAI и продолжить позже.",
            "success",
        )

    def load_free_receipt_draft(self) -> None:
        if self.manual_service.is_deleted():
            self._draft_loaded = True
            return
        try:
            payload = self.manual_service.load_autosave()
            if not payload:
                return
            rows = payload.get("rows") or []
            if isinstance(rows, list) and rows:
                self.rows = rows
                self.populate_rows()
            saved_date = safe_str(payload.get("date"))
            if saved_date:
                self.date_edit.setText(saved_date)
            card = payload.get("current_card") or {}
            if isinstance(card, dict) and any(card.values()):
                self.name_edit.setText(safe_str(card.get("name")))
                self.current_barcodes = [str(x).strip() for x in (card.get("barcodes") or []) if str(x).strip()]
                cat = card.get("category") or {}
                if isinstance(cat, dict):
                    self.selected_category = dict(cat)
                    self.update_category_chip()
                self.set_unit(safe_str(card.get("unit")) or "штука")
                self.qty_edit.setText(safe_str(card.get("qty")))
                self.sale_edit.setText(safe_str(card.get("purchase_price")))
                saved_sale = safe_str(card.get("sale_price"))
                try:
                    self.current_old_sale_price = float(card.get("old_sale_price") or 0.0)
                    if not saved_sale and self.current_old_sale_price:
                        saved_sale = _free_price_text(self.current_old_sale_price)
                except Exception:
                    pass
                self.retail_price_edit.setText(saved_sale)
                prod = card.get("product") or {}
                if isinstance(prod, dict):
                    self.current_product = dict(prod)
                markup = card.get("markup")
                if getattr(self, "markup_edit", None) is not None and markup is not None:
                    try:
                        value = max(0.0, _free_money_float(markup))
                        self.markup_edit.setText(_free_price_text(value).replace(".00", ""))
                    except Exception:
                        pass
                self._free_label_qty_manual = bool(card.get("label_copies_manual"))
                if getattr(self, "free_label_qty_edit", None) is not None:
                    self.free_label_qty_edit.setText(safe_str(card.get("label_copies")) or str(self.default_free_label_qty()))
                if getattr(self, "print_label_check", None) is not None:
                    self.print_label_check.setChecked(bool(card.get("print_labels")))
                self.render_barcodes()
        except Exception:
            pass
        self.update_free_receipt_finish_button()
        self._draft_loaded = True

    def clear_free_receipt_draft(self) -> None:
        try:
            self.manual_service.clear_autosave()
        except Exception:
            pass

    def discard_deleted_manual_draft(self) -> None:
        """Clear stale in-memory fields so a deleted draft cannot autosave itself again."""
        self._suspend_manual_autosave = True
        try:
            if getattr(self, "autosave_timer", None) is not None:
                self.autosave_timer.stop()
            self.rows = []
            self.populate_rows()
            self.clear_current()
            self.free_receipt_saved_xml_path = None
            self.free_receipt_saved_signature = ""
        finally:
            self._suspend_manual_autosave = False

    def begin_new_manual_receipt(self) -> None:
        """Explicit user action starts a new manual draft after a previous deletion."""
        if self.manual_service.is_deleted():
            self.discard_deleted_manual_draft()
            self.manual_service.restore()

    def has_unpromoted_manual_receipt(self) -> bool:
        return bool(self.rows or self.current_card_has_data())

    def add_current_row(self) -> bool:
        self.resolve_price_equation()
        print_labels = bool(getattr(self, "print_label_check", None) and self.print_label_check.isChecked())
        print_copies = (
            max(1, int(self.free_label_qty_edit.text() or self.default_free_label_qty()))
            if print_labels and getattr(self, "free_label_qty_edit", None) is not None
            else 0
        )
        new_row = ManualReceiptRow.from_values(
            name=self.name_edit.text(),
            barcodes=self.current_barcodes,
            category="",
            unit=self.unit_combo.currentText().strip() or "штука",
            qty=self.qty_edit.text(),
            sale=self.sale_value(),
            buy=self.purchase_value(),
            product_id=self.current_product.get("id", ""),
        )
        if not new_row.valid:
            QMessageBox.information(
                self,
                "Ручная накладная",
                "Нужны название, количество и цена. Товар без ШК можно добавить — позже он откроется в полуавтоматическом привозе.",
            )
            return False
        self.rows, _merged = merge_manual_row(self.rows, new_row)
        row_for_print = new_row.to_mapping()
        self.populate_rows()
        self.schedule_free_receipt_autosave()
        self.clear_current()
        if print_labels:
            if row_for_print.get("barcodes"):
                self.print_thermal_labels_for_free_row(row_for_print, copies_override=print_copies)
            else:
                self.parent_page.notify("Ценники", "Товар добавлен без ШК — печать пропущена.", "info")
        return True

    def free_row_label_copies(self, row: Dict[str, Any]) -> int:
        return manual_label_copies(row)

    def update_repeat_print_button(self) -> None:
        btn = getattr(self, "repeat_print_btn", None)
        if btn is not None:
            btn.setEnabled(bool(getattr(self, "last_free_print_row", {}) or {}))

    def repeat_last_free_print(self) -> None:
        row = dict(getattr(self, "last_free_print_row", {}) or {})
        if not row:
            selected = self.rows_table.currentRow() if getattr(self, "rows_table", None) is not None else -1
            if 0 <= selected < len(self.rows):
                row = dict(self.rows[selected])
        if not row:
            QMessageBox.information(self, "Повтор печати", "Пока нет позиции для повтора печати.")
            return
        copies = int(getattr(self, "last_free_print_copies", 0) or 0) or self.free_row_label_copies(row)
        self.print_thermal_labels_for_free_row(row, copies_override=copies, repeat=True)

    def print_thermal_labels_for_free_row(self, row: Dict[str, Any], copies_override: Optional[int] = None, repeat: bool = False) -> None:
        """Print thermal price labels for a free-receipt row."""
        try:
            copies = max(1, int(copies_override if copies_override is not None else self.free_row_label_copies(row)))
            cfg = _thermal_config()
            max_without_confirm = max(1, int(cfg.get("max_without_confirm") or 20))
            if copies > max_without_confirm:
                answer = QMessageBox.question(
                    self,
                    "Печать ценников",
                    f"Напечатать {copies} ценников для товара?\n\n{row.get('name', '')}",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if answer != QMessageBox.Yes:
                    return
            item = {
                "name": row.get("name", ""),
                "barcode": (row.get("barcodes") or [""])[0],
                "price": row.get("sale", 0),
                "unit": row.get("unit", "штука"),
            }
            print_thermal_price_label(item, copies=copies, parent=self, printer_override=safe_str(_thermal_config().get("printer")))
            self.last_free_print_row = dict(row)
            self.last_free_print_copies = copies
            self.update_repeat_print_button()
            prefix = "Повторно отправлено" if repeat else "Отправлено"
            self.parent_page.notify("Термоценники", f"{prefix} на печать: {copies} шт.", "success")
        except Exception as exc:
            self.last_free_print_row = dict(row or {})
            self.last_free_print_copies = int(copies_override or self.free_row_label_copies(row or {}))
            self.update_repeat_print_button()
            QMessageBox.warning(self, "Печать ценников", f"Ценники не напечатались. Проверьте принтер и повторите печать из карточки товара.\n\n{exc}")

    def populate_rows(self) -> None:
        self.rows_label.setText(f"Добавленные товары: {len(self.rows)}")
        visible_rows = max(1, len(self.rows))
        self.rows_table.setRowCount(visible_rows)
        self.rows_table.clearContents()
        for i, r in enumerate(self.rows):
            unit = safe_str(r.get("unit"))
            if unit.casefold().replace(".", "") in {"штука", "штук", "шт"}:
                unit = "шт."
            qty = free_core_price_text(r.get("qty"))
            try:
                price = str(int(round(float(r.get("sale") or 0))))
            except Exception:
                price = safe_str(r.get("sale"))
            vals = [str(i + 1), r.get("name", ""), ", ".join(r.get("barcodes") or []), unit, qty, price]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(safe_str(v))
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
                    if c == 1
                    else Qt.AlignmentFlag.AlignCenter
                )
                self.rows_table.setItem(i, c, item)
            edit_btn = TableEditButton(tooltip="Открыть карточку товара: изменить данные или напечатать ценники")
            edit_btn.clicked.connect(lambda _checked=False, row=i: self.edit_manual_row(row))
            delete_btn = QPushButton("×")
            delete_btn.setObjectName("ManualRowDeleteButton")
            delete_btn.setToolTip("Удалить товар")
            delete_btn.clicked.connect(lambda _checked=False, row=i: self.remove_manual_row(row))
            self.rows_table.setCellWidget(i, 6, edit_btn)
            self.rows_table.setCellWidget(i, 7, delete_btn)
        row_height = 42
        self.rows_table.verticalHeader().setDefaultSectionSize(row_height)
        self.rows_table.setMinimumHeight(86)
        self.rows_table.setMaximumHeight(min(520, 44 + visible_rows * row_height + 4))
        self.rows_table.setFixedHeight(min(520, 44 + visible_rows * row_height + 4))
        self.update_free_receipt_finish_button()

    def clear_current(self) -> None:
        self.current_product = {}; self.current_old_sale_price = 0.0; self.current_barcodes = []; self.selected_category = {}; self._auto_barcode_applied = ""
        self.name_edit.clear(); self.name_edit.setPlaceholderText("Просканируйте ШК или введите наименование товара"); self.render_barcodes(); self.category_edit.clear(); self.category_edit.setPlaceholderText(""); self.update_category_chip(); self.sale_edit.clear(); self.sale_edit.setPlaceholderText("закупка"); self.retail_price_edit.clear(); self.qty_edit.clear(); self.set_unit("штука")
        if getattr(self, "print_label_check", None) is not None:
            self.print_label_check.setChecked(False)
        self._free_label_qty_manual = False
        if getattr(self, "free_label_qty_edit", None) is not None:
            self.free_label_qty_edit.setText("1")
        self.sync_free_label_qty_enabled(False)

    def remove_selected_row(self) -> None:
        row = self.rows_table.currentRow()
        self.remove_manual_row(row)

    def remove_manual_row(self, row: int) -> None:
        if not (0 <= row < len(self.rows)):
            return
        answer = QMessageBox.question(
            self,
            "Удалить товар",
            f"Удалить из накладной?\n\n{safe_str(self.rows[row].get('name'))}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.rows.pop(row)
        self.populate_rows()
        self.save_free_receipt_draft()

    def edit_manual_row(self, row: int) -> None:
        if not (0 <= row < len(self.rows)):
            return
        original = dict(self.rows[row])
        dialog = QDialog(self)
        dialog.setWindowTitle("Карточка товара")
        dialog.setMinimumWidth(620)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)
        title = QLabel("Карточка товара")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        form = QFormLayout()
        name_edit = QLineEdit(safe_str(original.get("name"))); name_edit.setObjectName("WorkbenchInput")
        barcode_edit = QLineEdit(", ".join(original.get("barcodes") or [])); barcode_edit.setObjectName("WorkbenchInput")
        barcode_edit.setPlaceholderText("Можно оставить пустым")
        unit_combo = NoWheelComboBox(); unit_combo.setObjectName("WorkbenchCombo"); unit_combo.addItems(self.units)
        unit_index = unit_combo.findText(safe_str(original.get("unit")))
        unit_combo.setCurrentIndex(max(0, unit_index))
        qty_edit = QLineEdit(free_core_price_text(original.get("qty"))); qty_edit.setObjectName("WorkbenchInput")
        buy_edit = QLineEdit(free_core_price_text(original.get("buy"))); buy_edit.setObjectName("WorkbenchInput")
        sale_edit = QLineEdit(free_core_price_text(original.get("sale"))); sale_edit.setObjectName("WorkbenchInput")
        form.addRow("Наименование", name_edit)
        barcode_row = QHBoxLayout()
        barcode_row.addWidget(barcode_edit, 1)
        generate_btn = QPushButton("Товар без ШК ⇒ Создать ШК"); generate_btn.setObjectName("SoftButton")
        barcode_row.addWidget(generate_btn)
        barcode_wrap = QWidget(); barcode_wrap.setLayout(barcode_row)
        form.addRow("ШК", barcode_wrap)
        form.addRow("Единица", unit_combo)
        form.addRow("Количество", qty_edit)
        form.addRow("Закупочная цена", buy_edit)
        form.addRow("Цена продажи", sale_edit)
        layout.addLayout(form)

        print_row = QHBoxLayout()
        copies_minus = QPushButton("−"); copies_minus.setObjectName("SoftButton"); copies_minus.setFixedSize(38, 38)
        copies_edit = QLineEdit(str(self.free_row_label_copies(original))); copies_edit.setObjectName("WorkbenchInput"); copies_edit.setFixedWidth(74); copies_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        copies_plus = QPushButton("+"); copies_plus.setObjectName("SoftButton"); copies_plus.setFixedSize(38, 38)
        print_btn = QPushButton("Печатать"); print_btn.setObjectName("SoftButton")
        print_row.addWidget(QLabel("Ценников"))
        print_row.addWidget(copies_minus); print_row.addWidget(copies_edit); print_row.addWidget(copies_plus)
        print_row.addStretch(1); print_row.addWidget(print_btn)
        layout.addLayout(print_row)
        actions = QHBoxLayout()
        cancel_btn = QPushButton("Отмена"); cancel_btn.setObjectName("SoftButton"); cancel_btn.clicked.connect(dialog.reject)
        save_btn = QPushButton("Сохранить"); save_btn.setObjectName("WorkbenchPrimaryButton")
        actions.addStretch(1); actions.addWidget(cancel_btn); actions.addWidget(save_btn)
        layout.addLayout(actions)

        def card_mapping() -> Optional[Dict[str, Any]]:
            model = ManualReceiptRow.from_values(
                name=name_edit.text(),
                barcodes=_sai_package_barcodes(barcode_edit.text()),
                category=original.get("category", ""),
                unit=unit_combo.currentText(),
                qty=qty_edit.text(),
                buy=buy_edit.text(),
                sale=sale_edit.text(),
                product_id=original.get("product_id", ""),
            )
            if not model.valid:
                QMessageBox.information(dialog, "Карточка товара", "Нужны название, количество и цена продажи.")
                return None
            data = dict(original)
            data.update(model.to_mapping())
            return data

        def adjust_copies(delta: int) -> None:
            try:
                value = max(1, int(copies_edit.text() or 1) + delta)
            except Exception:
                value = 1
            copies_edit.setText(str(value))

        def generate_for_card() -> None:
            try:
                existing = _sai_package_barcodes(barcode_edit.text())
                if existing:
                    QMessageBox.information(dialog, "Создание ШК", "У товара уже есть ШК.")
                    return
                generated = self.free_catalog_service.generate_internal_barcode(existing, self.rows)
                barcode_edit.setText(", ".join([*existing, generated.code]))
            except Exception as exc:
                QMessageBox.warning(dialog, "Создание ШК", str(exc))

        def print_card() -> None:
            data = card_mapping()
            if data is None:
                return
            if not data.get("barcodes"):
                QMessageBox.information(dialog, "Печать ценников", "Для печати сначала создай или введи ШК.")
                return
            try:
                copies = max(1, int(copies_edit.text() or 1))
            except Exception:
                copies = 1
            self.print_thermal_labels_for_free_row(data, copies_override=copies)

        def save_card() -> None:
            data = card_mapping()
            if data is None:
                return
            self.rows[row] = data
            self.populate_rows()
            self.save_free_receipt_draft()
            dialog.accept()

        copies_minus.clicked.connect(lambda: adjust_copies(-1))
        copies_plus.clicked.connect(lambda: adjust_copies(1))
        generate_btn.clicked.connect(generate_for_card)
        print_btn.clicked.connect(print_card)
        save_btn.clicked.connect(save_card)
        dialog.exec()

    def free_receipt_rows_signature(self) -> str:
        """Stable signature of the rows that are already in «Текущий привоз»."""
        try:
            data = self.supplier_combo.currentData() if getattr(self, "supplier_combo", None) is not None else None
            supplier_id, supplier_name = supplier_fields(
                data,
                self.supplier_combo.currentText() if getattr(self, "supplier_combo", None) is not None else "",
            )
            return self.manual_service.signature(
                supplier_id=supplier_id,
                supplier_name=supplier_name,
                date_text=self.date_edit.text().strip() if getattr(self, "date_edit", None) is not None else "",
                rows=self.rows,
            )
        except Exception:
            return ""

    def update_free_receipt_finish_button(self) -> None:
        btn = getattr(self, "finish_btn", None)
        if btn is None:
            return
        btn.setText("Сохранить как черновик")
        btn.setToolTip("Перенести накладную в общие черновики SAI.")

    def build_free_receipt_convert_result(self, supplier: str) -> Any:
        markup = float(load_private_config().get("default_markup_percent") or 60.0)
        return self.manual_service.build_convert_result(
            rows=self.rows,
            supplier=supplier,
            date_text=self.date_edit.text().strip(),
            markup_percent=markup,
        )

    def save_free_receipt_xml_to_desktop(self) -> Optional[Path]:
        """Compatibility name: store the manual receipt in the internal draft area."""
        data = self.supplier_combo.currentData() if getattr(self, "supplier_combo", None) is not None else None
        _supplier_id, supplier = supplier_fields(
            data,
            self.supplier_combo.currentText() if getattr(self, "supplier_combo", None) is not None else "",
        )
        if not supplier or supplier.lower().startswith("загружа"):
            supplier = "РУЧНАЯ НАКЛАДНАЯ"
        try:
            result = self.build_free_receipt_convert_result(supplier)
            meta = self.manual_service.save_prepared_receipt(result)
            if meta.get("deleted"):
                return None
            out = Path(safe_str(meta.get("package_path")))
            self.free_receipt_saved_xml_path = out
            self.free_receipt_saved_meta = dict(meta)
            self.free_receipt_saved_signature = self.free_receipt_rows_signature()
            return out
        except Exception as exc:
            QMessageBox.critical(
                self,
                "Ручная накладная",
                f"Не удалось подготовить привоз. Черновик сохранён внутри SAI.\n\nОшибка:\n{exc}",
            )
            self.save_free_receipt_draft()
            return None
    def open_saved_free_receipt_in_workbench(self) -> None:
        path = getattr(self, "free_receipt_saved_xml_path", None)
        if not path or not Path(path).exists():
            QMessageBox.information(self, "Ручная накладная", "Внутренний черновик не найден. Подготовьте привоз ещё раз.")
            return
        self.parent_page.route_sai_file(Path(path))

    def save_manual_as_draft(self, navigate_to_hub: bool = True, start_receipt: bool = False) -> bool:
        # Never lose typed data before validation.
        self.save_free_receipt_draft()
        if self.current_card_has_data():
            answer = QMessageBox.question(
                self,
                "Ручная накладная",
                "В карточке есть незавершённая позиция. Добавить её в накладную перед продолжением?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Yes,
            )
            if answer == QMessageBox.StandardButton.Cancel:
                return False
            if answer == QMessageBox.StandardButton.Yes and not self.add_current_row():
                self.save_free_receipt_draft()
                return False
        if not self.rows:
            QMessageBox.information(self, "Ручная накладная", "Сначала добавьте хотя бы одну позицию.")
            return False
        out = self.save_free_receipt_xml_to_desktop()
        if not out:
            return False
        meta = dict(getattr(self, "free_receipt_saved_meta", {}) or {})
        missing = int(meta.get("missing_barcodes") or 0)
        item_count = int(meta.get("item_count") or len(self.rows))
        self.manual_service.clear_autosave()
        self.discard_deleted_manual_draft()
        self.manual_service.restore()
        route_text = (
            f"Не хватает ШК у {missing} из {item_count} товаров — при продолжении откроется полуавтоматический привоз."
            if missing
            else f"У всех {item_count} товаров есть ШК — при продолжении откроется автоматический привоз."
        )
        self.parent_page.notify("Черновик сохранён", route_text, "success")
        hub = getattr(self.parent_page, "ux_preview_page", None)
        if hub is not None:
            hub.render()
        if start_receipt:
            self.parent_page.route_sai_file(Path(out))
        elif navigate_to_hub:
            self.parent_page.show_receipt_hub()
        return True

    def finish_free_receipt(self) -> None:
        self.save_manual_as_draft(navigate_to_hub=True)

    def enter_free_receipt(self) -> None:
        self.save_manual_as_draft(navigate_to_hub=False, start_receipt=True)



# --- Semi-auto mobile dashboard -------------------------------------------------

def _qr_gf_tables():
    exp = [0] * 512
    log = [0] * 256
    x = 1
    for i in range(255):
        exp[i] = x
        log[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11D
    for i in range(255, 512):
        exp[i] = exp[i - 255]
    return exp, log

_QR_EXP, _QR_LOG = _qr_gf_tables()


def _qr_gf_mul(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return _QR_EXP[_QR_LOG[a] + _QR_LOG[b]]


def _qr_rs_generator(degree: int) -> List[int]:
    poly = [1]
    for i in range(degree):
        nxt = [0] * (len(poly) + 1)
        for j, coef in enumerate(poly):
            nxt[j] ^= coef
            nxt[j + 1] ^= _qr_gf_mul(coef, _QR_EXP[i])
        poly = nxt
    return poly


def _qr_rs_remainder(data: List[int], degree: int) -> List[int]:
    gen = _qr_rs_generator(degree)
    rem = [0] * degree
    for b in data:
        factor = b ^ rem[0]
        rem = rem[1:] + [0]
        for i in range(degree):
            rem[i] ^= _qr_gf_mul(gen[i + 1], factor)
    return rem


def _qr_append_bits(bits: List[int], value: int, length: int) -> None:
    for i in range(length - 1, -1, -1):
        bits.append((value >> i) & 1)


def _qr_mask_bit(mask: int, r: int, c: int) -> bool:
    if mask == 0:
        return (r + c) % 2 == 0
    if mask == 1:
        return r % 2 == 0
    if mask == 2:
        return c % 3 == 0
    if mask == 3:
        return (r + c) % 3 == 0
    if mask == 4:
        return (r // 2 + c // 3) % 2 == 0
    if mask == 5:
        return ((r * c) % 2 + (r * c) % 3) == 0
    if mask == 6:
        return (((r * c) % 2 + (r * c) % 3) % 2) == 0
    return (((r + c) % 2 + (r * c) % 3) % 2) == 0


def _qr_format_bits(mask: int) -> int:
    # Error correction level L = 01 in the QR format field.
    data = (1 << 3) | (mask & 7)
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ (0x537 if ((rem >> 9) & 1) else 0)
    return ((data << 10) | rem) ^ 0x5412


def _qr_draw_format(matrix: List[List[bool]], mask: int) -> None:
    size = len(matrix)
    bits = _qr_format_bits(mask)

    def bit(i: int) -> bool:
        return ((bits >> i) & 1) != 0

    # QR format bits are duplicated around the finder patterns.
    # Keep the placement identical to the QR spec / reference encoders;
    # the previous hand-written order produced a visually valid-looking,
    # but undecodable code on phone cameras.
    for i in range(15):
        val = bit(i)
        # Vertical copy.
        if i < 6:
            matrix[i][8] = val
        elif i < 8:
            matrix[i + 1][8] = val
        else:
            matrix[size - 15 + i][8] = val

        # Horizontal copy.
        if i < 8:
            matrix[8][size - i - 1] = val
        elif i < 9:
            matrix[8][15 - i] = val
        else:
            matrix[8][14 - i] = val

    matrix[size - 8][8] = True


def _qr_penalty(matrix: List[List[bool]]) -> int:
    size = len(matrix)
    penalty = 0
    for row in matrix:
        run_color = row[0]
        run_len = 1
        for val in row[1:]:
            if val == run_color:
                run_len += 1
            else:
                if run_len >= 5:
                    penalty += 3 + (run_len - 5)
                run_color = val
                run_len = 1
        if run_len >= 5:
            penalty += 3 + (run_len - 5)
    for c in range(size):
        run_color = matrix[0][c]
        run_len = 1
        for r in range(1, size):
            val = matrix[r][c]
            if val == run_color:
                run_len += 1
            else:
                if run_len >= 5:
                    penalty += 3 + (run_len - 5)
                run_color = val
                run_len = 1
        if run_len >= 5:
            penalty += 3 + (run_len - 5)
    for r in range(size - 1):
        for c in range(size - 1):
            color = matrix[r][c]
            if matrix[r][c + 1] == color and matrix[r + 1][c] == color and matrix[r + 1][c + 1] == color:
                penalty += 3
    dark = sum(1 for row in matrix for val in row if val)
    percent = dark * 100 // (size * size)
    penalty += abs(percent - 50) // 5 * 10
    return penalty


def _make_qr_matrix(text: str) -> Optional[List[List[bool]]]:
    data_bytes = text.encode("utf-8")
    # Fixed small QR encoder for local-dashboard URLs: byte mode, EC level L.
    # Version 4 covers normal LAN URLs; version 5 is a safety reserve.
    versions = [
        (4, 80, 20, [6, 26]),
        (5, 108, 26, [6, 30]),
    ]
    chosen = None
    for version, data_cw, ecc_cw, align in versions:
        capacity_bits = data_cw * 8
        needed = 4 + 8 + len(data_bytes) * 8
        if needed <= capacity_bits:
            chosen = (version, data_cw, ecc_cw, align)
            break
    if chosen is None:
        return None
    version, data_cw, ecc_cw, align = chosen
    size = 17 + version * 4

    bits: List[int] = []
    _qr_append_bits(bits, 0b0100, 4)  # byte mode
    _qr_append_bits(bits, len(data_bytes), 8)
    for b in data_bytes:
        _qr_append_bits(bits, b, 8)
    remaining = data_cw * 8 - len(bits)
    _qr_append_bits(bits, 0, min(4, max(0, remaining)))
    while len(bits) % 8:
        bits.append(0)
    data = []
    for i in range(0, len(bits), 8):
        value = 0
        for b in bits[i:i + 8]:
            value = (value << 1) | b
        data.append(value)
    pads = [0xEC, 0x11]
    pidx = 0
    while len(data) < data_cw:
        data.append(pads[pidx % 2])
        pidx += 1
    codewords = data + _qr_rs_remainder(data, ecc_cw)
    stream: List[int] = []
    for cw in codewords:
        _qr_append_bits(stream, cw, 8)

    base: List[List[Optional[bool]]] = [[None for _ in range(size)] for _ in range(size)]
    function = [[False for _ in range(size)] for _ in range(size)]

    def set_func(r: int, c: int, val: bool) -> None:
        if 0 <= r < size and 0 <= c < size:
            base[r][c] = val
            function[r][c] = True

    def reserve(r: int, c: int) -> None:
        if 0 <= r < size and 0 <= c < size:
            if base[r][c] is None:
                base[r][c] = False
            function[r][c] = True

    def finder(r0: int, c0: int) -> None:
        for dr in range(-1, 8):
            for dc in range(-1, 8):
                r, c = r0 + dr, c0 + dc
                if not (0 <= r < size and 0 <= c < size):
                    continue
                if 0 <= dr <= 6 and 0 <= dc <= 6:
                    val = dr in (0, 6) or dc in (0, 6) or (2 <= dr <= 4 and 2 <= dc <= 4)
                    set_func(r, c, val)
                else:
                    set_func(r, c, False)

    finder(0, 0)
    finder(0, size - 7)
    finder(size - 7, 0)
    for i in range(size):
        if not function[6][i]:
            set_func(6, i, i % 2 == 0)
        if not function[i][6]:
            set_func(i, 6, i % 2 == 0)
    for ar in align:
        for ac in align:
            if function[ar][ac]:
                continue
            for dr in range(-2, 3):
                for dc in range(-2, 3):
                    set_func(ar + dr, ac + dc, max(abs(dr), abs(dc)) == 2 or (dr == 0 and dc == 0))
    # Format areas + dark module.
    for i in range(9):
        if i != 6:
            reserve(8, i)
            reserve(i, 8)
    for i in range(8):
        reserve(size - 1 - i, 8)
        reserve(8, size - 1 - i)
    set_func(4 * version + 9, 8, True)

    bit_idx = 0
    upward = True
    c = size - 1
    while c > 0:
        if c == 6:
            c -= 1
        for j in range(size):
            r = size - 1 - j if upward else j
            for cc in (c, c - 1):
                if not function[r][cc]:
                    base[r][cc] = bool(stream[bit_idx]) if bit_idx < len(stream) else False
                    bit_idx += 1
        upward = not upward
        c -= 2

    best: Optional[List[List[bool]]] = None
    best_penalty = 10 ** 9
    for mask in range(8):
        matrix = [[bool(base[r][c]) for c in range(size)] for r in range(size)]
        for r in range(size):
            for c in range(size):
                if not function[r][c] and _qr_mask_bit(mask, r, c):
                    matrix[r][c] = not matrix[r][c]
        _qr_draw_format(matrix, mask)
        score = _qr_penalty(matrix)
        if score < best_penalty:
            best_penalty = score
            best = matrix
    return best


def _make_qr_pixmap(
    text: str,
    scale: int = 8,
    border: int = 4,
    dark_color: str = "#000000",
    light_color: str = "#ffffff",
) -> Optional[QPixmap]:
    try:
        matrix = _make_qr_matrix(text)
        if not matrix:
            return None
        n = len(matrix)
        size = (n + border * 2) * scale
        img = QImage(size, size, QImage.Format_RGB32)
        bg = QColor(light_color)
        fg = QColor(dark_color)
        img.fill(bg)
        painter = QPainter(img)
        painter.fillRect(0, 0, size, size, bg)
        painter.setPen(Qt.NoPen)
        painter.setBrush(fg)
        for r, row in enumerate(matrix):
            for c, val in enumerate(row):
                if val:
                    painter.drawRect((c + border) * scale, (r + border) * scale, scale, scale)
        painter.end()
        return QPixmap.fromImage(img)
    except Exception:
        return None


def _windows_default_route_ip() -> str:
    """Return the real LAN interface behind Windows' routed default gateway.

    VPN/TUN adapters frequently install an on-link 0.0.0.0 route. A UDP probe
    then returns the tunnel address, which is unreachable from a phone on Wi-Fi.
    The normal routed default gateway identifies the physical LAN interface.
    """
    if not sys.platform.startswith("win"):
        return ""
    try:
        creation_flags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
        result = subprocess.run(
            ["route", "print", "-4"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=4,
            creationflags=creation_flags,
        )
        candidates: List[tuple[int, str]] = []
        for line in (result.stdout or "").splitlines():
            parts = line.split()
            if len(parts) < 5 or parts[0] != "0.0.0.0" or parts[1] != "0.0.0.0":
                continue
            gateway, interface = parts[2], parts[3]
            if gateway in {"0.0.0.0", "On-link"} or interface.startswith("127."):
                continue
            try:
                socket.inet_aton(gateway)
                socket.inet_aton(interface)
                metric = int(parts[4])
            except Exception:
                continue
            candidates.append((metric, interface))
        if candidates:
            return min(candidates)[1]
    except Exception:
        pass
    return ""


def _local_lan_ip() -> str:
    routed = _windows_default_route_ip()
    if routed:
        return routed
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect(("8.8.8.8", 80))
            ip = sock.getsockname()[0]
        finally:
            sock.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    try:
        addresses = list(socket.gethostbyname_ex(socket.gethostname())[2])
        usable = [ip for ip in addresses if ip and not ip.startswith(("127.", "169.254."))]
        if usable:
            def score(ip: str) -> int:
                if ip.startswith("192.168."):
                    return 30
                if ip.startswith("10."):
                    return 20
                if ip.startswith("172."):
                    try:
                        return 10 if 16 <= int(ip.split(".")[1]) <= 31 else 0
                    except Exception:
                        return 0
                return 1
            return max(usable, key=score)
    except Exception:
        pass
    return "127.0.0.1"


def _persistent_mobile_dashboard_token() -> str:
    """Keep installed PWA links valid across ordinary SAI restarts."""
    token_path = USER_DATA_DIR / "mobile_https" / "dashboard_token.txt"
    try:
        token = token_path.read_text(encoding="ascii").strip()
        if re.fullmatch(r"[A-Za-z0-9_-]{24,128}", token):
            return token
    except Exception:
        pass
    token = secrets.token_urlsafe(32)
    try:
        token_path.parent.mkdir(parents=True, exist_ok=True)
        token_path.write_text(token, encoding="ascii")
    except Exception:
        pass
    return token


class _SemiAutoMobileActionBridge(QObject):
    """Thread-safe bridge between the LAN HTTP server and the Qt UI thread."""

    request_signal = Signal(object)

    def __init__(self, page: "SemiAutoReceiptPage") -> None:
        super().__init__(page)
        self.page = page
        self.request_signal.connect(self._execute, type=Qt.ConnectionType.QueuedConnection)

    def request(self, action: str, payload: Optional[Dict[str, Any]] = None, timeout: float = 20.0) -> Dict[str, Any]:
        envelope: Dict[str, Any] = {
            "action": safe_str(action),
            "payload": dict(payload or {}),
            "event": threading.Event(),
            "result": None,
        }
        self.request_signal.emit(envelope)
        if not envelope["event"].wait(timeout):
            return {"ok": False, "error": "SAI не ответил вовремя"}
        result = envelope.get("result")
        return result if isinstance(result, dict) else {"ok": False, "error": "Пустой ответ SAI"}

    def _execute(self, envelope: Dict[str, Any]) -> None:
        try:
            envelope["result"] = self.page._execute_mobile_dashboard_action(
                safe_str(envelope.get("action")),
                envelope.get("payload") if isinstance(envelope.get("payload"), dict) else {},
            )
        except Exception as exc:
            envelope["result"] = {"ok": False, "error": str(exc)}
        finally:
            try:
                envelope["event"].set()
            except Exception:
                pass


def _mobile_app_icon_png(size: int) -> bytes:
    """Generate a dependency-free SAI-blue PNG for PWA installation."""
    side = max(64, min(512, int(size)))
    blue = (37, 99, 235, 255)
    white = (255, 255, 255, 255)
    rows = []
    bar = max(7, side // 11)
    left, right = side // 4, side - side // 4
    top, middle, bottom = side // 4, side // 2, side - side // 4
    for y in range(side):
        row = bytearray([0])
        for x in range(side):
            pixel = blue
            in_top = left <= x <= right and top <= y < top + bar
            in_mid = left <= x <= right and middle - bar // 2 <= y < middle + bar // 2
            in_bottom = left <= x <= right and bottom - bar < y <= bottom
            in_upper_left = left <= x < left + bar and top <= y <= middle
            in_lower_right = right - bar < x <= right and middle <= y <= bottom
            if in_top or in_mid or in_bottom or in_upper_left or in_lower_right:
                pixel = white
            row.extend(pixel)
        rows.append(bytes(row))

    def chunk(kind: bytes, payload: bytes) -> bytes:
        return struct.pack(">I", len(payload)) + kind + payload + struct.pack(
            ">I", zlib.crc32(kind + payload) & 0xFFFFFFFF
        )

    raw = b"".join(rows)
    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", side, side, 8, 6, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw, 9))
        + chunk(b"IEND", b"")
    )


class _SemiAutoMobileDashboardHandler(BaseHTTPRequestHandler):
    server_version = "SAI-SemiDashboard/2.0"

    def log_message(self, format, *args):  # noqa: A002 - stdlib name
        return

    def _send(
        self,
        body: bytes,
        content_type: str = "text/html; charset=utf-8",
        status: int = 200,
        extra_headers: Optional[Dict[str, str]] = None,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Private-Network", "true")
        for name, value in (extra_headers or {}).items():
            self.send_header(str(name), str(value))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, data: Dict[str, Any], status: int = 200) -> None:
        self._send(json.dumps(data, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

    def _authorized(self, query: Dict[str, List[str]]) -> bool:
        token = getattr(self.server, "token", "")
        return bool(token and (query.get("t") or [""])[0] == token)

    def do_OPTIONS(self):  # noqa: N802 - stdlib name
        self._send(b"", "text/plain; charset=utf-8", 204)

    def do_POST(self):  # noqa: N802 - stdlib name
        try:
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            if parsed.path != "/api/action":
                self._send_json({"ok": False, "error": "not found"}, 404)
                return
            if not self._authorized(query):
                self._send_json({"ok": False, "error": "bad token"}, 403)
                return
            try:
                length = min(65536, max(0, int(self.headers.get("Content-Length") or 0)))
                raw = self.rfile.read(length) if length else b"{}"
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                self._send_json({"ok": False, "error": "Некорректный запрос"}, 400)
                return
            if not isinstance(payload, dict):
                self._send_json({"ok": False, "error": "Некорректный запрос"}, 400)
                return
            action = safe_str(payload.pop("action", ""))
            page = getattr(self.server, "page", None)
            result = page.mobile_dashboard_request(action, payload) if page is not None else {"ok": False, "error": "page lost"}
            self._send_json(result, 200 if result.get("ok") else 400)
        except Exception as exc:
            self._send_json({"ok": False, "error": str(exc)}, 500)

    def do_GET(self):  # noqa: N802 - stdlib name
        try:
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            if parsed.path in {
                "/manifest.webmanifest",
                "/mobile-sw.js",
                "/app-icon-192.png",
                "/app-icon-512.png",
                "/zxing-browser.min.js",
            }:
                if not self._authorized(query):
                    self._send(b"bad token", "text/plain; charset=utf-8", 403)
                    return
                token = (query.get("t") or [""])[0]
                quoted = urllib.parse.quote(token)
                if parsed.path == "/manifest.webmanifest":
                    manifest = {
                        "id": "/sai-mobile-scanner",
                        "name": "SAI — мобильный сканер",
                        "short_name": "SAI Сканер",
                        "description": "Сбор штрихкодов для полуавтоматического привоза SAI",
                        "start_url": f"/?t={quoted}&app=1",
                        "scope": "/",
                        "display": "standalone",
                        "background_color": "#f5f7fb",
                        "theme_color": "#2563eb",
                        "orientation": "portrait",
                        "icons": [
                            {
                                "src": f"/app-icon-192.png?t={quoted}",
                                "sizes": "192x192",
                                "type": "image/png",
                                "purpose": "any maskable",
                            },
                            {
                                "src": f"/app-icon-512.png?t={quoted}",
                                "sizes": "512x512",
                                "type": "image/png",
                                "purpose": "any maskable",
                            },
                        ],
                    }
                    self._send(
                        json.dumps(manifest, ensure_ascii=False).encode("utf-8"),
                        "application/manifest+json; charset=utf-8",
                    )
                elif parsed.path == "/mobile-sw.js":
                    worker = """
const CACHE='sai-mobile-shell-v4';
const ROOT='/?t=__TOKEN__&app=1';
const SHELL=[ROOT,'/manifest.webmanifest?t=__TOKEN__','/app-icon-192.png?t=__TOKEN__','/app-icon-512.png?t=__TOKEN__','/zxing-browser.min.js?t=__TOKEN__'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const url=new URL(event.request.url);
  if(url.origin!==location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/sai-local-ca.'))return;
  if(event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).then(response=>{const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(ROOT,copy));return response;}).catch(()=>caches.match(ROOT)));
    return;
  }
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request,copy));}return response;})));
});
""".replace("__TOKEN__", quoted)
                    self._send(
                        worker.encode("utf-8"),
                        "application/javascript; charset=utf-8",
                    )
                elif parsed.path == "/zxing-browser.min.js":
                    library_path = APP_DIR / "assets" / "mobile" / "zxing-browser-0.2.0.min.js"
                    if not library_path.exists():
                        self._send(b"// ZXing library is missing", "application/javascript; charset=utf-8", 404)
                    else:
                        self._send(library_path.read_bytes(), "application/javascript; charset=utf-8")
                else:
                    size = 512 if "512" in parsed.path else 192
                    self._send(_mobile_app_icon_png(size), "image/png")
                return
            if parsed.path in {"/sai-local-ca.cer", "/sai-local-ca.crt", "/sai-local-ca.mobileconfig"}:
                if not self._authorized(query):
                    self._send("SAI: неверная или устаревшая ссылка".encode("utf-8"), "text/plain; charset=utf-8", 403)
                    return
                page = getattr(self.server, "page", None)
                if page is None:
                    self._send("SAI: страница закрыта".encode("utf-8"), "text/plain; charset=utf-8", 503)
                    return
                try:
                    page.ensure_mobile_dashboard_https()
                    ca_path = Path(page.mobile_dashboard_ca_path)
                    if parsed.path.endswith(".mobileconfig"):
                        body = build_apple_ca_profile(ca_path)
                        self._send(
                            body,
                            "application/x-apple-aspen-config",
                            extra_headers={"Content-Disposition": 'attachment; filename="SAI-Mobile-Camera.mobileconfig"'},
                        )
                    else:
                        self._send(
                            ca_path.read_bytes(),
                            "application/octet-stream",
                            extra_headers={"Content-Disposition": 'attachment; filename="SAI-Mobile-Scanner-CA.crt"'},
                        )
                except Exception as exc:
                    self._send(("SAI: " + str(exc)).encode("utf-8"), "text/plain; charset=utf-8", 503)
                return
            if parsed.path == "/api/state":
                if not self._authorized(query):
                    self._send_json({"ok": False, "error": "bad token"}, 403)
                    return
                page = getattr(self.server, "page", None)
                state = page.mobile_dashboard_request("state", {}) if page is not None else {"ok": False, "error": "page lost"}
                self._send_json(state)
                return
            if parsed.path == "/api/https":
                if not self._authorized(query):
                    self._send_json({"ok": False, "error": "bad token"}, 403)
                    return
                page = getattr(self.server, "page", None)
                if page is None:
                    self._send_json({"ok": False, "error": "page lost"}, 500)
                    return
                try:
                    url = page.ensure_mobile_dashboard_https()
                    self._send_json({"ok": True, "url": url})
                except Exception as exc:
                    self._send_json({"ok": False, "error": str(exc)}, 503)
                return
            if not self._authorized(query):
                self._send("SAI: неверная или устаревшая ссылка".encode("utf-8"), "text/plain; charset=utf-8", 403)
                return
            token_value = (query.get("t") or [getattr(self.server, "token", "")])[0]
            token_json = json.dumps(token_value)
            token_url = urllib.parse.quote(token_value)
            html_body = f"""<!doctype html>
<html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\">
<meta name=\"theme-color\" content=\"#2563eb\"><meta name=\"mobile-web-app-capable\" content=\"yes\"><meta name=\"apple-mobile-web-app-capable\" content=\"yes\"><meta name=\"apple-mobile-web-app-status-bar-style\" content=\"default\">
<link rel=\"manifest\" href=\"/manifest.webmanifest?t={token_url}\"><link rel=\"apple-touch-icon\" href=\"/app-icon-192.png?t={token_url}\">
<title>SAI — сбор штрихкодов</title>
<style>
:root {{ color-scheme:light; font-family:-apple-system,BlinkMacSystemFont,'SF Pro Display','Segoe UI',Arial,sans-serif; --canvas:#eef4ff; --surface:#ffffff; --ink:#07152e; --heading:#07152e; --muted:#65738b; --blue:#2474f5; --blue-hover:#1261dc; --blue-soft:#e9f2ff; --border:#ffffffb8; --border-strong:#ccdaee; --error-bg:#fff1f2; --error:#b91c1c; --error-border:#fecdd3; }}
* {{ box-sizing:border-box; -webkit-tap-highlight-color:transparent; }}
html,body {{ width:100%; height:100%; overflow:hidden; overscroll-behavior:none; background:var(--canvas); }}
body {{ position:fixed; inset:0; margin:0; color:var(--ink); touch-action:manipulation; transition:background-color .18s ease; background:radial-gradient(circle at 12% -10%,#d7e9ff 0,transparent 42%),linear-gradient(155deg,#f9fbff 0%,#edf3fc 100%); }}
body.error-state {{ background:var(--error-bg); }}
button,input {{ font:inherit; }}
button {{ cursor:pointer; }}
.wrap {{ position:relative; z-index:1; width:min(100%,720px); height:calc(100dvh - 92px - env(safe-area-inset-bottom)); margin:0 auto; padding:0 10px 8px; display:grid; grid-template-rows:minmax(188px,31dvh) auto auto; align-content:start; gap:10px; overflow:hidden; }}
.glass,.card {{ background:linear-gradient(145deg,#ffffffee,#f8fbffe6); border:1px solid var(--border); border-radius:26px; box-shadow:inset 0 1px 0 #ffffff,0 12px 32px #31578414; }}
.scannerCard {{ position:relative; min-height:0; margin:0 -10px; overflow:hidden; background:linear-gradient(150deg,#12213a,#07101f); border:0; border-radius:0 0 32px 32px; box-shadow:0 14px 34px #07152e2b; }}
.scannerView {{ position:absolute; inset:0; overflow:hidden; }}
.cameraVideo {{ width:100%; height:100%; object-fit:cover; object-position:center center; transition:opacity .2s ease; }}
.cameraShade {{ position:absolute; inset:0; background:#0f172a26; }}
.cameraAim {{ position:absolute; left:7%; right:7%; top:56%; height:78px; transform:translateY(-50%); border:1.5px solid #ffffffeb; border-radius:20px; box-shadow:0 0 0 999px #0610204d,inset 0 0 0 1px #ffffff26; transition:border-color .15s ease,box-shadow .15s ease; }}
.cameraAim:before {{ content:''; position:absolute; left:9px; right:9px; top:50%; height:2px; background:#60a5fa; box-shadow:0 0 10px #3b82f6; opacity:.28; transition:opacity .15s ease; }}
.cameraAim.armed {{ border:2px solid #60a5fa; box-shadow:0 0 0 999px #0f172a4d,0 0 22px #2563eb70; }}
.cameraAim.armed:before {{ opacity:1; animation:scanPulse 1.1s ease-in-out infinite alternate; }}
.cameraAim.ok {{ border:2px solid #16a34a; box-shadow:0 0 0 999px #0f172a4d,0 0 24px #16a34a80; }}
.cameraAim.err {{ border:2px solid #dc2626; box-shadow:0 0 0 999px #0f172a4d,0 0 24px #dc262680; }}
.mobileHeader {{ position:absolute; z-index:4; top:calc(10px + env(safe-area-inset-top)); left:14px; display:flex; align-items:center; gap:9px; color:#fff; font-size:12px; font-weight:750; text-shadow:0 1px 8px #0008; }}
.saiMark {{ display:grid; place-items:center; min-width:42px; height:30px; padding:0 10px; border:1px solid #ffffff70; border-radius:999px; background:linear-gradient(145deg,#59a8ffcc,#2474f5dd); box-shadow:inset 0 1px 0 #ffffff80,0 6px 18px #06102042; font-weight:900; letter-spacing:.04em; text-shadow:none; }}
.installButton {{ position:absolute; z-index:5; top:calc(9px + env(safe-area-inset-top)); right:12px; min-height:38px; padding:0 13px; border:1px solid #ffffff70; border-radius:999px; background:linear-gradient(145deg,#ffffff45,#ffffff1f); color:#fff; box-shadow:inset 0 1px 0 #ffffff70,0 8px 24px #0004; font-size:11px; font-weight:800; }}
.torchButton {{ position:absolute; z-index:5; top:calc(8px + env(safe-area-inset-top)); right:12px; width:42px; height:42px; display:grid; place-items:center; padding:0; border:1px solid #ffffff70; border-radius:50%; background:linear-gradient(145deg,#ffffff45,#ffffff1f); color:#fff; box-shadow:inset 0 1px 0 #ffffff70,0 8px 24px #0004; }}
.torchButton svg {{ width:19px; height:19px; fill:currentColor; }}
.torchButton.on {{ color:#07152e; background:#fff; box-shadow:0 0 0 4px #ffffff2e,0 8px 24px #0004; }}
.cameraIdle {{ position:absolute; z-index:3; left:50%; top:58%; transform:translate(-50%,-50%); width:max-content; max-width:76%; padding:9px 14px; border:1px solid #ffffff38; border-radius:999px; background:#07152e66; color:#ffffffd9; font-size:12px; font-weight:700; text-align:center; }}
.hero {{ min-height:0; padding:13px 17px 15px; display:flex; flex-direction:column; justify-content:center; }}
.heroTop {{ display:flex; align-items:center; justify-content:space-between; gap:10px; }}
.eyebrow {{ color:var(--muted); font-size:10px; font-weight:800; letter-spacing:.08em; text-transform:uppercase; }}
.previousItem {{ min-height:30px; padding:4px 9px; border:1px solid #d7e3f2; border-radius:10px; background:#f8fbff; color:#31557d; font-size:10px; font-weight:800; white-space:nowrap; }}
.previousItem:disabled {{ opacity:.38; }}
.nameRow {{ display:flex; align-items:flex-start; gap:7px; min-width:0; }}
h1 {{ flex:1; min-width:0; max-width:100%; margin:0 0 4px -7px; padding:5px 7px; border-radius:10px; outline:2px solid transparent; font-size:clamp(19px,5.7vw,29px); line-height:1.1; letter-spacing:-.025em; font-weight:800; overflow:visible; overflow-wrap:anywhere; }}
h1[contenteditable="true"] {{ outline-color:var(--blue); background:#fff; }}
.editName {{ flex:0 0 auto; width:34px; height:34px; margin-top:3px; display:grid; place-items:center; padding:0; border:1px solid #d7e3f2; border-radius:11px; background:#f8fbff; color:var(--blue); }}
.editName svg {{ width:16px; height:16px; fill:currentColor; }}
.editName.saving {{ color:#fff; background:var(--blue); border-color:var(--blue); }}
.restoreName {{ flex:0 0 auto; width:34px; height:34px; margin-top:3px; padding:0; border:1px solid #d7e3f2; border-radius:11px; background:#f8fbff; color:#526b8e; font-size:20px; line-height:1; font-weight:700; }}
.heroFacts {{ display:flex; align-items:center; flex-wrap:wrap; gap:8px; }}
.factPill {{ display:inline-flex; align-items:baseline; gap:5px; min-height:32px; padding:7px 11px; border:1px solid #dbe8f8; border-radius:999px; background:#f5f9ff; color:var(--muted); font-size:11px; font-weight:700; }}
.factPill strong {{ color:var(--ink); font-size:13px; font-weight:800; }}
.remainingPill {{ margin-left:auto; color:#1d4ed8; background:var(--blue-soft); border-color:#bfdbfe; }}
.controlStack {{ display:grid; grid-template-columns:1fr 1fr; gap:0; min-height:0; align-self:start; overflow:hidden; border:1px solid var(--border); border-radius:26px; background:linear-gradient(145deg,#ffffffed,#f7faffdf); box-shadow:inset 0 1px 0 #fff,0 12px 32px #31578412; }}
.controlPanel {{ min-width:0; padding:11px 10px 10px; border:0; border-radius:0; background:transparent; box-shadow:none; }}
.controlPanel + .controlPanel {{ border-left:1px solid #dce7f5; }}
.controlHeader {{ display:flex; align-items:center; justify-content:space-between; gap:5px; min-height:25px; color:#475569; font-size:10px; font-weight:800; letter-spacing:.025em; text-transform:uppercase; white-space:nowrap; }}
.controlHeader > span:first-child {{ min-width:0; overflow:hidden; line-height:1.15; text-overflow:ellipsis; white-space:nowrap; }}
.printControl {{ display:flex; align-items:center; gap:5px; color:#475569; font-size:9px; letter-spacing:0; text-transform:none; white-space:nowrap; }}
.controls {{ display:grid; grid-template-columns:40px minmax(44px,1fr) 40px; gap:0; align-items:center; margin-top:6px; }}
.controlBtn {{ width:40px; height:44px; border:1px solid #d5e2f3; border-radius:0; background:linear-gradient(#fff,#f2f7fd); color:var(--blue); font-size:24px; line-height:1; font-weight:650; box-shadow:inset 0 1px 0 #fff; }}
.controlBtn:first-child {{ border-radius:14px 0 0 14px; }}
.controlBtn:last-child {{ border-radius:0 14px 14px 0; }}
.controlBtn:active {{ background:#dbeafe; }}
.num {{ position:relative; z-index:1; width:100%; min-width:0; height:44px; margin:0 -1px; border:1px solid #d5e2f3; border-radius:0; outline:none; text-align:center; font-size:19px; font-weight:800; color:var(--ink); background:#ffffffdc; }}
.num:focus {{ border:2px solid var(--blue); }}
.unitSelector {{ display:grid; grid-template-columns:1fr 1fr; gap:3px; margin-top:7px; padding:3px; border-radius:12px; background:#eaf1fa; }}
.unitBtn {{ min-width:0; height:27px; padding:0 4px; border:0; border-radius:9px; background:transparent; color:#64748b; font-size:10px; font-weight:800; }}
.unitBtn.active {{ background:#fff; color:var(--blue); box-shadow:0 2px 8px #3157841a; }}
.switch {{ position:relative; width:43px; height:25px; flex:0 0 auto; }}
.switch input {{ opacity:0; width:0; height:0; }}
.slider {{ position:absolute; inset:0; background:#cbd5e1; border-radius:999px; transition:.15s ease; }}
.slider:before {{ content:''; position:absolute; width:21px; height:21px; left:2px; top:2px; background:#ffffff; border-radius:50%; box-shadow:0 2px 7px #0f172a33; transition:.15s ease; }}
.switch input:checked + .slider {{ background:var(--blue); }} .switch input:checked + .slider:before {{ transform:translateX(18px); }}
.notice {{ position:fixed; z-index:40; left:50%; bottom:calc(88px + env(safe-area-inset-bottom)); width:min(calc(100% - 28px),520px); min-height:44px; padding:11px 14px; border:1px solid var(--error-border); border-radius:16px; background:#fff7f7f5; color:var(--error); box-shadow:0 12px 34px #7f1d1d2b; font-size:12px; font-weight:750; line-height:1.3; opacity:0; visibility:hidden; pointer-events:none; transform:translate(-50%,8px); transition:opacity .16s ease,transform .16s ease,visibility 0s linear .16s; }}
.notice.err:not(:empty) {{ opacity:1; visibility:visible; transform:translate(-50%,0); transition-delay:0s; }}
.meta {{ color:#637083; font-size:13px; line-height:1.45; }}
.actions {{ display:grid; grid-template-columns:1fr 1fr; gap:9px; margin-top:12px; }}
.btn {{ min-height:44px; border:1px solid var(--border-strong); border-radius:12px; background:#ffffff; color:#172033; font-weight:700; padding:9px; }}
.btn.primary {{ border-color:var(--blue); background:var(--blue); color:#fff; }} .btn.full {{ grid-column:1/-1; }}
#httpsSetup {{ position:fixed; z-index:120; inset:0; display:grid; place-items:center; padding:18px; background:#0f172a70; }}
#installHelp {{ position:fixed; z-index:130; inset:0; display:grid; place-items:center; padding:18px; background:#0f172a70; }}
.setupCard {{ width:min(100%,460px); padding:18px; background:#ffffff; border:1px solid var(--border); border-radius:20px; box-shadow:0 20px 60px #0f172a33; }}
.setupTitle {{ display:block; font-size:18px; color:var(--ink); }}
.setupSteps {{ margin:14px 0 0; padding:13px 14px 13px 34px; border:1px solid #bfdbfe; border-radius:14px; background:#eff6ff; color:#334155; font-size:13px; line-height:1.42; }}
.setupSteps li + li {{ margin-top:5px; }}
.setupHint {{ margin-top:10px; color:#64748b; font-size:11px; line-height:1.35; }}
#doneCard {{ padding:22px; text-align:center; }}
.scanInput,.techState,.footer {{ display:none !important; }}
.scanDock {{ position:fixed; z-index:20; left:0; right:0; bottom:0; padding:7px 10px calc(7px + env(safe-area-inset-bottom)); background:linear-gradient(to top,#eef4ff 52%,transparent); }}
.dockInner {{ width:min(calc(100% - 4px),700px); margin:0 auto; padding:6px; display:grid; grid-template-columns:1fr 1.5fr 1fr; gap:6px; align-items:stretch; border:1px solid #ffffffc9; border-radius:26px; background:linear-gradient(145deg,#fffffff2,#f5f9ffe8); box-shadow:inset 0 1px 0 #fff,0 14px 38px #17375f26; }}
.dockBtn {{ min-width:0; min-height:52px; padding:7px 4px; border:0; border-radius:19px; background:transparent; color:#52627a; font-size:11px; font-weight:750; }}
.dockBtn.scan {{ min-height:56px; border:1px solid #5ba0ff; border-radius:20px; background:linear-gradient(145deg,#3488ff,#1765e6); color:#ffffff; font-size:15px; box-shadow:inset 0 1px 0 #ffffff66,0 8px 20px #2474f543; }}
.dockBtn.scan.armed {{ background:var(--blue-hover); }}
.dockBtn:active {{ background:#f1f5f9; }} .dockBtn.scan:active {{ background:#1e40af; }}
@keyframes scanPulse {{ from {{ transform:translateY(-22px); opacity:.5; }} to {{ transform:translateY(22px); opacity:1; }} }}
.hidden {{ display:none !important; }}
@media (max-width:380px) {{ .controlPanel {{ padding-left:8px; padding-right:8px; }} .controlHeader {{ font-size:9px; }} .controls {{ grid-template-columns:37px minmax(38px,1fr) 37px; }} .controlBtn {{ width:37px; }} }}
@media (max-height:680px) {{ .wrap {{ grid-template-rows:minmax(158px,27dvh) auto auto; }} .hero {{ padding:10px 13px; }} h1 {{ font-size:20px; margin:3px 0 6px; }} .controlPanel {{ padding-top:8px; padding-bottom:8px; }} .controls {{ margin-top:3px; }} }}
</style></head><body><div class=\"wrap\">
<section id=\"scannerCard\" class=\"scannerCard\"><div id=\"cameraStage\" class=\"scannerView\"><video id=\"cameraVideo\" class=\"cameraVideo\" autoplay playsinline muted></video><div class=\"cameraShade\"></div><div id=\"cameraAim\" class=\"cameraAim\"></div></div><div class=\"mobileHeader\"><span class=\"saiMark\">SAI</span><span>Мобильный сканер</span></div><button id=\"installBtn\" class=\"installButton\" onclick=\"installMobileApp()\">Установить приложение</button><button id=\"torchBtn\" class=\"torchButton hidden\" onclick=\"toggleTorch()\" aria-label=\"Фонарик\" aria-pressed=\"false\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"M9 2h6l1 5-2 2v3.2c2.4.8 4 3 4 5.6V22H6v-4.2c0-2.6 1.6-4.8 4-5.6V9L8 7l1-5Zm1.7 2-.4 2h3.4l-.4-2h-2.6ZM8 20h8v-2.2c0-2.1-1.8-3.8-4-3.8s-4 1.7-4 3.8V20Z\"/></svg></button><div id=\"cameraIdle\" class=\"cameraIdle\">Нажмите «Сканировать»</div></section>
<section class=\"glass hero\"><div class=\"heroTop\"><div class=\"eyebrow\">Текущий товар</div><button id=\"previousItem\" class=\"previousItem\" onclick=\"act('previous')\">← Предыдущий товар</button></div><div class=\"nameRow\"><h1 id=\"name\" contenteditable=\"false\">—</h1><button id=\"restoreName\" class=\"restoreName hidden\" onclick=\"restoreOriginalName()\" aria-label=\"Вернуть исходное название\" title=\"Вернуть исходное название\">↶</button><button id=\"editName\" class=\"editName\" onclick=\"toggleNameEdit()\" aria-label=\"Изменить название\"><svg viewBox=\"0 0 24 24\" aria-hidden=\"true\"><path d=\"m15.2 5.1 3.7 3.7L8.2 19.5l-4.4.7.7-4.4L15.2 5.1Zm1.4-1.4 1.1-1.1a1.5 1.5 0 0 1 2.1 0l1.6 1.6a1.5 1.5 0 0 1 0 2.1l-1.1 1.1-3.7-3.7Z\"/></svg></button></div><div class=\"heroFacts\"><span class=\"factPill\">В приходе <strong id=\"receiptQty\">—</strong></span><span id=\"remainingBadge\" class=\"factPill remainingPill\">Без ШК: —</span></div></section>
<section id=\"httpsSetup\"><div class=\"setupCard\"><b class=\"setupTitle\">Настройка камеры</b><div class=\"meta\" style=\"margin-top:6px\">Это нужно сделать один раз, чтобы Android разрешил SAI использовать камеру в локальной сети.</div><div class=\"actions\"><button class=\"btn\" onclick=\"installLocalCertificate('android')\">Скачать для Android</button><button class=\"btn\" onclick=\"installLocalCertificate('ios')\">Установить на iPhone</button></div><div id=\"androidCertHelp\" class=\"hidden\"><ol class=\"setupSteps\"><li>Откройте <b>Настройки телефона</b>.</li><li>Найдите пункт <b>Установить сертификат</b> через поиск настроек.</li><li>Выберите <b>Сертификат CA</b> или <b>Сертификат ЦС</b>.</li><li>Откройте скачанный файл <b>SAI-Mobile-Scanner-CA.crt</b> и подтвердите установку.</li></ol><div class=\"setupHint\">Предупреждение Android о сертификате ЦС нормально для локальной камеры SAI. Устанавливайте только файл с названием SAI Mobile Scanner CA, скачанный с этого экрана.</div></div><button class=\"btn primary\" style=\"width:100%;margin-top:12px\" onclick=\"openLiveCamera()\">Сертификат установлен — открыть камеру</button></div></section>
<section id=\"installHelp\" class=\"hidden\"><div class=\"setupCard\"><b class=\"setupTitle\">Установить SAI</b><div id=\"installHelpText\" class=\"meta\" style=\"margin-top:8px\">Откройте меню браузера и выберите «Установить приложение» или «Добавить на главный экран».</div><button class=\"btn primary\" style=\"width:100%;margin-top:14px\" onclick=\"el('installHelp').classList.add('hidden')\">Понятно</button></div></section>
<div id=\"workCard\" class=\"controlStack\">
<section class=\"glass controlPanel\"><div class=\"controlHeader\"><span>Фактическое количество</span></div><div class=\"controls\"><button class=\"controlBtn\" onclick=\"act('qty_delta',{{delta:-1}})\" aria-label=\"Уменьшить количество\">−</button><input id=\"qtyInput\" class=\"num\" inputmode=\"decimal\" aria-label=\"Фактическое количество\"><button class=\"controlBtn\" onclick=\"act('qty_delta',{{delta:1}})\" aria-label=\"Увеличить количество\">+</button></div><div class=\"unitSelector\" aria-label=\"Единица измерения\"><button id=\"unitPiece\" class=\"unitBtn\" onclick=\"setUnit('штука')\">Штуки</button><button id=\"unitMeter\" class=\"unitBtn\" onclick=\"setUnit('м')\">Метры</button></div></section>
<section class=\"glass controlPanel\"><div class=\"controlHeader\"><span>Термоэтикетки</span><label class=\"switch\" aria-label=\"Печатать термоэтикетки\"><input id=\"printToggle\" type=\"checkbox\"><span class=\"slider\"></span></label></div><div class=\"controls\"><button class=\"controlBtn\" onclick=\"act('label_delta',{{delta:-1}})\" aria-label=\"Уменьшить количество этикеток\">−</button><input id=\"labelInput\" class=\"num\" inputmode=\"numeric\" aria-label=\"Количество термоэтикеток\"><button class=\"controlBtn\" onclick=\"act('label_delta',{{delta:1}})\" aria-label=\"Увеличить количество этикеток\">+</button></div></section>
<input id=\"scanInput\" class=\"scanInput\" inputmode=\"numeric\" autocomplete=\"off\"><input id=\"cameraFile\" class=\"hidden\" type=\"file\" accept=\"image/*\" capture=\"environment\"></div>
<div id=\"notice\" class=\"notice\"></div>
<section class=\"glass hidden\" id=\"doneCard\"><b>Все штрихкоды собраны</b><div class=\"meta\" style=\"margin-top:5px\">SAI-файл сохранён. Можно запускать ввод прихода.</div><button class=\"btn primary\" style=\"width:100%;margin-top:12px\" onclick=\"act('enter_sigma')\">Ввести приход</button></section>
<div class=\"techState\"><span id=\"status\"></span><span id=\"meta\"></span><span id=\"article\"></span><span id=\"price\"></span><span id=\"barcode\"></span><span id=\"progressShort\"></span><span id=\"progressText\"></span><span id=\"bar\"></span></div>
</div><div id=\"scanDock\" class=\"scanDock\"><div class=\"dockInner\"><button class=\"dockBtn\" onclick=\"act('skip')\">Пропустить</button><button id=\"scanButton\" class=\"dockBtn scan\" onclick=\"focusScanner()\">Сканировать</button><button class=\"dockBtn\" onclick=\"generateBarcode()\">Товар без ШК</button></div></div><script>
const TOKEN = {token_json}; let lastState = null; let busy = false; let editingQty = false; let editingLabel = false; let editingName = false; let originalName = '';
let secureScannerUrl = ''; let cameraReader = null; let cameraControls = null; let cameraTrack = null; let cameraBusy = false; let scannerArmed = false; let torchOn = false; let zxingLoadPromise = null;
let scanLoopTimer = null; let focusRetryTimer = null; let cameraSleepTimer = null; let scanDeadline = 0; let nativeBarcodeDetector = null;
let scanCanvas = null; let scanContext = null; let pollTimer = null; let pollInFlight = false; let lastRenderKey = '';
let cameraDevices = []; let cameraDeviceIndex = -1; let cameraDeviceId = ''; let focusAttempt = 0; let manualFocusIndex = 0; let installPromptEvent = null;
let apiBase = ''; let sessionDiscoveryPromise = null; let lastSessionDiscovery = 0;
function el(id) {{ return document.getElementById(id); }}
function apiUrl(path) {{ return (apiBase||'')+path; }}
function badgeClass(kind) {{ if (kind === 'error') return 'badge err'; if (kind === 'warn') return 'badge warn'; if (kind === 'done') return 'badge done'; if (kind === 'ok') return 'badge ok'; return 'badge'; }}
function say(text, kind='') {{
  const isError=kind==='err'&&!!text;
  el('notice').textContent=isError?text:'';
  el('notice').className='notice '+(isError?'err':'');
  document.body.classList.toggle('error-state',isError);
}}
function isInstalledApp() {{ return window.matchMedia('(display-mode: standalone)').matches||window.navigator.standalone===true; }}
function refreshInstallButton() {{ el('installBtn').classList.toggle('hidden',isInstalledApp()||!!cameraControls); }}
async function installMobileApp() {{
  if(installPromptEvent){{
    installPromptEvent.prompt();
    try{{await installPromptEvent.userChoice;}}catch(_e){{}}
    installPromptEvent=null; refreshInstallButton(); return;
  }}
  const ios=/iphone|ipad|ipod/i.test(navigator.userAgent);
  el('installHelpText').innerHTML=ios
    ? 'Нажмите кнопку <b>«Поделиться»</b> в Safari, затем выберите <b>«На экран Домой»</b>.'
    : 'Откройте меню браузера и выберите <b>«Установить приложение»</b> или <b>«Добавить на главный экран»</b>.';
  el('installHelp').classList.remove('hidden');
}}
async function probeSaiBase(base,timeoutMs=650) {{
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),timeoutMs);
  try{{
    const response=await fetch(base+'/api/state?t='+encodeURIComponent(TOKEN)+'&_='+Date.now(),{{cache:'no-store',signal:controller.signal}});
    if(!response.ok)return false;
    const state=await response.json();
    if(!state||!state.ok)return false;
    apiBase=base===location.origin?'':base;
    try{{localStorage.setItem('sai_active_api_base',base);}}catch(_e){{}}
    render(state); say(''); return true;
  }}catch(_e){{return false;}}finally{{clearTimeout(timer);}}
}}
async function discoverSaiSession() {{
  if(!isInstalledApp())return false;
  const now=Date.now(); if(sessionDiscoveryPromise)return sessionDiscoveryPromise; if(now-lastSessionDiscovery<120000)return false;
  lastSessionDiscovery=now;
  sessionDiscoveryPromise=(async()=>{{
    let saved=''; try{{saved=localStorage.getItem('sai_active_api_base')||'';}}catch(_e){{}}
    for(const base of [saved,location.origin]){{if(base&&await probeSaiBase(base,900))return true;}}
    const hosts=[location.hostname];
    try{{if(saved)hosts.push(new URL(saved).hostname);}}catch(_e){{}}
    const prefixes=[];
    for(const host of hosts){{const parts=host.split('.').map(Number);const privateIp=parts.length===4&&parts.every(value=>Number.isInteger(value)&&value>=0&&value<=255)&&(parts[0]===10||(parts[0]===192&&parts[1]===168)||(parts[0]===172&&parts[1]>=16&&parts[1]<=31));if(privateIp){{const prefix=parts.slice(0,3).join('.');if(!prefixes.includes(prefix))prefixes.push(prefix);}}}}
    for(const prefix of prefixes){{
      const bases=[]; for(let host=1;host<255;host++){{const base='https://'+prefix+'.'+host+':8765';if(base!==location.origin&&base!==saved)bases.push(base);}}
      for(let start=0;start<bases.length;start+=20){{
        const batch=bases.slice(start,start+20); const results=await Promise.all(batch.map(base=>probeSaiBase(base)));
        const found=results.findIndex(Boolean); if(found>=0)return true;
      }}
    }}
    return false;
  }})().finally(()=>{{sessionDiscoveryPromise=null;}});
  return sessionDiscoveryPromise;
}}
async function prepareHttps() {{
  if (window.isSecureContext) return location.href;
  if (secureScannerUrl) return secureScannerUrl;
  const response=await fetch('/api/https?t='+encodeURIComponent(TOKEN),{{cache:'no-store'}});
  const data=await response.json();
  if(!data.ok||!data.url) throw new Error(data.error||'HTTPS недоступен');
  secureScannerUrl=data.url; return secureScannerUrl;
}}
async function focusScanner() {{
  if(!window.isSecureContext){{
    await openLiveCamera();
    return;
  }}
  if(!cameraControls)await startCamera();
  if(!cameraControls)return;
  say('');
  scannerArmed=true; cameraBusy=false;
  focusAttempt=0; manualFocusIndex=0;
  scanDeadline=Date.now()+8000;
  clearTimeout(cameraSleepTimer);
  el('cameraAim').className='cameraAim armed';
  el('scanButton').classList.add('armed');
  el('scanButton').textContent='Ищу ШК…';
  await kickCameraFocus();
  scheduleFocusRetry();
  try {{ if(cameraTrack&&cameraTrack.applyConstraints)await cameraTrack.applyConstraints({{frameRate:{{ideal:20,max:24}}}}); }} catch(_e) {{}}
  scanCurrentFrame();
}}
function setUnit(unit) {{ return act('unit_set',{{unit}}); }}
function toggleNameEdit() {{
  const name=el('name'),button=el('editName');
  if(!editingName){{
    editingName=true; originalName=name.textContent.trim();
    name.contentEditable='true'; name.focus();
    const selection=window.getSelection(),range=document.createRange(); range.selectNodeContents(name); selection.removeAllRanges(); selection.addRange(range);
    button.classList.add('saving'); button.setAttribute('aria-label','Сохранить название');
    return;
  }}
  finishNameEdit();
}}
async function finishNameEdit() {{
  if(!editingName)return;
  const name=el('name'),button=el('editName'),value=name.textContent.trim();
  editingName=false; name.contentEditable='false'; button.classList.remove('saving'); button.setAttribute('aria-label','Изменить название');
  if(!value){{name.textContent=originalName;say('Название товара не может быть пустым','err');return;}}
  if(value!==originalName){{const ok=await act('name_set',{{value}});if(!ok)name.textContent=originalName;}}
}}
function restoreOriginalName() {{ if(!busy)act('name_restore'); }}
async function installLocalCertificate(platform) {{
  if(platform==='ios'){{
    location.href='/sai-local-ca.mobileconfig?t='+encodeURIComponent(TOKEN);
    return;
  }}
  const help=el('androidCertHelp');
  help.classList.remove('hidden');
  try {{
    const response=await fetch('/sai-local-ca.crt?t='+encodeURIComponent(TOKEN),{{cache:'no-store'}});
    if(!response.ok)throw new Error('Не удалось скачать сертификат');
    const blob=await response.blob();
    const url=URL.createObjectURL(new Blob([blob],{{type:'application/octet-stream'}}));
    const link=document.createElement('a');
    link.href=url; link.download='SAI-Mobile-Scanner-CA.crt';
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1500);
  }} catch(e) {{
    say(e.message||'Не удалось скачать сертификат','err');
  }}
}}
async function openLiveCamera() {{
  say('');
  try {{
    const url=await prepareHttps();
    sessionStorage.setItem('sai_https_attempted','1');
    location.href=url+'&camera=1';
  }} catch(e) {{
    say(e.message||'Не удалось запустить локальный HTTPS','err');
  }}
}}
async function decodeCapturedImage(file) {{
  if(!file) return;
  say('Распознаю штрихкод…');
  let bitmap=null, reader=null;
  try {{
    try {{ bitmap=await createImageBitmap(file,{{imageOrientation:'from-image'}}); }}
    catch(_e) {{ bitmap=await createImageBitmap(file); }}
    if('BarcodeDetector' in window){{
      try {{
        const detector=new BarcodeDetector({{formats:['ean_13','ean_8','code_128','upc_a','upc_e']}});
        const codes=await detector.detect(bitmap);
        if(codes&&codes.length){{await handleCameraResult(codes[0].rawValue);return;}}
      }} catch(_e) {{}}
    }}
    await ensureZxing();
    reader=new ZXingBrowser.BrowserMultiFormatReader();
    const w=bitmap.width, h=bitmap.height;
    const regions=[
      [0,0,1,1,false],
      [.04,.10,.92,.80,false],
      [.03,.27,.94,.46,false],
      [.03,.38,.94,.24,false],
      [.03,.08,.94,.48,false],
      [.03,.48,.94,.48,false],
      [.03,.27,.94,.46,true],
      [.03,.38,.94,.24,true],
      [0,0,1,1,true]
    ];
    for(const region of regions){{
      const [rx,ry,rw,rh,enhance]=region;
      const sx=Math.max(0,Math.floor(w*rx)), sy=Math.max(0,Math.floor(h*ry));
      const sw=Math.max(1,Math.min(w-sx,Math.floor(w*rw))), sh=Math.max(1,Math.min(h-sy,Math.floor(h*rh)));
      const scale=Math.min(2.4,1800/sw);
      const canvas=document.createElement('canvas');
      canvas.width=Math.max(640,Math.round(sw*scale));
      canvas.height=Math.max(180,Math.round(sh*scale));
      const ctx=canvas.getContext('2d',{{alpha:false,willReadFrequently:true}});
      ctx.imageSmoothingEnabled=true; ctx.imageSmoothingQuality='high';
      if(enhance)ctx.filter='grayscale(1) contrast(2.15)';
      ctx.drawImage(bitmap,sx,sy,sw,sh,0,0,canvas.width,canvas.height);
      try {{
        const result=reader.decodeFromCanvas(canvas);
        if(result){{await handleCameraResult(result.getText());return;}}
      }} catch(_e) {{}}
    }}
    throw new Error('Штрихкод не найден — попробуйте приблизить камеру');
  }} catch(e) {{
    const message=String(e&&e.message||'');
    say(message.includes('Штрихкод не найден')?message:'Не удалось распознать ШК. Снимите его ближе, ровно и без бликов.','err');
  }} finally {{
    try {{ if(reader&&reader.reset)reader.reset(); }} catch(_e) {{}}
    if(bitmap&&bitmap.close)bitmap.close();
    el('cameraFile').value='';
  }}
}}
function loadScriptWithTimeout(url, timeoutMs=7000) {{
  return new Promise((resolve,reject)=>{{
    const script=document.createElement('script'); let done=false;
    const timer=setTimeout(()=>{{if(done)return;done=true;script.remove();reject(new Error('Модуль камеры не загрузился'));}},timeoutMs);
    script.src=url; script.async=true;
    script.onload=()=>{{if(done)return;done=true;clearTimeout(timer);resolve();}};
    script.onerror=()=>{{if(done)return;done=true;clearTimeout(timer);script.remove();reject(new Error('Источник камеры недоступен'));}};
    document.head.appendChild(script);
  }});
}}
async function ensureZxing() {{
  if(window.ZXingBrowser&&ZXingBrowser.BrowserMultiFormatReader)return;
  if(!zxingLoadPromise){{
    zxingLoadPromise=(async()=>{{
      const sources=[
        '/zxing-browser.min.js?t='+encodeURIComponent(TOKEN)
      ];
      let lastError=null;
      for(const source of sources){{
        try{{await loadScriptWithTimeout(source);if(window.ZXingBrowser)return;}}
        catch(error){{lastError=error;}}
      }}
      throw lastError||new Error('Не загрузился модуль распознавания ШК');
    }})().catch(error=>{{zxingLoadPromise=null;throw error;}});
  }}
  await zxingLoadPromise;
}}
async function startCamera(requestedDeviceId='') {{
  if(cameraControls) return;
  say(''); el('cameraAim').className='cameraAim';
  try {{
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia) throw new Error('Браузер не дал доступ к камере');
    if(!requestedDeviceId){{try{{requestedDeviceId=localStorage.getItem('sai_working_camera_id')||'';}}catch(_e){{}}}}
    const video={{width:{{ideal:960,max:1280}},height:{{ideal:540,max:720}},frameRate:{{ideal:12,max:20}},advanced:[{{focusMode:'continuous'}}]}};
    video.facingMode={{exact:'environment'}};
    if(requestedDeviceId){{delete video.facingMode;video.deviceId={{exact:requestedDeviceId}};}}
    let stream;
    try {{ stream=await navigator.mediaDevices.getUserMedia({{audio:false,video}}); }}
    catch(_rearError) {{
      delete video.advanced;
      if(!requestedDeviceId)video.facingMode={{ideal:'environment'}};
      try {{ stream=await navigator.mediaDevices.getUserMedia({{audio:false,video}}); }}
      catch(_savedCameraError) {{
        if(!requestedDeviceId)throw _savedCameraError;
        try{{localStorage.removeItem('sai_working_camera_id');}}catch(_e){{}}
        delete video.deviceId; video.facingMode={{ideal:'environment'}};
        stream=await navigator.mediaDevices.getUserMedia({{audio:false,video}});
      }}
    }}
    let initialTrack=stream&&stream.getVideoTracks?stream.getVideoTracks()[0]:null;
    let initialSettings=initialTrack&&initialTrack.getSettings?initialTrack.getSettings():{{}};
    try {{
      cameraDevices=(await navigator.mediaDevices.enumerateDevices()).filter(device=>device.kind==='videoinput');
      if(!requestedDeviceId&&cameraDevices.length>1){{
        const currentId=initialSettings.deviceId||'';
        const ranked=cameraDevices.map((device,index)=>({{device,index,score:primaryCameraScore(device)}})).sort((a,b)=>b.score-a.score);
        const current=ranked.find(item=>item.device.deviceId===currentId);
        const best=ranked[0];
        if(best&&best.score>0&&best.device.deviceId!==currentId&&(!current||best.score>current.score)){{
          stream.getTracks().forEach(track=>track.stop());
          const preferred={{deviceId:{{exact:best.device.deviceId}},width:{{ideal:960,max:1280}},height:{{ideal:540,max:720}},frameRate:{{ideal:12,max:20}},advanced:[{{focusMode:'continuous'}}]}};
          try{{stream=await navigator.mediaDevices.getUserMedia({{audio:false,video:preferred}});}}
          catch(_e){{delete preferred.advanced;stream=await navigator.mediaDevices.getUserMedia({{audio:false,video:preferred}});}}
        }}
      }}
    }} catch(_e) {{cameraDevices=[];}}
    cameraControls=stream;
    el('cameraVideo').srcObject=stream;
    await el('cameraVideo').play();
    el('cameraIdle').classList.add('hidden');
    cameraTrack=stream&&stream.getVideoTracks?stream.getVideoTracks()[0]:null;
    const caps=cameraTrack&&cameraTrack.getCapabilities?cameraTrack.getCapabilities():{{}};
    const settings=cameraTrack&&cameraTrack.getSettings?cameraTrack.getSettings():{{}};
    cameraDeviceId=settings.deviceId||requestedDeviceId||'';
    try {{
      if(!cameraDevices.length)cameraDevices=(await navigator.mediaDevices.enumerateDevices()).filter(device=>device.kind==='videoinput');
      cameraDeviceIndex=Math.max(0,cameraDevices.findIndex(device=>device.deviceId===cameraDeviceId));
    }} catch(_e) {{cameraDevices=[];cameraDeviceIndex=-1;}}
    el('torchBtn').classList.toggle('hidden',!caps.torch);
    el('installBtn').classList.add('hidden');
    await new Promise(resolve=>setTimeout(resolve,320));
    await kickCameraFocus();
    scheduleCameraSleep();
  }} catch(e) {{
    cameraControls=null;
    el('cameraAim').className='cameraAim err';
    el('cameraIdle').textContent='Камера недоступна'; el('cameraIdle').classList.remove('hidden');
    say((e.message||'Камера не открылась')+'. Разрешите камеру в настройках браузера.','err');
  }}
}}
function primaryCameraScore(device) {{
  const label=String(device&&device.label||'').toLowerCase();
  let score=0;
  if(/back|rear|environment|задн/.test(label))score+=100;
  if(/main|primary|основн/.test(label))score+=90;
  if(/camera2\\s*0|camera\\s*0/.test(label))score+=35;
  if(/front|user|фронт|передн/.test(label))score-=500;
  if(/ultra|macro|tele|depth|aux|широкоугол|макро|теле/.test(label))score-=160;
  return score;
}}
async function applyCameraAutofocus() {{
  if(!cameraTrack||!cameraTrack.applyConstraints)return false;
  try {{
    const caps=cameraTrack.getCapabilities?cameraTrack.getCapabilities():{{}};
    const modes=Array.isArray(caps.focusMode)?caps.focusMode:[];
    const focusMode=modes.includes('continuous')?'continuous':modes.includes('single-shot')?'single-shot':'continuous';
    await cameraTrack.applyConstraints({{advanced:[{{focusMode}}]}});
    return true;
  }} catch(_e) {{ return false; }}
}}
async function kickCameraFocus(point=null, allowManualSweep=false) {{
  if(!cameraTrack||!cameraTrack.applyConstraints)return false;
  try {{
    const caps=cameraTrack.getCapabilities?cameraTrack.getCapabilities():{{}};
    const modes=Array.isArray(caps.focusMode)?caps.focusMode:[];
    if(allowManualSweep&&modes.includes('manual')&&caps.focusDistance&&Number.isFinite(Number(caps.focusDistance.max))){{
      const min=Number(caps.focusDistance.min||0),max=Number(caps.focusDistance.max||0);
      const fractions=[.22,.38,.54,.7,.86,1];
      const distance=min+(max-min)*fractions[manualFocusIndex++%fractions.length];
      await cameraTrack.applyConstraints({{advanced:[{{focusMode:'manual',focusDistance:distance}}]}});
      return true;
    }}
    const target={{}};
    if(point&&caps.pointsOfInterest)target.pointsOfInterest=[point];
    if(modes.includes('single-shot')){{
      target.focusMode='single-shot';
      await cameraTrack.applyConstraints({{advanced:[target]}});
      await new Promise(resolve=>setTimeout(resolve,220));
    }}
    if(modes.includes('continuous')||!modes.length){{
      const continuous={{focusMode:'continuous'}};
      if(point&&caps.pointsOfInterest)continuous.pointsOfInterest=[point];
      await cameraTrack.applyConstraints({{advanced:[continuous]}});
    }}
    return true;
  }} catch(_e) {{ return applyCameraAutofocus(); }}
}}
function scheduleFocusRetry() {{
  clearTimeout(focusRetryTimer);
  if(!scannerArmed||!cameraTrack)return;
  focusRetryTimer=setTimeout(async()=>{{focusAttempt+=1;await kickCameraFocus(null,focusAttempt>=2);scheduleFocusRetry();}},1100);
}}
function scheduleCameraSleep() {{
  clearTimeout(cameraSleepTimer);
  if(!cameraControls||scannerArmed||torchOn)return;
  cameraSleepTimer=setTimeout(()=>stopCamera(true),12000);
}}
async function scanCurrentFrame() {{
  clearTimeout(scanLoopTimer);
  if(!scannerArmed||cameraBusy||!cameraControls)return;
  if(Date.now()>scanDeadline){{
    await finishScanning(false);
    say('Штрихкод не найден. Наведите прицел и нажмите «Сканировать» ещё раз.','err');
    return;
  }}
  try {{
    const video=el('cameraVideo');
    let code='';
    if(!scanCanvas){{scanCanvas=document.createElement('canvas');scanContext=scanCanvas.getContext('2d',{{alpha:false,willReadFrequently:true}});}}
    const canvas=scanCanvas,ctx=scanContext;
    const sourceWidth=video.videoWidth||640, sourceHeight=video.videoHeight||480;
    const stageBox=el('cameraStage').getBoundingClientRect(),aimBox=el('cameraAim').getBoundingClientRect();
    const coverScale=Math.max(stageBox.width/sourceWidth,stageBox.height/sourceHeight);
    const renderedWidth=sourceWidth*coverScale,renderedHeight=sourceHeight*coverScale;
    const offsetX=(stageBox.width-renderedWidth)/2,offsetY=(stageBox.height-renderedHeight)/2;
    const insetX=Math.min(10,aimBox.width*.025),insetY=Math.min(6,aimBox.height*.06);
    const visibleLeft=aimBox.left-stageBox.left+insetX-offsetX;
    const visibleTop=aimBox.top-stageBox.top+insetY-offsetY;
    const cropWidth=Math.max(1,Math.min(sourceWidth-visibleLeft/coverScale,(aimBox.width-insetX*2)/coverScale));
    const cropHeight=Math.max(1,Math.min(sourceHeight-visibleTop/coverScale,(aimBox.height-insetY*2)/coverScale));
    const cropX=Math.max(0,visibleLeft/coverScale),cropY=Math.max(0,visibleTop/coverScale);
    const targetWidth=640,targetHeight=Math.max(96,Math.min(300,Math.round(targetWidth*cropHeight/cropWidth)));
    if(canvas.width!==targetWidth||canvas.height!==targetHeight){{canvas.width=targetWidth;canvas.height=targetHeight;}}
    ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.drawImage(video,cropX,cropY,cropWidth,cropHeight,0,0,canvas.width,canvas.height);
    if('BarcodeDetector' in window){{
      if(!nativeBarcodeDetector)nativeBarcodeDetector=new BarcodeDetector({{formats:['ean_13','ean_8','code_128','upc_a','upc_e']}});
      const codes=await nativeBarcodeDetector.detect(canvas);
      if(codes&&codes.length)code=codes[0].rawValue||'';
    }} else {{
      await ensureZxing();
      if(!cameraReader)cameraReader=new ZXingBrowser.BrowserMultiFormatReader();
      try {{ const result=cameraReader.decodeFromCanvas(canvas); if(result)code=result.getText(); }} catch(_e) {{}}
    }}
    if(code){{await handleCameraResult(code);return;}}
  }} catch(e) {{
    if(String(e&&e.name||'')!=='NotFoundException')console.debug('SAI scan frame:',e);
  }}
  if(scannerArmed)scanLoopTimer=setTimeout(scanCurrentFrame,380);
}}
async function finishScanning(success=true) {{
  scannerArmed=false;
  clearTimeout(scanLoopTimer); clearTimeout(focusRetryTimer);
  el('scanButton').classList.remove('armed');
  el('scanButton').textContent='Сканировать';
  if(!success)el('cameraAim').className='cameraAim';
  try {{ if(cameraTrack&&cameraTrack.applyConstraints)await cameraTrack.applyConstraints({{frameRate:{{ideal:8,max:12}}}}); }} catch(_e) {{}}
  if(torchOn)await setTorch(false);
  scheduleCameraSleep();
}}
async function setTorch(enabled) {{
  if(!cameraTrack||!cameraTrack.applyConstraints)return false;
  try {{
    const caps=cameraTrack.getCapabilities?cameraTrack.getCapabilities():{{}};
    if(!caps.torch)throw new Error('На этом телефоне фонарик недоступен');
    await cameraTrack.applyConstraints({{advanced:[{{torch:!!enabled}}]}});
    torchOn=!!enabled;
    el('torchBtn').classList.toggle('on',torchOn);
    el('torchBtn').setAttribute('aria-pressed',torchOn?'true':'false');
    if(torchOn)clearTimeout(cameraSleepTimer);else scheduleCameraSleep();
    return true;
  }} catch(e) {{ say(e.message||'Не удалось переключить фонарик','err'); return false; }}
}}
async function toggleTorch() {{
  if(!cameraControls)await startCamera();
  await setTorch(!torchOn);
}}
async function handleCameraResult(raw) {{
  const code=String(raw||'').replace(/\\D+/g,'');
  if(code.length<8||!scannerArmed) return;
  cameraBusy=true; el('cameraAim').className='cameraAim ok';
  if(cameraDeviceId){{try{{localStorage.setItem('sai_working_camera_id',cameraDeviceId);}}catch(_e){{}}}}
  await finishScanning(true);
  el('scanButton').textContent='Принято';
  if(navigator.vibrate) navigator.vibrate(70);
  el('scanInput').value=code;
  const accepted=await acceptBarcode();
  if(!accepted)el('cameraAim').className='cameraAim err';
  setTimeout(async()=>{{cameraBusy=false;el('cameraAim').className='cameraAim';el('scanButton').textContent='Сканировать';await stopCamera(false);}},420);
}}
async function stopCamera(sleeping=false) {{
  clearTimeout(scanLoopTimer); clearTimeout(focusRetryTimer); clearTimeout(cameraSleepTimer);
  await setTorch(false);
  clearTimeout(cameraSleepTimer);
  const stream=el('cameraVideo').srcObject;
  if(stream&&stream.getTracks) stream.getTracks().forEach(track=>track.stop());
  el('cameraVideo').srcObject=null; cameraControls=null; cameraReader=null; cameraTrack=null; cameraBusy=false; scannerArmed=false; torchOn=false;
  el('torchBtn').classList.add('hidden'); el('torchBtn').classList.remove('on'); el('torchBtn').setAttribute('aria-pressed','false');
  refreshInstallButton();
  el('scanButton').classList.remove('armed'); el('scanButton').textContent='Сканировать';
  el('cameraIdle').textContent='Нажмите «Сканировать»'; el('cameraIdle').classList.remove('hidden');
}}
async function act(action, payload={{}}) {{
  if (busy) return false; busy=true;
  try {{
    const r=await fetch(apiUrl('/api/action?t='+encodeURIComponent(TOKEN)),{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify(Object.assign({{action}},payload)),cache:'no-store'}});
    const s=await r.json();
    if (!s.ok) throw new Error(s.error || 'Действие не выполнено');
    say(''); if (s.state) render(s.state); if ((action==='accept'||action==='generate') && navigator.vibrate) navigator.vibrate(60); return true;
  }} catch(e) {{ say(e.message || 'Ошибка','err'); if (navigator.vibrate) navigator.vibrate([70,50,70]); return false; }} finally {{ busy=false;scheduleTick(5000); }}
}}
function acceptBarcode() {{
  const value=el('scanInput').value.trim(); if(!value){{say('Штрихкод не распознан','err');return Promise.resolve(false);}}
  let suppress=false, confirmed=false;
  if(lastState && lastState.print_labels && Number(lastState.label_copies||0)>Number(lastState.print_confirm_limit||20)){{
    confirmed=confirm('После принятия SAI напечатает '+lastState.label_copies+' этикеток. Нажми ОК для печати. Отмена — принять ШК без печати.'); suppress=!confirmed;
  }}
  return act('accept',{{barcode:value,print_confirmed:confirmed,suppress_print:suppress}}).then(ok=>{{if(ok)el('scanInput').value='';return ok;}});
}}
function generateBarcode() {{
  let suppress=false, confirmed=false;
  if(lastState && lastState.print_labels && Number(lastState.label_copies||0)>Number(lastState.print_confirm_limit||20)){{
    confirmed=confirm('После генерации SAI напечатает '+lastState.label_copies+' этикеток. Нажми ОК для печати. Отмена — сгенерировать ШК без печати.'); suppress=!confirmed;
  }}
  act('generate',{{print_confirmed:confirmed,suppress_print:suppress}});
}}
function render(s) {{
  const renderKey=JSON.stringify(s); if(renderKey===lastRenderKey)return; lastRenderKey=renderKey;
  lastState=s; el('status').className=badgeClass(s.status_kind); el('status').textContent=s.status||'—'; if(!editingName)el('name').textContent=s.name||'—'; el('meta').textContent=s.position||'—'; el('article').textContent=s.article||'—'; el('price').textContent=s.price||'—'; el('barcode').textContent=s.barcodes||'ШК пока нет'; el('progressShort').textContent=(s.done||0)+'/'+(s.total||0); el('bar').style.width=Math.max(0,Math.min(100,s.percent||0))+'%'; el('progressText').textContent=s.progress||'—';
  el('receiptQty').textContent=((s.qty===null||s.qty===undefined)?'—':s.qty)+(s.unit?' '+s.unit:'');
  el('remainingBadge').textContent='Без ШК: '+Number(s.missing||0);
  if(!editingQty) el('qtyInput').value=(s.qty_value===null||s.qty_value===undefined)?'':s.qty_value; if(!editingLabel) el('labelInput').value=(s.label_copies===null||s.label_copies===undefined)?'':s.label_copies; el('printToggle').checked=!!s.print_labels;
  const unit=String(s.unit||'').toLowerCase().replace('.',''); const meter=unit==='м'||unit==='метр'||unit==='метры'; const piece=unit==='штука'||unit==='штук'||unit==='шт'; el('unitPiece').classList.toggle('active',piece); el('unitMeter').classList.toggle('active',meter);
  el('previousItem').disabled=!s.can_previous;
  el('restoreName').classList.toggle('hidden',!s.name_can_restore);
  el('workCard').classList.toggle('hidden',!!s.can_enter_sigma || !s.has_current); el('doneCard').classList.toggle('hidden',!s.can_enter_sigma); el('scanDock').classList.toggle('hidden',!s.has_current);
}}
function scheduleTick(delay=5000) {{
  clearTimeout(pollTimer);
  if(document.hidden)return;
  pollTimer=setTimeout(tick,Math.max(0,delay));
}}
async function tick() {{
  if(document.hidden||pollInFlight){{scheduleTick(5000);return;}}
  pollInFlight=true;
  try {{
    const r=await fetch(apiUrl('/api/state?t='+encodeURIComponent(TOKEN)+'&_='+Date.now()),{{cache:'no-store'}});
    const s=await r.json();
    if(s.ok){{render(s);if(el('notice').textContent.startsWith('Нет связи с SAI'))say('');scheduleTick(5000);}}
    else throw new Error(s.error);
  }} catch(e) {{
    if(await discoverSaiSession()){{scheduleTick(5000);return;}}
    say('Ищу активный SAI в локальной сети…','err'); scheduleTick(12000);
  }}
  finally {{pollInFlight=false;}}
}}
el('qtyInput').addEventListener('focus',()=>editingQty=true); el('qtyInput').addEventListener('blur',()=>{{editingQty=false;act('qty_set',{{value:el('qtyInput').value}});}}); el('qtyInput').addEventListener('keydown',e=>{{if(e.key==='Enter'){{e.preventDefault();el('qtyInput').blur();}}}});
el('labelInput').addEventListener('focus',()=>editingLabel=true); el('labelInput').addEventListener('blur',()=>{{editingLabel=false;act('label_set',{{value:el('labelInput').value}});}}); el('labelInput').addEventListener('keydown',e=>{{if(e.key==='Enter'){{e.preventDefault();el('labelInput').blur();}}}});
el('printToggle').addEventListener('change',()=>act('toggle_print',{{enabled:el('printToggle').checked}})); el('scanInput').addEventListener('keydown',e=>{{if(e.key==='Enter'){{e.preventDefault();acceptBarcode();}}}});
el('name').addEventListener('blur',()=>{{if(editingName)finishNameEdit();}}); el('name').addEventListener('keydown',e=>{{if(e.key==='Enter'&&!e.shiftKey){{e.preventDefault();finishNameEdit();}}if(e.key==='Escape'){{e.preventDefault();el('name').textContent=originalName;editingName=false;el('name').contentEditable='false';el('editName').classList.remove('saving');}}}});
el('editName').addEventListener('pointerdown',e=>e.preventDefault());
el('cameraFile').addEventListener('change',e=>decodeCapturedImage(e.target.files&&e.target.files[0]));
document.addEventListener('touchmove',e=>e.preventDefault(),{{passive:false}});
document.addEventListener('gesturestart',e=>e.preventDefault());
document.addEventListener('visibilitychange',()=>{{if(document.hidden){{clearTimeout(pollTimer);stopCamera();}}else scheduleTick(0);}});
if(window.isSecureContext)document.cookie='sai_camera_ready=1; Max-Age=31536000; Path=/; SameSite=Lax';
try{{localStorage.setItem('sai_mobile_session_url',location.origin+'/?t='+encodeURIComponent(TOKEN)+'&app=1');if(!localStorage.getItem('sai_active_api_base'))localStorage.setItem('sai_active_api_base',location.origin);}}catch(_e){{}}
window.addEventListener('beforeinstallprompt',event=>{{event.preventDefault();installPromptEvent=event;refreshInstallButton();}});
window.addEventListener('appinstalled',()=>{{installPromptEvent=null;el('installBtn').classList.add('hidden');}});
try{{window.matchMedia('(display-mode: standalone)').addEventListener('change',refreshInstallButton);}}catch(_e){{}}
if('serviceWorker' in navigator&&window.isSecureContext)navigator.serviceWorker.register('/mobile-sw.js?t='+encodeURIComponent(TOKEN)).catch(()=>{{}});
refreshInstallButton();
scheduleTick(0);
const cameraWasConfigured=document.cookie.split(';').some(value=>value.trim()==='sai_camera_ready=1');
const alreadyTriedHttps=sessionStorage.getItem('sai_https_attempted')==='1';
el('httpsSetup').classList.toggle('hidden',window.isSecureContext||(cameraWasConfigured&&!alreadyTriedHttps));
if(!window.isSecureContext&&cameraWasConfigured&&!alreadyTriedHttps)setTimeout(openLiveCamera,0);
</script></body></html>"""
            self._send(html_body.encode("utf-8"))
        except Exception as exc:
            self._send(("SAI dashboard error: " + str(exc)).encode("utf-8"), "text/plain; charset=utf-8", 500)



class SemiAutoReceiptPage(QWidget):
    """Полуавтоматический привоз: позиции уже есть, ШК собираются сканером по порядку."""

    def __init__(self, parent_page: "MainPage") -> None:
        super().__init__()
        self.parent_page = parent_page
        self.sai_path: Optional[Path] = None
        self.output_path: Optional[Path] = None
        self.sheet_name: str = ""
        self.rows: List[Dict[str, Any]] = []
        self.current_index: int = -1
        self.scan_timer: Optional[QTimer] = None
        self.edit_unlock_timer: Optional[QTimer] = None
        self._last_scan_text: str = ""
        self._table_edit_unlocked: bool = False
        self._table_refreshing: bool = False
        self._table_relocking: bool = False
        # The add-row is shown once when a file is opened. Later refreshes must
        # preserve the operator's current table position instead of jumping down.
        self._table_scroll_to_add_pending: bool = True
        self._dashboard_status_text: str = "ЖДУ ФАЙЛ"
        self._dashboard_status_kind: str = "idle"
        self._mobile_dashboard_last_seen: float = 0.0
        self.mobile_dashboard_server: Optional[ThreadingHTTPServer] = None
        self.mobile_dashboard_thread: Optional[threading.Thread] = None
        self.mobile_dashboard_token: str = ""
        self.mobile_dashboard_url: str = ""
        self.mobile_dashboard_https_url: str = ""
        self.mobile_dashboard_https_server: Optional[ThreadingHTTPServer] = None
        self.mobile_dashboard_https_thread: Optional[threading.Thread] = None
        self.mobile_dashboard_ca_path: str = ""
        self.mobile_dashboard_tunnel_process: Optional[subprocess.Popen] = None
        self.mobile_dashboard_tunnel_log_handle = None
        self.mobile_dashboard_tunnel_lock = threading.Lock()
        self.mobile_dashboard_bridge = _SemiAutoMobileActionBridge(self)
        self.semi_service = SemiAutoWorkflowService()
        self.semi_auto_service = SemiAutoPersistenceService()
        self.catalog_service = shared_free_catalog_service()
        self.catalog_service.warm_catalog_cache(background=True)
        self.build_ui()
        QTimer.singleShot(1200, self._start_mobile_https_silently)
        self.mobile_connection_timer = QTimer(self)
        self.mobile_connection_timer.setInterval(2000)
        self.mobile_connection_timer.timeout.connect(self.refresh_mobile_connection_visibility)
        self.mobile_connection_timer.start()

    def _start_mobile_https_silently(self) -> None:
        """Keep an installed phone PWA reachable whenever SAI is running."""
        try:
            self.ensure_mobile_dashboard_https()
        except Exception:
            # The connection dialog will show a concrete error if the operator
            # actually requests the mobile scanner.
            pass

    def build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setObjectName("WorkbenchScroll")
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll, 1)

        body = QWidget()
        body.setObjectName("WorkbenchBody")
        scroll.setWidget(body)
        root = QVBoxLayout(body)
        root.setContentsMargins(28, 26, 28, 30)
        root.setSpacing(14)

        # These labels remain as an internal compatibility surface for the
        # loader, but technical file details are no longer part of this screen.
        self.file_summary = QFrame(self)
        self.file_summary.setVisible(False)
        self.file_status_label = QLabel("Файл не найден", self.file_summary)
        self.file_supplier_value = QLabel("—", self.file_summary)
        self.file_date_value = QLabel("—", self.file_summary)
        self.file_name_value = QLabel("—", self.file_summary)
        self.file_label = self.file_name_value

        scan_card = QFrame(); scan_card.setObjectName("WorkbenchCard")
        sl = QVBoxLayout(scan_card); sl.setContentsMargins(22, 18, 22, 18); sl.setSpacing(11)
        self.progress_label = QLabel("Недостающие штрихкоды")
        self.progress_label.setVisible(False)

        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("SemiProgressBar")
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("0% · файл не выбран")
        self.progress_bar.setTextVisible(True)

        self.scan_state_label = QLabel("ЖДУ ФАЙЛ")
        self.scan_state_label.setObjectName("SemiStateIdle")
        self.scan_state_label.setAlignment(Qt.AlignCenter)
        self.scan_state_label.setVisible(False)

        overview_row = QHBoxLayout()
        overview_row.setSpacing(12)
        current_panel = QFrame()
        current_panel.setObjectName("SemiCurrentPanel")
        current_layout = QVBoxLayout(current_panel)
        current_layout.setContentsMargins(16, 14, 16, 14)
        current_layout.setSpacing(5)
        current_caption = QLabel("ТЕКУЩИЙ ТОВАР")
        current_caption.setObjectName("SemiCurrentCaption")
        current_header = QHBoxLayout()
        current_header.setContentsMargins(0, 0, 0, 0)
        current_header.setSpacing(8)
        current_header.addWidget(current_caption)
        current_header.addStretch(1)
        self.previous_item_btn = QPushButton("← Предыдущий товар")
        self.previous_item_btn.setObjectName("SoftButton")
        self.previous_item_btn.setMinimumHeight(34)
        self.previous_item_btn.setEnabled(False)
        self.previous_item_btn.clicked.connect(self.show_previous_receipt_item)
        current_header.addWidget(self.previous_item_btn)
        self.current_name_edit_btn = TableEditButton(tooltip="Изменить название текущего товара")
        self.current_name_edit_btn.setEnabled(False)
        self.current_name_edit_btn.clicked.connect(self.edit_current_product_name)
        current_header.addWidget(self.current_name_edit_btn)
        current_layout.addLayout(current_header)
        self.current_name = QLabel("—")
        self.current_name.setObjectName("SemiCurrentName")
        self.current_name.setWordWrap(True)
        current_layout.addWidget(self.current_name)
        self.current_meta = QLabel("—")
        self.current_meta.setObjectName("SemiCurrentMeta")
        self.current_meta.setWordWrap(True)
        current_layout.addWidget(self.current_meta)
        overview_row.addWidget(current_panel, 1)

        self.mobile_dashboard_panel = QFrame()
        self.mobile_dashboard_panel.setObjectName("SemiPhonePanel")
        self.mobile_dashboard_panel.setFixedWidth(168)
        mobile_layout = QVBoxLayout(self.mobile_dashboard_panel)
        mobile_layout.setContentsMargins(12, 10, 12, 10)
        mobile_layout.setSpacing(5)
        mobile_title = QLabel("СКАНЕР В ТЕЛЕФОНЕ")
        mobile_title.setObjectName("SemiCurrentCaption")
        mobile_title.setAlignment(Qt.AlignCenter)
        self.mobile_dashboard_qr = RoundedQrLabel("QR появится\nпосле загрузки")
        self.mobile_dashboard_qr.setObjectName("SemiPhoneQr")
        self.mobile_dashboard_qr.setAlignment(Qt.AlignCenter)
        self.mobile_dashboard_qr.setFixedSize(116, 116)
        self.mobile_dashboard_status = QLabel("Подключение по Wi‑Fi")
        self.mobile_dashboard_status.setObjectName("StatsSubtitle")
        self.mobile_dashboard_status.setWordWrap(True)
        mobile_layout.addWidget(mobile_title)
        mobile_layout.addWidget(self.mobile_dashboard_qr, 0, Qt.AlignCenter)
        mobile_layout.addWidget(self.mobile_dashboard_status)
        overview_row.addWidget(self.mobile_dashboard_panel, 0)
        sl.addLayout(overview_row)

        cfg = load_private_config()
        self.print_thermal_check = SaiToggleSwitch()
        self.print_thermal_check.setChecked(bool(cfg.get("semi_auto_print_thermal_labels", False)))
        self.print_thermal_check.setToolTip("После принятия ШК сразу напечатать выбранное количество термоэтикеток.")
        self.print_thermal_check.stateChanged.connect(self.semi_print_thermal_changed)
        thermal_panel = QFrame()
        thermal_panel.setObjectName("SemiThermalPanel")
        thermal_layout = QVBoxLayout(thermal_panel)
        thermal_layout.setContentsMargins(16, 14, 16, 14)
        thermal_layout.setSpacing(10)
        thermal_header = QHBoxLayout()
        thermal_header.setSpacing(9)
        thermal_title = QLabel("Термоэтикетки")
        thermal_title.setObjectName("SemiThermalTitle")
        thermal_header.addWidget(thermal_title)
        thermal_header.addWidget(self.print_thermal_check, 0, Qt.AlignVCenter)
        thermal_header.addStretch(1)

        # Size and split-layout are global printer settings.  Keep the widgets
        # as an internal compatibility surface, but do not crowd the receiving
        # screen with settings that rarely change during barcode collection.
        size_label = QLabel("Размер")
        size_label.setObjectName("StatsSubtitle")
        self.quick_thermal_size_combo = NoWheelComboBox()
        self.quick_thermal_size_combo.setObjectName("WorkbenchCombo")
        self.quick_thermal_size_combo.setMinimumHeight(38)
        self.quick_thermal_size_combo.setMaximumWidth(160)
        self.quick_thermal_size_combo.addItem("58×40 мм", "58x40")
        self.quick_thermal_size_combo.addItem("43×25 мм", "43x25")
        self.quick_thermal_size_combo.addItem("30×20 мм", "30x20")
        quick_size = str(cfg.get("thermal_label_size") or "58x40").lower().replace("×", "x").replace(" ", "")
        quick_size_index = self.quick_thermal_size_combo.findData(quick_size)
        self.quick_thermal_size_combo.setCurrentIndex(quick_size_index if quick_size_index >= 0 else 0)
        self.quick_thermal_size_combo.currentIndexChanged.connect(self.semi_thermal_size_changed)
        size_label.setVisible(False)
        self.quick_thermal_size_combo.setVisible(False)

        self.thermal_code_mode_wrap = QWidget()
        self.thermal_code_mode_wrap.setObjectName("TransparentPanel")
        code_mode_layout = QHBoxLayout(self.thermal_code_mode_wrap)
        code_mode_layout.setContentsMargins(0, 0, 0, 0)
        code_mode_layout.setSpacing(8)
        self.thermal_code_mode_switch = SaiToggleSwitch()
        self.thermal_code_mode_switch.setChecked(str(cfg.get("thermal_label_code_mode") or "barcode").lower() == "datamatrix")
        self.thermal_code_mode_switch.setToolTip("Переключить линейный штрихкод на квадратный Data Matrix.")
        self.thermal_code_mode_switch.stateChanged.connect(self.semi_thermal_code_mode_changed)
        self.thermal_code_mode_switch.setVisible(False)
        self.barcode_mode_btn = QPushButton("Штрихкод")
        self.barcode_mode_btn.setObjectName("SemiCodeModeButton")
        self.barcode_mode_btn.setCheckable(True)
        self.datamatrix_mode_btn = QPushButton("Data Matrix")
        self.datamatrix_mode_btn.setObjectName("SemiCodeModeButton")
        self.datamatrix_mode_btn.setCheckable(True)
        mode_icon_dir = Path(__file__).resolve().parent / "assets" / "icons"
        barcode_icon = QIcon()
        barcode_icon.addFile(str(mode_icon_dir / "mdi" / "barcode.svg"), QSize(24, 24), QIcon.Mode.Normal, QIcon.State.Off)
        barcode_icon.addFile(str(mode_icon_dir / "mdi" / "barcode-active.svg"), QSize(24, 24), QIcon.Mode.Normal, QIcon.State.On)
        barcode_icon.addFile(str(mode_icon_dir / "mdi" / "barcode-active.svg"), QSize(24, 24), QIcon.Mode.Active, QIcon.State.On)
        datamatrix_icon = QIcon()
        datamatrix_icon.addFile(str(mode_icon_dir / "mdi" / "data-matrix.svg"), QSize(24, 24), QIcon.Mode.Normal, QIcon.State.Off)
        datamatrix_icon.addFile(str(mode_icon_dir / "mdi" / "data-matrix-active.svg"), QSize(24, 24), QIcon.Mode.Normal, QIcon.State.On)
        datamatrix_icon.addFile(str(mode_icon_dir / "mdi" / "data-matrix-active.svg"), QSize(24, 24), QIcon.Mode.Active, QIcon.State.On)
        self.barcode_mode_btn.setIcon(barcode_icon)
        self.datamatrix_mode_btn.setIcon(datamatrix_icon)
        self.barcode_mode_btn.setIconSize(QSize(24, 24))
        self.datamatrix_mode_btn.setIconSize(QSize(24, 24))
        self.code_mode_group = QButtonGroup(self)
        self.code_mode_group.setExclusive(True)
        self.code_mode_group.addButton(self.barcode_mode_btn)
        self.code_mode_group.addButton(self.datamatrix_mode_btn)
        is_datamatrix = self.thermal_code_mode_switch.isChecked()
        self.barcode_mode_btn.setChecked(not is_datamatrix)
        self.datamatrix_mode_btn.setChecked(is_datamatrix)
        self.barcode_mode_btn.clicked.connect(lambda: self.set_semi_thermal_code_mode("barcode"))
        self.datamatrix_mode_btn.clicked.connect(lambda: self.set_semi_thermal_code_mode("datamatrix"))
        code_mode_layout.addWidget(self.barcode_mode_btn, 1)
        code_mode_layout.addWidget(self.datamatrix_mode_btn, 1)
        thermal_header.addWidget(self.thermal_code_mode_wrap)
        thermal_layout.addLayout(thermal_header)

        self.thermal_split_wrap = QWidget()
        self.thermal_split_wrap.setObjectName("TransparentPanel")
        split_layout = QHBoxLayout(self.thermal_split_wrap)
        split_layout.setContentsMargins(4, 0, 4, 0)
        split_layout.setSpacing(7)
        split_label = QLabel("2 на этикетке")
        split_label.setObjectName("StatsSubtitle")
        self.thermal_split_switch = SaiToggleSwitch()
        self.thermal_split_switch.setChecked(bool(cfg.get("thermal_label_datamatrix_split", False)))
        self.thermal_split_switch.setToolTip("Напечатать две одинаковые части 15×20 мм и разрезать этикетку пополам.")
        self.thermal_split_switch.stateChanged.connect(self.semi_thermal_split_changed)
        split_layout.addWidget(split_label)
        split_layout.addWidget(self.thermal_split_switch)
        self.thermal_split_wrap.setVisible(False)

        qty_row = QHBoxLayout()
        qty_row.setContentsMargins(12, 9, 12, 9)
        qty_row.setSpacing(0)
        qty_label = QLabel("Кол-во в приходе")
        qty_label.setObjectName("StatsSubtitle")
        qty_label.setFixedWidth(132)
        self.current_qty_edit = QLineEdit()
        self.current_qty_edit.setObjectName("SemiStepInput")
        self.current_qty_edit.setPlaceholderText("Кол-во")
        self.current_qty_edit.setFixedWidth(76)
        self.current_qty_edit.setMinimumHeight(38)
        self.current_qty_edit.setEnabled(False)
        self.current_qty_edit.setToolTip("0 = полный недовоз: позиция не пойдёт в приход, НДП и ценники.")
        self.current_qty_edit.returnPressed.connect(self.apply_current_qty_from_edit)
        self.current_qty_edit.editingFinished.connect(self.apply_current_qty_from_edit)
        self.qty_minus_btn = QPushButton("−")
        self.qty_minus_btn.setObjectName("SemiStepLeft"); self.qty_minus_btn.setFixedSize(38, 38); self.qty_minus_btn.setEnabled(False)
        self.qty_minus_btn.clicked.connect(lambda: self.adjust_current_qty(-1))
        self.qty_plus_btn = QPushButton("+")
        self.qty_plus_btn.setObjectName("SemiStepRight"); self.qty_plus_btn.setFixedSize(38, 38); self.qty_plus_btn.setEnabled(False)
        self.qty_plus_btn.clicked.connect(lambda: self.adjust_current_qty(1))
        self.qty_print_hint = QLabel("В приход: —")
        self.qty_print_hint.setVisible(False)
        qty_row.addWidget(qty_label); qty_row.addWidget(self.qty_minus_btn); qty_row.addWidget(self.current_qty_edit); qty_row.addWidget(self.qty_plus_btn); qty_row.addStretch(1)
        qty_panel = QFrame()
        qty_panel.setObjectName("SemiFieldPanel")
        qty_panel.setLayout(qty_row)

        sale_row = QHBoxLayout()
        sale_row.setContentsMargins(12, 9, 12, 9)
        sale_row.setSpacing(0)
        sale_label = QLabel("Продажная цена")
        sale_label.setObjectName("StatsSubtitle")
        sale_label.setFixedWidth(132)
        self.current_sale_edit = QLineEdit()
        self.current_sale_edit.setObjectName("SemiStepInput")
        self.current_sale_edit.setPlaceholderText("Цена продажи")
        self.current_sale_edit.setFixedWidth(76)
        self.current_sale_edit.setMinimumHeight(38)
        self.current_sale_edit.setEnabled(False)
        self.current_sale_edit.returnPressed.connect(self.apply_current_sale_from_edit)
        self.current_sale_edit.editingFinished.connect(self.apply_current_sale_from_edit)
        self.sale_minus_btn = QPushButton("−")
        self.sale_minus_btn.setObjectName("SemiStepLeft"); self.sale_minus_btn.setFixedSize(38, 38); self.sale_minus_btn.setEnabled(False)
        self.sale_minus_btn.clicked.connect(lambda: self.adjust_current_sale_price(-1))
        self.sale_plus_btn = QPushButton("+")
        self.sale_plus_btn.setObjectName("SemiStepRight"); self.sale_plus_btn.setFixedSize(38, 38); self.sale_plus_btn.setEnabled(False)
        self.sale_plus_btn.clicked.connect(lambda: self.adjust_current_sale_price(1))
        self.current_sale_hint = QLabel("Цена: —")
        self.current_sale_hint.setVisible(False)
        sale_row.addWidget(sale_label)
        sale_row.addWidget(self.sale_minus_btn)
        sale_row.addWidget(self.current_sale_edit)
        sale_row.addWidget(self.sale_plus_btn)
        sale_row.addStretch(1)
        sale_panel = QFrame()
        sale_panel.setObjectName("SemiFieldPanel")
        sale_panel.setLayout(sale_row)
        receipt_values = QHBoxLayout()
        receipt_values.setSpacing(8)
        receipt_values.addWidget(qty_panel, 1)
        receipt_values.addWidget(sale_panel, 1)
        current_layout.addLayout(receipt_values)

        self.label_qty_label = QLabel("Количество")
        self.label_qty_label.setObjectName("StatsSubtitle")
        self.current_label_qty_edit = QLineEdit()
        self.current_label_qty_edit.setObjectName("SemiStepInput")
        self.current_label_qty_edit.setPlaceholderText("Шт.")
        self.current_label_qty_edit.setFixedWidth(62)
        self.current_label_qty_edit.setMinimumHeight(38)
        self.current_label_qty_edit.setEnabled(False)
        self.current_label_qty_edit.setToolTip("Нажмите на число, чтобы снова печатать по количеству в приходе.")
        self.current_label_qty_edit.returnPressed.connect(self.apply_current_label_qty_from_edit)
        self.current_label_qty_edit.editingFinished.connect(self.apply_current_label_qty_from_edit)
        self.current_label_qty_edit.installEventFilter(self)
        self.label_qty_minus_btn = QPushButton("−")
        self.label_qty_minus_btn.setObjectName("SemiStepLeft"); self.label_qty_minus_btn.setFixedSize(38, 38); self.label_qty_minus_btn.setEnabled(False)
        self.label_qty_minus_btn.clicked.connect(lambda: self.adjust_current_label_qty(-1))
        self.label_qty_plus_btn = QPushButton("+")
        self.label_qty_plus_btn.setObjectName("SemiStepRight"); self.label_qty_plus_btn.setFixedSize(38, 38); self.label_qty_plus_btn.setEnabled(False)
        self.label_qty_plus_btn.clicked.connect(lambda: self.adjust_current_label_qty(1))
        self.label_qty_hint = QLabel("Термоэтикетки: —")
        self.label_qty_hint.setVisible(False)
        self.label_qty_one_btn = QPushButton("1")
        self.label_qty_one_btn.setObjectName("SemiLabelPresetButton")
        self.label_qty_one_btn.setCheckable(True)
        self.label_qty_one_btn.clicked.connect(lambda: self.set_current_label_qty_preset(1))
        self.label_qty_two_btn = QPushButton("2")
        self.label_qty_two_btn.setObjectName("SemiLabelPresetButton")
        self.label_qty_two_btn.setCheckable(True)
        self.label_qty_two_btn.clicked.connect(lambda: self.set_current_label_qty_preset(2))
        self.label_qty_group = QButtonGroup(self)
        self.label_qty_group.setExclusive(True)
        for preset_button in (self.label_qty_one_btn, self.label_qty_two_btn):
            self.label_qty_group.addButton(preset_button)
        thermal_layout.addWidget(self.label_qty_label)
        label_presets_row = QHBoxLayout()
        label_presets_row.setSpacing(8)
        label_presets_row.addWidget(self.label_qty_one_btn, 1)
        label_presets_row.addWidget(self.label_qty_two_btn, 1)
        thermal_layout.addLayout(label_presets_row)
        label_custom_row = QHBoxLayout()
        label_custom_row.setSpacing(8)
        label_stepper = QFrame()
        label_stepper.setObjectName("SemiStepper")
        label_stepper_layout = QHBoxLayout(label_stepper)
        label_stepper_layout.setContentsMargins(0, 0, 0, 0)
        label_stepper_layout.setSpacing(0)
        label_stepper_layout.addWidget(self.label_qty_minus_btn)
        label_stepper_layout.addWidget(self.current_label_qty_edit)
        label_stepper_layout.addWidget(self.label_qty_plus_btn)
        label_custom_row.addWidget(label_stepper, 0)
        thermal_layout.addLayout(label_custom_row)
        self.update_quick_thermal_controls()
        sl.addWidget(thermal_panel)

        scan_row = QHBoxLayout()
        self.barcode_edit = QLineEdit()
        self.barcode_edit.setObjectName("WorkbenchInput")
        self.barcode_edit.setPlaceholderText("Готов к скану")
        self.barcode_edit.returnPressed.connect(lambda: self.scan_entered(force=True))
        self.barcode_edit.textChanged.connect(self.schedule_scan_autocommit)
        self.barcode_edit.installEventFilter(self)
        self.barcode_edit.setMinimumHeight(46)
        self.scan_timer = QTimer(self)
        self.scan_timer.setSingleShot(True)
        self.scan_timer.setInterval(360)
        self.scan_timer.timeout.connect(self.scan_autocommit_tick)
        self.generate_btn = QPushButton("Товар без ШК ⇒ Создать ШК")
        self.generate_btn.setObjectName("SoftButton"); self.generate_btn.setMinimumHeight(46); self.generate_btn.clicked.connect(self.generate_for_current)
        self.name_search_btn = QPushButton("Поиск по названию")
        self.name_search_btn.setObjectName("SoftButton"); self.name_search_btn.setMinimumHeight(46); self.name_search_btn.clicked.connect(self.search_current_product_by_name)
        self.skip_btn = QPushButton("Пропустить")
        self.skip_btn.setObjectName("SoftButton"); self.skip_btn.setMinimumHeight(46); self.skip_btn.clicked.connect(self.skip_current)
        scan_row.addWidget(self.barcode_edit, 1); scan_row.addWidget(self.generate_btn, 0); scan_row.addWidget(self.name_search_btn, 0); scan_row.addWidget(self.skip_btn, 0)
        sl.addLayout(scan_row)
        sl.addWidget(self.progress_bar)
        self.scan_status = QLabel("")
        self.scan_status.setObjectName("StatsSubtitle")
        self.scan_status.setWordWrap(True)
        sl.addWidget(self.scan_status)

        self.retry_save_btn = QPushButton("Повторить сохранение")
        self.retry_save_btn.setObjectName("SoftButton")
        self.retry_save_btn.setMinimumHeight(44)
        self.retry_save_btn.setVisible(False)
        self.retry_save_btn.clicked.connect(self.retry_save_current_state)
        sl.addWidget(self.retry_save_btn)

        self.enter_sigma_btn = QPushButton("Сохранить и ввести приход в SIGMA")
        self.enter_sigma_btn.setObjectName("WorkbenchPrimaryButton")
        self.enter_sigma_btn.setMinimumHeight(48)
        self.enter_sigma_btn.setVisible(False)
        self.enter_sigma_btn.setEnabled(False)
        self.enter_sigma_btn.clicked.connect(self.open_in_auto_receipt)
        sl.addWidget(self.enter_sigma_btn)

        # Recompose the working surface after creating the compatibility
        # widgets above. The scan task stays dominant; frequently changed
        # values form one full-width band below it instead of a side column.
        while sl.count():
            sl.takeAt(0)
        sl.setContentsMargins(0, 0, 0, 0)
        sl.setSpacing(0)

        progress_strip = QFrame()
        progress_strip.setObjectName("SemiProgressStrip")
        progress_layout = QHBoxLayout(progress_strip)
        progress_layout.setContentsMargins(20, 12, 20, 12)
        progress_layout.setSpacing(14)
        progress_title = QLabel("Сбор штрихкодов")
        progress_title.setObjectName("SemiProgressTitle")
        progress_layout.addWidget(progress_title)
        progress_layout.addWidget(self.progress_bar, 1)
        self.progress_remaining_label = QLabel("Файл не выбран")
        self.progress_remaining_label.setObjectName("SemiProgressRemaining")
        progress_layout.addWidget(self.progress_remaining_label)
        sl.addWidget(progress_strip)

        self.mobile_dashboard_panel.setProperty("compactHidden", True)
        self.mobile_dashboard_panel.setVisible(False)
        current_panel.setObjectName("SemiFocusArea")
        current_layout.setContentsMargins(30, 28, 30, 24)
        current_layout.setSpacing(8)
        current_panel.setMinimumHeight(320)

        receipt_values.removeWidget(qty_panel)
        receipt_values.removeWidget(sale_panel)
        current_layout.removeItem(receipt_values)
        qty_panel.setObjectName("SemiValueSection")
        sale_panel.setObjectName("SemiValueSection")
        self.current_qty_edit.setFixedWidth(76)
        self.current_sale_edit.setFixedWidth(76)

        scan_prompt = QLabel("Отсканируйте штрихкод")
        scan_prompt.setObjectName("SemiScanPrompt")
        current_layout.addSpacing(24)
        current_layout.addWidget(scan_prompt)
        scan_field = QFrame()
        scan_field.setObjectName("SemiScanField")
        scan_field_layout = QHBoxLayout(scan_field)
        scan_field_layout.setContentsMargins(14, 7, 7, 7)
        scan_field_layout.setSpacing(8)
        self.barcode_edit.setObjectName("SemiScanInput")
        self.barcode_edit.setMinimumHeight(48)
        self.barcode_edit.setPlaceholderText("Ожидание сканирования…")
        self.mobile_dashboard_btn = QPushButton("Телефон")
        self.mobile_dashboard_btn.setObjectName("SemiPhoneButton")
        self.mobile_dashboard_btn.setMinimumHeight(44)
        self.mobile_dashboard_btn.clicked.connect(self.show_mobile_dashboard_dialog)
        scan_field_layout.addWidget(self.barcode_edit, 1)
        scan_field_layout.addWidget(self.mobile_dashboard_btn)
        current_layout.addWidget(scan_field)
        scanner_hint = QLabel("●  Сканер готов   ·   Enter не требуется")
        scanner_hint.setObjectName("SemiScannerHint")
        current_layout.addWidget(scanner_hint)
        current_layout.addWidget(self.scan_status)
        current_layout.addSpacing(12)

        alternatives = QHBoxLayout()
        alternatives.setSpacing(8)
        self.generate_btn.setText("Товар без ШК")
        self.skip_btn.setText("Пропустить пока")
        for action_button in (self.generate_btn, self.name_search_btn, self.skip_btn):
            action_button.setObjectName("SemiAlternativeButton")
            action_button.setMinimumHeight(48)
            alternatives.addWidget(action_button, 1)
        current_layout.addLayout(alternatives)

        control_panel = QFrame()
        control_panel.setObjectName("SemiControlArea")
        control_panel.setMinimumWidth(0)
        control_panel.setMaximumWidth(16777215)
        control_layout = QHBoxLayout(control_panel)
        control_layout.setContentsMargins(24, 16, 24, 16)
        control_layout.setSpacing(20)

        values_panel = QFrame()
        values_panel.setObjectName("SemiValuesColumn")
        values_panel.setFixedWidth(320)
        values_column = QVBoxLayout(values_panel)
        values_column.setContentsMargins(0, 0, 0, 0)
        values_column.setSpacing(8)
        values_column.addWidget(qty_panel)
        values_column.addWidget(sale_panel)
        control_layout.addWidget(values_panel, 0)

        value_divider = QFrame()
        value_divider.setObjectName("SemiVerticalDivider")
        value_divider.setFrameShape(QFrame.VLine)
        control_layout.addWidget(value_divider)

        thermal_panel.setObjectName("SemiLabelsSection")
        thermal_layout.setContentsMargins(0, 0, 0, 0)
        while thermal_layout.count():
            thermal_layout.takeAt(0)
        thermal_layout.setSpacing(8)
        thermal_mode_row = QHBoxLayout()
        thermal_mode_row.setContentsMargins(0, 0, 0, 0)
        thermal_mode_row.setSpacing(10)
        thermal_mode_row.addWidget(thermal_title)
        thermal_mode_row.addWidget(self.print_thermal_check, 0, Qt.AlignVCenter)
        thermal_mode_row.addSpacing(8)
        self.thermal_code_mode_wrap.setMinimumWidth(280)
        self.thermal_code_mode_wrap.setMaximumWidth(300)
        thermal_mode_row.addWidget(self.thermal_code_mode_wrap)
        thermal_mode_row.addStretch(1)

        thermal_quantity_row = QHBoxLayout()
        thermal_quantity_row.setContentsMargins(0, 0, 0, 0)
        thermal_quantity_row.setSpacing(10)
        self.label_qty_label.setText("Количество")
        thermal_quantity_row.addWidget(self.label_qty_label)
        self.label_qty_one_btn.setFixedWidth(42)
        self.label_qty_two_btn.setFixedWidth(42)
        thermal_quantity_row.addWidget(self.label_qty_one_btn)
        thermal_quantity_row.addWidget(self.label_qty_two_btn)
        self.current_label_qty_edit.setFixedWidth(62)
        thermal_quantity_row.addWidget(label_stepper)
        thermal_quantity_row.addWidget(self.thermal_split_wrap)
        thermal_quantity_row.addStretch(1)
        thermal_layout.addLayout(thermal_mode_row)
        thermal_layout.addLayout(thermal_quantity_row)
        control_layout.addWidget(thermal_panel, 1)

        work_area = QVBoxLayout()
        work_area.setContentsMargins(0, 0, 0, 0)
        work_area.setSpacing(0)
        work_area.addWidget(current_panel)
        work_area.addWidget(control_panel)
        sl.addLayout(work_area)
        sl.addWidget(self.retry_save_btn)
        sl.addWidget(self.enter_sigma_btn)
        root.addWidget(scan_card)

        table_card = QFrame(); table_card.setObjectName("WorkbenchCard"); table_card.setMinimumHeight(590)
        tl = QVBoxLayout(table_card); tl.setContentsMargins(22, 18, 22, 18); tl.setSpacing(10)
        table_header = QHBoxLayout()
        section3 = QLabel("Товары")
        section3.setObjectName("WorkbenchSection")
        self.table_add_btn = QPushButton("Добавить товар")
        self.table_add_btn.setObjectName("SoftButton")
        self.table_add_btn.setMinimumHeight(34)
        self.table_add_btn.setToolTip("Добавить новую позицию в эту же накладную")
        self.table_add_btn.clicked.connect(self.open_manual_add)
        table_header.addWidget(section3)
        table_header.addStretch(1)
        table_header.addWidget(self.table_add_btn)
        tl.addLayout(table_header)
        self.table = RoundedTableWidget(0, 9)
        self.table.setObjectName("ReceiptTable")
        self.table.setProperty("saiRoundedByShell", True)
        semi_header = RoundedTopHeaderView(Qt.Orientation.Horizontal, self.table)
        semi_header.setObjectName("SemiProductsHeader")
        self.table.setHorizontalHeader(semi_header)
        self.table.setHorizontalHeaderLabels(["№", "Наименование", "Артикул", "ШК", "Кол-во", "Ед.", "Цена продажи", "Статус", ""])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setMinimumHeight(500)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.cellClicked.connect(self.table_row_activated)
        self.table.cellDoubleClicked.connect(self.table_cell_double_clicked)
        table_shell = QFrame()
        table_shell.setObjectName("RoundedTableShell")
        table_shell_layout = QVBoxLayout(table_shell)
        table_shell_layout.setContentsMargins(2, 2, 2, 2)
        table_shell_layout.setSpacing(0)
        table_shell_layout.addWidget(self.table)
        tl.addWidget(table_shell, 1)
        root.addWidget(table_card, 1)

    def table_row_activated(self, row: int, _column: int = 0) -> None:
        """Select a scan row; editing is available only through its pencil."""
        if _column == 8:
            return
        if 0 <= row < len(self.rows or []):
            self.set_current_index(row)

    def table_cell_double_clicked(self, row: int, column: int) -> None:
        """Copy barcodes directly from the main semi-auto table."""
        if column != 3 or not (0 <= row < len(self.rows or [])):
            return
        codes = self.row_barcodes(self.rows[row])
        if not codes:
            return
        QApplication.clipboard().setText(", ".join(codes))
        self.scan_status.setText("ШК скопирован в буфер обмена.")

    def search_current_product_by_name(self) -> None:
        """Open an instant local-catalog picker for the current invoice row."""
        if not (0 <= self.current_index < len(self.rows or [])):
            QMessageBox.information(self, "Поиск по названию", "Сначала выбери товар.")
            return
        source_row = self.rows[self.current_index]
        source_name = safe_str(source_row.get("name")).strip()
        if len(source_name) < 2:
            QMessageBox.information(self, "Поиск по названию", "У текущего товара нет названия для поиска.")
            return

        matches = self.catalog_service.similar_name_search(
            source_name,
            categories=getattr(self, "categories", ()) or (),
            limit=20,
            non_blocking=True,
        )
        if not self.catalog_service.catalog_ready:
            self.catalog_service.warm_catalog_cache(background=True)
            QMessageBox.information(
                self,
                "Поиск по названию",
                "Каталог ещё загружается в память. Повтори поиск через несколько секунд.",
            )
            return
        if not matches:
            QMessageBox.information(self, "Поиск по названию", "Похожих товаров с ШК в каталоге не найдено.")
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Поиск товара по названию")
        dialog.setMinimumSize(900, 520)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)
        title = QLabel("Похожие товары в каталоге SIGMA")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        source = QLabel(source_name)
        source.setObjectName("WorkbenchSubtitle")
        source.setWordWrap(True)
        layout.addWidget(source)

        table = RoundedTableWidget(0, 5)
        table.setObjectName("ReceiptTable")
        table.setProperty("saiRoundedByShell", True)
        table.setHorizontalHeaderLabels(["Совпадение", "Товар", "Артикул", "ШК", "Цена"])
        table.verticalHeader().setVisible(False)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        table.setRowCount(len(matches))
        for index, product in enumerate(matches):
            codes = [safe_str(code) for code in (product.get("barcodes") or []) if safe_str(code)]
            values = (
                f"{int(product.get('score') or 0)}%",
                safe_str(product.get("name")),
                safe_str(product.get("vendor_code")) or "—",
                ", ".join(codes),
                (f"{_free_price_text(product.get('price'))} ₽" if _free_money_float(product.get("price")) > 0 else "—"),
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setData(Qt.UserRole, index)
                table.setItem(index, column, item)
        table.selectRow(0)
        layout.addWidget(table, 1)

        hint = QLabel("Дважды нажми строку или выбери её и нажми «Использовать ШК».")
        hint.setObjectName("StatsSubtitle")
        layout.addWidget(hint)
        actions = QHBoxLayout()
        cancel_btn = QPushButton("Отмена")
        cancel_btn.setObjectName("SoftButton")
        use_btn = QPushButton("Использовать ШК")
        use_btn.setObjectName("WorkbenchPrimaryButton")
        actions.addWidget(cancel_btn)
        actions.addStretch(1)
        actions.addWidget(use_btn)
        layout.addLayout(actions)

        def use_selected() -> None:
            selected_row = table.currentRow()
            if not (0 <= selected_row < len(matches)):
                return
            product = matches[selected_row]
            codes = [safe_str(code) for code in (product.get("barcodes") or []) if safe_str(code)]
            if not codes:
                QMessageBox.information(dialog, "Поиск по названию", "У выбранного товара нет ШК.")
                return
            code = codes[0]
            if len(codes) > 1:
                code, accepted = QInputDialog.getItem(
                    dialog, "Выбрать ШК", safe_str(product.get("name")), codes, 0, False,
                )
                if not accepted or not code:
                    return
            owner = self.find_barcode_owner(code, exclude_current=True)
            if owner is not None:
                QMessageBox.warning(
                    dialog,
                    "Поиск по названию",
                    f"Этот ШК уже указан у позиции №{owner + 1}: {safe_str((self.rows[owner] or {}).get('name'))}",
                )
                return
            if not self.approve_scanned_catalog_price(code):
                return
            self.add_barcodes_to_current([code])
            dialog.accept()

        cancel_btn.clicked.connect(dialog.reject)
        use_btn.clicked.connect(use_selected)
        table.cellDoubleClicked.connect(lambda _row, _column: use_selected())
        dialog.exec()

    def refresh_mobile_dashboard_qr(self) -> None:
        """Start the full-control phone dashboard and render its QR directly."""
        label = getattr(self, "mobile_dashboard_qr", None)
        if label is None:
            return
        try:
            url = self.ensure_mobile_dashboard()
            pix = _make_qr_pixmap(url, scale=7, border=4, dark_color="#0f172a", light_color="#ffffff")
            if pix:
                label.setPixmap(pix.scaled(116, 116, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.FastTransformation))
            else:
                label.setPixmap(QPixmap())
                label.setText("QR не создался")
            self.mobile_dashboard_status.setText("Готово к подключению")
            self.mobile_dashboard_status.setToolTip(url)
        except Exception as exc:
            label.setPixmap(QPixmap())
            label.setText("QR недоступен")
            self.mobile_dashboard_status.setText(f"Не удалось запустить дэшборд: {exc}")

    def refresh_mobile_connection_visibility(self) -> None:
        """Show the QR only while no phone is actively polling SAI."""
        panel = getattr(self, "mobile_dashboard_panel", None)
        if panel is None:
            return
        if bool(panel.property("compactHidden")):
            panel.setVisible(False)
            return
        connected = bool(
            self._mobile_dashboard_last_seen
            and (time.monotonic() - self._mobile_dashboard_last_seen) < 6.0
        )
        panel.setVisible(not connected)

    def open_manual_add(self) -> None:
        """Append a minimal missing invoice row to the semi-auto receipt.

        This is not the full free/manual receipt constructor. It only creates a
        normal invoice position inside the current semi-auto list: name, actual
        quantity, purchase price and unit. Barcode collection/generation then
        continues in the same scanner queue, and categories are requested later
        only if the product is new in SIGMA.
        """
        # Adding and editing deliberately use the same product card.  This keeps
        # quantity, direct sale-price entry, barcodes and label printing
        # consistent and, importantly, does not require a purchase price.
        self.open_semi_product_card(len(self.rows or []), new_item=True)
        return
        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить товар вручную")
        dialog.setMinimumWidth(620)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        title = QLabel("Новый товар в этой накладной")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        hint = QLabel(
            "Заполни только то, что есть в накладной: наименование, фактическое количество, "
            "закупочную цену и единицу. ШК не вводится здесь: после добавления SAI поставит "
            "позицию в очередь, чтобы ты отсканировал или сгенерировал штрихкод."
        )
        hint.setObjectName("WorkbenchSubtitle")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        form = QGridLayout()
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(10)

        name_edit = QLineEdit()
        name_edit.setObjectName("WorkbenchInput")
        name_edit.setPlaceholderText("Например: ВЕДРО ПЛАСТИКОВОЕ 10 Л")
        qty_edit = QLineEdit("1")
        qty_edit.setObjectName("WorkbenchInput")
        qty_edit.setPlaceholderText("Факт. кол-во")
        buy_edit = QLineEdit()
        buy_edit.setObjectName("WorkbenchInput")
        buy_edit.setPlaceholderText("Закупочная цена")
        unit_combo = NoWheelComboBox()
        unit_combo.setObjectName("WorkbenchCombo")
        unit_combo.addItems(["штука", "м", "кг", "г", "пара"])

        sale_preview = QLabel("Продажная цена рассчитается после ввода закупочной")
        sale_preview.setObjectName("StatsSubtitle")
        sale_preview.setWordWrap(True)

        form.addWidget(QLabel("Наименование"), 0, 0, 1, 4)
        form.addWidget(name_edit, 1, 0, 1, 4)
        form.addWidget(QLabel("Факт. кол-во"), 2, 0)
        form.addWidget(qty_edit, 3, 0)
        form.addWidget(QLabel("Закупочная цена"), 2, 1)
        form.addWidget(buy_edit, 3, 1)
        form.addWidget(QLabel("Ед."), 2, 2)
        form.addWidget(unit_combo, 3, 2)
        form.addWidget(sale_preview, 4, 0, 1, 4)
        form.setColumnStretch(0, 1)
        form.setColumnStretch(1, 1)
        form.setColumnStretch(2, 1)
        form.setColumnStretch(3, 1)
        layout.addLayout(form)

        def calc_sale() -> float:
            buy = self._parse_table_number(buy_edit.text(), 0.0)
            return float(_free_round_sale_from_purchase(buy, _free_default_markup_choice()) or 0.0)

        def update_sale_preview(*_args: Any) -> None:
            buy = self._parse_table_number(buy_edit.text(), 0.0)
            if buy <= 0:
                sale_preview.setText("Продажная цена рассчитается после ввода закупочной")
                return
            sale = calc_sale()
            sale_preview.setText(
                f"Продажная цена для SAI: {_free_price_text(sale)} ₽ "
                f"(закупка + {_free_default_markup_choice()}%; итог ниже 25 ₽ — до рубля, "
                "от 25 ₽ — до ближайшей цены на 0 или 5). "
                "Категорию SAI спросит позже, если товар окажется новым."
            )

        buy_edit.textChanged.connect(update_sale_preview)

        buttons = QDialogButtonBox(QDialogButtonBox.Cancel)
        add_btn = buttons.addButton("Добавить товар", QDialogButtonBox.AcceptRole)
        add_btn.setObjectName("WorkbenchPrimaryButton")
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        def accept() -> None:
            name = safe_str(name_edit.text()).strip().upper()
            if not name:
                QMessageBox.information(dialog, "Новая позиция", "Нужно указать наименование товара.")
                name_edit.setFocus()
                return
            qty = self._format_qty_value(qty_edit.text())
            try:
                if float(qty or 0) < 0:
                    raise ValueError
            except Exception:
                QMessageBox.information(dialog, "Новая позиция", "Количество не может быть отрицательным. 0 = полный недовоз.")
                qty_edit.setFocus()
                return
            buy = round(self._parse_table_number(buy_edit.text(), 0.0), 2)
            if buy <= 0:
                QMessageBox.information(dialog, "Новая позиция", "Нужно указать закупочную цену.")
                buy_edit.setFocus()
                return
            sale = round(calc_sale(), 2)
            unit = normalize_unit(unit_combo.currentText() or "штука") or "штука"
            row: Dict[str, Any] = {
                "excel_row": 0,
                "name": name,
                "article": "",
                "vendor_code": "",
                "code": "",
                "barcodes": [],
                "barcode_cell": "",
                "qty": qty,
                "unit": unit,
                "buy": buy,
                "purchase_price": buy,
                "sale": sale,
                "price": sale,
                "category": "",
                "comment": "Добавлено строкой в полуавтоматическом привозе",
                "semi_manual_row": True,
            }
            self.append_manual_receipt_row(row, print_labels=False)
            dialog.accept()

        add_btn.clicked.connect(accept)
        name_edit.setFocus()
        dialog.exec()

    def append_manual_receipt_row(self, row: Dict[str, Any], print_labels: bool = False) -> None:
        """Append a manually added item to the same semi/manual receipt list."""
        if not isinstance(row, dict):
            return
        self.rows.append(row)
        idx = len(self.rows) - 1
        self._table_scroll_to_add_pending = True
        self.refresh_table()
        self.refresh_progress()
        self.set_current_index(idx)
        bcs = self.row_barcodes(row)
        if print_labels and bcs and not self.semi_is_zero_qty(row):
            try:
                copies = self.print_thermal_labels_for_row(row, preferred_barcode=bcs[0])
                self.scan_status.setText(f"Позиция добавлена в накладную. Термоценники: {copies} шт.")
            except Exception as exc:
                self.scan_status.setText(f"Позиция добавлена в накладную, но ценники не напечатались: {exc}")
        elif bcs:
            self.scan_status.setText("Позиция добавлена в накладную и уже содержит ШК.")
        else:
            self.scan_status.setText("Позиция добавлена в накладную. ШК можно собрать сейчас — SAI стоит на этой строке.")
        try:
            self.save_updated_sai_file(show_message=False)
        except Exception:
            pass
    def set_scan_state(self, text: str, kind: str = "idle") -> None:
        label = getattr(self, "scan_state_label", None)
        if label is None:
            return
        names = {
            "idle": "SemiStateIdle",
            "ready": "SemiStateReady",
            "ok": "SemiStateOk",
            "warn": "SemiStateWarn",
            "error": "SemiStateError",
            "done": "SemiStateDone",
        }
        self._dashboard_status_text = safe_str(text)
        self._dashboard_status_kind = safe_str(kind) or "idle"
        label.setText(text)
        label.setObjectName(names.get(kind, "SemiStateIdle"))
        try:
            label.style().unpolish(label)
            label.style().polish(label)
        except Exception:
            pass

    def mobile_dashboard_request(self, action: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Execute a phone-dashboard request safely in the Qt UI thread."""
        bridge = getattr(self, "mobile_dashboard_bridge", None)
        if bridge is None:
            return {"ok": False, "error": "Мобильный пульт ещё не готов"}
        timeout = 45.0 if safe_str(action) in {"accept", "generate", "enter_sigma"} else 15.0
        return bridge.request(action, payload or {}, timeout=timeout)

    def _mobile_action_result(self, message: str = "") -> Dict[str, Any]:
        state = self.mobile_dashboard_state()
        state["message"] = safe_str(message)
        return {"ok": True, "message": safe_str(message), "state": state}

    def _execute_mobile_dashboard_action(self, action: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Qt-thread implementation of the complete barcode-collection controls."""
        action = safe_str(action).strip().lower()
        self._mobile_dashboard_last_seen = time.monotonic()
        self.refresh_mobile_connection_visibility()
        if action == "state":
            return self.mobile_dashboard_state()
        if not self.rows:
            return {"ok": False, "error": "В SAI ещё не открыт файл привоза"}

        if action == "accept":
            if self.current_index < 0:
                self.goto_next_missing(start=-1, wrap=True)
            if self.current_index < 0:
                return self._mobile_action_result("Все штрихкоды уже собраны")
            text = safe_str(payload.get("barcode")).strip()
            bcs, warnings, error, _wait_more = self.parse_scan_barcodes(text, force=True)
            if error:
                self.mark_scan_error(error)
                return {"ok": False, "error": error, "state": self.mobile_dashboard_state()}
            for bc in bcs:
                owner = self.find_barcode_owner(bc, exclude_current=True)
                if owner is not None:
                    error = f"Этот ШК уже указан у позиции №{owner + 1}: {safe_str((self.rows[owner] or {}).get('name'))}"
                    self.mark_scan_error(error)
                    return {"ok": False, "error": error, "state": self.mobile_dashboard_state()}
            if len(bcs) == 1 and not self.approve_scanned_catalog_price(bcs[0]):
                return {
                    "ok": False,
                    "error": "Выбор цены отменён — ШК не добавлен",
                    "state": self.mobile_dashboard_state(),
                }
            self.add_barcodes_to_current(
                bcs,
                warnings=warnings,
                print_confirmed=bool(payload.get("print_confirmed")),
                suppress_print=bool(payload.get("suppress_print")),
            )
            return self._mobile_action_result(f"ШК принят: {', '.join(bcs)}")

        if action == "generate":
            if self.current_index < 0:
                self.goto_next_missing(start=-1, wrap=True)
            if self.current_index < 0:
                return self._mobile_action_result("Все штрихкоды уже собраны")
            code = self.make_internal_barcode()
            if not code:
                return {"ok": False, "error": "Не удалось подобрать свободный внутренний ШК"}
            self.add_barcodes_to_current(
                [code],
                print_confirmed=bool(payload.get("print_confirmed")),
                suppress_print=bool(payload.get("suppress_print")),
            )
            return self._mobile_action_result(f"Сгенерирован и принят ШК {code}")

        if action == "skip":
            before = self.current_index
            self.skip_current()
            if self.current_index == before and self.current_index >= 0:
                return self._mobile_action_result("Других позиций без ШК пока нет")
            return self._mobile_action_result("Перешёл к следующему товару")

        if action == "previous":
            if not self.show_previous_receipt_item():
                return self._mobile_action_result("Это первый товар")
            return self._mobile_action_result("Вернулся к предыдущему товару")

        if action == "name_set":
            value = safe_str(payload.get("value")).strip()
            if not value:
                return {"ok": False, "error": "Название товара не может быть пустым"}
            if not self.update_current_product_name(value):
                return {"ok": False, "error": "Нет выбранного товара"}
            return self._mobile_action_result("Название товара сохранено")

        if action == "name_restore":
            if not self.restore_current_product_name():
                return {"ok": False, "error": "Исходное название для этого товара не сохранено"}
            return self._mobile_action_result("Исходное название восстановлено")

        if action == "unit_set":
            value = normalize_unit(payload.get("unit") or "штука") or "штука"
            if value not in {"штука", "м"}:
                return {"ok": False, "error": "На телефоне доступны штуки или метры"}
            if not (0 <= self.current_index < len(self.rows)):
                return {"ok": False, "error": "Нет выбранного товара"}
            row = dict(self.rows[self.current_index])
            row["unit"] = value
            row["_final_review_edited"] = True
            self.rows[self.current_index] = row
            self.refresh_table()
            self.save_updated_sai_file(show_message=False)
            self.set_current_index(self.current_index)
            return self._mobile_action_result("Единица измерения сохранена")

        if action in {"qty_set", "qty_delta"}:
            if not (0 <= self.current_index < len(self.rows)):
                return {"ok": False, "error": "Нет выбранного товара"}
            if action == "qty_delta":
                try:
                    delta = int(payload.get("delta") or 0)
                except Exception:
                    delta = 0
                self.adjust_current_qty(delta)
            else:
                raw = safe_str(payload.get("value")).strip().replace(" ", "").replace(",", ".")
                try:
                    value = float(raw or "0")
                    if value < 0:
                        raise ValueError
                except Exception:
                    return {"ok": False, "error": "Количество должно быть числом от 0 и выше"}
                self.current_qty_edit.setText(raw)
                self.apply_current_qty_from_edit()
            return self._mobile_action_result("Фактическое количество сохранено")

        if action in {"label_set", "label_delta"}:
            if not (0 <= self.current_index < len(self.rows)):
                return {"ok": False, "error": "Нет выбранного товара"}
            if action == "label_delta":
                try:
                    delta = int(payload.get("delta") or 0)
                except Exception:
                    delta = 0
                self.adjust_current_label_qty(delta)
            else:
                raw = safe_str(payload.get("value")).strip().replace(" ", "").replace(",", ".")
                try:
                    value = int(round(float(raw or "0")))
                    if value < 0:
                        raise ValueError
                except Exception:
                    return {"ok": False, "error": "Количество ценников должно быть целым числом от 0 и выше"}
                self.current_label_qty_edit.setText(str(value))
                self.apply_current_label_qty_from_edit()
            return self._mobile_action_result("Количество ценников изменено")

        if action == "toggle_print":
            enabled = bool(payload.get("enabled"))
            self.print_thermal_check.setChecked(enabled)
            return self._mobile_action_result("Термопечать включена" if enabled else "Термопечать выключена")

        if action == "enter_sigma":
            if self.missing_indices():
                return {"ok": False, "error": "Сначала собери все обязательные штрихкоды"}
            try:
                path = self.save_updated_sai_file(show_message=False)
            except Exception as exc:
                self.retry_save_btn.setVisible(True)
                return {
                    "ok": False,
                    "error": f"Все ШК в памяти, но файл не сохранился: {exc}",
                    "state": self.mobile_dashboard_state(),
                }
            if not path:
                return {"ok": False, "error": "Не удалось сохранить SAI-файл"}
            if getattr(self.parent_page, "open_sai_file_in_workbench", None):
                self.parent_page.open_sai_file_in_workbench(Path(path))
            return self._mobile_action_result("Приход передан в автоматический ввод SIGMA")

        return {"ok": False, "error": f"Неизвестное действие: {action}"}

    def ensure_mobile_dashboard(self) -> str:
        """Start a full-control LAN dashboard for the semi-auto mode."""
        if self.mobile_dashboard_server and self.mobile_dashboard_url:
            ip = _local_lan_ip()
            port = int(self.mobile_dashboard_server.server_address[1])
            self.mobile_dashboard_url = f"http://{ip}:{port}/?t={urllib.parse.quote(self.mobile_dashboard_token)}"
            return self.mobile_dashboard_url
        token = _persistent_mobile_dashboard_token()
        server = ThreadingHTTPServer(("0.0.0.0", 0), _SemiAutoMobileDashboardHandler)
        server.page = self  # type: ignore[attr-defined]
        server.token = token  # type: ignore[attr-defined]
        thread = threading.Thread(target=server.serve_forever, daemon=True, name="SAI semi mobile dashboard")
        thread.start()
        ip = _local_lan_ip()
        port = int(server.server_address[1])
        self.mobile_dashboard_server = server
        self.mobile_dashboard_thread = thread
        self.mobile_dashboard_token = token
        self.mobile_dashboard_url = f"http://{ip}:{port}/?t={urllib.parse.quote(token)}"
        try:
            self.mobile_dashboard_status.setText("Сканер телефона готов")
        except Exception:
            pass
        return self.mobile_dashboard_url

    def ensure_mobile_dashboard_https(self) -> str:
        """Start a LAN-only HTTPS server trusted by the operator's phones."""
        with self.mobile_dashboard_tunnel_lock:
            if self.mobile_dashboard_https_url and self.mobile_dashboard_https_server is not None:
                return self.mobile_dashboard_https_url
            local_url = self.ensure_mobile_dashboard()
            parsed = urllib.parse.urlparse(local_url)
            ip = safe_str(parsed.hostname) or _local_lan_ip()
            material = ensure_mobile_https_material(
                app_dir=APP_DIR,
                user_data_dir=USER_DATA_DIR,
                ip_address=ip,
            )
            try:
                server = ThreadingHTTPServer(("0.0.0.0", 8765), _SemiAutoMobileDashboardHandler)
            except OSError as exc:
                raise RuntimeError(
                    "Локальный HTTPS-порт 8765 занят. Закройте вторую копию SAI и повторите."
                ) from exc
            server.page = self  # type: ignore[attr-defined]
            server.token = self.mobile_dashboard_token  # type: ignore[attr-defined]
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = ssl.TLSVersion.TLSv1_2
            context.load_cert_chain(
                certfile=str(material.server_certificate),
                keyfile=str(material.server_private_key),
            )
            server.socket = context.wrap_socket(server.socket, server_side=True)
            thread = threading.Thread(
                target=server.serve_forever,
                daemon=True,
                name="SAI semi mobile HTTPS dashboard",
            )
            thread.start()
            port = int(server.server_address[1])
            self.mobile_dashboard_https_server = server
            self.mobile_dashboard_https_thread = thread
            self.mobile_dashboard_ca_path = str(material.ca_certificate)
            self.mobile_dashboard_https_url = (
                f"https://{ip}:{port}/?t={urllib.parse.quote(self.mobile_dashboard_token)}"
            )
            return self.mobile_dashboard_https_url

    def show_mobile_dashboard_dialog(self) -> None:
        try:
            url = self.ensure_mobile_dashboard()
        except Exception as exc:
            QMessageBox.critical(self, "Подключить телефон", f"Не удалось запустить мобильный дэшборд:\n{exc}")
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Подключить телефон")
        dialog.setMinimumWidth(520)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        title = QLabel("Подключить телефон")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        note = QLabel("Отсканируй QR-код телефоном. На телефоне можно полностью управлять блоком «Сбор штрихкодов»: вводить и генерировать ШК, менять количество прихода и ценников, включать печать, пропускать позиции и запускать ввод в SIGMA. Телефон и компьютер должны быть в одной Wi‑Fi сети.")
        note.setObjectName("WorkbenchSubtitle")
        note.setWordWrap(True)
        layout.addWidget(note)

        qr_label = QLabel()
        qr_label.setAlignment(Qt.AlignCenter)
        pix = _make_qr_pixmap(url, scale=10, border=5, dark_color="#0f172a", light_color="#e2e8f0")
        if pix:
            qr_label.setPixmap(pix)
        else:
            qr_label.setText("QR-код не создался. Открой адрес ниже вручную.")
            qr_label.setObjectName("InlineStatus")
        layout.addWidget(qr_label)

        url_label = QLabel(url)
        url_label.setObjectName("WorkbenchFile")
        url_label.setWordWrap(True)
        url_label.setTextInteractionFlags(Qt.TextSelectableByMouse | Qt.TextSelectableByKeyboard)
        layout.addWidget(url_label)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        try:
            self.mobile_dashboard_status.setText("Мобильный дэшборд активен. QR-код можно открыть повторно этой же кнопкой.")
        except Exception:
            pass
        dialog.exec()

    def mobile_dashboard_state(self) -> Dict[str, Any]:
        """Return the complete mobile-control state. Runs in the Qt UI thread."""
        rows = self.rows or []
        snapshot = self.semi_service.progress(rows)
        total = snapshot.total
        missing = snapshot.missing
        done = snapshot.done
        percent = snapshot.percent
        idx = self.current_index
        row = rows[idx] if 0 <= idx < total else None
        has_current = row is not None
        if row:
            name = safe_str(row.get("name")) or "Без названия"
            article = safe_str(row.get("article") or row.get("vendor_code") or row.get("code")) or "—"
            qty_value: Any = row.get("qty") if row.get("qty") not in (None, "") else 1
            qty = safe_str(qty_value)
            unit = safe_str(row.get("unit")) or "штука"
            price = money(row.get("sale") or row.get("price") or 0) or "—"
            barcodes = ", ".join(self.row_barcodes(row)) or ""
            copies = self._current_qty_copies(row)
            position = f"Позиция {idx + 1} из {total} · осталось без ШК: {missing}"
        else:
            name = "Все ШК собраны" if total else "Файл ещё не выбран"
            article = "—"
            qty_value = None
            qty = "—"
            unit = ""
            price = "—"
            barcodes = ""
            copies = 0
            position = f"Готово {done}/{total}" if total else "Загрузи файл в SAI"
        cfg = _thermal_config()
        can_enter_sigma = bool(total and missing == 0)
        return {
            "ok": True,
            "version": APP_VERSION,
            "status": safe_str(self._dashboard_status_text or "ЖДУ ФАЙЛ"),
            "status_kind": safe_str(self._dashboard_status_kind or "idle"),
            "current_index": idx,
            "has_current": has_current,
            "can_previous": bool(total and (idx > 0 or idx < 0)),
            "can_enter_sigma": can_enter_sigma,
            "total": total,
            "done": done,
            "missing": missing,
            "percent": percent,
            "progress": f"{done}/{total} собрано · осталось {missing}" if total else "файл не выбран",
            "position": position,
            "name": name,
            "name_can_restore": bool(
                row
                and safe_str(row.get("name_before_operator_edit")).strip()
                and safe_str(row.get("name_before_operator_edit")).strip() != name
            ),
            "article": article,
            "qty": qty,
            "qty_value": qty_value,
            "unit": unit,
            "price": price,
            "barcodes": barcodes,
            "print_labels": bool(getattr(self, "print_thermal_check", None) and self.print_thermal_check.isChecked()),
            "label_copies": copies,
            "print_confirm_limit": max(1, int(cfg.get("max_without_confirm") or 20)),
            "scan_message": safe_str(getattr(self, "scan_status", None).text() if getattr(self, "scan_status", None) is not None else ""),
        }

    def start_table_unlock_hold(self) -> None:
        try:
            if self._table_edit_unlocked:
                return
            self.table_lock_btn.setText("🔓 Держи 5 сек…")
            self.table_edit_hint.setText("Держи кнопку до конца: редактирование откроется на одну правку.")
            if self.edit_unlock_timer:
                self.edit_unlock_timer.start()
        except Exception:
            pass

    def cancel_table_unlock_hold(self) -> None:
        try:
            if self.edit_unlock_timer and self.edit_unlock_timer.isActive():
                self.edit_unlock_timer.stop()
                self.table_lock_btn.setText("🔒 Редактирование")
                self.table_edit_hint.setText("Таблица защищена от случайных правок. Чтобы изменить кол-во, цену, ШК или название — удерживай замок 5 секунд.")
        except Exception:
            pass

    def unlock_table_editing(self) -> None:
        self._table_edit_unlocked = True
        try:
            self.table_lock_btn.setText("🔓 Можно править 1 ячейку")
            self.table_edit_hint.setText("Редактирование открыто. Измени одну ячейку — после ввода таблица снова закроется.")
            self.table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed | QAbstractItemView.SelectedClicked)
        except Exception:
            pass
        self.refresh_table()

    def lock_table_editing(self, message: str = "Таблица снова защищена от случайных правок.") -> None:
        self._table_edit_unlocked = False
        try:
            if self.edit_unlock_timer and self.edit_unlock_timer.isActive():
                self.edit_unlock_timer.stop()
            self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.table_lock_btn.setText("🔒 Редактирование")
            self.table_edit_hint.setText(message)
        except Exception:
            pass
        self.refresh_table()

    def _format_file_meta_date(self, value: Any) -> str:
        text = safe_str(value).strip()
        if not text:
            return ""
        # Common SAI XML form: YYYY-MM-DD.
        try:
            parsed = dt.date.fromisoformat(text[:10])
            return parsed.strftime("%d.%m.%Y")
        except Exception:
            pass
        # Already human-readable.
        if re.fullmatch(r"\d{1,2}[.]\d{1,2}[.]\d{2,4}", text):
            return text
        digits = re.sub(r"\D+", "", text)
        try:
            if len(digits) == 8 and digits[:4].isdigit() and 1900 <= int(digits[:4]) <= 2200:
                return dt.date(int(digits[:4]), int(digits[4:6]), int(digits[6:8])).strftime("%d.%m.%Y")
            if len(digits) == 8:
                return dt.date(int(digits[4:8]), int(digits[2:4]), int(digits[:2])).strftime("%d.%m.%Y")
            if len(digits) == 6:
                year = 2000 + int(digits[4:6])
                return dt.date(year, int(digits[2:4]), int(digits[:2])).strftime("%d.%m.%Y")
        except Exception:
            pass
        return text

    def _supplier_from_filename(self, path: Path) -> str:
        stem = re.sub(r"^SAI[ _-]*", "", path.stem, flags=re.IGNORECASE)
        stem = re.sub(r"[ _-]*(?:\d{6}|\d{8})(?:[ _-].*)?$", "", stem)
        stem = re.sub(r"[_]+", " ", stem).strip(" -_")
        generic = {"", "полуавто", "полуавтоматический", "ручной", "привоз", "свободный"}
        return "" if stem.lower() in generic else stem

    def read_sai_file_summary(self, path: Path) -> tuple[str, str]:
        """Read supplier/date for the human-facing file card.

        XML metadata is authoritative. Excel is inspected conservatively, then
        filename hints are used as a final fallback. No technical path is shown.
        """
        supplier = ""
        date_text = ""
        try:
            if path.suffix.lower() == ".sai":
                summary = sai_package.read_summary(path)
                supplier = safe_str(summary.get("supplier")).strip()
                date_text = safe_str(summary.get("date")).strip()
            elif path.suffix.lower() == ".xml":
                root = ET.parse(str(path)).getroot()
                meta = root.find("meta")
                if meta is not None:
                    supplier = safe_str(meta.findtext("supplier")).strip()
                    date_text = safe_str(meta.findtext("date")).strip()
            elif path.suffix.lower() in (".xlsx", ".xlsm") and globals().get("load_workbook") is not None:
                wb = globals()["load_workbook"](path, read_only=True, data_only=True)
                try:
                    ws = wb[wb.sheetnames[0]]
                    for row in ws.iter_rows(min_row=1, max_row=min(20, ws.max_row), max_col=min(12, ws.max_column), values_only=True):
                        values = [safe_str(v).strip() for v in row]
                        for idx, value in enumerate(values):
                            key = re.sub(r"[^А-ЯA-Z0-9]+", " ", value.upper()).strip()
                            nxt = values[idx + 1].strip() if idx + 1 < len(values) else ""
                            if not supplier and key.startswith("ПОСТАВЩИК") and nxt:
                                supplier = nxt
                            if not date_text and key in {"ДАТА", "ДАТА НАКЛАДНОЙ", "ДАТА ДОКУМЕНТА"} and nxt:
                                date_text = nxt
                finally:
                    wb.close()
        except Exception:
            pass
        if not supplier:
            supplier = self._supplier_from_filename(path)
        if not date_text:
            date_text = infer_date_from_sai_file(path)
        return supplier or "Не указан", self._format_file_meta_date(date_text) or "Не указана"

    def update_file_summary(self, path: Optional[Path], saved: bool = False) -> None:
        status = getattr(self, "file_status_label", None)
        if path is None:
            if status is not None:
                status.setText("Файл не найден")
                status.setObjectName("SemiFileStatusIdle")
            self.file_supplier_value.setText("—")
            self.file_date_value.setText("—")
            self.file_name_value.setText("—")
            self.file_name_value.setToolTip("")
        else:
            path = Path(path)
            supplier, date_text = self.read_sai_file_summary(path)
            if status is not None:
                status.setText("Файл найден")
                status.setObjectName("SemiFileStatusOk")
                status.setToolTip("Изменения сохраняются в SAI-файл автоматически" if saved else "SAI-файл готов к работе")
            self.file_supplier_value.setText(supplier)
            self.file_date_value.setText(date_text)
            self.file_name_value.setText(path.name)
            self.file_name_value.setToolTip(str(path))
        if status is not None:
            try:
                status.style().unpolish(status)
                status.style().polish(status)
            except Exception:
                pass

    def choose_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Выберите SAI-файл для сбора ШК", str(Path.home() / "Desktop"), "SAI Package (*.sai);;Все SAI-файлы (*.sai *.xml *.xlsx *.xlsm);;Старый SAI XML (*.xml);;Excel (*.xlsx *.xlsm)")
        if path:
            self.set_sai_file(Path(path))

    def auto_pick_latest(self) -> None:
        path = find_latest_sai_file()
        if path:
            self.set_sai_file(path)
        else:
            QMessageBox.information(self, "Полуавтоматический привоз", "Свежий SAI-файл не найден на рабочем столе или в загрузках.")

    def set_sai_file(self, path: Path) -> None:
        if load_sai_rows is None:
            QMessageBox.critical(self, "Полуавтоматический привоз", "Не подключилась логика чтения SAI-файлов.")
            return
        path = Path(path)
        if path.suffix.lower() in (".xlsx", ".xlsm"):
            package = path.with_suffix(".sai")
            xml = path.with_suffix(".xml")
            if package.exists() and package.is_file():
                path = package
            elif xml.exists() and xml.is_file():
                path = xml
        try:
            sheet, rows = load_sai_rows(str(path))
        except Exception as exc:
            QMessageBox.critical(self, "Полуавтоматический привоз", f"Не удалось прочитать файл:\n{exc}")
            return
        self.sai_path = path
        sai_receipt_drafts.update_by_package(path, stage="semi_auto")
        # The semi-auto editor owns the selected SAI file and overwrites it
        # after every accepted/generated barcode. No duplicate *_с_ШК file.
        self.output_path = path
        self.sheet_name = sheet
        self.rows = rows
        self.retry_save_btn.setVisible(False)
        self.enter_sigma_btn.setVisible(False)
        self.enter_sigma_btn.setEnabled(False)
        self.update_file_summary(path, saved=False)
        self._table_scroll_to_add_pending = True
        self.set_scan_state("ФАЙЛ ЗАГРУЖЕН", "ready")
        self.refresh_table()
        self.refresh_mobile_dashboard_qr()
        self.goto_next_missing(start=-1, wrap=True)
    def eventFilter(self, obj, event):  # noqa: N802 - Qt override name
        try:
            if obj is getattr(self, "current_label_qty_edit", None) and event.type() == QEvent.MouseButtonPress:
                self.select_current_label_qty_auto()
            if obj is getattr(self, "barcode_edit", None) and event.type() == QEvent.KeyPress:
                if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Tab):
                    if self.scan_timer:
                        self.scan_timer.stop()
                    self.scan_entered(force=True)
                    return True
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def schedule_scan_autocommit(self, text: str) -> None:
        text = safe_str(text)
        if not text:
            self._last_scan_text = ""
            return
        if self.scan_timer:
            self.scan_timer.start()

    def scan_autocommit_tick(self) -> None:
        text = safe_str(self.barcode_edit.text()).strip()
        if not text or text == self._last_scan_text:
            return
        # Автопринятие только для обычных цифровых ШК стандартной длины.
        # Всё нестандартное можно принять явной кнопкой/Enter, чтобы защититься от мусора.
        codes, warnings, error, wait_more = self.parse_scan_barcodes(text, force=False)
        if wait_more:
            return
        if error:
            self.mark_scan_error(error)
            self._last_scan_text = text
            return
        if codes:
            self.scan_entered(force=False)

    def valid_barcodes_from_text(self, text: str) -> List[str]:
        return list(semi_valid_barcodes_from_text(text))

    def parse_scan_barcodes(self, text: str, force: bool = False) -> tuple[List[str], List[str], str, bool]:
        return self.semi_service.parse_scan(text, force=force).legacy_tuple()

    def semi_print_thermal_changed(self, *_args) -> None:
        try:
            save_private_config_patch({"semi_auto_print_thermal_labels": bool(self.print_thermal_check.isChecked())})
            self.sync_current_qty_editor()
            self.sync_current_label_qty_editor()
        except Exception:
            pass

    def update_quick_thermal_controls(self) -> None:
        size = str(self.quick_thermal_size_combo.currentData() or "58x40")
        is_tiny = size == "30x20"
        datamatrix = bool(self.thermal_code_mode_switch.isChecked())
        split = is_tiny and datamatrix and bool(self.thermal_split_switch.isChecked())
        self.thermal_code_mode_wrap.setVisible(True)
        self.thermal_split_wrap.setVisible(False)
        if getattr(self, "barcode_mode_btn", None) is not None:
            self.barcode_mode_btn.setChecked(not datamatrix)
        if getattr(self, "datamatrix_mode_btn", None) is not None:
            self.datamatrix_mode_btn.setChecked(datamatrix)
        self.label_qty_label.setText("Количество")
        self.current_label_qty_edit.setToolTip(
            "Количество товаров: SAI напечатает по две одинаковые части на одной этикетке."
            if split else
            "Отдельное количество термоэтикеток. Например, 30 товаров в 3 пачках = 3 ценника."
        )

    def sync_quick_thermal_controls_from_config(self) -> None:
        cfg = load_private_config()
        size = str(cfg.get("thermal_label_size") or "58x40").lower().replace("×", "x").replace(" ", "")
        index = self.quick_thermal_size_combo.findData(size)
        self.quick_thermal_size_combo.blockSignals(True)
        self.quick_thermal_size_combo.setCurrentIndex(index if index >= 0 else 0)
        self.quick_thermal_size_combo.blockSignals(False)
        self.thermal_code_mode_switch.blockSignals(True)
        self.thermal_code_mode_switch.setChecked(str(cfg.get("thermal_label_code_mode") or "barcode").lower() == "datamatrix")
        self.thermal_code_mode_switch.blockSignals(False)
        self.thermal_split_switch.blockSignals(True)
        self.thermal_split_switch.setChecked(bool(cfg.get("thermal_label_datamatrix_split", False)))
        self.thermal_split_switch.blockSignals(False)
        self.update_quick_thermal_controls()

    def semi_thermal_size_changed(self, *_args) -> None:
        size = str(self.quick_thermal_size_combo.currentData() or "58x40")
        save_private_config_patch({"thermal_label_size": size})
        self.update_quick_thermal_controls()
        settings = getattr(self.parent_page, "settings_page", None)
        combo = getattr(settings, "thermal_size_combo", None)
        if combo is not None:
            index = combo.findData(size)
            combo.blockSignals(True)
            combo.setCurrentIndex(index if index >= 0 else 0)
            combo.blockSignals(False)
            settings.update_thermal_preview()
            settings.update_thermal_settings_summary()

    def semi_thermal_code_mode_changed(self, *_args) -> None:
        mode = "datamatrix" if self.thermal_code_mode_switch.isChecked() else "barcode"
        save_private_config_patch({"thermal_label_code_mode": mode})
        self.update_quick_thermal_controls()
        settings = getattr(self.parent_page, "settings_page", None)
        if settings is not None:
            settings.update_thermal_preview()

    def set_semi_thermal_code_mode(self, mode: str) -> None:
        """Switch only the code type here; deeper label layout lives in Settings."""
        datamatrix = str(mode).strip().lower() == "datamatrix"
        self.thermal_code_mode_switch.blockSignals(True)
        self.thermal_code_mode_switch.setChecked(datamatrix)
        self.thermal_code_mode_switch.blockSignals(False)
        save_private_config_patch({"thermal_label_code_mode": "datamatrix" if datamatrix else "barcode"})
        self.update_quick_thermal_controls()
        settings = getattr(self.parent_page, "settings_page", None)
        if settings is not None:
            settings.update_thermal_preview()

    def semi_thermal_split_changed(self, *_args) -> None:
        save_private_config_patch({"thermal_label_datamatrix_split": bool(self.thermal_split_switch.isChecked())})
        self.update_quick_thermal_controls()
        settings = getattr(self.parent_page, "settings_page", None)
        if settings is not None:
            settings.update_thermal_preview()

    def mark_scan_error(self, message: str) -> None:
        self.set_scan_state("ОШИБКА СКАНА", "error")
        self.scan_status.setText(message)
        try:
            self.barcode_edit.setStyleSheet("QLineEdit#WorkbenchInput { border: 2px solid #ef4444; }")
        except Exception:
            pass
        self.beep_error()

    def clear_scan_visual_state(self) -> None:
        try:
            self.barcode_edit.setStyleSheet("")
        except Exception:
            pass

    def beep_success(self) -> None:
        try:
            if sys.platform.startswith("win"):
                import winsound
                winsound.Beep(1568, 75)
            else:
                QApplication.beep()
        except Exception:
            try:
                QApplication.beep()
            except Exception:
                pass

    def beep_error(self) -> None:
        try:
            if sys.platform.startswith("win"):
                import winsound
                winsound.Beep(440, 120)
            else:
                QApplication.beep()
        except Exception:
            try:
                QApplication.beep()
            except Exception:
                pass

    def find_barcode_owner(self, barcode: str, exclude_current: bool = True) -> Optional[int]:
        return semi_find_barcode_owner(
            self.rows or [], barcode, current_index=self.current_index, exclude_current=exclude_current,
        )

    def row_barcodes(self, row: Dict[str, Any]) -> List[str]:
        return list(semi_row_barcodes(row))

    def semi_qty_value(self, row: Optional[Dict[str, Any]]) -> float:
        return semi_quantity_value(row)

    def semi_is_zero_qty(self, row: Optional[Dict[str, Any]]) -> bool:
        return semi_is_zero_quantity(row)

    def missing_indices(self) -> List[int]:
        return list(semi_missing_barcode_indices(self.rows or []))

    def open_semi_product_card(self, row_index: int, new_item: bool = False) -> None:
        """Edit and optionally reprint any product from the semi-auto table."""
        if new_item:
            row_index = len(self.rows or [])
            original = {
                "excel_row": 0,
                "name": "",
                "article": "",
                "vendor_code": "",
                "code": "",
                "barcodes": [],
                "barcode_cell": "",
                "qty": "1",
                "unit": "штука",
                "buy": 0.0,
                "purchase_price": 0.0,
                "sale": 0.0,
                "price": 0.0,
                "category": "",
                "comment": "Добавлено вручную в полуавтоматическом привозе",
                "semi_manual_row": True,
            }
        else:
            if not (0 <= row_index < len(self.rows or [])):
                return
            original = dict(self.rows[row_index])
        dialog = QDialog(self)
        dialog.setWindowTitle("Добавить товар" if new_item else "Карточка товара")
        dialog.setMinimumWidth(760)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(12)

        title = QLabel(
            "Новый товар"
            if new_item
            else f"Карточка товара · позиция №{row_index + 1}"
        )
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)

        name_edit = QLineEdit(safe_str(original.get("name")))
        name_edit.setObjectName("WorkbenchInput")
        article_edit = QLineEdit(safe_str(original.get("article") or original.get("vendor_code") or original.get("code")))
        article_edit.setObjectName("WorkbenchInput")
        barcode_edit = BarcodeCopyLineEdit(", ".join(self.row_barcodes(original)))
        barcode_edit.setObjectName("WorkbenchInput")
        barcode_edit.setPlaceholderText("Можно оставить пустым и собрать ШК позже")
        barcode_edit.setToolTip("Двойной клик по ШК копирует его в буфер обмена")

        barcode_row = QHBoxLayout()
        barcode_row.addWidget(barcode_edit, 1)
        copy_barcode_btn = QPushButton("Копировать ШК")
        copy_barcode_btn.setObjectName("SoftButton")
        barcode_row.addWidget(copy_barcode_btn)
        generate_btn = QPushButton("Товар без ШК ⇒ Создать ШК")
        generate_btn.setObjectName("SoftButton")
        barcode_row.addWidget(generate_btn)
        barcode_wrap = QWidget()
        barcode_wrap.setLayout(barcode_row)

        unit_combo = NoWheelComboBox()
        unit_combo.setObjectName("WorkbenchCombo")
        units = ["штука", "шт.", "м", "кг", "г", "пара", "упаковка", "комплект"]
        current_unit = safe_str(original.get("unit")) or "штука"
        if current_unit not in units:
            units.append(current_unit)
        unit_combo.addItems(units)
        unit_combo.setCurrentText(current_unit)

        qty_edit = QLineEdit(safe_str(original.get("qty") if original.get("qty") not in (None, "") else 1))
        qty_edit.setObjectName("WorkbenchInput")
        purchase_value = original.get("buy") if original.get("buy") not in (None, "") else original.get("purchase_price")
        buy_edit = QLineEdit(_free_price_text(purchase_value or 0))
        buy_edit.setObjectName("WorkbenchInput")
        sale_value = original.get("sale") if original.get("sale") not in (None, "") else original.get("price")
        sale_edit = QLineEdit(_free_price_text(sale_value or 0))
        sale_edit.setObjectName("WorkbenchInput")
        category_edit = QLineEdit(safe_str(original.get("category")))
        category_edit.setObjectName("WorkbenchInput")
        comment_edit = QLineEdit(safe_str(original.get("comment")))
        comment_edit.setObjectName("WorkbenchInput")

        def make_edit_group(group_title: str) -> tuple[QFrame, QFormLayout]:
            frame = QFrame()
            frame.setObjectName("SemiEditGroup")
            group_layout = QVBoxLayout(frame)
            group_layout.setContentsMargins(14, 12, 14, 14)
            group_layout.setSpacing(8)
            heading = QLabel(group_title)
            heading.setObjectName("SemiEditGroupTitle")
            group_layout.addWidget(heading)
            group_form = QFormLayout()
            group_form.setHorizontalSpacing(12)
            group_form.setVerticalSpacing(9)
            group_layout.addLayout(group_form)
            return frame, group_form

        details_row = QHBoxLayout()
        details_row.setSpacing(10)
        identity_group, identity_form = make_edit_group("Основные данные")
        identity_form.addRow("Наименование", name_edit)
        identity_form.addRow("Артикул", article_edit)
        identity_form.addRow("Единица", unit_combo)
        identity_form.addRow("Категория", category_edit)
        accounting_group, accounting_form = make_edit_group("Учёт и цены")
        accounting_form.addRow("Количество", qty_edit)
        accounting_form.addRow("Закупочная цена", buy_edit)
        accounting_form.addRow("Цена продажи", sale_edit)
        accounting_form.addRow("Комментарий", comment_edit)
        details_row.addWidget(identity_group, 1)
        details_row.addWidget(accounting_group, 1)
        layout.addLayout(details_row)

        barcode_group, barcode_form = make_edit_group("Штрихкоды")
        barcode_form.addRow("ШК", barcode_wrap)
        layout.addWidget(barcode_group)

        print_module = QFrame()
        print_module.setObjectName("SemiPrintModule")
        print_module_layout = QVBoxLayout(print_module)
        print_module_layout.setContentsMargins(14, 12, 14, 14)
        print_module_layout.setSpacing(5)
        print_title = QLabel("Печать термоэтикеток")
        print_title.setObjectName("SemiEditGroupTitle")
        print_hint = QLabel("Укажи количество. Этикетки напечатаются сразу после нажатия «Печатать и сохранить».")
        print_hint.setObjectName("StatsSubtitle")
        print_hint.setWordWrap(True)
        print_module_layout.addWidget(print_title)
        print_module_layout.addWidget(print_hint)
        print_row = QHBoxLayout()
        copies_minus = QPushButton("−")
        copies_minus.setObjectName("SoftButton")
        copies_minus.setFixedSize(38, 38)
        copies_edit = QLineEdit(str(self._current_qty_copies(original)))
        copies_edit.setObjectName("WorkbenchInput")
        copies_edit.setFixedWidth(74)
        copies_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        copies_plus = QPushButton("+")
        copies_plus.setObjectName("SoftButton")
        copies_plus.setFixedSize(38, 38)
        print_save_btn = QPushButton("Печатать и сохранить")
        print_save_btn.setObjectName("WorkbenchPrimaryButton")
        print_row.addWidget(QLabel("Термоэтикеток"))
        print_row.addWidget(copies_minus)
        print_row.addWidget(copies_edit)
        print_row.addWidget(copies_plus)
        print_row.addStretch(1)
        print_module_layout.addLayout(print_row)
        layout.addWidget(print_module)

        actions = QHBoxLayout()
        cancel_btn = QPushButton("Отмена")
        cancel_btn.setObjectName("SoftButton")
        save_btn = QPushButton("Сохранить")
        save_btn.setObjectName("SoftButton")
        if new_item:
            save_btn.setText("Добавить товар")
            print_save_btn.setText("Добавить и напечатать")
        actions.addWidget(cancel_btn)
        actions.addStretch(1)
        actions.addWidget(save_btn)
        actions.addWidget(print_save_btn)
        layout.addLayout(actions)

        def adjust_copies(delta: int) -> None:
            try:
                value = max(1, int(round(float(copies_edit.text().replace(",", ".")))) + delta)
            except Exception:
                value = 1
            copies_edit.setText(str(value))

        def generate_for_card() -> None:
            if self.valid_barcodes_from_text(barcode_edit.text()):
                QMessageBox.information(dialog, "Создание ШК", "У товара уже есть ШК.")
                return
            code = self.make_internal_barcode()
            if not code:
                QMessageBox.warning(dialog, "Создание ШК", "Не удалось подобрать свободный внутренний ШК.")
                return
            barcode_edit.setText(code)

        def copy_card_barcodes() -> None:
            codes = self.valid_barcodes_from_text(barcode_edit.text())
            if not codes:
                QMessageBox.information(dialog, "Копировать ШК", "В карточке пока нет ШК.")
                return
            QApplication.clipboard().setText(", ".join(codes))
            copy_barcode_btn.setText("Скопировано")
            QTimer.singleShot(1200, lambda: copy_barcode_btn.setText("Копировать ШК"))

        def card_mapping() -> Optional[Dict[str, Any]]:
            name = safe_str(name_edit.text()).strip()
            if not name:
                QMessageBox.information(dialog, "Карточка товара", "Нужно указать наименование.")
                name_edit.setFocus()
                return None
            try:
                updated = self.semi_service.with_quantity(original, qty_edit.text())
            except ValueError as exc:
                QMessageBox.information(dialog, "Карточка товара", str(exc))
                qty_edit.setFocus()
                return None
            buy = round(self._parse_table_number(buy_edit.text(), 0.0), 2)
            sale = round(self._parse_table_number(sale_edit.text(), 0.0), 2)
            if buy < 0:
                QMessageBox.information(dialog, "Карточка товара", "Закупочная цена не может быть отрицательной.")
                buy_edit.setFocus()
                return None
            if sale <= 0:
                QMessageBox.information(dialog, "Карточка товара", "Цена продажи должна быть больше нуля.")
                sale_edit.setFocus()
                return None

            barcode_text = safe_str(barcode_edit.text()).strip()
            codes: List[str] = []
            warnings: List[str] = []
            if barcode_text:
                codes, warnings, error, _wait = self.parse_scan_barcodes(barcode_text, force=True)
                if error:
                    QMessageBox.warning(dialog, "Карточка товара", error)
                    barcode_edit.setFocus()
                    return None
                for barcode in codes:
                    owner = semi_find_barcode_owner(
                        self.rows or [], barcode, current_index=row_index, exclude_current=True,
                    )
                    if owner is not None:
                        QMessageBox.warning(
                            dialog,
                            "Карточка товара",
                            f"ШК {barcode} уже указан у позиции №{owner + 1}: "
                            f"{safe_str((self.rows[owner] or {}).get('name'))}",
                        )
                        return None
            updated.update({
                "name": name,
                "article": safe_str(article_edit.text()).strip(),
                "unit": normalize_unit(unit_combo.currentText() or "штука") or "штука",
                "buy": buy,
                "purchase_price": buy,
                "sale": sale,
                "price": sale,
                "category": safe_str(category_edit.text()).strip(),
                "comment": safe_str(comment_edit.text()).strip(),
                "barcodes": [],
                "barcode_cell": "",
            })
            original_sale = self._parse_table_number(
                original.get("sale", original.get("price")), 0.0,
            )
            if abs(original_sale - sale) >= 0.005:
                updated = semi_approve_operator_sale_price(
                    updated, sale, source="manual_card",
                )
            if codes:
                updated = self.semi_service.merge_barcodes(updated, codes, warnings=warnings)
            else:
                updated.pop("barcode_warning", None)
            try:
                updated = self.semi_service.with_label_quantity(updated, copies_edit.text())
            except ValueError as exc:
                QMessageBox.information(dialog, "Карточка товара", str(exc))
                copies_edit.setFocus()
                return None
            return updated

        created = False

        def save_card() -> Optional[Dict[str, Any]]:
            nonlocal created, row_index
            updated = card_mapping()
            if updated is None:
                return None
            if new_item and not created:
                self.rows.append(updated)
                row_index = len(self.rows) - 1
                created = True
                self._table_scroll_to_add_pending = True
            else:
                self.rows[row_index] = updated
            try:
                self.save_updated_sai_file(show_message=False)
                self.retry_save_btn.setVisible(False)
                self.scan_status.setText(f"Позиция №{row_index + 1} изменена и сохранена.")
            except Exception as exc:
                self.retry_save_btn.setVisible(True)
                self.scan_status.setText(
                    f"Позиция №{row_index + 1} изменена в памяти, но файл не сохранился: {exc}"
                )
                QMessageBox.warning(dialog, "Карточка товара", f"Не удалось сохранить SAI-файл:\n{exc}")
                return None
            self.refresh_table()
            self.refresh_progress()
            self.set_current_index(row_index)
            return updated

        def save_and_close() -> None:
            if save_card() is not None:
                dialog.accept()

        def print_and_save() -> None:
            updated = save_card()
            if updated is None:
                return
            bcs = self.row_barcodes(updated)
            if not bcs:
                QMessageBox.information(dialog, "Печать термоэтикеток", "Изменения сохранены. Для печати сначала введи или создай ШК.")
                return
            try:
                copies = self.print_thermal_labels_for_row(updated, preferred_barcode=bcs[0])
            except Exception as exc:
                QMessageBox.warning(
                    dialog,
                    "Печать термоэтикеток",
                    f"Изменения сохранены, но термоэтикетки не напечатались:\n{exc}",
                )
                return
            self.scan_status.setText(
                f"Позиция №{row_index + 1} сохранена. Термоценники отправлены на печать: {copies} шт."
            )
            dialog.accept()

        copies_minus.clicked.connect(lambda: adjust_copies(-1))
        copies_plus.clicked.connect(lambda: adjust_copies(1))
        generate_btn.clicked.connect(generate_for_card)
        copy_barcode_btn.clicked.connect(copy_card_barcodes)
        cancel_btn.clicked.connect(dialog.reject)
        save_btn.clicked.connect(save_and_close)
        print_save_btn.clicked.connect(print_and_save)
        dialog.exec()

    def refresh_table(self) -> None:
        table = getattr(self, "table", None)
        if table is None:
            return
        old_scroll = table.verticalScrollBar().value()
        old_row = table.currentRow()
        old_col = table.currentColumn()
        scroll_to_add = False
        self._table_scroll_to_add_pending = False
        self._table_refreshing = True
        try:
            table.blockSignals(True)
            table.clearSpans()
            data_rows = len(self.rows or [])
            table.setRowCount(data_rows)
            for i, row in enumerate(self.rows or []):
                bcs = self.row_barcodes(row)
                warning = safe_str(row.get("barcode_warning"))
                zero_qty = self.semi_is_zero_qty(row)
                status = "НЕДОВОЗ 0" if zero_qty else ("⚠ ШК" if (bcs and warning) else "OK" if bcs else "НУЖЕН ШК")
                vals = [
                    str(i + 1),
                    safe_str(row.get("name")),
                    safe_str(row.get("article") or row.get("vendor_code") or row.get("code")),
                    ", ".join(bcs),
                    safe_str(row.get("qty")),
                    safe_str(row.get("unit")) or "штука",
                    money(row.get("sale") or row.get("price") or 0),
                    status,
                ]
                for c, val in enumerate(vals):
                    item = QTableWidgetItem(val)
                    if c in (0, 4, 5, 6, 7):
                        item.setTextAlignment(Qt.AlignCenter)
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                    if zero_qty:
                        item.setBackground(QColor("#e5e7eb"))
                        item.setToolTip("Фактическое количество 0: полный недовоз. Позиция не попадёт в SIGMA, НДП и ценники.")
                    elif not bcs:
                        item.setBackground(QColor("#ffe7d6"))
                        if c == 7:
                            item.setBackground(QColor("#ffd6bd"))
                    elif warning:
                        item.setBackground(QColor("#fff3bf"))
                        item.setToolTip(warning)
                    elif i == self.current_index:
                        item.setBackground(QColor("#eaf7ff"))
                    table.setItem(i, c, item)
                edit_btn = TableEditButton(tooltip="Открыть карточку товара: изменить данные или напечатать термоэтикетки")
                edit_btn.clicked.connect(lambda _checked=False, row_index=i: self.open_semi_product_card(row_index))
                table.setCellWidget(i, 8, edit_btn)

            table.resizeRowsToContents()
            table.setColumnWidth(0, 48)
            table.setColumnWidth(2, 110)
            table.setColumnWidth(3, 170)
            table.setColumnWidth(4, 76)
            table.setColumnWidth(5, 70)
            table.setColumnWidth(6, 90)
            table.setColumnWidth(7, 110)
            table.setColumnWidth(8, 48)
        finally:
            try:
                table.blockSignals(False)
            except Exception:
                pass
            self._table_refreshing = False
        def restore_table_view() -> None:
            try:
                if scroll_to_add:
                    table.scrollToBottom()
                    return
                bar = table.verticalScrollBar()
                bar.setValue(max(bar.minimum(), min(old_scroll, bar.maximum())))
                if 0 <= old_row < table.rowCount():
                    table.setCurrentCell(old_row, max(0, old_col))
            except Exception:
                pass
        QTimer.singleShot(0, restore_table_view)

    def _parse_table_number(self, text: str, default: float = 0.0) -> float:
        value = self.semi_service.quantity_value({"qty": text})
        if not safe_str(text).strip():
            return default
        return value

    def _format_qty_value(self, value: Any) -> Any:
        return self.semi_service.formatted_number(value)

    def table_item_changed(self, item: QTableWidgetItem) -> None:
        if self._table_refreshing or self._table_relocking or not self._table_edit_unlocked:
            return
        if item is None:
            return
        row_idx = item.row()
        col = item.column()
        if not (0 <= row_idx < len(self.rows or [])):
            return
        if col not in (1, 2, 3, 4, 5, 6):
            self.lock_table_editing()
            return
        original = self.rows[row_idx]
        updated = dict(original)
        value_text = safe_str(item.text()).strip()
        try:
            if col == 1:
                updated["name"] = value_text
            elif col == 2:
                updated["article"] = value_text
            elif col == 3:
                codes, warnings, error, _wait = self.parse_scan_barcodes(value_text, force=True)
                if error:
                    QMessageBox.warning(self, "Редактирование", error)
                    return
                for barcode in codes:
                    owner = self.find_barcode_owner(barcode, exclude_current=False)
                    if owner is not None and owner != row_idx:
                        QMessageBox.warning(
                            self,
                            "Редактирование",
                            f"Этот ШК уже указан у позиции №{owner + 1}: {safe_str((self.rows[owner] or {}).get('name'))}",
                        )
                        return
                updated = self.semi_service.merge_barcodes(
                    {**updated, "barcodes": [], "barcode_cell": ""},
                    codes,
                    warnings=warnings,
                )
            elif col == 4:
                try:
                    updated = self.semi_service.with_quantity(updated, value_text)
                except ValueError as exc:
                    QMessageBox.warning(self, "Редактирование", str(exc))
                    return
            elif col == 5:
                updated["unit"] = normalize_unit(value_text or "штука") or "штука"
            elif col == 6:
                price = round(self._parse_table_number(value_text, 0.0), 2)
                if price < 0:
                    QMessageBox.warning(self, "Редактирование", "Цена не может быть отрицательной.")
                    return
                updated["sale"] = price
                updated["price"] = price
            self.rows[row_idx] = updated
            if col == 4 and row_idx == self.current_index:
                self.sync_current_qty_editor()
            self.set_current_index(row_idx)
            try:
                self.save_updated_sai_file(show_message=False)
                self.scan_status.setText(f"Позиция №{row_idx + 1} обновлена и сохранена. Таблица снова защищена.")
            except Exception as exc:
                self.scan_status.setText(f"Позиция №{row_idx + 1} обновлена, но автосохранение не удалось: {exc}")
        finally:
            self._table_relocking = True
            try:
                self.lock_table_editing("Правка сохранена. Таблица снова защищена от случайных изменений.")
            finally:
                self._table_relocking = False

    def _receipt_qty_int(self, row: Optional[Dict[str, Any]] = None) -> int:
        data = row if row is not None else (self.rows[self.current_index] if 0 <= self.current_index < len(self.rows) else {})
        return semi_receipt_quantity_int(data)

    def _label_qty_is_manual(self, row: Optional[Dict[str, Any]] = None) -> bool:
        data = row if row is not None else (self.rows[self.current_index] if 0 <= self.current_index < len(self.rows) else {})
        return semi_label_quantity_is_manual(data)

    def _current_qty_copies(self, row: Optional[Dict[str, Any]] = None) -> int:
        data = row if row is not None else (self.rows[self.current_index] if 0 <= self.current_index < len(self.rows) else {})
        return semi_label_copies(data)

    def sync_current_label_qty_editor(self) -> None:
        """Synchronize the separate thermal label quantity editor."""
        edit = getattr(self, "current_label_qty_edit", None)
        if edit is None:
            return
        active = bool(0 <= self.current_index < len(self.rows or []))
        try:
            edit.blockSignals(True)
            if active:
                row = self.rows[self.current_index]
                receipt_qty = self._receipt_qty_int(row)
                copies = self._current_qty_copies(row)
                manual = self._label_qty_is_manual(row)
                enabled = receipt_qty > 0
                edit.setProperty("autoQuantity", not manual)
                edit.style().unpolish(edit)
                edit.style().polish(edit)
                edit.setText(str(copies))
                edit.setEnabled(enabled)
                if getattr(self, "label_qty_minus_btn", None) is not None:
                    self.label_qty_minus_btn.setEnabled(enabled)
                if getattr(self, "label_qty_plus_btn", None) is not None:
                    self.label_qty_plus_btn.setEnabled(enabled)
                for preset_name in ("label_qty_one_btn", "label_qty_two_btn"):
                    preset_button = getattr(self, preset_name, None)
                    if preset_button is not None:
                        preset_button.setEnabled(enabled)
                selected_preset = self.label_qty_one_btn if manual and copies == 1 else self.label_qty_two_btn if manual and copies == 2 else None
                self.label_qty_group.setExclusive(False)
                self.label_qty_one_btn.setChecked(selected_preset is self.label_qty_one_btn)
                self.label_qty_two_btn.setChecked(selected_preset is self.label_qty_two_btn)
                self.label_qty_group.setExclusive(True)
                if getattr(self, "label_qty_hint", None) is not None:
                    if receipt_qty <= 0:
                        self.label_qty_hint.setText("Недовоз: ценники не печатаются")
                    elif manual:
                        self.label_qty_hint.setText(f"Будет ценников: {copies} шт. · отдельно от прихода")
                    else:
                        self.label_qty_hint.setText(f"Будет ценников: {copies} шт. · по кол-ву прихода")
            else:
                edit.clear()
                edit.setEnabled(False)
                if getattr(self, "label_qty_minus_btn", None) is not None:
                    self.label_qty_minus_btn.setEnabled(False)
                if getattr(self, "label_qty_plus_btn", None) is not None:
                    self.label_qty_plus_btn.setEnabled(False)
                for preset_name in ("label_qty_one_btn", "label_qty_two_btn"):
                    preset_button = getattr(self, preset_name, None)
                    if preset_button is not None:
                        preset_button.setEnabled(False)
                self.label_qty_group.setExclusive(False)
                self.label_qty_one_btn.setChecked(False)
                self.label_qty_two_btn.setChecked(False)
                self.label_qty_group.setExclusive(True)
                if getattr(self, "label_qty_hint", None) is not None:
                    self.label_qty_hint.setText("Ценники: —")
        finally:
            try:
                edit.blockSignals(False)
            except Exception:
                pass

    def sync_current_qty_editor(self) -> None:
        """Synchronize the quick receipt quantity editor with the current row."""
        edit = getattr(self, "current_qty_edit", None)
        if edit is None:
            self.sync_current_sale_editor()
            self.sync_current_label_qty_editor()
            return
        active = bool(0 <= self.current_index < len(self.rows or []))
        try:
            edit.blockSignals(True)
            if active:
                row = self.rows[self.current_index]
                edit.setText(safe_str(row.get("qty") if row.get("qty") not in (None, "") else 1))
                edit.setEnabled(True)
                if getattr(self, "qty_minus_btn", None) is not None:
                    self.qty_minus_btn.setEnabled(True)
                if getattr(self, "qty_plus_btn", None) is not None:
                    self.qty_plus_btn.setEnabled(True)
                if getattr(self, "qty_print_hint", None) is not None:
                    if self._receipt_qty_int(row) <= 0:
                        self.qty_print_hint.setText("Недовоз: в приход не пойдёт")
                    else:
                        self.qty_print_hint.setText(f"В приход: {safe_str(row.get('qty')) or '1'} {safe_str(row.get('unit')) or 'шт.'}")
            else:
                edit.clear()
                edit.setEnabled(False)
                if getattr(self, "qty_minus_btn", None) is not None:
                    self.qty_minus_btn.setEnabled(False)
                if getattr(self, "qty_plus_btn", None) is not None:
                    self.qty_plus_btn.setEnabled(False)
                if getattr(self, "qty_print_hint", None) is not None:
                    self.qty_print_hint.setText("В приход: —")
        finally:
            try:
                edit.blockSignals(False)
            except Exception:
                pass
        self.sync_current_sale_editor()
        self.sync_current_label_qty_editor()

    def sync_current_sale_editor(self) -> None:
        """Show the selected row's retail price in the quick editor."""
        edit = getattr(self, "current_sale_edit", None)
        if edit is None:
            return
        active = bool(0 <= self.current_index < len(self.rows or []))
        try:
            edit.blockSignals(True)
            if active:
                row = self.rows[self.current_index]
                price = row.get("sale") if row.get("sale") not in (None, "") else row.get("price")
                edit.setText(_free_price_text(price or 0))
                edit.setEnabled(True)
                if getattr(self, "sale_minus_btn", None) is not None:
                    self.sale_minus_btn.setEnabled(True)
                if getattr(self, "sale_plus_btn", None) is not None:
                    self.sale_plus_btn.setEnabled(True)
                if getattr(self, "current_sale_hint", None) is not None:
                    self.current_sale_hint.setText("Сохраняется в SAI и используется для печати")
            else:
                edit.setProperty("autoQuantity", False)
                edit.style().unpolish(edit)
                edit.style().polish(edit)
                edit.clear()
                edit.setEnabled(False)
                if getattr(self, "sale_minus_btn", None) is not None:
                    self.sale_minus_btn.setEnabled(False)
                if getattr(self, "sale_plus_btn", None) is not None:
                    self.sale_plus_btn.setEnabled(False)
                if getattr(self, "current_sale_hint", None) is not None:
                    self.current_sale_hint.setText("Цена: —")
        finally:
            try:
                edit.blockSignals(False)
            except Exception:
                pass

    def adjust_current_sale_price(self, direction: int) -> None:
        """Change retail price by ₽1 below ₽20, otherwise by ₽5."""
        edit = getattr(self, "current_sale_edit", None)
        if edit is None or not edit.isEnabled():
            return
        current = round(self._parse_table_number(edit.text(), 0.0), 2)
        step = 1.0 if current < 20 else 5.0
        updated = max(1.0, current + (step if int(direction) > 0 else -step))
        edit.setText(_free_price_text(updated))
        self.apply_current_sale_from_edit()

    def apply_current_sale_from_edit(self) -> None:
        """Persist the retail price of the currently selected semi-auto row."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return
        edit = getattr(self, "current_sale_edit", None)
        if edit is None or not edit.isEnabled():
            return
        row_index = self.current_index
        price = round(self._parse_table_number(edit.text(), 0.0), 2)
        if price <= 0:
            QMessageBox.warning(self, "Продажная цена", "Продажная цена должна быть больше нуля.")
            self.sync_current_sale_editor()
            return
        original_price = self.rows[row_index].get("sale")
        if original_price in (None, ""):
            original_price = self.rows[row_index].get("price")
        try:
            if abs(float(original_price or 0) - price) < 0.005:
                return
        except Exception:
            pass
        updated = dict(self.rows[row_index])
        updated = semi_approve_operator_sale_price(
            updated, price, source="manual_price_field",
        )
        self.rows[row_index] = updated
        try:
            self.save_updated_sai_file(show_message=False)
            self.scan_status.setText(
                f"Продажная цена позиции №{row_index + 1} сохранена: {_free_price_text(price)} ₽."
            )
        except Exception as exc:
            self.scan_status.setText(
                f"Цена изменена в памяти, но SAI-файл пока не сохранился: {exc}"
            )
            self.retry_save_btn.setVisible(True)
        self.refresh_table()
        self.set_current_index(row_index)

    def apply_current_label_qty_from_edit(self) -> None:
        """Apply separate thermal label quantity without changing receipt qty."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return
        edit = getattr(self, "current_label_qty_edit", None)
        if edit is None or not edit.isEnabled():
            return
        try:
            requested = max(1, int(round(self._parse_table_number(edit.text(), 1.0))))
            current_row = self.rows[self.current_index]
            if not self._label_qty_is_manual(current_row) and requested == self._receipt_qty_int(current_row):
                self.sync_current_label_qty_editor()
                return
            self.rows[self.current_index] = self.semi_service.with_label_quantity(
                current_row, requested
            )
        except ValueError as exc:
            QMessageBox.warning(self, "Ценники", str(exc))
            self.sync_current_label_qty_editor()
            return
        row = self.rows[self.current_index]
        self.sync_current_label_qty_editor()
        self.scan_status.setText(f"Для позиции №{self.current_index + 1} будет напечатано ценников: {self._current_qty_copies(row)} шт. Количество прихода не меняется.")
        try:
            self.barcode_edit.setFocus()
        except Exception:
            pass

    def set_current_label_qty_preset(self, quantity: int) -> None:
        """Apply a one-click label quantity preset."""
        edit = getattr(self, "current_label_qty_edit", None)
        if edit is None or not edit.isEnabled() or not (0 <= self.current_index < len(self.rows or [])):
            return
        requested = max(1, int(quantity))
        self.rows[self.current_index] = self.semi_service.with_label_quantity(
            self.rows[self.current_index], requested
        )
        self.sync_current_label_qty_editor()
        self.scan_status.setText(
            f"Для позиции №{self.current_index + 1} выбрано фиксированное количество ценников: {requested} шт."
        )
        try:
            self.barcode_edit.setFocus()
        except Exception:
            pass

    def select_current_label_qty_auto(self) -> None:
        """Return label printing to the receipt quantity by clicking the counter."""
        edit = getattr(self, "current_label_qty_edit", None)
        if edit is None or not edit.isEnabled() or not (0 <= self.current_index < len(self.rows or [])):
            return
        row = dict(self.rows[self.current_index])
        if "label_qty" in row:
            row.pop("label_qty", None)
            self.rows[self.current_index] = row
            self.sync_current_label_qty_editor()
            self.scan_status.setText(
                f"Для позиции №{self.current_index + 1} ценники снова печатаются по количеству в приходе: {self._current_qty_copies(row)} шт."
            )

    def adjust_current_label_qty(self, delta: int) -> None:
        """Quick +/- adjustment for separate thermal label copies."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return
        row = self.rows[self.current_index]
        if self._receipt_qty_int(row) <= 0:
            self.scan_status.setText(f"Позиция №{self.current_index + 1}: полный недовоз — ценники не печатаются.")
            self.sync_current_label_qty_editor()
            return
        self.rows[self.current_index] = self.semi_service.with_label_quantity(
            row, max(1, self._current_qty_copies(row) + int(delta))
        )
        row = self.rows[self.current_index]
        self.sync_current_label_qty_editor()
        self.scan_status.setText(f"Для позиции №{self.current_index + 1} будет напечатано ценников: {self._current_qty_copies(row)} шт. Количество прихода не меняется.")
        try:
            self.barcode_edit.setFocus()
        except Exception:
            pass

    def apply_current_qty_from_edit(self) -> None:
        """Apply receipt quantity from the quick editor without unlocking the whole table."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return
        edit = getattr(self, "current_qty_edit", None)
        if edit is None or not edit.isEnabled():
            return
        row = self.rows[self.current_index]
        old = safe_str(row.get("qty"))
        try:
            updated = self.semi_service.with_quantity(row, edit.text())
        except ValueError as exc:
            QMessageBox.warning(self, "Кол-во", str(exc))
            self.sync_current_qty_editor()
            return
        self.rows[self.current_index] = updated
        qty = updated.get("qty")
        self.refresh_table()
        self.refresh_progress()
        try:
            self.save_updated_sai_file(show_message=False)
        except Exception as exc:
            self.scan_status.setText(f"Количество изменено, но автосохранение не удалось: {exc}")
        current_idx = self.current_index
        self.set_current_index(current_idx)
        if safe_str(qty) != old:
            if self.semi_is_zero_qty(updated):
                self.scan_status.setText(f"Позиция №{current_idx + 1}: полный недовоз. В SIGMA, НДП и ценники не попадёт.")
                self.goto_next_missing(start=current_idx, wrap=False)
            else:
                self.scan_status.setText(f"Кол-во позиции №{current_idx + 1} изменено на {qty}. Ценников будет: {self._current_qty_copies(updated)} шт.")
        try:
            self.barcode_edit.setFocus()
        except Exception:
            pass

    def adjust_current_qty(self, delta: int) -> None:
        """Quick +/- receipt quantity adjustment for the current semi-auto item."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return
        current_index = self.current_index
        row = self.rows[current_index]
        value = max(0.0, self.semi_service.quantity_value(row) + float(delta))
        self.rows[current_index] = self.semi_service.with_quantity(row, value)
        row = self.rows[current_index]
        self.refresh_table()
        try:
            self.save_updated_sai_file(show_message=False)
        except Exception as exc:
            self.scan_status.setText(f"Количество изменено, но автосохранение не удалось: {exc}")
        self.set_current_index(current_index)
        if self._receipt_qty_int(row) <= 0:
            self.scan_status.setText(f"Кол-во позиции №{current_index + 1}: 0. Полный недовоз — ценники не печатаются, позиция не пойдёт в приход.")
            self.goto_next_missing(start=current_index, wrap=False)
        else:
            self.scan_status.setText(f"Кол-во позиции №{current_index + 1}: {row['qty']}. Ценников будет: {self._current_qty_copies(row)} шт.")
        try:
            self.barcode_edit.setFocus()
        except Exception:
            pass

    def _scroll_table_row_visible(self, row_index: int) -> None:
        """Scroll safely after Qt has processed pending table rebuilds.

        QTableWidget owns its items and may delete them during refresh_table().
        Never keep a QTableWidgetItem wrapper inside a deferred callback.
        """
        try:
            if not (0 <= row_index < self.table.rowCount()):
                return
            item = self.table.item(row_index, 0)
            if item is None:
                return
            self.table.scrollToItem(item, QAbstractItemView.ScrollHint.EnsureVisible)
        except RuntimeError:
            # The dialog/table can be rebuilt or closed before the zero-delay timer fires.
            return

    def set_current_index(self, idx: int) -> None:
        if not (0 <= idx < len(self.rows)):
            self.current_index = -1
            self.current_name.setText("—")
            self.current_meta.setText("—")
            if getattr(self, "previous_item_btn", None) is not None:
                self.previous_item_btn.setEnabled(bool(self.rows))
            if getattr(self, "current_name_edit_btn", None) is not None:
                self.current_name_edit_btn.setEnabled(False)
            self.sync_current_qty_editor()
            return
        self.current_index = idx
        row = self.rows[idx]
        if getattr(self, "previous_item_btn", None) is not None:
            self.previous_item_btn.setEnabled(idx > 0)
        if getattr(self, "current_name_edit_btn", None) is not None:
            self.current_name_edit_btn.setEnabled(True)
        self.current_name.setText(safe_str(row.get("name")) or "Без названия")
        article = safe_str(row.get("article") or row.get("vendor_code") or row.get("code")) or "—"
        bcs = ", ".join(self.row_barcodes(row)) or "ШК пока нет"
        if self.semi_is_zero_qty(row):
            bcs = "ШК не нужен — полный недовоз"
        self.current_meta.setText(f"Позиция {idx + 1}  ·  Артикул {article}  ·  {bcs}")
        self.sync_current_qty_editor()
        self.table.selectRow(idx)
        QTimer.singleShot(0, lambda row_index=idx: self._scroll_table_row_visible(row_index))
        self.barcode_edit.clear()
        self.clear_scan_visual_state()
        if self.semi_is_zero_qty(row):
            self.set_scan_state("НЕДОВОЗ 0", "warn")
        elif self.row_barcodes(row):
            self.set_scan_state("СТРОКА УЖЕ С ШК", "warn")
        else:
            self.set_scan_state("ГОТОВ К СКАНУ", "ready")
        self.barcode_edit.setFocus()
        self.refresh_progress()

    def show_previous_receipt_item(self) -> bool:
        """Show the literal previous row; the action is explicit, never a swipe."""
        if not self.rows:
            return False
        if self.current_index < 0:
            target = len(self.rows) - 1
        elif self.current_index > 0:
            target = self.current_index - 1
        else:
            return False
        self.set_current_index(target)
        self.refresh_table()
        self.scan_status.setText(f"Возвращён предыдущий товар: позиция №{target + 1}.")
        return True

    def update_current_product_name(self, value: str) -> bool:
        """Persist an operator name edit from either desktop or phone."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return False
        name = safe_str(value).strip()
        if not name:
            return False
        index = self.current_index
        row = dict(self.rows[index])
        if safe_str(row.get("name")).strip() == name:
            return True
        if not safe_str(row.get("name_before_operator_edit")).strip():
            row["name_before_operator_edit"] = safe_str(row.get("name")).strip()
        row["name"] = name
        row["_final_review_edited"] = True
        row["name_operator_edited"] = True
        self.rows[index] = row
        self.refresh_table()
        self.save_updated_sai_file(show_message=False)
        self.set_current_index(index)
        self.scan_status.setText(f"Название позиции №{index + 1} изменено и сохранено.")
        return True

    def restore_current_product_name(self) -> bool:
        """Restore the immutable name captured before the first manual edit."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return False
        index = self.current_index
        row = dict(self.rows[index])
        original = safe_str(row.get("name_before_operator_edit")).strip()
        if not original:
            return False
        row["name"] = original
        row["_final_review_edited"] = True
        row["name_operator_edited"] = False
        self.rows[index] = row
        self.refresh_table()
        self.save_updated_sai_file(show_message=False)
        self.set_current_index(index)
        self.scan_status.setText(f"Для позиции №{index + 1} восстановлено исходное название.")
        return True

    def edit_current_product_name(self) -> None:
        """Open the same name edit on desktop without unlocking the whole table."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return
        current = safe_str(self.rows[self.current_index].get("name"))
        value, accepted = QInputDialog.getText(
            self,
            "Название товара",
            "Название:",
            QLineEdit.EchoMode.Normal,
            current,
        )
        if not accepted:
            return
        if not safe_str(value).strip():
            QMessageBox.information(self, "Название товара", "Название не может быть пустым.")
            return
        try:
            self.update_current_product_name(value)
        except Exception as exc:
            QMessageBox.warning(self, "Название товара", f"Не удалось сохранить название.\n\n{exc}")

    def refresh_progress(self) -> None:
        progress = semi_collection_progress(self.rows or [])
        extra = f" Недовоз 0: {progress.zero_quantity}." if progress.zero_quantity else ""
        self.progress_label.setText(
            f"Готово: {progress.done}/{progress.total}. Осталось собрать ШК: {progress.missing}.{extra}"
        )
        try:
            if progress.total > 0:
                self.progress_bar.setValue(progress.percent)
                self.progress_bar.setFormat(f"{progress.done} из {progress.total}")
                if getattr(self, "progress_remaining_label", None) is not None:
                    self.progress_remaining_label.setText(
                        "Всё готово" if progress.missing == 0 else f"Осталось: {progress.missing}"
                    )
            else:
                self.progress_bar.setValue(0)
                self.progress_bar.setFormat("0% · нет товаров")
                if getattr(self, "progress_remaining_label", None) is not None:
                    self.progress_remaining_label.setText("Нет товаров")
        except Exception:
            pass

    def goto_next_missing(self, start: int = -1, wrap: bool = False) -> bool:
        snapshot = self.semi_service.progress(self.rows or [])
        if snapshot.missing == 0:
            self.current_index = -1
            self.refresh_table()
            self.refresh_progress()
            if getattr(self, "previous_item_btn", None) is not None:
                self.previous_item_btn.setEnabled(bool(self.rows))
            if getattr(self, "current_name_edit_btn", None) is not None:
                self.current_name_edit_btn.setEnabled(False)
            self.current_name.setText("Все ШК собраны")
            self.current_meta.setText("SAI-файл сохранён. Можно сразу перейти к вводу прихода в SIGMA.")
            self.sync_current_qty_editor()
            self.set_scan_state("ВСЁ СОБРАНО", "done")
            self.scan_status.setText("Готово. Все данные уже выбраны и приняты в работу.")
            self.barcode_edit.clear()
            self.enter_sigma_btn.setText("Сохранить и ввести приход в SIGMA")
            self.enter_sigma_btn.setVisible(True)
            self.enter_sigma_btn.setEnabled(True)
            try:
                self.save_updated_sai_file(show_message=False)
                self.retry_save_btn.setVisible(False)
            except Exception as exc:
                self.retry_save_btn.setVisible(True)
                self.scan_status.setText(
                    "Все ШК остаются в памяти SAI, но файл пока не сохранён: "
                    f"{exc}. Нажми «Повторить сохранение» или большую кнопку продолжения."
                )
            return False
        self.enter_sigma_btn.setVisible(False)
        self.enter_sigma_btn.setEnabled(False)
        index = self.semi_service.next_missing(self.rows or [], start=start, wrap=wrap)
        if index is None:
            return False
        self.set_current_index(index)
        self.refresh_table()
        return True

    def scan_entered(self, force: bool = True) -> None:
        if self.scan_timer:
            self.scan_timer.stop()
        if not self.rows:
            QMessageBox.information(self, "Полуавтоматический привоз", "Сначала выбери SAI-файл.")
            return
        if self.current_index < 0:
            self.goto_next_missing(start=-1, wrap=True)
            return
        text = self.barcode_edit.text()
        bcs, warnings, error, wait_more = self.parse_scan_barcodes(text, force=force)
        if wait_more:
            return
        if error:
            self.mark_scan_error(error)
            self.barcode_edit.selectAll()
            return
        duplicates = []
        for bc in bcs:
            owner = self.find_barcode_owner(bc, exclude_current=True)
            if owner is not None:
                duplicates.append((bc, owner))
        if duplicates:
            bc, owner = duplicates[0]
            self.mark_scan_error(f"Этот ШК уже указан у позиции №{owner + 1}: {safe_str((self.rows[owner] or {}).get('name'))}")
            self.barcode_edit.selectAll()
            return
        if len(bcs) == 1 and not self.approve_scanned_catalog_price(bcs[0]):
            self.barcode_edit.selectAll()
            self.barcode_edit.setFocus()
            return
        self.add_barcodes_to_current(bcs, warnings=warnings)

    def approve_scanned_catalog_price(self, barcode: str) -> bool:
        """Let the operator lock the catalog or incoming price before label printing."""
        if not (0 <= self.current_index < len(self.rows or [])):
            return False
        # Exact scans must never rebuild thousands of catalog rows in the Qt
        # thread. The shared index is warmed in the background when the page
        # opens; a refresh may continue without blocking the operator.
        matches = self.catalog_service.find_exact_barcode(barcode, non_blocking=True)
        if not matches:
            return True
        product = dict(matches[0])
        catalog_price = round(_free_money_float(product.get("price")), 2)
        if catalog_price <= 0:
            return True
        row = dict(self.rows[self.current_index])
        incoming_price = round(_free_money_float(row.get("sale") or row.get("price")), 2)

        dialog = QDialog(self)
        dialog.setObjectName("SemiPriceChoiceDialog")
        dialog.setWindowTitle("Выбрать цену")
        dialog.setMinimumWidth(560)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(13)
        title = QLabel("Этот ШК уже есть в каталоге")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        product_name = QLabel(safe_str(product.get("name")) or safe_str(row.get("name")))
        product_name.setObjectName("WorkbenchSubtitle")
        product_name.setWordWrap(True)
        layout.addWidget(product_name)

        prices = QFrame()
        prices.setObjectName("WorkbenchCard")
        price_layout = QGridLayout(prices)
        price_layout.setContentsMargins(16, 14, 16, 14)
        price_layout.addWidget(QLabel("Цена в каталоге"), 0, 0)
        price_layout.addWidget(QLabel(f"{_free_price_text(catalog_price)} ₽"), 0, 1)
        price_layout.addWidget(QLabel("Новая цена"), 1, 0)
        price_layout.addWidget(QLabel(f"{_free_price_text(incoming_price)} ₽"), 1, 1)
        layout.addWidget(prices)

        repeat_hint = QLabel(
            "Можно нажать любую кнопку. Чтобы быстро выбрать цену каталога, "
            "повторно просканируй этот же ШК."
        )
        repeat_hint.setObjectName("StatsSubtitle")
        repeat_hint.setWordWrap(True)
        layout.addWidget(repeat_hint)
        repeat_scan = QLineEdit()
        repeat_scan.setObjectName("WorkbenchInput")
        repeat_scan.setProperty("priceRepeatScan", True)
        repeat_scan.setPlaceholderText("Повторный скан подтверждает цену каталога")
        layout.addWidget(repeat_scan)

        actions = QHBoxLayout()
        incoming_btn = QPushButton("Оставить новую")
        incoming_btn.setObjectName("SoftButton")
        incoming_btn.setProperty("priceChoice", "incoming")
        incoming_btn.setEnabled(incoming_price > 0)
        catalog_btn = QPushButton("Использовать цену из каталога")
        catalog_btn.setObjectName("WorkbenchPrimaryButton")
        catalog_btn.setProperty("priceChoice", "catalog")
        actions.addWidget(incoming_btn)
        actions.addStretch(1)
        actions.addWidget(catalog_btn)
        layout.addLayout(actions)

        choice: Dict[str, str] = {"source": ""}

        def accept_choice(source: str) -> None:
            choice["source"] = source
            dialog.accept()

        def accept_repeat_scan() -> None:
            scanned = re.sub(r"\D+", "", repeat_scan.text())
            expected = re.sub(r"\D+", "", barcode)
            if scanned != expected:
                repeat_hint.setText("Это другой ШК. Для подтверждения повторно просканируй последний ШК.")
                repeat_scan.selectAll()
                return
            accept_choice("catalog")

        incoming_btn.clicked.connect(lambda: accept_choice("incoming"))
        catalog_btn.clicked.connect(lambda: accept_choice("catalog"))
        repeat_scan.returnPressed.connect(accept_repeat_scan)
        QTimer.singleShot(0, repeat_scan.setFocus)
        if dialog.exec() != QDialog.DialogCode.Accepted or not choice["source"]:
            return False

        selected_price = catalog_price if choice["source"] == "catalog" else incoming_price
        row["sale"] = selected_price
        row["price"] = selected_price
        row["price_operator_approved"] = True
        row["price_approval_source"] = choice["source"]
        row["catalog_price_snapshot"] = catalog_price
        row["price_approval_barcode"] = re.sub(r"\D+", "", barcode)
        self.rows[self.current_index] = row
        self.sync_current_sale_editor()
        return True

    def add_barcodes_to_current(
        self,
        bcs: List[str],
        warnings: Optional[List[str]] = None,
        print_confirmed: bool = False,
        suppress_print: bool = False,
    ) -> None:
        if not (0 <= self.current_index < len(self.rows)):
            return
        idx = self.current_index
        row = self.semi_service.merge_barcodes(self.rows[idx], bcs, warnings=warnings or ())
        self.rows[idx] = row
        suffix = " ⚠ " + "; ".join(warnings) if warnings else ""
        save_suffix = ""
        save_failed = False
        try:
            self.save_updated_sai_file(show_message=False)
            save_suffix = " Файл сохранён."
        except Exception as exc:
            save_failed = True
            save_suffix = f" Автосохранение не удалось: {exc}. ШК сохранён в памяти."
        if save_failed:
            self.set_scan_state("ОШИБКА СОХРАНЕНИЯ", "error")
            self.scan_status.setText(
                f"{idx + 1}: ШК {', '.join(bcs)} принят и остаётся в памяти, "
                f"но перейти к следующей позиции нельзя. {save_suffix}"
            )
            self.retry_save_btn.setVisible(True)
            self.refresh_table()
            self.beep_error()
            return
        self.retry_save_btn.setVisible(False)
        print_suffix = ""
        print_failed = False
        if (not suppress_print) and bool(getattr(self, "print_thermal_check", None) and self.print_thermal_check.isChecked()):
            try:
                copies = self.print_thermal_labels_for_row(
                    row,
                    preferred_barcode=bcs[0] if bcs else "",
                    confirmed=print_confirmed,
                )
                if copies:
                    print_suffix = f" Термоценники: {copies} шт."
            except Exception as exc:
                print_failed = True
                print_suffix = f" Термоценники не напечатались: {exc}"
        price_suffix = ""
        if row.get("price_operator_approved"):
            source_label = "каталога" if row.get("price_approval_source") == "catalog" else "новая"
            price_suffix = (
                f" Цена {source_label} утверждена оператором: "
                f"{_free_price_text(row.get('sale') or row.get('price'))} ₽."
            )
        self.set_scan_state("ПРИНЯТО", "ok" if not warnings else "warn")
        self.scan_status.setText(
            f"{idx + 1}: записал {', '.join(bcs)}. Готов к следующему ШК."
            f"{price_suffix}{suffix}{save_suffix}{print_suffix}"
        )
        self.clear_scan_visual_state()
        self.refresh_table()
        self.goto_next_missing(start=idx, wrap=False)
        if self.current_index == idx:
            self.goto_next_missing(start=-1, wrap=True)
        if print_failed:
            self.beep_error()
        else:
            self.beep_success()

    def retry_save_current_state(self) -> None:
        """Persist in-memory scans before allowing the workflow to move on."""
        try:
            saved = self.save_updated_sai_file(show_message=False)
        except Exception as exc:
            self.retry_save_btn.setVisible(True)
            self.set_scan_state("ОШИБКА СОХРАНЕНИЯ", "error")
            self.scan_status.setText(
                f"ШК всё ещё находятся в памяти, но файл сохранить не удалось: {exc}"
            )
            self.beep_error()
            return
        if not saved:
            return
        self.retry_save_btn.setVisible(False)
        self.scan_status.setText(f"Данные сохранены: {saved}")
        self.goto_next_missing(start=self.current_index, wrap=True)
        self.beep_success()

    def print_thermal_labels_for_row(
        self,
        row: Dict[str, Any],
        preferred_barcode: str = "",
        confirmed: bool = False,
    ) -> int:
        """Print thermal labels for a semi-auto receipt row.

        Used only when the operator enabled printing in the semi-auto scanner page.
        Copies come from the separate label quantity control. If the operator did
        not change it for this row, it follows the receipt quantity. The label
        price is the sale price from the SAI file. The barcode is the just-scanned
        code when available, otherwise the first barcode in the row.
        """
        copies = self._current_qty_copies(row)
        if copies <= 0:
            return 0
        cfg = _thermal_config()
        max_without_confirm = max(1, int(cfg.get("max_without_confirm") or 20))
        if copies > max_without_confirm and not confirmed:
            answer = QMessageBox.question(
                self,
                "Печать термоценников",
                f"Напечатать {copies} термоценников для товара?\n\n{safe_str(row.get('name'))}",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return 0
        # Persist the exact price before touching the physical printer.  If the
        # save fails, no potentially misleading label is allowed to leave SAI.
        # The APPLY stage recognises this approval flag and carries the same
        # value into SIGMA, NDP and all later price tags.
        row_index = next(
            (index for index, candidate in enumerate(self.rows or []) if candidate is row),
            None,
        )
        if row_index is None:
            raise RuntimeError("Не удалось связать термоценник со строкой прихода. Печать остановлена, чтобы не потерять цену.")
        row = semi_lock_sale_price_for_thermal_label(row)
        self.rows[row_index] = row
        if not self.save_updated_sai_file(show_message=False):
            raise RuntimeError("Не удалось сохранить цену термоценника в SAI-файл.")
        barcode = safe_str(preferred_barcode) or (self.row_barcodes(row)[0] if self.row_barcodes(row) else "")
        item = {
            "name": row.get("name", ""),
            "barcode": barcode,
            "price": row.get("sale") or row.get("price") or 0,
            "unit": row.get("unit", "штука") or "штука",
        }
        print_thermal_price_label(item, copies=copies, parent=self, printer_override=safe_str(cfg.get("printer")))
        return copies

    def skip_current(self) -> None:
        if self.current_index >= 0:
            idx = self.current_index
            if not self.goto_next_missing(start=idx, wrap=False):
                self.goto_next_missing(start=-1, wrap=True)

    def all_existing_barcodes(self) -> set:
        existing = self.semi_service.existing_barcodes(self.rows or [])
        existing.update(_free_load_generated_barcodes())
        try:
            for row in db_rows("SELECT barcode FROM barcodes WHERE barcode LIKE '77%'"):
                existing.add(str(row.get("barcode") or ""))
        except Exception:
            pass
        return {x for x in existing if x}

    def make_internal_barcode(self) -> Optional[str]:
        existing = self.all_existing_barcodes()
        cfg = load_private_config()
        prefix = free_normalized_internal_prefix(cfg.get("free_receipt_barcode_prefix") or "7700")
        remembered_raw = int(_free_money_float(cfg.get("free_receipt_barcode_last_counter") or 0))
        max_counter = (10 ** max(1, 12 - len(prefix))) - 1
        remembered = remembered_raw if 0 <= remembered_raw <= max_counter else 0
        observed = free_highest_internal_counter(existing, prefix)
        candidate = self.semi_service.next_internal_barcode(
            existing,
            prefix=prefix,
            start_counter=max(remembered, observed) + 1,
        )
        if candidate is None:
            return None
        code, counter = candidate
        history = _free_load_generated_barcodes()
        history.append(code)
        _free_save_generated_barcodes(history)
        save_private_config_patch({
            "free_receipt_barcode_prefix": prefix,
            "free_receipt_barcode_last_counter": counter,
        })
        return code

    def generate_for_current(self) -> None:
        if self.current_index < 0:
            self.goto_next_missing(start=-1, wrap=True)
            return
        code = self.make_internal_barcode()
        if not code:
            QMessageBox.warning(self, "Полуавтоматический привоз", "Не удалось подобрать свободный внутренний ШК.")
            return
        self.add_barcodes_to_current([code])

    def output_copy_path(self) -> Path:
        """Return the active SAI file path.

        Semi-auto editing is an in-place editor: when a source file exists it is
        overwritten atomically after each accepted/generated barcode.
        """
        if self.sai_path:
            self.output_path = Path(self.sai_path)
            return self.output_path
        if self.output_path:
            return self.output_path
        base = desktop_dir() / f"SAI_Полуавто_{dt.datetime.now().strftime('%d%m%y')}.sai"
        if base.exists():
            base = desktop_dir() / f"SAI_Полуавто_{dt.datetime.now().strftime('%d%m%y_%H%M%S')}.sai"
        self.output_path = base
        return base

    def _write_row_to_xml_item(self, item_el: ET.Element, row: Dict[str, Any], idx: int) -> None:
        """Write one unified manual/semi-auto row into a SAI XML <item>."""
        item_el.set("row", safe_str(item_el.get("row") or idx + 1))

        def set_xml_text(tag: str, value: Any) -> None:
            el = item_el.find(tag)
            if el is None:
                el = ET.SubElement(item_el, tag)
            el.text = safe_str(value)

        if self.semi_is_zero_qty(row) and "недовоз" not in safe_str(row.get("comment")).lower():
            row["comment"] = (safe_str(row.get("comment")) + " Недовоз: фактическое количество 0.").strip()
        purchase = row.get("buy") if row.get("buy") not in (None, "") else row.get("purchase_price")
        sale = row.get("sale") if row.get("sale") not in (None, "") else row.get("price")
        set_xml_text("name", row.get("name"))
        set_xml_text("quantity", row.get("qty"))
        set_xml_text("unit", row.get("unit") or "штука")
        set_xml_text("purchase_price", purchase or 0)
        set_xml_text("sale_price", sale or 0)
        set_xml_text("article", row.get("article") or row.get("vendor_code") or row.get("code") or "")
        # Category deliberately stays blank here. New-product category wizard fills it later.
        set_xml_text("category", row.get("category") or "")
        set_xml_text("comment", row.get("comment") or "")
        bcs_el = item_el.find("barcodes")
        if bcs_el is None:
            bcs_el = ET.SubElement(item_el, "barcodes")
        for child in list(bcs_el):
            bcs_el.remove(child)
        for bc in self.row_barcodes(row):
            bc_el = ET.SubElement(bcs_el, "barcode")
            bc_el.text = str(bc)

    def _create_manual_receipt_xml_tree(self) -> ET.ElementTree:
        root = ET.Element("sai_receipt", {"version": "1.0"})
        meta = ET.SubElement(root, "meta")
        def m(tag: str, text: str) -> None:
            el = ET.SubElement(meta, tag)
            el.text = text
        m("supplier", "ПОЛУАВТОМАТИЧЕСКИЙ ПРИВОЗ")
        m("date", dt.date.today().isoformat())
        m("invoice_number", "MANUAL")
        m("markup_percent", safe_str(load_private_config().get("default_markup_percent") or 60))
        m("currency", "RUB")
        m("source", "SAI полуавтоматический привоз")
        items_el = ET.SubElement(root, "items")
        for idx, row in enumerate(self.rows or []):
            item_el = ET.SubElement(items_el, "item", {"row": str(idx + 1)})
            self._write_row_to_xml_item(item_el, row, idx)
        try:
            ET.indent(root, space="  ")
        except Exception:
            pass
        return ET.ElementTree(root)

    def save_updated_sai_file(self, show_message: bool = True) -> Optional[Path]:
        if not self.rows:
            if show_message:
                QMessageBox.information(self, "Полуавтоматический привоз", "Сначала выбери SAI-файл или добавь хотя бы одну позицию вручную.")
            return None
        out = self.output_copy_path()
        source = Path(self.sai_path) if self.sai_path else None
        try:
            saved_path = self.semi_auto_service.save_rows(
                self.rows,
                source_path=source,
                output_path=out,
                sheet_name=self.sheet_name,
                default_markup_percent=float(load_private_config().get("default_markup_percent") or 60),
            )
            self.sai_path = saved_path
            self.output_path = saved_path
            self.update_file_summary(saved_path, saved=True)
            if show_message:
                QMessageBox.information(self, "Полуавтоматический привоз", f"SAI-файл сохранён:\n{saved_path}")
            return saved_path
        except Exception as exc:
            if show_message:
                QMessageBox.critical(self, "Полуавтоматический привоз", f"Не удалось сохранить SAI-файл:\n{exc}")
            else:
                raise
            return None

    def open_in_auto_receipt(self) -> None:
        if self.missing_indices():
            QMessageBox.warning(
                self,
                "Полуавтоматический привоз",
                "Нельзя продолжить: ещё остались позиции без обязательного ШК.",
            )
            return
        try:
            # Never trust an existing path here: the authoritative rows live in
            # memory until this exact save succeeds.
            path = self.save_updated_sai_file(show_message=False)
        except Exception as exc:
            self.enter_sigma_btn.setVisible(True)
            self.enter_sigma_btn.setEnabled(True)
            self.retry_save_btn.setVisible(True)
            QMessageBox.critical(
                self,
                "Полуавтоматический привоз",
                "Все ШК остаются в открытом SAI, но файл пока не сохранён.\n\n"
                f"{exc}\n\nНе закрывай SAI и нажми «Повторить сохранение».",
            )
            return
        if path and getattr(self.parent_page, "open_sai_file_in_workbench", None):
            self.retry_save_btn.setVisible(False)
            self.parent_page.open_sai_file_in_workbench(Path(path))



class AIInvoiceSignals(QObject):
    finished = Signal(object)
    failed = Signal(str)


class InvoiceDropFrame(QFrame):
    """Workbench card that accepts one or more local invoice files."""

    files_dropped = Signal(object)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setProperty("dropTarget", True)
        self.setProperty("dragActive", False)

    def _set_drag_active(self, active: bool) -> None:
        active = bool(active)
        if bool(self.property("dragActive")) == active:
            return
        self.setProperty("dragActive", active)
        style = self.style()
        style.unpolish(self)
        style.polish(self)
        self.update()

    @staticmethod
    def _local_files(event) -> List[Path]:
        mime = event.mimeData()
        if not mime or not mime.hasUrls():
            return []
        result: List[Path] = []
        for url in mime.urls():
            if not url.isLocalFile():
                continue
            path = Path(url.toLocalFile())
            if path.is_file():
                result.append(path)
        return result

    def dragEnterEvent(self, event) -> None:  # noqa: N802 - Qt override name
        if self._local_files(event):
            self._set_drag_active(True)
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event) -> None:  # noqa: N802 - Qt override name
        if self._local_files(event):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event) -> None:  # noqa: N802 - Qt override name
        self._set_drag_active(False)
        event.accept()

    def dropEvent(self, event) -> None:  # noqa: N802 - Qt override name
        paths = self._local_files(event)
        self._set_drag_active(False)
        if not paths:
            event.ignore()
            return
        self.files_dropped.emit(paths)
        event.acceptProposedAction()


class PageCropPreview(QWidget):
    """Document preview with a direct mouse-drag crop selection."""

    crop_changed = Signal(object)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumSize(320, 200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setCursor(Qt.CrossCursor)
        self._image = QImage()
        self._crop: Optional[tuple[float, float, float, float]] = None
        self._image_rect = QRectF()
        self._drag_start: Optional[QPointF] = None
        self._drag_end: Optional[QPointF] = None

    def set_page(self, image: QImage, crop: object = None) -> None:
        self._image = image
        self._crop = sai_page_orientation.normalize_crop(crop)
        self._drag_start = None
        self._drag_end = None
        self.update()

    def _selection_rect(self) -> QRectF:
        if self._drag_start is not None and self._drag_end is not None:
            return QRectF(self._drag_start, self._drag_end).normalized().intersected(self._image_rect)
        if self._crop and not self._image_rect.isEmpty():
            x, y, width, height = self._crop
            return QRectF(
                self._image_rect.left() + x * self._image_rect.width(),
                self._image_rect.top() + y * self._image_rect.height(),
                width * self._image_rect.width(),
                height * self._image_rect.height(),
            )
        return QRectF()

    def paintEvent(self, event):  # noqa: N802 - Qt override name
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.fillRect(self.rect(), QColor("#e5e7eb"))
        if self._image.isNull():
            return
        available = QRectF(self.rect()).adjusted(10, 10, -10, -10)
        scale = min(available.width() / self._image.width(), available.height() / self._image.height())
        width = self._image.width() * scale
        height = self._image.height() * scale
        self._image_rect = QRectF(
            available.center().x() - width / 2,
            available.center().y() - height / 2,
            width,
            height,
        )
        painter.drawImage(self._image_rect, self._image)
        selection = self._selection_rect()
        if selection.isEmpty():
            painter.setPen(QPen(QColor("#64748b"), 1))
            painter.drawRoundedRect(self._image_rect, 7, 7)
            return
        shade = QColor(15, 23, 42, 112)
        outer = self._image_rect
        painter.fillRect(QRectF(outer.left(), outer.top(), outer.width(), selection.top() - outer.top()), shade)
        painter.fillRect(QRectF(outer.left(), selection.bottom(), outer.width(), outer.bottom() - selection.bottom()), shade)
        painter.fillRect(QRectF(outer.left(), selection.top(), selection.left() - outer.left(), selection.height()), shade)
        painter.fillRect(QRectF(selection.right(), selection.top(), outer.right() - selection.right(), selection.height()), shade)
        painter.setPen(QPen(QColor("#2563eb"), 3))
        painter.drawRoundedRect(selection, 5, 5)

    def mousePressEvent(self, event):  # noqa: N802 - Qt override name
        if event.button() == Qt.LeftButton and self._image_rect.contains(event.position()):
            self._drag_start = event.position()
            self._drag_end = event.position()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: N802 - Qt override name
        if self._drag_start is not None:
            point = event.position()
            point.setX(max(self._image_rect.left(), min(self._image_rect.right(), point.x())))
            point.setY(max(self._image_rect.top(), min(self._image_rect.bottom(), point.y())))
            self._drag_end = point
            self.update()
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: N802 - Qt override name
        if event.button() == Qt.LeftButton and self._drag_start is not None:
            rect = self._selection_rect()
            self._drag_start = None
            self._drag_end = None
            if not rect.isEmpty() and not self._image_rect.isEmpty():
                crop = sai_page_orientation.normalize_crop((
                    (rect.left() - self._image_rect.left()) / self._image_rect.width(),
                    (rect.top() - self._image_rect.top()) / self._image_rect.height(),
                    rect.width() / self._image_rect.width(),
                    rect.height() / self._image_rect.height(),
                ))
                if crop:
                    self._crop = crop
                    self.crop_changed.emit(crop)
            self.update()
            event.accept()
            return
        super().mouseReleaseEvent(event)


class PageOrientationDialog(QDialog):
    """Preview every visual page and confirm its rotation before API spending.

    The confirmation bar is always kept inside the available desktop area. The
    preview is the only element allowed to shrink on compact screens.
    """

    def __init__(self, paths: List[Path], supplier_hint: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Подготовка страниц накладной")
        self.setSizeGripEnabled(True)
        self.pages: List[Dict[str, Any]] = []
        self.current_index = 0
        self.supplier_hint = safe_str(supplier_hint)
        self.preferred_angle = sai_page_orientation.load_supplier_preference(self.supplier_hint)
        self._screen_fitted = False
        self._load_pages(paths)
        self._build_ui()
        self._fit_to_available_screen(force=True)
        self._refresh()

    def _load_pages(self, paths: List[Path]) -> None:
        try:
            from PySide6.QtPdf import QPdfDocument
        except Exception:
            QPdfDocument = None
        for path in paths:
            suffix = path.suffix.lower()
            if suffix == ".pdf":
                if QPdfDocument is None:
                    raise RuntimeError("В этой сборке недоступен модуль QtPdf для предварительного просмотра PDF.")
                doc = QPdfDocument()
                doc.load(str(path))
                try:
                    page_count = max(0, int(doc.pageCount()))
                    if page_count <= 0:
                        raise RuntimeError(f"{path.name}: PDF не содержит доступных страниц.")
                    loaded_pages: List[Dict[str, Any]] = []
                    failed_pages: List[int] = []
                    for page_index in range(page_count):
                        points = doc.pagePointSize(page_index)
                        if points.width() <= 0 or points.height() <= 0:
                            failed_pages.append(page_index + 1)
                            continue
                        scale = 2200.0 / max(points.width(), points.height())
                        image = doc.render(
                            page_index,
                            QSize(max(1, int(points.width() * scale)), max(1, int(points.height() * scale))),
                        )
                        if image.isNull():
                            failed_pages.append(page_index + 1)
                            continue
                        angle, reason = sai_page_orientation.propose_rotation(image, self.preferred_angle)
                        loaded_pages.append(
                            {
                                "path": path.resolve(),
                                "page_index": page_index,
                                "image": image,
                                "angle": angle,
                                "suggested_angle": angle,
                                "reason": reason,
                            }
                        )
                    if failed_pages or len(loaded_pages) != page_count:
                        failed_text = ", ".join(str(page) for page in failed_pages) or "неизвестно"
                        raise RuntimeError(
                            f"{path.name}: в PDF {page_count} стр., но SAI не смог подготовить "
                            f"страницы {failed_text}. Распознавание не запущено, чтобы не потерять листы."
                        )
                    self.pages.extend(loaded_pages)
                finally:
                    try:
                        doc.close()
                    except Exception:
                        pass
            elif suffix in sai_page_orientation.VISUAL_EXTENSIONS:
                image = QImage(str(path))
                if image.isNull():
                    continue
                angle, reason = sai_page_orientation.propose_rotation(image, self.preferred_angle)
                self.pages.append(
                    {
                        "path": path.resolve(),
                        "page_index": 0,
                        "image": image,
                        "angle": angle,
                        "suggested_angle": angle,
                        "reason": reason,
                    }
                )
        if not self.pages:
            raise RuntimeError("Не удалось подготовить ни одной страницы для предварительного просмотра.")

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 10, 12, 10)
        outer.setSpacing(8)

        title = QLabel("Подготовь страницы до платного запроса")
        title.setObjectName("PageHeaderTitle")
        note = QLabel(
            "Поверни листы как нужно. Чтобы убрать лишнее, протяни рамку мышью вокруг полезной области. "
            "До подтверждения обращение к API не выполняется."
        )
        note.setObjectName("WorkbenchNote")
        note.setWordWrap(True)
        outer.addWidget(title)
        outer.addWidget(note)

        info_row = QHBoxLayout()
        info_row.setSpacing(8)
        self.page_label = QLabel()
        self.page_label.setObjectName("WorkbenchSection")
        self.angle_label = QLabel()
        self.angle_label.setObjectName("InlineStatus")
        info_row.addWidget(self.page_label, 1)
        info_row.addWidget(self.angle_label)
        outer.addLayout(info_row)

        self.preview = PageCropPreview()
        self.preview.crop_changed.connect(self._set_crop)
        self.preview.setStyleSheet("PageCropPreview { background: #e5e7eb; border: 1px solid #cbd5e1; border-radius: 10px; }")
        outer.addWidget(self.preview, 1)

        self.reason_label = QLabel()
        self.reason_label.setObjectName("WorkbenchNote")
        self.reason_label.setWordWrap(True)
        self.reason_label.setMaximumHeight(44)
        outer.addWidget(self.reason_label)

        rotation_panel = QWidget()
        rotation_flow = FlowLayout(rotation_panel, margin=0, spacing=6)
        self.left_btn = QPushButton("↶ 90° влево")
        self.reset_btn = QPushButton("Без поворота")
        self.flip_btn = QPushButton("180°")
        self.right_btn = QPushButton("90° вправо ↷")
        self.apply_file_btn = QPushButton("Так же для всех листов файла")
        for button in (self.left_btn, self.reset_btn, self.flip_btn, self.right_btn, self.apply_file_btn):
            button.setObjectName("SoftButton")
            button.setMinimumHeight(34)
        self.left_btn.clicked.connect(lambda: self._rotate(-90))
        self.reset_btn.clicked.connect(lambda: self._set_angle(0))
        self.flip_btn.clicked.connect(lambda: self._rotate(180))
        self.right_btn.clicked.connect(lambda: self._rotate(90))
        self.apply_file_btn.clicked.connect(self._apply_to_file)
        for button in (self.left_btn, self.reset_btn, self.flip_btn, self.right_btn, self.apply_file_btn):
            rotation_flow.addWidget(button)
        outer.addWidget(rotation_panel)

        crop_panel = QWidget()
        crop_flow = FlowLayout(crop_panel, margin=0, spacing=6)
        self.crop_hint = QLabel("Кадрирование: выдели мышью область с товарами")
        self.crop_hint.setObjectName("WorkbenchNote")
        self.reset_crop_btn = QPushButton("Показать весь лист")
        self.apply_crop_file_btn = QPushButton("Такое кадрирование для всех листов файла")
        for button in (self.reset_crop_btn, self.apply_crop_file_btn):
            button.setObjectName("SoftButton")
            button.setMinimumHeight(34)
        self.reset_crop_btn.clicked.connect(lambda: self._set_crop(None))
        self.apply_crop_file_btn.clicked.connect(self._apply_crop_to_file)
        crop_flow.addWidget(self.crop_hint)
        crop_flow.addWidget(self.reset_crop_btn)
        crop_flow.addWidget(self.apply_crop_file_btn)
        outer.addWidget(crop_panel)

        navigation = QHBoxLayout()
        navigation.setSpacing(6)
        self.prev_btn = QPushButton("← Предыдущая")
        self.next_btn = QPushButton("Следующая →")
        self.prev_btn.setObjectName("SoftButton")
        self.next_btn.setObjectName("SoftButton")
        self.prev_btn.setMinimumHeight(34)
        self.next_btn.setMinimumHeight(34)
        self.prev_btn.clicked.connect(self._previous)
        self.next_btn.clicked.connect(self._next)
        navigation.addWidget(self.prev_btn)
        navigation.addWidget(self.next_btn)
        navigation.addStretch(1)
        self.counter_label = QLabel()
        navigation.addWidget(self.counter_label)
        outer.addLayout(navigation)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        outer.addWidget(separator)

        action_row = QHBoxLayout()
        action_row.setContentsMargins(0, 0, 0, 0)
        self.shortcut_label = QLabel("Ctrl+Enter — подтвердить")
        self.shortcut_label.setObjectName("WorkbenchNote")
        action_row.addWidget(self.shortcut_label)
        action_row.addStretch(1)
        self.button_box = QDialogButtonBox(QDialogButtonBox.Cancel | QDialogButtonBox.Ok)
        self.confirm_button = self.button_box.button(QDialogButtonBox.Ok)
        self.cancel_button = self.button_box.button(QDialogButtonBox.Cancel)
        self.confirm_button.setText("Подтвердить страницы")
        self.cancel_button.setText("Отмена")
        self.confirm_button.setObjectName("PageOrientationConfirmButton")
        self.cancel_button.setObjectName("SoftButton")
        self.confirm_button.setMinimumSize(240, 48)
        self.cancel_button.setMinimumHeight(44)
        self.confirm_button.setCursor(Qt.PointingHandCursor)
        self.cancel_button.setCursor(Qt.PointingHandCursor)
        self.confirm_button.setDefault(True)
        self.confirm_button.setAutoDefault(True)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        action_row.addWidget(self.button_box)
        outer.addLayout(action_row)

    def _fit_to_available_screen(self, force: bool = False) -> None:
        if self._screen_fitted and not force:
            return
        screen = None
        try:
            parent = self.parentWidget()
            if parent is not None:
                screen = parent.screen()
        except Exception:
            screen = None
        if screen is None:
            screen = QApplication.primaryScreen()
        if screen is None:
            self.resize(960, 700)
            self._screen_fitted = True
            return
        available = screen.availableGeometry()
        width = max(520, min(1120, int(available.width() * 0.96)))
        height = max(430, min(820, int(available.height() * 0.94)))
        width = min(width, available.width())
        height = min(height, available.height())
        self.setMinimumSize(min(600, width), min(430, height))
        self.setMaximumSize(available.size())
        self.resize(width, height)
        frame = self.frameGeometry()
        frame.moveCenter(available.center())
        self.move(frame.topLeft())
        self._screen_fitted = True

    def showEvent(self, event):  # noqa: N802 - Qt override name
        self._fit_to_available_screen(force=True)
        super().showEvent(event)

    def resizeEvent(self, event):  # noqa: N802 - Qt override name
        super().resizeEvent(event)
        self._refresh_preview_pixmap()

    def keyPressEvent(self, event):  # noqa: N802 - Qt override name
        if event.key() in (Qt.Key_Return, Qt.Key_Enter) and event.modifiers() & Qt.ControlModifier:
            self.accept()
            return
        super().keyPressEvent(event)

    def _page(self) -> Dict[str, Any]:
        return self.pages[self.current_index]

    def _set_angle(self, angle: int) -> None:
        page = self._page()
        new_angle = sai_page_orientation.normalize_angle(angle)
        if new_angle != sai_page_orientation.normalize_angle(page.get("angle")):
            page["crop"] = None
        page["angle"] = new_angle
        self._refresh()

    def _set_crop(self, crop: object) -> None:
        self._page()["crop"] = sai_page_orientation.normalize_crop(crop)
        self._refresh()

    def _rotate(self, delta: int) -> None:
        self._set_angle(int(self._page().get("angle") or 0) + int(delta))

    def _apply_to_file(self) -> None:
        page = self._page()
        for candidate in self.pages:
            if candidate["path"] == page["path"]:
                if sai_page_orientation.normalize_angle(candidate.get("angle")) != page["angle"]:
                    candidate["crop"] = None
                candidate["angle"] = page["angle"]
        self._refresh()

    def _apply_crop_to_file(self) -> None:
        page = self._page()
        crop = sai_page_orientation.normalize_crop(page.get("crop"))
        for candidate in self.pages:
            if candidate["path"] == page["path"]:
                candidate["crop"] = crop
        self._refresh()

    def _previous(self) -> None:
        if self.current_index > 0:
            self.current_index -= 1
            self._refresh()

    def _next(self) -> None:
        if self.current_index + 1 < len(self.pages):
            self.current_index += 1
            self._refresh()

    def _refresh_preview_pixmap(self) -> None:
        if not self.pages or not hasattr(self, "preview"):
            return
        page = self._page()
        prepared = sai_page_orientation.apply_rotation(page["image"], page["angle"])
        self.preview.set_page(prepared, page.get("crop"))

    def _refresh(self) -> None:
        page = self._page()
        total = len(self.pages)
        self.page_label.setText(f"{page['path'].name} · лист {int(page['page_index']) + 1}")
        self.angle_label.setText("Сейчас: " + sai_page_orientation.angle_label(page["angle"]))
        suggested = sai_page_orientation.angle_label(page.get("suggested_angle", 0))
        self.reason_label.setText(f"SAI предлагает: {suggested} — {page.get('reason') or 'проверь визуально'}.")
        has_crop = sai_page_orientation.normalize_crop(page.get("crop")) is not None
        self.crop_hint.setText(
            "Кадрирование включено — в ИИ уйдёт только выделенная область"
            if has_crop else "Кадрирование: выдели мышью область с товарами"
        )
        self.reset_crop_btn.setEnabled(has_crop)
        self.apply_crop_file_btn.setEnabled(has_crop)
        self.counter_label.setText(f"Страница {self.current_index + 1} из {total}")
        self.prev_btn.setEnabled(self.current_index > 0)
        self.next_btn.setEnabled(self.current_index + 1 < total)
        self._refresh_preview_pixmap()

    def orientation_plan(self) -> Dict[str, List[Any]]:
        plan: Dict[str, List[Any]] = {}
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for page in self.pages:
            grouped.setdefault(str(page["path"]), []).append(page)
        for path, pages in grouped.items():
            pages.sort(key=lambda item: int(item["page_index"]))
            settings: List[Any] = []
            for item in pages:
                angle = sai_page_orientation.normalize_angle(item["angle"])
                crop = sai_page_orientation.normalize_crop(item.get("crop"))
                settings.append({"angle": angle, "crop": list(crop)} if crop else angle)
            plan[path] = settings
        return plan

    def common_angle(self) -> Optional[int]:
        angles = {sai_page_orientation.normalize_angle(page["angle"]) for page in self.pages}
        return next(iter(angles)) if len(angles) == 1 else None


class ProductNameReviewDialog(QDialog):
    """Side-by-side review of source literals and catalog-facing names."""

    def __init__(self, items: List[Any], parent=None) -> None:
        super().__init__(parent)
        self.items = list(items or [])
        self.changed_count = 0
        self.setWindowTitle("Проверка названий товаров")
        self.resize(1240, 680)
        self.setMinimumSize(900, 520)

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 20)
        root.setSpacing(14)

        title = QLabel("Исходное название и название товара")
        title.setObjectName("PageHeaderTitle")
        subtitle = QLabel(
            "Слева сохранена дословная строка из накладной. Справа — название для каталога и SIGMA. "
            "Правь только правую колонку; исходник никогда не меняется."
        )
        subtitle.setObjectName("PageHeaderSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(title)
        root.addWidget(subtitle)

        self.table = RoundedTableWidget(0, 4)
        self.table.setObjectName("ReceiptTable")
        self.table.setProperty("saiInlineEdit", True)
        self.table.setHorizontalHeaderLabels(["№", "Дословно в документе", "Название товара", "Статус"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(
            QAbstractItemView.EditTrigger.DoubleClicked
            | QAbstractItemView.EditTrigger.SelectedClicked
            | QAbstractItemView.EditTrigger.EditKeyPressed
        )
        self.table.setWordWrap(True)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        root.addWidget(self.table, 1)

        action_row = QHBoxLayout()
        action_row.setSpacing(10)
        self.reset_btn = QPushButton("Вернуть предложение SAI")
        self.reset_btn.setObjectName("SoftButton")
        self.reset_btn.setMinimumHeight(38)
        self.reset_btn.clicked.connect(self.reset_selected_to_suggestion)
        self.source_btn = QPushButton("Вернуть как в документе")
        self.source_btn.setObjectName("SoftButton")
        self.source_btn.setMinimumHeight(38)
        self.source_btn.clicked.connect(self.reset_selected_to_source)
        action_row.addWidget(self.reset_btn)
        action_row.addWidget(self.source_btn)
        action_row.addStretch(1)

        cancel = QPushButton("Отмена")
        cancel.setObjectName("SoftButton")
        cancel.setMinimumHeight(40)
        cancel.clicked.connect(self.reject)
        apply_btn = QPushButton("Применить названия")
        apply_btn.setObjectName("WorkbenchPrimaryButton")
        apply_btn.setMinimumHeight(42)
        apply_btn.clicked.connect(self.apply_names)
        action_row.addWidget(cancel)
        action_row.addWidget(apply_btn)
        root.addLayout(action_row)

        self.populate()

    def populate(self) -> None:
        self.table.setRowCount(len(self.items))
        for row, item in enumerate(self.items):
            raw = safe_str(getattr(item, "raw_name", "") or getattr(item, "name", ""))
            final = safe_str(getattr(item, "name", ""))
            status = "РУЧНАЯ ПРАВКА" if bool(getattr(item, "name_manually_edited", False)) else "ПРЕДЛОЖЕНИЕ SAI"
            values = [str(row + 1), raw, final, status]
            for col, value in enumerate(values):
                cell = QTableWidgetItem(value)
                if col != 2:
                    cell.setFlags(cell.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if col == 0:
                    cell.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if col == 2:
                    notes = list(getattr(item, "name_normalization_changes", None) or [])
                    aliases = list(getattr(item, "name_search_aliases", None) or [])
                    tip = []
                    if notes:
                        tip.append("Что изменил SAI:\n• " + "\n• ".join(notes))
                    if aliases:
                        tip.append("Поисковая расшифровка:\n" + "\n".join(aliases))
                    if tip:
                        cell.setToolTip("\n\n".join(tip))
                self.table.setItem(row, col, cell)
        self.table.resizeRowsToContents()
        for row in range(self.table.rowCount()):
            self.table.setRowHeight(row, min(130, max(54, self.table.rowHeight(row))))
        if self.items:
            self.table.selectRow(0)

    def selected_rows(self) -> List[int]:
        rows = sorted({index.row() for index in self.table.selectionModel().selectedRows()})
        if not rows and self.table.currentRow() >= 0:
            rows = [self.table.currentRow()]
        return rows

    def reset_selected_to_suggestion(self) -> None:
        for row in self.selected_rows():
            item = self.items[row]
            source = safe_str(getattr(item, "raw_name", "") or getattr(item, "name", ""))
            suggestion = sai_product_names.normalize_product_name(source).normalized or source.upper()
            self.table.item(row, 2).setText(suggestion)
            self.table.item(row, 3).setText("ПРЕДЛОЖЕНИЕ SAI")

    def reset_selected_to_source(self) -> None:
        for row in self.selected_rows():
            item = self.items[row]
            source = safe_str(getattr(item, "raw_name", "") or getattr(item, "name", ""))
            self.table.item(row, 2).setText(source.upper())
            self.table.item(row, 3).setText("КАК В ДОКУМЕНТЕ")

    def apply_names(self) -> None:
        prepared: List[str] = []
        for row in range(self.table.rowCount()):
            cell = self.table.item(row, 2)
            value = safe_str(cell.text() if cell else "")
            if not value:
                QMessageBox.warning(self, "Проверка названий", f"В строке {row + 1} пустое название.")
                self.table.setCurrentCell(row, 2)
                return
            prepared.append(value)

        changed = 0
        for row, item in enumerate(self.items):
            before = safe_str(getattr(item, "name", ""))
            source = safe_str(getattr(item, "raw_name", "") or before)
            suggested = sai_product_names.normalize_product_name(source).normalized or source.upper()
            entered = _collapse_product_name_input(prepared[row])
            if entered == suggested:
                sai_product_names.restore_normalized_name(item)
            else:
                sai_product_names.apply_manual_name(item, entered)
            if safe_str(getattr(item, "name", "")) != before:
                changed += 1
        self.changed_count = changed
        self.accept()


def _collapse_product_name_input(value: str) -> str:
    text = safe_str(value).upper().replace("\xa0", " ")
    text = re.sub(r"[\r\n\t]+", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" -–—;,")


class ConverterPage(QWidget):
    """AI-powered supplier document -> internal receipt draft."""

    def __init__(self, parent_page: "MainPage") -> None:
        super().__init__()
        self.setAcceptDrops(True)
        self.parent_page = parent_page
        self.source_paths: List[Path] = []
        self.source_path: Optional[Path] = None  # compatibility with older code
        self.result: Optional[sai_converter.ConvertResult] = None
        self.saved_sai_path: Optional[Path] = None
        self.draft_id: Optional[str] = None
        self.orientation_plan: Dict[str, List[int]] = {}
        self.orientation_confirmed = False
        self._worker_thread: Optional[threading.Thread] = None
        self._drag_generation = 0
        self._updating_name_table = False
        self._supplier_selection_manual = False
        self.ai_signals = AIInvoiceSignals(self)
        self.ai_signals.finished.connect(self._ai_finished)
        self.ai_signals.failed.connect(self._ai_failed)
        self.build_ui()
        self.scan_watch_timer = QTimer(self)
        self.scan_watch_timer.setInterval(5000)
        self.scan_watch_timer.timeout.connect(self.refresh_fresh_scan_button)
        self.scan_watch_timer.start()
        QTimer.singleShot(0, self.refresh_fresh_scan_button)
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)
        QTimer.singleShot(0, self._enable_window_drop_target)

    def _enable_window_drop_target(self) -> None:
        host = self.window()
        if isinstance(host, QWidget):
            host.setAcceptDrops(True)

    def build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.scroll = QScrollArea()
        self.scroll.setObjectName("WorkbenchScroll")
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll.setAcceptDrops(True)
        self.scroll.viewport().setAcceptDrops(True)
        outer.addWidget(self.scroll, 1)

        body = QWidget()
        body.setObjectName("WorkbenchBody")
        body.setAcceptDrops(True)
        self.scroll.setWidget(body)

        root = QVBoxLayout(body)
        root.setContentsMargins(28, 30, 28, 30)
        root.setSpacing(18)
        header_row = QHBoxLayout()
        header_row.setSpacing(14)
        header_row.addWidget(make_standard_page_header(
            "Новый привоз",
            "Загрузите накладную: SAI распознает товары, сохранит черновик и выберет сценарий приёмки.",
        ), 1)
        self.tour_btn = QPushButton("Как ввести приход?")
        self.tour_btn.setObjectName("SoftButton")
        self.tour_btn.setMinimumHeight(38)
        self.tour_btn.clicked.connect(self.start_receipt_tutorial)
        header_row.addWidget(self.tour_btn, 0, Qt.AlignmentFlag.AlignTop)
        root.addLayout(header_row)

        card = QFrame()
        card.setObjectName("WorkbenchCard")
        self.source_card = card
        card.setAcceptDrops(True)
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(22, 20, 22, 20)
        card_layout.setSpacing(12)
        section = QLabel("1. Исходные файлы")
        section.setObjectName("WorkbenchSection")
        self.source_label = QLabel("Выберите файлы в проводнике или перетащите в окно")
        self.source_label.setObjectName("WorkbenchFile")
        self.source_label.setWordWrap(True)
        card_layout.addWidget(section)
        card_layout.addWidget(self.source_label)

        options = QHBoxLayout()
        options.setSpacing(10)
        supplier_caption = QLabel("Поставщик")
        supplier_caption.setObjectName("WorkbenchFieldLabel")
        self.supplier_combo = NoWheelComboBox()
        self.supplier_combo.setObjectName("WorkbenchCombo")
        self.supplier_combo.setMinimumHeight(42)
        self.supplier_combo.setMinimumWidth(330)
        self.supplier_combo.currentIndexChanged.connect(self.supplier_selection_changed)
        options.addWidget(supplier_caption)
        options.addWidget(self.supplier_combo, 1)
        markup_caption = QLabel("Наценка %")
        markup_caption.setObjectName("WorkbenchFieldLabel")
        self.markup_edit = QLineEdit()
        self.markup_edit.setObjectName("WorkbenchInput")
        self.markup_edit.setPlaceholderText("60")
        self.markup_edit.setText("60")
        self.markup_edit.setMaximumWidth(150)
        options.addWidget(markup_caption)
        options.addWidget(self.markup_edit)
        card_layout.addLayout(options)
        self.refresh_supplier_choices(preserve_current=False)

        buttons = QHBoxLayout()
        self.choose_btn = QPushButton("Выбрать файлы")
        self.choose_btn.setObjectName("SoftButton")
        self.choose_btn.setMinimumHeight(40)
        self.choose_btn.clicked.connect(self.choose_source)
        self.fresh_scans_btn = QPushButton("Найти свежие сканы")
        self.fresh_scans_btn.setObjectName("SoftButton")
        self.fresh_scans_btn.setMinimumHeight(40)
        self.fresh_scans_btn.clicked.connect(self.find_fresh_scans)
        self.orientation_btn = QPushButton("Проверить страницы")
        self.orientation_btn.setObjectName("SoftButton")
        self.orientation_btn.setMinimumHeight(40)
        self.orientation_btn.clicked.connect(self.prepare_orientation)
        self.orientation_btn.setVisible(False)
        self.convert_btn = QPushButton("Распознать данные с ИИ")
        self.convert_btn.setObjectName("WorkbenchPrimaryButton")
        self.convert_btn.setMinimumHeight(42)
        self.convert_btn.clicked.connect(self.convert_source)
        self.convert_btn.setVisible(False)
        buttons.addWidget(self.choose_btn)
        buttons.addWidget(self.fresh_scans_btn)
        buttons.addWidget(self.orientation_btn)
        buttons.addWidget(self.convert_btn)
        buttons.addStretch(1)
        card_layout.addLayout(buttons)
        root.addWidget(card)

        preview_card = QFrame()
        preview_card.setObjectName("WorkbenchCard")
        self.preview_card = preview_card
        preview_layout = QVBoxLayout(preview_card)
        preview_layout.setContentsMargins(22, 20, 22, 20)
        preview_layout.setSpacing(12)
        result_header = QHBoxLayout()
        result_header.setSpacing(10)
        section2 = QLabel("2. Проверка результата")
        section2.setObjectName("WorkbenchSection")
        self.name_review_btn = QPushButton("Проверить названия")
        self.name_review_btn.setObjectName("SoftButton")
        self.name_review_btn.setMinimumHeight(38)
        self.name_review_btn.setVisible(False)
        self.name_review_btn.clicked.connect(self.review_product_names)
        result_header.addWidget(section2)
        result_header.addStretch(1)
        result_header.addWidget(self.name_review_btn)
        self.status_label = QLabel("")
        self.status_label.setObjectName("InlineStatus")
        self.status_label.setWordWrap(True)
        self.status_label.setVisible(False)
        preview_layout.addLayout(result_header)
        preview_layout.addWidget(self.status_label)
        self.name_edit_hint = QLabel("Названия уже приведены к стилю SAI. Дважды нажми на название, чтобы исправить одну строку, или открой общую проверку.")
        self.name_edit_hint.setObjectName("StatsSubtitle")
        self.name_edit_hint.setWordWrap(True)
        self.name_edit_hint.setVisible(False)
        preview_layout.addWidget(self.name_edit_hint)

        self.table = RoundedTableWidget(0, 9)
        self.table.setObjectName("ReceiptTable")
        self.table.setProperty("saiInlineEdit", True)
        self.table.setHorizontalHeaderLabels(["#", "ШК", "Кол-во", "Ед.", "Закуп", "Продажа", "Наименование", "Основа цены", "Проверить"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(
            QAbstractItemView.EditTrigger.DoubleClicked
            | QAbstractItemView.EditTrigger.SelectedClicked
            | QAbstractItemView.EditTrigger.EditKeyPressed
        )
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.itemChanged.connect(self.product_name_item_changed)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setHighlightSections(False)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        self.table.setMinimumHeight(380)
        preview_layout.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        bottom.addStretch(1)
        self.continue_btn = QPushButton("Продолжить")
        self.continue_btn.setObjectName("WorkbenchPrimaryButton")
        self.continue_btn.setMinimumHeight(42)
        self.continue_btn.clicked.connect(self.continue_receipt)
        self.continue_btn.setEnabled(False)
        self.continue_btn.setVisible(False)
        self.continue_btn.setText("Продолжить")
        bottom.addWidget(self.continue_btn)
        preview_layout.addLayout(bottom)
        root.addWidget(preview_card, 1)

        self.drop_overlay = QFrame(self)
        self.drop_overlay.setObjectName("InvoiceDropOverlay")
        self.drop_overlay.setAttribute(Qt.WA_StyledBackground, True)
        # The visual hint must never become the drag target itself. Otherwise
        # Qt can keep sending drag events to the overlay and leave it stuck.
        self.drop_overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.drop_overlay.setAcceptDrops(False)
        overlay_layout = QVBoxLayout(self.drop_overlay)
        overlay_layout.setContentsMargins(24, 24, 24, 24)
        overlay_layout.addStretch(1)
        plus = DropPlusIndicator()
        title = QLabel("Добавить файлы")
        title.setObjectName("InvoiceDropTitle")
        title.setAlignment(Qt.AlignCenter)
        title.setWordWrap(False)
        title.setMinimumWidth(280)
        overlay_layout.addWidget(plus, 0, Qt.AlignHCenter)
        overlay_layout.addSpacing(16)
        overlay_layout.addWidget(title, 0, Qt.AlignHCenter)
        overlay_layout.addStretch(1)
        self.drop_overlay.hide()

    @property
    def _tutorial_state_path(self) -> Path:
        return USER_DATA_DIR / "guided_tutorials.json"

    def _receipt_tutorial_seen(self) -> bool:
        try:
            payload = json.loads(self._tutorial_state_path.read_text(encoding="utf-8"))
            return bool(payload.get("receipt_entry_v1")) if isinstance(payload, dict) else False
        except Exception:
            return False

    def _remember_receipt_tutorial(self) -> None:
        path = self._tutorial_state_path
        try:
            payload = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}
        payload["receipt_entry_v1"] = True
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def maybe_start_receipt_tutorial(self) -> None:
        if self._receipt_tutorial_seen():
            return
        QTimer.singleShot(220, self.start_receipt_tutorial)

    def _finish_receipt_tutorial(self) -> None:
        self._guided_tour = None
        self._remember_receipt_tutorial()

    def start_receipt_tutorial(self) -> None:
        existing = getattr(self, "_guided_tour", None)
        if existing is not None:
            try:
                if existing.isVisible():
                    existing.raise_()
                    return
            except RuntimeError:
                self._guided_tour = None
        host = self.window()
        if not isinstance(host, QWidget) or not self.isVisible():
            return
        steps = [
            GuidedTourStep(
                self.choose_btn,
                "Добавьте накладную",
                "Нажмите «Выбрать файлы» или просто перетащите PDF, изображение, таблицу либо ZIP из Диадока в окно SAI.",
            ),
            GuidedTourStep(
                self.fresh_scans_btn,
                "Можно забрать свежие сканы",
                "Если сканер сохраняет файлы в настроенную папку, SAI найдёт последнюю серию сканов и откроет обычную проверку страниц.",
            ),
            GuidedTourStep(
                self.supplier_combo,
                "Поставщик и наценка",
                "Поставщика можно оставить для определения по накладной или выбрать вручную. Справа задаётся наценка для расчёта продажных цен.",
            ),
            GuidedTourStep(
                self.preview_card,
                "Проверьте результат",
                "После распознавания здесь появятся товары. Сверьте названия, количество, закупку и продажу. Название исправляется двойным нажатием.",
            ),
            GuidedTourStep(
                lambda: self.continue_btn if self.continue_btn.isVisible() else self.preview_card,
                "Продолжайте только после проверки",
                "Когда данные готовы, внизу появится синяя кнопка «Продолжить». Затем SAI покажет поставщика, дату и весь рабочий процесс прихода.",
            ),
        ]
        self._guided_tour = GuidedTourOverlay(host, steps, on_finished=self._finish_receipt_tutorial)
        self._guided_tour.start()

    @staticmethod
    def _drop_local_files(event) -> List[Path]:
        mime = event.mimeData()
        if not mime or not mime.hasUrls():
            return []
        result: List[Path] = []
        for url in mime.urls():
            if not url.isLocalFile():
                continue
            path = Path(url.toLocalFile())
            if path.is_file():
                result.append(path)
        return result

    def _event_is_inside_sai_window(self, obj: object) -> bool:
        if not self.isVisible():
            return False
        try:
            if not isinstance(obj, QWidget) or obj.window() is not self.window():
                return False
            overlay = getattr(self, "drop_overlay", None)
            if overlay is not None and (obj is overlay or overlay.isAncestorOf(obj)):
                return False
            return True
        except Exception:
            return False

    def eventFilter(self, obj, event):  # noqa: N802 - Qt override name
        try:
            if self._event_is_inside_sai_window(obj):
                event_type = event.type()
                if event_type in (QEvent.DragEnter, QEvent.DragMove):
                    paths = self._drop_local_files(event)
                    if paths:
                        self._drag_generation += 1
                        self._show_drop_overlay()
                        event.acceptProposedAction()
                        return True
                elif event_type == QEvent.Drop:
                    paths = self._drop_local_files(event)
                    self._drag_generation += 1
                    self._hide_drop_overlay()
                    if paths:
                        self.set_source_paths(paths)
                        event.acceptProposedAction()
                        return True
                elif event_type == QEvent.DragLeave:
                    self._drag_generation += 1
                    self._hide_drop_overlay()
        except Exception:
            self._hide_drop_overlay()
        return super().eventFilter(obj, event)

    def _hide_overlay_if_stale(self, generation: int) -> None:
        if generation == self._drag_generation:
            self._hide_drop_overlay()

    def _show_drop_overlay(self) -> None:
        host = self.window()
        if not isinstance(host, QWidget):
            host = self
        if self.drop_overlay.parentWidget() is not host:
            self.drop_overlay.setParent(host)
        self.drop_overlay.setGeometry(host.rect())
        self.drop_overlay.show()
        self.drop_overlay.raise_()

    def _hide_drop_overlay(self) -> None:
        if getattr(self, "drop_overlay", None) is not None:
            self.drop_overlay.hide()

    def hideEvent(self, event):  # noqa: N802 - Qt override name
        self._hide_drop_overlay()
        super().hideEvent(event)

    def choose_source(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self,
            "Выберите файлы одной накладной",
            str(Path.home() / "Desktop"),
            "Читаемые документы (*.zip *.pdf *.png *.jpg *.jpeg *.webp *.gif *.xlsx *.xlsm *.xls *.csv *.tsv *.txt *.md *.xml *.json *.html *.htm *.doc *.docx *.rtf *.odt *.ppt *.pptx *.ods *.iif *.xlt *.xltx);;ZIP Контур.Диадока (*.zip);;PDF и изображения (*.pdf *.png *.jpg *.jpeg *.webp *.gif);;Таблицы (*.xlsx *.xlsm *.xls *.csv *.tsv *.ods *.xlt *.xltx);;Все файлы (*.*)",
        )
        if paths:
            self.set_source_paths([Path(path) for path in paths])

    def configured_scan_folder(self, *, ask_if_missing: bool = False) -> Optional[Path]:
        configured = safe_str(load_private_config().get("invoice_scan_folder"))
        folder = Path(configured).expanduser() if configured else None
        if folder is not None and folder.is_dir():
            return folder
        if not ask_if_missing:
            return None
        selected = QFileDialog.getExistingDirectory(
            self,
            "Выберите папку, куда сканер сохраняет накладные",
            configured or str(Path.home() / "Documents"),
        )
        if not selected:
            return None
        folder = Path(selected).resolve()
        save_private_config_patch({
            "invoice_scan_folder": str(folder),
            "invoice_scan_last_selected_ns": 0,
        })
        return folder

    def fresh_scan_batch(self, folder: Path) -> list[sai_scan_inbox.ScanCandidate]:
        cfg = load_private_config()
        try:
            marker = int(cfg.get("invoice_scan_last_selected_ns") or 0)
        except (TypeError, ValueError):
            marker = 0
        return sai_scan_inbox.latest_scan_batch(folder, newer_than_ns=marker)

    def refresh_fresh_scan_button(self) -> None:
        button = getattr(self, "fresh_scans_btn", None)
        if button is None:
            return
        folder = self.configured_scan_folder()
        if folder is None:
            button.setText("Найти свежие сканы")
            button.setToolTip("Сначала SAI предложит выбрать папку сканера.")
            return
        batch = self.fresh_scan_batch(folder)
        count = len(batch)
        button.setText(f"Найти свежие сканы · {count}" if count else "Найти свежие сканы")
        button.setToolTip(
            f"Папка: {folder}\n"
            + (f"Готова последняя серия: {count} файл(а)." if count else "Новых завершённых сканов пока нет.")
        )

    def find_fresh_scans(self) -> None:
        folder = self.configured_scan_folder(ask_if_missing=True)
        if folder is None:
            return
        batch = self.fresh_scan_batch(folder)
        if not batch:
            QMessageBox.information(
                self,
                "Свежие сканы",
                "Новых PDF или изображений за последние сутки пока нет.\n\n"
                "SAI подождёт, пока сканер полностью допишет файл, и обновит кнопку автоматически.",
            )
            self.refresh_fresh_scan_button()
            return
        paths = [item.path for item in batch]
        self.set_source_paths(paths)
        if self.source_paths:
            save_private_config_patch({
                "invoice_scan_folder": str(folder),
                "invoice_scan_last_selected_ns": sai_scan_inbox.batch_marker(batch),
            })
        self.refresh_fresh_scan_button()

    def _supplier_hint(self) -> str:
        selected = self.selected_supplier_record()
        if selected:
            return safe_str(selected.get("name"))
        if self.result and self.result.supplier:
            return safe_str(self.result.supplier)
        if self.source_paths:
            return safe_str(sai_converter.supplier_from_filename(self.source_paths[0]))
        return ""

    def supplier_source_rows(self) -> List[Dict[str, Any]]:
        workbench = getattr(self.parent_page, "workbench_page", None)
        suppliers = list(getattr(workbench, "supplier_list", []) or []) if workbench is not None else []
        if not suppliers and workbench is not None:
            suppliers = list(workbench.load_supplier_cache() or [])
        return [row for row in suppliers if isinstance(row, dict) and safe_str(row.get("name"))]

    def refresh_supplier_choices(self, *, preserve_current: bool = True) -> None:
        combo = getattr(self, "supplier_combo", None)
        if combo is None:
            return
        current = self.selected_supplier_record() if preserve_current else {}
        current_id = safe_str(current.get("id"))
        current_name = safe_str(current.get("name"))
        combo.blockSignals(True)
        combo.clear()
        combo.addItem("Определить по накладной", {})
        selected_index = 0
        for supplier in sorted(self.supplier_source_rows(), key=lambda row: safe_str(row.get("name")).casefold()):
            name = safe_str(supplier.get("name"))
            supplier_id = safe_str(supplier.get("id"))
            inn = safe_str(supplier.get("inn") or supplier.get("taxpayerIdentificationNumber"))
            label = f"{name} · ИНН {inn}" if inn else name
            data = {"id": supplier_id, "name": name, "inn": inn}
            combo.addItem(label, data)
            if (current_id and supplier_id == current_id) or (not current_id and current_name and name.casefold() == current_name.casefold()):
                selected_index = combo.count() - 1
        combo.setCurrentIndex(selected_index)
        combo.blockSignals(False)

    def selected_supplier_record(self) -> Dict[str, Any]:
        combo = getattr(self, "supplier_combo", None)
        if combo is None:
            return {}
        data = combo.currentData()
        return dict(data) if isinstance(data, dict) and safe_str(data.get("name")) else {}

    def select_recognized_supplier(self, name: str) -> Dict[str, Any]:
        combo = getattr(self, "supplier_combo", None)
        if combo is None or not safe_str(name):
            return {}
        wanted = WorkbenchPage.normalize_supplier_match_name(name)
        matches: List[int] = []
        for index in range(1, combo.count()):
            data = combo.itemData(index)
            if isinstance(data, dict) and WorkbenchPage.normalize_supplier_match_name(data.get("name")) == wanted:
                matches.append(index)
        if len(matches) != 1:
            return {}
        combo.blockSignals(True)
        combo.setCurrentIndex(matches[0])
        combo.blockSignals(False)
        data = combo.currentData()
        return dict(data) if isinstance(data, dict) else {}

    def supplier_selection_changed(self, index: int) -> None:
        self._supplier_selection_manual = index > 0
        if not self.result:
            return
        selected = self.selected_supplier_record()
        if not selected:
            return
        self.result.supplier = safe_str(selected.get("name"))
        validation = dict(self.result.validation or {})
        validation["supplier_selection"] = {
            "id": safe_str(selected.get("id")),
            "name": safe_str(selected.get("name")),
            "source": "operator",
        }
        self.result.validation = validation
        self.persist_internal_draft("ai_review")

    def _can_start_ai(self) -> bool:
        if not self.source_paths:
            return False
        if sai_page_orientation.has_visual_sources(self.source_paths):
            return bool(self.orientation_confirmed)
        return True

    def _refresh_ai_action_visibility(self) -> None:
        self.convert_btn.setVisible(self._can_start_ai())

    def _reset_after_source_change(self) -> None:
        self.result = None
        self.saved_sai_path = None
        self.draft_id = None
        self.continue_btn.setEnabled(False)
        self.continue_btn.setVisible(False)
        self.continue_btn.setText("Продолжить")
        self.name_review_btn.setVisible(False)
        self.name_edit_hint.setVisible(False)
        self.choose_btn.setVisible(True)
        self.choose_btn.setEnabled(True)
        self.convert_btn.setText("Распознать данные с ИИ")
        self.convert_btn.setEnabled(True)
        self._refresh_ai_action_visibility()

    def set_source_paths(self, raw_paths: object) -> None:
        # A successful drop or any alternate source-selection path must always
        # clear the visual drag hint, even if Qt skipped the matching Drop event.
        self._hide_drop_overlay()
        if self._worker_thread is not None and self._worker_thread.is_alive():
            QMessageBox.information(self, "Новый привоз", "Дождись завершения текущего распознавания.")
            return
        accepted: List[Path] = []
        rejected: List[str] = []
        seen = set()
        for raw in list(raw_paths or []):
            path = Path(raw).expanduser()
            try:
                path = path.resolve()
            except Exception:
                path = Path(raw)
            key = str(path).lower()
            if key in seen:
                continue
            seen.add(key)
            if not path.is_file() or path.suffix.lower() not in sai_openai_invoice.SUPPORTED_EXTENSIONS:
                rejected.append(path.name or str(path))
                continue
            accepted.append(path)
        if not accepted:
            if rejected:
                QMessageBox.information(
                    self,
                    "Новый привоз",
                    "SAI не нашёл среди выбранных файлов поддерживаемую накладную.\n\n"
                    + "Пропущено: " + ", ".join(rejected[:8]),
                )
            return
        self.source_paths = accepted
        self.source_path = self.source_paths[0]
        self.orientation_plan = {}
        has_visual = sai_page_orientation.has_visual_sources(self.source_paths)
        # Non-visual documents need no page-orientation confirmation.
        self.orientation_confirmed = not has_visual
        self._reset_after_source_change()
        if len(self.source_paths) == 1 and self.source_paths[0].suffix.lower() == ".zip":
            self.convert_btn.setText("Прочитать ZIP Диадока")
        shown = "\n".join(f"• {path.name}" for path in self.source_paths)
        self.source_label.setText(shown)
        self.orientation_btn.setVisible(has_visual)
        self.orientation_btn.setEnabled(True)
        skipped = f" Пропущено неподдерживаемых файлов: {len(rejected)}." if rejected else ""
        self.status_label.setText(
            f"Выбрано файлов: {len(self.source_paths)}. "
            + ("Сначала проверь ориентацию страниц." if has_visual else "Можно запускать распознавание.")
            + skipped
        )
        self.status_label.setVisible(True)
        self.table.setRowCount(0)
        if has_visual:
            QTimer.singleShot(0, self.prepare_orientation)

    def prepare_orientation(self) -> bool:
        if not self.source_paths or not sai_page_orientation.has_visual_sources(self.source_paths):
            self.orientation_plan = {}
            self.orientation_confirmed = True
            self._refresh_ai_action_visibility()
            return True
        try:
            dialog = PageOrientationDialog(self.source_paths, self._supplier_hint(), self)
        except Exception as exc:
            QMessageBox.critical(self, "Подготовка страниц", f"Не удалось открыть предварительный просмотр:\n{exc}")
            self.orientation_confirmed = False
            self._refresh_ai_action_visibility()
            return False
        if dialog.exec() != QDialog.Accepted:
            self.orientation_confirmed = False
            self._refresh_ai_action_visibility()
            self.status_label.setText("Ориентация страниц не подтверждена. Платный запрос не запущен.")
            self.status_label.setVisible(True)
            return False
        self.orientation_plan = dialog.orientation_plan()
        self.orientation_confirmed = True
        common = dialog.common_angle()
        supplier_hint = self._supplier_hint()
        if common is not None and supplier_hint:
            sai_page_orientation.save_supplier_preference(supplier_hint, common)
        page_count = sum(len(values) for values in self.orientation_plan.values())
        summaries = []
        for path_text, angles in self.orientation_plan.items():
            labels = [
                sai_page_orientation.angle_label(angle.get("angle") if isinstance(angle, dict) else angle)
                for angle in angles
            ]
            unique = list(dict.fromkeys(labels))
            summaries.append(f"{Path(path_text).name}: {', '.join(unique)}")
        self.status_label.setText(f"Подтверждено страниц: {page_count}. " + " · ".join(summaries))
        self.status_label.setVisible(True)
        self._refresh_ai_action_visibility()
        return True

    def convert_source(self) -> None:
        if not self.source_paths:
            QMessageBox.information(self, "Новый привоз", "Сначала выбери файлы накладной.")
            return
        if self._worker_thread is not None and self._worker_thread.is_alive():
            return
        if sai_page_orientation.has_visual_sources(self.source_paths) and not self.orientation_confirmed:
            if not self.prepare_orientation():
                return
        local_zip = len(self.source_paths) == 1 and self.source_paths[0].suffix.lower() == ".zip"
        ai_cfg = AccountService().effective_owner_ai_configuration()
        api_key = safe_str(ai_cfg.get("api_key"))
        if not api_key and not local_zip:
            QMessageBox.information(
                self, "Новый привоз",
                "ChatGPT API не подключён. Добавьте ключ владельцу Mike в отдельном приложении SAI Admin.",
            )
            self.parent_page.show_settings()
            return
        try:
            markup = float((self.markup_edit.text().strip() or "60").replace(",", "."))
        except Exception:
            markup = 60.0
            self.markup_edit.setText("60")
        args = {
            "paths": list(self.source_paths),
            "api_key": api_key,
            "model": sai_openai_invoice.quality_model(safe_str(ai_cfg.get("model"))),
            "proxy_url": safe_str(ai_cfg.get("proxy_url")),
            "api_base": safe_str(ai_cfg.get("api_base")) or sai_openai_invoice.DEFAULT_API_BASE,
            "markup_percent": markup,
            # A Diadoc ZIP contains authoritative supplier requisites. Only an
            # explicit operator choice may override them; its filename may not.
            "supplier_hint": (
                safe_str(self.selected_supplier_record().get("name"))
                if local_zip else self._supplier_hint()
            ),
            "date_hint": "",
            "invoice_hint": "",
            "orientation_plan": dict(self.orientation_plan),
        }
        self.choose_btn.setVisible(False)
        self.orientation_btn.setVisible(False)
        self.convert_btn.setText("Читаем УПД из ZIP…" if local_zip else "Распознаём данные…")
        self.convert_btn.setEnabled(False)
        self.status_label.setText(
            "SAI читает структурированный УПД локально — без ИИ и ожидания сети…"
            if local_zip else
            "ИИ обрабатывает накладную: две независимые Luna сверяют страницы, Terra получает только спорные строки…"
        )
        self.status_label.setVisible(True)
        self.result = None
        self.saved_sai_path = None
        self.draft_id = None
        self.continue_btn.setVisible(False)
        self.continue_btn.setEnabled(False)

        def worker() -> None:
            try:
                result = sai_openai_invoice.analyze_invoice(**args)
                self.ai_signals.finished.emit(result)
            except Exception as exc:
                self.ai_signals.failed.emit(str(exc))

        self._worker_thread = threading.Thread(target=worker, daemon=True)
        self._worker_thread.start()

    def _ai_finished(self, result: object) -> None:
        self.convert_btn.setText(
            "Прочитать ZIP Диадока"
            if len(self.source_paths) == 1 and self.source_paths[0].suffix.lower() == ".zip"
            else "Распознать данные с ИИ"
        )
        self.result = result if isinstance(result, sai_converter.ConvertResult) else None
        self.saved_sai_path = None
        if not self.result:
            self.status_label.setText("ИИ вернул неизвестный результат.")
            self.choose_btn.setVisible(True)
            self.convert_btn.setEnabled(True)
            self._refresh_ai_action_visibility()
            return
        selected = self.selected_supplier_record() if self._supplier_selection_manual else self.select_recognized_supplier(self.result.supplier)
        if selected:
            self.result.supplier = safe_str(selected.get("name"))
            validation = dict(self.result.validation or {})
            validation["supplier_selection"] = {
                "id": safe_str(selected.get("id")),
                "name": safe_str(selected.get("name")),
                "source": "operator" if self._supplier_selection_manual else "recognized",
            }
            self.result.validation = validation
        all_angles = {
            sai_page_orientation.normalize_angle(angle.get("angle") if isinstance(angle, dict) else angle)
            for values in self.orientation_plan.values() for angle in values
        }
        if self.result.supplier and len(all_angles) == 1:
            sai_page_orientation.save_supplier_preference(self.result.supplier, next(iter(all_angles)))
        sai_product_names.ensure_user_rules_file()
        sai_product_names.normalize_items(self.result.items)
        name_rows = sum(1 for item in self.result.items if list(getattr(item, "name_normalization_changes", None) or []))
        self.result.validation = dict(self.result.validation or {})
        self.result.validation["product_name_normalization"] = {
            "rules_version": sai_product_names.RULES_VERSION,
            "normalized_rows": name_rows,
            "manual_rows": sum(1 for item in self.result.items if bool(getattr(item, "name_manually_edited", False))),
        }
        self.persist_internal_draft("ai_review")
        self.populate_preview()
        self.name_review_btn.setVisible(True)
        self.name_edit_hint.setVisible(True)
        self.choose_btn.setVisible(False)
        self.orientation_btn.setVisible(False)
        self.convert_btn.setVisible(False)
        if list(self.result.validation.get("manual_header_fields") or []):
            self.continue_btn.setText("Ввести реквизиты и продолжить")
        elif bool(self.result.validation.get("manual_review_required")):
            self.continue_btn.setText("Принять результат ИИ")
        else:
            self.continue_btn.setText("Продолжить")
        self.continue_btn.setEnabled(True)
        self.continue_btn.setVisible(True)

    def persist_internal_draft(self, stage: str = "ai_review") -> Optional[Path]:
        """Save the recognized receipt inside SAI without exposing a Desktop file."""
        if not self.result or not self.result.items:
            return None
        try:
            meta = sai_receipt_drafts.save_result(
                self.result,
                self.source_paths,
                draft_id=self.draft_id,
                stage=stage,
                kind="ai",
            )
            if meta.get("deleted"):
                self.saved_sai_path = None
                return None
            self.draft_id = safe_str(meta.get("id")) or self.draft_id
            self.saved_sai_path = Path(safe_str(meta.get("package_path")))
            return self.saved_sai_path
        except Exception as exc:
            self.parent_page.notify(
                "Черновик",
                "Не удалось сохранить распознанную накладную внутри SAI: " + str(exc)[:180],
                "warning",
            )
            return None

    def _ai_failed(self, message: str) -> None:
        self.convert_btn.setText(
            "Прочитать ZIP Диадока"
            if len(self.source_paths) == 1 and self.source_paths[0].suffix.lower() == ".zip"
            else "Распознать данные с ИИ"
        )
        self.convert_btn.setEnabled(True)
        self._refresh_ai_action_visibility()
        self.choose_btn.setEnabled(True)
        self.choose_btn.setVisible(True)
        self.orientation_btn.setEnabled(True)
        self.orientation_btn.setVisible(sai_page_orientation.has_visual_sources(self.source_paths))
        self.name_review_btn.setVisible(False)
        self.name_edit_hint.setVisible(False)
        self.status_label.setText("Не удалось распознать накладную.")
        self.status_label.setVisible(True)
        QMessageBox.critical(self, "Новый привоз", message)

    def populate_preview(self) -> None:
        self.status_label.setVisible(True)
        result = self.result
        if not result:
            return
        self._updating_name_table = True
        self.table.blockSignals(True)
        self.table.setRowCount(len(result.items))
        widths = [42, 150, 70, 64, 88, 88, 330, 180, 210]
        for idx, width in enumerate(widths):
            self.table.setColumnWidth(idx, width)
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        for r, item in enumerate(result.items):
            vals = [
                str(r + 1),
                ", ".join(item.barcodes),
                sai_converter.format_number(item.quantity),
                item.unit,
                sai_converter.format_number(item.purchase_price),
                sai_converter.format_number(item.sale_price),
                item.name,
                item.purchase_price_source,
                ", ".join(item.issues),
            ]
            for c, val in enumerate(vals):
                twi = QTableWidgetItem(val)
                if c in (0, 2, 3, 4, 5):
                    twi.setTextAlignment(Qt.AlignCenter)
                if c != 6:
                    twi.setFlags(twi.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if c in (7, 8) and val:
                    twi.setToolTip(val)
                if c == 6:
                    tooltip_parts = []
                    if getattr(item, "raw_name", ""):
                        tooltip_parts.append("Дословно в документе:\n" + str(item.raw_name))
                    notes = list(getattr(item, "name_normalization_changes", None) or [])
                    if notes:
                        tooltip_parts.append("Что изменил SAI:\n• " + "\n• ".join(notes))
                    aliases = list(getattr(item, "name_search_aliases", None) or [])
                    if aliases:
                        tooltip_parts.append("Поисковая расшифровка:\n" + "\n".join(aliases))
                    if tooltip_parts:
                        twi.setToolTip("\n\n".join(tooltip_parts))
                self.table.setItem(r, c, twi)
        self.table.blockSignals(False)
        self._updating_name_table = False
        self.table.resizeRowsToContents()
        for row_index in range(self.table.rowCount()):
            self.table.setRowHeight(row_index, min(104, max(42, self.table.rowHeight(row_index))))
        total_buy = sum((i.quantity or 0) * (i.purchase_price or 0) for i in result.items)
        total_sale = sum((i.quantity or 0) * (i.sale_price or 0) for i in result.items)
        bad = sum(1 for i in result.items if i.issues)
        missing_barcodes = sum(1 for i in result.items if (i.quantity or 0) > 0 and not i.barcodes)
        validation = result.validation or {}
        parts = [f"Распознано строк: {len(result.items)}", f"закупка: {money(total_buy)}", f"продажа: {money(total_sale)}"]
        by_total = int(validation.get("price_from_line_total") or 0)
        by_price = int(validation.get("price_from_printed") or 0)
        if by_total:
            parts.append(f"цена по сумме строки: {by_total}")
        if by_price:
            parts.append(f"цена по колонке: {by_price}")
        document_total = float(validation.get("document_total") or 0)
        if document_total:
            parts.append(f"итог документа: {money(document_total)}")
        usage = validation.get("openai_usage") or {}
        total_tokens = int(usage.get("total_tokens") or 0) if isinstance(usage, dict) else 0
        cost = validation.get("estimated_cost_usd")
        cache_hit = bool(validation.get("cache_hit"))
        stages = validation.get("openai_stages") or []
        pass_count = len(stages) if isinstance(stages, list) else int(validation.get("quality_passes") or 0)
        if cache_hit:
            parts.append("AI: проверенный результат из локального кэша, новый расход $0")
        elif cost is not None:
            parts.append(f"AI: {pass_count or 1} этапа, ${float(cost):.4f}" + (f", {total_tokens:,} токенов" if total_tokens else ""))
            stage_costs = []
            for stage in stages if isinstance(stages, list) else []:
                stage_cost = stage.get("estimated_cost_usd")
                if stage_cost is None:
                    continue
                model_name = safe_str(stage.get("model"))
                if "luna" in model_name:
                    label = "Luna"
                elif "terra" in model_name:
                    label = "Terra"
                elif "sol" in model_name or model_name == "gpt-5.6":
                    label = "Sol"
                else:
                    label = model_name or "AI"
                stage_costs.append(f"{label} ${float(stage_cost):.4f}")
            if stage_costs:
                parts.append("этапы: " + " · ".join(stage_costs))
        elif total_tokens:
            parts.append(f"AI: {pass_count or 1} этапа, {total_tokens:,} токенов, цена модели неизвестна SAI")
        economy_shadow = validation.get("economy_shadow") or {}
        if isinstance(economy_shadow, dict) and economy_shadow.get("enabled"):
            page_count = int(economy_shadow.get("page_count") or 0)
            candidates = list(economy_shadow.get("candidate_skip_pages") or [])
            safe_candidates = list(economy_shadow.get("validated_safe_skip_pages") or [])
            false_negative = list(economy_shadow.get("material_false_negative_pages") or [])
            shadow_savings = float(economy_shadow.get("validated_savings_usd") or 0)
            if page_count:
                shadow_text = (
                    f"теневой экономрежим: кандидаты {len(candidates)}/{page_count}, "
                    f"подтверждено безопасных {len(safe_candidates)}"
                )
                if shadow_savings > 0:
                    shadow_text += f", потенциально −${shadow_savings:.4f}"
                if false_negative:
                    shadow_text += f", риск-пропусков {len(false_negative)}"
                parts.append(shadow_text)
        disagreements = int(validation.get("disagreement_count") or 0)
        if disagreements:
            parts.append(f"исправлено проверкой: {disagreements}")
        unresolved = validation.get("unresolved_rows") or []
        if unresolved:
            parts.append(f"ручная сверка: {len(unresolved)}")
        invalid_barcodes = int(validation.get("invalid_barcode_count") or 0)
        if invalid_barcodes:
            parts.append(f"ШК не подтверждены: {invalid_barcodes}")
        if missing_barcodes:
            parts.append(f"без ШК: {missing_barcodes}")
        if bad:
            parts.append(f"требуют внимания: {bad}")
        name_meta = validation.get("product_name_normalization") or {}
        if isinstance(name_meta, dict):
            normalized_rows = int(name_meta.get("normalized_rows") or 0)
            manual_rows = sum(1 for item in result.items if bool(getattr(item, "name_manually_edited", False)))
            if normalized_rows:
                parts.append(f"названия приведены в порядок: {normalized_rows}")
            if manual_rows:
                parts.append(f"названия изменены вручную: {manual_rows}")
        if result.critical_issues:
            parts.append("КРИТИЧНО: " + "; ".join(result.critical_issues[:2]))
        elif result.errors:
            parts.append("ошибки: " + "; ".join(result.errors[:3]))
        if bool(validation.get("manual_review_required")) and not bool(validation.get("manual_review_accepted")):
            parts.append("НУЖНО ТВОЁ РЕШЕНИЕ: принять результат ИИ или не использовать его")
        self.status_label.setText(" · ".join(parts))

    def review_product_names(self) -> None:
        if not self.result or not self.result.items:
            return
        dialog = ProductNameReviewDialog(self.result.items, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        self.saved_sai_path = None
        self.result.validation = dict(self.result.validation or {})
        meta = dict(self.result.validation.get("product_name_normalization") or {})
        meta["rules_version"] = sai_product_names.RULES_VERSION
        meta["normalized_rows"] = sum(1 for item in self.result.items if list(getattr(item, "name_normalization_changes", None) or []))
        meta["manual_rows"] = sum(1 for item in self.result.items if bool(getattr(item, "name_manually_edited", False)))
        self.result.validation["product_name_normalization"] = meta
        self.persist_internal_draft("ai_review")
        self.populate_preview()

    def product_name_item_changed(self, cell: QTableWidgetItem) -> None:
        if self._updating_name_table or cell is None or cell.column() != 6:
            return
        if not self.result or not (0 <= cell.row() < len(self.result.items)):
            return
        item = self.result.items[cell.row()]
        try:
            normalized = sai_product_names.apply_manual_name(item, cell.text())
        except ValueError as exc:
            QMessageBox.warning(self, "Название товара", str(exc))
            normalized = safe_str(getattr(item, "name", ""))
        self.saved_sai_path = None
        self._updating_name_table = True
        self.table.blockSignals(True)
        cell.setText(normalized)
        source = safe_str(getattr(item, "raw_name", ""))
        cell.setToolTip("Дословно в документе:\n" + source + "\n\nРУЧНАЯ ПРАВКА")
        self.table.blockSignals(False)
        self._updating_name_table = False
        self.result.validation = dict(self.result.validation or {})
        meta = dict(self.result.validation.get("product_name_normalization") or {})
        meta["rules_version"] = sai_product_names.RULES_VERSION
        meta["manual_rows"] = sum(1 for row in self.result.items if bool(getattr(row, "name_manually_edited", False)))
        self.result.validation["product_name_normalization"] = meta
        self.persist_internal_draft("ai_review")
        self.populate_preview()

    def confirm_critical_result(self) -> bool:
        if not self.result or not self.result.critical_issues:
            return True
        validation = dict(self.result.validation or {})
        if bool(validation.get("manual_review_accepted")):
            return True
        manual_review = bool(validation.get("manual_review_required"))
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        if manual_review:
            document_total = float(validation.get("document_total") or 0)
            items_total = float(validation.get("items_total") or 0)
            difference = float(validation.get("total_difference") or abs(document_total - items_total))
            reasons = list(validation.get("manual_review_reasons") or self.result.critical_issues)
            box.setWindowTitle("Решение по результату ИИ")
            box.setText(
                "Строки накладной распознаны, но их сумма не совпала с повреждённым "
                "или нечитаемым итогом документа."
            )
            details = [
                f"Сумма распознанных строк: {money(items_total)}",
                f"Итог, прочитанный в документе: {money(document_total)}",
                f"Расхождение: {money(difference)}",
                "",
                *[f"• {item}" for item in reasons[:6]],
                "",
                "Прими результат только после проверки строк в таблице.",
            ]
            box.setInformativeText("\n".join(details))
            proceed = box.addButton("Принять результат ИИ", QMessageBox.ButtonRole.AcceptRole)
            cancel = box.addButton("Не принимать", QMessageBox.ButtonRole.RejectRole)
            box.setDefaultButton(cancel)
        else:
            box.setWindowTitle("Накладная требует проверки")
            box.setText("SAI обнаружил критическое расхождение. Автоматически продолжать небезопасно.")
            box.setInformativeText("\n".join(f"• {item}" for item in self.result.critical_issues[:6]))
            proceed = box.addButton("Я проверил — продолжить", QMessageBox.ButtonRole.AcceptRole)
            cancel = box.addButton("Отмена", QMessageBox.ButtonRole.RejectRole)
            box.setDefaultButton(cancel)
        box.exec()
        accepted = box.clickedButton() is proceed
        if accepted and manual_review:
            validation["manual_review_accepted"] = True
            validation["manual_review_decision"] = {
                "decision": "accepted_by_operator",
                "accepted_at": dt.datetime.now().astimezone().isoformat(),
                "document_total": float(validation.get("document_total") or 0),
                "items_total": float(validation.get("items_total") or 0),
                "total_difference": float(validation.get("total_difference") or 0),
                "reasons": list(validation.get("manual_review_reasons") or []),
            }
            self.result.validation = validation
            self.persist_internal_draft("ai_review_accepted")
        elif manual_review:
            current = self.status_label.text().strip()
            suffix = "Результат ИИ не принят — приход не создан."
            self.status_label.setText((current + " · " + suffix) if current else suffix)
        return accepted

    def complete_missing_invoice_header(self) -> bool:
        """Collect unreadable document headers locally without another AI call."""
        if not self.result:
            return False
        validation = dict(self.result.validation or {})
        missing = list(validation.get("manual_header_fields") or [])
        if not missing:
            return True

        labels = {
            "supplier": "Поставщик",
            "invoice_date": "Дата накладной",
            "invoice_number": "Номер накладной",
        }
        dialog = QDialog(self)
        dialog.setWindowTitle("Реквизиты накладной")
        dialog.setMinimumWidth(430)
        layout = QVBoxLayout(dialog)
        title = QLabel("ИИ прочитал товары, но не разобрал реквизиты")
        title.setObjectName("SectionTitle")
        layout.addWidget(title)
        note = QLabel(
            "Впиши данные с первой страницы. Накладная повторно в ChatGPT "
            "не отправляется и дополнительная плата не списывается."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        form = QFormLayout()
        edits: Dict[str, QLineEdit] = {}
        current_values = {
            "supplier": safe_str(self.result.supplier),
            "invoice_date": safe_str(self.result.date),
            "invoice_number": safe_str(self.result.invoice_number),
        }
        for field in missing:
            edit = QLineEdit(current_values.get(field, ""))
            edit.setObjectName("WorkbenchInput")
            if field == "invoice_date":
                edit.setPlaceholderText("дд.мм.гггг")
            form.addRow(labels.get(field, field), edit)
            edits[field] = edit
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Сохранить и продолжить")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        while dialog.exec() == QDialog.Accepted:
            values = {field: edit.text().strip() for field, edit in edits.items()}
            empty = [labels.get(field, field) for field, value in values.items() if not value]
            parsed_date = sai_converter.parse_date(values.get("invoice_date", "")) if "invoice_date" in values else self.result.date
            if "invoice_date" in values and not parsed_date:
                QMessageBox.warning(dialog, "Дата накладной", "Введи дату в формате дд.мм.гггг.")
                continue
            if empty:
                QMessageBox.warning(dialog, "Реквизиты накладной", "Заполни: " + ", ".join(empty) + ".")
                continue
            if "supplier" in values:
                self.result.supplier = values["supplier"]
            if "invoice_date" in values:
                self.result.date = parsed_date
            if "invoice_number" in values:
                self.result.invoice_number = values["invoice_number"]
            validation["manual_header_fields"] = []
            validation["manual_header_completed"] = {
                "completed_at": dt.datetime.now().astimezone().isoformat(),
                "fields": list(missing),
            }
            self.result.validation = validation
            self.persist_internal_draft("ai_review")
            return True
        return False

    def save_sai_to_desktop(self) -> Optional[Path]:
        """Compatibility name: the package is now stored only in SAI drafts."""
        if not self.result or not self.result.items:
            QMessageBox.information(self, "Новый привоз", "Сначала распознай документ.")
            return None
        return self.persist_internal_draft("ai_review")

    def continue_receipt(self) -> None:
        if not self.complete_missing_invoice_header():
            return
        if not self.confirm_critical_result():
            return
        path = self.persist_internal_draft("ai_review")
        if not path:
            return
        self.parent_page.route_sai_file(Path(path))


class PriceTagsPage(PriceTagSigmaBatchMixin, QWidget):
    """Standalone price tag generator from SAI files plus manual one-by-one tags."""
    def __init__(self, parent_page: "MainPage") -> None:
        super().__init__()
        self.parent_page = parent_page
        self.sai_path: Optional[Path] = None
        self.items: List[Dict[str, Any]] = []
        self.last_pdf_path: Optional[Path] = None
        self.search_results: List[Dict[str, Any]] = []
        self.current_product: Dict[str, Any] = {}
        self.current_barcode: str = ""
        self.pending_unknown_barcode: str = ""
        self._mass_last_barcode: str = ""
        self.mass_unknown_barcodes: List[str] = []
        self._table_refreshing = False
        self._auto_barcode_applied = ""
        self._sigma_batch_job: Optional[Dict[str, Any]] = None
        self.catalog_service = shared_free_catalog_service()
        self.catalog_service.warm_catalog_cache(background=True)
        self.search_timer = QTimer(self)
        self.search_timer.setInterval(90)
        self.search_timer.setSingleShot(True)
        self.search_timer.timeout.connect(self.run_product_search)
        self.build_ui()
    def build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        scroll = QScrollArea(); scroll.setObjectName("WorkbenchScroll"); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll, 1)
        body = QWidget(); body.setObjectName("WorkbenchBody"); scroll.setWidget(body)
        root = QVBoxLayout(body); root.setContentsMargins(28, 30, 28, 30); root.setSpacing(18)

        root.addWidget(make_standard_page_header(
            "Ценники",
            "Быстро найди товар, проверь данные и отправь готовый список на печать.",
        ))

        manual = QFrame(); manual.setObjectName("WorkbenchCard")
        ml = QGridLayout(manual); ml.setContentsMargins(22, 20, 22, 20); ml.setHorizontalSpacing(14); ml.setVerticalSpacing(10)
        mode_row = QHBoxLayout(); mode_row.setSpacing(10)
        mtitle = QLabel("Добавить один ценник"); mtitle.setObjectName("WorkbenchSection")
        self.mass_scan_switch = SaiToggleSwitch()
        self.mass_scan_switch.setToolTip("Включить непрерывное сканирование штрихкодов без нажатия Enter")
        mass_title = QLabel("Массовое сканирование ШК"); mass_title.setObjectName("WorkbenchSection")
        mode_row.addWidget(mtitle); mode_row.addWidget(self.mass_scan_switch); mode_row.addWidget(mass_title); mode_row.addStretch(1)
        ml.addLayout(mode_row, 0, 0, 1, 4)
        self.product_field_label = QLabel("Товар")
        ml.addWidget(self.product_field_label, 1, 0, 1, 4)
        self.name_edit = QLineEdit(); self.name_edit.setObjectName("WorkbenchInput"); self.name_edit.setPlaceholderText("Наименование / ШК / артикул")
        self.name_edit.textChanged.connect(lambda *_: self.search_timer.start())
        self.name_edit.returnPressed.connect(self.accept_name_input)
        ml.addWidget(self.name_edit, 2, 0, 1, 4)
        self.search_popup = SuggestionPopup(body, self.select_search_row)

        self.barcode_status = QLabel("")
        self.barcode_status.setObjectName("StatsSubtitle")
        self.barcode_status.setVisible(False)
        self.add_missing_barcode_btn = QPushButton("ШК нет в каталоге ⇒ Добавить")
        self.add_missing_barcode_btn.setObjectName("SoftButton")
        self.add_missing_barcode_btn.setMinimumHeight(36)
        self.add_missing_barcode_btn.setVisible(False)
        self.add_missing_barcode_btn.clicked.connect(self.add_missing_barcode)
        self.barcode_state_wrap = QWidget(); barcode_state_row = QHBoxLayout(self.barcode_state_wrap)
        barcode_state_row.setContentsMargins(0, 0, 0, 0)
        barcode_state_row.addWidget(self.barcode_status)
        barcode_state_row.addWidget(self.add_missing_barcode_btn)
        barcode_state_row.addStretch(1)
        ml.addWidget(self.barcode_state_wrap, 3, 0, 1, 4)
        self.mass_unknown_panel = QFrame(); self.mass_unknown_panel.setObjectName("MassUnknownPanel")
        unknown_layout = QVBoxLayout(self.mass_unknown_panel); unknown_layout.setContentsMargins(14, 11, 14, 11); unknown_layout.setSpacing(5)
        self.mass_unknown_title = QLabel("Не найденные ШК · 0"); self.mass_unknown_title.setObjectName("MassUnknownTitle")
        self.mass_unknown_text = QLabel("Пока нет"); self.mass_unknown_text.setObjectName("StatsSubtitle"); self.mass_unknown_text.setWordWrap(True)
        unknown_layout.addWidget(self.mass_unknown_title); unknown_layout.addWidget(self.mass_unknown_text)
        ml.addWidget(self.mass_unknown_panel, 4, 0, 5, 4)
        self.accent_title = QLabel("ВАЖНОЕ ОТЛИЧИЕ · необязательно")
        self.accent_title.setObjectName("ImportantAccentLabel")
        ml.addWidget(self.accent_title, 4, 0, 1, 4)
        self.accent_edit = QLineEdit(); self.accent_edit.setObjectName("WorkbenchInput")
        self.accent_edit.setPlaceholderText("Например: 650 МЛ, БЕЛЫЙ, УСИЛЕННЫЙ")
        self.accent_edit.setMaxLength(80)
        ml.addWidget(self.accent_edit, 5, 0, 1, 4)
        self.price_field_label = QLabel("Цена"); ml.addWidget(self.price_field_label, 6, 0)
        self.price_edit = QLineEdit(); self.price_edit.setObjectName("WorkbenchInput"); self.price_edit.setPlaceholderText("цена продажи")
        self.price_edit.returnPressed.connect(self.add_manual_tag)
        ml.addWidget(self.price_edit, 7, 0)
        self.unit_field_label = QLabel("Ед."); ml.addWidget(self.unit_field_label, 6, 1)
        self.unit_combo = NoWheelComboBox(); self.unit_combo.setObjectName("WorkbenchCombo"); self.unit_combo.addItems(["штука", "кг", "г", "м", "пара"])
        ml.addWidget(self.unit_combo, 7, 1)
        btn_row = QHBoxLayout(); btn_row.setSpacing(10)
        self.manual_add_btn = QPushButton("Добавить")
        self.manual_add_btn.setObjectName("WorkbenchPrimaryButton"); self.manual_add_btn.setMinimumHeight(42); self.manual_add_btn.clicked.connect(self.add_manual_tag)
        self.manual_clear_btn = QPushButton("Очистить")
        self.manual_clear_btn.setObjectName("SoftButton"); self.manual_clear_btn.setMinimumHeight(40); self.manual_clear_btn.clicked.connect(self.clear_manual_form)
        btn_row.addWidget(self.manual_add_btn); btn_row.addWidget(self.manual_clear_btn); btn_row.addStretch(1)
        self.manual_button_wrap = QWidget(); self.manual_button_wrap.setLayout(btn_row)
        self.manual_button_wrap.layout().setContentsMargins(0, 0, 0, 0)
        ml.addWidget(self.manual_button_wrap, 8, 0, 1, 4)
        ml.setColumnStretch(0, 1); ml.setColumnStretch(1, 1); ml.setColumnStretch(2, 2); ml.setColumnStretch(3, 2)
        root.addWidget(manual)
        mass_cfg = load_private_config()
        self.mass_scan_switch.setChecked(bool(mass_cfg.get("price_tags_mass_scan_mode", False)))
        self.mass_scan_switch.stateChanged.connect(self.mass_scan_mode_changed)

        preview = QFrame(); preview.setObjectName("WorkbenchCard")
        pl = QVBoxLayout(preview); pl.setContentsMargins(22, 20, 22, 20); pl.setSpacing(10)
        phead = QHBoxLayout(); phead.setSpacing(10)
        ptitle = QLabel("Что попадёт на ценники")
        ptitle.setObjectName("WorkbenchSection")
        cfg = load_private_config()
        saved_mode = safe_str(cfg.get("price_tags_print_mode")).lower()
        if saved_mode not in {"off", "a4", "thermal"}:
            saved_mode = "thermal" if bool(cfg.get("price_tags_use_thermal_printer", False)) else "a4"
        try:
            saved_copies = max(1, min(99, int(cfg.get("price_tags_print_copies") or 1)))
        except Exception:
            saved_copies = 1
        self.price_tags_print_mode_group = QButtonGroup(self); self.price_tags_print_mode_group.setExclusive(True)
        self.price_tags_print_mode_buttons: Dict[str, QPushButton] = {}
        for mode, text in (("off", "Не печатать"), ("a4", "Печатать"), ("thermal", "Термо")):
            button = QPushButton(text); button.setObjectName("PrintModeOption"); button.setCheckable(True)
            button.setProperty("mode", mode); button.setChecked(mode == saved_mode)
            button.clicked.connect(self.price_tags_print_mode_changed)
            self.price_tags_print_mode_group.addButton(button); self.price_tags_print_mode_buttons[mode] = button
        self.price_tags_copy_wrap = QWidget(); copies_layout = QHBoxLayout(self.price_tags_copy_wrap)
        copies_layout.setContentsMargins(2, 0, 2, 0); copies_layout.setSpacing(5)
        copies_title = QLabel("Количество"); copies_title.setObjectName("StatsSubtitle")
        self.price_tags_copy_minus = QPushButton("−"); self.price_tags_copy_minus.setObjectName("QuantityStepButton")
        self.price_tags_copy_value = QLabel(str(saved_copies)); self.price_tags_copy_value.setObjectName("QuantityValue")
        self.price_tags_copy_wrap.setToolTip("Количество экземпляров для каждого товара в списке")
        self.price_tags_copy_value.setAlignment(Qt.AlignCenter); self.price_tags_copy_value.setMinimumWidth(30)
        self.price_tags_copy_plus = QPushButton("+"); self.price_tags_copy_plus.setObjectName("QuantityStepButton")
        self.price_tags_copy_minus.clicked.connect(lambda: self.change_price_tags_copies(-1))
        self.price_tags_copy_plus.clicked.connect(lambda: self.change_price_tags_copies(1))
        copies_layout.addWidget(copies_title); copies_layout.addWidget(self.price_tags_copy_minus); copies_layout.addWidget(self.price_tags_copy_value); copies_layout.addWidget(self.price_tags_copy_plus)
        self.print_all_btn = QPushButton("Обновить SIGMA и напечатать")
        self.print_all_btn.setObjectName("WorkbenchPrimaryButton")
        self.print_all_btn.setMinimumHeight(40)
        self.print_all_btn.setEnabled(False)
        self.print_all_btn.clicked.connect(self.print_price_tags_now)
        phead.addWidget(ptitle)
        phead.addStretch(1)
        for mode in ("off", "a4", "thermal"):
            phead.addWidget(self.price_tags_print_mode_buttons[mode])
        phead.addSpacing(6)
        phead.addWidget(self.price_tags_copy_wrap)
        phead.addSpacing(8)
        phead.addWidget(self.print_all_btn)
        self.table = RoundedTableWidget(0, 6)
        self.table.setObjectName("ReceiptTable")
        self.table.setProperty("saiInlineEdit", True)
        self.table.setHorizontalHeaderLabels(["Товар", "ВАЖНО", "ШК", "Цена", "Ед.", ""])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(
            QAbstractItemView.EditTrigger.SelectedClicked
            | QAbstractItemView.EditTrigger.DoubleClicked
            | QAbstractItemView.EditTrigger.EditKeyPressed
        )
        self.table.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Fixed)
        self.table.setColumnWidth(1, 178)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Fixed)
        self.table.setColumnWidth(3, 94)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Fixed)
        self.table.setColumnWidth(4, 82)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.Fixed)
        self.table.setColumnWidth(5, 44)
        self.table.setMinimumHeight(320)
        self.table.itemSelectionChanged.connect(self.update_price_tag_preview)
        self.table.itemChanged.connect(self.price_tag_item_changed)
        self.price_tag_preview = QLabel("Предпросмотр ценника появится здесь")
        self.price_tag_preview.setObjectName("BarcodePreview")
        self.price_tag_preview.setAlignment(Qt.AlignCenter)
        self.price_tag_preview.setMinimumHeight(300)
        self.price_tag_preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.status_label = QLabel(
            "Собери список и поправь названия или цены. "
            "Перед печатью SAI обновит и проверит все карточки SIGMA."
        )
        self.status_label.setObjectName("InlineStatus")
        self.status_label.setWordWrap(True)
        pl.addLayout(phead); pl.addWidget(self.table, 1); pl.addWidget(self.price_tag_preview); pl.addWidget(self.status_label)
        root.addWidget(preview, 1)
        root.addStretch(1)
        self.price_tags_print_mode_changed(persist=False)
        self.mass_scan_mode_changed(persist=False)

    def mass_scan_mode_changed(self, *_args, persist: bool = True) -> None:
        enabled = bool(self.mass_scan_switch.isChecked())
        for widget in (
            self.accent_title, self.accent_edit, self.price_field_label, self.price_edit,
            self.unit_field_label, self.unit_combo, self.manual_button_wrap,
        ):
            widget.setVisible(not enabled)
        self.barcode_state_wrap.setVisible(not enabled)
        self.mass_unknown_panel.setVisible(enabled)
        self.product_field_label.setText("Штрихкод" if enabled else "Товар")
        self.clear_manual_form()
        if enabled:
            self.refresh_mass_unknown_codes()
            QTimer.singleShot(0, self.name_edit.setFocus)
        if persist:
            save_private_config_patch({"price_tags_mass_scan_mode": enabled})

    def refresh_mass_unknown_codes(self) -> None:
        count = len(self.mass_unknown_barcodes)
        self.mass_unknown_title.setText(f"Не найденные ШК · {count}")
        self.mass_unknown_text.setText(
            "Пока нет" if not count
            else "\n".join(f"{code}  —  не найден" for code in self.mass_unknown_barcodes[-12:])
        )

    def finish_mass_scan(self, placeholder: str) -> None:
        self.search_timer.stop(); self.search_popup.hide()
        self.current_product = {}; self.current_barcode = ""; self.pending_unknown_barcode = ""
        self.name_edit.blockSignals(True); self.name_edit.clear(); self.name_edit.blockSignals(False)
        self.name_edit.setPlaceholderText(placeholder)
        self._auto_barcode_applied = ""
        QTimer.singleShot(0, self.name_edit.setFocus)

    def record_mass_unknown_barcode(self, barcode: str) -> None:
        code = re.sub(r"\D+", "", safe_str(barcode))
        if code and code not in self.mass_unknown_barcodes:
            self.mass_unknown_barcodes.append(code)
        self.refresh_mass_unknown_codes()
        self.finish_mass_scan("Не найден. Сканируйте следующий штрихкод")

    def add_mass_scanned_product(self, product: Dict[str, Any], scanned_barcode: str) -> bool:
        """Add one exact catalog match and immediately re-arm the scanner field."""
        barcode = re.sub(r"\D+", "", safe_str(scanned_barcode))
        name = safe_str(product.get("name")).upper()
        price = _free_money_float(product.get("price") or 0)
        if not name or not barcode or price <= 0:
            self.record_mass_unknown_barcode(barcode)
            return False
        catalog_barcodes = [safe_str(value) for value in (product.get("barcodes") or ()) if safe_str(value)]
        if barcode not in catalog_barcodes:
            catalog_barcodes.insert(0, barcode)
        before = len(self.items)
        self.items = self.merge_price_items(self.items + [{
            "name": name, "barcode": barcode, "price": price,
            "unit": _free_normalize_unit(product.get("unit") or "штука"),
            "accent_text": "", "manual": True,
            "sigma_product_id": safe_str(product.get("id")),
            "vendor_code": safe_str(product.get("vendor_code")),
            "catalog_barcodes": catalog_barcodes,
        }])
        self.last_pdf_path = None
        self.populate_preview()
        added = len(self.items) > before
        self._mass_last_barcode = barcode
        prefix = "Добавлен" if added else "Уже был в списке"
        self.finish_mass_scan(f"{prefix}: {name[:38]}. Сканируйте следующий")
        return added

    def price_tag_print_mode(self) -> str:
        for mode, button in getattr(self, "price_tags_print_mode_buttons", {}).items():
            if button.isChecked():
                return mode
        return "off"

    def price_tags_print_copies(self) -> int:
        try:
            return max(1, min(99, int(self.price_tags_copy_value.text())))
        except Exception:
            return 1

    def change_price_tags_copies(self, delta: int) -> None:
        value = max(1, min(99, self.price_tags_print_copies() + int(delta)))
        self.price_tags_copy_value.setText(str(value))
        save_private_config_patch({"price_tags_print_copies": value})

    def price_tags_print_mode_changed(self, *_args, persist: bool = True) -> None:
        mode = self.price_tag_print_mode()
        self.price_tags_copy_wrap.setVisible(mode != "off")
        self.print_all_btn.setText("Обновить SIGMA" if mode == "off" else "Обновить SIGMA и напечатать")
        if persist:
            save_private_config_patch({
                "price_tags_print_mode": mode,
                "price_tags_use_thermal_printer": mode == "thermal",
            })
        descriptions = {
            "off": "Цены и названия обновятся в SIGMA без печати.",
            "a4": "После подтверждения SIGMA ценники сразу уйдут на обычный принтер.",
            "thermal": "После подтверждения SIGMA ценники сразу уйдут на термопринтер.",
        }
        self.status_label.setText(descriptions[mode])
    def choose_xml(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Выберите SAI-файл",
            str(desktop_dir()),
            "SAI Package (*.sai);;Все SAI-файлы (*.sai *.xml *.xlsx *.xlsm);;Старый SAI XML (*.xml);;Excel (*.xlsx *.xlsm);;Все файлы (*.*)",
        )
        if not path:
            return
        self.set_sai_file(Path(path))
    def set_sai_file(self, path: Path) -> None:
        self.sai_path = Path(path)
        self.last_pdf_path = None
        try:
            loaded = read_sai_price_items(self.sai_path)
            self.items = self.merge_price_items(loaded + [i for i in self.items if i.get("manual")])
            self.populate_preview()
            self.status_label.setText(f"Добавлено из SAI-файла: {len(self.items)} позиций.")
        except Exception as exc:
            self.items = [i for i in self.items if i.get("manual")]
            self.populate_preview()
            self.status_label.setText(f"Не удалось прочитать SAI-файл: {exc}")
    def merge_price_items(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        seen: Dict[tuple[Any, ...], int] = {}
        for item in rows:
            name = safe_str(item.get("name"))
            barcode = safe_str(item.get("barcode"))
            price = _price_tag_num(item.get("price"))
            unit = _price_tag_unit_text(item.get("unit"))
            accent_text = safe_str(item.get("accent_text") or item.get("price_tag_accent"))
            key = (_free_norm(name), barcode, round(price, 2), _free_norm(unit), _free_norm(accent_text))
            if not name:
                continue
            row = dict(item)
            row.update({"name": name, "barcode": barcode, "price": price, "unit": unit, "accent_text": accent_text})
            if key in seen:
                existing = out[seen[key]]
                if not safe_str(existing.get("sigma_product_id")) and safe_str(row.get("sigma_product_id")):
                    existing.update({
                        "sigma_product_id": row.get("sigma_product_id"),
                        "vendor_code": row.get("vendor_code"),
                        "catalog_barcodes": row.get("catalog_barcodes"),
                    })
                continue
            seen[key] = len(out)
            out.append(row)
        return out
    def populate_preview(self) -> None:
        current_row = self.table.currentRow()
        self._table_refreshing = True
        try:
            self.table.blockSignals(True)
            self.table.setRowCount(len(self.items))
            self.table.clearContents()
            for r, item in enumerate(self.items):
                values = [
                    safe_str(item.get("name")),
                    safe_str(item.get("accent_text") or item.get("price_tag_accent")),
                    safe_str(item.get("barcode")),
                    _price_tag_price_text(item.get("price")),
                    _price_tag_unit_text(item.get("unit")),
                ]
                for c, value in enumerate(values):
                    twi = QTableWidgetItem(value)
                    twi.setTextAlignment(Qt.AlignLeft | Qt.AlignVCenter if c == 0 else Qt.AlignCenter)
                    if c == 1 and value:
                        twi.setToolTip("Этот текст будет напечатан белым на чёрной плашке над ценником")
                    self.table.setItem(r, c, twi)
                delete_btn = HistoryDeleteButton()
                delete_btn.setToolTip("Удалить ценник")
                delete_btn.clicked.connect(lambda _checked=False, row_index=r: self.remove_price_tag_row(row_index))
                cell = QWidget()
                cell_layout = QHBoxLayout(cell)
                cell_layout.setContentsMargins(0, 0, 0, 0)
                cell_layout.setAlignment(Qt.AlignCenter)
                cell_layout.addWidget(delete_btn)
                self.table.setCellWidget(r, 5, cell)
        finally:
            self.table.blockSignals(False)
            self._table_refreshing = False
        self.table.resizeRowsToContents()
        self.print_all_btn.setEnabled(bool(self.items))
        if self.items:
            self.table.setCurrentCell(min(max(0, current_row), len(self.items) - 1), 0)
        self.update_price_tag_preview()
    def run_product_search(self) -> None:
        query = self.name_edit.text().strip()
        barcode_mode = free_is_barcode_like_query(query)
        rows = self.catalog_service.search(
            name_query=query,
            barcode_query=query,
            barcode_mode=barcode_mode,
            limit=10,
            non_blocking=True,
        )
        if not self.catalog_service.catalog_ready:
            self.search_timer.start(60)
            return
        digits = re.sub(r"\D+", "", query)
        if barcode_mode and digits:
            exact = [row for row in rows if row.get("exact_barcode_match")]
            unique_ids = {safe_str(row.get("id")) for row in exact}
            if len(exact) == 1 and len(unique_ids) == 1:
                if self._auto_barcode_applied != digits:
                    self._auto_barcode_applied = digits
                    if self.mass_scan_switch.isChecked():
                        self.add_mass_scanned_product(exact[0], digits)
                    else:
                        self.apply_product_result(exact[0])
                return
            self.pending_unknown_barcode = digits if not exact and len(digits) >= 4 else ""
            if self.mass_scan_switch.isChecked() and len(digits) >= 8:
                self.record_mass_unknown_barcode(digits)
                return
            self.show_barcode_state()
        else:
            self.pending_unknown_barcode = ""
            if not self.current_barcode:
                self.show_barcode_state()
        self.search_results = rows
        if rows:
            self.search_popup.show_rows(rows, self.name_edit, query, kind="product")
        else:
            self.search_popup.hide()
    def extract_product_price(self, con: sqlite3.Connection, product_id: str, raw: Any) -> float:
        price = _free_recursive_price(raw)
        if price:
            return price
        price = _free_money_float(_json_pick(raw, ["sellingPrice", "sellingCost", "sellingCostPerUnit", "productPrice", "retailPrice", "salePrice", "price"], 0))
        if price:
            return price
        try:
            row = con.execute("SELECT final_selling_price, sigma_existing_selling_price, incoming_selling_price FROM price_history WHERE product_id=? ORDER BY created_at DESC LIMIT 1", (product_id,)).fetchone()
            if row:
                return _free_money_float(row[0] or row[1] or row[2])
        except Exception:
            pass
        return 0.0
    def select_search_row(self, row: int, col: int = 0) -> None:
        if row < 0 or row >= len(getattr(self, "search_results", [])):
            return
        self.apply_product_result(self.search_results[row])
    def apply_product_result(self, r: Dict[str, Any]) -> None:
        self.current_product = dict(r or {})
        self.name_edit.blockSignals(True); self.name_edit.setText(safe_str(r.get("name"))); self.name_edit.blockSignals(False)
        bcs = [safe_str(x) for x in (r.get("barcodes") or []) if safe_str(x)]
        self.current_barcode = bcs[0] if bcs else ""
        self.pending_unknown_barcode = ""
        price = _free_money_float(r.get("price") or 0)
        self.price_edit.setText(_free_price_text(price) if price else "")
        unit = _free_normalize_unit(r.get("unit") or "штука")
        idx = self.unit_combo.findText(unit)
        if idx < 0:
            self.unit_combo.addItem(unit); idx = self.unit_combo.findText(unit)
        self.unit_combo.setCurrentIndex(max(0, idx))
        self.search_timer.stop(); self.search_popup.hide(); self.show_barcode_state(); self.price_edit.setFocus()
    def accept_name_input(self) -> None:
        self.search_timer.stop()
        self.search_popup.hide()
        text = self.name_edit.text().strip()
        if not text:
            return
        if self.mass_scan_switch.isChecked():
            self.run_product_search()
            return
        if self.search_results:
            self.apply_product_result(self.search_results[0])
            return
        if free_is_barcode_like_query(text):
            self.pending_unknown_barcode = re.sub(r"\D+", "", text)
            self.show_barcode_state()
            return
        self.name_edit.setText(text.upper())
        self.price_edit.setFocus()
    def show_barcode_state(self) -> None:
        """Render the catalog barcode as read-only state below the product field."""
        if self.current_barcode:
            self.barcode_status.setText(f"ШК: {self.current_barcode}")
            self.barcode_status.setVisible(True)
            self.add_missing_barcode_btn.setVisible(False)
            return
        self.barcode_status.setVisible(False)
        self.add_missing_barcode_btn.setVisible(bool(self.current_product or self.pending_unknown_barcode))

    def add_missing_barcode(self) -> None:
        """Accept an unknown scanned code, or ask for one when the catalog item has none."""
        code = re.sub(r"\D+", "", self.pending_unknown_barcode)
        if not code:
            value, accepted = QInputDialog.getText(
                self,
                "Добавить ШК",
                "Введите штрихкод товара:",
            )
            if not accepted:
                return
            code = re.sub(r"\D+", "", safe_str(value))
        if len(code) < 4:
            QMessageBox.information(self, "Добавить ШК", "Штрихкод должен содержать не меньше четырёх цифр.")
            return
        self.current_barcode = code
        self.pending_unknown_barcode = ""
        if free_is_barcode_like_query(self.name_edit.text().strip()):
            self.current_product = {}
            self.name_edit.blockSignals(True)
            self.name_edit.clear()
            self.name_edit.setPlaceholderText("Введите наименование нового товара")
            self.name_edit.blockSignals(False)
            self.name_edit.setFocus()
        self.show_barcode_state()

    def add_manual_tag(self) -> None:
        name = self.name_edit.text().strip().upper()
        barcode = self.current_barcode.strip()
        price = _price_tag_num(self.price_edit.text())
        unit = self.unit_combo.currentText().strip() or "штука"
        if not name or not barcode or price <= 0:
            QMessageBox.information(self, "Ценники", "Нужно указать название, ШК и цену.")
            return
        catalog_barcodes = [
            safe_str(value) for value in (self.current_product.get("barcodes") or ())
            if safe_str(value)
        ]
        if barcode and barcode not in catalog_barcodes:
            catalog_barcodes.append(barcode)
        self.items = self.merge_price_items(self.items + [{
            "name": name,
            "barcode": barcode,
            "price": price,
            "unit": unit,
            "accent_text": safe_str(self.accent_edit.text()),
            "manual": True,
            "sigma_product_id": safe_str(self.current_product.get("id")),
            "vendor_code": safe_str(self.current_product.get("vendor_code")),
            "catalog_barcodes": catalog_barcodes,
        }])
        self.populate_preview()
        self.status_label.setText(f"В списке ценников: {len(self.items)} позиций.")
        self.clear_manual_form()

    def clear_manual_form(self) -> None:
        self._auto_barcode_applied = ""
        self.search_timer.stop(); self.search_popup.hide()
        self.current_product = {}
        self.current_barcode = ""
        self.pending_unknown_barcode = ""
        self.name_edit.clear(); self.name_edit.setPlaceholderText(
            "Сканируйте штрихкод — Enter не нужен" if getattr(self, "mass_scan_switch", None) and self.mass_scan_switch.isChecked()
            else "Наименование / ШК / артикул"
        )
        self.price_edit.clear(); self.accent_edit.clear(); self.unit_combo.setCurrentIndex(0); self.show_barcode_state(); self.name_edit.setFocus()

    def remove_selected_item(self) -> None:
        row = self.table.currentRow()
        self.remove_price_tag_row(row)

    def remove_price_tag_row(self, row: int) -> None:
        if not (0 <= row < len(self.items)):
            return
        self.items.pop(row)
        self.last_pdf_path = None
        self.populate_preview()
        self.status_label.setText(f"В списке ценников: {len(self.items)} позиций.")

    def price_tag_item_changed(self, item: QTableWidgetItem) -> None:
        if self._table_refreshing or item is None:
            return
        row = item.row()
        column = item.column()
        if not (0 <= row < len(self.items)) or not (0 <= column < 5):
            return
        updated = dict(self.items[row])
        text = safe_str(item.text()).strip()
        error = ""
        if column == 0:
            if text:
                updated["name"] = text.upper()
            else:
                error = "Название товара не может быть пустым."
        elif column == 1:
            updated["accent_text"] = text
        elif column == 2:
            barcode = re.sub(r"\D+", "", text)
            if len(barcode) >= 4:
                updated["barcode"] = barcode
            else:
                error = "ШК должен содержать не меньше четырёх цифр."
        elif column == 3:
            price = _price_tag_num(text)
            if price > 0:
                updated["price"] = price
            else:
                error = "Цена должна быть больше нуля."
        elif column == 4:
            if text:
                updated["unit"] = _price_tag_unit_text(text)
            else:
                error = "Единица измерения не может быть пустой."
        if error:
            QMessageBox.information(self, "Ценники", error)
        else:
            self.items[row] = updated
            self.last_pdf_path = None
            self.status_label.setText(f"Строка №{row + 1} изменена.")
        self.populate_preview()
        if self.items:
            self.table.setCurrentCell(min(row, len(self.items) - 1), min(column, 4))


    def selected_price_tag_item(self) -> Dict[str, Any]:
        row = self.table.currentRow()
        if 0 <= row < len(self.items):
            return self.items[row]
        return self.items[0] if self.items else {}

    def update_price_tag_preview(self) -> None:
        label = getattr(self, "price_tag_preview", None)
        if label is None:
            return
        item = self.selected_price_tag_item()
        if not item:
            label.setPixmap(QPixmap())
            label.setText("Предпросмотр ценника появится здесь")
            return
        try:
            label.setPixmap(make_price_tag_preview_pixmap(item, max_w=max(260, label.width() - 24), max_h=300))
            label.setText("")
        except Exception as exc:
            label.setPixmap(QPixmap())
            label.setText(f"Не удалось построить предпросмотр: {exc}")

    def print_selected_thermal_label(self) -> None:
        """Print the selected price tag as a single thermal label."""
        if not self.items:
            QMessageBox.information(self, "Термоэтикетка", "Сначала загрузи SAI-файл или добавь ценник вручную.")
            return
        item = self.selected_price_tag_item()
        if not item:
            QMessageBox.information(self, "Термоэтикетка", "Выбери строку для печати термоэтикетки.")
            return
        thermal_item = {
            "name": safe_str(item.get("name")),
            "barcode": safe_str(item.get("barcode")),
            "price": _price_tag_num(item.get("price")),
            "unit": _price_tag_unit_text(item.get("unit")),
            "accent_text": safe_str(item.get("accent_text") or item.get("price_tag_accent")),
        }
        if not thermal_item["name"] or not thermal_item["barcode"] or _price_tag_num(thermal_item["price"]) <= 0:
            QMessageBox.information(self, "Термоэтикетка", "Для термопечати нужны название, ШК и цена.")
            return
        try:
            print_thermal_price_label(thermal_item, copies=1, parent=self)
            title = thermal_item["name"][:70]
            self.status_label.setText(f"Термоэтикетка отправлена на печать: {title}")
            self.parent_page.notify("Термоэтикетка", f"Отправлена на печать: {title}", "success")
        except Exception as exc:
            QMessageBox.critical(self, "Термоэтикетка", f"Не удалось напечатать термоэтикетку:\n{exc}")

    def print_pdf(self) -> None:
        if not self.last_pdf_path or not Path(self.last_pdf_path).exists():
            self.generate_pdf()
        if not self.last_pdf_path or not Path(self.last_pdf_path).exists():
            return
        self.open_last_pdf()
        self.parent_page.notify("Ценники", "Стандартный лист A4 открыт для печати.", "success")

    def _print_verified_price_tags(self) -> None:
        """Print directly after verification, then keep a backup PDF."""
        mode = self.price_tag_print_mode()
        copies = self.price_tags_print_copies()
        if mode == "off":
            self.status_label.setText("SIGMA обновлена. Печать отключена.")
            self.parent_page.notify("Ценники", "SIGMA обновлена без печати.", "success")
            return
        if mode == "thermal":
            self._print_verified_thermal_price_tags()
            return
        print_items = [dict(item) for item in self.items for _copy in range(copies)]
        cfg = load_private_config()
        configured_printer = configured_a4_printer_name(cfg)
        try:
            printer_name = print_price_tags_a4(print_items, configured_printer)
        except Exception as exc:
            fallback_text = ""
            try:
                out = _unique_desktop_path("Ценники", ".pdf")
                self.last_pdf_path = create_price_tags_pdf(print_items, out)
                open_path(self.last_pdf_path)
                fallback_text = f"\n\nPDF сохранён и открыт:\n{self.last_pdf_path}"
            except Exception as pdf_exc:
                fallback_text = f"\n\nРезервный PDF также не создан: {pdf_exc}"
            self.status_label.setText("Принтер не принял лист ценников.")
            QMessageBox.warning(
                self,
                "Ценники",
                "Принтер не принял прямое задание печати.\n\n"
                f"{exc}{fallback_text}",
            )
            return
        backup_text = ""
        try:
            out = _unique_desktop_path("Ценники", ".pdf")
            self.last_pdf_path = create_price_tags_pdf(print_items, out)
            backup_text = f"\nРезервный PDF: {self.last_pdf_path}"
        except Exception as exc:
            backup_text = f"\nРезервный PDF не создан: {exc}"
        self.status_label.setText(
            f"Отправлено на принтер «{printer_name}»: {len(print_items)} ценников.\n"
            + backup_text.strip()
        )
        self.parent_page.notify(
            "Ценники отправлены на печать",
            f"{len(print_items)} шт. → {printer_name}",
            "success",
        )

    def _print_verified_thermal_price_tags(self) -> None:
        """Send every verified row as one label to the configured thermal printer."""
        printed = 0
        copies = self.price_tags_print_copies()
        expected = len(self.items) * copies
        try:
            for source in self.items:
                item = {
                    "name": safe_str(source.get("name")),
                    "barcode": safe_str(source.get("barcode")),
                    "price": _price_tag_num(source.get("price")),
                    "unit": _price_tag_unit_text(source.get("unit")),
                    "accent_text": safe_str(source.get("accent_text") or source.get("price_tag_accent")),
                }
                print_thermal_price_label(item, copies=copies, parent=self)
                printed += copies
        except Exception as exc:
            self.status_label.setText(f"Термопечать остановлена: отправлено {printed} из {expected}.")
            QMessageBox.critical(
                self,
                "Термоэтикетки",
                f"Не удалось отправить весь список на термопринтер.\n\n"
                f"Отправлено: {printed} из {expected}.\n{exc}",
            )
            return
        self.status_label.setText(f"На термопринтер отправлено: {printed} этикеток.")
        self.parent_page.notify(
            "Термоэтикетки отправлены на печать",
            f"{printed} шт.",
            "success",
        )

    def generate_pdf(self) -> None:
        if not self.items:
            QMessageBox.information(self, "Ценники", "Сначала загрузи SAI-файл или добавь ценник вручную.")
            return
        try:
            out = _unique_desktop_path("Ценники", ".pdf")
            self.last_pdf_path = create_price_tags_pdf(self.items, out)
            self.status_label.setText(f"Ценники созданы на рабочем столе:\n{self.last_pdf_path}")
            self.parent_page.notify("Ценники готовы", f"Создан PDF: {self.last_pdf_path.name}", "success")
        except Exception as exc:
            QMessageBox.critical(self, "Ценники", f"Не удалось сформировать ценники:\n{exc}")

    def open_last_pdf(self) -> None:
        if self.last_pdf_path and self.last_pdf_path.exists():
            open_path(self.last_pdf_path)



class WelcomeDialog(QDialog):
    """First-launch setup: collect the minimum private SIGMA settings."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Первичная настройка SAI")
        self.setModal(True)
        self.setMinimumWidth(520)
        cfg = load_private_config()

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 18)
        root.setSpacing(14)

        title = QLabel("Добро пожаловать в SAI")
        title.setObjectName("DialogTitle")
        subtitle = QLabel("Введите доступы SIGMA один раз. Они сохранятся локально в user_data/sai_private_config.json.")
        subtitle.setObjectName("DialogSubtitle")
        subtitle.setWordWrap(True)
        root.addWidget(title)
        root.addWidget(subtitle)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        form.setFormAlignment(Qt.AlignTop)
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(10)

        self.login_edit = QLineEdit(normalize_sigma_login(cfg.get("sigma_login", "")))
        self.login_edit.setPlaceholderText("номер телефона")
        bind_sigma_login_editor(self.login_edit)
        self.password_edit = QLineEdit(str(cfg.get("sigma_password", "")))
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("пароль")
        self.key_edit = QLineEdit(str(cfg.get("sigma_company_key", "")))
        self.key_edit.setPlaceholderText("ключ компании / X-Api-Key")
        self.token_edit = QLineEdit(str(cfg.get("sigma_api_token", "")))
        self.token_edit.setPlaceholderText("токен API")

        for edit in (self.login_edit, self.password_edit, self.key_edit, self.token_edit):
            edit.setObjectName("WorkbenchInput")

        form.addRow("Логин", self.login_edit)
        form.addRow("Пароль", self.password_edit)
        form.addRow("Ключ", self.key_edit)
        form.addRow("Токен", self.token_edit)
        root.addLayout(form)

        hint = QLabel("Позже это можно изменить в Меню → Настройки → Редактировать private config.")
        hint.setObjectName("WorkbenchNote")
        hint.setWordWrap(True)
        root.addWidget(hint)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("Сохранить и продолжить")
        buttons.button(QDialogButtonBox.Cancel).setText("Пропустить")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

    def accept(self) -> None:  # noqa: D401 - Qt override
        save_private_config_patch({
            "sigma_login": normalize_sigma_login(self.login_edit.text()),
            "sigma_password": self.password_edit.text(),
            "sigma_company_key": self.key_edit.text().strip(),
            "sigma_api_token": self.token_edit.text().strip(),
            "first_run_setup_done": True,
        })
        super().accept()

    def reject(self) -> None:  # noqa: D401 - Qt override
        save_private_config_patch({"first_run_setup_done": True})
        super().reject()





class StartupSyncSignals(QObject):
    log = Signal(str)
    status = Signal(str)
    finished = Signal(bool, bool, str)  # accepted, offline_mode, message


class StartupUpdateSignals(QObject):
    checked = Signal(object, str)
    downloaded = Signal(object, str)


class StartupGateWidget(QWidget):
    startup_done = Signal(bool, str)
    startup_cancelled = Signal()

    """Embedded SAI startup gate.

    SAI should not be usable until private config exists and the current SIGMA
    session/reference data have been checked. If online login fails, SAI can
    continue only in offline/free-receipt mode.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("StartupGate")
        self.signals = StartupSyncSignals()
        self.signals.log.connect(self.add_log)
        self.signals.status.connect(self.set_startup_status)
        self.signals.finished.connect(self.sync_finished)
        self.offline_mode = False
        self.finish_message = ""
        self._worker_thread: threading.Thread | None = None
        self._started = False
        self._update_running = False
        self._startup_update = None
        self._update_attempts = 0
        self.update_signals = StartupUpdateSignals()
        self.update_signals.checked.connect(self.startup_update_checked)
        self.update_signals.downloaded.connect(self.startup_update_downloaded)

        self.required = ["sigma_login", "sigma_password", "sigma_company_key", "sigma_api_token"]
        self.cfg = load_private_config()
        self.update_channel = (
            "development"
            if safe_str(self.cfg.get("github_update_channel")).casefold() == "development"
            else "production"
        )
        self.needs_fields = any(not str(self.cfg.get(k, "")).strip() for k in self.required)
        # The decorative startup intro was removed.  Startup now consists only
        # of the update gate and, on the first run, the required SIGMA fields.
        self.intro_enabled = False
        self._sync_result: tuple[bool, bool, str] | None = None
        self.build_ui()
        self.build_update_gate()
        QTimer.singleShot(80, self.check_startup_update)

    def build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Normal startup stays visually neutral while the fast local readiness
        # check runs.  There is deliberately no logo splash or animation.
        if not self.needs_fields:
            self.splash = None
            fast_canvas = QFrame(self)
            fast_canvas.setObjectName("StartupFastCanvas")
            root.addWidget(fast_canvas, 1)

            # Compatibility placeholders used by the startup workflow. They stay
            # invisible, so the splash screen remains completely clean.
            self.form_frame = QFrame(self); self.form_frame.setVisible(False)
            self.status_label = QLabel("", self); self.status_label.setVisible(False)
            self.log_box = QTextEdit(self); self.log_box.setVisible(False)
            self.exit_btn = QPushButton("", self); self.exit_btn.setVisible(False)
            self.start_btn = QPushButton("", self); self.start_btn.setVisible(False)
            return

        # First launch / missing config: SAI still needs fields, but keep the
        # screen centered and calm instead of showing a technical log panel.
        outer = QFrame()
        outer.setObjectName("StartupFirstRunCanvas")
        root.addWidget(outer, 1)
        outer_layout = QVBoxLayout(outer)
        outer_layout.setContentsMargins(32, 32, 32, 32)
        outer_layout.addStretch(1)

        panel = QFrame()
        panel.setObjectName("StartupFirstRunPanel")
        panel.setMaximumWidth(520)
        outer_layout.addWidget(panel, 0, Qt.AlignHCenter)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(28, 26, 28, 24)
        layout.setSpacing(14)

        title = QLabel("Sigma Auto Income")
        title.setObjectName("StartupTitle")
        title.setAlignment(Qt.AlignCenter)
        subtitle = QLabel("Введите доступы SIGMA один раз. SAI сохранит их локально и продолжит запуск.")
        subtitle.setObjectName("StartupSubtitle")
        subtitle.setWordWrap(True)
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        self.form_frame = QFrame()
        self.form_frame.setObjectName("StartupForm")
        form_layout = QVBoxLayout(self.form_frame)
        form_layout.setContentsMargins(0, 0, 0, 0)
        form_layout.setSpacing(10)

        self.login_edit = QLineEdit(normalize_sigma_login(self.cfg.get("sigma_login", "")))
        self.login_edit.setPlaceholderText("Логин SIGMA / номер телефона")
        bind_sigma_login_editor(self.login_edit)
        self.password_edit = QLineEdit(str(self.cfg.get("sigma_password", "")))
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setPlaceholderText("Пароль SIGMA")
        self.key_edit = QLineEdit(str(self.cfg.get("sigma_company_key", "")))
        self.key_edit.setPlaceholderText("Ключ компании / company key")
        self.token_edit = QLineEdit(str(self.cfg.get("sigma_api_token", "")))
        self.token_edit.setPlaceholderText("API token / X-Api-Key")
        for edit in (self.login_edit, self.password_edit, self.key_edit, self.token_edit):
            edit.setObjectName("StartupInput")
            edit.setMinimumHeight(44)
            edit.textChanged.connect(self.update_start_enabled)
            form_layout.addWidget(edit)
        layout.addWidget(self.form_frame)

        self.status_label = QLabel("Введите данные SIGMA.")
        self.status_label.setObjectName("StartupStatus")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)

        self.log_box = QTextEdit(self)
        self.log_box.setVisible(False)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.exit_btn = QPushButton("Закрыть")
        self.exit_btn.setObjectName("StartupSecondary")
        self.exit_btn.clicked.connect(self.reject)
        self.start_btn = QPushButton("Продолжить")
        self.start_btn.setObjectName("StartupPrimary")
        self.start_btn.clicked.connect(self.start_sync)
        buttons.addWidget(self.exit_btn)
        buttons.addWidget(self.start_btn)
        buttons.addStretch(1)
        layout.addLayout(buttons)

        outer_layout.addStretch(1)
        self.update_start_enabled()

    def build_update_gate(self) -> None:
        self.update_gate = QFrame(self)
        self.update_gate.setObjectName("StartupUpdateGate")
        gate_layout = QVBoxLayout(self.update_gate)
        gate_layout.setContentsMargins(32, 32, 32, 32)
        gate_layout.addStretch(1)

        panel = QFrame(self.update_gate)
        panel.setObjectName("StartupUpdatePanel")
        panel.setMaximumWidth(580)
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(46, 42, 46, 42)
        panel_layout.setSpacing(13)

        badge = QLabel("SAI · ОБНОВЛЕНИЕ")
        badge.setObjectName("StartupUpdateBadge")
        badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.update_title = QLabel("Проверяю обновления")
        self.update_title.setObjectName("StartupUpdateTitle")
        self.update_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.update_title.setWordWrap(True)
        self.update_subtitle = QLabel("Связываюсь с официальным каналом SAI…")
        self.update_subtitle.setObjectName("StartupUpdateSubtitle")
        self.update_subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.update_subtitle.setWordWrap(True)
        self.update_notes = QLabel("")
        self.update_notes.setObjectName("StartupUpdateNotes")
        self.update_notes.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.update_notes.setWordWrap(True)
        self.update_notes.setVisible(False)
        self.update_progress = QProgressBar()
        self.update_progress.setObjectName("StartupUpdateProgress")
        self.update_progress.setRange(0, 0)
        self.update_progress.setTextVisible(False)
        self.update_progress.setMaximumWidth(280)
        self.update_progress.setFixedHeight(5)
        self.update_button = QPushButton("Обновить")
        self.update_button.setObjectName("StartupUpdateButton")
        self.update_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.update_button.setMinimumWidth(190)
        self.update_button.setMinimumHeight(46)
        self.update_button.setVisible(False)
        self.update_button.clicked.connect(self.startup_update_action)
        self.update_continue_button = QPushButton("Продолжить без проверки")
        self.update_continue_button.setObjectName("StartupUpdateSecondary")
        self.update_continue_button.setVisible(False)
        self.update_continue_button.clicked.connect(self.finish_update_gate)

        panel_layout.addWidget(badge)
        panel_layout.addSpacing(7)
        panel_layout.addWidget(self.update_title)
        panel_layout.addWidget(self.update_subtitle)
        panel_layout.addWidget(self.update_notes)
        panel_layout.addSpacing(8)
        panel_layout.addWidget(self.update_progress, 0, Qt.AlignmentFlag.AlignHCenter)
        panel_layout.addWidget(self.update_button, 0, Qt.AlignmentFlag.AlignHCenter)
        panel_layout.addWidget(self.update_continue_button, 0, Qt.AlignmentFlag.AlignHCenter)
        gate_layout.addWidget(panel, 0, Qt.AlignmentFlag.AlignCenter)
        gate_layout.addStretch(1)
        self.update_gate.setGeometry(self.rect())
        self.update_gate.show()
        self.update_gate.raise_()

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().resizeEvent(event)
        gate = getattr(self, "update_gate", None)
        if gate is not None:
            gate.setGeometry(self.rect())

    @staticmethod
    def _short_release_notes(value: Any) -> str:
        lines = []
        for raw in safe_str(value).replace("\r", "").split("\n"):
            text = re.sub(r"^[#>*\-\s]+", "", raw).strip()
            if text:
                lines.append(text)
            if len(lines) >= 3:
                break
        result = " · ".join(lines)
        return result[:420].rstrip() + ("…" if len(result) > 420 else "")

    def check_startup_update(self) -> None:
        if self._update_running:
            return
        self._update_running = True
        self._update_attempts += 1
        self._startup_update = None
        self.update_title.setText("Проверяю обновления")
        self.update_subtitle.setText("Связываюсь с официальным каналом SAI…")
        self.update_notes.setVisible(False)
        self.update_progress.setVisible(True)
        self.update_button.setVisible(False)
        self.update_continue_button.setVisible(False)

        def worker() -> None:
            try:
                update = sai_github_updates.check_for_update(APP_VERSION, channel=self.update_channel)
                self.update_signals.checked.emit(update, "")
            except Exception as exc:
                self.update_signals.checked.emit(None, str(exc))

        threading.Thread(target=worker, daemon=True, name="sai-startup-update-check").start()

    def startup_update_checked(self, update: Any, error: str) -> None:
        self._update_running = False
        if error:
            self.update_progress.setVisible(False)
            self.update_title.setText("Не удалось проверить обновления")
            self.update_subtitle.setText("Проверь подключение к интернету и повтори попытку.")
            self.update_notes.setText(safe_str(error)[:260])
            self.update_notes.setVisible(True)
            self.update_button.setText("Повторить")
            self.update_button.setVisible(True)
            self.update_continue_button.setVisible(True)
            return
        if update is None:
            self.finish_update_gate()
            return
        self._startup_update = update
        self.update_progress.setVisible(False)
        self.update_title.setText(f"Доступна версия v{update.version}")
        self.update_subtitle.setText(f"Сейчас установлена {APP_VERSION}. Перед началом работы SAI необходимо обновить.")
        notes = self._short_release_notes(getattr(update, "notes", ""))
        self.update_notes.setText(notes or "Обновление содержит последние улучшения стабильности и возможностей SAI.")
        self.update_notes.setVisible(True)
        self.update_button.setText("Обновить")
        self.update_button.setVisible(True)
        self.update_continue_button.setVisible(False)

    def startup_update_action(self) -> None:
        if self._startup_update is None:
            self.check_startup_update()
            return
        if self._update_running:
            return
        self._update_running = True
        self.update_button.setEnabled(False)
        self.update_button.setText("Загружаю…")
        self.update_progress.setVisible(True)
        update = self._startup_update

        def worker() -> None:
            try:
                package = sai_github_updates.download_update(update)
                self.update_signals.downloaded.emit(package, "")
            except Exception as exc:
                self.update_signals.downloaded.emit(None, str(exc))

        threading.Thread(target=worker, daemon=True, name="sai-startup-update-download").start()

    def startup_update_downloaded(self, package: Any, error: str) -> None:
        self._update_running = False
        if error or package is None:
            self.update_progress.setVisible(False)
            self.update_title.setText("Не удалось загрузить обновление")
            self.update_subtitle.setText("Пакет не был установлен. Можно безопасно повторить загрузку.")
            self.update_notes.setText(safe_str(error)[:300])
            self.update_notes.setVisible(True)
            self.update_button.setText("Повторить")
            self.update_button.setEnabled(True)
            self.update_button.setVisible(True)
            return
        self.update_title.setText("Устанавливаю обновление")
        self.update_subtitle.setText("SAI закроется и автоматически запустится снова.")
        self.update_button.setVisible(False)
        QApplication.processEvents()
        try:
            launched = sai_github_bootstrap.launch_downloaded_update(
                Path(package), self._startup_update.version, ROOT_DIR, restart=True,
            )
            if not launched:
                raise RuntimeError("Не удалось запустить установщик обновления.")
        except Exception as exc:
            self.update_progress.setVisible(False)
            self.update_title.setText("Не удалось начать установку")
            self.update_subtitle.setText("Рабочая версия SAI не изменена.")
            self.update_notes.setText(str(exc)[:300])
            self.update_notes.setVisible(True)
            self.update_button.setText("Повторить")
            self.update_button.setEnabled(True)
            self.update_button.setVisible(True)
            return
        app = QApplication.instance()
        if app is not None:
            QTimer.singleShot(200, app.quit)

    def finish_update_gate(self) -> None:
        gate = getattr(self, "update_gate", None)
        if gate is not None:
            gate.hide()
        if not self.needs_fields:
            QTimer.singleShot(0, self.start_sync)

    def update_start_enabled(self) -> None:
        if self._started:
            self.start_btn.setEnabled(False)
            return
        if not self.needs_fields:
            self.start_btn.setEnabled(True)
            return
        ok = all(x.text().strip() for x in (self.login_edit, self.password_edit, self.key_edit, self.token_edit))
        self.start_btn.setEnabled(ok)

    def set_startup_status(self, text: str) -> None:
        text = safe_str(text)
        if getattr(self, "status_label", None) is not None:
            self.status_label.setText(text)

    def add_log(self, text: str) -> None:
        stamp = dt.datetime.now().strftime("%H:%M:%S")
        self.log_box.append(f"[{stamp}] {text}")
        self.log_box.moveCursor(QTextCursor.End)

    def start_sync(self) -> None:
        if self._started:
            return
        if self.needs_fields:
            if not all(x.text().strip() for x in (self.login_edit, self.password_edit, self.key_edit, self.token_edit)):
                self.status_label.setText("Заполните все поля, чтобы продолжить.")
                return
            save_private_config_patch({
                "sigma_login": normalize_sigma_login(self.login_edit.text()),
                "sigma_password": self.password_edit.text(),
                "sigma_company_key": self.key_edit.text().strip(),
                "sigma_api_token": self.token_edit.text().strip(),
                "first_run_setup_done": True,
            })
        self._started = True
        self.start_btn.setEnabled(False)
        self.exit_btn.setEnabled(False)
        for edit in (getattr(self, "login_edit", None), getattr(self, "password_edit", None), getattr(self, "key_edit", None), getattr(self, "token_edit", None)):
            if edit:
                edit.setEnabled(False)
        self.form_frame.setVisible(False)
        self.log_box.setVisible(False)
        self.status_label.setText("Проверяю SIGMA в скрытом режиме…")
        self.add_log("Старт проверки SAI.")
        self._worker_thread = threading.Thread(target=self.run_worker, daemon=True)
        self._worker_thread.start()

    def run_worker(self) -> None:
        try:
            accepted, offline, message = self._do_startup_sync()
        except Exception as exc:
            accepted, offline, message = True, True, f"Онлайн-вход не удался. SAI запущен offline: {str(exc)[:240]}"
        self.signals.finished.emit(bool(accepted), bool(offline), str(message))

    def _do_startup_sync(self) -> tuple[bool, bool, str]:
        cfg = load_private_config()
        missing = [k for k in self.required if not str(cfg.get(k, "")).strip()]
        if missing:
            raise RuntimeError("не заполнены обязательные поля: " + ", ".join(missing))

        company = str(cfg.get("sigma_company_key") or "").strip()
        token = str(cfg.get("sigma_api_token") or "").strip()
        sell_point_id = str(cfg.get("sigma_sell_point_id") or "").strip()

        # Fast path: the local mirror is the startup source of truth.  Do not make
        # the operator wait for SIGMA just to open the application.
        local_snapshot = sai_catalog_ready.catalog_snapshot(cfg)
        if local_snapshot.get("catalog_present"):
            product_count = int(local_snapshot.get("product_count") or 0)
            barcode_count = int(local_snapshot.get("barcode_count") or 0)
            age_text = sai_catalog_ready.human_age(local_snapshot.get("age_seconds"))
            catalog_message = f"Каталог готов: {product_count} товаров, {barcode_count} ШК · обновлён {age_text} назад."
            save_private_config_patch({
                "startup_offline_mode": False,
                "catalog_last_startup_status": catalog_message,
                "sai_ready_last_ui_open_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
            return True, False, catalog_message

        headers = {"Accept": "application/json", "X-Api-Key": token, "User-Agent": f"SAI-Startup/{APP_VERSION}"}
        base = f"https://api.sigma.ru/v1/companies/{company}"

        try:
            import requests
            self.signals.log.emit("Проверяю X-Api-Key API SIGMA…")
            sell_points_resp = requests.get(base + "/sell-points", headers=headers, timeout=8)
            if not (200 <= sell_points_resp.status_code < 300):
                raise RuntimeError(f"sell-points HTTP {sell_points_resp.status_code}: {sell_points_resp.text[:180]}")
            sell_points = _collect_api_items(sell_points_resp.json())
            if not sell_point_id and sell_points:
                for item in sell_points:
                    sell_point_id = _api_item_id(item)
                    if sell_point_id:
                        save_private_config_patch({"sigma_sell_point_id": sell_point_id})
                        cfg["sigma_sell_point_id"] = sell_point_id
                        break
            self.signals.log.emit(f"Торговые точки: {len(sell_points)}" + (f", выбрана: {sell_point_id}" if sell_point_id else ""))
        except Exception as exc:
            raise RuntimeError("проверка API SIGMA не прошла: " + str(exc)) from exc

        # SAI Ready: an existing SQLite mirror is trusted immediately.  A normal
        # application launch must not wait for a full catalog download.  Only the
        # very first launch (no local mirror at all) performs a blocking refresh.
        snapshot = sai_catalog_ready.catalog_snapshot(cfg)
        if snapshot.get("catalog_present"):
            product_count = int(snapshot.get("product_count") or 0)
            barcode_count = int(snapshot.get("barcode_count") or 0)
            age_text = sai_catalog_ready.human_age(snapshot.get("age_seconds"))
            catalog_message = f"Каталог готов: {product_count} товаров, {barcode_count} ШК · обновлён {age_text} назад."
            self.signals.log.emit(catalog_message)
        else:
            self.signals.status.emit("Первый запуск: загружаю каталог SIGMA...")
            self.signals.log.emit("Локального каталога ещё нет. Выполняю единственную обязательную первичную загрузку…")
            try:
                result = sai_catalog_ready.refresh_catalog(reason="first-catalog", force=True, cfg=cfg)
                if not bool(result.get("ok")):
                    raise RuntimeError(safe_str(result.get("message")) or "каталог не загружен")
                product_count = int(result.get("product_count") or 0)
                barcode_count = int(result.get("barcode_count") or 0)
                catalog_message = f"Каталог готов: {product_count} товаров, {barcode_count} ШК."
                self.signals.log.emit(catalog_message)
            except Exception as exc:
                raise RuntimeError("первичный каталог SIGMA не удалось загрузить: " + str(exc)) from exc

        save_private_config_patch({
            "startup_last_online_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "startup_offline_mode": False,
            "catalog_last_startup_status": catalog_message,
        })
        return True, False, catalog_message

    def sync_finished(self, accepted: bool, offline: bool, message: str) -> None:
        self.offline_mode = bool(offline)
        self.finish_message = message
        self._sync_result = (bool(accepted), bool(offline), message)
        self.status_label.setText(message)
        self.add_log(message)
        if accepted:
            self.start_finish_transition()
        else:
            self.exit_btn.setEnabled(True)
            self.start_btn.setEnabled(True)

    def start_finish_transition(self, force: bool = False) -> None:
        """Open the working interface immediately after startup checks."""
        if getattr(self, "_finish_transition_started", False):
            return
        self._finish_transition_started = True
        self.startup_done.emit(bool(self.offline_mode), self.finish_message)

    def reject(self) -> None:
        if self._started:
            return
        self.startup_cancelled.emit()


class ThemeModeButton(QPushButton):
    """One crisp, scale-independent icon inside the day/night theme switch."""

    def __init__(self, mode: str, tooltip: str, parent=None) -> None:
        super().__init__(parent)
        self.mode = str(mode)
        self.setObjectName("ThemeModeButton")
        self.setCheckable(True)
        self.setAutoExclusive(True)
        self.setText("")
        self.setToolTip(tooltip)
        self.setAccessibleName(tooltip)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setFixedSize(44, 40)

    def _icon_color(self) -> QColor:
        if self.isChecked():
            return QColor("#ffffff")
        app = QApplication.instance()
        dark = bool(app and app.property("saiNightTheme"))
        if not self.isEnabled():
            return QColor("#64748b" if dark else "#9aa7b8")
        if self.underMouse() or self.hasFocus():
            return QColor("#dbeafe" if dark else "#1d4ed8")
        return QColor("#a8b7cc" if dark else "#536277")

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        color = self._icon_color()
        pen = QPen(color, 1.75, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        cx = self.width() / 2.0
        cy = self.height() / 2.0

        if self.mode == "day":
            painter.setBrush(color)
            painter.drawEllipse(QPointF(cx, cy), 3.4, 3.4)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            for dx, dy in ((0, -8), (0, 8), (-8, 0), (8, 0), (-5.7, -5.7), (5.7, -5.7), (-5.7, 5.7), (5.7, 5.7)):
                length = 2.3
                norm = max(1.0, math.hypot(dx, dy))
                ux, uy = dx / norm, dy / norm
                painter.drawLine(
                    QPointF(cx + ux * (norm - length / 2), cy + uy * (norm - length / 2)),
                    QPointF(cx + ux * (norm + length / 2), cy + uy * (norm + length / 2)),
                )
        else:  # night
            outer = QPainterPath()
            outer.addEllipse(QPointF(cx - 0.8, cy), 7.5, 7.5)
            cut = QPainterPath()
            cut.addEllipse(QPointF(cx + 3.1, cy - 2.2), 7.0, 7.0)
            crescent = outer.subtracted(cut)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(color)
            painter.drawPath(crescent)


class ThemeModeSelector(QFrame):
    """Modern icon-only segmented switch for fixed light and dark themes."""

    modeChanged = Signal(str)
    MODES = (
        ("day", "Светлая тема"),
        ("night", "Тёмная тема"),
    )

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("ThemeModeSelector")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(3)
        self.buttons: Dict[str, ThemeModeButton] = {}
        for mode, tooltip in self.MODES:
            button = ThemeModeButton(mode, tooltip, self)
            button.clicked.connect(lambda _checked=False, value=mode: self._clicked(value))
            self.buttons[mode] = button
            layout.addWidget(button)
        self.set_mode("day", emit=False)

    def _clicked(self, mode: str) -> None:
        self.set_mode(mode, emit=False)
        self.modeChanged.emit(mode)

    def mode(self) -> str:
        for mode, button in self.buttons.items():
            if button.isChecked():
                return mode
        return "day"

    def set_mode(self, mode: str, emit: bool = False) -> None:
        value = normalize_theme_mode(mode)
        button = self.buttons[value]
        button.setChecked(True)
        for item in self.buttons.values():
            item.update()
        if emit:
            self.modeChanged.emit(value)


class SettingsDisclosureButton(QPushButton):
    """A full-width, modern disclosure header for optional settings groups."""

    def __init__(self, title: str, summary: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("SettingsDisclosureButton")
        self.setText("")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setMinimumHeight(62)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 9, 12, 9)
        layout.setSpacing(10)
        labels = QVBoxLayout()
        labels.setContentsMargins(0, 0, 0, 0)
        labels.setSpacing(2)
        self.title_label = QLabel(title, self)
        self.title_label.setObjectName("SettingsDisclosureTitle")
        self.title_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.summary_label = QLabel(summary, self)
        self.summary_label.setObjectName("SettingsDisclosureSummary")
        self.summary_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        labels.addWidget(self.title_label)
        labels.addWidget(self.summary_label)
        layout.addLayout(labels, 1)
        self.arrow_label = QLabel("›", self)
        self.arrow_label.setObjectName("SettingsDisclosureArrow")
        self.arrow_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.arrow_label.setFixedSize(24, 24)
        self.arrow_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        layout.addWidget(self.arrow_label, 0, Qt.AlignmentFlag.AlignVCenter)
        self.toggled.connect(self._sync_arrow)
        self._sync_arrow(False)

    def set_summary(self, text: str) -> None:
        self.summary_label.setText(str(text or ""))

    def _sync_arrow(self, expanded: bool) -> None:
        self.arrow_label.setText("⌄" if expanded else "›")
        self.setProperty("expanded", bool(expanded))
        style = self.style()
        if style is not None:
            style.unpolish(self)
            style.polish(self)


class SettingsPage(QWidget):
    """Centralized settings screen for navigation tools and preferences."""

    def __init__(self, parent_page: "MainPage") -> None:
        super().__init__()
        self.parent_page = parent_page
        self.manual_sigma_login_running = False
        self.build_ui()

    def build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll, 1)

        body = QWidget()
        body.setObjectName("StatsPage")
        scroll.setWidget(body)
        root = QVBoxLayout(body)
        root.setContentsMargins(28, 30, 28, 30)
        root.setSpacing(18)

        root.addWidget(make_standard_page_header(
            "Настройки",
            "Подключение SIGMA, печать, уведомления, диагностика и служебные параметры SAI.",
        ))

        tools = QFrame(); tools.setObjectName("WorkbenchCard")
        tl = QVBoxLayout(tools); tl.setContentsMargins(18, 16, 18, 16); tl.setSpacing(12)
        t = QLabel("Инструменты"); t.setObjectName("WorkbenchSection"); tl.addWidget(t)
        row = QHBoxLayout(); row.setSpacing(10)
        self.logs_btn = QPushButton("Логи")
        self.logs_btn.setObjectName("SoftButton")
        self.logs_btn.clicked.connect(lambda: open_path(LOGS_DIR))
        self.folder_btn = QPushButton("Папка SAI")
        self.folder_btn.setObjectName("SoftButton")
        self.folder_btn.clicked.connect(lambda: open_path(USER_DATA_DIR))
        self.config_btn = QPushButton("Редактировать private config")
        self.config_btn.setObjectName("SoftButton")
        self.config_btn.clicked.connect(self.open_private_config)
        self.doctor_btn = QPushButton("Диагностика")
        self.doctor_btn.setObjectName("WorkbenchPrimaryButton")
        self.doctor_btn.clicked.connect(self.parent_page.launch_doctor)
        for b in (self.logs_btn, self.folder_btn, self.config_btn, self.doctor_btn):
            row.addWidget(b)
        row.addStretch(1)
        tl.addLayout(row)
        self.doctor_hint = QLabel("Диагностика запускается в фоне, отчёт автоматически копируется на рабочий стол.")
        self.doctor_hint.setObjectName("WorkbenchNote")
        tl.addWidget(self.doctor_hint)
        root.addWidget(tools)

        updates_card = QFrame(); updates_card.setObjectName("WorkbenchCard")
        ul = QVBoxLayout(updates_card); ul.setContentsMargins(18, 16, 18, 16); ul.setSpacing(10)
        update_title = QLabel("Обновления SAI"); update_title.setObjectName("WorkbenchSection"); ul.addWidget(update_title)
        update_note = QLabel(
            f"Установлена {APP_VERSION}. SAI проверяет официальный публичный канал KZEEBEX/SAI-releases. "
            "Стабильный канал получает проверенные релизы, тестовый — также новые DEV-сборки. "
            "Каждый пакет проверяется по SHA-256 перед установкой."
        )
        update_note.setObjectName("WorkbenchNote"); update_note.setWordWrap(True); ul.addWidget(update_note)
        channel_row = QHBoxLayout(); channel_row.setSpacing(10)
        channel_label = QLabel("Канал обновлений")
        channel_label.setObjectName("WorkbenchLabel")
        self.github_update_channel_combo = NoWheelComboBox()
        self.github_update_channel_combo.setObjectName("WorkbenchCombo")
        self.github_update_channel_combo.addItem("Стабильная версия", "production")
        self.github_update_channel_combo.addItem("Тестовая версия (DEV)", "development")
        configured_channel = safe_str(load_private_config().get("github_update_channel")).casefold()
        channel_index = self.github_update_channel_combo.findData(
            "development" if configured_channel == "development" else "production"
        )
        self.github_update_channel_combo.setCurrentIndex(max(0, channel_index))
        self.github_update_channel_combo.currentIndexChanged.connect(self.github_update_channel_changed)
        channel_row.addWidget(channel_label)
        channel_row.addWidget(self.github_update_channel_combo)
        channel_row.addStretch(1)
        ul.addLayout(channel_row)
        update_actions = QHBoxLayout(); update_actions.setSpacing(10)
        self.github_update_check_btn = QPushButton("Проверить обновления")
        self.github_update_check_btn.setObjectName("SoftButton")
        self.github_update_check_btn.clicked.connect(lambda: self.parent_page.check_github_update(notify=True))
        self.github_update_install_btn = QPushButton("Скачать и установить")
        self.github_update_install_btn.setObjectName("WorkbenchPrimaryButton")
        self.github_update_install_btn.clicked.connect(lambda: self.parent_page.install_github_update())
        self.github_update_install_btn.setVisible(False)
        update_actions.addWidget(self.github_update_check_btn)
        update_actions.addWidget(self.github_update_install_btn)
        update_actions.addStretch(1)
        ul.addLayout(update_actions)
        self.github_update_status = QLabel("Проверка выполняется тихо после запуска SAI.")
        self.github_update_status.setObjectName("InlineStatus")
        self.github_update_status.setWordWrap(True)
        ul.addWidget(self.github_update_status)
        root.addWidget(updates_card)

        scans_card = QFrame(); scans_card.setObjectName("WorkbenchCard")
        sl = QVBoxLayout(scans_card); sl.setContentsMargins(18, 16, 18, 16); sl.setSpacing(10)
        scans_title = QLabel("Сканер накладных"); scans_title.setObjectName("WorkbenchSection"); sl.addWidget(scans_title)
        scans_note = QLabel(
            "SAI наблюдает за этой папкой. В «Привоз → Новый привоз» кнопка «Найти свежие сканы» "
            "соберёт последнюю серию PDF и изображений, если между соседними файлами прошло не больше 10 минут."
        )
        scans_note.setObjectName("WorkbenchNote"); scans_note.setWordWrap(True); sl.addWidget(scans_note)
        scan_row = QHBoxLayout(); scan_row.setSpacing(10)
        self.scan_folder_edit = QLineEdit(safe_str(load_private_config().get("invoice_scan_folder")))
        self.scan_folder_edit.setObjectName("WorkbenchInput")
        self.scan_folder_edit.setPlaceholderText("Папка, куда сканер сохраняет накладные")
        self.scan_folder_edit.setReadOnly(True)
        self.scan_folder_choose_btn = QPushButton("Выбрать папку")
        self.scan_folder_choose_btn.setObjectName("WorkbenchPrimaryButton")
        self.scan_folder_choose_btn.clicked.connect(self.choose_scan_folder)
        self.scan_folder_open_btn = QPushButton("Открыть")
        self.scan_folder_open_btn.setObjectName("SoftButton")
        self.scan_folder_open_btn.clicked.connect(self.open_scan_folder)
        scan_row.addWidget(self.scan_folder_edit, 1)
        scan_row.addWidget(self.scan_folder_choose_btn)
        scan_row.addWidget(self.scan_folder_open_btn)
        sl.addLayout(scan_row)
        root.addWidget(scans_card)

        organization = QFrame(); organization.setObjectName("WorkbenchCard")
        ol = QVBoxLayout(organization); ol.setContentsMargins(18, 16, 18, 16); ol.setSpacing(10)
        org_title = QLabel("Организация и общая папка"); org_title.setObjectName("WorkbenchSection"); ol.addWidget(org_title)
        org_note = QLabel(
            "Подойдёт расшаренная папка Windows в локальной сети или Яндекс Диск. "
            "SAI синхронизирует черновики, историю завершённых приходов и их документы между компьютерами. "
            "Пароли, принтеры, браузер SIGMA и локальная база в облако не отправляются."
        )
        org_note.setObjectName("WorkbenchNote"); org_note.setWordWrap(True); ol.addWidget(org_note)
        org_cfg = load_private_config()
        org_settings = sai_organization_sync.SyncSettings.from_config(org_cfg)
        if not safe_str(org_cfg.get("organization_device_id")):
            save_private_config_patch({
                "organization_device_id": org_settings.device_id,
                "organization_device_name": org_settings.device_name,
            })
        org_form = QFormLayout(); org_form.setHorizontalSpacing(12); org_form.setVerticalSpacing(9)
        self.organization_name_edit = QLineEdit(org_settings.organization_name)
        self.organization_name_edit.setObjectName("WorkbenchInput")
        self.organization_name_edit.setPlaceholderText("Название организации")
        self.organization_device_edit = QLineEdit(org_settings.device_name)
        self.organization_device_edit.setObjectName("WorkbenchInput")
        self.organization_device_edit.setPlaceholderText("Например: Касса или Компьютер руководителя")
        self.organization_path_edit = QLineEdit(str(org_settings.root) if safe_str(org_cfg.get("organization_sync_root")) else "")
        self.organization_path_edit.setObjectName("WorkbenchInput")
        self.organization_path_edit.setPlaceholderText(r"Например: \\КОМПЬЮТЕР\SAI_SYNC")
        self.organization_path_edit.returnPressed.connect(self.connect_organization_path)
        org_form.addRow("Организация", self.organization_name_edit)
        org_form.addRow("Этот компьютер", self.organization_device_edit)
        org_form.addRow("Общая папка", self.organization_path_edit)
        ol.addLayout(org_form)
        org_actions = QHBoxLayout(); org_actions.setSpacing(10)
        self.organization_connect_btn = QPushButton("Выбрать папку")
        self.organization_connect_btn.setObjectName("WorkbenchPrimaryButton")
        self.organization_connect_btn.clicked.connect(self.choose_organization_folder)
        self.organization_path_connect_btn = QPushButton("Подключить путь")
        self.organization_path_connect_btn.setObjectName("SoftButton")
        self.organization_path_connect_btn.clicked.connect(self.connect_organization_path)
        self.organization_sync_btn = QPushButton("Синхронизировать сейчас")
        self.organization_sync_btn.setObjectName("SoftButton")
        self.organization_sync_btn.clicked.connect(lambda: self.parent_page.sync_organization_now(notify=True))
        self.organization_open_btn = QPushButton("Открыть общую папку")
        self.organization_open_btn.setObjectName("SoftButton")
        self.organization_open_btn.clicked.connect(self.open_organization_folder)
        self.organization_update_btn = QPushButton("Установить обновление")
        self.organization_update_btn.setObjectName("WorkbenchPrimaryButton")
        self.organization_update_btn.clicked.connect(self.install_organization_update)
        self.organization_update_btn.setVisible(False)
        for button in (self.organization_connect_btn, self.organization_path_connect_btn, self.organization_sync_btn, self.organization_open_btn, self.organization_update_btn):
            org_actions.addWidget(button)
        org_actions.addStretch(1)
        ol.addLayout(org_actions)
        self.organization_status = QLabel("")
        self.organization_status.setObjectName("InlineStatus")
        self.organization_status.setWordWrap(True)
        ol.addWidget(self.organization_status)
        root.addWidget(organization)
        self.refresh_organization_status()

        appearance = QFrame(); appearance.setObjectName("WorkbenchCard")
        apl = QVBoxLayout(appearance); apl.setContentsMargins(18, 16, 18, 16); apl.setSpacing(11)
        ap_title = QLabel("Оформление"); ap_title.setObjectName("WorkbenchSection"); apl.addWidget(ap_title)

        theme_row = QHBoxLayout(); theme_row.setSpacing(12)
        theme_label = QLabel("Тема интерфейса")
        theme_label.setObjectName("ThemeSettingLabel")
        theme_label.setMinimumWidth(150)
        theme_row.addWidget(theme_label)

        self.theme_selector = ThemeModeSelector(appearance)
        theme_row.addWidget(self.theme_selector, 0)
        theme_row.addStretch(1)
        apl.addLayout(theme_row)

        self.theme_mode_description = QLabel("")
        self.theme_mode_description.setObjectName("ThemeModeDescription")
        self.theme_mode_description.setWordWrap(True)
        apl.addWidget(self.theme_mode_description)

        theme_cfg = load_private_config()
        initial_theme_mode = normalize_theme_mode(theme_cfg.get("theme_mode"))
        self._loading_theme_ui = True
        self.theme_selector.set_mode(initial_theme_mode, emit=False)
        self._loading_theme_ui = False
        self.theme_selector.modeChanged.connect(self.theme_mode_changed)
        self._sync_theme_controls(initial_theme_mode)
        root.addWidget(appearance)

        behavior = QFrame(); behavior.setObjectName("WorkbenchCard")
        bl = QVBoxLayout(behavior); bl.setContentsMargins(18, 16, 18, 16); bl.setSpacing(10)
        btitle = QLabel("Поведение SAI"); btitle.setObjectName("WorkbenchSection"); bl.addWidget(btitle)
        cfg = load_private_config()
        self.browser_check = QCheckBox("Показывать браузер SIGMA")
        self.browser_check.setChecked(bool(cfg.get("browser_visible", False)))
        self.browser_check.stateChanged.connect(self.parent_page.browser_visibility_changed)
        self.logs_check = QCheckBox("Показывать логи")
        self.logs_check.setChecked(bool(cfg.get("hub_show_logs", False)))
        self.logs_check.stateChanged.connect(self.parent_page.logs_visibility_changed)
        self.notifications_check = QCheckBox("Показывать краткие уведомления")
        self.notifications_check.setChecked(bool(cfg.get("hub_notifications_enabled", True)))
        self.notifications_check.stateChanged.connect(self.notifications_changed)
        self.auto_ndp_check = QCheckBox("Автопечать НДП после успешного привоза")
        self.auto_ndp_check.setChecked(bool(cfg.get("auto_print_ndp", False)))
        self.auto_ndp_check.stateChanged.connect(self.print_settings_changed)
        self.auto_price_tags_check = QCheckBox("Автопечать ценников после успешного привоза")
        self.auto_price_tags_check.setChecked(bool(cfg.get("auto_print_price_tags", True)))
        self.auto_price_tags_check.stateChanged.connect(self.print_settings_changed)
        self.catalog_ready_check = QCheckBox("Подготавливать каталог при входе в Windows")
        self.catalog_ready_check.setChecked(bool(cfg.get("sai_ready_enabled", True)))
        self.catalog_ready_check.setToolTip("SAI Ready запускается скрыто после входа в Windows и заранее обновляет локальный каталог.")
        self.catalog_ready_check.stateChanged.connect(self.catalog_settings_changed)
        for cb in (self.browser_check, self.logs_check, self.notifications_check, self.auto_ndp_check, self.auto_price_tags_check, self.catalog_ready_check):
            cb.setObjectName("SettingsCheck")
            bl.addWidget(cb)
        ready_snapshot = sai_catalog_ready.catalog_snapshot(cfg)
        ready_status = sai_catalog_ready.read_status()
        if ready_snapshot.get("catalog_present"):
            ready_text = (
                f"SAI Ready: локальный каталог — {int(ready_snapshot.get('product_count') or 0)} товаров, "
                f"{int(ready_snapshot.get('barcode_count') or 0)} ШК; возраст "
                f"{sai_catalog_ready.human_age(ready_snapshot.get('age_seconds'))}."
            )
        else:
            ready_text = "SAI Ready: локальный каталог ещё не создан; первая загрузка выполнится при запуске SAI."
        if safe_str(ready_status.get("state")) in {"refreshing", "waiting", "retry_wait"}:
            ready_text += " Сейчас каталог подготавливается в фоне."
        self.catalog_ready_hint = QLabel(ready_text)
        self.catalog_ready_hint.setObjectName("WorkbenchNote")
        self.catalog_ready_hint.setWordWrap(True)
        bl.addWidget(self.catalog_ready_hint)
        cat_row = QHBoxLayout(); cat_row.setSpacing(10)
        self.catalog_refresh_now_btn = QPushButton("Обновить каталог сейчас")
        self.catalog_refresh_now_btn.setObjectName("SoftButton")
        self.catalog_refresh_now_btn.clicked.connect(self.parent_page.force_catalog_refresh_now)
        cat_row.addWidget(self.catalog_refresh_now_btn)

        self.catalog_rebuild_hold_timer = QTimer(self)
        self.catalog_rebuild_hold_timer.setSingleShot(True)
        self.catalog_rebuild_hold_timer.setInterval(5000)
        self.catalog_rebuild_hold_timer.timeout.connect(self.rebuild_catalog_by_hold)
        self.catalog_rebuild_btn = QPushButton("Полная пересборка каталога")
        self.catalog_rebuild_btn.setObjectName("DangerHoldButton")
        self.catalog_rebuild_btn.setToolTip("Удерживай 5 секунд: SAI заново скачает каталог SIGMA и заменит локальный кэш.")
        self.catalog_rebuild_btn.pressed.connect(self.start_catalog_rebuild_hold)
        self.catalog_rebuild_btn.released.connect(self.cancel_catalog_rebuild_hold)
        self.catalog_rebuild_btn.leaveEvent = lambda event, _orig=self.catalog_rebuild_btn.leaveEvent: (self.cancel_catalog_rebuild_hold(), _orig(event))[1]

        self.manual_sigma_login_btn = QPushButton("Ручной вход в SIGMA")
        self.manual_sigma_login_btn.setObjectName("WorkbenchPrimaryButton")
        self.manual_sigma_login_btn.setToolTip(
            "Открыть видимый браузер SAI, войти в SIGMA вручную и затем обновить поставщиков и каталог."
        )
        self.manual_sigma_login_btn.clicked.connect(self.start_manual_sigma_login)
        cat_row.addWidget(self.manual_sigma_login_btn)
        cat_row.addWidget(self.catalog_rebuild_btn)
        cat_row.addStretch(1)
        bl.addLayout(cat_row)
        rebuild_hint = QLabel("Полная пересборка нужна, если число товаров в SAI отличается от SIGMA или каталог явно устарел. Запускается в фоне, интерфейс не зависает.")
        rebuild_hint.setObjectName("WorkbenchNote")
        rebuild_hint.setWordWrap(True)
        bl.addWidget(rebuild_hint)
        root.addWidget(behavior)

        thermal = QFrame(); thermal.setObjectName("WorkbenchCard")
        thl = QVBoxLayout(thermal); thl.setContentsMargins(12, 10, 12, 10); thl.setSpacing(8)
        self.thermal_toggle_btn = SettingsDisclosureButton("Принтеры", parent=thermal)
        self.thermal_toggle_btn.toggled.connect(self.set_thermal_settings_expanded)
        thl.addWidget(self.thermal_toggle_btn)
        self.thermal_body = QWidget(thermal)
        self.thermal_body.setObjectName("SettingsDisclosureBody")
        thermal_body_layout = QVBoxLayout(self.thermal_body)
        thermal_body_layout.setContentsMargins(6, 4, 6, 6)
        thermal_body_layout.setSpacing(10)
        thl.addWidget(self.thermal_body)
        thform = QFormLayout(); thform.setHorizontalSpacing(12); thform.setVerticalSpacing(10)
        self.thermal_printer_combo = NoWheelComboBox(); self.thermal_printer_combo.setObjectName("WorkbenchCombo")
        self.thermal_printer_combo.setEditable(True)
        if self.thermal_printer_combo.lineEdit():
            self.thermal_printer_combo.lineEdit().setObjectName("WorkbenchInput")
            self.thermal_printer_combo.lineEdit().setPlaceholderText("Выберите подключенный принтер или введите имя вручную")
            self.thermal_printer_combo.lineEdit().editingFinished.connect(self.thermal_settings_changed)
        self.thermal_printer_refresh_btn = QPushButton("Обновить")
        self.thermal_printer_refresh_btn.setObjectName("SoftButton")
        self.thermal_printer_refresh_btn.clicked.connect(lambda: (self.populate_thermal_printers(True), self.populate_extra_printer_combos(False)))
        self.a4_printer_combo = NoWheelComboBox(); self.a4_printer_combo.setObjectName("WorkbenchCombo"); self.a4_printer_combo.setEditable(True)
        if self.a4_printer_combo.lineEdit():
            self.a4_printer_combo.lineEdit().setObjectName("WorkbenchInput")
            self.a4_printer_combo.lineEdit().setPlaceholderText("Выберите обычный принтер для бумаги A4")
            self.a4_printer_combo.lineEdit().editingFinished.connect(self.thermal_settings_changed)
        self.populate_thermal_printers(False)
        self.populate_extra_printer_combos(False)
        self.thermal_printer_combo.currentIndexChanged.connect(lambda _=None: self.thermal_settings_changed())
        self.a4_printer_combo.currentIndexChanged.connect(lambda _=None: self.thermal_settings_changed())
        self.thermal_size_combo = NoWheelComboBox(); self.thermal_size_combo.setObjectName("WorkbenchCombo")
        self.thermal_size_combo.addItem("58×40 мм", "58x40")
        self.thermal_size_combo.addItem("43×25 мм", "43x25")
        self.thermal_size_combo.addItem("30×20 мм · цена и ШК", "30x20")
        size = str(cfg.get("thermal_label_size") or "58x40").lower().replace("×", "x").replace(" ", "")
        idx = self.thermal_size_combo.findData(size)
        self.thermal_size_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.thermal_size_combo.currentIndexChanged.connect(lambda _=None: self.thermal_settings_changed())
        self.thermal_method_combo = NoWheelComboBox(); self.thermal_method_combo.setObjectName("WorkbenchCombo")
        self.thermal_method_combo.addItem("Авто: TSPL RAW, затем драйвер Windows", "auto")
        self.thermal_method_combo.addItem("Только через драйвер Windows", "driver")
        self.thermal_method_combo.addItem("Только TSPL RAW", "raw")
        method = str(cfg.get("thermal_label_print_method") or "auto").lower().strip()
        idx = self.thermal_method_combo.findData(method)
        self.thermal_method_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.thermal_method_combo.currentIndexChanged.connect(lambda _=None: self.thermal_settings_changed())
        self.thermal_polarity_combo = NoWheelComboBox(); self.thermal_polarity_combo.setObjectName("WorkbenchCombo")
        self.thermal_polarity_combo.addItem("4BARCODE / Xprinter: нормальная печать", True)
        self.thermal_polarity_combo.addItem("Классическая TSPL-полярность", False)
        polarity = bool(cfg.get("thermal_label_tspl_invert", True))
        idx = self.thermal_polarity_combo.findData(polarity)
        self.thermal_polarity_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.thermal_polarity_combo.currentIndexChanged.connect(lambda _=None: self.thermal_settings_changed())
        self.thermal_max_combo = NoWheelComboBox(); self.thermal_max_combo.setObjectName("WorkbenchCombo")
        for n in (5, 10, 20, 50, 100):
            self.thermal_max_combo.addItem(str(n), n)
        max_confirm = int(cfg.get("thermal_label_max_without_confirm") or 20)
        idx = self.thermal_max_combo.findData(max_confirm)
        self.thermal_max_combo.setCurrentIndex(idx if idx >= 0 else 2)
        self.thermal_max_combo.currentIndexChanged.connect(lambda _=None: self.thermal_settings_changed())

        def make_thermal_slider(attr: str, value_attr: str, minimum: int, maximum: int, value: int, suffix: str = "%", tick: int = 10):
            slider = QSlider(Qt.Horizontal)
            slider.setObjectName("WorkbenchSlider")
            slider.setRange(minimum, maximum)
            slider.setSingleStep(5 if suffix == "%" else 1)
            slider.setPageStep(10 if suffix == "%" else 5)
            slider.setTickPosition(QSlider.TicksBelow)
            slider.setTickInterval(tick)
            slider.setValue(max(minimum, min(maximum, int(value))))
            label = QLabel()
            label.setObjectName("WorkbenchNote")
            setattr(self, attr, slider)
            setattr(self, value_attr, label)
            slider.valueChanged.connect(self.thermal_layout_changed)
            return slider, label

        scale_percent = max(80, min(160, int(cfg.get("thermal_label_scale_percent") or 130)))
        price_scale_percent = max(70, min(180, int(cfg.get("thermal_label_price_scale_percent") or 120)))
        barcode_scale_percent = max(70, min(180, int(cfg.get("thermal_label_barcode_scale_percent") or 125)))
        offset_x = max(-50, min(50, int(cfg.get("thermal_label_offset_x_tenth_mm") or 0)))
        offset_y = max(-50, min(50, int(cfg.get("thermal_label_offset_y_tenth_mm") or 0)))
        self.thermal_scale_slider, self.thermal_scale_value = make_thermal_slider("thermal_scale_slider", "thermal_scale_value", 80, 160, scale_percent, "%", 10)
        self.thermal_price_scale_slider, self.thermal_price_scale_value = make_thermal_slider("thermal_price_scale_slider", "thermal_price_scale_value", 70, 180, price_scale_percent, "%", 10)
        self.thermal_barcode_scale_slider, self.thermal_barcode_scale_value = make_thermal_slider("thermal_barcode_scale_slider", "thermal_barcode_scale_value", 70, 180, barcode_scale_percent, "%", 10)
        self.thermal_offset_x_slider, self.thermal_offset_x_value = make_thermal_slider("thermal_offset_x_slider", "thermal_offset_x_value", -50, 50, offset_x, "мм", 10)
        self.thermal_offset_y_slider, self.thermal_offset_y_value = make_thermal_slider("thermal_offset_y_slider", "thermal_offset_y_value", -50, 50, offset_y, "мм", 10)
        self.thermal_layout_changed(save=False)

        a4_row = QHBoxLayout(); a4_row.setSpacing(8)
        a4_row.addWidget(self.a4_printer_combo, 1)
        a4_row.addWidget(self.thermal_printer_refresh_btn, 0)
        a4_wrap = QWidget(); a4_wrap.setObjectName("TransparentPanel"); a4_wrap.setLayout(a4_row)
        thform.addRow("Обычная печать (A4)", a4_wrap)
        thform.addRow("Термоэтикетки", self.thermal_printer_combo)
        thform.addRow("Размер", self.thermal_size_combo)
        thform.addRow("Способ печати", self.thermal_method_combo)
        thform.addRow("Полярность TSPL", self.thermal_polarity_combo)
        thform.addRow("Подтверждать свыше", self.thermal_max_combo)
        def slider_row(slider: QSlider, value_label: QLabel) -> QWidget:
            row = QHBoxLayout(); row.setSpacing(10)
            row.addWidget(slider, 1)
            row.addWidget(value_label, 0)
            wrap = QWidget(); wrap.setObjectName("TransparentPanel"); wrap.setLayout(row)
            return wrap

        thform.addRow("Общий масштаб", slider_row(self.thermal_scale_slider, self.thermal_scale_value))
        thform.addRow("Крупность цены", slider_row(self.thermal_price_scale_slider, self.thermal_price_scale_value))
        thform.addRow("Крупность ШК", slider_row(self.thermal_barcode_scale_slider, self.thermal_barcode_scale_value))
        thform.addRow("Сдвиг X", slider_row(self.thermal_offset_x_slider, self.thermal_offset_x_value))
        thform.addRow("Сдвиг Y", slider_row(self.thermal_offset_y_slider, self.thermal_offset_y_value))
        thermal_body_layout.addLayout(thform)

        preview_title = QLabel("Предпросмотр этикетки")
        preview_title.setObjectName("WorkbenchLabel")
        thermal_body_layout.addWidget(preview_title)
        self.thermal_preview = QLabel()
        self.thermal_preview.setObjectName("BarcodePreview")
        self.thermal_preview.setMinimumHeight(150)
        self.thermal_preview.setAlignment(Qt.AlignCenter)
        self.thermal_preview.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        thermal_body_layout.addWidget(self.thermal_preview)
        test_row = QHBoxLayout(); test_row.setSpacing(10)
        self.thermal_test_btn = QPushButton("Напечатать тестовую этикетку")
        self.thermal_test_btn.setObjectName("SoftButton")
        self.thermal_test_btn.clicked.connect(lambda: print_test_thermal_label(self))
        self.thermal_reset_layout_btn = QPushButton("Хорошие значения")
        self.thermal_reset_layout_btn.setObjectName("SoftButton")
        self.thermal_reset_layout_btn.clicked.connect(self.reset_thermal_layout_defaults)
        test_row.addWidget(self.thermal_test_btn)
        test_row.addWidget(self.thermal_reset_layout_btn)
        test_row.addStretch(1)
        thermal_body_layout.addLayout(test_row)
        thnote = QLabel(
            "Обычная печать — все документы и ценники на листах A4. "
            "Термоэтикетки — только маленькие этикетки полуавтоматического привоза и ручной накладной. "
            "SAI никогда не отправляет A4 на 4BARCODE/Xprinter. Если RAW-печать этикеток не стартует, "
            "выбери «Только через драйвер Windows» или оставь «Авто»."
        )
        thnote.setObjectName("WorkbenchNote"); thnote.setWordWrap(True)
        thermal_body_layout.addWidget(thnote)
        self.update_thermal_preview()
        self.update_thermal_settings_summary()
        self.set_thermal_settings_expanded(bool(cfg.get("thermal_settings_expanded", False)), persist=False)
        root.addWidget(thermal)

        root.addStretch(1)

    def _organization_settings(self) -> sai_organization_sync.SyncSettings:
        cfg = load_private_config()
        return sai_organization_sync.SyncSettings.from_config(cfg)

    def choose_scan_folder(self) -> None:
        current = safe_str(self.scan_folder_edit.text())
        selected = QFileDialog.getExistingDirectory(
            self,
            "Выберите папку, куда сканер сохраняет накладные",
            current or str(Path.home() / "Documents"),
        )
        if not selected:
            return
        folder = Path(selected).resolve()
        save_private_config_patch({
            "invoice_scan_folder": str(folder),
            "invoice_scan_last_selected_ns": 0,
        })
        self.scan_folder_edit.setText(str(folder))
        converter = getattr(self.parent_page, "converter_page", None)
        if converter is not None:
            converter.refresh_fresh_scan_button()
        self.parent_page.notify("Сканер накладных", "Папка сохранена. SAI уже следит за новыми файлами.", "success")

    def open_scan_folder(self) -> None:
        folder = Path(safe_str(self.scan_folder_edit.text())).expanduser()
        if not folder.is_dir():
            self.parent_page.notify("Сканер накладных", "Сначала выбери доступную папку сканера.", "warning")
            return
        open_path(folder)

    def choose_organization_folder(self) -> None:
        current = safe_str(getattr(self, "organization_path_edit", None).text() if getattr(self, "organization_path_edit", None) else "")
        start = current or str(Path.home())
        selected = QFileDialog.getExistingDirectory(
            self,
            "Выбери папку, общую для двух компьютеров",
            start,
        )
        if not selected:
            return
        self._connect_organization_root(Path(selected))

    def connect_organization_path(self) -> None:
        raw = safe_str(self.organization_path_edit.text())
        if not raw:
            self.parent_page.notify("Общая папка", "Введи сетевой путь или выбери папку.", "warning")
            return
        self._connect_organization_root(Path(raw))

    def _connect_organization_root(self, base: Path) -> None:
        root = base if (base / sai_organization_sync.ORGANIZATION_FILE).exists() or base.name.casefold() == "sai organization" else base / "SAI Organization"
        cfg = load_private_config()
        device_id = safe_str(cfg.get("organization_device_id")) or sai_organization_sync.new_device_id()
        organization_name = safe_str(self.organization_name_edit.text()) or "Моя организация"
        device_name = safe_str(self.organization_device_edit.text()) or sai_organization_sync.default_device_name()
        settings = sai_organization_sync.SyncSettings(True, root, organization_name, device_id, device_name)
        try:
            sai_organization_sync.initialize_organization(settings)
        except Exception as exc:
            QMessageBox.warning(self, "Общая папка", f"Не удалось подключить общую папку:\n{exc}")
            return
        save_private_config_patch({
            "organization_sync_enabled": True,
            "organization_sync_root": str(root),
            "organization_name": organization_name,
            "organization_device_id": device_id,
            "organization_device_name": device_name,
        })
        self.organization_path_edit.setText(str(root))
        self.organization_device_edit.setText(device_name)
        self.organization_name_edit.setText(organization_name)
        self.refresh_organization_status("Папка подключена. Запускаю первую синхронизацию…")
        self.parent_page.sync_organization_now(notify=True)

    def open_organization_folder(self) -> None:
        settings = self._organization_settings()
        if not settings.valid or not settings.root.exists():
            self.parent_page.notify("Общая папка", "Сначала подключи общую папку организации.", "warning")
            return
        open_path(settings.root)

    def install_organization_update(self) -> None:
        settings = self._organization_settings()
        try:
            package = sai_organization_sync.update_package(settings)
        except Exception as exc:
            QMessageBox.warning(self, "Обновление SAI", str(exc))
            return
        if package is None:
            self.parent_page.notify("Обновление SAI", "Файл обновления ещё не появился в общей папке.", "warning")
            return
        suffix = package.suffix.casefold()
        if suffix in {".cmd", ".bat", ".exe", ".msi"}:
            try:
                os.startfile(str(package))  # type: ignore[attr-defined]
                self.parent_page.notify("Обновление SAI", "Установщик запущен. Закрой SAI, когда он попросит.", "success")
            except Exception as exc:
                QMessageBox.warning(self, "Обновление SAI", f"Не удалось запустить установщик:\n{exc}")
        else:
            open_path(package.parent)
            self.parent_page.notify("Обновление SAI", f"Открыта папка с обновлением {package.name}.", "info")

    def refresh_github_update_status(self) -> None:
        running = bool(getattr(self.parent_page, "_github_update_running", False))
        info = getattr(self.parent_page, "_github_update_info", None)
        error = safe_str(getattr(self.parent_page, "_github_update_error", ""))
        check_button = getattr(self, "github_update_check_btn", None)
        install_button = getattr(self, "github_update_install_btn", None)
        status = getattr(self, "github_update_status", None)
        channel_combo = getattr(self, "github_update_channel_combo", None)
        channel = self.parent_page.github_update_channel()
        channel_name = "тестовая" if channel == "development" else "стабильная"
        if channel_combo is not None:
            channel_combo.setEnabled(not running)
        if check_button is not None:
            check_button.setEnabled(not running)
            check_button.setText("Проверяю…" if running else "Проверить обновления")
        if install_button is not None:
            install_button.setVisible(info is not None)
            install_button.setEnabled(not running)
            install_button.setText("Загружаю…" if running and info is not None else "Скачать и установить")
        if status is None:
            return
        if running:
            status.setText(f"Проверяю канал «{channel_name}»…")
        elif info is not None:
            size_mb = float(getattr(info, "size", 0) or 0) / (1024 * 1024)
            status.setText(f"Доступна версия v{info.version} · {size_mb:.1f} МБ. Пакет будет проверен перед запуском.")
        elif error:
            status.setText("Не удалось проверить обновления: " + error)
        else:
            status.setText(f"Установлена актуальная версия {APP_VERSION} для канала «{channel_name}».")

    def github_update_channel_changed(self, *_args: Any) -> None:
        combo = getattr(self, "github_update_channel_combo", None)
        if combo is None:
            return
        channel = safe_str(combo.currentData()).casefold()
        if channel not in {"production", "development"}:
            channel = "production"
        save_private_config_patch({"github_update_channel": channel})
        self.parent_page._github_update_info = None
        self.parent_page._github_update_error = ""
        self.parent_page.check_github_update(notify=True)

    def save_organization_identity(self) -> None:
        cfg = load_private_config()
        save_private_config_patch({
            "organization_name": safe_str(self.organization_name_edit.text()) or "Моя организация",
            "organization_device_name": safe_str(self.organization_device_edit.text()) or sai_organization_sync.default_device_name(),
            "organization_device_id": safe_str(cfg.get("organization_device_id")) or sai_organization_sync.new_device_id(),
        })

    def refresh_organization_status(self, override: str = "") -> None:
        self.save_organization_identity()
        settings = self._organization_settings()
        connected = settings.valid and settings.root.exists()
        for name in ("organization_sync_btn", "organization_open_btn"):
            button = getattr(self, name, None)
            if button is not None:
                button.setEnabled(connected)
        if override:
            text = override
        elif not settings.enabled:
            text = r"Не подключено. Расшарь папку Windows и введи путь вида \\КОМПЬЮТЕР\SAI_SYNC либо выбери папку Яндекс Диска."
        elif not settings.root.exists():
            text = "Общая папка сейчас недоступна. Проверь сеть, включён ли компьютер-хозяин и разрешён ли доступ к папке."
        else:
            report = getattr(self.parent_page, "_organization_sync_last_report", None)
            if report is None:
                text = f"Подключено: {settings.root}. Ожидаю первую синхронизацию."
            elif report.ok:
                text = report.message
                if report.available_version:
                    text += f" Доступна версия SAI {report.available_version}."
            else:
                text = "Ошибка синхронизации: " + safe_str(report.message)
        label = getattr(self, "organization_status", None)
        if label is not None:
            label.setText(text)
        update_button = getattr(self, "organization_update_btn", None)
        if update_button is not None:
            report = getattr(self.parent_page, "_organization_sync_last_report", None)
            update_button.setVisible(bool(report and safe_str(getattr(report, "available_version", ""))))

    def update_thermal_settings_summary(self) -> None:
        button = getattr(self, "thermal_toggle_btn", None)
        if button is None:
            return
        printer = safe_str(getattr(self, "thermal_printer_combo", None).currentText() if getattr(self, "thermal_printer_combo", None) else "").strip()
        a4_printer = safe_str(getattr(self, "a4_printer_combo", None).currentText() if getattr(self, "a4_printer_combo", None) else "").strip()
        size = safe_str(getattr(self, "thermal_size_combo", None).currentText() if getattr(self, "thermal_size_combo", None) else "").strip()
        parts = [part for part in (
            f"A4: {a4_printer}" if a4_printer else "",
            f"термо: {printer}" if printer else "",
            size,
        ) if part]
        button.set_summary(" · ".join(parts) if parts else "Параметры печати и макета")

    def set_thermal_settings_expanded(self, expanded: bool, persist: bool = True) -> None:
        body = getattr(self, "thermal_body", None)
        button = getattr(self, "thermal_toggle_btn", None)
        value = bool(expanded)
        if body is not None:
            body.setVisible(value)
        if button is not None and button.isChecked() != value:
            button.blockSignals(True)
            button.setChecked(value)
            button.blockSignals(False)
            button._sync_arrow(value)
        if persist:
            save_private_config_patch({"thermal_settings_expanded": value})

    def open_private_config(self) -> None:
        path = ensure_private_config_file()
        open_path(path)
        self.parent_page.notify("Настройки", "Открыт sai_private_config.json", "info")

    def _set_manual_sigma_login_running(self, running: bool) -> None:
        self.manual_sigma_login_running = bool(running)
        button = getattr(self, "manual_sigma_login_btn", None)
        if button is not None:
            button.setEnabled(not running)
            button.setText("Жду вход в SIGMA…" if running else "Ручной вход в SIGMA")

    def start_manual_sigma_login(self) -> None:
        if self.manual_sigma_login_running:
            self.parent_page.notify("SIGMA", "SAI уже ждёт ручного входа.", "info")
            return
        if getattr(self.parent_page, "offline_mode", False):
            self.parent_page.notify("SIGMA", "В offline-режиме войти в SIGMA нельзя.", "warning")
            return
        if getattr(self.parent_page, "_background_catalog_running", False):
            self.parent_page.notify("SIGMA", "Дождись окончания текущего обновления каталога.", "info")
            return
        workbench = getattr(self.parent_page, "workbench_page", None)
        if workbench is None:
            self.parent_page.notify("SIGMA", "Экран приёмки ещё не готов.", "warning")
            return

        self._set_manual_sigma_login_running(True)
        self.parent_page.notify(
            "Ручной вход в SIGMA",
            "В открывшемся окне войди через ATOL ID. SAI продолжит сам, когда увидит успешный вход.",
            "info",
        )
        started = workbench.load_suppliers_async(
            manual_login=True,
            on_finished=self._manual_sigma_suppliers_finished,
        )
        if not started:
            self._set_manual_sigma_login_running(False)

    def _manual_sigma_suppliers_finished(self, ok: bool, message: str) -> None:
        self._set_manual_sigma_login_running(False)
        if not ok:
            self.parent_page.notify("Ручной вход в SIGMA", message, "warning")
            return
        self.parent_page.notify(
            "Ручной вход в SIGMA",
            message + " Запускаю полную пересборку каталога…",
            "success",
        )
        self.parent_page.force_catalog_full_rebuild_now()

    def start_catalog_rebuild_hold(self) -> None:
        if getattr(self.parent_page, "_background_catalog_running", False):
            self.parent_page.notify("Каталог", "Обновление каталога уже идёт.", "info")
            return
        if getattr(self, "catalog_rebuild_btn", None) is not None:
            self.catalog_rebuild_btn.setText("Держи 5 сек…")
            self.catalog_rebuild_btn.setToolTip("Не отпускай: полная пересборка каталога начнётся через 5 секунд")
        if getattr(self, "catalog_rebuild_hold_timer", None) is not None:
            self.catalog_rebuild_hold_timer.start()

    def cancel_catalog_rebuild_hold(self) -> None:
        if getattr(self, "catalog_rebuild_hold_timer", None) is not None and self.catalog_rebuild_hold_timer.isActive():
            self.catalog_rebuild_hold_timer.stop()
        if getattr(self, "catalog_rebuild_btn", None) is not None:
            self.catalog_rebuild_btn.setText("Полная пересборка каталога")
            self.catalog_rebuild_btn.setToolTip("Удерживай 5 секунд: SAI заново скачает каталог SIGMA и заменит локальный кэш.")

    def rebuild_catalog_by_hold(self) -> None:
        if getattr(self, "catalog_rebuild_btn", None) is not None:
            self.catalog_rebuild_btn.setText("Полная пересборка каталога")
            self.catalog_rebuild_btn.setToolTip("Удерживай 5 секунд: SAI заново скачает каталог SIGMA и заменит локальный кэш.")
        self.parent_page.force_catalog_full_rebuild_now()

    def _sync_theme_controls(self, mode: str | None = None) -> None:
        value = normalize_theme_mode(mode or self.theme_selector.mode())
        descriptions = {
            "day": "Светлое оформление остаётся включённым, пока ты сам его не поменяешь.",
            "night": "Тёмное оформление остаётся включённым, пока ты сам его не поменяешь.",
        }
        self.theme_mode_description.setText(descriptions[value])

    def _apply_theme_settings_now(self) -> None:
        app = QApplication.instance()
        controller = getattr(app, "_sai_theme_controller", None) if app is not None else None
        if controller is not None:
            controller.reload_settings(apply_now=True)

    def theme_mode_changed(self, mode: str) -> None:
        if getattr(self, "_loading_theme_ui", False):
            return
        value = normalize_theme_mode(mode)
        save_private_config_patch({"theme_mode": value})
        self._sync_theme_controls(value)
        self._apply_theme_settings_now()

    def notifications_changed(self) -> None:
        enabled = bool(self.notifications_check.isChecked())
        save_private_config_patch({"hub_notifications_enabled": enabled})
        if enabled:
            self.parent_page.notify("УВЕДОМЛЕНИЯ ВКЛЮЧЕНЫ", "Короткие сообщения будут появляться в правом нижнем углу.", "success")

    def category_settings_changed(self) -> None:
        """Compatibility no-op: category assignment for new products is separate."""
        return

    def print_settings_changed(self) -> None:
        save_private_config_patch({
            "auto_print_ndp": bool(getattr(self, "auto_ndp_check", None) and self.auto_ndp_check.isChecked()),
            "auto_print_price_tags": bool(getattr(self, "auto_price_tags_check", None) and self.auto_price_tags_check.isChecked()),
        })
        self.parent_page.notify("Печать", "Настройки автопечати сохранены.", "success")

    def catalog_settings_changed(self) -> None:
        enabled = bool(getattr(self, "catalog_ready_check", None) and self.catalog_ready_check.isChecked())
        save_private_config_patch({
            "sai_ready_enabled": enabled,
            "catalog_force_refresh_on_startup": False,
        })
        try:
            if enabled:
                path = sai_ready_autostart.install_autostart(ROOT_DIR)
                message = "SAI Ready включён: каталог будет подготавливаться при входе в Windows."
                if path is None:
                    message = "SAI Ready включён, но автозапуск доступен только в Windows."
            else:
                sai_ready_autostart.remove_autostart()
                message = "Фоновая подготовка каталога при входе в Windows отключена."
            self.parent_page.notify("Каталог", message, "success")
        except Exception as exc:
            self.parent_page.notify("Каталог", "Не удалось изменить автозапуск: " + str(exc)[:180], "warning")

    def thermal_preview_item(self) -> Dict[str, Any]:
        size_key = str(getattr(self, "thermal_size_combo", None).currentData() if getattr(self, "thermal_size_combo", None) else "58x40")
        if size_key == "43x25":
            name = "ТЕСТОВЫЙ ЦЕННИК SAI"
        else:
            name = "ТЕСТОВЫЙ ЦЕННИК SAI"
        return {"name": name, "barcode": "10000542", "price": 123, "unit": "штука"}

    def update_thermal_preview(self) -> None:
        label = getattr(self, "thermal_preview", None)
        if label is None:
            return
        try:
            size_key = str(getattr(self, "thermal_size_combo", None).currentData() if getattr(self, "thermal_size_combo", None) else "58x40")
            img = _draw_thermal_label_image(self.thermal_preview_item(), size_key)
            pix = QPixmap.fromImage(img)
            target_w = max(260, label.width() - 24)
            target_h = 170 if size_key == "58x40" else 140
            label.setPixmap(pix.scaled(target_w, target_h, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            label.setText("")
        except Exception as exc:
            label.setPixmap(QPixmap())
            label.setText(f"Не удалось построить предпросмотр: {exc}")

    def thermal_layout_changed(self, value: int | None = None, save: bool = True) -> None:
        pairs = (
            ("thermal_scale_slider", "thermal_scale_value", "%"),
            ("thermal_price_scale_slider", "thermal_price_scale_value", "%"),
            ("thermal_barcode_scale_slider", "thermal_barcode_scale_value", "%"),
        )
        for slider_name, label_name, suffix in pairs:
            slider = getattr(self, slider_name, None)
            label = getattr(self, label_name, None)
            if slider is not None and label is not None:
                label.setText(f"{int(slider.value())}{suffix}")
        for slider_name, label_name in (("thermal_offset_x_slider", "thermal_offset_x_value"), ("thermal_offset_y_slider", "thermal_offset_y_value")):
            slider = getattr(self, slider_name, None)
            label = getattr(self, label_name, None)
            if slider is not None and label is not None:
                label.setText(f"{slider.value() / 10.0:+.1f} мм")
        if save:
            self.thermal_settings_changed(notify=False)

    def reset_thermal_layout_defaults(self) -> None:
        size_key = str(getattr(self, "thermal_size_combo", None).currentData() if getattr(self, "thermal_size_combo", None) else "58x40")
        defaults = {
            "58x40": (130, 120, 125, 0, 0),
            "43x25": (115, 110, 110, 0, 0),
            "30x20": (100, 100, 100, 0, 0),
        }.get(size_key, (130, 120, 125, 0, 0))
        sliders = (
            getattr(self, "thermal_scale_slider", None),
            getattr(self, "thermal_price_scale_slider", None),
            getattr(self, "thermal_barcode_scale_slider", None),
            getattr(self, "thermal_offset_x_slider", None),
            getattr(self, "thermal_offset_y_slider", None),
        )
        for slider, val in zip(sliders, defaults):
            if slider is not None:
                slider.blockSignals(True)
                slider.setValue(int(val))
                slider.blockSignals(False)
        self.thermal_layout_changed(save=True)
        self.parent_page.notify("Термоэтикетки", "Вернул хорошие значения макета.", "success")

    # Compatibility name for older signal connections in patched installations.
    def thermal_scale_changed(self, value: int) -> None:
        self.thermal_layout_changed(value, save=True)


    def _fill_printer_combo(self, combo: QComboBox, current: str, *, allow_thermal: bool = True) -> None:
        names = _list_windows_printers()
        if not allow_thermal:
            names = [name for name in names if not _is_thermal_printer_name(name)]
        default_name = _get_default_windows_printer()
        combo.blockSignals(True)
        combo.clear()
        if names:
            for name in names:
                label = name + ("  • по умолчанию" if default_name and name == default_name else "")
                combo.addItem(label, name)
        if current and current not in names:
            combo.addItem(current + "  • вручную", current)
        if not names and not current:
            combo.addItem("", "")
        idx = -1
        for i in range(combo.count()):
            if safe_str(combo.itemData(i)) == current:
                idx = i
                break
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        combo.blockSignals(False)

    def populate_extra_printer_combos(self, notify: bool = False) -> None:
        cfg = load_private_config()
        combo = getattr(self, "a4_printer_combo", None)
        if combo is None:
            return
        names = _list_windows_printers()
        resolved = _resolve_a4_printer_name(
            cfg.get("a4_printer") or cfg.get("document_printer") or cfg.get("price_tags_printer"),
            names,
            _get_default_windows_printer(),
        )
        self._fill_printer_combo(combo, resolved, allow_thermal=False)
        if resolved and any(
            safe_str(cfg.get(key)).strip() != resolved
            for key in ("a4_printer", "document_printer", "price_tags_printer")
        ):
            save_private_config_patch({
                "a4_printer": resolved,
                "document_printer": resolved,
                "price_tags_printer": resolved,
            })
        if notify:
            if resolved:
                self.parent_page.notify("Принтеры", f"Обычная печать A4: {resolved}", "success")
            else:
                self.parent_page.notify("Принтеры", "Обычный A4-принтер не найден.", "warning")

    def populate_thermal_printers(self, notify: bool = False) -> None:
        combo = getattr(self, "thermal_printer_combo", None)
        if combo is None:
            return
        cfg = load_private_config()
        configured = safe_str(cfg.get("thermal_label_printer") or combo.currentText()).strip()
        names = _list_windows_printers()
        default_name = _get_default_windows_printer()
        current = _resolve_windows_printer_name(configured, names, default_name)
        if current and current != configured:
            patch = {"thermal_label_printer": current}
            configured_free = safe_str(cfg.get("thermal_free_receipt_printer")).strip()
            if not configured_free or configured_free == configured:
                patch["thermal_free_receipt_printer"] = current
            save_private_config_patch(patch)
        combo.blockSignals(True)
        combo.clear()
        if names:
            for name in names:
                label = name + ("  • по умолчанию" if default_name and name == default_name else "")
                combo.addItem(label, name)
        if current and current not in names:
            combo.addItem(current + "  • вручную", current)
        if not names and not current:
            combo.addItem("", "")
        idx = -1
        for i in range(combo.count()):
            if safe_str(combo.itemData(i)) == current:
                idx = i
                break
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        combo.blockSignals(False)
        if notify:
            if names:
                self.parent_page.notify("Принтеры", f"Найдено принтеров: {len(names)}", "success")
            else:
                self.parent_page.notify("Принтеры", "Windows не вернул список принтеров. Имя можно ввести вручную.", "warning")

    def thermal_settings_changed(self, notify: bool = True) -> None:
        printer = ""
        combo = getattr(self, "thermal_printer_combo", None)
        if combo is not None:
            printer = safe_str(combo.currentData() or combo.currentText()).strip()
            printer = re.sub(r"\s+•\s+(по умолчанию|вручную)\s*$", "", printer).strip()
        a4_printer = ""
        a4_combo = getattr(self, "a4_printer_combo", None)
        if a4_combo is not None:
            a4_printer = safe_str(a4_combo.currentData() or a4_combo.currentText()).strip()
            a4_printer = re.sub(r"\s+•\s+(по умолчанию|вручную)\s*$", "", a4_printer).strip()
        a4_printer = _resolve_a4_printer_name(
            a4_printer,
            _list_windows_printers(),
            _get_default_windows_printer(),
        )
        save_private_config_patch({
            "thermal_label_printer": printer,
            "thermal_free_receipt_printer": printer,
            "a4_printer": a4_printer,
            "document_printer": a4_printer,
            "price_tags_printer": a4_printer,
            "thermal_label_size": str(getattr(self, "thermal_size_combo", None).currentData() if getattr(self, "thermal_size_combo", None) else "58x40"),
            "thermal_label_print_method": str(getattr(self, "thermal_method_combo", None).currentData() if getattr(self, "thermal_method_combo", None) else "auto"),
            "thermal_label_tspl_invert": bool(getattr(self, "thermal_polarity_combo", None).currentData() if getattr(self, "thermal_polarity_combo", None) else True),
            "thermal_label_max_without_confirm": int(getattr(self, "thermal_max_combo", None).currentData() if getattr(self, "thermal_max_combo", None) else 20),
            "thermal_label_scale_percent": int(getattr(self, "thermal_scale_slider", None).value() if getattr(self, "thermal_scale_slider", None) else 130),
            "thermal_label_price_scale_percent": int(getattr(self, "thermal_price_scale_slider", None).value() if getattr(self, "thermal_price_scale_slider", None) else 120),
            "thermal_label_barcode_scale_percent": int(getattr(self, "thermal_barcode_scale_slider", None).value() if getattr(self, "thermal_barcode_scale_slider", None) else 125),
            "thermal_label_offset_x_tenth_mm": int(getattr(self, "thermal_offset_x_slider", None).value() if getattr(self, "thermal_offset_x_slider", None) else 0),
            "thermal_label_offset_y_tenth_mm": int(getattr(self, "thermal_offset_y_slider", None).value() if getattr(self, "thermal_offset_y_slider", None) else 0),
        })
        self.update_thermal_preview()
        self.update_thermal_settings_summary()
        semi_page = getattr(self.parent_page, "semi_receipt_page", None)
        if semi_page is not None and getattr(semi_page, "quick_thermal_size_combo", None) is not None:
            semi_page.sync_quick_thermal_controls_from_config()
        if notify:
            if a4_printer:
                self.parent_page.notify("Принтеры", "Разделение обычной печати и термоэтикеток сохранено.", "success")
            else:
                self.parent_page.notify("Принтеры", "Термопринтер сохранён, но обычный A4-принтер не выбран.", "warning")

    def set_doctor_running(self, running: bool, text: str = "Диагностика") -> None:
        if not getattr(self, "doctor_btn", None):
            return
        self.doctor_btn.setEnabled(not running)
        self.doctor_btn.setText(text)



class RailIconButton(QPushButton):
    """Navigation button with a fixed icon lane and stable compact geometry.

    Qt's native QPushButton icon/text layout changes its internal spacing when
    the text disappears.  That produced the small jumps visible while toggling
    the compact rail.  SAI now owns the icon and label layout explicitly: the
    icon centre stays on the same global x-coordinate in both rail widths, the
    SVG is always rendered at 24 px, and only the label is hidden.
    """

    ICON_FILES = {
        "ux": "mdi/truck-delivery-outline.svg",
        "auto": "mdi/truck-delivery-outline.svg",
        "semi": "mdi/barcode-scan.svg",
        "free": "mdi/plus-box-outline.svg",
        "history": "mdi/history.svg",
        "home": "mdi/history.svg",
        "store": "mdi/store-outline.svg",
        "prices": "mdi/tag-outline.svg",
        "thermal_text": "mdi/printer-outline.svg",
        "stock": "mdi/package-variant-closed.svg",
        "staff": "mdi/account-group-outline.svg",
        "marking": "mdi/data-matrix-scan.svg",
        "settings": "mdi/tune-variant.svg",
        "compact": "panel-collapse.svg",
    }

    def __init__(self, icon_key: str, label: str, primary: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.icon_key = icon_key
        self.label = label
        self.primary = bool(primary)
        self.compact = False
        self._hovered = False
        self.setText("")
        self.setObjectName("StableRailButtonPrimary" if self.primary else "StableRailButton")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(label)
        self.setFixedHeight(46 if self.primary else 42)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self._content_layout = QHBoxLayout(self)
        self._content_layout.setContentsMargins(13, 0, 12, 0)
        self._content_layout.setSpacing(10)

        self.icon_label = QLabel(self)
        self.icon_label.setObjectName("StableRailIcon")
        self.icon_label.setFixedSize(24, 24)
        self.icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.icon_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._content_layout.addWidget(self.icon_label, 0, Qt.AlignmentFlag.AlignVCenter)

        self.text_label = QLabel(label, self)
        self.text_label.setObjectName("StableRailLabel")
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft)
        self.text_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.text_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._content_layout.addWidget(self.text_label, 1)

        self.toggled.connect(lambda _checked: self._sync_visual_state())
        self._load_icon()
        self.set_compact(False)
        # A deferred pass runs after Qt has polished the parent hierarchy. This
        # prevents the first frame from using stale/default palette colours.
        QTimer.singleShot(0, self.refresh_theme)

    def _icon_filename(self) -> str:
        if self.icon_key == "compact":
            return "panel-expand.svg" if self.compact else "panel-collapse.svg"
        return self.ICON_FILES.get(self.icon_key, "mdi/truck-delivery-outline.svg")

    def _visual_color(self) -> QColor:
        app = QApplication.instance()
        dark = bool(app and app.property("saiNightTheme"))
        if not self.isEnabled():
            return QColor("#64748b" if dark else "#94a3b8")
        if self.primary:
            return QColor("#ffffff")
        if self.isChecked() or self._hovered:
            return QColor("#f8fafc" if dark else "#172033")
        return QColor("#b8c4d8" if dark else "#526079")

    def _load_icon(self) -> None:
        app = QApplication.instance()
        dark = bool(app and app.property("saiNightTheme"))
        icon_dir = "icons_dark" if dark else "icons_light"
        icon_path = Path(__file__).resolve().parent / "assets" / icon_dir / self._icon_filename()
        if not icon_path.exists():
            icon_path = Path(__file__).resolve().parent / "assets" / "icons" / self._icon_filename()
        icon = QIcon(str(icon_path)) if icon_path.exists() else QIcon()
        if icon.isNull():
            fallback = {
                "ux": QStyle.StandardPixmap.SP_ArrowDown,
                "auto": QStyle.StandardPixmap.SP_ArrowDown,
                "semi": QStyle.StandardPixmap.SP_FileDialogListView,
                "free": QStyle.StandardPixmap.SP_FileDialogNewFolder,
                "history": QStyle.StandardPixmap.SP_BrowserReload,
                "home": QStyle.StandardPixmap.SP_BrowserReload,
                "store": QStyle.StandardPixmap.SP_DirHomeIcon,
                "prices": QStyle.StandardPixmap.SP_FileDialogContentsView,
                "thermal_text": QStyle.StandardPixmap.SP_DesktopIcon,
                "stock": QStyle.StandardPixmap.SP_DriveHDIcon,
                "staff": QStyle.StandardPixmap.SP_ComputerIcon,
                "marking": QStyle.StandardPixmap.SP_DialogApplyButton,
                "settings": QStyle.StandardPixmap.SP_FileDialogDetailedView,
                "compact": QStyle.StandardPixmap.SP_ToolBarHorizontalExtensionButton,
            }.get(self.icon_key, QStyle.StandardPixmap.SP_FileIcon)
            icon = self.style().standardIcon(fallback)

        source = icon.pixmap(QSize(24, 24))
        tinted = QPixmap(QSize(24, 24))
        tinted.fill(Qt.GlobalColor.transparent)
        painter = QPainter(tinted)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.drawPixmap(0, 0, source)
        painter.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceIn)
        painter.fillRect(tinted.rect(), self._visual_color())
        painter.end()
        self.icon_label.setPixmap(tinted)

    def refresh_theme(self) -> None:
        color = self._visual_color().name()
        self.text_label.setStyleSheet(
            f"background: transparent; border: none; color: {color}; "
            "font-size: 12px; font-weight: 850; padding: 0;"
        )
        self._load_icon()
        self.update()

    def _sync_visual_state(self) -> None:
        self.refresh_theme()

    def set_compact(self, compact: bool) -> None:
        self.compact = bool(compact)
        # Compact mode changes only label visibility and the collapse glyph.
        # Margins, spacing, height and the 24 px icon lane never change, so Qt
        # has no geometry to recalculate and the icon cannot drift by a pixel.
        self.text_label.setVisible(not self.compact)
        self.setProperty("compactRail", self.compact)
        self._load_icon()
        style = self.style()
        if style is not None:
            style.unpolish(self)
            style.polish(self)
        self._sync_visual_state()
        self.update()

    def enterEvent(self, event) -> None:  # noqa: N802 - Qt override
        self._hovered = True
        self._sync_visual_state()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802 - Qt override
        self._hovered = False
        self._sync_visual_state()
        super().leaveEvent(event)

    def showEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().showEvent(event)
        self.refresh_theme()

    def changeEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().changeEvent(event)
        if event.type() in (QEvent.Type.EnabledChange, QEvent.Type.StyleChange, QEvent.Type.PaletteChange) and hasattr(self, "text_label"):
            QTimer.singleShot(0, self.refresh_theme)











class ReceiptUxPreviewPage(QWidget):
    """Release receiving hub built from the approved UX preview.

    The hub is now the production entry point for receipt work. It keeps the
    proven legacy workbench pages intact and routes the user to them from one
    calm, consistent start screen.
    """

    STATE_DATA = {
        "empty": {
            "tab": "Старт",
            "title": "Привоз не открыт",
            "status": ("НЕТ SAI-ФАЙЛА", "gray"),
            "progress": "0/0",
            "progress_value": 0,
            "progress_max": 1,
            "metrics": [("Новых", "—", "gray"), ("Категорий", "—", "gray"), ("Недовоз", "—", "gray")],
            "action": "Открой SAI-файл или подготовь его по накладной",
            "action_chip": ("ожидание", "gray"),
            "primary": "Открыть SAI-файл",
        },
        "scan": {
            "tab": "Сбор ШК",
            "title": "Привоз",
            "status": ("ГОТОВ К СКАНУ", "green"),
            "progress": "ШК · 18/31",
            "progress_value": 18,
            "progress_max": 31,
            "metrics": [("Новых", "4", "green"), ("Категорий", "2", "amber"), ("Недовоз", "1", "gray")],
            "action": "Сканируй ШК позиции №19",
            "action_chip": ("ждёт сканер", "blue"),
            "primary": "Принять ШК",
        },
        "categories": {
            "tab": "Категории",
            "title": "Привоз",
            "status": ("НУЖНЫ КАТЕГОРИИ", "amber"),
            "progress": "Категории · 2",
            "progress_value": 29,
            "progress_max": 31,
            "metrics": [("Новых", "4", "green"), ("Категорий", "2", "amber"), ("Недовоз", "1", "gray")],
            "action": "Укажи категорию для нового товара",
            "action_chip": ("категория", "amber"),
            "primary": "Применить категорию",
        },
        "ready": {
            "tab": "Проверка",
            "title": "Привоз",
            "status": ("ГОТОВО К ПРИХОДУ", "green"),
            "progress": "готово",
            "progress_value": 31,
            "progress_max": 31,
            "metrics": [("Новых", "4", "green"), ("Категорий", "0", "green"), ("Недовоз", "1", "gray")],
            "action": "Проверь итог и запусти приход в SIGMA",
            "action_chip": ("можно запускать", "green"),
            "primary": "Запустить приход",
        },
        "final": {
            "tab": "Финал",
            "title": "Приход завершён",
            "status": ("ГОТОВО", "green"),
            "progress": "31/31",
            "progress_value": 31,
            "progress_max": 31,
            "metrics": [("Создано", "4", "green"), ("НДП", "✓", "green"), ("Ценники", "27", "blue")],
            "action": "Открой НДП, ценники или папку привоза",
            "action_chip": ("завершено", "green"),
            "primary": "Открыть папку",
        },
    }

    def __init__(self, parent_page=None) -> None:
        super().__init__()
        self.parent_page = parent_page
        self.dev_state = "empty"
        self.source_expanded = False
        self._draft_buttons: List[DraftsTileButton] = []
        self._draft_badge_timer = QTimer(self)
        self._draft_badge_timer.setInterval(3000)
        self._draft_badge_timer.timeout.connect(self.refresh_draft_badges)
        self.build_ui()
        self._draft_badge_timer.start()
        QTimer.singleShot(0, self.refresh_draft_badges)

    def _card(self, name: str = "UxCard") -> QFrame:
        card = QFrame()
        card.setObjectName(name)
        return card

    def _label(self, text: str, name: str = "") -> QLabel:
        label = QLabel(text)
        if name:
            label.setObjectName(name)
        label.setWordWrap(True)
        return label

    def _button(self, text: str, primary: bool = False, compact: bool = False) -> QPushButton:
        btn = QPushButton(text)
        btn.setObjectName("UxButtonCompactPrimary" if primary else "UxButtonCompact")
        btn.setMinimumHeight(34 if compact else 38)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        return btn

    def _chip(self, text: str, tone: str = "blue") -> QLabel:
        chip = QLabel(text)
        chip.setObjectName(f"UxChip_{tone}")
        chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
        return chip

    def _metric(self, title: str, value: str, tone: str) -> QFrame:
        card = self._card(f"UxMetric_{tone}")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(11, 8, 11, 8)
        layout.setSpacing(0)
        layout.addWidget(self._label(title, "UxMetricTitle"))
        layout.addWidget(self._label(value, "UxMetricValue"))
        return card

    def _source_tile(
        self,
        title: str,
        subtitle: str,
        primary: bool = False,
        callback=None,
        drafts: bool = False,
    ) -> QPushButton:
        if drafts:
            tile = DraftsTileButton(title, subtitle)
            self._draft_buttons.append(tile)
        else:
            tile = UxTwoLineButton(title, subtitle, primary=primary, large=False)
        if callback is not None:
            tile.clicked.connect(callback)
        return tile

    def _manual_receipt_tile(self) -> QPushButton:
        page = getattr(self.parent_page, "free_receipt_page", None)
        has_current = bool(page is not None and page.has_unpromoted_manual_receipt())
        if not has_current:
            return self._source_tile(
                "Составить накладную вручную",
                "наименование · количество · закупка",
                False,
                self.open_manual_receipt,
            )
        tile = ManualReceiptTileButton(
            "Продолжить составлять накладную",
            f"Добавлено товаров: {len(page.rows)}",
        )
        tile.clicked.connect(self.open_manual_receipt)
        tile.new_button.clicked.connect(self.start_new_manual_receipt_with_cooldown)
        return tile

    def start_new_manual_receipt_with_cooldown(self) -> None:
        page = getattr(self.parent_page, "free_receipt_page", None)
        if page is None:
            return
        if not page.has_unpromoted_manual_receipt():
            page.begin_new_manual_receipt()
            self.parent_page.show_free_receipt()
            return

        dialog = QDialog(self)
        dialog.setWindowTitle("Создать новую ручную накладную")
        dialog.setMinimumWidth(520)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(22, 20, 22, 20)
        layout.setSpacing(14)
        title = QLabel("Текущая накладная не потеряется")
        title.setObjectName("WorkbenchSection")
        layout.addWidget(title)
        text = QLabel(
            "Существующая ручная накладная сначала сохранится в общие черновики SAI. "
            "После этого вместо неё откроется новая пустая накладная."
        )
        text.setWordWrap(True)
        layout.addWidget(text)
        actions = QHBoxLayout()
        cancel = QPushButton("Отмена"); cancel.setObjectName("SoftButton"); cancel.clicked.connect(dialog.reject)
        proceed = QPushButton("Продолжить (5)"); proceed.setObjectName("WorkbenchPrimaryButton"); proceed.setEnabled(False)
        proceed.clicked.connect(dialog.accept)
        actions.addStretch(1); actions.addWidget(cancel); actions.addWidget(proceed)
        layout.addLayout(actions)
        remaining = {"value": 5}
        timer = QTimer(dialog)
        timer.setInterval(1000)

        def tick() -> None:
            remaining["value"] -= 1
            if remaining["value"] <= 0:
                timer.stop()
                proceed.setText("Продолжить")
                proceed.setEnabled(True)
            else:
                proceed.setText(f"Продолжить ({remaining['value']})")

        timer.timeout.connect(tick)
        timer.start()
        if dialog.exec() != QDialog.Accepted:
            return
        if not page.save_manual_as_draft(navigate_to_hub=False):
            return
        page.begin_new_manual_receipt()
        self.render()
        self.parent_page.show_free_receipt()

    def active_draft_count(self) -> int:
        try:
            return len(sai_receipt_drafts.list_active())
        except Exception:
            return 0

    def refresh_draft_badges(self) -> None:
        count = self.active_draft_count()
        alive: List[DraftsTileButton] = []
        for button in self._draft_buttons:
            try:
                button.set_draft_count(count)
                alive.append(button)
            except RuntimeError:
                pass
        self._draft_buttons = alive

    def showEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().showEvent(event)
        self.refresh_draft_badges()

    def _route_barcodes(self, row: Dict[str, Any]) -> List[str]:
        """Compatibility wrapper around the Core v2 routing rule."""
        return list(numeric_barcodes(row))

    def _route_qty(self, row: Dict[str, Any]) -> float:
        """Compatibility wrapper around the Core v2 routing rule."""
        return receipt_quantity(row)

    def _missing_barcode_indices(self, rows: List[Dict[str, Any]]) -> List[int]:
        """Compatibility wrapper around the Core v2 routing rule."""
        return list(missing_barcode_indices(rows))

    def _choose_sai_path(self) -> Optional[Path]:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Выберите SAI-файл",
            str(Path.home() / "Desktop"),
            "SAI Package (*.sai);;Все SAI-файлы (*.sai *.xml *.xlsx *.xlsm);;Старый SAI XML (*.xml);;Excel (*.xlsx *.xlsm)",
        )
        return Path(path) if path else None

    def _route_new_receipt(self, path: Path) -> None:
        if self.parent_page is None or load_sai_rows is None:
            QMessageBox.critical(self, "Новый привоз", "Не подключилась логика чтения SAI-файлов.")
            return
        path = resolve_prepared_receipt_path(path)
        try:
            _sheet, rows = load_sai_rows(str(path))
        except Exception as exc:
            QMessageBox.critical(self, "Новый привоз", f"Не удалось прочитать SAI-файл:\n{exc}")
            return
        if not rows:
            QMessageBox.warning(self, "Новый привоз", "В SAI-файле не найдено товарных позиций.")
            return

        plan = build_receipt_route_plan(path, rows)
        if plan.requires_barcode_completion:
            sai_receipt_drafts.update_by_package(plan.path, stage=plan.stage)
            page = getattr(self.parent_page, "semi_receipt_page", None)
            if page is None:
                return
            page.set_sai_file(plan.path)
            self.parent_page.show_semi_receipt()
            self.parent_page.notify(
                "Нужны штрихкоды",
                f"{plan.path.name}: без ШК {plan.missing_count} из {plan.item_count} позиций. Открыт режим сбора ШК.",
                "info",
            )
            return

        if getattr(self.parent_page, "open_sai_file_direct", None) is None:
            return
        sai_receipt_drafts.update_by_package(plan.path, stage=plan.stage)
        self.parent_page.open_sai_file_direct(plan.path)
        self.parent_page.notify(
            "SAI-файл готов",
            f"Во всех {plan.item_count} позициях есть ШК. Открыт автоматический приход.",
            "success",
        )

    def start_new_receipt(self) -> None:
        """Start the normal SAI workflow: supplier document -> AI -> receipt."""
        self.open_ai_invoice()

    def choose_new_receipt_file(self) -> None:
        path = self._choose_sai_path()
        if path is not None:
            self._route_new_receipt(path)

    def open_prepared_sai(self) -> None:
        """Compatibility action: choose a SAI file and use the same auto-routing."""
        self.choose_new_receipt_file()

    def prepare_from_invoice(self) -> None:
        """Open ChatGPT invoice recognition."""
        if self.parent_page is not None:
            self.parent_page.show_converter()

    def open_ai_invoice(self) -> None:
        if self.parent_page is not None:
            self.parent_page.show_converter()

    def open_manual_receipt(self) -> None:
        if self.parent_page is not None:
            page = getattr(self.parent_page, "free_receipt_page", None)
            if page is not None:
                page.begin_new_manual_receipt()
            self.parent_page.show_free_receipt()

    def continue_draft(self) -> None:
        """Show every unfinished receipt and resume the selected workflow."""
        if self.parent_page is None:
            return
        dialog = ReceiptDraftsDialog(self.parent_page, self)
        accepted = dialog.exec() == QDialog.DialogCode.Accepted and bool(dialog.selected)
        self.refresh_draft_badges()
        if not accepted:
            return
        resume = build_draft_resume_plan(dialog.selected)
        if resume.kind is DraftResumeKind.MANUAL:
            self.parent_page.show_free_receipt()
            return
        if resume.kind is not DraftResumeKind.PACKAGE or resume.package_path is None:
            QMessageBox.warning(self, "Черновики", "Не удалось определить сценарий этого черновика.")
            return
        if not resume.package_path.exists():
            QMessageBox.warning(self, "Черновики", "Внутренний файл этого черновика не найден.")
            return
        self.parent_page.route_sai_file(resume.package_path)

    def open_receipt_history(self) -> None:
        """Open completed receipts from the receipt hub."""
        if self.parent_page is not None:
            self.parent_page.show_stats()

    def _flow_step(self, title: str, subtitle: str, tone: str = "wait") -> QFrame:
        step = self._card(f"UxFlowStep_{tone}")
        layout = QVBoxLayout(step)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(2)
        layout.addWidget(self._label(title, "UxFlowTitle"))
        layout.addWidget(self._label(subtitle, "UxFlowSub"))
        return step

    def _field(self, label: str, value: str, value_name: str = "UxFieldValue") -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        layout.addWidget(self._label(label, "UxFieldLabel"))
        layout.addWidget(self._label(value, value_name))
        return box

    def _status_item(self, text: str, tone: str) -> QLabel:
        pill = QLabel(text)
        pill.setObjectName(f"UxStatus_{tone}")
        pill.setAlignment(Qt.AlignmentFlag.AlignCenter)
        return pill

    def _phone_qr_label(self) -> QLabel:
        label = QLabel()
        label.setObjectName("UxPhoneQr")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pix = _make_qr_pixmap("http://192.168.1.14:8765", scale=4, border=3, dark_color="#0f172a", light_color="#e2e8f0")
        if pix:
            label.setPixmap(pix.scaled(78, 78, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.FastTransformation))
        else:
            label.setText("QR")
        return label

    def _state(self) -> Dict[str, Any]:
        return self.STATE_DATA.get(self.dev_state, self.STATE_DATA["scan"])

    def _clear_layout(self, layout: QLayout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            child_layout = item.layout()
            widget = item.widget()
            if child_layout is not None:
                self._clear_layout(child_layout)
            if widget is not None:
                widget.deleteLater()

    def set_dev_state(self, state: str) -> None:
        if state not in self.STATE_DATA:
            return
        self.dev_state = state
        self.render()

    def toggle_source(self) -> None:
        self.source_expanded = not self.source_expanded
        self.render()

    def _state_button(self, state: str) -> QPushButton:
        label = self.STATE_DATA[state]["tab"]
        btn = QPushButton(label)
        btn.setObjectName("UxStateButtonActive" if self.dev_state == state else "UxStateButton")
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        btn.clicked.connect(lambda checked=False, key=state: self.set_dev_state(key))
        return btn

    def build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setObjectName("UxScroll")
        root.addWidget(self.scroll, 1)

        self.page = QWidget()
        self.page.setObjectName("UxPage")
        self.scroll.setWidget(self.page)
        self.outer = QVBoxLayout(self.page)
        self.outer.setContentsMargins(18, 14, 18, 14)
        self.outer.setSpacing(9)
        self.render()

    def render(self) -> None:
        self._clear_layout(self.outer)
        self._draft_buttons = []
        if self.dev_state == "empty":
            # Release start screen: one clear decision. Automatic and barcode
            # completion are internal branches of the same "Новый привоз".
            self.outer.addWidget(self._build_empty_state(), 1)
            self.refresh_draft_badges()
            return
        self.outer.addWidget(self._build_source_card())
        self.outer.addWidget(self._build_header_card())
        if self.dev_state == "final":
            self.outer.addWidget(self._build_final_state(), 1)
        else:
            self.outer.addLayout(self._build_working_body(), 1)
        self.refresh_draft_badges()

    def _build_source_card(self) -> QFrame:
        card = self._card("UxSaiFileCard")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 11, 14, 11)
        layout.setSpacing(8)

        top = QHBoxLayout()
        top.setSpacing(10)
        title = self._label("Текущий привоз", "UxSourceTitleCompact")
        top.addWidget(title, 1)
        top.addWidget(self._label("Накладная → проверка → приход в SIGMA", "UxSourceSubCompact"), 2)
        toggle = self._button("скрыть схему" if self.source_expanded else "схема", compact=True)
        toggle.clicked.connect(self.toggle_source)
        top.addWidget(toggle, 0)
        layout.addLayout(top)

        if self.source_expanded:
            detail = QHBoxLayout()
            detail.setSpacing(12)
            flow = QHBoxLayout()
            flow.setSpacing(6)
            flow.addWidget(self._flow_step("1. Накладная", "бумага / Excel / PDF", "done"))
            arrow1 = self._label("→", "UxFlowArrow")
            arrow1.setAlignment(Qt.AlignmentFlag.AlignCenter)
            flow.addWidget(arrow1, 0)
            flow.addWidget(self._flow_step("2. Проверка", "ШК · названия · факт", "active"))
            arrow2 = self._label("→", "UxFlowArrow")
            arrow2.setAlignment(Qt.AlignmentFlag.AlignCenter)
            flow.addWidget(arrow2, 0)
            flow.addWidget(self._flow_step("3. Приход", "SIGMA · НДП · ценники", "wait"))
            detail.addLayout(flow, 1)
            actions = QHBoxLayout()
            actions.setSpacing(7)
            actions.addWidget(self._source_tile("Новый привоз", "Загрузите накладную", True, self.start_new_receipt))
            actions.addWidget(self._manual_receipt_tile())
            actions.addWidget(self._source_tile("Черновики", "продолжить незавершённый", False, self.continue_draft, drafts=True))
            actions.addWidget(self._source_tile("История приходов", "завершённые приходы и документы", False, self.open_receipt_history))
            detail.addLayout(actions, 0)
            layout.addLayout(detail)
        return card

    def _build_header_card(self) -> QFrame:
        s = self._state()
        header = self._card("UxHeaderCard")
        header_l = QVBoxLayout(header)
        header_l.setContentsMargins(14, 10, 14, 10)
        header_l.setSpacing(7)
        top = QHBoxLayout()
        top.setSpacing(9)
        status_text, status_tone = s["status"]
        top.addWidget(self._label(s["title"], "UxCompactTitle"), 0)
        top.addWidget(self._chip(status_text, status_tone), 0)
        top.addWidget(self._chip(s["progress"], "blue" if self.dev_state != "empty" else "gray"), 0)
        progress = QProgressBar()
        progress.setObjectName("UxProgressInline")
        progress.setRange(0, max(1, int(s["progress_max"])))
        progress.setValue(int(s["progress_value"]))
        progress.setTextVisible(False)
        top.addWidget(progress, 1)
        for title, value, tone in s["metrics"]:
            top.addWidget(self._metric(title, value, tone), 0)
        header_l.addLayout(top)
        return header

    def _build_empty_state(self) -> QFrame:
        card = QFrame()
        card.setObjectName("UxStartActions")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(12, 8, 12, 8)
        layout.setSpacing(14)

        self.new_receipt_btn = NewReceiptHeroButton(
            "НОВЫЙ ПРИВОЗ",
            "Загрузите накладную — SAI распознает её и сам выберет подходящий сценарий",
        )
        self.new_receipt_btn.clicked.connect(self.start_new_receipt)
        if self.parent_page is not None:
            self.parent_page.new_receipt_btn = self.new_receipt_btn
        layout.addWidget(self.new_receipt_btn)

        secondary = QHBoxLayout()
        secondary.setSpacing(10)
        secondary.addWidget(self._manual_receipt_tile(), 1)
        secondary.addWidget(self._source_tile("Черновики", "продолжить незавершённый привоз", False, self.continue_draft, drafts=True), 1)
        secondary.addWidget(self._source_tile("История приходов", "завершённые приходы и документы", False, self.open_receipt_history), 1)
        layout.addLayout(secondary)

        layout.addStretch(1)
        return card

    def _build_final_state(self) -> QFrame:
        card = self._card("UxFinalCard")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(12)
        layout.addWidget(self._label("Приход завершён", "UxStartTitle"))
        grid = QGridLayout()
        grid.setSpacing(10)
        for i, (title, value, tone) in enumerate((("Принято позиций", "30", "green"), ("Новых товаров", "4", "green"), ("Недовоз", "1", "gray"), ("Термоэтикеток", "27", "blue"), ("НДП", "готова", "green"), ("PDF-ценники", "готовы", "green"))):
            grid.addWidget(self._metric(title, value, tone), i // 3, i % 3)
        layout.addLayout(grid)
        actions = QHBoxLayout()
        actions.setSpacing(10)
        actions.addWidget(self._button("Открыть папку привоза", True))
        actions.addWidget(self._button("Открыть НДП"))
        actions.addWidget(self._button("Открыть ценники"))
        actions.addWidget(self._button("Новый привоз"))
        layout.addLayout(actions)
        layout.addStretch(1)
        return card

    def _product_values(self) -> Dict[str, str]:
        if self.dev_state == "categories":
            return {
                "name": "СВЕРЛО ПО ДЕРЕВУ ПЕРОВОЕ 16×152 ММ",
                "article": "659116",
                "doc": "5",
                "fact": "5",
                "buy": "120 ₽",
                "sale": "190 ₽",
                "input_label": "Категория",
                "input": "Начни писать категорию...",
                "labels": "5",
                "row": "новый товар",
            }
        if self.dev_state == "ready":
            return {
                "name": "Все обязательные данные собраны",
                "article": "—",
                "doc": "31",
                "fact": "30",
                "buy": "—",
                "sale": "—",
                "input_label": "Проверка",
                "input": "Можно запускать приход",
                "labels": "27",
                "row": "итог",
            }
        return {
            "name": "ВЕДРО ОЦИНКОВАННОЕ 12 Л",
            "article": "A-1209",
            "doc": "10",
            "fact": "7",
            "buy": "350 ₽",
            "sale": "420 ₽",
            "input_label": "ШК",
            "input": "Готов к скану...",
            "labels": "3",
            "row": "№19",
        }

    def _build_working_body(self) -> QHBoxLayout:
        s = self._state()
        product_data = self._product_values()
        body = QHBoxLayout()
        body.setSpacing(10)

        main_col = QVBoxLayout()
        main_col.setSpacing(9)
        action = self._card("UxNextActionCard")
        al = QHBoxLayout(action)
        al.setContentsMargins(12, 9, 12, 9)
        al.setSpacing(11)
        icon = QLabel("↘" if self.dev_state == "scan" else "●")
        icon.setObjectName("UxActionIcon")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        al.addWidget(icon, 0)
        al.addWidget(self._label(s["action"], "UxActionText"), 1)
        chip_text, chip_tone = s["action_chip"]
        al.addWidget(self._chip(chip_text, chip_tone), 0)
        main_col.addWidget(action)

        product = self._card("UxProductCard")
        pl = QVBoxLayout(product)
        pl.setContentsMargins(16, 12, 16, 12)
        pl.setSpacing(9)
        product_header = QHBoxLayout()
        product_header.addWidget(self._label("Текущий товар" if self.dev_state != "ready" else "Итог проверки", "UxCardTitle"), 1)
        product_header.addWidget(self._chip(product_data["row"], "gray"), 0)
        pl.addLayout(product_header)
        pl.addWidget(self._field("Наименование", product_data["name"], "UxProductName"))

        facts = QGridLayout()
        facts.setHorizontalSpacing(10)
        facts.setVerticalSpacing(7)
        facts.addWidget(self._field("Артикул", product_data["article"], "UxFieldValue"), 0, 0)
        facts.addWidget(self._field("Док.", product_data["doc"], "UxBlueValue"), 0, 1)
        facts.addWidget(self._field("Факт", product_data["fact"], "UxBlueValue"), 0, 2)
        facts.addWidget(self._field("Закуп", product_data["buy"], "UxFieldValue"), 0, 3)
        facts.addWidget(self._field("Продажа", product_data["sale"], "UxFieldValue"), 0, 4)
        facts.setColumnStretch(0, 2)
        for i in range(1, 5):
            facts.setColumnStretch(i, 1)
        pl.addLayout(facts)

        scan_row = QHBoxLayout()
        scan_row.setSpacing(10)
        scan_row.addWidget(self._field(product_data["input_label"], product_data["input"], "UxInputLookMuted"), 1)
        qty_wrap = QWidget()
        qty_layout = QVBoxLayout(qty_wrap)
        qty_layout.setContentsMargins(0, 0, 0, 0)
        qty_layout.setSpacing(3)
        qty_layout.addWidget(self._label("Ценников", "UxFieldLabel"))
        qty_box = self._card("UxQtyBox")
        qty_box.setFixedWidth(142)
        qty_box.setFixedHeight(42)
        qbl = QHBoxLayout(qty_box)
        qbl.setContentsMargins(0, 0, 0, 0)
        qbl.setSpacing(0)
        for text, name in (("−", "UxQtyPartBtn"), (product_data["labels"], "UxQtyPartValue"), ("+", "UxQtyPartBtn")):
            lab = QLabel(text)
            lab.setObjectName(name)
            lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
            qbl.addWidget(lab, 1)
        qty_layout.addWidget(qty_box)
        scan_row.addWidget(qty_wrap, 0)
        pl.addLayout(scan_row)
        main_col.addWidget(product)
        main_col.addWidget(self._build_table(), 1)
        body.addLayout(main_col, 1)
        body.addLayout(self._build_side_panel(s), 0)
        return body

    def _build_table(self) -> QFrame:
        table_card = self._card("UxTableCard")
        tl = QVBoxLayout(table_card)
        tl.setContentsMargins(14, 12, 14, 14)
        tl.setSpacing(8)
        table_top = QHBoxLayout()
        table_top.addWidget(self._label("Позиции", "UxCardTitle"), 1)
        table_top.addWidget(self._label("🔒 правки: удерживать 3 сек.", "UxLockHint"))
        table_top.addWidget(self._chip("только проблемы", "gray"))
        tl.addLayout(table_top)
        table = RoundedTableWidget(0, 11)
        table.setObjectName("UxTable")
        table.setHorizontalHeaderLabels(["№", "Наименование", "Артикул", "Док.", "Факт", "Ед.", "Закуп", "Продажа", "ШК", "Цен.", "Статус"])
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        if self.dev_state == "categories":
            rows = [
                ["1", "СВЕРЛО ПО ДЕРЕВУ ПЕРОВОЕ 16×152", "659116", "5", "5", "шт", "120", "190", "4690670009142", "5", ("Нет категории", "amber")],
                ["2", "ВЕДРО ОЦИНКОВАННОЕ 12 Л", "A-1209", "10", "7", "шт", "350", "420", "4601234567892", "3", ("Готово", "green")],
                ["3", "ШУРУПЫ ПО ДЕРЕВУ 4,2Х75", "S-4275", "200", "180", "шт", "0,80", "1,20", "2012345678901", "0", ("Недовоз", "gray")],
            ]
        elif self.dev_state == "ready":
            rows = [
                ["—", "Все строки готовы к приходу", "—", "31", "30", "", "", "", "", "27", ("Готово", "green")],
                ["—", "Новые товары будут созданы", "—", "4", "4", "", "", "", "", "", ("Готово", "green")],
                ["—", "Полный недовоз будет пропущен", "—", "1", "0", "", "", "", "", "0", ("Недовоз", "gray")],
            ]
        else:
            rows = [
                ["16", "МЕШКИ СТРОИТЕЛЬНЫЕ 55Х95", "M-5595", "25", "25", "шт", "12", "18", "4601234567800", "25", ("Готово", "green")],
                ["17", "ПЕРЧАТКИ Х/Б С ПВХ ТОЧКОЙ", "P-001", "100", "100", "пар", "15", "25", "4601234567801", "100", ("Готово", "green")],
                ["18", "КРЕПЁЖНЫЙ УГОЛОК 40Х40Х2", "K-40402", "50", "50", "шт", "9", "15", "4601234567802", "50", ("Готово", "green")],
                ["19", "ВЕДРО ОЦИНКОВАННОЕ 12 Л", "A-1209", "10", "7", "шт", "350", "420", "—", "3", ("Нет ШК", "peach")],
                ["20", "ШУРУПЫ ПО ДЕРЕВУ 4,2Х75", "S-4275", "200", "180", "шт", "0,80", "1,20", "2012345678901", "0", ("Недовоз", "gray")],
                ["21", "ЛЕНТА МАЛЯРНАЯ 48 ММ Х 50 М", "L-4850", "20", "20", "шт", "65", "95", "2109876543210", "20", ("Нестанд.", "amber")],
            ]
        table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, value in enumerate(row):
                if c == 10:
                    text, tone = value
                    table.setCellWidget(r, c, self._status_item(text, tone))
                    continue
                item = QTableWidgetItem(str(value))
                active = (self.dev_state == "scan" and r == 3) or (self.dev_state in ("categories", "ready") and r == 0)
                if active:
                    item.setBackground(QColor("#eff6ff"))
                    if c == 1:
                        item.setForeground(QColor("#1d4ed8"))
                elif c == 10:
                    pass
                elif "Недовоз" in str(row[-1][0]):
                    item.setBackground(QColor("#f8fafc"))
                elif "Нестанд" in str(row[-1][0]) or "категории" in str(row[-1][0]).lower():
                    item.setBackground(QColor("#fffbeb"))
                else:
                    item.setBackground(QColor("#ffffff"))
                if c != 1:
                    item.setForeground(QColor("#0f172a"))
                if c in (0, 3, 4, 5, 6, 7, 9):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                table.setItem(r, c, item)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        widths = [42, 260, 92, 66, 66, 52, 72, 78, 150, 62, 104]
        for col, width in enumerate(widths):
            table.setColumnWidth(col, width)
        table.horizontalHeader().setStretchLastSection(True)
        table.setMinimumHeight(250)
        tl.addWidget(table)
        return table_card

    def _build_side_panel(self, s: Dict[str, Any]) -> QVBoxLayout:
        side = QVBoxLayout()
        side.setSpacing(9)
        phone = self._card("UxSideCard")
        ph = QVBoxLayout(phone)
        ph.setContentsMargins(12, 10, 12, 10)
        ph.setSpacing(5)
        ph.addWidget(self._label("Телефон", "UxCardTitle"))
        ph.addWidget(self._phone_qr_label(), 0, Qt.AlignmentFlag.AlignCenter)
        ph.addWidget(self._label("192.168.1.14:8765", "UxTinyMono"), 0, Qt.AlignmentFlag.AlignCenter)
        side.addWidget(phone)
        quick = self._card("UxSideCard")
        ql = QVBoxLayout(quick)
        ql.setContentsMargins(12, 10, 12, 10)
        ql.setSpacing(7)
        ql.addWidget(self._label("Действия", "UxCardTitle"))
        ql.addWidget(self._button(str(s["primary"]), True, compact=True))
        for label in ("Сгенерировать", "Печать термо", "Сохранить"):
            ql.addWidget(self._button(label, compact=True))
        side.addWidget(quick)
        add_row = self._card("UxAddRowCard")
        arl = QVBoxLayout(add_row)
        arl.setContentsMargins(12, 10, 12, 10)
        arl.setSpacing(3)
        arl.addWidget(self._label("+ Новая позиция", "UxAddRowTitle"))
        arl.addWidget(self._label("наименование · кол-во · закупка · ед.", "UxMuted"))
        side.addWidget(add_row)
        next_box = self._card("UxSideCard")
        nl = QVBoxLayout(next_box)
        nl.setContentsMargins(12, 10, 12, 10)
        nl.setSpacing(5)
        nl.addWidget(self._label("Дальше", "UxCardTitle"))
        lines = {
            "scan": ("собрать оставшиеся ШК", "спросить 2 категории", "запустить проверку"),
            "categories": ("создать 4 товара", "обновить каталог", "запустить приход"),
            "ready": ("создать товары", "заполнить SIGMA", "напечатать НДП"),
        }.get(self.dev_state, ("открыть результаты", "начать новый привоз", ""))
        for line in lines:
            if line:
                nl.addWidget(self._label(line, "UxNextLine"))
        side.addWidget(next_box)
        flags = self._card("UxSideCard")
        fl = QGridLayout(flags)
        fl.setContentsMargins(12, 10, 12, 10)
        fl.setHorizontalSpacing(6)
        fl.setVerticalSpacing(6)
        fl.addWidget(self._chip("готово", "green"), 0, 0)
        fl.addWidget(self._chip("нужно", "peach"), 0, 1)
        fl.addWidget(self._chip("предупр.", "amber"), 1, 0)
        fl.addWidget(self._chip("исключено", "gray"), 1, 1)
        side.addWidget(flags)
        side.addStretch(1)
        return side


class MainPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        self.classic_process: subprocess.Popen | None = None
        self.doctor_process: QProcess | None = None
        self.doctor_spinner_timer: QTimer | None = None
        self.doctor_spinner_i: int = 0
        self.settings_page: SettingsPage | None = None
        self.settings_btn: QPushButton | None = None
        self.browser_check: QCheckBox | None = None
        self.history_table: QTableWidget | None = None
        self.history_search: QLineEdit | None = None
        self.history_summary_label: QLabel | None = None
        self.history_open_btn: QPushButton | None = None  # legacy compatibility; UI button removed in v1.22.7l
        self.history_delete_btn: QPushButton | None = None  # legacy compatibility; row-level cross is used instead
        self.status_label: QLabel | None = None
        self.content_stack: QStackedWidget | None = None
        self.workbench_page: WorkbenchPage | None = None
        self.home_btn: QPushButton | None = None
        self.store_btn: QPushButton | None = None
        self.price_tags_btn: QPushButton | None = None
        self.free_receipt_btn: QPushButton | None = None
        self.stock_btn: QPushButton | None = None
        self.staff_btn: QPushButton | None = None
        self.marking_btn: QPushButton | None = None
        self.thermal_text_btn: QPushButton | None = None
        self.ux_preview_btn: QPushButton | None = None
        self.compact_mode_btn: QPushButton | None = None
        self._rail: QFrame | None = None
        self._rail_buttons: List[RailIconButton] = []
        self._rail_compact: bool = False
        self.ux_preview_page: ReceiptUxPreviewPage | None = None
        self.price_tags_page: PriceTagsPage | None = None
        self.free_receipt_page: FreeReceiptPage | None = None
        self.stock_page: WarehousePage | None = None
        self.store_page: StoreDashboardPage | None = None
        self.staff_page: StaffPage | None = None
        self.marking_page: MarkingCheckPage | None = None
        self.thermal_text_page: ThermalTextPrintPage | None = None
        self.notification_center: NotificationCenter | None = None
        self.catalog_status_badge: CatalogStatusBadge | None = None
        self.offline_mode: bool = False
        self._background_catalog_running: bool = False
        self._background_catalog_signals = BackgroundCatalogSignals()
        self._background_catalog_signals.finished.connect(self._background_catalog_finished)
        self._organization_sync_running = False
        self._organization_sync_last_report = None
        self._organization_sync_signals = OrganizationSyncSignals()
        self._organization_sync_signals.finished.connect(self._organization_sync_finished)
        self._github_update_running = False
        self._github_update_info = None
        self._github_update_error = ""
        self._github_update_signals = GithubUpdateSignals()
        self._github_update_signals.checked.connect(self._github_update_checked)
        self._github_update_signals.downloaded.connect(self._github_update_downloaded)
        self.build_ui()
        self.notification_center = NotificationCenter(self)
        self.refresh()
        self._local_refresh_timer = QTimer(self)
        self._local_refresh_timer.setInterval(60000)
        self._local_refresh_timer.timeout.connect(self.auto_refresh_local)
        self._local_refresh_timer.start()
        self._history_refresh_timer = QTimer(self)
        self._history_refresh_timer.setInterval(5000)
        self._history_refresh_timer.timeout.connect(self.auto_refresh_history)
        self._history_refresh_timer.start()
        self._catalog_refresh_timer = QTimer(self)
        self._catalog_refresh_timer.setInterval(6 * 60 * 60 * 1000)
        self._catalog_refresh_timer.timeout.connect(self.maybe_background_catalog_refresh)
        self._catalog_refresh_timer.start()
        self._organization_sync_timer = QTimer(self)
        self._organization_sync_timer.setInterval(30000)
        self._organization_sync_timer.timeout.connect(self.sync_organization_now)
        self._organization_sync_timer.start()
        QTimer.singleShot(1800, self.sync_organization_now)
        QTimer.singleShot(3200, self.check_github_update)

    def build_ui(self) -> None:
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Left rail: navigation and service actions live here, so the main
        # work area can stay quiet and focused. The icons are drawn by SAI, not
        # by emoji fonts, so the navigation looks consistent on Windows.
        rail = QFrame()
        rail.setObjectName("Rail")
        rail.setFixedWidth(220)
        self._rail = rail
        rail_layout = QVBoxLayout(rail)
        # The outer rail geometry is identical in both modes. Only rail width
        # and label visibility may change. This is the single invariant that
        # prevents every navigation element from jumping during collapse.
        rail_layout.setContentsMargins(12, 14, 12, 12)
        rail_layout.setSpacing(0)
        self._rail_layout = rail_layout
        self._rail_buttons = []

        top_block = QFrame(rail)
        top_block.setObjectName("RailTopBlock")
        top_layout = QVBoxLayout(top_block)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.setSpacing(8)
        self._rail_top_layout = top_layout
        rail_layout.addWidget(top_block, 0)

        def add_rail_button(attr: str, icon: str, label: str, handler, primary: bool = False) -> RailIconButton:
            btn = RailIconButton(icon, label, primary=primary)
            btn.setCheckable(True)
            btn.clicked.connect(handler)
            setattr(self, attr, btn)
            self._rail_buttons.append(btn)
            top_layout.addWidget(btn)
            return btn

        # The approved UX preview is now the production receipt entry point.
        # Legacy workbench pages stay in the stack and are opened from this hub.
        add_rail_button("ux_preview_btn", "ux", "Привоз", self.show_receipt_hub, primary=True)
        add_rail_button("store_btn", "store", "Магазин", self.show_store)
        add_rail_button("price_tags_btn", "prices", "Ценники", self.show_price_tags)
        add_rail_button("thermal_text_btn", "thermal_text", "Термо печать", self.show_thermal_text)
        add_rail_button("stock_btn", "stock", "Склад", self.show_stock)
        add_rail_button("marking_btn", "marking", "Маркировка", self.show_marking)
        add_rail_button("staff_btn", "staff", "Сотрудники", self.show_staff)
        add_rail_button("settings_btn", "settings", "Настройки", self.show_settings)

        rail_layout.addStretch(1)

        bottom_block = QFrame(rail)
        bottom_block.setObjectName("RailBottomBlock")
        bottom_layout = QVBoxLayout(bottom_block)
        bottom_layout.setContentsMargins(0, 0, 0, 0)
        bottom_layout.setSpacing(0)
        self._rail_bottom_layout = bottom_layout
        rail_layout.addWidget(bottom_block, 0)

        self.catalog_status_badge = CatalogStatusBadge(bottom_block)
        bottom_layout.addWidget(self.catalog_status_badge)
        bottom_layout.addSpacing(12)

        self.compact_mode_btn = RailIconButton("compact", "Компактный режим", primary=False)
        self.compact_mode_btn.setCheckable(True)
        self.compact_mode_btn.setChecked(False)
        self.compact_mode_btn.setToolTip("Компактный режим меню: скрыть подписи")
        self.compact_mode_btn.toggled.connect(self.set_nav_compact)
        self._rail_buttons.append(self.compact_mode_btn)
        bottom_layout.addWidget(self.compact_mode_btn)
        bottom_layout.addSpacing(6)

        version = QLabel(APP_VERSION)
        version.setObjectName("RailVersion")
        version.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        version.setFixedHeight(18)
        version.setContentsMargins(0, 0, 0, 0)
        self._rail_version_label = version
        version.setVisible(False)
        bottom_layout.addWidget(version)

        outer.addWidget(rail)

        main_area = QFrame()
        main_area.setObjectName("MainArea")
        main_layout = QVBoxLayout(main_area)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("ContentStack")
        main_layout.addWidget(self.content_stack, 1)
        outer.addWidget(main_area, 1)

        self.workbench_page = WorkbenchPage(self)
        self.workbench_page.set_logs_visible(bool(load_private_config().get("hub_show_logs", False)))
        self.content_stack.addWidget(self.workbench_page)

        self.semi_receipt_page = SemiAutoReceiptPage(self)
        self.content_stack.addWidget(self.semi_receipt_page)

        # History is a working archive of successfully completed SIGMA receipts.
        stats = QWidget()
        stats.setObjectName("StatsPage")
        content = QVBoxLayout(stats)
        content.setContentsMargins(28, 30, 28, 30)
        content.setSpacing(18)

        content.addWidget(make_standard_page_header(
            "История",
            "Успешно введённые приходы, их состав, суммы и сохранённые документы.",
        ))

        self.history_search = QLineEdit()
        self.history_search.setObjectName("WorkbenchInput")
        self.history_search.setPlaceholderText("Найти товар по названию, ШК или поставщику")
        self.history_search.setClearButtonEnabled(True)
        self._history_search_timer = QTimer(self)
        self._history_search_timer.setSingleShot(True)
        self._history_search_timer.setInterval(140)
        self._history_search_timer.timeout.connect(self.refresh_history_table)
        self.history_search.textChanged.connect(lambda _text: self._history_search_timer.start())
        content.addWidget(self.history_search)

        self.history_summary_label = QLabel("Успешных приходов пока нет")
        self.history_summary_label.setObjectName("InlineStatus")
        content.addWidget(self.history_summary_label)

        self.history_table = self.make_table([
            "Дата накладной", "Поставщик SIGMA", "Найденный товар", "Позиций", "Товаров всего",
            "Сумма закупки", "Сумма продажи", "Введён в SIGMA", ""
        ])
        self.history_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.history_table.setToolTip("Двойной щелчок по строке — открыть приход")
        self.history_table.cellDoubleClicked.connect(lambda row, column: self.open_selected_receipt() if column != 8 else None)
        # Supplier names are business data, not decorative labels: never replace
        # them with an ellipsis. Long names wrap inside the supplier column.
        self.history_table.setWordWrap(True)
        self.history_table.setTextElideMode(Qt.TextElideMode.ElideNone)
        self.history_table.verticalHeader().setMinimumSectionSize(46)
        self.history_table.verticalHeader().setDefaultSectionSize(46)
        header = self.history_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        for column in (3, 4, 5, 6, 7):
            header.setSectionResizeMode(column, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(8, QHeaderView.Fixed)
        self.history_table.setColumnWidth(8, 44)
        content.addWidget(self.history_table, 1)
        self.status_label = QLabel("Готов к работе")
        self.status_label.setVisible(False)
        self.content_stack.addWidget(stats)

        self.price_tags_page = PriceTagsPage(self)
        self.content_stack.addWidget(self.price_tags_page)

        self.free_receipt_page = FreeReceiptPage(self)
        self.content_stack.addWidget(self.free_receipt_page)

        self.settings_page = SettingsPage(self)
        self.content_stack.addWidget(self.settings_page)

        self.ux_preview_page = ReceiptUxPreviewPage(self)
        self.content_stack.addWidget(self.ux_preview_page)

        self.converter_page = ConverterPage(self)
        self.content_stack.addWidget(self.converter_page)

        self.stock_page = WarehousePage(self)
        self.content_stack.addWidget(self.stock_page)

        self.store_page = StoreDashboardPage(self)
        self.content_stack.addWidget(self.store_page)

        self.staff_page = StaffPage(self)
        self.content_stack.addWidget(self.staff_page)

        self.marking_page = MarkingCheckPage(self)
        self.content_stack.addWidget(self.marking_page)

        self.thermal_text_page = ThermalTextPrintPage(
            self,
            load_config=load_private_config,
            save_config=save_private_config_patch,
        )
        self.content_stack.addWidget(self.thermal_text_page)

        # The store dashboard is the stable entry point. Receipt mechanics stay
        # untouched and open from the dedicated navigation action.
        self.set_nav_compact(False)
        self.set_nav_active("store")
        self.content_stack.setCurrentWidget(self.store_page)

        # The application-level theme controller owns the stylesheet so the
        # interface can switch between day and night modes without rebuilding pages.

    def set_nav_compact(self, compact: bool) -> None:
        """Switch rail width without changing any internal geometry."""
        self._rail_compact = bool(compact)
        rail = getattr(self, "_rail", None)
        if rail is not None:
            # Paint the whole state change in one frame. Otherwise Windows can
            # briefly show intermediate positions while labels are disappearing.
            rail.setUpdatesEnabled(False)
        try:
            if rail is not None:
                rail.setFixedWidth(74 if self._rail_compact else 220)
            for btn in getattr(self, "_rail_buttons", []):
                try:
                    btn.set_compact(self._rail_compact)
                except Exception:
                    pass
            if getattr(self, "compact_mode_btn", None):
                self.compact_mode_btn.setToolTip("Обычный режим меню: показать подписи" if self._rail_compact else "Компактный режим меню: скрыть подписи")
            badge = getattr(self, "catalog_status_badge", None)
            if badge is not None:
                badge.set_compact(self._rail_compact)
        finally:
            if rail is not None:
                rail.setUpdatesEnabled(True)
                rail.update()

    def show_home(self) -> None:
        self.show_stats()

    def set_nav_active(self, section: str) -> None:
        buttons = {
            "home": getattr(self, "home_btn", None),
            "store": getattr(self, "store_btn", None),
            "ux": getattr(self, "ux_preview_btn", None),
            "prices": getattr(self, "price_tags_btn", None),
            "thermal_text": getattr(self, "thermal_text_btn", None),
            "stock": getattr(self, "stock_btn", None),
            "staff": getattr(self, "staff_btn", None),
            "marking": getattr(self, "marking_btn", None),
            "settings": getattr(self, "settings_btn", None),
        }
        for name, btn in buttons.items():
            if btn is None:
                continue
            btn.blockSignals(True)
            btn.setChecked(name == section)
            btn.blockSignals(False)

    def show_workbench(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("ux")
            self.content_stack.setCurrentIndex(0)
            page = getattr(self, "workbench_page", None)
            if page is not None and not page.supplier_list:
                cached = page.load_supplier_cache()
                if cached:
                    page.fill_suppliers(cached)

    def show_semi_receipt(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("ux")
            self.content_stack.setCurrentIndex(1)

    def show_stats(self) -> None:
        if hasattr(self, "content_stack"):
            self.refresh()
            # History belongs to receiving; keep the parent section selected.
            self.set_nav_active("ux")
            self.content_stack.setCurrentIndex(2)

    def show_store(self) -> None:
        if hasattr(self, "content_stack") and self.store_page is not None:
            self.set_nav_active("store")
            self.store_page.refresh()
            self.content_stack.setCurrentWidget(self.store_page)


    def show_receipt_hub(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("ux")
            self.content_stack.setCurrentIndex(6)
            if getattr(self, "ux_preview_page", None) is not None:
                self.ux_preview_page.render()

    def show_ux_preview(self) -> None:
        # Compatibility alias for older callbacks/configs.
        self.show_receipt_hub()

    def show_converter(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("ux")
            if getattr(self, "converter_page", None) is not None:
                self.converter_page.refresh_supplier_choices(preserve_current=True)
            self.content_stack.setCurrentIndex(7)
            if getattr(self, "converter_page", None) is not None:
                self.converter_page.maybe_start_receipt_tutorial()

    def show_price_tags(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("prices")
            self.content_stack.setCurrentIndex(3)

    def show_thermal_text(self) -> None:
        if hasattr(self, "content_stack") and self.thermal_text_page is not None:
            self.set_nav_active("thermal_text")
            self.thermal_text_page.refresh_config()
            self.thermal_text_page.update_preview()
            self.content_stack.setCurrentWidget(self.thermal_text_page)

    def show_free_receipt(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("ux")
            if getattr(self, "free_receipt_page", None) is not None and not getattr(self.free_receipt_page, "_references_loaded", False):
                QTimer.singleShot(80, self.free_receipt_page.refresh_reference_data)
            self.content_stack.setCurrentIndex(4)

    def show_settings(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("settings")
            self.content_stack.setCurrentIndex(5)
            if self.settings_page is not None:
                self.settings_page.refresh_organization_status()

    def show_stock(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("stock")
            if self.stock_page is not None:
                self.stock_page.refresh()
            self.content_stack.setCurrentWidget(self.stock_page)

    def show_staff(self) -> None:
        if hasattr(self, "content_stack"):
            self.set_nav_active("staff")
            if self.staff_page is not None:
                self.staff_page.refresh()
            self.content_stack.setCurrentWidget(self.staff_page)

    def show_marking(self) -> None:
        if hasattr(self, "content_stack") and self.marking_page is not None:
            self.set_nav_active("marking")
            self.content_stack.setCurrentWidget(self.marking_page)
            self.marking_page.arm_scanner()

    def on_draft_deleted(self, draft: Dict[str, Any]) -> None:
        """Drop every live reference to a draft that the user explicitly deleted."""
        draft_id = safe_str(draft.get("id"))
        if draft_id == "manual_current" and self.free_receipt_page is not None:
            self.free_receipt_page.discard_deleted_manual_draft()
        converter = getattr(self, "converter_page", None)
        if converter is not None and safe_str(getattr(converter, "draft_id", "")) == draft_id:
            # Keep the deleted id in memory: its tombstone prevents a delayed
            # name-edit autosave from silently recreating the same draft.
            converter.saved_sai_path = None

    def print_draft_ndp(self, draft: Dict[str, Any]) -> None:
        """Create and print an NDP from any selected draft without receipt/barcode gates."""
        if create_ndp_file is None:
            QMessageBox.critical(self, "Печать НДП", "Не подключилась логика создания НДП.")
            return
        draft_id = safe_str(draft.get("id"))
        supplier = safe_str(draft.get("supplier")) or "Черновик"
        invoice_date = safe_str(draft.get("invoice_date")) or dt.date.today().isoformat()
        package_raw = safe_str(draft.get("package_path"))
        package = Path(package_raw) if package_raw else None
        rows_override = None
        output_dir = sai_receipt_drafts.draft_dir(draft_id) if draft_id else USER_DATA_DIR
        catalog_service = shared_free_catalog_service()

        if not (package and package.exists()):
            payload_raw = safe_str(draft.get("manual_payload_path"))
            payload_path = Path(payload_raw) if payload_raw else None
            try:
                payload = json.loads(payload_path.read_text(encoding="utf-8")) if payload_path and payload_path.exists() else {}
            except Exception as exc:
                QMessageBox.warning(self, "Печать НДП", f"Не удалось прочитать ручной черновик:\n{exc}")
                return
            rows_override = list(payload.get("rows") or []) if isinstance(payload, dict) else []
            if not rows_override:
                QMessageBox.information(self, "Печать НДП", "В выбранном черновике пока нет добавленных товаров.")
                return

        try:
            out_path, count = create_ndp_file(
                str(package or ""),
                supplier,
                invoice_date,
                log_path=None,
                out_dir=output_dir,
                rows_override=rows_override,
                price_source="buy_and_sale",
                sale_price_resolver=catalog_service.sale_price_for_receipt_row,
            )
            ndp_path = Path(out_path)
            if int(count or 0) <= 0:
                QMessageBox.information(self, "Печать НДП", "В выбранном черновике нет товаров с положительным количеством.")
                return
            if print_file_silent(ndp_path):
                self.notify(
                    "НДП отправлена на печать",
                    f"{supplier}: {int(count)} поз. · приход и ШК не требовались",
                    "success",
                )
            else:
                QMessageBox.warning(
                    self,
                    "Печать НДП",
                    "НДП создана, но Windows не принял задание на принтер «Обычная печать».\n\n"
                    f"Файл сохранён здесь:\n{ndp_path}",
                )
        except Exception as exc:
            QMessageBox.critical(self, "Печать НДП", f"Не удалось создать НДП:\n{exc}")

    def route_sai_file(self, path: Path) -> None:
        """Single guarded entry point for every prepared SAI file.

        A file with any positive-quantity row without a barcode can only open
        the semi-automatic completion page. This closes every direct shortcut
        into automatic receiving.
        """
        hub = getattr(self, "ux_preview_page", None)
        if hub is None:
            QMessageBox.critical(self, "Новый привоз", "Не найден маршрутизатор сценария прихода.")
            return
        hub._route_new_receipt(Path(path))

    def open_sai_file_direct(self, path: Path) -> None:
        """Open the automatic workbench after route_sai_file has approved it."""
        if getattr(self, "workbench_page", None) is not None:
            self.workbench_page.set_sai_file(Path(path))
        self.show_workbench()

    def open_sai_file_in_workbench(self, path: Path) -> None:
        # Compatibility name retained for older callbacks, but it is now safe.
        self.route_sai_file(Path(path))

    def make_table(self, headers: List[str]) -> QTableWidget:
        table = RoundedTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setAlternatingRowColors(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.horizontalHeader().setHighlightSections(False)
        table.setMinimumHeight(300)
        table.setShowGrid(False)
        return table

    def browser_visibility_changed(self) -> None:
        cb = None
        if getattr(self, "settings_page", None) is not None:
            cb = getattr(self.settings_page, "browser_check", None)
        visible = bool(cb and cb.isChecked())
        save_private_config_patch({"browser_visible": visible})
        self.notify("Настройки", "Браузер SIGMA будет показан." if visible else "Браузер SIGMA будет скрыт.", "info")

    def logs_visibility_changed(self) -> None:
        cb = None
        if getattr(self, "settings_page", None) is not None:
            cb = getattr(self.settings_page, "logs_check", None)
        visible = bool(cb and cb.isChecked())
        save_private_config_patch({"hub_show_logs": visible})
        if getattr(self, "workbench_page", None) is not None:
            self.workbench_page.set_logs_visible(visible)
        self.notify("Логи", "Логи рабочего сценария показаны." if visible else "Логи рабочего сценария скрыты.", "info")

    def launch_classic(self) -> None:
        script = APP_DIR / "sai_app.py"
        try:
            self.classic_process = subprocess.Popen([sys.executable, str(script)], cwd=str(APP_DIR))
        except Exception as exc:
            QMessageBox.critical(self, "SAI", f"Не удалось запустить рабочий SAI:\n{exc}")

    def launch_doctor(self) -> None:
        """Run SAI Doctor in the background and copy fresh reports to Desktop."""
        if self.doctor_process is not None and self.doctor_process.state() != QProcess.NotRunning:
            self.notify("Диагностика", "SAI Doctor уже выполняется.", "info")
            return
        script = APP_DIR / "sai_doctor.py"
        if not script.exists():
            QMessageBox.critical(self, "SAI Doctor", f"Не найден файл диагностики:\n{script}")
            return
        self.doctor_process = QProcess(self)
        self.doctor_process.setWorkingDirectory(str(APP_DIR))
        self.doctor_process.setProgram(sys.executable)
        self.doctor_process.setArguments([str(script)])
        self.doctor_process.finished.connect(self.doctor_finished)
        self.doctor_process.errorOccurred.connect(self.doctor_error)
        self.doctor_spinner_i = 0
        self.doctor_spinner_timer = QTimer(self)
        self.doctor_spinner_timer.timeout.connect(self.update_doctor_spinner)
        self.doctor_spinner_timer.start(120)
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.set_doctor_running(True, "Диагностика ⠋")
        self.notify("Диагностика", "SAI Doctor запущен в фоне.", "info")
        self.doctor_process.start()

    def update_doctor_spinner(self) -> None:
        frames = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        self.doctor_spinner_i = (self.doctor_spinner_i + 1) % len(frames)
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.set_doctor_running(True, f"Диагностика {frames[self.doctor_spinner_i]}")

    def doctor_error(self, error) -> None:
        if self.doctor_spinner_timer:
            self.doctor_spinner_timer.stop()
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.set_doctor_running(False)
        self.notify("Диагностика", f"Не удалось запустить SAI Doctor: {error}", "error")

    def doctor_finished(self, exit_code: int, exit_status) -> None:
        if self.doctor_spinner_timer:
            self.doctor_spinner_timer.stop()
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.set_doctor_running(False)
        copied = self.copy_latest_doctor_reports()
        if exit_code == 0:
            msg = "SAI Doctor завершён."
            if copied:
                msg += f" Отчёты на рабочем столе: {copied}."
            self.notify("Диагностика готова", msg, "success")
        else:
            msg = f"SAI Doctor завершился с кодом {exit_code}."
            if copied:
                msg += f" Отчёты скопированы: {copied}."
            self.notify("Диагностика", msg, "error")

    def copy_latest_doctor_reports(self) -> int:
        try:
            logs = sorted(LOGS_DIR.glob("sai_doctor_*.*"), key=lambda p: p.stat().st_mtime, reverse=True)
            if not logs:
                return 0
            newest_stem = logs[0].stem
            selected = [p for p in logs if p.stem == newest_stem][:3]
            if len(selected) < 3:
                newest_stamp = newest_stem.replace("sai_doctor_", "")
                selected = [p for p in logs if p.stem.endswith(newest_stamp)][:3]
            dest_dir = desktop_dir() / "SAI Doctor Reports"
            dest_dir.mkdir(parents=True, exist_ok=True)
            count = 0
            for p in selected:
                shutil.copy2(p, dest_dir / p.name)
                count += 1
            return count
        except Exception:
            return 0

    def notify(self, title: str, message: str, tone: str = "info") -> None:
        """Show a short non-blocking message through the single SAI notification center."""
        cfg = load_private_config()
        if not bool(cfg.get("hub_notifications_enabled", True)):
            return
        center = getattr(self, "notification_center", None)
        if center is not None:
            center.notify(title, message, tone)

    def update_catalog_status(self, refreshing: bool = False) -> None:
        """Keep catalog state visible without turning routine readiness into a toast."""
        badge = getattr(self, "catalog_status_badge", None)
        if badge is None:
            return
        if getattr(self, "offline_mode", False):
            badge.set_status("ЛОКАЛЬНЫЙ КАТАЛОГ", "SIGMA НЕДОСТУПНА", "warning")
            return
        try:
            cfg = load_private_config()
            snapshot = sai_catalog_ready.catalog_snapshot(cfg)
        except Exception:
            snapshot = {}
        if refreshing or getattr(self, "_background_catalog_running", False):
            if snapshot.get("catalog_present"):
                badge.set_status("КАТАЛОГ ОБНОВЛЯЕТСЯ", "МОЖНО ПРОДОЛЖАТЬ РАБОТУ", "info")
            else:
                badge.set_status("КАТАЛОГ ЗАГРУЖАЕТСЯ", "ПЕРВАЯ СИНХРОНИЗАЦИЯ", "info")
            return
        if snapshot.get("catalog_present"):
            count = int(snapshot.get("product_count") or 0)
            age = sai_catalog_ready.human_age(snapshot.get("age_seconds"))
            badge.set_status("КАТАЛОГ ГОТОВ", f"{count:,} ТОВАРОВ · {age}".replace(",", " "), "success")
        else:
            badge.set_status("КАТАЛОГ НЕ ГОТОВ", "НУЖНА ПЕРВАЯ ЗАГРУЗКА", "warning")

    def set_offline_mode(self, offline: bool, message: str = "") -> None:
        self.offline_mode = bool(offline)
        if getattr(self, "new_receipt_btn", None) is not None:
            self.new_receipt_btn.setEnabled(not offline)
            self.new_receipt_btn.setToolTip("Недоступно в offline-режиме" if offline else "Загрузить накладную и начать новый привоз")
        if getattr(self, "status_label", None) is not None:
            self.status_label.setText("Offline: доступна только ручная накладная" if offline else "SAI готов")
        if offline:
            self.show_free_receipt()
            self.update_catalog_status()
            self.notify("SIGMA НЕДОСТУПНА", "SAI открыт с локальными данными. Доступна ручная накладная.", "error")
        else:
            workbench = getattr(self, "workbench_page", None)
            if workbench is not None and not workbench.supplier_list:
                cached = workbench.load_supplier_cache()
                if cached:
                    workbench.fill_suppliers(cached)
            # Normal readiness is a persistent rail status, not a distracting popup.
            self.update_catalog_status()

    def start_background_services(self, offline: bool = False) -> None:
        self.offline_mode = bool(offline)
        if not self.offline_mode:
            # The main window opens against SQLite immediately.  If the Windows
            # startup worker did not refresh the catalog, this quiet fallback will.
            QTimer.singleShot(900, self.maybe_background_catalog_refresh)

    def sync_organization_now(self, notify: bool = False) -> None:
        """Exchange receipt drafts and completed receipts through the shared folder."""
        if self._organization_sync_running:
            if notify:
                self.notify("Общая папка", "Синхронизация уже выполняется.", "info")
            return
        settings = sai_organization_sync.SyncSettings.from_config(load_private_config())
        if not settings.valid:
            if notify:
                self.notify("Общая папка", "Сначала подключи общую папку в Настройках.", "warning")
            return
        self._organization_sync_running = True

        def worker() -> None:
            report = sai_organization_sync.sync_once(settings, APP_VERSION)
            self._organization_sync_signals.finished.emit(report, bool(notify))

        threading.Thread(target=worker, daemon=True, name="sai-organization-sync").start()

    def github_update_channel(self) -> str:
        value = safe_str(load_private_config().get("github_update_channel")).casefold()
        return "development" if value == "development" else "production"

    def check_github_update(self, notify: bool = False) -> None:
        """Check the selected public release channel without delaying SAI."""
        if self._github_update_running:
            if notify:
                self.notify("Обновление SAI", "Проверка уже выполняется.", "info")
            return
        self._github_update_running = True
        self._github_update_error = ""
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.refresh_github_update_status()

        def worker() -> None:
            try:
                info = sai_github_updates.check_for_update(
                    APP_VERSION,
                    channel=self.github_update_channel(),
                )
                self._github_update_signals.checked.emit(info, "", bool(notify))
            except Exception as exc:
                self._github_update_signals.checked.emit(None, str(exc), bool(notify))

        threading.Thread(target=worker, daemon=True, name="sai-github-update-check").start()

    def _github_update_checked(self, info: Any, error: str, notify_requested: bool) -> None:
        self._github_update_running = False
        self._github_update_info = info
        self._github_update_error = safe_str(error)
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.refresh_github_update_status()
        if info is not None:
            label = "тестовая" if safe_str(getattr(info, "channel", "")) == "development" else "стабильная"
            self.notify("Доступно обновление SAI", f"Готова {label} версия v{info.version}.", "info")
        elif error and notify_requested:
            self.notify("Обновление SAI", "Не удалось проверить GitHub: " + safe_str(error), "warning")
        elif notify_requested:
            self.notify("Обновление SAI", f"Установлена актуальная версия {APP_VERSION}.", "success")

    def install_github_update(self) -> None:
        info = self._github_update_info
        if info is None:
            self.check_github_update(notify=True)
            return
        if self._github_update_running:
            return
        self._github_update_running = True
        self._github_update_error = ""
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.refresh_github_update_status()

        def worker() -> None:
            try:
                package = sai_github_updates.download_update(info)
                self._github_update_signals.downloaded.emit(package, "")
            except Exception as exc:
                self._github_update_signals.downloaded.emit(None, str(exc))

        threading.Thread(target=worker, daemon=True, name="sai-github-update-download").start()

    def _github_update_downloaded(self, package: Any, error: str) -> None:
        self._github_update_running = False
        self._github_update_error = safe_str(error)
        if getattr(self, "settings_page", None) is not None:
            self.settings_page.refresh_github_update_status()
        if error or package is None:
            QMessageBox.warning(self, "Обновление SAI", "Не удалось безопасно загрузить обновление:\n" + safe_str(error))
            return
        package = Path(package)
        try:
            if package.suffix.casefold() in {".cmd", ".bat", ".exe", ".msi"}:
                os.startfile(str(package))  # type: ignore[attr-defined]
                self.notify("Обновление SAI", "Проверенный установщик запущен. Следуй его подсказкам.", "success")
            else:
                open_path(package.parent)
                self.notify("Обновление SAI", f"Проверенный пакет {package.name} загружен.", "success")
        except Exception as exc:
            QMessageBox.warning(self, "Обновление SAI", f"Пакет проверен, но не удалось его открыть:\n{exc}")

    def _organization_sync_finished(self, report: Any, notify_requested: bool) -> None:
        self._organization_sync_running = False
        self._organization_sync_last_report = report
        settings_page = getattr(self, "settings_page", None)
        if settings_page is not None:
            settings_page.refresh_organization_status()
        if getattr(report, "ok", False):
            if int(getattr(report, "imported_receipts", 0) or 0) > 0:
                self.refresh_history_table()
            if getattr(self, "ux_preview_page", None) is not None:
                self.ux_preview_page.refresh_draft_badges()
            if int(getattr(report, "imported_staff_records", 0) or 0) > 0 and getattr(self, "staff_page", None) is not None:
                self.staff_page.refresh()
            available = safe_str(getattr(report, "available_version", ""))
            if available:
                self.notify("Доступно обновление SAI", f"В общей папке находится версия {available}.", "info")
            elif notify_requested:
                self.notify("Общая папка", safe_str(getattr(report, "message", "Синхронизация завершена.")), "success")
        elif notify_requested:
            self.notify("Общая папка", safe_str(getattr(report, "message", "Не удалось синхронизировать данные.")), "warning")

    def auto_refresh_local(self) -> None:
        # Local SQLite refresh only. No SIGMA API, no browser, no slowdown.
        try:
            if not self.isVisible():
                return
            if getattr(self, "workbench_page", None) is not None and getattr(self.workbench_page, "running", False):
                return
            self.refresh()
        except Exception:
            pass

    def auto_refresh_history(self) -> None:
        """Keep the visible receipt history current without a manual refresh button."""
        try:
            if not self.isVisible() or self.content_stack is None:
                return
            if self.content_stack.currentIndex() != 2:
                return
            if getattr(self, "workbench_page", None) is not None and getattr(self.workbench_page, "running", False):
                return
            self.refresh_history_table()
        except Exception:
            pass

    def maybe_background_catalog_refresh(self, force: bool = False, reason: str = "background") -> None:
        if getattr(self, "offline_mode", False) or self._background_catalog_running:
            return
        cfg = load_private_config()
        company = safe_str(cfg.get("sigma_company_key"))
        token = safe_str(cfg.get("sigma_api_token"))
        sp = safe_str(cfg.get("sigma_sell_point_id"))
        if not company or not token or not sp:
            return
        if not force:
            try:
                age = sai_db.catalog_age_seconds(company, sp)
                interval_minutes = max(30, int(cfg.get("catalog_background_refresh_interval_minutes", 360) or 360))
                if age is not None and age < interval_minutes * 60:
                    return
            except Exception:
                pass
        self._background_catalog_running = True
        self.update_catalog_status(refreshing=True)
        if force:
            try:
                self.notify("Каталог", "Обновляю каталог SIGMA в фоне…", "info")
            except Exception:
                pass

        def worker() -> None:
            ok = False
            msg = ""
            try:
                result = sai_catalog_ready.refresh_catalog(
                    reason="manual" if force else reason,
                    force=force,
                    min_age_minutes=0 if force else int(cfg.get("catalog_background_refresh_interval_minutes", 360) or 360),
                    cfg=cfg,
                )
                ok = bool(result.get("ok"))
                msg = safe_str(result.get("message")) or ("Каталог готов." if ok else "Каталог не обновлён.")
            except Exception as exc:
                msg = "Фоновое обновление каталога не удалось: " + str(exc)[:220]
            self._background_catalog_signals.finished.emit(ok, msg)

        threading.Thread(target=worker, daemon=True).start()

    def force_catalog_refresh_now(self) -> None:
        if getattr(self, "offline_mode", False):
            self.notify("Каталог", "В offline-режиме каталог SIGMA обновить нельзя.", "warning")
            return
        if self._background_catalog_running:
            self.notify("Каталог", "Обновление каталога уже идёт.", "info")
            return
        self.maybe_background_catalog_refresh(force=True, reason="manual")

    def force_catalog_full_rebuild_now(self) -> None:
        if getattr(self, "offline_mode", False):
            self.notify("Каталог", "В offline-режиме каталог SIGMA пересобрать нельзя.", "warning")
            return
        if self._background_catalog_running:
            self.notify("Каталог", "Обновление каталога уже идёт.", "info")
            return
        cfg = load_private_config()
        company = safe_str(cfg.get("sigma_company_key"))
        token = safe_str(cfg.get("sigma_api_token"))
        sp = safe_str(cfg.get("sigma_sell_point_id"))
        if not company or not token or not sp:
            self.notify("Каталог", "Не заполнены company key, API token или sellPointId.", "warning")
            return
        self._background_catalog_running = True
        self.update_catalog_status(refreshing=True)
        try:
            self.notify("Каталог", "Полная пересборка каталога SIGMA запущена…", "info")
        except Exception:
            pass

        def worker() -> None:
            ok = False
            msg = ""
            try:
                from sai_app import get_sigma_api_catalog_cached
                # get_sigma_api_catalog_cached(force_refresh=True) скачивает живой каталог и
                # save_catalog() атомарно заменяет products/barcodes для текущей точки.
                # Старый SQLite-кэш остаётся на месте, если скачивание сорвётся.
                catalog = get_sigma_api_catalog_cached(company, token, sp, log_callback=None, force_refresh=True)
                product_count = int(catalog.get("product_count") or 0)
                barcode_count = len(catalog.get("codes") or [])
                try:
                    save_private_config_patch({
                        "catalog_last_full_rebuild_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "catalog_last_full_rebuild_product_count": product_count,
                        "catalog_last_full_rebuild_barcode_count": barcode_count,
                    })
                except Exception:
                    pass
                ok = True
                msg = f"Каталог полностью пересобран: {product_count} товаров, {barcode_count} ШК."
            except Exception as exc:
                msg = "Полная пересборка каталога не удалась: " + str(exc)[:240]
            self._background_catalog_signals.finished.emit(ok, msg)

        threading.Thread(target=worker, daemon=True).start()

    def _background_catalog_finished(self, ok: bool, message: str) -> None:
        self._background_catalog_running = False
        self.refresh()
        self.update_catalog_status()
        if ok:
            # Forced startup/manual refresh should be visible; routine age-based
            # refreshes remain quiet because they are just a background service.
            message_l = safe_str(message).lower()
            if "принудительно" in message_l or "полностью пересобран" in message_l:
                self.notify("Каталог", message, "success")
        elif message:
            self.notify("Каталог", message, "warning")

    def refresh(self) -> None:
        ensure_runtime_dirs()
        try:
            sai_db.init_db()
        except Exception:
            pass
        self.refresh_history_table()
        self.update_catalog_status()

    def history_selected_id(self) -> int:
        table = getattr(self, "history_table", None)
        if table is None:
            return 0
        row = table.currentRow()
        if row < 0:
            return 0
        item = table.item(row, 0)
        try:
            return int(item.data(Qt.ItemDataRole.UserRole) if item else 0)
        except Exception:
            return 0

    def history_selection_changed(self) -> None:
        # Retained for compatibility with older code paths. History actions now
        # live directly in each row, so selection no longer controls buttons.
        return

    def _display_invoice_date(self, value: Any) -> str:
        raw = safe_str(value)
        if not raw:
            return "—"
        try:
            iso = sai_receipt_archive.normalize_date(raw)
            return dt.datetime.strptime(iso, "%Y-%m-%d").strftime("%d.%m.%Y")
        except Exception:
            return raw

    def refresh_history_table(self) -> None:
        table = getattr(self, "history_table", None)
        if table is None:
            return
        search = self.history_search.text().strip() if self.history_search is not None else ""
        try:
            rows = sai_db.search_successful_apply_runs(search, limit=1000) if search else sai_db.successful_apply_runs(search="", limit=1000)
        except Exception as exc:
            rows = []
            if self.history_summary_label is not None:
                self.history_summary_label.setText(f"Не удалось прочитать историю: {exc}")
        table.setRowCount(len(rows))
        quantity_sum = 0.0
        buying_sum = 0.0
        selling_sum = 0.0
        for r, row in enumerate(rows):
            quantity_sum += float(row.get("total_quantity") or 0)
            buying_sum += float(row.get("buying_total") or 0)
            selling_sum += float(row.get("selling_total") or 0)
            values = [
                self._display_invoice_date(row.get("invoice_date")),
                row.get("supplier_name") or "Без поставщика",
                "\n".join((row.get("history_matches") or [])[:3]) if search else "—",
                int(row.get("ok_count") or 0),
                quantity_text(row.get("total_quantity")),
                money(row.get("buying_total")),
                money(row.get("selling_total")),
                friendly_dt(row.get("created_at") or ""),
            ]
            apply_run_id = int(row.get("id") or 0)
            for c, value in enumerate(values):
                item = QTableWidgetItem(safe_str(value))
                if c == 0:
                    item.setData(Qt.ItemDataRole.UserRole, apply_run_id)
                if c in (1, 2):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
                else:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                table.setItem(r, c, item)
            delete_btn = HistoryDeleteButton(table)
            delete_btn.clicked.connect(lambda _checked=False, rid=apply_run_id: self.delete_receipt_by_id(rid))
            delete_cell = QWidget(table)
            delete_cell.setObjectName("HistoryDeleteCell")
            delete_cell.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
            delete_layout = QHBoxLayout(delete_cell)
            delete_layout.setContentsMargins(0, 0, 0, 0)
            delete_layout.setSpacing(0)
            delete_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            delete_layout.addWidget(delete_btn, 0, Qt.AlignmentFlag.AlignCenter)
            table.setCellWidget(r, 8, delete_cell)
        table.resizeRowsToContents()
        for row_index in range(table.rowCount()):
            table.setRowHeight(row_index, max(46, table.rowHeight(row_index)))
        table.clearSelection()
        if self.history_summary_label is not None:
            if rows:
                self.history_summary_label.setText(
                    f"Успешных приходов: {len(rows)} · товаров всего: {quantity_text(quantity_sum)} · "
                    f"закупка: {money(buying_sum)} · продажа: {money(selling_sum)}"
                )
            elif search:
                self.history_summary_label.setText("Такой товар или поставщик в истории не найден")
            else:
                self.history_summary_label.setText("Успешных приходов пока нет")

    def open_selected_receipt(self) -> None:
        apply_run_id = self.history_selected_id()
        if apply_run_id:
            self.open_receipt_details(apply_run_id)

    def _file_size_text(self, size: Any) -> str:
        try:
            value = int(size or 0)
        except Exception:
            value = 0
        if value >= 1024 * 1024:
            return f"{value / 1024 / 1024:.1f} МБ"
        if value >= 1024:
            return f"{value / 1024:.0f} КБ"
        return f"{value} Б"

    def open_receipt_details(self, apply_run_id: int) -> None:
        run = sai_db.get_apply_run(apply_run_id)
        if not run:
            QMessageBox.warning(self, "История приходов", "Запись прихода не найдена.")
            self.refresh_history_table()
            return
        try:
            sai_receipt_archive.ensure_legacy_archive(apply_run_id)
            run = sai_db.get_apply_run(apply_run_id) or run
        except Exception:
            pass

        dialog = QDialog(self)
        dialog.setWindowTitle(f"Приход — {run.get('supplier_name') or 'Без поставщика'}")
        dialog.resize(980, 680)
        root = QVBoxLayout(dialog)
        root.setContentsMargins(20, 18, 20, 16)
        root.setSpacing(12)

        title = QLabel(f"{run.get('supplier_name') or 'Без поставщика'} · {self._display_invoice_date(run.get('invoice_date'))}")
        title.setObjectName("WorkbenchTitle")
        root.addWidget(title)
        meta = QLabel(
            f"Позиций: {int(run.get('ok_count') or 0)}    ·    "
            f"Товаров всего: {quantity_text(run.get('total_quantity'))}    ·    "
            f"Закупка: {money(run.get('buying_total'))}    ·    "
            f"Продажа: {money(run.get('selling_total'))}\n"
            f"ID прихода SIGMA: {run.get('waybill_id') or '—'}    ·    "
            f"Введён: {friendly_dt(run.get('created_at') or '')}"
        )
        meta.setObjectName("InlineStatus")
        meta.setWordWrap(True)
        root.addWidget(meta)

        tabs = QTabWidget()
        items_table = self.make_table(["Товар", "ШК", "Кол-во", "Закупка", "Продажа", "Сумма закупки", "Сумма продажи"])
        items = sai_db.get_apply_items(apply_run_id)
        items_table.setRowCount(len(items))
        for r, item_row in enumerate(items):
            qty = float(item_row.get("quantity") or 0)
            buy = float(item_row.get("buying_price") or 0)
            sale = float(item_row.get("final_selling_price") or item_row.get("incoming_selling_price") or 0)
            values = [
                item_row.get("name") or "",
                item_row.get("used_barcode") or item_row.get("barcode") or "",
                quantity_text(qty),
                money(buy),
                money(sale),
                money(qty * buy),
                money(qty * sale),
            ]
            for c, value in enumerate(values):
                cell = QTableWidgetItem(safe_str(value))
                if c >= 2:
                    cell.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                items_table.setItem(r, c, cell)
        items_table.resizeRowsToContents()
        tabs.addTab(items_table, f"Состав прихода ({len(items)})")

        files_page = QWidget()
        files_layout = QVBoxLayout(files_page)
        files_layout.setContentsMargins(8, 10, 8, 8)
        files_layout.setSpacing(10)
        files_table = self.make_table(["Тип", "Файл", "Размер", "Сохранён"])
        files_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        files_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)

        def populate_files() -> None:
            file_rows = sai_db.receipt_files(apply_run_id)
            files_table.setRowCount(len(file_rows))
            for rr, file_row in enumerate(file_rows):
                path = Path(safe_str(file_row.get("archived_path")))
                values = [
                    sai_receipt_archive.KIND_LABELS.get(safe_str(file_row.get("kind")), safe_str(file_row.get("kind"))),
                    file_row.get("stored_name") or file_row.get("original_name") or path.name,
                    self._file_size_text(file_row.get("file_size")),
                    "да" if path.is_file() else "файл отсутствует",
                ]
                for cc, value in enumerate(values):
                    cell = QTableWidgetItem(safe_str(value))
                    if cc == 0:
                        cell.setData(Qt.ItemDataRole.UserRole, str(path))
                    if cc in (0, 2, 3):
                        cell.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    files_table.setItem(rr, cc, cell)
            files_table.resizeRowsToContents()

        def selected_file_path() -> Optional[Path]:
            rr = files_table.currentRow()
            if rr < 0:
                return None
            item = files_table.item(rr, 0)
            path = Path(safe_str(item.data(Qt.ItemDataRole.UserRole) if item else ""))
            return path if path.is_file() else None

        file_buttons = QHBoxLayout()
        open_file_btn = QPushButton("Открыть файл")
        open_file_btn.setObjectName("WorkbenchPrimaryButton")
        open_file_btn.clicked.connect(lambda: open_path(selected_file_path()) if selected_file_path() else QMessageBox.information(dialog, "Файлы прихода", "Выберите существующий файл."))
        file_buttons.addWidget(open_file_btn)
        open_folder_btn = QPushButton("Открыть папку прихода")
        open_folder_btn.setObjectName("SoftButton")
        open_folder_btn.clicked.connect(lambda: open_path(Path(safe_str((sai_db.get_apply_run(apply_run_id) or {}).get("archive_dir"))) if safe_str((sai_db.get_apply_run(apply_run_id) or {}).get("archive_dir")) else sai_receipt_archive.ARCHIVE_ROOT))
        file_buttons.addWidget(open_folder_btn)
        add_sources_btn = QPushButton("Добавить входные накладные")
        add_sources_btn.setObjectName("SoftButton")

        def add_sources() -> None:
            paths, _ = QFileDialog.getOpenFileNames(
                dialog,
                "Выберите исходные накладные",
                str(Path.home() / "Desktop"),
                "Документы (*.pdf *.png *.jpg *.jpeg *.webp *.xlsx *.xlsm *.xls *.xml *.zip *.csv);;Все файлы (*.*)",
            )
            if not paths:
                return
            try:
                copied = sai_receipt_archive.add_source_documents(apply_run_id, [Path(x) for x in paths])
                populate_files()
                self.notify("История приходов", f"Добавлено исходных файлов: {len(copied)}", "success")
            except Exception as exc:
                QMessageBox.critical(dialog, "История приходов", f"Не удалось добавить файлы:\n{exc}")

        add_sources_btn.clicked.connect(add_sources)
        file_buttons.addWidget(add_sources_btn)
        file_buttons.addStretch(1)
        files_layout.addLayout(file_buttons)
        files_layout.addWidget(files_table, 1)
        files_table.cellDoubleClicked.connect(lambda *_: open_path(selected_file_path()) if selected_file_path() else None)
        populate_files()
        tabs.addTab(files_page, "Файлы")
        root.addWidget(tabs, 1)

        bottom_buttons = QHBoxLayout()
        bottom_buttons.addStretch(1)
        close_btn = QPushButton("Закрыть")
        close_btn.setObjectName("SoftButton")
        close_btn.clicked.connect(dialog.reject)
        bottom_buttons.addWidget(close_btn)
        print_btn = QPushButton("Печатать")
        print_btn.setObjectName("WorkbenchPrimaryButton")
        print_btn.setEnabled(False)
        bottom_buttons.addWidget(print_btn)
        root.addLayout(bottom_buttons)

        def update_print_button() -> None:
            print_btn.setEnabled(tabs.currentWidget() is files_page and selected_file_path() is not None)

        def print_selected_receipt_file() -> None:
            path = selected_file_path()
            if path is None:
                update_print_button()
                return
            if print_file_silent(path):
                self.notify("Файлы прихода", f"Отправлено на печать: {path.name}", "success")
                return
            QMessageBox.warning(
                dialog,
                "Файлы прихода",
                "Не удалось отправить выбранный документ на обычный принтер.\n\n"
                "Проверьте принтер для обычной печати в настройках SAI.",
            )

        files_table.itemSelectionChanged.connect(update_print_button)
        tabs.currentChanged.connect(lambda *_: update_print_button())
        print_btn.clicked.connect(print_selected_receipt_file)
        update_print_button()
        dialog.exec()
        self.refresh_history_table()

    def delete_selected_receipt(self) -> None:
        self.delete_receipt_by_id(self.history_selected_id())

    def delete_receipt_by_id(self, apply_run_id: int) -> None:
        if not apply_run_id:
            return
        run = sai_db.get_apply_run(apply_run_id)
        if not run:
            self.refresh_history_table()
            return
        answer = QMessageBox.question(
            self,
            "Удалить запись прихода",
            f"Удалить локальную запись и сохранённую папку файлов?\n\n"
            f"{run.get('supplier_name') or 'Без поставщика'} · {self._display_invoice_date(run.get('invoice_date'))}\n\n"
            "Сам приход в SIGMA удалён не будет.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            sai_receipt_archive.delete_receipt_archive(apply_run_id)
            sai_db.delete_apply_run(apply_run_id)
            self.refresh_history_table()
            self.notify("История приходов", "Локальная запись удалена. Приход в SIGMA не изменён.", "success")
        except Exception as exc:
            QMessageBox.critical(self, "История приходов", f"Не удалось удалить запись:\n{exc}")


class WindowControlButton(QPushButton):
    """Crisp vector window controls that do not depend on icon fonts."""

    def __init__(self, kind: str, window: QMainWindow, parent=None) -> None:
        super().__init__(parent)
        self.kind = str(kind)
        self.host_window = window
        self.setObjectName("WindowControlButton")
        self.setProperty("kind", self.kind)
        self.setFixedSize(46, 36)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        if self.kind == "minimize":
            self.setToolTip("Свернуть")
            self.clicked.connect(window.showMinimized)
        elif self.kind == "maximize":
            self.setToolTip("Развернуть")
            self.clicked.connect(self.toggle_maximized)
        else:
            self.setToolTip("Закрыть")
            self.clicked.connect(window.close)

    def toggle_maximized(self) -> None:
        if self.host_window.isMaximized():
            self.host_window.showNormal()
        else:
            self.host_window.showMaximized()
        self.update()

    def sync_state(self) -> None:
        if self.kind == "maximize":
            self.setToolTip("Восстановить" if self.host_window.isMaximized() else "Развернуть")
            self.update()

    def paintEvent(self, event):  # noqa: N802 - Qt override name
        dark = bool(QApplication.instance() and QApplication.instance().property("saiNightTheme"))
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        if self.underMouse():
            hover = QColor("#e5484d") if self.kind == "close" else QColor("#1e293b" if dark else "#e6ebf3")
            painter.fillRect(self.rect(), hover)
        color = QColor("#ffffff") if self.kind == "close" and self.underMouse() else QColor("#cbd5e1" if dark else "#334155")
        pen = QPen(color, 1.55)
        pen.setCapStyle(Qt.PenCapStyle.SquareCap)
        painter.setPen(pen)
        cx = self.width() / 2.0
        cy = self.height() / 2.0
        if self.kind == "minimize":
            painter.drawLine(QPointF(cx - 5.5, cy + 3.0), QPointF(cx + 5.5, cy + 3.0))
        elif self.kind == "maximize":
            if self.host_window.isMaximized():
                painter.drawRect(QRectF(cx - 4.5, cy - 3.5, 9.0, 8.0))
                painter.drawLine(QPointF(cx - 2.5, cy - 5.5), QPointF(cx + 6.5, cy - 5.5))
                painter.drawLine(QPointF(cx + 6.5, cy - 5.5), QPointF(cx + 6.5, cy + 2.5))
            else:
                painter.drawRect(QRectF(cx - 5.0, cy - 5.0, 10.0, 10.0))
        else:
            painter.drawLine(QPointF(cx - 5.0, cy - 5.0), QPointF(cx + 5.0, cy + 5.0))
            painter.drawLine(QPointF(cx + 5.0, cy - 5.0), QPointF(cx - 5.0, cy + 5.0))
        painter.end()


class FramelessTitleBar(QFrame):
    """Thin application-owned title strip for a frameless SAI window."""

    def __init__(self, window: QMainWindow) -> None:
        super().__init__(window)
        self.host_window = window
        self._drag_offset: QPoint | None = None
        self.setObjectName("FramelessTitleBar")
        self.setFixedHeight(36)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 0, 0, 0)
        layout.setSpacing(0)
        brand = QLabel(f"SAI  ·  {APP_VERSION}", self)
        brand.setObjectName("FramelessTitleBrand")
        brand.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        layout.addWidget(brand)
        layout.addStretch(1)
        self.minimize_btn = WindowControlButton("minimize", window, self)
        self.maximize_btn = WindowControlButton("maximize", window, self)
        self.close_btn = WindowControlButton("close", window, self)
        layout.addWidget(self.minimize_btn)
        layout.addWidget(self.maximize_btn)
        layout.addWidget(self.close_btn)

    def sync_state(self) -> None:
        self.maximize_btn.sync_state()

    def mousePressEvent(self, event):  # noqa: N802 - Qt override name
        if event.button() == Qt.MouseButton.LeftButton:
            handle = self.host_window.windowHandle()
            if handle is not None and handle.startSystemMove():
                event.accept()
                return
            self._drag_offset = event.globalPosition().toPoint() - self.host_window.frameGeometry().topLeft()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):  # noqa: N802 - Qt override name
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton and not self.host_window.isMaximized():
            self.host_window.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):  # noqa: N802 - Qt override name
        self._drag_offset = None
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):  # noqa: N802 - Qt override name
        if event.button() == Qt.MouseButton.LeftButton:
            self.maximize_btn.toggle_maximized()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


class FramelessResizeController(QObject):
    """Start native Qt resize operations from the invisible six-pixel window edge."""

    EDGE_SIZE = 6

    def __init__(self, window: QMainWindow) -> None:
        super().__init__(window)
        self.window = window
        window.setMouseTracking(True)
        for child in window.findChildren(QWidget):
            child.setMouseTracking(True)
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)

    def _edges_at(self, global_pos: QPoint):
        if self.window.isMaximized() or self.window.isFullScreen():
            return Qt.Edge(0)
        local = self.window.mapFromGlobal(global_pos)
        edges = Qt.Edge(0)
        if local.x() <= self.EDGE_SIZE:
            edges |= Qt.Edge.LeftEdge
        elif local.x() >= self.window.width() - self.EDGE_SIZE - 1:
            edges |= Qt.Edge.RightEdge
        if local.y() <= self.EDGE_SIZE:
            edges |= Qt.Edge.TopEdge
        elif local.y() >= self.window.height() - self.EDGE_SIZE - 1:
            edges |= Qt.Edge.BottomEdge
        return edges

    @staticmethod
    def _cursor_for_edges(edges):
        if edges in (Qt.Edge.LeftEdge | Qt.Edge.TopEdge, Qt.Edge.RightEdge | Qt.Edge.BottomEdge):
            return Qt.CursorShape.SizeFDiagCursor
        if edges in (Qt.Edge.RightEdge | Qt.Edge.TopEdge, Qt.Edge.LeftEdge | Qt.Edge.BottomEdge):
            return Qt.CursorShape.SizeBDiagCursor
        if edges & (Qt.Edge.LeftEdge | Qt.Edge.RightEdge):
            return Qt.CursorShape.SizeHorCursor
        if edges & (Qt.Edge.TopEdge | Qt.Edge.BottomEdge):
            return Qt.CursorShape.SizeVerCursor
        return Qt.CursorShape.ArrowCursor

    def eventFilter(self, obj, event):  # noqa: N802 - Qt override name
        if not isinstance(obj, QWidget) or obj.window() is not self.window:
            return super().eventFilter(obj, event)
        event_type = event.type()
        if event_type == QEvent.Type.ChildAdded:
            child = getattr(event, "child", lambda: None)()
            if isinstance(child, QWidget):
                child.setMouseTracking(True)
        if event_type == QEvent.Type.MouseMove:
            try:
                edges = self._edges_at(event.globalPosition().toPoint())
                obj.setCursor(self._cursor_for_edges(edges))
            except Exception:
                pass
        elif event_type == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
            try:
                edges = self._edges_at(event.globalPosition().toPoint())
                if edges:
                    handle = self.window.windowHandle()
                    if handle is not None and handle.startSystemResize(edges):
                        return True
            except Exception:
                pass
        return super().eventFilter(obj, event)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"SAI {APP_VERSION}")
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self._initial_screen_fit_done = False

        shell = QWidget(self)
        shell.setObjectName("FramelessWindowShell")
        shell_layout = QVBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)
        self.title_bar = FramelessTitleBar(self)
        shell_layout.addWidget(self.title_bar, 0)
        self.main_stack = QStackedWidget()
        self.main_stack.setObjectName("MainWindowStack")
        shell_layout.addWidget(self.main_stack, 1)
        self.setCentralWidget(shell)
        self._frameless_resize = FramelessResizeController(self)
        self.main_page: MainPage | None = None
        self.startup_page = StartupGateWidget(self)
        self.title_bar.setVisible(False)
        self.startup_page.startup_done.connect(self.finish_startup)
        self.startup_page.startup_cancelled.connect(self.cancel_startup)
        self.main_stack.addWidget(self.startup_page)
        self.main_stack.setCurrentWidget(self.startup_page)
        # No top menu bar: the main window should stay visually clean.
        # All useful actions are available from the left rail or main button.

    def fit_to_available_screen(self, force: bool = False) -> None:
        """Keep every window edge inside the usable desktop, including the taskbar."""
        if self._initial_screen_fit_done and not force:
            return
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            self.resize(1180, 720)
            self._initial_screen_fit_done = True
            return
        available = screen.availableGeometry()
        margin = 10
        max_width = max(1, available.width() - margin * 2)
        max_height = max(1, available.height() - margin * 2)
        width = min(1180, max_width)
        height = min(760, max_height)
        self.setMinimumSize(min(860, width), min(540, height))
        self.resize(width, height)
        self.move(
            available.x() + max(0, (available.width() - width) // 2),
            available.y() + max(0, (available.height() - height) // 2),
        )
        self._initial_screen_fit_done = True

    def showEvent(self, event):  # noqa: N802 - Qt override name
        self.fit_to_available_screen()
        super().showEvent(event)

    def changeEvent(self, event):  # noqa: N802 - Qt override name
        super().changeEvent(event)
        if event.type() == QEvent.Type.WindowStateChange and getattr(self, "title_bar", None) is not None:
            self.title_bar.sync_state()

    def finish_startup(self, offline: bool, message: str) -> None:
        """Open the working interface without a splash or animated handoff."""
        if getattr(self, "_startup_handoff_started", False):
            return
        self._startup_handoff_started = True
        if self.main_page is None:
            self.main_page = MainPage()
            self.main_stack.addWidget(self.main_page)
        self.main_page.set_offline_mode(bool(offline), message)
        self.main_page.setGraphicsEffect(None)
        self.title_bar.setVisible(True)
        self.main_stack.setCurrentWidget(self.main_page)

        # Background services must not delay the first painted interface frame.
        QTimer.singleShot(0, lambda: self.main_page and self.main_page.start_background_services(bool(offline)))
        self._startup_handoff_started = False

    def cancel_startup(self) -> None:
        app = QApplication.instance()
        if app is not None:
            app.quit()

    def make_menu(self) -> None:
        sai_menu = self.menuBar().addMenu("SAI")
        refresh = QAction("Обновить экран", self)
        refresh.triggered.connect(self.main_page.refresh)
        sai_menu.addAction(refresh)
        sai_menu.addSeparator()
        launch = QAction("Новый привоз", self)
        launch.triggered.connect(self.main_page.show_workbench)
        sai_menu.addAction(launch)
        sai_menu.addSeparator()
        open_data = QAction("Открыть папку SAI", self)
        open_data.triggered.connect(lambda: open_path(USER_DATA_DIR))
        sai_menu.addAction(open_data)
        open_logs = QAction("Открыть логи", self)
        open_logs.triggered.connect(lambda: open_path(LOGS_DIR))
        sai_menu.addAction(open_logs)
        sai_menu.addSeparator()
        about = QAction("О программе", self)
        about.triggered.connect(lambda: QMessageBox.information(
            self,
            "SAI",
            f"SAI {APP_VERSION}\n\nPySide6 стал главным окном SAI."
        ))
        sai_menu.addAction(about)



from sai_legacy_styles import STYLESHEET, DARK_STYLESHEET

THEME_MODE_DAY = "day"
THEME_MODE_NIGHT = "night"
THEME_MODES = {THEME_MODE_DAY, THEME_MODE_NIGHT}
DEFAULT_NIGHT_THEME_START = dt.time(22, 0)
NIGHT_THEME_END = dt.time(7, 0)


def normalize_theme_mode(value: Any) -> str:
    mode = safe_str(value).strip().lower()
    return mode if mode in THEME_MODES else THEME_MODE_DAY


def parse_theme_start(value: Any) -> dt.time:
    """Legacy parser used only to migrate the removed timed theme mode once."""
    text = safe_str(value).strip()
    for fmt in ("%H:%M", "%H.%M", "%H"):
        try:
            parsed = dt.datetime.strptime(text, fmt).time()
            return dt.time(parsed.hour, parsed.minute)
        except Exception:
            pass
    return DEFAULT_NIGHT_THEME_START


def is_night_theme_time(
    moment: dt.datetime | dt.time | None = None,
    start: dt.time | None = None,
    end: dt.time | None = None,
) -> bool:
    """Legacy helper used only to preserve the visible theme during migration."""
    if moment is None:
        current = dt.datetime.now().time()
    elif isinstance(moment, dt.datetime):
        current = moment.time()
    else:
        current = moment
    current = dt.time(current.hour, current.minute)
    start_value = start or DEFAULT_NIGHT_THEME_START
    end_value = end or NIGHT_THEME_END
    if start_value == end_value:
        return True
    if start_value < end_value:
        return start_value <= current < end_value
    return current >= start_value or current < end_value


def system_prefers_dark(app: QApplication | None = None) -> bool:
    """Legacy one-shot reader used only when migrating an old system mode."""
    qt_app = app or QApplication.instance()
    if qt_app is not None:
        try:
            scheme = qt_app.styleHints().colorScheme()
            dark_value = getattr(Qt.ColorScheme, "Dark", None)
            light_value = getattr(Qt.ColorScheme, "Light", None)
            if dark_value is not None and scheme == dark_value:
                return True
            if light_value is not None and scheme == light_value:
                return False
        except Exception:
            pass
    if os.name == "nt":
        try:
            import winreg

            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
            ) as key:
                value, _kind = winreg.QueryValueEx(key, "AppsUseLightTheme")
                return int(value) == 0
        except Exception:
            pass
    return False


def legacy_theme_is_dark(config: Dict[str, Any], app: QApplication | None = None) -> bool:
    """Convert removed system/schedule settings into one fixed current theme."""
    raw_mode = safe_str(config.get("theme_mode")).strip().lower()
    if raw_mode == "night":
        return True
    if raw_mode == "system":
        return system_prefers_dark(app)
    if raw_mode == "schedule":
        return is_night_theme_time(start=parse_theme_start(config.get("night_theme_start")))
    return False


def resolve_theme_is_dark(
    mode: Any,
    moment: dt.datetime | dt.time | None = None,
    start: dt.time | None = None,
    app: QApplication | None = None,
) -> bool:
    del moment, start, app
    return normalize_theme_mode(mode) == THEME_MODE_NIGHT




class AutoThemeController(QObject):
    """Apply one fixed user-selected light or dark theme."""

    def __init__(self, app: QApplication) -> None:
        super().__init__(app)
        self.app = app
        self.dark_active: Optional[bool] = None
        self.mode = THEME_MODE_DAY
        self.reload_settings(apply_now=True)

    def reload_settings(self, apply_now: bool = True) -> None:
        cfg = load_private_config()
        raw_mode = safe_str(cfg.get("theme_mode")).strip().lower()
        if raw_mode in THEME_MODES:
            self.mode = raw_mode
        else:
            self.mode = THEME_MODE_NIGHT if legacy_theme_is_dark(cfg, self.app) else THEME_MODE_DAY
            save_private_config_patch({"theme_mode": self.mode})
        if apply_now:
            self.apply_if_needed(force=True)

    def resolve_dark(self) -> bool:
        return self.mode == THEME_MODE_NIGHT

    def apply_if_needed(self, force: bool = False) -> None:
        dark = self.resolve_dark()
        if not force and dark == self.dark_active:
            return
        self.dark_active = dark
        self.app.setProperty("saiNightTheme", dark)
        top_levels = list(self.app.topLevelWidgets())
        for widget in top_levels:
            widget.setUpdatesEnabled(False)
        try:
            # The normalized layer is always appended last. Theme changes are
            # repainted once, after the whole object tree has the new palette,
            # which removes the slow grey intermediate frame.
            self.app.setStyleSheet(
                STYLESHEET
                + (DARK_STYLESHEET if dark else "")
                + ui_polish_stylesheet(dark)
            )
            for button in self.app.findChildren(RailIconButton):
                button.refresh_theme()
        finally:
            for widget in top_levels:
                widget.setUpdatesEnabled(True)
                widget.update()


def main() -> int:
    ensure_runtime_dirs()
    apply_v12119_startup_defaults()
    apply_v1227av_ready_defaults()
    app = QApplication(sys.argv)
    app.setApplicationName("SAI")
    app._sai_theme_controller = AutoThemeController(app)
    app._sai_no_wheel_filter = NoWheelFilter(app)
    app.installEventFilter(app._sai_no_wheel_filter)
    win = MainWindow()
    win.showMaximized()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
