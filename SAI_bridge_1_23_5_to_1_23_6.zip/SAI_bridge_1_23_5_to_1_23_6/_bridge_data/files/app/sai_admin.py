#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Standalone SAI Admin application for users, secrets and module access."""
from __future__ import annotations

import sys
from dataclasses import replace

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QDialog, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMainWindow, QMessageBox, QPushButton,
    QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

from sai_accounts import AccountService
from sai_ui_style import ui_polish_stylesheet
from sai_version import APP_VERSION


ADMIN_STYLE = """
QMainWindow, QWidget#AdminRoot { background:#f5f7fb; color:#172033; }
QFrame#AdminSidebar { background:#172033; border:none; }
QLabel#AdminBrand { color:white; font-size:20px; font-weight:800; }
QLabel#AdminMuted { color:#94a3b8; font-size:12px; }
QListWidget#UserList { background:transparent; border:none; color:#dbeafe; outline:none; }
QListWidget#UserList::item { padding:12px 10px; margin:2px 0; border-radius:9px; }
QListWidget#UserList::item:selected { background:#2b3b55; color:white; }
QFrame#AdminCard, QFrame#ModuleTile { background:white; border:1px solid #dbe3ef; border-radius:14px; }
QFrame#ModuleTile[moduleEnabled="false"] { background:#eef2f7; border-color:#d8e0eb; }
QLabel#AdminTitle { font-size:25px; font-weight:850; color:#172033; }
QLabel#AdminSection { font-size:14px; font-weight:800; color:#172033; }
QLabel#AdminText { color:#526079; font-size:12px; }
QPushButton#ModuleAction[moduleState="off"] { background:#3b82f6; color:white; border:none; border-radius:15px; min-width:30px; min-height:30px; font-size:19px; font-weight:800; }
QPushButton#ModuleAction[moduleState="off"]:hover { background:#1d4ed8; }
QPushButton#ModuleAction[moduleState="off"]:pressed { background:#1e40af; padding-top:2px; }
QPushButton#ModuleAction[moduleState="on"] { background:#e8f7ef; color:#137547; border:1px solid #b9e6cf; border-radius:15px; padding:6px 12px; font-weight:750; }
QPushButton#ModuleAction[moduleState="on"]:hover { background:#fee2e2; color:#b42318; border-color:#fecaca; }
QPushButton#ModuleAction[moduleState="core"] { background:#eef2f7; color:#64748b; border:1px solid #d8e0eb; border-radius:15px; padding:6px 12px; font-weight:750; }
QPushButton#AdminPrimary { background:#2563eb; color:white; border:none; border-radius:9px; padding:9px 15px; font-weight:800; }
QPushButton#AdminSoft { background:white; color:#334155; border:1px solid #d5deea; border-radius:9px; padding:8px 12px; font-weight:700; }
QLineEdit#AdminInput { background:white; color:#172033; border:1px solid #cfd9e7; border-radius:9px; padding:9px 11px; }
"""


class AdminLoginDialog(QDialog):
    def __init__(self, service: AccountService) -> None:
        super().__init__(); self.service = service; self.owner = service.owner()
        self.setWindowTitle("SAI Admin — вход"); self.setModal(True); self.setMinimumWidth(430)
        layout = QVBoxLayout(self); layout.setContentsMargins(24, 24, 24, 24); layout.setSpacing(12)
        title = QLabel("Первичная защита SAI Admin" if self.owner and self.owner.status != "active" else "Вход в SAI Admin")
        title.setObjectName("AdminTitle"); layout.addWidget(title)
        note = QLabel("Создайте пароль владельца Mike." if self.owner and self.owner.status != "active" else "Введите пароль владельца Mike.")
        note.setObjectName("AdminText"); layout.addWidget(note)
        self.password = QLineEdit(); self.password.setObjectName("AdminInput"); self.password.setEchoMode(QLineEdit.Password); self.password.setPlaceholderText("Пароль")
        layout.addWidget(self.password)
        self.confirm = QLineEdit(); self.confirm.setObjectName("AdminInput"); self.confirm.setEchoMode(QLineEdit.Password); self.confirm.setPlaceholderText("Повторите пароль")
        self.confirm.setVisible(bool(self.owner and self.owner.status != "active")); layout.addWidget(self.confirm)
        button = QPushButton("Создать пароль" if self.confirm.isVisible() else "Войти"); button.setObjectName("AdminPrimary"); button.clicked.connect(self.submit)
        layout.addWidget(button, 0, Qt.AlignRight)

    def submit(self) -> None:
        try:
            if self.confirm.isVisible():
                if self.password.text() != self.confirm.text(): raise ValueError("Пароли не совпадают")
                self.service.activate_owner(self.password.text())
            elif not self.service.verify_owner(self.password.text()):
                raise ValueError("Неверный пароль")
        except Exception as exc:
            QMessageBox.warning(self, "SAI Admin", str(exc)); return
        self.accept()


class ModuleTile(QFrame):
    def __init__(self, module, callback) -> None:
        super().__init__(); self.module = module; self.setObjectName("ModuleTile"); self.setProperty("moduleEnabled", module.enabled)
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        layout = QHBoxLayout(self); layout.setContentsMargins(14, 12, 12, 12); layout.setSpacing(12)
        text = QVBoxLayout(); text.setSpacing(3)
        title = QLabel(module.name); title.setObjectName("AdminSection")
        note = QLabel(module.description); note.setObjectName("AdminText"); note.setWordWrap(True)
        text.addWidget(title); text.addWidget(note); layout.addLayout(text, 1)
        self.callback = callback
        self.action_button = QPushButton()
        self.action_button.setObjectName("ModuleAction")
        self.action_button.clicked.connect(lambda _checked=False: self._clicked())
        layout.addWidget(self.action_button)
        self.set_enabled(module.enabled)

    def _clicked(self, _checked: bool = False) -> None:
        if not self.module.locked:
            self.callback(self, self.module.code, not self.module.enabled)

    def set_enabled(self, enabled: bool) -> None:
        self.module = replace(self.module, enabled=bool(enabled))
        button = self.action_button
        if self.module.locked:
            button.setText("Базовый"); button.setProperty("moduleState", "core"); button.setEnabled(False)
            button.setToolTip("Этот модуль входит в основу SAI и не отключается")
        else:
            button.setEnabled(True)
            button.setText("✓ Подключён" if enabled else "+")
            button.setProperty("moduleState", "on" if enabled else "off")
            button.setCursor(Qt.PointingHandCursor)
            button.setToolTip("Отключить модуль" if enabled else "Подключить модуль")
        self.setProperty("moduleEnabled", bool(enabled))
        for widget in (self, button):
            style = widget.style(); style.unpolish(widget); style.polish(widget); widget.update()


class AdminWindow(QMainWindow):
    def __init__(self, service: AccountService | None = None) -> None:
        super().__init__(); self.service = service or AccountService(); self.current_username = ""; self.module_tiles: dict[str, ModuleTile] = {}
        self.setWindowTitle(f"SAI Admin {APP_VERSION}"); self.resize(1220, 780); self.setMinimumSize(980, 650); self.build_ui(); self.refresh_users()

    def build_ui(self) -> None:
        root = QWidget(); root.setObjectName("AdminRoot"); self.setCentralWidget(root)
        outer = QHBoxLayout(root); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        sidebar = QFrame(); sidebar.setObjectName("AdminSidebar"); sidebar.setFixedWidth(280)
        side = QVBoxLayout(sidebar); side.setContentsMargins(18, 22, 18, 18); side.setSpacing(10)
        brand = QLabel("SAI Admin"); brand.setObjectName("AdminBrand"); side.addWidget(brand)
        caption = QLabel("Пользователи и модули"); caption.setObjectName("AdminMuted"); side.addWidget(caption)
        self.search = QLineEdit(); self.search.setObjectName("AdminInput"); self.search.setPlaceholderText("Найти пользователя"); self.search.textChanged.connect(self.refresh_users); side.addWidget(self.search)
        self.user_list = QListWidget(); self.user_list.setObjectName("UserList"); self.user_list.currentItemChanged.connect(self.user_selected); side.addWidget(self.user_list, 1)
        add_title = QLabel("Новый пользователь"); add_title.setObjectName("AdminMuted"); side.addWidget(add_title)
        self.new_name = QLineEdit(); self.new_name.setObjectName("AdminInput"); self.new_name.setPlaceholderText("Имя")
        self.new_login = QLineEdit(); self.new_login.setObjectName("AdminInput"); self.new_login.setPlaceholderText("Логин")
        side.addWidget(self.new_name); side.addWidget(self.new_login)
        add = QPushButton("+ Добавить пользователя"); add.setObjectName("AdminPrimary"); add.clicked.connect(self.add_user); side.addWidget(add)
        outer.addWidget(sidebar)

        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.detail = QWidget(); self.detail.setObjectName("AdminRoot"); scroll.setWidget(self.detail)
        self.detail_layout = QVBoxLayout(self.detail); self.detail_layout.setContentsMargins(30, 28, 30, 28); self.detail_layout.setSpacing(16)
        self.user_title = QLabel("Выберите пользователя"); self.user_title.setObjectName("AdminTitle"); self.detail_layout.addWidget(self.user_title)
        self.user_meta = QLabel("Информация о пользователе появится здесь."); self.user_meta.setObjectName("AdminText"); self.detail_layout.addWidget(self.user_meta)
        user_actions = QHBoxLayout()
        self.status_button = QPushButton("Заблокировать"); self.status_button.setObjectName("AdminSoft"); self.status_button.clicked.connect(self.toggle_status)
        user_actions.addWidget(self.status_button); user_actions.addStretch(1); self.detail_layout.addLayout(user_actions)

        api = QFrame(); api.setObjectName("AdminCard"); api_layout = QVBoxLayout(api); api_layout.setContentsMargins(18, 16, 18, 16); api_layout.setSpacing(10)
        api_title = QLabel("ChatGPT API"); api_title.setObjectName("AdminSection"); api_layout.addWidget(api_title)
        api_note = QLabel("Ключ владельца используется текущей SAI. Ключи остальных пользователей готовы для будущего персонального входа.")
        api_note.setObjectName("AdminText"); api_note.setWordWrap(True); api_layout.addWidget(api_note)
        self.api_status = QLabel("Не задан"); self.api_status.setObjectName("AdminText"); api_layout.addWidget(self.api_status)
        api_row = QHBoxLayout(); self.api_input = QLineEdit(); self.api_input.setObjectName("AdminInput"); self.api_input.setEchoMode(QLineEdit.Password); self.api_input.setPlaceholderText("Вставьте новый API-ключ — sk-…")
        save = QPushButton("Сохранить ключ"); save.setObjectName("AdminPrimary"); save.clicked.connect(self.save_api_key)
        self.delete_api_button = QPushButton("Удалить ключ"); self.delete_api_button.setObjectName("AdminSoft"); self.delete_api_button.clicked.connect(self.delete_api_key)
        api_row.addWidget(self.api_input, 1); api_row.addWidget(save); api_row.addWidget(self.delete_api_button); api_layout.addLayout(api_row); self.detail_layout.addWidget(api)
        connection_form = QFormLayout(); connection_form.setHorizontalSpacing(12); connection_form.setVerticalSpacing(9)
        self.ai_model_input = QLineEdit(); self.ai_model_input.setObjectName("AdminInput")
        self.ai_proxy_input = QLineEdit(); self.ai_proxy_input.setObjectName("AdminInput"); self.ai_proxy_input.setPlaceholderText("Необязательно")
        self.ai_base_input = QLineEdit(); self.ai_base_input.setObjectName("AdminInput")
        connection_form.addRow("Модель", self.ai_model_input)
        connection_form.addRow("Прокси", self.ai_proxy_input)
        connection_form.addRow("Адрес API", self.ai_base_input)
        api_layout.addLayout(connection_form)
        save_connection = QPushButton("Сохранить настройки ChatGPT"); save_connection.setObjectName("AdminPrimary"); save_connection.clicked.connect(self.save_ai_settings)
        api_layout.addWidget(save_connection, 0, Qt.AlignRight)

        marking = QFrame(); marking.setObjectName("AdminCard"); marking_layout = QVBoxLayout(marking); marking_layout.setContentsMargins(18, 16, 18, 16); marking_layout.setSpacing(10)
        marking_title = QLabel("Проверка маркировки — токен ККТ"); marking_title.setObjectName("AdminSection"); marking_layout.addWidget(marking_title)
        marking_note = QLabel("Один ключ действует для всей организации. Он хранится зашифрованно средствами Windows и используется только для проверки Data Matrix через «Честный знак».")
        marking_note.setObjectName("AdminText"); marking_note.setWordWrap(True); marking_layout.addWidget(marking_note)
        self.marking_status = QLabel("Не задан"); self.marking_status.setObjectName("AdminText"); marking_layout.addWidget(self.marking_status)
        marking_row = QHBoxLayout(); self.marking_input = QLineEdit(); self.marking_input.setObjectName("AdminInput"); self.marking_input.setEchoMode(QLineEdit.Password); self.marking_input.setPlaceholderText("Вставьте токен ККТ")
        marking_save = QPushButton("Сохранить токен"); marking_save.setObjectName("AdminPrimary"); marking_save.clicked.connect(self.save_marking_token)
        self.delete_marking_button = QPushButton("Удалить токен"); self.delete_marking_button.setObjectName("AdminSoft"); self.delete_marking_button.clicked.connect(self.delete_marking_token)
        marking_row.addWidget(self.marking_input, 1); marking_row.addWidget(marking_save); marking_row.addWidget(self.delete_marking_button); marking_layout.addLayout(marking_row)
        self.detail_layout.addWidget(marking)

        modules_card = QFrame(); modules_card.setObjectName("AdminCard"); modules_layout = QVBoxLayout(modules_card); modules_layout.setContentsMargins(18, 16, 18, 16); modules_layout.setSpacing(12)
        module_title = QLabel("Модули пользователя"); module_title.setObjectName("AdminSection"); modules_layout.addWidget(module_title)
        module_note = QLabel("Серые модули отключены. Нажмите +, чтобы подключить модуль пользователю."); module_note.setObjectName("AdminText"); modules_layout.addWidget(module_note)
        self.module_grid = QGridLayout(); self.module_grid.setHorizontalSpacing(10); self.module_grid.setVerticalSpacing(10)
        self.module_grid.setColumnStretch(0, 1); self.module_grid.setColumnStretch(1, 1); modules_layout.addLayout(self.module_grid)
        self.detail_layout.addWidget(modules_card); self.detail_layout.addStretch(1); outer.addWidget(scroll, 1)

    def refresh_users(self) -> None:
        selected = self.current_username; query = self.search.text().strip().lower() if hasattr(self, "search") else ""
        self.user_list.blockSignals(True); self.user_list.clear()
        target_row = -1
        for user in self.service.users():
            if query and query not in user.username.lower() and query not in user.display_name.lower(): continue
            item = QListWidgetItem(f"{user.display_name}\n@{user.username}  ·  {user.role}"); item.setData(Qt.UserRole, user.username); self.user_list.addItem(item)
            if user.username == selected: target_row = self.user_list.count() - 1
        self.user_list.blockSignals(False)
        if self.user_list.count(): self.user_list.setCurrentRow(target_row if target_row >= 0 else 0)

    def user_selected(self, current, _previous=None) -> None:
        if not current: return
        self.current_username = str(current.data(Qt.UserRole)); self.refresh_detail()

    def refresh_detail(self) -> None:
        user = self.service.user(self.current_username)
        if not user: return
        self.user_title.setText(user.display_name)
        last_seen = user.last_login_at or "ещё не входил"
        self.user_meta.setText(f"@{user.username}  ·  роль: {user.role}  ·  статус: {user.status}\nСоздан: {user.created_at}  ·  Последний вход: {last_seen}")
        self.status_button.setVisible(user.role != "owner")
        self.status_button.setText("Разблокировать" if user.status == "blocked" else "Заблокировать")
        mask = self.service.openai_key_mask(user.user_id)
        suffix = " · используется текущей SAI" if user.role == "owner" and mask != "Не задан" else ""
        self.api_status.setText(("Сохранён: " + mask if mask != "Не задан" else "Ключ не задан") + suffix)
        self.delete_api_button.setEnabled(mask != "Не задан")
        ai_settings = self.service.ai_settings(user.user_id)
        self.ai_model_input.setText(ai_settings["model"])
        self.ai_proxy_input.setText(ai_settings["proxy_url"])
        self.ai_base_input.setText(ai_settings["api_base"])
        marking_mask = self.service.marking_token_mask()
        self.marking_status.setText("Сохранён: " + marking_mask if marking_mask != "Не задан" else "Токен не задан")
        self.delete_marking_button.setEnabled(marking_mask != "Не задан")
        while self.module_grid.count():
            item = self.module_grid.takeAt(0)
            widget = item.widget()
            if widget:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        self.module_tiles = {}
        for index, module in enumerate(self.service.modules_for(user.user_id)):
            tile = ModuleTile(module, self.change_module)
            self.module_tiles[module.code] = tile
            self.module_grid.addWidget(tile, index // 2, index % 2)

    def change_module(self, tile: ModuleTile, code: str, enabled: bool) -> None:
        user = self.service.user(self.current_username)
        if not user: return
        self.service.set_module(user.user_id, code, enabled)
        tile.set_enabled(enabled)

    def save_api_key(self) -> None:
        user = self.service.user(self.current_username)
        if not user: return
        try: masked = self.service.save_openai_key(user.user_id, self.api_input.text())
        except Exception as exc: QMessageBox.warning(self, "ChatGPT API", str(exc)); return
        self.api_input.clear(); self.refresh_detail()

    def delete_api_key(self) -> None:
        user = self.service.user(self.current_username)
        if not user: return
        answer = QMessageBox.question(
            self, "ChatGPT API", f"Удалить API-ключ пользователя {user.display_name}?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if answer != QMessageBox.Yes: return
        self.service.delete_openai_key(user.user_id)
        self.refresh_detail()

    def save_ai_settings(self) -> None:
        user = self.service.user(self.current_username)
        if not user: return
        try:
            self.service.save_ai_settings(
                user.user_id, self.ai_model_input.text(),
                self.ai_proxy_input.text(), self.ai_base_input.text(),
            )
        except Exception as exc:
            QMessageBox.warning(self, "ChatGPT API", str(exc)); return
        self.refresh_detail()

    def save_marking_token(self) -> None:
        owner = self.service.owner()
        if not owner: return
        try: self.service.save_marking_token(owner.user_id, self.marking_input.text())
        except Exception as exc: QMessageBox.warning(self, "Токен ККТ", str(exc)); return
        self.marking_input.clear(); self.refresh_detail()

    def delete_marking_token(self) -> None:
        owner = self.service.owner()
        if not owner: return
        answer = QMessageBox.question(self, "Токен ККТ", "Удалить токен проверки маркировки?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes: return
        self.service.delete_marking_token(owner.user_id); self.refresh_detail()

    def toggle_status(self) -> None:
        user = self.service.user(self.current_username)
        if not user: return
        self.service.change_status(user.user_id, "active" if user.status == "blocked" else "blocked")
        self.refresh_users(); self.refresh_detail()

    def add_user(self) -> None:
        try: user = self.service.add_user(self.new_login.text(), self.new_name.text())
        except Exception as exc: QMessageBox.warning(self, "Новый пользователь", str(exc)); return
        self.new_login.clear(); self.new_name.clear(); self.current_username = user.username; self.refresh_users()


def main() -> int:
    app = QApplication(sys.argv); app.setApplicationName("SAI Admin"); app.setStyleSheet(ui_polish_stylesheet(False) + ADMIN_STYLE)
    service = AccountService(); login = AdminLoginDialog(service)
    if login.exec() != QDialog.Accepted: return 0
    window = AdminWindow(service); window.show(); return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
