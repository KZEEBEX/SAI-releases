#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations
import os,sys,tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve(); os.environ['SAI_USER_DATA_DIR']=tempfile.mkdtemp(prefix='sai_patch_z_'); sys.path.insert(0,str(root/'app'))
import sai_openai_invoice as m
assert m.CONTRACT_VERSION=='invoice_ai_contract_v5'
assert m.PROMPT_VERSION=='invoice_prompt_v5' and m.AUDIT_PROMPT_VERSION=='invoice_audit_prompt_v2'
assert m.build_invoice_schema()['title']=='SAI Invoice Extraction v5'
assert m.build_audit_schema()['title']=='SAI Material Invoice Audit v2'
doc={'supplier':'A','invoice_date':'2026-07-18','invoice_number':'1','currency':'RUB','document_total':20.0,'document_total_note':'','items':[{'source_row':1,'raw_name':'DOMTOK УДЛИНИТЕЛЬ','name':'DOMTOK УДЛИНИТЕЛЬ','quantity':2.0,'unit':'шт','purchase_price':10.0,'line_total':20.0,'article':'A1','barcodes':['4006381333931'],'confidence':0.9,'note':''}],'warnings':['нечёткий текст']}
audit={'checked_rows':[1],'corrections':[{'source_row':1,'status':'corrected','changed_fields':['article'],'raw_name':'DOMTOK УДЛИНИТЕЛЬ','article':'A2','barcodes':['4006381333931'],'quantity':2.0,'line_total':20.0,'note':''}]}
merged,changed,uncertain=m.apply_audit(doc,audit)
assert merged['items'][0]['article']=='A2' and changed=={1:['article']} and not uncertain
# Punctuation-only raw_name must not create a material change.
audit2={'checked_rows':[1],'corrections':[{'source_row':1,'status':'corrected','changed_fields':['raw_name'],'raw_name':'DOMTOK: УДЛИНИТЕЛЬ','article':'A2','barcodes':['4006381333931'],'quantity':2.0,'line_total':20.0,'note':''}]}
merged2,changed2,_=m.apply_audit(merged,audit2)
assert changed2=={}
compact=m._compact_audit_draft(doc)
assert set(compact['items'][0])=={'source_row','raw_name','article','barcodes','quantity','line_total'}
print('PATCH_Z_SELF_TEST_OK')
