#!/usr/bin/env python
# -*- coding: utf-8 -*-
from __future__ import annotations

import datetime as dt
import sys
import tempfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

from sai_core_v2.manual_receipt import (
    ManualReceiptRow,
    build_document,
    card_has_data,
    label_copies,
    merge_row,
    money_float,
    receipt_date_iso,
    round_sale_from_purchase,
    stable_rows_signature,
)
from sai_manual_receipt import ManualReceiptService
import sai_receipt_drafts


def test_price_policy() -> None:
    assert money_float("1 234,50 ₽") == 1234.5
    assert round_sale_from_purchase("5", "60") == 8.0
    assert round_sale_from_purchase("100", "60") == 160.0
    assert round_sale_from_purchase("101", "60") == 160.0
    assert round_sale_from_purchase("100", "-50") == 100.0


def test_validation_and_merge() -> None:
    invalid = ManualReceiptRow.from_values(name="", barcodes=[], qty=0, sale=0)
    assert invalid.validation_errors() == ("name", "qty", "sale")
    first = ManualReceiptRow.from_values(
        name="товар тест",
        barcodes=["4600000000001"],
        unit="штука",
        qty="2",
        sale="160",
        buy="100",
        product_id="p1",
    )
    assert first.valid and first.name == "ТОВАР ТЕСТ"
    rows, merged = merge_row([], first)
    assert not merged and rows[0]["qty"] == 2
    rows[0]["future_field"] = "keep"
    rows2, merged = merge_row(rows, first.with_qty(3))
    assert merged and rows2[0]["qty"] == 5
    assert rows2[0]["future_field"] == "keep"
    assert rows[0]["qty"] == 2, "merge must not mutate caller-owned rows"
    changed_price = ManualReceiptRow.from_values(
        name=first.name, barcodes=first.barcodes, unit=first.unit,
        qty=1, sale=170, buy=100, product_id="p1",
    )
    rows3, merged = merge_row(rows2, changed_price)
    assert not merged and len(rows3) == 2
    assert label_copies({"qty": "2,6"}) == 3


def test_draft_values_and_signature() -> None:
    assert not card_has_data({})
    assert card_has_data({"barcode_input": "12345"})
    rows = [{
        "name": "ТОВАР",
        "barcodes": ["12345"],
        "category": "",
        "unit": "штука",
        "qty": 2,
        "sale": 160,
        "buy": 100,
        "product_id": "p1",
    }]
    one = stable_rows_signature(
        supplier_id="s1", supplier_name="ООО ТЕСТ", date_text="22.07.2026", rows=rows,
    )
    two = stable_rows_signature(
        supplier_id="s1", supplier_name="ООО ТЕСТ", date_text="22.07.2026", rows=[dict(rows[0])],
    )
    assert one == two
    assert one != stable_rows_signature(
        supplier_id="s1", supplier_name="ООО ТЕСТ", date_text="22.07.2026",
        rows=[{**rows[0], "qty": 3}],
    )


def test_document_and_converter_adapter() -> None:
    rows = [
        {"name": "ТОВАР 1", "barcodes": ["11111"], "unit": "штука", "qty": 2, "sale": 160, "buy": 100},
        {"name": "ТОВАР 2", "barcodes": ["22222"], "unit": "м", "qty": 3, "sale": 80, "buy": 0},
    ]
    document = build_document(
        rows=rows,
        supplier="ООО ТЕСТ",
        date_text="22.07.2026",
        markup_percent=60,
        today=dt.date(2026, 7, 22),
    )
    assert document.date == "2026-07-22"
    assert document.items[0].purchase_price == 100
    assert document.items[1].purchase_price == 50
    result = ManualReceiptService.to_convert_result(document)
    assert result.source_type == "FreeReceipt"
    assert result.supplier == "ООО ТЕСТ"
    assert len(result.items) == 2
    assert result.items[1].barcodes == ["22222"]
    assert receipt_date_iso("broken", today=dt.date(2026, 7, 22)) == "2026-07-22"


def test_prepared_draft_routing() -> None:
    service = ManualReceiptService()
    old_drafts_dir = sai_receipt_drafts.DRAFTS_DIR
    old_autosave = sai_receipt_drafts.MANUAL_AUTOSAVE
    with tempfile.TemporaryDirectory() as temp_dir:
        root = Path(temp_dir)
        sai_receipt_drafts.DRAFTS_DIR = root / "drafts"
        sai_receipt_drafts.MANUAL_AUTOSAVE = root / "manual.json"
        try:
            complete = build_document(
                rows=[{"name": "ТОВАР", "barcodes": ["11111"], "unit": "штука", "qty": 1, "sale": 100}],
                supplier="ООО ТЕСТ",
                date_text="22.07.2026",
                markup_percent=60,
            )
            missing = build_document(
                rows=[{"name": "БЕЗ ШК", "barcodes": [], "unit": "штука", "qty": 1, "sale": 100}],
                supplier="ООО ТЕСТ",
                date_text="22.07.2026",
                markup_percent=60,
            )
            auto_meta = service.save_prepared_receipt(service.to_convert_result(complete))
            semi_meta = service.save_prepared_receipt(service.to_convert_result(missing))
            assert auto_meta["stage"] == "automatic"
            assert semi_meta["stage"] == "semi_auto"
            assert auto_meta["id"] != semi_meta["id"]
        finally:
            sai_receipt_drafts.DRAFTS_DIR = old_drafts_dir
            sai_receipt_drafts.MANUAL_AUTOSAVE = old_autosave


def test_boundaries() -> None:
    main_text = (APP_DIR / "sai_pyside_preview.py").read_text(encoding="utf-8-sig")
    service_text = (APP_DIR / "sai_manual_receipt.py").read_text(encoding="utf-8-sig")
    core_text = (APP_DIR / "sai_core_v2" / "manual_receipt.py").read_text(encoding="utf-8-sig")
    assert "from sai_manual_receipt import ManualReceiptService" in main_text
    assert "self.manual_service = ManualReceiptService()" in main_text
    assert "self.manual_service.save_prepared_receipt" in main_text
    assert 'QPushButton("Сохранить как черновик")' in main_text
    assert 'QPushButton("Ввести приход")' in main_text
    assert "def enter_free_receipt(self)" in main_text
    assert 'QPushButton("Товар без ШК ⇒ Создать ШК")' in main_text
    assert "start_new_manual_receipt_with_cooldown" in main_text
    assert "Добавленные товары:" in main_text
    assert "Позиция" not in main_text[main_text.index("class FreeReceiptPage"):main_text.index("class _SemiAutoMobileDashboardHandler")]
    assert "sai_receipt_drafts.save_result(" not in main_text[main_text.index("class FreeReceiptPage"):main_text.index("class _SemiAutoMobileDashboardHandler")]
    assert "PySide6" not in service_text
    assert "PySide6" not in core_text
    assert "sai_receipt_drafts" not in core_text
    assert "sai_converter" not in core_text


def main() -> int:
    test_price_policy()
    test_validation_and_merge()
    test_draft_values_and_signature()
    test_document_and_converter_adapter()
    test_prepared_draft_routing()
    test_boundaries()
    print("Manual receipt refactor tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
