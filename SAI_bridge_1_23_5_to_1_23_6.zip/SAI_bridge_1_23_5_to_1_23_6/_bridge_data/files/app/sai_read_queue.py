"""Cooperative, cross-process scheduling for read-only SIGMA requests.

Call from workers. Interactive reads take precedence over background reads
between requests, never by interrupting an in-flight request or replaying writes.
"""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import time
import uuid

from sai_runtime_paths import CACHE_DIR
from sai_sigma_session import ProcessLock, SessionUnavailable, atomic_json, read_json

INTERACTIVE = 0
REFERENCE = 10
ARCHIVE = 20
MAX_CONCURRENT_READS = 4


class ReadQueue:
    def __init__(self, directory: Path | None = None, *, capacity: int = MAX_CONCURRENT_READS):
        self.directory = Path(directory or CACHE_DIR / "sigma_read_queue")
        self.capacity = max(1, min(12, int(capacity)))

    @contextmanager
    def slot(self, priority: int = REFERENCE, *, timeout: float = 120):
        started = time.time()
        ticket = self.directory / (uuid.uuid4().hex + ".json")
        atomic_json(ticket, {"priority": int(priority), "created": started, "expires": started + timeout})
        acquired = None
        try:
            while acquired is None:
                now = time.time()
                if now >= started + timeout:
                    raise SessionUnavailable("Очередь чтения SIGMA занята. Повторите обновление позже.")
                try:
                    with ProcessLock(self.directory / "dispatch.lock", timeout=0):
                        waiting = []
                        for path in self.directory.glob("*.json"):
                            item = read_json(path)
                            try:
                                expires = float(item["expires"])
                                # Ageing prevents permanent starvation of archive reads.
                                rank = int(item["priority"]) - int(max(0, now - float(item["created"])) / 2)
                                created = float(item["created"])
                            except (KeyError, TypeError, ValueError):
                                expires, rank, created = 0, 0, 0
                            if expires <= now:
                                path.unlink(missing_ok=True)
                            else:
                                waiting.append((rank, created, path.name))
                        if waiting and min(waiting)[2] == ticket.name:
                            for index in range(self.capacity):
                                candidate = ProcessLock(self.directory / f"slot-{index}.lock", timeout=0)
                                try:
                                    candidate.__enter__()
                                except SessionUnavailable:
                                    continue
                                acquired = candidate
                                ticket.unlink(missing_ok=True)
                                break
                except SessionUnavailable:
                    pass
                if acquired is None:
                    time.sleep(.025)
            yield
        finally:
            if acquired is not None:
                acquired.__exit__(None, None, None)
            ticket.unlink(missing_ok=True)


def read_slot(priority: int = REFERENCE):
    return ReadQueue().slot(priority)
