@echo off
setlocal
cd /d "%~dp0"
if not exist "app\.venv\Scripts\pythonw.exe" goto missing
start "" "app\.venv\Scripts\pythonw.exe" "app\sai_launcher.py"
exit /b 0

:missing
echo SAI is not installed. Run INSTALL_SAI.cmd first.
echo.
pause
exit /b 2
