@echo off
setlocal
cd /d "%~dp0"
title SAI Full Setup
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONUTF8=1"

echo ==============================================================================
echo SAI FULL SETUP FOR A NEW WINDOWS PC
echo ==============================================================================
echo.
echo Python, application libraries and Chromium are already included.
echo Internet access is not required.
echo Keep this window open until setup is complete.
echo.

if not exist "_offline\python\python.exe" goto missing
if not exist "install_offline.py" goto missing

"_offline\python\python.exe" "install_offline.py"
set "EXIT_CODE=%ERRORLEVEL%"
echo.
if "%EXIT_CODE%"=="0" goto success

echo ==============================================================================
echo ERROR: SAI WAS NOT INSTALLED.
echo Send SAI_INSTALL_LAST_LOG.txt to the developer.
echo ==============================================================================
if exist "SAI_INSTALL_LAST_LOG.txt" start "" notepad.exe "SAI_INSTALL_LAST_LOG.txt"
echo.
if "%SAI_SETUP_NO_PAUSE%"=="1" exit /b %EXIT_CODE%
pause
exit /b %EXIT_CODE%

:success
echo ==============================================================================
echo SUCCESS: SAI IS INSTALLED AND VERIFIED.
echo Use START_SAI.cmd to launch the application.
echo ==============================================================================
echo.
if "%SAI_SETUP_NO_PAUSE%"=="1" exit /b 0
pause
exit /b 0

:missing
echo ERROR: The ZIP archive was not extracted completely.
echo Extract the entire SAI folder and run INSTALL_SAI.cmd again.
echo.
if "%SAI_SETUP_NO_PAUSE%"=="1" exit /b 2
pause
exit /b 2
