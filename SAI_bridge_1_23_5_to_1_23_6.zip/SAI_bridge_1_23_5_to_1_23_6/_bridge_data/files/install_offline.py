#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Install SAI from a self-contained Windows x64 release folder."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
OFFLINE = ROOT / "_offline"
RUNTIME_PYTHON = OFFLINE / "python" / "python.exe"
WHEELHOUSE = OFFLINE / "wheelhouse"
BROWSERS = OFFLINE / "ms-playwright"
VENV = APP / ".venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"
LOG_PATH = ROOT / "SAI_INSTALL_LAST_LOG.txt"
MANIFEST_PATH = OFFLINE / "RELEASE_MANIFEST.json"
LOCKED_REQUIREMENTS = OFFLINE / "requirements-offline.txt"


class InstallError(RuntimeError):
    pass


def log(message: object = "") -> None:
    text = str(message)
    print(text, flush=True)
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(text + "\n")


def run(command: list[str], *, cwd: Path = ROOT, env: dict[str, str] | None = None) -> None:
    safe = [str(part) for part in command]
    log("  > " + " ".join(f'"{part}"' if " " in part else part for part in safe))
    process = subprocess.Popen(
        safe,
        cwd=str(cwd),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert process.stdout is not None
    for line in process.stdout:
        log("    " + line.rstrip())
    code = process.wait()
    if code:
        raise InstallError(f"Команда завершилась с кодом {code}: {safe[0]}")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_bundle() -> dict:
    if platform.system() != "Windows" or platform.machine().lower() not in {"amd64", "x86_64"}:
        raise InstallError("Этот комплект предназначен для Windows x64.")
    for path in (RUNTIME_PYTHON, LOCKED_REQUIREMENTS, MANIFEST_PATH):
        if not path.is_file():
            raise InstallError(f"Не найден обязательный файл: {path.relative_to(ROOT)}")
    if not WHEELHOUSE.is_dir() or not any(WHEELHOUSE.glob("*.whl")):
        raise InstallError("Не найден офлайн-набор Python-пакетов.")
    if not (BROWSERS / "chromium-1129" / "INSTALLATION_COMPLETE").is_file():
        raise InstallError("Не найден встроенный Chromium для Playwright 1.46.")
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    checked = 0
    for item in manifest.get("files", []):
        relative = str(item.get("path") or "")
        if relative == "_offline/RELEASE_MANIFEST.json":
            continue
        path = ROOT / Path(relative)
        if not path.is_file():
            raise InstallError(f"Архив повреждён: отсутствует {relative}")
        expected_size = item.get("size")
        if expected_size is None or int(expected_size) != path.stat().st_size or str(item.get("sha256")) != sha256(path):
            raise InstallError(f"Архив повреждён: контрольная сумма не совпала для {relative}")
        checked += 1
    log(f"  Целостность архива: OK, файлов проверено: {checked}")
    return manifest


def prepare_user_data() -> None:
    user_data = ROOT / "user_data"
    (user_data / "backups").mkdir(parents=True, exist_ok=True)
    (user_data / "logs").mkdir(parents=True, exist_ok=True)
    copies = (
        (APP / "sai_private_config.example.json", user_data / "sai_private_config.json"),
        (APP / "sai_config.example.json", user_data / "sai_config.json"),
    )
    for source, target in copies:
        if not target.exists() and source.is_file():
            shutil.copy2(source, target)


def install_venv() -> Path | None:
    backup: Path | None = None
    if VENV.exists():
        stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup = APP / f".venv_before_offline_install_{stamp}"
        VENV.replace(backup)
        log(f"  Существующая .venv сохранена: {backup.name}")
    try:
        run([str(RUNTIME_PYTHON), "-m", "venv", str(VENV)])
        if not VENV_PYTHON.is_file():
            raise InstallError("Python не создал app\\.venv.")
        run([
            str(VENV_PYTHON), "-m", "pip", "install",
            "--no-index", "--disable-pip-version-check",
            "--find-links", str(WHEELHOUSE),
            "-r", str(LOCKED_REQUIREMENTS),
        ])
        return backup
    except Exception:
        shutil.rmtree(VENV, ignore_errors=True)
        if backup and backup.exists():
            backup.replace(VENV)
        raise


def install_ready_autostart(env: dict[str, str]) -> None:
    code = (
        "from pathlib import Path; "
        "from sai_ready_autostart import install_autostart; "
        f"p=install_autostart(Path({str(ROOT)!r})); "
        "print('SAI Ready:', p or 'not available')"
    )
    run([str(VENV_PYTHON), "-c", code], cwd=APP, env=env)


def write_installed_build(manifest: dict) -> None:
    from_version = str(manifest.get("version") or "")
    payload = {
        "version": from_version,
        "build_id": str(manifest.get("build_id") or ""),
        "installation": "full-offline-windows-x64",
        "installed_at": dt.datetime.now().astimezone().isoformat(),
        "python": "3.12.10 x64 bundled",
        "acceptance": "INSTALL SMOKE PASSED",
    }
    target = ROOT / "user_data" / "installed_build.json"
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    LOG_PATH.write_text(
        "SAI full offline installation log\n"
        + dt.datetime.now().astimezone().isoformat()
        + "\n"
        + "=" * 78
        + "\n",
        encoding="utf-8",
    )
    backup: Path | None = None
    try:
        log("[1/6] Проверяю комплект и контрольные суммы...")
        manifest = validate_bundle()
        log("[2/6] Создаю чистую app\\.venv встроенным Python 3.12 x64...")
        backup = install_venv()
        prepare_user_data()
        env = os.environ.copy()
        env["PYTHONUTF8"] = "1"
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["QT_QPA_PLATFORM"] = "offscreen"
        env["PLAYWRIGHT_BROWSERS_PATH"] = str(BROWSERS)
        log("[3/6] Проверяю Python, Qt и встроенный Chromium...")
        run([
            str(VENV_PYTHON), "-c",
            "import PySide6,openpyxl,requests; from playwright.sync_api import sync_playwright; "
            "p=sync_playwright().start(); b=p.chromium.launch(headless=True); "
            "print('Python/Qt/Chromium: OK'); b.close(); p.stop()",
        ], cwd=APP, env=env)
        log("[4/6] Проверяю запуск текущей версии SAI...")
        run([
            str(VENV_PYTHON), str(APP / "sai_launcher.py"), "--check", "--console",
        ], cwd=APP, env=env)
        log("[5/6] Подключаю фоновую подготовку каталога при входе в Windows...")
        if os.environ.get("SAI_OFFLINE_VERIFY_ONLY") == "1":
            log("Проверочный режим: автозапуск Windows не изменяется.")
        else:
            install_ready_autostart(env)
        log("[6/6] Фиксирую установленную сборку...")
        write_installed_build(manifest)
        if backup and backup.exists():
            shutil.rmtree(backup, ignore_errors=True)
        log("")
        log("SUCCESS: SAI установлен полностью и готов к запуску.")
        log('Запуск: "START_SAI.cmd"')
        return 0
    except Exception as exc:
        if backup and backup.exists():
            shutil.rmtree(VENV, ignore_errors=True)
            backup.replace(VENV)
            log("Предыдущая .venv восстановлена.")
        elif VENV.exists():
            shutil.rmtree(VENV, ignore_errors=True)
        log("")
        log("ERROR: " + str(exc))
        log(traceback.format_exc())
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
