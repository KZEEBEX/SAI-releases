#!/usr/bin/env python
"""Build a clean SAI release with Python and automatic online dependencies."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
sys.path.insert(0, str(APP))
from sai_version import APP_VERSION, BUILD_ID, VERSION  # noqa: E402

STAGING_PARENT = ROOT / "_deployment_staging" / "online_release"
STAGING_ROOT = STAGING_PARENT / "SAI"
ZIP_PATH = ROOT.parent / f"SAI_{VERSION}_EASY_SETUP_WINDOWS_X64.zip"
BASE_PYTHON = Path(sys.base_prefix)

EXCLUDED_DIRS = {
    ".git", ".venv", "__pycache__", ".pytest_cache", "user_data",
    "_deployment_staging", "Sai logo history", "Profile", "cache", "logs",
    "backups", "_backups", "_patch_backups", "_offline", "_runtime",
}
EXCLUDED_FILES = {
    ".gitignore", "make_release.py", "make_release.cmd",
    "make_offline_release.py", "make_offline_release.cmd",
    "make_online_release.py", "make_online_release.cmd",
    "INSTALL_SAI_OFFLINE.cmd", "install_offline.py",
    "README_НОВЫЙ_КОМПЬЮТЕР.txt",
    "SAI_RECEIPT_READINESS_LAST_LOG.txt", "SAI_INSTALL_LAST_LOG.txt",
    "SAI_SETUP_LAST_LOG.txt", "SAI_PATCH_LAST_LOG.txt", "app/install.cmd",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".7z"}


def excluded(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return True
    if relative.as_posix() in EXCLUDED_FILES or path.name in EXCLUDED_FILES:
        return True
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if path.name.startswith(("acceptance_report", "sai_crash_", "sai_doctor_")):
        return True
    return False


def copy_clean_source() -> None:
    if STAGING_PARENT.exists():
        shutil.rmtree(STAGING_PARENT)
    STAGING_ROOT.mkdir(parents=True)
    for source in ROOT.rglob("*"):
        if excluded(source):
            continue
        target = STAGING_ROOT / source.relative_to(ROOT)
        if source.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif source.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def add_python() -> None:
    if not (BASE_PYTHON / "python.exe").is_file():
        raise RuntimeError(f"Bundled Python was not found: {BASE_PYTHON}")
    shutil.copytree(
        BASE_PYTHON,
        STAGING_ROOT / "_runtime" / "python",
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_manifest() -> None:
    manifest_path = STAGING_ROOT / "_runtime" / "RELEASE_MANIFEST.json"
    files = []
    for path in sorted(STAGING_ROOT.rglob("*")):
        if not path.is_file() or path == manifest_path:
            continue
        files.append({
            "path": path.relative_to(STAGING_ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256(path),
        })
    payload = {
        "format": 1,
        "version": APP_VERSION,
        "build_id": BUILD_ID,
        "platform": "Windows x64",
        "python": "3.12.10 x64 bundled",
        "dependency_source": "PyPI and Playwright CDN",
        "files": files,
    }
    manifest_path.write_text(json.dumps(payload, ensure_ascii=True, indent=2), encoding="ascii")


def validate_clean_tree() -> None:
    forbidden = []
    for path in STAGING_ROOT.rglob("*"):
        relative = path.relative_to(STAGING_ROOT)
        if any(part in {".git", ".venv", "user_data", "Profile"} for part in relative.parts):
            forbidden.append(relative.as_posix())
        if path.name in {"sai_private_config.json", "sai.db", "Cookies", "Login Data", "Local State"}:
            forbidden.append(relative.as_posix())
    if forbidden:
        raise RuntimeError("Private or local files found:\n" + "\n".join(forbidden[:30]))
    for path in (
        STAGING_ROOT / "INSTALL_SAI.cmd",
        STAGING_ROOT / "START_SAI.cmd",
        STAGING_ROOT / "install_sai.py",
        STAGING_ROOT / "requirements-online.txt",
        STAGING_ROOT / "_runtime" / "python" / "python.exe",
        STAGING_ROOT / "_runtime" / "RELEASE_MANIFEST.json",
    ):
        if not path.exists():
            raise RuntimeError(f"Release file is missing: {path.relative_to(STAGING_ROOT)}")
    for name in ("INSTALL_SAI.cmd", "START_SAI.cmd"):
        data = (STAGING_ROOT / name).read_bytes()
        data.decode("ascii")
        if b"\n" in data.replace(b"\r\n", b""):
            raise RuntimeError(f"{name} must use Windows CRLF line endings.")


def run_acceptance() -> None:
    with tempfile.TemporaryDirectory(prefix="sai_online_release_acceptance_") as temp:
        env = os.environ.copy()
        env["QT_QPA_PLATFORM"] = "offscreen"
        env["SAI_USER_DATA_DIR"] = str(Path(temp) / "user_data")
        subprocess.run([
            sys.executable, str(APP / "run_patch_acceptance.py"),
            "--root", str(ROOT), "--python", sys.executable,
        ], cwd=APP, env=env, check=True)


def zip_release() -> None:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(STAGING_ROOT.rglob("*")):
            if path.is_file():
                archive.write(path, (Path("SAI") / path.relative_to(STAGING_ROOT)).as_posix())
    with zipfile.ZipFile(ZIP_PATH) as archive:
        roots = {name.split("/", 1)[0] for name in archive.namelist() if name}
        if roots != {"SAI"}:
            raise RuntimeError(f"ZIP must contain one SAI folder, found: {sorted(roots)}")
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"Corrupt ZIP member: {bad}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-tests", action="store_true")
    args = parser.parse_args()
    print(f"Building SAI {APP_VERSION} easy Windows setup...")
    if not args.skip_tests:
        run_acceptance()
    copy_clean_source()
    add_python()
    write_manifest()
    validate_clean_tree()
    zip_release()
    print(f"Ready: {ZIP_PATH}")
    print(f"Size: {ZIP_PATH.stat().st_size / 1024 / 1024:.1f} MB")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
