@echo off
setlocal
cd /d "%~dp0"
"app\.venv\Scripts\python.exe" "make_offline_release.py"
set "CODE=%ERRORLEVEL%"
echo.
pause
exit /b %CODE%
