@echo off
chcp 65001 >nul
cd /d "%~dp0\app"
call run_sai_doctor.cmd
