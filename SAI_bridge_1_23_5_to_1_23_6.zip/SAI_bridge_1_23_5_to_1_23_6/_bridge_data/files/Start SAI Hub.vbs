Option Explicit
Dim Shell, FSO, RootDir, AppDir, PythonW, Launcher, Command
Set Shell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")
RootDir = FSO.GetParentFolderName(WScript.ScriptFullName)
AppDir = RootDir & "\app"
PythonW = AppDir & "\.venv\Scripts\pythonw.exe"
Launcher = AppDir & "\sai_launcher.py"
If Not FSO.FileExists(PythonW) Then
    MsgBox "SAI is not installed. Run app\install.cmd.", vbExclamation, "SAI Hub"
    WScript.Quit 1
End If
If Not FSO.FileExists(Launcher) Then
    MsgBox "SAI launcher is missing. Re-apply the patch.", vbCritical, "SAI Hub"
    WScript.Quit 1
End If
Shell.CurrentDirectory = AppDir
Command = Chr(34) & PythonW & Chr(34) & " " & Chr(34) & Launcher & Chr(34)
Shell.Run Command, 0, False
