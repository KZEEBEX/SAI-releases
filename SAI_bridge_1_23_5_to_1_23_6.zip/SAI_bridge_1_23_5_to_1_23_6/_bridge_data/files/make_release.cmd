@echo off
setlocal
cd /d "%~dp0"
if exist "app\.venv\Scripts\python.exe" goto use_venv
py -3 make_release.py
goto after
:use_venv
"app\.venv\Scripts\python.exe" make_release.py
:after
if errorlevel 1 goto failed
pause
exit /b 0
:failed
echo Release build failed.
pause
exit /b 1
