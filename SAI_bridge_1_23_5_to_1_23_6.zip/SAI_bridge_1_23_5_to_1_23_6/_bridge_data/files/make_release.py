#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Build a tested and secret-free SAI release archive."""
from __future__ import annotations

import ast
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APP_DIR = ROOT / "app"
sys.path.insert(0, str(APP_DIR))
from sai_version import APP_VERSION  # noqa: E402

RELEASE_NAME = f"SAI_{APP_VERSION}_clean"
OUT_DIR = ROOT.parent / RELEASE_NAME
ZIP_PATH = ROOT.parent / f"{RELEASE_NAME}.zip"
if OUT_DIR.resolve() == ROOT.resolve():
    OUT_DIR = ROOT.parent / f"{RELEASE_NAME}_build"

EXCLUDE_DIR_NAMES = {
    ".venv", "__pycache__", ".pytest_cache", "Profile", "user_data",
    "cache", "logs", "backups", "_backups", "_patch_backups",
    "test-results", "playwright-report", "_sai_patch_payload",
}
EXCLUDE_FILE_NAMES = {
    "sai_private_config.json", "sai_config.json", "sai.db", "sai.db-shm",
    "sai.db-wal", "app_config.json", "api_probe_results.json",
    "api_products_sample.json", "Untitled.png",
    "Задание_для_ChatGPT_SAI_XML_v1.txt",
    "SAI_cleanup_patch.py", "Применить патч SAI.cmd", "README_ПАТЧ.txt",
}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp"}
GENERATED_PREFIXES = (
    "Накладная_для_продавцов_", "Накладная_на_согласование_", "Накладная_согласованная_", "Импорт_", "price_audit_",
    "sigma_api_first_", "sai_doctor_", "sai_crash_",
)
FORBIDDEN_RELEASE_NAMES = {
    "Cookies", "Login Data", "Local State", "History",
    "sai_private_config.json", "sai.db", "sigma_runtime_token.json",
}


def should_exclude(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    parts = rel.parts
    if parts[:2] == ("app", "app"):
        return True
    if any(part in EXCLUDE_DIR_NAMES for part in parts):
        return True
    if path.name in EXCLUDE_FILE_NAMES:
        return True
    if path.suffix.lower() in EXCLUDE_SUFFIXES:
        return True
    if path.name.startswith(GENERATED_PREFIXES):
        return True
    return False


def run_preflight() -> None:
    for source in ROOT.rglob("*.py"):
        if should_exclude(source):
            continue
        ast.parse(source.read_text(encoding="utf-8-sig"), filename=str(source))
    with tempfile.TemporaryDirectory(prefix="sai_release_test_") as td:
        env = os.environ.copy()
        env["SAI_USER_DATA_DIR"] = str(Path(td) / "user_data")
        subprocess.run([sys.executable, str(APP_DIR / "run_self_tests.py")], cwd=APP_DIR, env=env, check=True)
        subprocess.run(
            [sys.executable, str(APP_DIR / "sai_launcher.py"), "--check", "--console"],
            cwd=APP_DIR,
            env=env,
            check=True,
        )


def copy_clean_tree() -> None:
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    OUT_DIR.mkdir(parents=True)
    for src in ROOT.rglob("*"):
        if should_exclude(src):
            continue
        rel = src.relative_to(ROOT)
        dst = OUT_DIR / rel
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def validate_release_tree() -> None:
    problems = []
    for path in OUT_DIR.rglob("*"):
        rel = path.relative_to(OUT_DIR)
        if "user_data" in rel.parts or "Profile" in rel.parts:
            problems.append(str(rel))
        if path.name in FORBIDDEN_RELEASE_NAMES:
            problems.append(str(rel))
        if rel.parts[:2] == ("app", "app"):
            problems.append(str(rel))
    if problems:
        preview = "\n".join(f"- {item}" for item in problems[:30])
        raise RuntimeError(f"Сборка содержит запрещённые данные:\n{preview}")


def zip_clean_tree() -> None:
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for src in sorted(OUT_DIR.rglob("*")):
            if src.is_file():
                zf.write(src, src.relative_to(OUT_DIR))


def main() -> None:
    print(f"Проверяю SAI {APP_VERSION}...")
    run_preflight()
    copy_clean_tree()
    validate_release_tree()
    zip_clean_tree()
    size_mb = ZIP_PATH.stat().st_size / 1024 / 1024
    print(f"Создано: {ZIP_PATH}")
    print(f"Размер: {size_mb:.2f} МБ")
    print("Пользовательские данные, токены, профиль браузера, кэш и старая копия app/app исключены.")


if __name__ == "__main__":
    main()
