#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Build the tiny one-time GitHub bootstrap patch for SAI 1.23.1."""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent
APP = ROOT / "app"
OUTPUT = ROOT / "_deployment_staging" / "github_bootstrap"
PACKAGE = OUTPUT / "SAI_GITHUB_BOOTSTRAP_V2_FOR_1.23.1"
DATA = PACKAGE / "_bootstrap_data"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    shutil.rmtree(OUTPUT, ignore_errors=True)
    DATA.mkdir(parents=True)
    files = []
    for name in ("sai_github_updates.py", "sai_github_bootstrap.py"):
        target = DATA / name
        shutil.copy2(APP / name, target)
        files.append({"name": name, "size": target.stat().st_size, "sha256": sha256(target)})
    (DATA / "manifest.json").write_text(json.dumps({
        "schema_version": 1,
        "source_version": "1.23.1",
        "repository": "KZEEBEX/SAI-releases",
        "files": files,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    shutil.copy2(APP / "install_github_bootstrap_patch.py", PACKAGE / "install_bootstrap.py")
    cmd = """@echo off\r
setlocal\r
cd /d "%~dp0"\r
title SAI GitHub Bootstrap\r
set "TARGET=%~dp0.."\r
set "PY=%TARGET%\\app\\.venv\\Scripts\\python.exe"\r
if not exist "%PY%" goto missing\r
echo Close SAI before installing this small update.\r
echo Target: %TARGET%\r
pause\r
"%PY%" "%~dp0install_bootstrap.py" --target "%TARGET%"\r
set "RC=%ERRORLEVEL%"\r
if "%RC%"=="0" goto ok\r
if exist "%~dp0SAI_GITHUB_BOOTSTRAP_LAST_LOG.txt" start "" notepad.exe "%~dp0SAI_GITHUB_BOOTSTRAP_LAST_LOG.txt"\r
pause\r
exit /b %RC%\r
:ok\r
echo GitHub updates are connected. Start SAI normally.\r
pause\r
exit /b 0\r
:missing\r
echo Put this whole folder directly inside the existing SAI folder.\r
pause\r
exit /b 2\r
"""
    (PACKAGE / "INSTALL_GITHUB_BOOTSTRAP.cmd").write_bytes(cmd.encode("ascii"))
    (PACKAGE / "README.txt").write_text(
        "1. Close SAI.\n2. Copy this whole folder inside the existing SAI 1.23.1 folder.\n"
        "3. Run INSTALL_GITHUB_BOOTSTRAP.cmd.\n\nRepository: KZEEBEX/SAI-releases\n",
        encoding="utf-8",
    )
    archive = OUTPUT / "SAI_GITHUB_BOOTSTRAP_V2_FOR_1.23.1.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for path in sorted(PACKAGE.rglob("*")):
            if path.is_file():
                target.write(path, (Path(PACKAGE.name) / path.relative_to(PACKAGE)).as_posix())
    print(PACKAGE)
    print(archive)
    print(f"Size: {archive.stat().st_size / 1024:.1f} KB")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
