from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Iterable

from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import (
    QApplication,
    QDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QStackedWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


DEMO_VERSION = "0.1.0"


@dataclass(frozen=True)
class DemoProduct:
    article: str
    name: str
    barcode: str
    price: int
    stock: int
    category: str


def build_demo_catalog() -> list[DemoProduct]:
    products = [
        ("Крепёж", "Саморез универсальный", 129, 184),
        ("Крепёж", "Дюбель распорный", 95, 266),
        ("Инструмент", "Отвёртка крестовая", 349, 42),
        ("Инструмент", "Рулетка строительная", 590, 31),
        ("Электрика", "Лампа светодиодная", 219, 76),
        ("Электрика", "Удлинитель бытовой", 890, 18),
        ("Сантехника", "Лента уплотнительная", 89, 120),
        ("Сантехника", "Шланг гибкий", 449, 37),
        ("Хозтовары", "Перчатки рабочие", 159, 93),
        ("Хозтовары", "Пакеты для мусора", 199, 64),
        ("Малярные товары", "Кисть плоская", 179, 51),
        ("Малярные товары", "Валик малярный", 289, 28),
    ]
    result: list[DemoProduct] = []
    for group_index, (category, base_name, base_price, base_stock) in enumerate(products, 1):
        for variant in range(1, 9):
            number = group_index * 100 + variant
            body = f"2900000{number:05d}"
            check = (10 - sum((3 if index % 2 else 1) * int(char) for index, char in enumerate(body)) % 10) % 10
            result.append(
                DemoProduct(
                    article=f"SAI-{number:04d}",
                    name=f"{base_name} · вариант {variant}",
                    barcode=f"{body}{check}",
                    price=base_price + (variant - 1) * 15,
                    stock=max(0, base_stock - variant * 3),
                    category=category,
                )
            )
    return result


CATALOG = build_demo_catalog()


APP_STYLE = """
* {
    font-family: "Segoe UI";
    font-size: 13px;
    color: #0f172a;
}
QMainWindow, QWidget#Root, QStackedWidget {
    background: #f5f7fb;
}
QFrame#Sidebar {
    background: #0f172a;
    border: none;
}
QLabel#Brand {
    color: #ffffff;
    font-size: 30px;
    font-weight: 900;
}
QLabel#DemoPill {
    color: #bfdbfe;
    background: #1e3a8a;
    border: 1px solid #2563eb;
    border-radius: 10px;
    padding: 4px 9px;
    font-size: 11px;
    font-weight: 800;
}
QPushButton#NavButton {
    color: #e2e8f0;
    background: transparent;
    border: 1px solid transparent;
    border-radius: 12px;
    padding: 11px 14px;
    text-align: left;
    font-weight: 700;
}
QPushButton#NavButton:hover {
    background: #1e293b;
}
QPushButton#NavButton:checked {
    color: #ffffff;
    background: #273449;
    border-color: #334155;
}
QLabel#Version {
    color: #94a3b8;
    font-size: 10px;
}
QLabel#PageTitle {
    color: #0f172a;
    font-size: 28px;
    font-weight: 900;
}
QLabel#PageSubtitle {
    color: #64748b;
    font-size: 14px;
}
QLabel#CardTitle {
    color: #172033;
    font-size: 16px;
    font-weight: 800;
}
QLabel#MetricValue {
    color: #0f172a;
    font-size: 23px;
    font-weight: 900;
}
QLabel#Muted {
    color: #64748b;
    font-size: 12px;
}
QLabel#Success {
    color: #166534;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 11px;
    padding: 10px 12px;
    font-weight: 700;
}
QLabel#Info {
    color: #1d4ed8;
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 11px;
    padding: 10px 12px;
    font-weight: 700;
}
QFrame#Card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 18px;
}
QFrame#Hero {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 20px;
}
QPushButton#Primary {
    color: #ffffff;
    background: #2563eb;
    border: 1px solid #1d4ed8;
    border-radius: 13px;
    min-height: 44px;
    padding: 0 22px;
    font-size: 14px;
    font-weight: 800;
}
QPushButton#Primary:hover {
    background: #1d4ed8;
}
QPushButton#Primary:pressed {
    background: #1e40af;
}
QPushButton#Primary:disabled {
    color: #eff6ff;
    background: #bfdbfe;
    border-color: #bfdbfe;
}
QPushButton#Secondary {
    color: #111827;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 12px;
    min-height: 40px;
    padding: 0 16px;
    font-weight: 700;
}
QPushButton#Secondary:hover {
    background: #f8fafc;
    border-color: #94a3b8;
}
QLineEdit {
    color: #0f172a;
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 11px;
    min-height: 42px;
    padding: 0 11px;
    selection-background-color: #dbeafe;
}
QLineEdit:focus {
    border-color: #2563eb;
}
QTableWidget {
    background: #ffffff;
    alternate-background-color: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    gridline-color: transparent;
    selection-background-color: #dbeafe;
    selection-color: #0f172a;
}
QHeaderView::section {
    color: #475569;
    background: #f8fafc;
    border: none;
    border-bottom: 1px solid #e2e8f0;
    padding: 8px;
    font-weight: 700;
}
QTableWidget::item {
    border-bottom: 1px solid #f1f5f9;
    padding: 7px;
}
QProgressBar {
    color: #1e3a8a;
    background: #f1f5f9;
    border: 1px solid #dbe4f0;
    border-radius: 8px;
    min-height: 22px;
    text-align: center;
    font-weight: 700;
}
QProgressBar::chunk {
    background: #60a5fa;
    border-radius: 7px;
}
"""


def card() -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("Card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(20, 18, 20, 18)
    layout.setSpacing(12)
    return frame, layout


def label(text: str, object_name: str | None = None) -> QLabel:
    widget = QLabel(text)
    if object_name:
        widget.setObjectName(object_name)
    widget.setWordWrap(True)
    return widget


def page_header(title: str, subtitle: str) -> tuple[QWidget, QVBoxLayout]:
    page = QWidget()
    layout = QVBoxLayout(page)
    layout.setContentsMargins(28, 24, 28, 28)
    layout.setSpacing(16)
    layout.addWidget(label(title, "PageTitle"))
    layout.addWidget(label(subtitle, "PageSubtitle"))
    return page, layout


def configure_table(table: QTableWidget, stretch_column: int = 1) -> None:
    table.setAlternatingRowColors(True)
    table.setSelectionBehavior(QTableWidget.SelectRows)
    table.setEditTriggers(QTableWidget.NoEditTriggers)
    table.verticalHeader().setVisible(False)
    table.verticalHeader().setDefaultSectionSize(38)
    header = table.horizontalHeader()
    header.setSectionResizeMode(QHeaderView.ResizeToContents)
    header.setSectionResizeMode(stretch_column, QHeaderView.Stretch)


class OverviewPage(QWidget):
    def __init__(self, navigate) -> None:
        super().__init__()
        page, layout = page_header(
            "Обзор",
            "Познакомьтесь с основными рабочими сценариями SAI на безопасных демонстрационных данных.",
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(page)

        hero = QFrame()
        hero.setObjectName("Hero")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(26, 24, 26, 24)
        copy = QVBoxLayout()
        copy.setSpacing(7)
        title = label("Спокойное управление магазином", "CardTitle")
        title.setStyleSheet("font-size: 24px;")
        copy.addWidget(title)
        copy.addWidget(
            label(
                "Принимайте товары, находите остатки, собирайте ценники и оценивайте показатели — всё в одном понятном интерфейсе.",
                "Muted",
            )
        )
        hero_layout.addLayout(copy, 1)
        start = QPushButton("Открыть приёмку")
        start.setObjectName("Primary")
        start.clicked.connect(lambda: navigate(1))
        hero_layout.addWidget(start)
        layout.addWidget(hero)

        metrics = QHBoxLayout()
        metrics.setSpacing(14)
        for title_text, value, detail in (
            ("Товаров", "96", "в демо-каталоге"),
            ("В наличии", "83", "товарные позиции"),
            ("Низкий остаток", "7", "требуют внимания"),
            ("Сегодня", "₽ 38 450", "демо-оборот"),
        ):
            frame, frame_layout = card()
            frame_layout.addWidget(label(title_text, "Muted"))
            frame_layout.addWidget(label(value, "MetricValue"))
            frame_layout.addWidget(label(detail, "Muted"))
            metrics.addWidget(frame)
        layout.addLayout(metrics)

        modules = QHBoxLayout()
        modules.setSpacing(14)
        for title_text, description, index in (
            ("Склад", "Быстрый поиск по всему каталогу и контроль остатков.", 2),
            ("Ценники", "Соберите список товаров и подготовьте единый макет.", 3),
            ("Аналитика", "Ключевые показатели магазина без лишнего шума.", 4),
        ):
            frame, frame_layout = card()
            frame_layout.addWidget(label(title_text, "CardTitle"))
            frame_layout.addWidget(label(description, "Muted"))
            button = QPushButton("Открыть")
            button.setObjectName("Secondary")
            button.clicked.connect(lambda _checked=False, target=index: navigate(target))
            frame_layout.addWidget(button)
            modules.addWidget(frame)
        layout.addLayout(modules)
        layout.addStretch()


class ReceiptPage(QWidget):
    STAGES = (
        ("Проверяю накладную", 20),
        ("Сопоставляю товары", 45),
        ("Проверяю количества и цены", 70),
        ("Формирую результат", 90),
        ("Приёмка готова", 100),
    )

    def __init__(self) -> None:
        super().__init__()
        page, layout = page_header(
            "Приёмка",
            "Посмотрите полный демонстрационный цикл обработки накладной без изменения реальных данных.",
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(page)

        flow, flow_layout = card()
        flow_layout.addWidget(label("Демонстрационная накладная № 1042", "CardTitle"))
        flow_layout.addWidget(label("5 товарных позиций · 37 единиц · сумма закупки ₽ 9 785", "Muted"))
        self.status = label("Готово к запуску", "Info")
        flow_layout.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setFormat("Ожидание запуска")
        flow_layout.addWidget(self.progress)
        actions = QHBoxLayout()
        self.start_button = QPushButton("Запустить демонстрацию")
        self.start_button.setObjectName("Primary")
        self.start_button.clicked.connect(self.start_flow)
        actions.addWidget(self.start_button)
        reset = QPushButton("Сбросить")
        reset.setObjectName("Secondary")
        reset.clicked.connect(self.reset_flow)
        actions.addWidget(reset)
        actions.addStretch()
        flow_layout.addLayout(actions)
        layout.addWidget(flow)

        table_card, table_layout = card()
        table_layout.addWidget(label("Товары", "CardTitle"))
        self.table = QTableWidget(5, 5)
        self.table.setHorizontalHeaderLabels(["Товар", "ШК", "Кол-во", "Закупка", "Статус"])
        configure_table(self.table, 0)
        for row, product in enumerate(CATALOG[:5]):
            values = (product.name, product.barcode, str(row + 2), f"{product.price} ₽", "Готов")
            for column, value in enumerate(values):
                self.table.setItem(row, column, QTableWidgetItem(value))
        table_layout.addWidget(self.table)
        layout.addWidget(table_card, 1)

        self._stage = 0
        self.timer = QTimer(self)
        self.timer.setInterval(520)
        self.timer.timeout.connect(self.advance_flow)

    def start_flow(self) -> None:
        self._stage = 0
        self.start_button.setEnabled(False)
        self.timer.start()
        self.advance_flow()

    def advance_flow(self) -> None:
        if self._stage >= len(self.STAGES):
            self.timer.stop()
            self.start_button.setEnabled(True)
            return
        text, value = self.STAGES[self._stage]
        self.progress.setValue(value)
        self.progress.setFormat(f"{text} · {value}%")
        self.status.setText(text if value < 100 else "Готово: все позиции проверены")
        self.status.setObjectName("Success" if value == 100 else "Info")
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        if value == 100:
            for row in range(self.table.rowCount()):
                self.table.item(row, 4).setText("Принят")
        self._stage += 1

    def reset_flow(self) -> None:
        self.timer.stop()
        self._stage = 0
        self.progress.setValue(0)
        self.progress.setFormat("Ожидание запуска")
        self.status.setText("Готово к запуску")
        self.status.setObjectName("Info")
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.start_button.setEnabled(True)
        for row in range(self.table.rowCount()):
            self.table.item(row, 4).setText("Готов")


class WarehousePage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        page, layout = page_header(
            "Склад",
            "Остатки и быстрый поиск по наименованию, штрихкоду, артикулу, цене и категории.",
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(page)

        search_card, search_layout = card()
        search_layout.addWidget(label("Поиск по всему каталогу", "CardTitle"))
        self.search = QLineEdit()
        self.search.setPlaceholderText("Наименование / ШК / артикул / цена / категория")
        self.search.textChanged.connect(self.queue_search)
        self.search.returnPressed.connect(self.apply_search)
        search_layout.addWidget(self.search)
        self.result_label = label("", "Muted")
        search_layout.addWidget(self.result_label)
        layout.addWidget(search_card)

        table_card, table_layout = card()
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Артикул", "Товар", "ШК", "Цена", "Остаток", "Категория"])
        configure_table(self.table, 1)
        table_layout.addWidget(self.table)
        layout.addWidget(table_card, 1)

        self.debounce = QTimer(self)
        self.debounce.setSingleShot(True)
        self.debounce.setInterval(190)
        self.debounce.timeout.connect(self.apply_search)
        self.apply_search()

    def queue_search(self) -> None:
        self.debounce.start()

    def matched_products(self, query: str) -> list[DemoProduct]:
        words = [word.casefold() for word in query.split() if word.strip()]
        if not words:
            return CATALOG
        result = []
        for product in CATALOG:
            haystack = " ".join(
                (
                    product.article,
                    product.name,
                    product.barcode,
                    str(product.price),
                    product.category,
                )
            ).casefold()
            if all(word in haystack for word in words):
                result.append(product)
        return result

    def apply_search(self) -> None:
        matches = self.matched_products(self.search.text())
        shown = matches[:60]
        self.table.setRowCount(len(shown))
        for row, product in enumerate(shown):
            values = (
                product.article,
                product.name,
                product.barcode,
                f"{product.price} ₽",
                str(product.stock),
                product.category,
            )
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                if column in (3, 4):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(row, column, item)
        suffix = f" · показаны первые {len(shown)}" if len(matches) > len(shown) else ""
        self.result_label.setText(f"Найдено: {len(matches)}{suffix}")


class PricePreviewDialog(QDialog):
    def __init__(self, rows: Iterable[tuple[str, str]]) -> None:
        super().__init__()
        self.setWindowTitle("Макет ценников")
        self.setMinimumSize(720, 520)
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 24, 24, 24)
        root.setSpacing(14)
        root.addWidget(label("Предварительный макет", "PageTitle"))
        root.addWidget(label("Демонстрация листа перед печатью.", "PageSubtitle"))
        grid = QHBoxLayout()
        for name, price in list(rows)[:3]:
            tag, tag_layout = card()
            tag.setMinimumSize(190, 210)
            tag_layout.addWidget(label(name, "CardTitle"))
            tag_layout.addStretch()
            price_label = label(price, "MetricValue")
            price_label.setAlignment(Qt.AlignRight)
            tag_layout.addWidget(price_label)
            barcode = QLabel("▌ ▌▌ ▌ ▌▌▌ ▌ ▌▌ ▌▌ ▌")
            barcode.setStyleSheet("font-family: Consolas; font-size: 24px; color: #111827;")
            barcode.setAlignment(Qt.AlignCenter)
            tag_layout.addWidget(barcode)
            grid.addWidget(tag)
        root.addLayout(grid)
        root.addStretch()
        close = QPushButton("Готово")
        close.setObjectName("Primary")
        close.clicked.connect(self.accept)
        root.addWidget(close, alignment=Qt.AlignRight)


class PriceTagsPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        page, layout = page_header(
            "Ценники",
            "Найдите товары, соберите список и посмотрите единый макет перед печатью.",
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(page)

        add_card, add_layout = card()
        add_layout.addWidget(label("Добавить товар", "CardTitle"))
        row = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Наименование / ШК / артикул")
        self.search.returnPressed.connect(self.add_product)
        row.addWidget(self.search, 1)
        add = QPushButton("Добавить")
        add.setObjectName("Primary")
        add.clicked.connect(self.add_product)
        row.addWidget(add)
        add_layout.addLayout(row)
        self.hint = label("Введите часть названия, штрихкод или артикул.", "Muted")
        add_layout.addWidget(self.hint)
        layout.addWidget(add_card)

        list_card, list_layout = card()
        header = QHBoxLayout()
        header.addWidget(label("Что попадёт на ценники", "CardTitle"))
        header.addStretch()
        preview = QPushButton("Показать макет")
        preview.setObjectName("Primary")
        preview.clicked.connect(self.show_preview)
        header.addWidget(preview)
        list_layout.addLayout(header)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Товар", "ШК", "Цена", ""])
        configure_table(self.table, 0)
        self.table.setEditTriggers(QTableWidget.DoubleClicked | QTableWidget.EditKeyPressed)
        list_layout.addWidget(self.table)
        layout.addWidget(list_card, 1)

    def find_product(self, query: str) -> DemoProduct | None:
        query = query.strip().casefold()
        if not query:
            return None
        for product in CATALOG:
            if query in f"{product.name} {product.article} {product.barcode}".casefold():
                return product
        return None

    def add_product(self) -> None:
        product = self.find_product(self.search.text())
        if product is None:
            self.hint.setText("Товар не найден. Попробуйте другой запрос.")
            return
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(product.name))
        self.table.setItem(row, 1, QTableWidgetItem(product.barcode))
        self.table.setItem(row, 2, QTableWidgetItem(f"{product.price} ₽"))
        remove = QPushButton("×")
        remove.setObjectName("Secondary")
        remove.setToolTip("Удалить из списка")
        remove.setFixedSize(36, 34)
        remove.clicked.connect(lambda _checked=False, button=remove: self.remove_button_row(button))
        self.table.setCellWidget(row, 3, remove)
        self.search.clear()
        self.hint.setText(f"Добавлено: {product.name}")

    def remove_button_row(self, button: QPushButton) -> None:
        for row in range(self.table.rowCount()):
            if self.table.cellWidget(row, 3) is button:
                self.table.removeRow(row)
                return

    def show_preview(self) -> None:
        if self.table.rowCount() == 0:
            self.hint.setText("Сначала добавьте хотя бы один товар.")
            return
        rows = (
            (self.table.item(row, 0).text(), self.table.item(row, 2).text())
            for row in range(self.table.rowCount())
        )
        PricePreviewDialog(rows).exec()


class AnalyticsPage(QWidget):
    def __init__(self) -> None:
        super().__init__()
        page, layout = page_header(
            "Аналитика",
            "Демонстрационные показатели магазина в компактном и понятном виде.",
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(page)

        metrics = QHBoxLayout()
        metrics.setSpacing(14)
        for title_text, value, detail in (
            ("Выручка сегодня", "₽ 38 450", "+12% к среднему"),
            ("Средний чек", "₽ 742", "52 продажи"),
            ("Товаров принято", "137", "за последние 7 дней"),
        ):
            frame, frame_layout = card()
            frame_layout.addWidget(label(title_text, "Muted"))
            frame_layout.addWidget(label(value, "MetricValue"))
            frame_layout.addWidget(label(detail, "Muted"))
            metrics.addWidget(frame)
        layout.addLayout(metrics)

        chart, chart_layout = card()
        chart_layout.addWidget(label("Продажи по дням", "CardTitle"))
        for day, value, amount in (
            ("Понедельник", 58, "₽ 24 100"),
            ("Вторник", 72, "₽ 29 880"),
            ("Среда", 64, "₽ 26 430"),
            ("Четверг", 83, "₽ 34 200"),
            ("Пятница", 94, "₽ 38 450"),
        ):
            row = QHBoxLayout()
            day_label = QLabel(day)
            day_label.setFixedWidth(110)
            row.addWidget(day_label)
            progress = QProgressBar()
            progress.setRange(0, 100)
            progress.setValue(value)
            progress.setFormat("")
            row.addWidget(progress, 1)
            amount_label = QLabel(amount)
            amount_label.setFixedWidth(90)
            amount_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            row.addWidget(amount_label)
            chart_layout.addLayout(row)
        layout.addWidget(chart)
        layout.addStretch()


class MainWindow(QMainWindow):
    PAGE_NAMES = ("Обзор", "Приёмка", "Склад", "Ценники", "Аналитика")

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"SAI Demo {DEMO_VERSION}")
        self.resize(1240, 800)
        self.setMinimumSize(1040, 680)

        root = QWidget()
        root.setObjectName("Root")
        self.setCentralWidget(root)
        shell = QHBoxLayout(root)
        shell.setContentsMargins(0, 0, 0, 0)
        shell.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(218)
        nav = QVBoxLayout(sidebar)
        nav.setContentsMargins(16, 22, 16, 18)
        nav.setSpacing(8)
        brand_row = QHBoxLayout()
        brand_row.addWidget(label("SAI", "Brand"))
        brand_row.addStretch()
        brand_row.addWidget(label("ДЕМО", "DemoPill"))
        nav.addLayout(brand_row)
        nav.addSpacing(18)

        self.stack = QStackedWidget()
        self.pages = [
            OverviewPage(self.navigate),
            ReceiptPage(),
            WarehousePage(),
            PriceTagsPage(),
            AnalyticsPage(),
        ]
        for page in self.pages:
            self.stack.addWidget(page)

        self.nav_buttons: list[QPushButton] = []
        icons = ("⌂", "↓", "▦", "▤", "↗")
        for index, (icon, name) in enumerate(zip(icons, self.PAGE_NAMES)):
            button = QPushButton(f"{icon}   {name}")
            button.setObjectName("NavButton")
            button.setCheckable(True)
            button.clicked.connect(lambda _checked=False, target=index: self.navigate(target))
            nav.addWidget(button)
            self.nav_buttons.append(button)
        nav.addStretch()
        notice = label("Демонстрационные данные\nСеть не используется", "Version")
        nav.addWidget(notice)
        nav.addWidget(label(f"SAI Demo · {DEMO_VERSION}", "Version"))

        shell.addWidget(sidebar)
        shell.addWidget(self.stack, 1)
        self.navigate(0)

    def navigate(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        for current, button in enumerate(self.nav_buttons):
            button.setChecked(current == index)


def create_application(argv: list[str] | None = None) -> QApplication:
    app = QApplication(argv if argv is not None else sys.argv)
    app.setApplicationName("SAI Demo")
    app.setApplicationVersion(DEMO_VERSION)
    app.setStyle("Fusion")
    app.setStyleSheet(APP_STYLE)
    return app


def main() -> int:
    app = create_application()
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
