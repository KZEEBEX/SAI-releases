from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
BUILD_ROOT = PROJECT_ROOT / "_demo_build"
RELEASE_ROOT = PROJECT_ROOT / "_demo_release" / "SAI_Demo"
ENTRYPOINT = ROOT / "sai_demo_app.py"
README = ROOT / "README_DEMO.txt"


def run(*args: str) -> None:
    subprocess.run(args, cwd=PROJECT_ROOT, check=True)


def ensure_clean_release() -> None:
    if BUILD_ROOT.exists():
        shutil.rmtree(BUILD_ROOT)
    if RELEASE_ROOT.parent.exists():
        shutil.rmtree(RELEASE_ROOT.parent)
    BUILD_ROOT.mkdir(parents=True)
    RELEASE_ROOT.mkdir(parents=True)


def verify_release() -> None:
    forbidden_extensions = {".py", ".pyc", ".pyo"}
    files = [path for path in RELEASE_ROOT.rglob("*") if path.is_file()]
    assert files, "Release is empty"
    assert any(path.suffix.casefold() == ".exe" for path in files), "Executable is missing"
    assert not [path for path in files if path.suffix.casefold() in forbidden_extensions]
    forbidden = ("sig" + "ma").encode("utf-8")
    for path in files:
        if path.suffix.casefold() in {".txt", ".json", ".ini", ".cfg"}:
            assert forbidden not in path.read_bytes().lower(), f"Forbidden text in {path}"


def main() -> int:
    ensure_clean_release()
    run(str(sys.executable), str(ROOT / "run_demo_tests.py"))
    run(
        str(sys.executable),
        "-m",
        "nuitka",
        "--mode=onefile",
        "--enable-plugin=pyside6",
        "--mingw64",
        "--assume-yes-for-downloads",
        "--windows-console-mode=disable",
        f"--output-dir={BUILD_ROOT}",
        f"--output-filename=SAI_Demo.exe",
        str(ENTRYPOINT),
    )
    executable = BUILD_ROOT / "SAI_Demo.exe"
    if not executable.exists():
        raise FileNotFoundError(executable)
    shutil.copy2(executable, RELEASE_ROOT / executable.name)
    shutil.copy2(README, RELEASE_ROOT / README.name)
    verify_release()
    archive = shutil.make_archive(
        str(RELEASE_ROOT.parent / "SAI_Demo_0.1.0_Windows"),
        "zip",
        root_dir=RELEASE_ROOT.parent,
        base_dir=RELEASE_ROOT.name,
    )
    print(f"READY: {archive}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
