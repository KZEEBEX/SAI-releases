from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from sai_demo_app import CATALOG, MainWindow, WarehousePage, create_application


def main() -> int:
    app = create_application(["sai-demo-test"])
    window = MainWindow()

    assert len(CATALOG) >= 90
    assert window.stack.count() == 5
    assert window.PAGE_NAMES == ("Обзор", "Приёмка", "Склад", "Ценники", "Аналитика")

    warehouse = window.pages[2]
    assert isinstance(warehouse, WarehousePage)
    assert warehouse.matched_products("рулетка")
    assert warehouse.matched_products(CATALOG[0].barcode)[0] == CATALOG[0]
    assert warehouse.matched_products(CATALOG[0].article)[0] == CATALOG[0]
    assert warehouse.matched_products(str(CATALOG[0].price))

    source = Path(__file__).with_name("sai_demo_app.py").read_text(encoding="utf-8").casefold()
    forbidden = "sig" + "ma"
    assert forbidden not in source
    assert "requests" not in source
    assert "playwright" not in source
    assert "urllib" not in source

    window.close()
    app.quit()
    print("SAI demo tests: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
